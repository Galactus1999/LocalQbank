# Rovex 8.3.167 — CI Compile Fix for v8.3.166

VersionCode: 264

## Root cause (from CI build log)

```
e: BenInferenceProcessService.kt:109:14 Unresolved reference 'setSilent'.
```

v8.3.166 called `.setSilent(true)` on `android.app.Notification.Builder`. That method
does not exist on the framework `Notification.Builder` class at this project's compile
SDK -- I was thinking of `androidx.core.app.NotificationCompat.Builder.setSilent()`,
which does exist (it's the AndroidX mirror of the platform API added in Android 11/API
30, and no-ops safely below that). This is a genuine compile error, not a version-gating
issue that `Build.VERSION.SDK_INT` checks could have fixed -- the compiler needs the
symbol to exist in the SDK stub regardless of any runtime guard.

## Fix

`buildNotification()` in `BenInferenceProcessService.kt` now builds the foreground
notification with `androidx.core.app.NotificationCompat.Builder` instead of the framework
`Notification.Builder`. The project already depends on `androidx.core:core-ktx`, which
pulls in `androidx.core:core` (and `NotificationCompat`), so no new dependency was added.
`NotificationCompat.Builder.build()` still returns a plain `android.app.Notification`, so
`startForeground(FOREGROUND_NOTIFICATION_ID, buildNotification())` is unchanged.

No other logic from v8.3.166 changed: foreground promotion is still reference-counted
around in-flight generation/diagnostic requests, the wake lock and its 130s backstop are
unchanged, and the manifest permissions/`specialUse` type are unchanged.

## Scope

`BenInferenceProcessService.kt` only (import + `buildNotification()`).

## Verification status

The exact line CI failed on (`.setSilent(true)` on the framework builder) is fixed and
the file's braces/parens are balanced; not compiled end-to-end in this environment
(no network/Android SDK here -- same limitation as every prior release in this thread).
This should be verified by CI or a local build before being treated as green.
