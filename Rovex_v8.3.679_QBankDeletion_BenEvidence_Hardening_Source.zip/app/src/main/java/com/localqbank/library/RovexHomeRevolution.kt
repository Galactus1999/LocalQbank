package com.localqbank.library

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.airbnb.lottie.RenderMode
import kotlin.math.abs

/** Home dashboard: adaptive, data-backed and deliberately light on runtime work. */
object RovexHomeRevolution {
    private const val TAG = "ROVEX_HOME_SHELL"
    private data class DynamicResult(val today:Int,val attempted:Int,val correct:Int,val wrong:Int,val week:Int,val daily:Int,val weekly:Int,val bookmarks:Int,val todayRecords:List<Pair<Long,Boolean>>,val days:List<Last28StudyDaysGraphView.Day>)
    private fun d(v:Int,c:Context)=(v*c.resources.displayMetrics.density).toInt()
    private const val MOTION_BG_TAG = "rovex_home_motion_background"
    private const val MOTION_CARD_PREFIX = "rovex_home_motion_card:"
    private const val MOTION_HEADER_TAG = "rovex_home_motion_header"
    private const val MOTION_LOGO_TAG = "rovex_home_motion_logo"
    private var motionPolicyAllowed = true
    private fun motionAlpha(c:Context, background:Boolean):Float {
        val card = when (ThemeManager.get(c)) {
            ThemeManager.LIGHT -> 0.14f
            ThemeManager.PASTEL -> 0.12f // compatibility theme; not the design target
            ThemeManager.MINT -> 0.13f
            ThemeManager.SUNSET -> 0.14f
            ThemeManager.LAVENDER -> 0.13f
            ThemeManager.AMOLED -> 0.09f
            ThemeManager.PANDORA -> 0.12f
            ThemeManager.SPACE -> 0.10f
            else -> 0.12f
        }
        return if (background) card * 0.42f else card
    }

    private fun motionBackground(c:Context, tagValue:String, background:Boolean=false):LottieAnimationView? {
        val view = LottieAnimationView(c).apply {
            tag = tagValue
            // Card animation follows theme tokens; text-flow controls affect text only.
            val first = if (tagValue.startsWith(MOTION_CARD_PREFIX)) ThemeManager.accent(c) else RovexColorFlowTextView.colorOne(c)
            val second = if (tagValue.startsWith(MOTION_CARD_PREFIX)) ThemeManager.accentSecondary(c) else RovexColorFlowTextView.colorTwo(c)
            setAnimationFromJson(RovexMotionAssetLoader.themedJson(c, first, second), "rovex_home_gradient_" + ThemeManager.get(c) + "_" + first + "_" + second)
            repeatCount = LottieDrawable.INFINITE
            repeatMode = LottieDrawable.RESTART
            speed = 0.38f
            alpha = if (background) motionAlpha(c, true) else motionAlpha(c, false)
            scaleType = ImageView.ScaleType.CENTER_CROP
            renderMode = RenderMode.HARDWARE
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            contentDescription = null
        }
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v:View) {
                v.post { (v as? LottieAnimationView)?.let { updateMotionView(it, c) } }
            }
            override fun onViewDetachedFromWindow(v:View) {
                runCatching { (v as? LottieAnimationView)?.cancelAnimation() }
            }
        })
        return view
    }

    private fun updateMotionView(view:LottieAnimationView, c:Context, forcePause:Boolean=false) {
        val tag = view.tag as? String ?: return
        if (tag != MOTION_BG_TAG && !tag.startsWith(MOTION_CARD_PREFIX) && tag != MOTION_HEADER_TAG && tag != MOTION_LOGO_TAG) return
        view.alpha = if (tag == MOTION_LOGO_TAG) 0.18f else if (tag == MOTION_HEADER_TAG) when (ThemeManager.get(c)) {
            ThemeManager.LIGHT -> 0.54f
            ThemeManager.PASTEL -> 0.48f
            ThemeManager.MINT -> 0.42f
            ThemeManager.SUNSET -> 0.48f
            ThemeManager.LAVENDER -> 0.48f
            ThemeManager.AMOLED -> 0.28f
            ThemeManager.PANDORA -> 0.34f
            ThemeManager.SPACE -> 0.28f
            else -> 0.40f
        } else if (tag.startsWith(MOTION_CARD_PREFIX)) motionAlpha(c, false) else motionAlpha(c, tag == MOTION_BG_TAG)
        val cardMotionAllowed = !tag.startsWith(MOTION_CARD_PREFIX) || RovexLiveMotionSettings.surfaceFlowEnabled(c)
        if (tag == MOTION_BG_TAG || tag.startsWith(MOTION_CARD_PREFIX) || tag == MOTION_LOGO_TAG) {
            val cardSurface = tag.startsWith(MOTION_CARD_PREFIX)
            val first = if (cardSurface) ThemeManager.accent(c) else RovexColorFlowTextView.colorOne(c)
            val second = if (cardSurface) ThemeManager.accentSecondary(c) else RovexColorFlowTextView.colorTwo(c)
            val paletteKey = ThemeManager.get(c) + ":" + first + ":" + second + ":" + (if (cardSurface) "theme-card" else "flow")
            if (view.getTag(R.id.rovexMotionPaletteKey) != paletteKey) {
                view.setTag(R.id.rovexMotionPaletteKey, paletteKey)
                view.setAnimationFromJson(RovexMotionAssetLoader.themedJson(c, first, second), "rovex_home_gradient_" + ThemeManager.get(c) + "_" + first + "_" + second)
            }
        }
        // Keep the header motion slot measured when animation policy disables playback.
        // GONE collapses the Lottie child to 0x0 and breaks Home geometry diagnostics;
        // INVISIBLE preserves the fixed 11dp header layout without rendering or animating it.
        view.visibility = when {
            motionPolicyAllowed && cardMotionAllowed -> View.VISIBLE
            tag == MOTION_HEADER_TAG -> View.INVISIBLE
            else -> View.GONE
        }
        val visibleRect = android.graphics.Rect()
        val visible = !forcePause && view.isShown &&
            view.getGlobalVisibleRect(visibleRect) && visibleRect.width() > 0 && visibleRect.height() > 0
        if (visible && motionPolicyAllowed) {
            if (!view.isAnimating()) {
                if (view.progress > 0f) runCatching { view.resumeAnimation() }
                else runCatching { view.playAnimation() }
            }
        } else if (view.isAnimating()) {
            runCatching { view.pauseAnimation() }
        }
    }

    private fun updateMotionTree(view:View, c:Context, forcePause:Boolean=false) {
        if (view is LottieAnimationView) updateMotionView(view, c, forcePause)
        if (view is ViewGroup) for (i in 0 until view.childCount) updateMotionTree(view.getChildAt(i), c, forcePause)
    }

    fun pauseMotion(a:MainActivity) {
        val root = a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        root.findViewWithTag<FrameLayout>(TAG)?.let { updateMotionTree(it, a, true) }
    }


    private fun tv(c:Context,s:String,z:Float,col:Int=ThemeManager.text(c),bold:Boolean=true)=TextView(c).apply{
        text=s;textSize=z;setTextColor(col);if(bold)setTypeface(typeface,Typeface.BOLD);includeFontPadding=false
    }

    private fun card(c:Context,index:Int=0):android.graphics.drawable.Drawable {
        return RovexVisualSurfaceStyle.glass(c,22f,true)
    }

    private fun bookmarkSurface(c:Context, tintColor:Int, radiusDp:Float):android.graphics.drawable.Drawable {
        val radius = d(radiusDp.toInt(),c).toFloat()
        if (!RovexSurfaceSettings.isGlassEnabled(c)) {
            return GradientDrawable().apply { setColor(tintColor); cornerRadius=radius; setStroke(d(1,c),Color.argb(55,100,120,140)) }
        }
        val glass = RovexVisualSurfaceStyle.glass(c,radiusDp,true)
        val tint = GradientDrawable().apply {
            setColor(Color.argb(if(ThemeManager.isDark(c))34 else 24,Color.red(tintColor),Color.green(tintColor),Color.blue(tintColor)))
            cornerRadius=radius
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glass,tint))
    }

    private fun withMotionSurface(view:View, a:MainActivity, name:String, radiusDp:Float=22f, fillHeight:Boolean=false):View {
        // Geometry safety fix: the previous wrapper replaced each original view's LayoutParams
        // with FrameLayout.LayoutParams(-1, -1/-2), and then layered a full-size Lottie viewport
        // over it. That extra measurement parent can expand cards or stretch pastel surfaces,
        // especially in nested LinearLayout/GridLayout/weighted rows. Return the original view
        // untouched until each motion surface can be implemented without changing layout geometry.
        // Preserve its background, LayoutParams, click target, elevation, tags and accessibility.
        return view
    }

    private fun installMotionSurfaces(root:ViewGroup, a:MainActivity) {
        // No heuristic view reparenting on Home. Motion must not alter card geometry.
        root.setTag(R.id.rovexMotionSurfaceScan, true)
    }

    private fun feature(a:MainActivity,title:String,sub:String,icon:String,index:Int,target:()->Unit):View{
        val box=FrameLayout(a).apply{background=card(a,index);setPadding(0,0,0,0);clipChildren=true;clipToPadding=true;isClickable=true;isFocusable=true;elevation=d(4,a).toFloat();setOnClickListener{target()}}
        motionBackground(a, MOTION_CARD_PREFIX + title)?.let { motion ->
            val clip = FrameLayout(a).apply {
                tag = "rovex_motion_clip"
                background = GradientDrawable().apply { cornerRadius = d(22,a).toFloat(); setColor(Color.TRANSPARENT) }
                clipToOutline = true
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            clip.addView(motion, FrameLayout.LayoutParams(-1,-1))
            box.addView(clip, FrameLayout.LayoutParams(-1,-1))
        }
        val col=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(11,a),d(9,a),d(8,a),d(8,a))}
        val iconColor=ThemeManager.accent(a)
        if (ThemeManager.get(a) == ThemeManager.LIGHT) {
            val iconKind = when (title) { "QBank" -> 0; "Flashcards" -> 1; "Performance Lab" -> 2; "Study Health" -> 3; else -> 4 }
            val iconFrame = FrameLayout(a).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.argb(28, 38, 91, 230))
                    setStroke(d(1,a), Color.argb(70, 38, 91, 230))
                }
                elevation = d(2,a).toFloat()
            }
            iconFrame.addView(RovexClinicalFeatureIconView(a, iconKind), FrameLayout.LayoutParams(-1,-1).apply { setMargins(d(8,a),d(8,a),d(8,a),d(8,a)) })
            col.addView(iconFrame,LinearLayout.LayoutParams(d(40,a),d(40,a)).apply{bottomMargin=d(6,a)})
        } else if(title=="Frankenstein") {
            col.addView(RovexHeaderCosmicView(a),LinearLayout.LayoutParams(d(54,a),d(54,a)).apply{bottomMargin=d(6,a)})
        } else {
            col.addView(tv(a,icon,29f,iconColor,true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Color.argb(if(ThemeManager.isDark(a))55 else 95,Color.red(iconColor),Color.green(iconColor),Color.blue(iconColor)));setStroke(d(1,a),Color.argb(90,Color.red(iconColor),Color.green(iconColor),Color.blue(iconColor)))}},LinearLayout.LayoutParams(d(50,a),d(50,a)).apply{bottomMargin=d(8,a)})
        }
        col.addView(tv(a,title,16f,ThemeManager.text(a),true))
        col.addView(tv(a,sub,10.5f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(4,a)})
        box.addView(col,FrameLayout.LayoutParams(-1,-1))
        box.addView(tv(a,"›",28f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER},FrameLayout.LayoutParams(d(30,a),d(30,a),Gravity.END or Gravity.BOTTOM))
        return box
    }

    private fun openSection(a:MainActivity,id:String,focusKind:String?=null){
        a.startActivity(Intent(a,RovexSectionDashboardActivity::class.java).apply{
            putExtra("section",id);focusKind?.let{putExtra("focusKind",it)}
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        })
    }

    private fun navigateNav(a:MainActivity,index:Int,flashcards:View?){
        when(index.coerceIn(0,4)){
            0->a.startActivity(Intent(a,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            1->openSection(a,"qbank")
            2->a.startActivity(Intent(a,FlashcardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            3->a.startActivity(Intent(a,RenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            4->a.startActivity(Intent(a,StudyToolsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }

    fun refreshTheme(a:MainActivity){
        val root=a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        motionPolicyAllowed = AnimationPolicy.enabled(a) && RovexLiveMotionSettings.enabled(a)
        root.findViewWithTag<FrameLayout>(TAG)?.let {
            it.background = ThemeManager.backgroundDrawable(a)
            updateMotionTree(it, a)
            it.invalidate()
        }
    }

    fun apply(a:MainActivity){
        val root=a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        if(root.findViewWithTag<FrameLayout>(TAG)!=null)return
        motionPolicyAllowed = AnimationPolicy.enabled(a) && RovexLiveMotionSettings.enabled(a)
        val shell=FrameLayout(a).apply{tag=TAG;contentDescription="rovexHomeShell";background=ThemeManager.backgroundDrawable(a)}
        val scroll=ScrollView(a).apply{tag="ROVEX_HOME_SCROLL";overScrollMode=View.OVER_SCROLL_NEVER;clipToPadding=false;isFillViewport=true}
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> updateMotionTree(shell, a) }
        // The persistent five-tab shell is owned exclusively by RovexBottomNavigation.
        // Keep enough trailing space for that shell, but do not create a second in-content footer.
        val content=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(12,a),d(12,a),d(12,a),d(82,a))}
        scroll.addView(content);shell.addView(scroll,FrameLayout.LayoutParams(-1,-1))

        val header=FrameLayout(a)
        val top=LinearLayout(a).apply{gravity=Gravity.CENTER_VERTICAL}
        top.addView(RovexHeaderCosmicView(a),LinearLayout.LayoutParams(d(42,a),d(40,a)).apply{rightMargin=d(4,a)})
        top.addView(RovexWaveTextView(a).apply{text="Rovex";textSize=27f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(a));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,d(44,a),1f))
        top.addView(tv(a,"⚙",23f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;contentDescription="Settings";background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(ThemeManager.peacockFill(a));setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{a.startActivity(Intent(a,SettingsActivity::class.java))}},LinearLayout.LayoutParams(d(42,a),d(42,a)))
        header.addView(top,FrameLayout.LayoutParams(-1,d(48,a),Gravity.TOP))
        val motion = LottieAnimationView(a).apply {
            tag = MOTION_HEADER_TAG
            setAnimation(R.raw.rovex_header_flow)
            repeatCount = LottieDrawable.INFINITE
            repeatMode = LottieDrawable.RESTART
            speed = 0.55f
            alpha = if (ThemeManager.isDark(a)) 0.32f else 0.48f
            renderMode = RenderMode.HARDWARE
            contentDescription = null
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) { v.post { (v as? LottieAnimationView)?.let { updateMotionView(it, a) } } }
                override fun onViewDetachedFromWindow(v: View) { runCatching { (v as? LottieAnimationView)?.cancelAnimation() } }
            })
        }
        header.addView(motion, FrameLayout.LayoutParams(-1, d(11,a), Gravity.BOTTOM).apply {
            leftMargin = d(18,a); rightMargin = d(18,a); bottomMargin = 0
        })
        content.addView(header,LinearLayout.LayoutParams(-1,d(52,a)).apply{bottomMargin=d(7,a)})

        if (ThemeManager.get(a) == ThemeManager.LIGHT) {
            val hero = FrameLayout(a).apply {
                background = RovexClinicalSurfaceDrawable(d(24,a).toFloat(), ThemeManager.accent(a), ThemeManager.accentSecondary(a), AnimationPolicy.enabled(a))
                elevation = d(5,a).toFloat()
                setPadding(d(14,a),d(9,a),d(10,a),d(9,a))
                tag = "rovex_home_clinical_hero"
                contentDescription = "Clinical Day study cockpit"
            }
            val copy = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            copy.addView(tv(a,"TODAY • STUDY COCKPIT",10f,ThemeManager.accent(a),true))
            copy.addView(tv(a,"Build momentum, one question at a time.",16f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(5,a)})
            copy.addView(tv(a,"Your saved answer history drives the dashboard.",10.5f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(4,a)})
            hero.addView(copy,FrameLayout.LayoutParams(-1,-1).apply{rightMargin=d(78,a);gravity=Gravity.START or Gravity.CENTER_VERTICAL})
            val ring = RovexClinicalFocusRingView(a).apply { tag="rovex_home_clinical_focus_ring" }
            hero.addView(ring,FrameLayout.LayoutParams(d(64,a),d(64,a),Gravity.END or Gravity.CENTER_VERTICAL))
            content.addView(withMotionSurface(hero,a,"clinical-hero",24f,true),LinearLayout.LayoutParams(-1,d(88,a)).apply{bottomMargin=d(9,a)})
        }

        val search=tv(a,"⌕   Search questions, topics, anything…   ✦",14f,ThemeManager.text(a),false).apply{gravity=Gravity.CENTER_VERTICAL;tag="rovex_home_search";contentDescription="rovexHomeSearch";setPadding(d(12,a),0,d(12,a),0);background=card(a,0);setOnClickListener{a.startActivity(Intent(a,SearchActivity::class.java).putExtra("focusSearch",true))}}
        content.addView(withMotionSurface(search,a,"home-search",22f,true),LinearLayout.LayoutParams(-1,d(46,a)).apply{bottomMargin=d(9,a)})

        val online=LinearLayout(a).apply{tag="rovex_home_online";orientation=LinearLayout.VERTICAL;setPadding(d(12,a),d(8,a),d(12,a),d(7,a));background=card(a,0);isClickable=true;setOnClickListener{a.startActivity(Intent(a,RovexOnlineActivity::class.java))}}
        val onlineHead=LinearLayout(a).apply{gravity=Gravity.CENTER_VERTICAL}
        onlineHead.addView(tv(a,"☁",24f,ThemeManager.accent(a),true),LinearLayout.LayoutParams(d(32,a),d(32,a)))
        val onlineCopy=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL}
        onlineCopy.addView(tv(a,"Rovex Online",14.5f,ThemeManager.text(a),true))
        val onlineStatus=tv(a,if(RovexOnlineAuth.currentUser()!=null)"Connected • progress & friends" else "Optional • friends, streak & synced progress",10.5f,ThemeManager.muted(a),false).apply{tag="rovex_home_online_status"}
        onlineCopy.addView(onlineStatus,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)})
        onlineHead.addView(onlineCopy,LinearLayout.LayoutParams(0,-2,1f))
        onlineHead.addView(tv(a,"›",22f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(d(26,a),d(30,a)))
        online.addView(onlineHead)
        content.addView(withMotionSurface(online,a,"online-card",22f),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(8,a)})

        val quote=LinearLayout(a).apply{tag="rovex_home_daily_motivation";orientation=LinearLayout.VERTICAL;setPadding(d(12,a),d(8,a),d(12,a),d(8,a));background=card(a,2)}
        quote.addView(tv(a,"✦  DAILY MOTIVATION",10f,ThemeManager.accent(a),true))
        val dailyQuote=RovexDailyNotificationContent.quoteForNow(java.time.ZonedDateTime.now(java.time.ZoneId.systemDefault()))
        quote.addView(tv(a,"“$dailyQuote”",13.5f,ThemeManager.text(a),true).apply{tag="rovex_home_daily_quote";includeFontPadding=false},LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(4,a)})
        content.addView(withMotionSurface(quote,a,"daily-motivation",22f),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(9,a)})
        val quoteView = quote.findViewWithTag<TextView>("rovex_home_daily_quote")
        val quoteRefresh = object : Runnable {
            override fun run() {
                if (a.isFinishing || a.isDestroyed || !quoteView.isAttachedToWindow) return
                quoteView.text = "“${RovexDailyNotificationContent.quoteForNow(java.time.ZonedDateTime.now(java.time.ZoneId.systemDefault()))}”"
                val now = java.time.ZonedDateTime.now(java.time.ZoneId.systemDefault())
                val next = when {
                    now.toLocalTime().isBefore(java.time.LocalTime.of(7,0)) -> now.withHour(7).withMinute(0).withSecond(0).withNano(0)
                    now.toLocalTime().isBefore(java.time.LocalTime.of(17,0)) -> now.withHour(17).withMinute(0).withSecond(0).withNano(0)
                    else -> now.plusDays(1).withHour(7).withMinute(0).withSecond(0).withNano(0)
                }
                quoteView.postDelayed(this, java.time.Duration.between(now, next).toMillis().coerceAtLeast(60_000L))
            }
        }
        quoteView.postDelayed(quoteRefresh, 60_000L)
        shell.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) { quoteView.removeCallbacks(quoteRefresh) }
        })

        val progress=LinearLayout(a).apply{tag="rovex_home_today_progress";orientation=LinearLayout.VERTICAL;setPadding(d(12,a),d(10,a),d(12,a),d(10,a));background=card(a,2);elevation=d(3,a).toFloat()}
        val progressTitle=tv(a,"Today's Progress",15.5f,ThemeManager.text(a),true)
        val progressValue=tv(a,"Loading calibrated progress…",24f,ThemeManager.text(a),true).apply{tag="rovex_home_progress_value"}
        val progressMeta=tv(a,"Using saved answers only",11.5f,ThemeManager.muted(a),false).apply{tag="rovex_home_progress_meta"}
        val progressGraph=TodayProgressGraphView(a).apply{tag="rovex_home_progress_graph";contentDescription="Today-only accuracy timeline"}
        val continueButton=tv(a,"▶  CONTINUE MOST RECENT QBANK",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{
            isEnabled = false
            AppManagers.qbankLoading.loadLatestResumeTarget { target ->
                a.runOnUiThread {
                    isEnabled = true
                    if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                    if(target!=null)a.startActivity(Intent(a,QuizActivity::class.java).apply {
    putExtra("testId", target.testId)
    putExtra("title", target.title)
    putExtra("position", target.position)
    if (target.questionId > 0L) putExtra("questionId", target.questionId)
    putExtra("resumeLaunch", true)
    putExtra("practiceMode", true)
})
                    else a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))
                }
            }
        }}
        progress.addView(progressTitle);progress.addView(progressValue,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)});progress.addView(progressGraph,LinearLayout.LayoutParams(-1,d(76,a)).apply{topMargin=d(5,a)});progress.addView(progressMeta,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)});progress.addView(continueButton,LinearLayout.LayoutParams(-1,d(34,a)).apply{topMargin=d(6,a)})
        content.addView(withMotionSurface(progress,a,"today-progress",22f),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(9,a)})

        val grid=GridLayout(a).apply{columnCount=2}
        fun add(v:View,i:Int){val lp=GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED,1f),GridLayout.spec(GridLayout.UNDEFINED,1f));lp.width=0;lp.height=d(128,a);lp.setMargins(d(4,a),d(4,a),d(4,a),d(4,a));grid.addView(v,lp)}
        add(feature(a,"QBank","19 subjects • imported content","📚",0){openSection(a,"qbank")}.apply{tag="modern_feature_qbank";contentDescription="qbankHomeCard"},0)
        add(feature(a,"Flashcards","Spaced repetition • review","🧠",1){a.startActivity(Intent(a,FlashcardActivity::class.java))}.apply{tag="modern_feature_flashcards"},1)
        add(feature(a,"Performance Lab","Measured study telemetry","📊",2){a.openPerformanceLabFromModernHome()},2)
        add(feature(a,"Study Health","Due cards • weak areas • streak risk","♥",3){a.startActivity(Intent(a,StudyHealthActivity::class.java))},3)
        add(feature(a,"Frankenstein","Ben / AI study partner","🤖",0){a.startActivity(Intent(a,RenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))},0)
        content.addView(grid,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(9,a)})

        val qbox=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,1)}
        qbox.addView(tv(a,"QBank Library",17f,ThemeManager.text(a),true))
        qbox.addView(tv(a,"Browse the main imported QBank list, then open any bank for its subject/test content.",11.5f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(3,a)})
        val qb=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun action(label:String,click:()->Unit)=tv(a,label,10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.peacockFill(a));cornerRadius=d(18,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{click()}}
        qb.addView(action("BROWSE QBANKS"){a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))},LinearLayout.LayoutParams(0,d(44,a),1f).apply{rightMargin=d(4,a)})
        qb.addView(action("IMPORT QBANK"){a.openQBankImporterFromHome()},LinearLayout.LayoutParams(0,d(44,a),1f).apply{leftMargin=d(4,a)})
        qbox.addView(qb,LinearLayout.LayoutParams(-1,d(44,a)).apply{topMargin=d(8,a)})
        content.addView(withMotionSurface(qbox,a,"qbank-library",22f),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        val bookmarksBox=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,0)}
        bookmarksBox.addView(tv(a,"🔖  Bookmarked MCQs",17f,ThemeManager.text(a),true))
        bookmarksBox.addView(tv(a,"Saved questions remain independent of solved / wrong / marked status.",11.5f,ThemeManager.muted(a),false).apply{tag="rovex_home_bookmarks_meta"},LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(3,a)})
        bookmarksBox.addView(tv(a,"OPEN BOOKMARKS  →",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{a.startActivity(Intent(a,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue","all"))}},LinearLayout.LayoutParams(-1,d(40,a)).apply{topMargin=d(8,a)})
        content.addView(withMotionSurface(bookmarksBox,a,"bookmarks",22f),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(10,a)})
        val bookmarkCollections = listOf(
            Triple("★  Important", "important", ThemeManager.bookmarkFill(a,"important")),
            Triple("↻  Revise", "revise", ThemeManager.bookmarkFill(a,"revise")),
            Triple("❔  Doubt", "doubt", ThemeManager.bookmarkFill(a,"doubt")),
            Triple("♥  Favourite", "favorite", ThemeManager.bookmarkFill(a,"favorite"))
        )
        val bookmarkGrid=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL}
        val bookmarkViews=linkedMapOf<String,TextView>()
        bookmarkCollections.chunked(2).forEachIndexed{rowIndex,rowItems->
            val rr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL;weightSum=2f}
            rowItems.forEachIndexed{cellIndex,item->
                val key=item.second
                val b=tv(a,"${item.first}\n…",12.5f,ThemeManager.bookmarkText(a,key),true).apply{
                    gravity=Gravity.CENTER; textAlignment=View.TEXT_ALIGNMENT_CENTER; background=bookmarkSurface(a,item.third,16f)
                    setPadding(d(6,a),d(4,a),d(6,a),d(4,a))
                    setOnClickListener{a.startActivity(Intent(a,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue",key))}
                    contentDescription="${item.first} bookmark collection"
                }
                bookmarkViews[key]=b
                rr.addView(withMotionSurface(b,a,"bookmark-${key}",16f,true),LinearLayout.LayoutParams(0,d(66,a),1f).apply{if(cellIndex>0)setMargins(d(6,a),0,0,0)})
            }
            bookmarkGrid.addView(rr,LinearLayout.LayoutParams(-1,d(66,a)).apply{if(rowIndex>0)setMargins(0,d(6,a),0,0)})
        }
        content.addView(bookmarkGrid,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})
        PerformanceManager.submit {
            val counts=runCatching { QBankDb(a.applicationContext).let { db -> try { db.bookmarkCounts() } finally { db.close() } } }
                .getOrDefault(emptyMap())
            a.runOnUiThread {
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                bookmarkViews.forEach { (key,view) ->
                    val label=bookmarkCollections.firstOrNull{it.second==key}?.first ?: key
                    val count=counts[key] ?: 0
                    view.text="$label\n$count"
                    view.contentDescription="$label bookmark collection, $count saved"
                }
            }
        }

        RovexDailyStudyHub.install(a,content,null){a.startActivity(Intent(a,FlashcardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))}

        content.addView(tv(a,"Quick Tools",18f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{leftMargin=d(3,a);bottomMargin=d(7,a)})
        val qr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL}
        val qscroll=HorizontalScrollView(a).apply{isHorizontalScrollBarEnabled=false}
        val tools=listOf(
            "▣\nPYQ" to {openSection(a,"qbank","PYQ")},
            "✓\nTests" to {openSection(a,"tests","Subject Test")},
            "✎\nNotes" to {a.startActivity(Intent(a,NotesActivity::class.java))},
            "🔖\nBookmarks" to {a.startActivity(Intent(a,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue","all"))},
            "▤\nLibrary" to {a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))},
            "⌘\nTools" to {a.startActivity(Intent(a,StudyToolsActivity::class.java))},
            "⚙\nSettings" to {a.startActivity(Intent(a,SettingsActivity::class.java))}
        )
        tools.forEachIndexed{index,p->val tool=tv(a,p.first,13f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER;background=card(a,index);setOnClickListener{p.second()}};qr.addView(withMotionSurface(tool,a,"quick-tool-$index",18f,true),LinearLayout.LayoutParams(d(98,a),d(70,a)).apply{rightMargin=d(7,a)})}
        qscroll.addView(qr);content.addView(qscroll,LinearLayout.LayoutParams(-1,d(68,a)).apply{bottomMargin=d(10,a)})

        val goal=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,2)}
        val goalTitle=tv(a,"🏆  Weekly Goal",17f,ThemeManager.text(a),true)
        val goalText=tv(a,"Goals not set",12.5f,ThemeManager.muted(a),false).apply{tag="rovex_home_goal_text"}
        val goalBar=ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal).apply{tag="rovex_home_goal_bar";max=100;this.progress=0;progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(a));progressBackgroundTintList=android.content.res.ColorStateList.valueOf(ThemeManager.peacockFill(a))}
        val setGoals=tv(a,"SET DAILY / WEEKLY GOAL",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{showGoalDialog(a){refreshDynamic(a,progressValue,progressMeta,progressGraph,goalText,goalBar)}}}
        goal.addView(goalTitle);goal.addView(goalText,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(6,a)});goal.addView(goalBar,LinearLayout.LayoutParams(-1,d(7,a)).apply{topMargin=d(7,a)});goal.addView(setGoals,LinearLayout.LayoutParams(-1,d(38,a)).apply{topMargin=d(8,a)})
        content.addView(withMotionSurface(goal,a,"weekly-goal",22f),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        content.addView(tv(a,"Continue Learning",18f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{leftMargin=d(3,a);bottomMargin=d(7,a)})
        val hs=HorizontalScrollView(a).apply{isHorizontalScrollBarEnabled=false};val hr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL;id=R.id.rovexHomeContinueRow};hs.addView(hr)
        content.addView(hs,LinearLayout.LayoutParams(-1,d(128,a)).apply{bottomMargin=d(13,a)})
        refreshContinue(a,hr)



        // No legacy footer here. RovexBottomNavigation installs the single persistent
        // five-destination shell as a sibling of the dashboard root.

        var downX=0f;var downY=0f
        shell.setOnTouchListener{_,e->when(e.actionMasked){MotionEvent.ACTION_DOWN->{downX=e.x;downY=e.y;true};MotionEvent.ACTION_UP->{val dx=e.x-downX;val dy=e.y-downY;if(abs(dx)>d(72,a)&&abs(dx)>abs(dy)*1.3f){if(dx<0)navigateNav(a,1,null) else navigateNav(a,3,null);true}else false};else -> false}}
        root.addView(shell,ViewGroup.LayoutParams(-1,-1))
        shell.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(v:View,l:Int,t:Int,r:Int,b:Int,ol:Int,ot:Int,oright:Int,ob:Int) {
                if (shell.width <= 0 || shell.height <= 0) return
                shell.removeOnLayoutChangeListener(this)
                installMotionSurfaces(shell, a)
                AliveMotion.installTree(shell)
                updateMotionTree(shell, a)
            }
        })
        shell.post { updateMotionTree(shell, a) }

        refreshDynamic(a,progressValue,progressMeta,progressGraph,goalText,goalBar)
    }

    fun refreshData(a: MainActivity) {
        val root = a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        val shell = root.findViewWithTag<FrameLayout>(TAG) ?: return
        val value = shell.findViewWithTag<TextView>("rovex_home_progress_value") ?: return
        val meta = shell.findViewWithTag<TextView>("rovex_home_progress_meta") ?: return
        val graph = shell.findViewWithTag<TodayProgressGraphView>("rovex_home_progress_graph") ?: return
        val goalText = shell.findViewWithTag<TextView>("rovex_home_goal_text") ?: return
        val goalBar = shell.findViewWithTag<ProgressBar>("rovex_home_goal_bar") ?: return
        refreshDynamic(a, value, meta, graph, goalText, goalBar)
        val dailyQuote=RovexDailyNotificationContent.quoteForNow(java.time.ZonedDateTime.now(java.time.ZoneId.systemDefault()))
        shell.findViewWithTag<TextView>("rovex_home_daily_quote")?.text = "“$dailyQuote”"
        shell.findViewWithTag<TextView>("rovex_home_online_status")?.text = if (RovexOnlineAuth.currentUser()!=null) "Connected • progress & friends" else "Optional • friends, streak & synced progress"
        val continueRow = shell.findViewById<LinearLayout>(R.id.rovexHomeContinueRow)
        if (continueRow != null) refreshContinue(a, continueRow)
    }

    private fun refreshContinue(a:MainActivity,row:LinearLayout){
        AppManagers.qbankLoading.loadSources { sources ->
            AppManagers.qbankLoading.loadDashboardRows { rows ->
            val cards=sources.map{src->
                val relevant=rows.filter{it.source==src.fileName};val total=relevant.sumOf{it.total};val solved=relevant.sumOf{it.solved};Triple(src,total,solved)
            }.sortedByDescending{it.third}.take(6)
            a.runOnUiThread{
                val hr=row
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                hr.removeAllViews()
                if(cards.isEmpty()){
                    hr.addView(tv(a,"No imported QBank yet\nImport a QBank to start learning",13f,ThemeManager.muted(a),false).apply{gravity=Gravity.CENTER;background=card(a,0)},LinearLayout.LayoutParams(d(210,a),d(116,a)))
                } else cards.forEachIndexed{index,item->
                    val src=item.first;val total=item.second;val solved=item.third
                    val label=if(total>0)"$solved / $total solved" else "No question data yet"
                    val box=tv(a,"📘\n${src.fileName}\n$label",13f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER;background=card(a,index);setPadding(d(8,a),d(7,a),d(8,a),d(7,a))
                        setOnClickListener{
                            PerformanceManager.submit {
                                val target=runCatching { MainRepository(a.applicationContext).use { it.resumeTarget(src) } }.getOrNull()
                                a.runOnUiThread {
                                    if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                                    if(target!=null) a.startActivity(Intent(a,QuizActivity::class.java).apply {
    putExtra("testId", target.testId)
    putExtra("title", target.title)
    putExtra("position", target.position)
    if (target.questionId > 0L) putExtra("questionId", target.questionId)
    putExtra("resumeLaunch", true)
    putExtra("practiceMode", true)
})
                                    else a.startActivity(Intent(a,TestListActivity::class.java).putExtra("sourceId",src.id).putExtra("sourceName",src.fileName))
                                }
                            }
                        }}
                    hr.addView(withMotionSurface(box,a,"continue-${src.fileName}",18f,true),LinearLayout.LayoutParams(d(170,a),d(116,a)).apply{rightMargin=d(8,a)})
                }
                hr.setTag(R.id.rovexMotionSurfaceScan, false)
                installMotionSurfaces(hr, a)
                AliveMotion.installTree(hr)
                updateMotionTree(hr, a)
            }
            }
        }
    }
    private fun refreshDynamic(a:MainActivity,value:TextView,meta:TextView,graph:TodayProgressGraphView,goalText:TextView,goalBar:ProgressBar){
        PerformanceManager.submit{
            val result=runCatching{
                val now = java.util.Calendar.getInstance()
                val todayStart = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0)
                }.timeInMillis
                val weekStart = todayStart - 6L * 86_400_000L
                val graphStart = todayStart - 27L * 86_400_000L
                val db = QBankDb(a.applicationContext)
                val stats = try { db.homeStudyStats(todayStart, weekStart, graphStart) } finally { db.close() }
                val goals=MainRepository(a.applicationContext)
                val daily=goals.dailyGoal();val weekly=goals.weeklyGoal();goals.close()
                val dayMap=stats.days.toMap()
                val days = (27 downTo 0).map { offset ->
                    val start = todayStart - offset * 86_400_000L
                    val pair = dayMap[start] ?: (0 to 0)
                    Last28StudyDaysGraphView.Day(start,pair.first,pair.second)
                }
                DynamicResult(stats.today,stats.attempted,stats.correct,stats.wrong,stats.week,daily,weekly,stats.bookmarks,stats.todayRecords,days)
            }.getOrNull() ?: return@submit
            a.runOnUiThread{
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                val today=result.today;val attempted=result.attempted;val correct=result.correct;val wrong=result.wrong;val week=result.week;val daily=result.daily;val weekly=result.weekly
                a.findViewById<View>(android.R.id.content)?.findViewWithTag<TextView>("rovex_home_bookmarks_meta")?.text = "${result.bookmarks} saved MCQs • independent of solved / wrong status"
                value.text="$today solved today"
                graph.setTodayProgress(result.todayRecords)
                val todayCorrect=result.todayRecords.count { it.second }
                val accuracy=if(today>0) todayCorrect*100/today else 0
                meta.text="$accuracy% accuracy • $todayCorrect correct • ${today-todayCorrect} wrong"
                val ring = a.findViewById<View>(android.R.id.content)?.findViewWithTag<RovexClinicalFocusRingView>("rovex_home_clinical_focus_ring")
                val dailyFraction = daily.takeIf { it > 0 }?.let { today.toFloat() / it.toFloat() }
                ring?.setProgress(today, dailyFraction)
                goalText.text=if(weekly>0)"$week / $weekly questions this week" else "$week questions attempted this week • weekly goal not set"
                goalBar.progress=if(weekly>0)(week*100/weekly).coerceIn(0,100) else 0
            }
        }
    }

    private fun startOfToday(): Long = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0) }.timeInMillis

    private fun showGoalDialog(a:MainActivity,onSaved:()->Unit){
        val box=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(20,a),d(5,a),d(20,a),0)}
        val daily=EditText(a).apply{hint="Daily questions (0 = not set)";inputType=android.text.InputType.TYPE_CLASS_NUMBER}
        val weekly=EditText(a).apply{hint="Weekly questions (0 = not set)";inputType=android.text.InputType.TYPE_CLASS_NUMBER}
        box.addView(daily,LinearLayout.LayoutParams(-1,d(56,a)));box.addView(weekly,LinearLayout.LayoutParams(-1,d(56,a)))
        val loading=TextView(a).apply{
            text="Loading saved goals…";textSize=11.5f;setTextColor(ThemeManager.muted(a));setPadding(0,d(4,a),0,d(4,a))
        }
        box.addView(loading,LinearLayout.LayoutParams(-1,-2))
        val dialog=AlertDialog.Builder(a)
            .setTitle("Study goals")
            .setMessage("Only your saved answer history is used for progress. No target is invented automatically.")
            .setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create()
        dialog.setOnShowListener {
            val save=dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            save.isEnabled=false
            PerformanceManager.submit {
                val goals=runCatching { MainRepository(a.applicationContext).use { it.dailyGoal() to it.weeklyGoal() } }.getOrNull()
                a.runOnUiThread {
                    if(a.isFinishing || a.isDestroyed || !dialog.isShowing) return@runOnUiThread
                    if(goals!=null){
                        goals.first.takeIf{it>0}?.toString()?.let{daily.setText(it)}
                        goals.second.takeIf{it>0}?.toString()?.let{weekly.setText(it)}
                        loading.text="Saved goals loaded"
                        save.isEnabled=true
                    } else {
                        loading.text="Saved goals could not be loaded; you can still enter new values."
                        save.isEnabled=true
                    }
                }
            }
            save.setOnClickListener {
                val dailyValue=daily.text.toString().toIntOrNull()?.coerceIn(0,10000) ?: 0
                val weeklyValue=weekly.text.toString().toIntOrNull()?.coerceIn(0,50000) ?: 0
                save.isEnabled=false
                PerformanceManager.submit {
                    val ok=runCatching { MainRepository(a.applicationContext).use { it.setDailyGoal(dailyValue);it.setWeeklyGoal(weeklyValue) };true }.getOrDefault(false)
                    a.runOnUiThread {
                        if(a.isFinishing || a.isDestroyed) return@runOnUiThread
                        if(ok){ dialog.dismiss(); onSaved() } else { save.isEnabled=true;loading.text="Could not save goals. Try again." }
                    }
                }
            }
        }
        dialog.show()
    }
}
