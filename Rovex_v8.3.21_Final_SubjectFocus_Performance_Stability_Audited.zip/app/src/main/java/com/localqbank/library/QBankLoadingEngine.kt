package com.localqbank.library

import android.content.Context
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import android.os.Process

/**
 * Dedicated QBank loading layer. It keeps navigation metadata off the UI thread,
 * coalesces repeated section loads, and retains a small TTL cache so reopening a
 * heavy QBank feels immediate without retaining question HTML in memory.
 */
class QBankLoadingEngine(context: Context) {
    private val app = context.applicationContext
    private val executor = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "qbank-loader").apply { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
    }
    data class SectionBundle(val tests: List<Test>, val summaries: Map<String, ProgressSummary>, val source: Source?)
    private data class TestCache(val tests: List<Test>, val at: Long)
    private data class BundleCache(val bundle: SectionBundle, val at: Long)
    private val testCache = ConcurrentHashMap<Long, TestCache>()
    private val bundleCache = ConcurrentHashMap<Long, BundleCache>()
    private val inFlight = ConcurrentHashMap<Long, java.util.concurrent.Future<*>>()
    private val ttlMs = 30_000L

    fun loadSections(sourceId: Long, onLoaded: (List<Test>) -> Unit) {
        // Keep one in-flight path per source so a warm-up and the section screen never
        // open duplicate SQLite readers for the same heavy QBank.
        loadSectionBundle(sourceId) { onLoaded(it.tests) }
    }

    fun loadSectionBundle(sourceId: Long, onLoaded: (SectionBundle) -> Unit) {
        if (sourceId <= 0L) { onLoaded(SectionBundle(emptyList(), emptyMap(), null)); return }
        val now = System.currentTimeMillis()
        bundleCache[sourceId]?.let { cached ->
            if (now - cached.at < ttlMs) {
                executor.execute { onLoaded(cached.bundle) }
                return
            }
        }
        val key = sourceId * -1L
        if (inFlight.containsKey(key)) return
        val future = executor.submit {
            try {
                val db = QBankDb(app)
                try {
                    val tests = db.tests(sourceId)
                    val progress = PerformanceManager.progress(app)
                    val summaries = db.testProgressSummaries(sourceId, progress)
                    val source = db.sources().firstOrNull { it.id == sourceId }
                    val bundle = SectionBundle(tests, summaries, source)
                    bundleCache[sourceId] = BundleCache(bundle, System.currentTimeMillis())
                    testCache[sourceId] = TestCache(tests, System.currentTimeMillis())
                    onLoaded(bundle)
                } finally { db.close() }
            } finally { inFlight.remove(key) }
        }
        inFlight[key] = future
    }

    fun warmSource(sourceId: Long) {
        if (sourceId <= 0L) return
        loadSections(sourceId) { }
    }

    fun invalidate(sourceId: Long? = null) {
        if (sourceId == null) { testCache.clear(); bundleCache.clear() }
        else { testCache.remove(sourceId); bundleCache.remove(sourceId) }
    }

    fun shutdown() { executor.shutdownNow() }
}
