package com.localqbank.library

import android.content.Context
import android.os.Build
import android.os.Debug
import com.sentencepiece.Model
import com.sentencepiece.Scoring
import com.sentencepiece.SentencePieceAlgorithm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import com.google.ai.edge.litert.TensorType
import java.io.File
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Direct EmbeddingGemma execution boundary.
 *
 * The user-selected EmbeddingGemma .tflite graph is executed directly by LiteRT.
 * No higher-level embedding wrapper is allowed to reinterpret the model tensor contract.
 *
 * SentencePiece is used only for tokenization. Retrieval policy, learner logic and study logic
 * remain outside this class. Any failure falls back to deterministic retrieval.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)
    data class Result<T>(val hits: List<SemanticHit<T>>, val elapsedMs: Long, val usedModel: Boolean)
    data class DiagnosticReport(
        val timestampMs: Long,
        val appVersion: String,
        val android: String,
        val device: String,
        val abi: String,
        val modelName: String,
        val modelBytes: Long,
        val modelSha256: String,
        val tokenizerBytes: Long,
        val tokenizerSha256: String,
        val tokenizerParseOk: Boolean,
        val tokenizerSampleTokens: Int,
        val tokenizerSpecialTokens: String,
        val modelGraphHints: String,
        val qnnAttempted: Boolean,
        val qnnAvailable: Boolean,
        val qnnFallback: Boolean,
        val qnnFailure: String?,
        val backend: String,
        val inputs: String,
        val outputs: String,
        val sequenceLength: Int,
        val embeddingDimension: Int,
        val embeddingType: String,
        val embeddingFinite: Boolean,
        val embeddingNorm: Double,
        val semanticSimilarCosine: Double,
        val semanticUnrelatedCosine: Double,
        val semanticSeparation: Double,
        val runtimeInitMs: Long,
        val inferenceMs: Long,
        val totalMs: Long,
        val availableRamBeforeMb: Int,
        val availableRamAfterMb: Int,
        val javaHeapBeforeMb: Long,
        val javaHeapAfterMb: Long,
        val nativeHeapBeforeMb: Long,
        val nativeHeapAfterMb: Long,
        val thermalBefore: Int,
        val thermalAfter: Int,
        val powerSaveBefore: Boolean,
        val powerSaveAfter: Boolean,
        val contractPassed: Boolean,
        val inferencePassed: Boolean,
        val semanticSmokePassed: Boolean,
        val overallPassed: Boolean,
        val failure: String?
    ) {
        fun toText(): String = buildString {
            appendLine("BEN / EMBEDDINGGEMMA DIAGNOSTIC REPORT")
            appendLine("Generated: ${java.util.Date(timestampMs)}")
            appendLine("Overall: ${if (overallPassed) "PASS" else "FAIL / REVIEW"}")
            appendLine()
            appendLine("1. DEVICE / RUNTIME")
            appendLine("App: $appVersion")
            appendLine("Android: $android")
            appendLine("Device: $device")
            appendLine("ABI: $abi")
            appendLine("RAM available: ${availableRamBeforeMb} MB -> ${availableRamAfterMb} MB")
            appendLine("Java heap: ${javaHeapBeforeMb} MB -> ${javaHeapAfterMb} MB")
            appendLine("Native heap: ${nativeHeapBeforeMb} MB -> ${nativeHeapAfterMb} MB")
            appendLine("Thermal: $thermalBefore -> $thermalAfter")
            appendLine("Power save: $powerSaveBefore -> $powerSaveAfter")
            appendLine()
            appendLine("2. ARTIFACTS")
            appendLine("Model: $modelName (${modelBytes / (1024 * 1024)} MB)")
            appendLine("Model SHA-256: $modelSha256")
            appendLine("SentencePiece: ${tokenizerBytes / (1024 * 1024)} MB")
            appendLine("Tokenizer SHA-256: $tokenizerSha256")
            appendLine("Tokenizer parse: ${if (tokenizerParseOk) "PASS" else "FAIL"}")
            appendLine("Tokenizer sample tokens: $tokenizerSampleTokens")
            appendLine("Special tokens: $tokenizerSpecialTokens")
            appendLine("Graph hints: $modelGraphHints")
            appendLine()
            appendLine("3. MODEL GRAPH / TENSOR CONTRACT")
            appendLine("Inputs: $inputs")
            appendLine("Outputs: $outputs")
            appendLine("Sequence length: $sequenceLength")
            appendLine("Embedding dimension: $embeddingDimension")
            appendLine("Embedding type: $embeddingType")
            appendLine("Contract: ${if (contractPassed) "PASS" else "FAIL"}")
            appendLine()
            appendLine("4. BACKEND")
            appendLine("Backend selected: $backend")
            appendLine("QNN attempted: $qnnAttempted")
            appendLine("QNN available: $qnnAvailable")
            appendLine("QNN fallback to CPU/XNNPACK: $qnnFallback")
            appendLine("QNN failure: ${qnnFailure ?: "none"}")
            appendLine()
            appendLine("5. INFERENCE")
            appendLine("Inference: ${if (inferencePassed) "PASS" else "FAIL"}")
            appendLine("Finite embedding: $embeddingFinite")
            appendLine("Embedding L2 norm: ${"%.5f".format(embeddingNorm)}")
            appendLine("Runtime initialization: ${runtimeInitMs} ms")
            appendLine("Inference time: ${inferenceMs} ms")
            appendLine("Total diagnostic time: ${totalMs} ms")
            appendLine()
            appendLine("6. SEMANTIC SMOKE TEST")
            appendLine("Related pair cosine: ${"%.5f".format(semanticSimilarCosine)}")
            appendLine("Unrelated pair cosine: ${"%.5f".format(semanticUnrelatedCosine)}")
            appendLine("Separation: ${"%.5f".format(semanticSeparation)}")
            appendLine("Semantic smoke test: ${if (semanticSmokePassed) "PASS" else "REVIEW"}")
            appendLine()
            appendLine("7. FAILURE / FALLBACK")
            appendLine("Failure: ${failure ?: "none"}")
            appendLine("Deterministic Ben/RAG remains authoritative if neural inference is unavailable.")
        }
    }

    suspend fun <T> rerank(
        query: String,
        candidates: List<T>,
        textOf: (T) -> String,
        limit: Int = 8
    ): Result<T> = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile)
        val tokenizer = models.installedEmbeddingGemmaTokenizer()
        if (installed == null) {
            fail("EmbeddingGemma model is not installed")
            return@withContext fallback(candidates, limit, started)
        }
        if (tokenizer == null) {
            fail("EmbeddingGemma sentencepiece.model is not installed")
            return@withContext fallback(candidates, limit, started)
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, governor.snapshot(true))
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext fallback(candidates, limit, started)
        }
        val cleanQuery = clean(query)
        if (cleanQuery.length < 2 || candidates.isEmpty()) {
            return@withContext fallback(candidates, limit, started)
        }
        try {
            val runtime = Runtime(installed.file, tokenizer)
            runtime.use {
                BenNeuralTelemetry.stage(
                    BenNeuralTelemetry.Stage.SEMANTIC_RERANK,
                    "Semantic reranking via ${it.backend()}",
                    "EmbeddingGemma 300M",
                    it.backend()
                )
                val queryVector = it.embed(cleanQuery, Task.RETRIEVAL_QUERY)
                val selected = candidates.take(8)
                val scored = selected.map { candidate ->
                    val text = clean(textOf(candidate))
                    SemanticHit(candidate, cosine(queryVector, it.embed(text, Task.RETRIEVAL_DOCUMENT)))
                }.sortedByDescending { it.similarity }.take(limit.coerceIn(1, 8))
                policy.recordBackendSuccess()
                Result(scored, max(0L, System.currentTimeMillis() - started), true)
            }
        } catch (error: LinkageError) {
            fail("EmbeddingGemma native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            fallback(candidates, limit, started)
        } catch (error: Exception) {
            fail(runtimeMessage(error))
            policy.recordBackendFailure()
            fallback(candidates, limit, started)
        }
    }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile) ?: run {
            fail("EmbeddingGemma model is not installed")
            return@withContext null
        }
        val tokenizer = models.installedEmbeddingGemmaTokenizer() ?: run {
            fail("EmbeddingGemma sentencepiece.model is not installed")
            return@withContext null
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, governor.snapshot(true))
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext null
        }
        try {
            val runtime = Runtime(installed.file, tokenizer)
            runtime.use {
                BenNeuralTelemetry.stage(
                    BenNeuralTelemetry.Stage.SEMANTIC_RERANK,
                    "EmbeddingGemma inference via ${it.backend()}",
                    "EmbeddingGemma 300M",
                    it.backend()
                )
                val a = it.embed(clean(first), Task.SENTENCE_SIMILARITY)
                val b = it.embed(clean(second), Task.SENTENCE_SIMILARITY)
                if (a.size != b.size) throw IllegalStateException("Embedding dimension mismatch: ${a.size} vs ${b.size}")
                if (a.size < 128) throw IllegalStateException("Unexpected embedding dimension: ${a.size}")
                val score = cosine(a, b)
                policy.recordBackendSuccess()
                BenNeuralTelemetry.semantic(max(0L, System.currentTimeMillis() - started), true)
                score
            }
        } catch (error: LinkageError) {
            fail("EmbeddingGemma native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            null
        } catch (error: Exception) {
            fail(runtimeMessage(error))
            policy.recordBackendFailure()
            null
        }
    }

    /**
     * Non-destructive diagnostic for Adaptive Engine. It validates the installed artifact,
     * tokenizer, tensor contract, backend selection and a small semantic-similarity pair.
     * It never writes study data.
     */
    suspend fun diagnostic(): String? = diagnosticReport()?.toText()

    suspend fun diagnosticReport(): DiagnosticReport = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val before = governor.snapshot(true)
        val runtimeBefore = runtimeMemory()
        val installed = models.installed(profile)
        val tokenizerFile = models.installedEmbeddingGemmaTokenizer()
        val modelBytes = installed?.bytes ?: 0L
        val tokenizerBytes = tokenizerFile?.length() ?: 0L
        val modelHash = installed?.file?.let { runCatching { sha256(it) }.getOrNull() } ?: "not available"
        val tokenizerHash = tokenizerFile?.let { runCatching { sha256(it) }.getOrNull() } ?: "not available"
        val modelGraphHints = installed?.file?.let { runCatching { graphHints(it) }.getOrDefault("inspection failed") } ?: "not inspected"
        fun publish(report: DiagnosticReport): DiagnosticReport {
            BenNeuralTelemetry.setDiagnosticReport(report.toText())
            return report
        }
        if (installed == null || tokenizerFile == null) {
            val failure = if (installed == null && tokenizerFile == null) "Model and SentencePiece tokenizer are not installed" else if (installed == null) "EmbeddingGemma model is not installed" else "EmbeddingGemma sentencepiece.model is not installed"
            fail(failure)
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, modelGraphHints, tokenizerFile, failure))
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, before)
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, modelGraphHints, tokenizerFile, "Governor blocked: $blockReason"))
        }
        try {
            val runtimeStarted = System.currentTimeMillis()
            Runtime(installed.file, tokenizerFile).use { runtime ->
                val runtimeInitMs = System.currentTimeMillis() - runtimeStarted
                val relatedA = "nephrotic syndrome causes edema due to urinary protein loss and reduced plasma oncotic pressure"
                val relatedB = "protein loss in urine lowers plasma oncotic pressure and produces edema"
                val unrelated = "renal calculi commonly cause severe colicky flank pain with hematuria"
                val inferenceStarted = System.currentTimeMillis()
                val a = runtime.embed(relatedA, Task.SENTENCE_SIMILARITY)
                val b = runtime.embed(relatedB, Task.SENTENCE_SIMILARITY)
                val c = runtime.embed(unrelated, Task.SENTENCE_SIMILARITY)
                val inferenceMs = System.currentTimeMillis() - inferenceStarted
                val similar = cosine(a, b)
                val unrelatedScore = cosine(a, c)
                val separation = similar - unrelatedScore
                val finite = a.all { it.isFinite() } && b.all { it.isFinite() } && c.all { it.isFinite() }
                val norm = sqrt(a.sumOf { it.toDouble() * it.toDouble() })
                val after = governor.snapshot(true)
                val runtimeAfter = runtimeMemory()
                val contractPassed = runtime.contractPassed()
                val inferencePassed = finite && a.size == 768 && b.size == 768 && c.size == 768
                val semanticPassed = finite && separation > 0.0
                val overall = contractPassed && inferencePassed && semanticPassed
                val report = DiagnosticReport(
                    timestampMs = System.currentTimeMillis(), appVersion = appVersion(),
                    android = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                    device = deviceDescription(),
                    abi = Build.SUPPORTED_ABIS.joinToString(", "), modelName = profile.name, modelBytes = modelBytes, modelSha256 = modelHash,
                    tokenizerBytes = tokenizerBytes, tokenizerSha256 = tokenizerHash, tokenizerParseOk = runtime.tokenizerParsed(),
                    tokenizerSampleTokens = runtime.lastTokenCount(), tokenizerSpecialTokens = "BOS=2, EOS=1, PAD=0; padded=${runtime.sequenceLengthValue()}",
                    modelGraphHints = modelGraphHints,
                    qnnAttempted = runtime.qnnAttempted(), qnnAvailable = runtime.qnnAvailable(), qnnFallback = runtime.qnnFallback(), qnnFailure = runtime.qnnFailure(),
                    backend = runtime.backend(), inputs = runtime.inputsDescription(), outputs = runtime.outputsDescription(), sequenceLength = runtime.sequenceLengthValue(),
                    embeddingDimension = a.size, embeddingType = "FLOAT32", embeddingFinite = finite, embeddingNorm = norm,
                    semanticSimilarCosine = similar, semanticUnrelatedCosine = unrelatedScore, semanticSeparation = separation,
                    runtimeInitMs = runtimeInitMs, inferenceMs = inferenceMs, totalMs = System.currentTimeMillis() - started,
                    availableRamBeforeMb = before.availableMemoryMb, availableRamAfterMb = after.availableMemoryMb,
                    javaHeapBeforeMb = runtimeBefore.javaHeapMb, javaHeapAfterMb = runtimeAfter.javaHeapMb,
                    nativeHeapBeforeMb = runtimeBefore.nativeHeapMb, nativeHeapAfterMb = runtimeAfter.nativeHeapMb,
                    thermalBefore = before.thermalStatus, thermalAfter = after.thermalStatus, powerSaveBefore = before.powerSave, powerSaveAfter = after.powerSave,
                    contractPassed = contractPassed, inferencePassed = inferencePassed, semanticSmokePassed = semanticPassed, overallPassed = overall,
                    failure = if (overall) null else "One or more diagnostic gates failed or require review"
                )
                if (overall) { policy.recordBackendSuccess(); BenNeuralTelemetry.semantic(inferenceMs, true) } else { policy.recordBackendFailure(); BenNeuralTelemetry.error(report.failure ?: "Diagnostic review required") }
                return@withContext publish(report)
            }
        } catch (error: LinkageError) {
            val message = "EmbeddingGemma diagnostic native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(320) ?: "no message"}"
            fail(message); policy.recordBackendFailure()
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, modelGraphHints, tokenizerFile, message))
        } catch (error: Exception) {
            val message = runtimeMessage(error)
            fail(message); policy.recordBackendFailure()
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, modelGraphHints, tokenizerFile, message))
        }
    }

    private fun failureReport(started: Long, before: BenAiResourceGovernor.Snapshot, memory: RuntimeMemory, modelBytes: Long, tokenizerBytes: Long, modelHash: String, tokenizerHash: String, modelGraphHints: String, tokenizerFile: File?, failure: String): DiagnosticReport {
        return DiagnosticReport(
            timestampMs = System.currentTimeMillis(), appVersion = appVersion(),
            android = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            device = deviceDescription(),
            abi = Build.SUPPORTED_ABIS.joinToString(", "), modelName = profile.name, modelBytes = modelBytes, modelSha256 = modelHash,
            tokenizerBytes = tokenizerBytes, tokenizerSha256 = tokenizerHash, tokenizerParseOk = tokenizerFile?.let { runCatching { Model.parseFrom(it.toPath()) }.isSuccess } == true, tokenizerSampleTokens = tokenizerFile?.let { runCatching { Model.parseFrom(it.toPath()).encodeNormalized("diagnostic", SentencePieceAlgorithm(true, Scoring.HIGHEST_SCORE)).size }.getOrDefault(0) } ?: 0, tokenizerSpecialTokens = "BOS=2, EOS=1, PAD=0", modelGraphHints = modelGraphHints,
            qnnAttempted = false, qnnAvailable = false, qnnFallback = false, qnnFailure = null, backend = "not started", inputs = "not inspected", outputs = "not inspected",
            sequenceLength = 0, embeddingDimension = 0, embeddingType = "unknown", embeddingFinite = false, embeddingNorm = 0.0, semanticSimilarCosine = 0.0, semanticUnrelatedCosine = 0.0, semanticSeparation = 0.0,
            runtimeInitMs = 0L, inferenceMs = 0L, totalMs = System.currentTimeMillis() - started, availableRamBeforeMb = before.availableMemoryMb, availableRamAfterMb = before.availableMemoryMb,
            javaHeapBeforeMb = memory.javaHeapMb, javaHeapAfterMb = memory.javaHeapMb, nativeHeapBeforeMb = memory.nativeHeapMb, nativeHeapAfterMb = memory.nativeHeapMb,
            thermalBefore = before.thermalStatus, thermalAfter = before.thermalStatus, powerSaveBefore = before.powerSave, powerSaveAfter = before.powerSave,
            contractPassed = false, inferencePassed = false, semanticSmokePassed = false, overallPassed = false, failure = failure
        )
    }

    private fun graphHints(file: File): String {
        val needles = listOf("DISPATCH_OP", "LiteRtDispatch", "Qualcomm", "SM8650", "SM8550", "SM8750", "SM8850")
        val found = linkedSetOf<String>()
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            var carry = ByteArray(0)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                val chunk = ByteArray(carry.size + read)
                carry.copyInto(chunk)
                System.arraycopy(buffer, 0, chunk, carry.size, read)
                val text = String(chunk, Charsets.ISO_8859_1)
                for (needle in needles) if (text.contains(needle)) found += needle
                if (found.size == needles.size) break
                carry = chunk.takeLast(64).toByteArray()
            }
        }
        return if (found.isEmpty()) "No known dispatch/Qualcomm markers found in flatbuffer byte scan" else found.joinToString(", ")
    }

    private fun appVersion(): String {
        return try {
            @Suppress("DEPRECATION")
            app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "unknown"
        } catch (_: Exception) {
            "unknown"
        }
    }

    private fun deviceDescription(): String {
        val soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
        return "${Build.MANUFACTURER} ${Build.MODEL} / $soc"
    }

    private data class RuntimeMemory(val javaHeapMb: Long, val nativeHeapMb: Long)
    private fun runtimeMemory(): RuntimeMemory {
        val r = java.lang.Runtime.getRuntime()
        val javaMb = ((r.totalMemory() - r.freeMemory()).coerceAtLeast(0L) / (1024L * 1024L))
        val nativeMb = Debug.getNativeHeapAllocatedSize() / (1024L * 1024L)
        return RuntimeMemory(javaMb, nativeMb)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Direct model contract + inference implementation.
     *
     * EmbeddingGemma is now executed through LiteRT's modern CompiledModel API.
     * The legacy Interpreter + QNN-delegate path is deliberately removed here: the
     * installed EmbeddingGemma artifact can contain LiteRT dispatch/AOT constructs that
     * the legacy interpreter cannot resolve (DISPATCH_OP). CompiledModel is the supported
     * accelerator-first Android API for current LiteRT models.
     *
     * CPU is the first and safest contract path. Qualcomm/NPU acceleration is kept out of
     * this baseline until the exact device/model dispatch runtime is independently proven;
     * a missing accelerator must never prevent deterministic Ben/RAG fallback.
     */
    private inner class Runtime(model: File, tokenizerFile: File) : AutoCloseable {
        private val compiledModel: CompiledModel
        private lateinit var tokenizer: Model
        private val tokenizerAlgorithm = SentencePieceAlgorithm(true, Scoring.HIGHEST_SCORE)
        private var backendName: String = "LiteRT CompiledModel CPU"
        private var qnnAttemptedValue = false
        private var qnnAvailableValue = false
        private var qnnFallbackValue = false
        private var qnnFailureValue: String? = null
        private var tokenizerParsedValue = false
        private var lastTokenCountValue = 0
        private var inputsDescriptionValue = ""
        private var outputsDescriptionValue = ""
        private var inputIdsType: TensorType.ElementType = TensorType.ElementType.INT
        private var attentionMaskType: TensorType.ElementType = TensorType.ElementType.INT
        private var sequenceLengthValue = 0
        private var outputDimensionValue = 0
        private var contractDescription = ""
        private var inputBuffers: List<com.google.ai.edge.litert.TensorBuffer> = emptyList()
        private var outputBuffers: List<com.google.ai.edge.litert.TensorBuffer> = emptyList()

        init {
            // Do not use DJL SentencePiece JNI on Android. SentencePiece4J is pure Java,
            // so tokenizer execution is offline, deterministic, and does not require JNI.
            tokenizer = Model.parseFrom(tokenizerFile.toPath())
            tokenizerParsedValue = true

            qnnAttemptedValue = false
            qnnAvailableValue = false
            qnnFallbackValue = false

            // The generic EmbeddingGemma LiteRT artifact is first validated on the
            // universally available CPU backend. This avoids asking a legacy delegate to
            // interpret a dispatch graph and gives us a deterministic baseline before any
            // future Qualcomm AOT/NPU path is enabled.
            val compileStarted = System.currentTimeMillis()
            compiledModel = CompiledModel.create(
                model.absolutePath,
                CompiledModel.Options(Accelerator.CPU),
                null
            )
            backendName = "LiteRT CompiledModel CPU/XNNPACK"

            inputBuffers = compiledModel.createInputBuffers()
            outputBuffers = compiledModel.createOutputBuffers()
            if (inputBuffers.size != 2) {
                throw IllegalStateException("EmbeddingGemma expects 2 input buffers (input_ids + attention_mask), got ${inputBuffers.size}")
            }
            if (outputBuffers.isEmpty()) {
                throw IllegalStateException("EmbeddingGemma returned no output buffers")
            }

            inputIdsType = resolveTensorType(
                compiledModel,
                listOf("input_ids", "input_ids:0", "ids", "tokens"),
                TensorType.ElementType.INT
            )
            attentionMaskType = resolveTensorType(
                compiledModel,
                listOf("attention_mask", "attention_mask:0", "mask", "input_mask"),
                TensorType.ElementType.INT
            )
            validateInputTypes()
            sequenceLengthValue = inferSequenceLength(compiledModel, "input_ids", inputIdsType)
            if (sequenceLengthValue <= 0) sequenceLengthValue = inferSequenceLengthFromBytes(inputIdsType)
            if (sequenceLengthValue <= 0) {
                throw IllegalStateException("Unable to determine EmbeddingGemma input sequence length")
            }

            inputsDescriptionValue = describeInput("input_ids", inputIdsType, sequenceLengthValue) +
                " | " + describeInput("attention_mask", attentionMaskType, sequenceLengthValue)
            outputsDescriptionValue = "out#0:bufferCount=${outputBuffers.size}"
            contractDescription = "backend=$backendName; init=${System.currentTimeMillis() - compileStarted}ms; inputs=$inputsDescriptionValue; outputs=$outputsDescriptionValue"
        }

        fun embed(text: String, task: Task): List<Float> {
            val ids = tokenize(task.prefix + text)
            val padded = IntArray(sequenceLengthValue)
            val count = minOf(ids.size, sequenceLengthValue)
            for (i in 0 until count) padded[i] = ids[i]
            val mask = IntArray(sequenceLengthValue) { if (it < count) 1 else 0 }

            writeTokenData(inputBuffers[0], padded, inputIdsType)
            writeTokenData(inputBuffers[1], mask, attentionMaskType)
            compiledModel.run(inputBuffers, outputBuffers)
            if (outputBuffers.isEmpty()) throw IllegalStateException("EmbeddingGemma produced no output buffers")
            val output = outputBuffers[0].readFloat()
            outputDimensionValue = output.size
            if (output.size != 768) {
                throw IllegalStateException("EmbeddingGemma produced ${output.size} float values; expected 768")
            }
            return output.toList()
        }

        private fun tokenize(text: String): IntArray {
            val ids = tokenizer.encodeNormalized(text, tokenizerAlgorithm).map { it }.toIntArray()
            // EmbeddingGemma/Gemma tokenizer uses BOS=2, EOS=1, PAD=0.
            val withSpecial = IntArray(ids.size + 2)
            withSpecial[0] = 2
            ids.copyInto(withSpecial, destinationOffset = 1)
            withSpecial[withSpecial.lastIndex] = 1
            lastTokenCountValue = withSpecial.size
            return withSpecial
        }

        private fun validateInputTypes() {
            val valid = setOf(TensorType.ElementType.INT, TensorType.ElementType.INT64)
            if (inputIdsType !in valid || attentionMaskType !in valid) {
                throw IllegalStateException(
                    "EmbeddingGemma token inputs must be INT/INT64; got input_ids=$inputIdsType attention_mask=$attentionMaskType"
                )
            }
        }

        private fun resolveTensorType(
            model: CompiledModel,
            candidates: List<String>,
            fallback: TensorType.ElementType
        ): TensorType.ElementType {
            for (name in candidates) {
                val type = runCatching { model.getInputTensorType(name).elementType }.getOrNull()
                if (type != null) return type
            }
            return fallback
        }

        private fun inferSequenceLength(model: CompiledModel, name: String, type: TensorType.ElementType): Int {
            val bytes = runCatching { model.getInputBufferRequirements(name).bufferSize }.getOrNull() ?: return 0
            val bytesPerElement = if (type == TensorType.ElementType.INT64) Long.SIZE_BYTES else Int.SIZE_BYTES
            if (bytes <= 0 || bytes % bytesPerElement != 0) return 0
            return bytes / bytesPerElement
        }

        private fun inferSequenceLengthFromBytes(type: TensorType.ElementType): Int {
            val bytes = runCatching { modelInputBufferSize(inputBuffers[0]) }.getOrNull() ?: return 0
            val bytesPerElement = if (type == TensorType.ElementType.INT64) Long.SIZE_BYTES else Int.SIZE_BYTES
            if (bytes <= 0 || bytes % bytesPerElement != 0) return 0
            return bytes / bytesPerElement
        }

        private fun modelInputBufferSize(buffer: com.google.ai.edge.litert.TensorBuffer): Int {
            // The CompiledModel API intentionally exposes typed read/write operations rather
            // than a public element-count property. A zero-filled typed read gives us a safe
            // size without relying on internal/JNI APIs.
            return when (inputIdsType) {
                TensorType.ElementType.INT64 -> buffer.readLong().size * Long.SIZE_BYTES
                else -> buffer.readInt().size * Int.SIZE_BYTES
            }
        }

        private fun describeInput(name: String, type: TensorType.ElementType, sequence: Int): String {
            val bytes = runCatching { compiledModel.getInputBufferRequirements(name).bufferSize }.getOrNull()
            val strides = runCatching { compiledModel.getInputBufferRequirements(name).strides }.getOrNull()
            return "$name:$type:[1,$sequence]" +
                (bytes?.let { ":bytes=$it" } ?: "") +
                (strides?.let { ":strides=$it" } ?: "")
        }

        private fun writeTokenData(
            buffer: com.google.ai.edge.litert.TensorBuffer,
            values: IntArray,
            type: TensorType.ElementType
        ) {
            when (type) {
                TensorType.ElementType.INT64 -> buffer.writeLong(values.map { it.toLong() }.toLongArray())
                TensorType.ElementType.INT -> buffer.writeInt(values)
                else -> throw IllegalStateException("Unsupported token input type: $type")
            }
        }

        fun backend(): String = backendName
        fun contract(): String = contractDescription
        fun contractPassed(): Boolean = sequenceLengthValue == 512 && outputDimensionValue == 768
        fun tokenizerParsed(): Boolean = tokenizerParsedValue
        fun lastTokenCount(): Int = lastTokenCountValue
        fun sequenceLengthValue(): Int = sequenceLengthValue
        fun qnnAttempted(): Boolean = qnnAttemptedValue
        fun qnnAvailable(): Boolean = qnnAvailableValue
        fun qnnFallback(): Boolean = qnnFallbackValue
        fun qnnFailure(): String? = qnnFailureValue
        fun inputsDescription(): String = inputsDescriptionValue
        fun outputsDescription(): String = if (outputDimensionValue > 0) "$outputsDescriptionValue | out#0:FLOAT:${outputDimensionValue} elements" else outputsDescriptionValue

        override fun close() {
            inputBuffers.forEach { runCatching { it.close() } }
            outputBuffers.forEach { runCatching { it.close() } }
            runCatching { compiledModel.close() }
        }
    }

    private enum class Task(val prefix: String) {
        RETRIEVAL_QUERY("task: search result | query: "),
        RETRIEVAL_DOCUMENT("title: none | text: "),
        SENTENCE_SIMILARITY("task: sentence similarity | query: ")
    }

    private fun runtimeMessage(error: Exception): String =
        "EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(320) ?: "no message"}"

    private fun fail(message: String) {
        BenNeuralTelemetry.error(message)
    }

    private fun cosine(a: List<Float>, b: List<Float>): Double {
        val n = minOf(a.size, b.size)
        if (n == 0) return 0.0
        var dot = 0.0
        var aa = 0.0
        var bb = 0.0
        for (i in 0 until n) {
            val x = a[i].toDouble()
            val y = b[i].toDouble()
            dot += x * y
            aa += x * x
            bb += y * y
        }
        return if (aa <= 0.0 || bb <= 0.0) 0.0 else
            (dot / (sqrt(aa) * sqrt(bb))).coerceIn(-1.0, 1.0)
    }

    private fun clean(value: String) = value.replace(Regex("\\s+"), " ").trim().take(1800)

    private fun <T> fallback(candidates: List<T>, limit: Int, started: Long) =
        Result(candidates.take(limit.coerceAtLeast(0)).map { SemanticHit(it, 0.0) }, max(0L, System.currentTimeMillis() - started), false)
}
