package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Knowledge Vault notes surface. Notes are grouped by subject, searchable, and split into
 * machine-derived key points vs the user's own note so long imported explanations stay readable.
 */
class NotesActivity : Activity() {
    private lateinit var db: QBankDb
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var filter = "all"
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        db=QBankDb(this)
        setContentView(build())
        render()
    }

    private fun build():ScrollView {
        val scroll=ScrollView(this).apply{setBackgroundColor(ThemeManager.bg(this@NotesActivity));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(28))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val back=TextView(this).apply{text="←";textSize=25f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@NotesActivity));background=rounded(ThemeManager.elevated(this@NotesActivity),16f);setOnClickListener{finish()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(52),dp(48)))
        val title=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        title.addView(TextView(this@NotesActivity).apply{text="My Notes";textSize=24f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@NotesActivity))})
        title.addView(TextView(this@NotesActivity).apply{text="Organized knowledge, not a wall of text";textSize=11.5f;setTextColor(ThemeManager.muted(this@NotesActivity));setPadding(0,dp(2),0,0)})
        bar.addView(title,LinearLayout.LayoutParams(0,-2,1f));root.addView(bar)

        search=EditText(this).apply{
            hint="Search notes, subjects, questions…";textSize=14f;singleLine=true;setTextColor(ThemeManager.text(this@NotesActivity));setHintTextColor(ThemeManager.muted(this@NotesActivity));setPadding(dp(14),0,dp(14),0);background=rounded(ThemeManager.elevated(this@NotesActivity),16f)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()};override fun afterTextChanged(s:Editable?) {}})
        }
        root.addView(search,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(14),0,dp(9))})

        val filters=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f}
        listOf("all" to "All notes","recent" to "Recent","key" to "Key points").forEach{(key,label)->
            val chip=TextView(this).apply{text=label;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(dp(8),0,dp(8),0);setOnClickListener{filter=key;render()}}
            filters.addView(chip,LinearLayout.LayoutParams(0,dp(38),1f).apply{setMargins(dp(3),0,dp(3),0)})
        }
        root.addView(filters)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(list,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,0)})
        scroll.addView(root);return scroll
    }

    private fun render(){
        if(!::list.isInitialized) return
        list.removeAllViews()
        val query=search.text?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
        val now=System.currentTimeMillis()
        val week=now-7L*86_400_000L
        val records=runCatching{db.noteRecords()}.getOrDefault(emptyList()).filter{r->
            val match=query.isBlank() || r.note.lowercase().contains(query) || r.subject.lowercase().contains(query) || r.testTitle.lowercase().contains(query)
            val time=filter!="recent" || r.updatedAt>=week
            val key=filter!="key" || r.note.contains("[LocalQBank Auto Summary]",true)
            match && time && key
        }
        if(records.isEmpty()){
            list.addView(TextView(this).apply{text=if(query.isBlank())"No notes saved yet." else "No notes match your search.";textSize=15f;setTextColor(ThemeManager.muted(this@NotesActivity));gravity=Gravity.CENTER;setPadding(dp(12),dp(36),dp(12),dp(36))});return
        }
        val groups=records.groupBy{it.subject.ifBlank{"General"}}
        groups.toSortedMap(compareBy<String>{it}).forEach{(subject,items)->
            val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(4),dp(12),dp(4),dp(7))}
            header.addView(TextView(this@NotesActivity).apply{text=subject.uppercase(Locale.getDefault());textSize=11f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.muted(this@NotesActivity));letterSpacing=.08f},LinearLayout.LayoutParams(0,-2,1f))
            header.addView(TextView(this@NotesActivity).apply{text="${items.size} note${if(items.size==1)"" else "s"}";textSize=10.5f;setTextColor(ThemeManager.muted(this@NotesActivity))})
            list.addView(header)
            items.forEach{addNoteCard(it)}
        }
    }

    private fun addNoteCard(r:QBankDb.NoteRecord){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(12));background=rounded(if(ThemeManager.isDark(this@NotesActivity))ThemeManager.elevated(this@NotesActivity) else Color.WHITE,18f)}
        val meta=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        meta.addView(TextView(this@NotesActivity).apply{text="Q${r.position}";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@NotesActivity));background=rounded(ThemeManager.optionBg(this@NotesActivity),10f);setPadding(dp(9),dp(5),dp(9),dp(5))})
        meta.addView(TextView(this@NotesActivity).apply{text=r.testTitle;textSize=12f;setTextColor(ThemeManager.muted(this@NotesActivity));maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END;setPadding(dp(9),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        meta.addView(TextView(this@NotesActivity).apply{text=SimpleDateFormat("dd MMM",Locale.getDefault()).format(Date(r.updatedAt));textSize=10.5f;setTextColor(ThemeManager.muted(this@NotesActivity))})
        card.addView(meta)

        val parsed=parseNote(r.note)
        if(parsed.keyPoints.isNotEmpty()){
            val keyBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(11),dp(9),dp(11),dp(9));background=rounded(ThemeManager.peacockFill(this@NotesActivity),13f);setMargins(card,0,dp(10),0,0)}
            keyBox.addView(TextView(this@NotesActivity).apply{text="KEY POINTS";textSize=10f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.peacockText(this@NotesActivity));letterSpacing=.06f})
            parsed.keyPoints.take(6).forEach{point->keyBox.addView(TextView(this@NotesActivity).apply{text="• $point";textSize=13.5f;setTextColor(ThemeManager.text(this@NotesActivity));setLineSpacing(0f,1.15f);setPadding(0,dp(4),0,0)})}
            card.addView(keyBox)
        }
        if(parsed.personal.isNotBlank()){
            card.addView(TextView(this).apply{text="MY NOTE";textSize=10f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.muted(this@NotesActivity));letterSpacing=.06f;setPadding(0,dp(11),0,dp(3))})
            card.addView(TextView(this).apply{text=parsed.personal;textSize=15f;setTextColor(ThemeManager.text(this@NotesActivity));setLineSpacing(0f,1.18f)})
        }
        val actions=LinearLayout(this).apply{gravity=Gravity.END;setPadding(0,dp(10),0,0)}
        val view=TextView(this).apply{text="VIEW QUESTION";textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=rounded(ThemeManager.accent(this@NotesActivity),12f);setPadding(dp(13),0,dp(13),0);setOnClickListener{val q=runCatching{db.questionById(r.questionId)}.getOrNull();if(q!=null)startActivity(Intent(this@NotesActivity,QuizActivity::class.java).putExtra("questionId",r.questionId).putExtra("title","My Notes"))else Toast.makeText(this@NotesActivity,"Question no longer exists",Toast.LENGTH_SHORT).show()}}
        actions.addView(view,LinearLayout.LayoutParams(0,dp(40),1f))
        val del=TextView(this).apply{text="DELETE";textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.wrongText(this@NotesActivity));background=rounded(ThemeManager.wrongBg(this@NotesActivity),12f);setPadding(dp(13),0,dp(13),0);setOnClickListener{AlertDialog.Builder(this@NotesActivity).setTitle("Delete note?").setMessage("Only the saved note is removed. The original question remains safe.").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->db.deleteNote(r.questionId);render()}.show()}}
        actions.addView(del,LinearLayout.LayoutParams(dp(84),dp(40)).apply{setMargins(dp(8),0,0,0)})
        card.addView(actions)
        list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(9))})
    }

    private data class ParsedNote(val keyPoints:List<String>,val personal:String)
    private fun parseNote(raw:String):ParsedNote{
        val marker="[LocalQBank Auto Summary]"
        val split=raw.split(marker,limit=2)
        if(split.size<2) return ParsedNote(emptyList(),raw.trim())
        val personal=split[0].trim().removeSuffix("—").trim()
        val auto=split[1].trim()
        val points=auto.lines().map{it.trim()}.filter{it.isNotBlank() && !it.equals("Summary",true)}
            .map{it.removePrefix("-").removePrefix("•").trim()}.filter{it.length>2}
        return ParsedNote(points,personal)
    }

    private fun rounded(fill:Int,r:Float)=GradientDrawable().apply{setColor(fill);cornerRadius=dp(r.toInt()).toFloat()}
    private fun setMargins(v:View,l:Int,t:Int,r:Int,b:Int){v.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(l,t,r,b)}}
    override fun onResume(){super.onResume();if(::list.isInitialized)render()}
    override fun onDestroy(){if(::db.isInitialized)db.close();super.onDestroy()}
}
