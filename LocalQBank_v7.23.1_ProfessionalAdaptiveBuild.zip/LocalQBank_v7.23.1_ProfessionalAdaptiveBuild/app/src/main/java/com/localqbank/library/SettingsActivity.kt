package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class SettingsActivity: Activity(){
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private val section by lazy { intent.getStringExtra("section") ?: "all" }

    override fun onCreate(b:Bundle?){
        super.onCreate(b); AppManagers.initialize(applicationContext); SystemUi.immersive(this); setContentView(build())
    }

    private fun build():ScrollView{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(28));setBackgroundColor(ThemeManager.bg(this@SettingsActivity))}
        root.addView(TextView(this).apply{text=when(section){"adaptive"->"Adaptive Engine";"appearance"->"Appearance & Themes";"fonts"->"Quiz Typography";else->"Q Settings"};textSize=27f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity));setPadding(0,0,0,dp(6))})
        root.addView(TextView(this).apply{text="${if(section=="all")"Appearance, backup, typography and adaptive intelligence" else "Dedicated ${section.replaceFirstChar{it.uppercase()}} controls"}";textSize=13f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,0,0,dp(18))})

        if(section=="all" || section=="appearance") addAppearance(root)
        if(section=="all") {
            section(root,"BACKUP & RESTORE")
            root.addView(button("Open Backup & Restore"){startActivity(Intent(this,BackupActivity::class.java))},lp())
            section(root,"PRIVACY & DATA")
            val privacy=TextView(this).apply{
                text="Your QBank, answers, notes and adaptive state are stored locally. LocalQBank does not include an analytics or advertising SDK and does not send study data to a remote service. Optional backup is written only to the folder you explicitly choose. Imported external images are fetched only over HTTPS."
                textSize=12.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(dp(14),dp(12),dp(14),dp(12));background=rounded(ThemeManager.elevated(this@SettingsActivity),14)
            }
            root.addView(privacy,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(6))})
        }
        if(section=="all" || section=="fonts") addFonts(root)
        if(section=="all" || section=="adaptive") addAdaptive(root)
        return ScrollView(this).apply{addView(root);isFillViewport=true}
    }

    private fun addAppearance(root:LinearLayout){
        section(root,"APPEARANCE")
        val themes=linkedMapOf(ThemeManager.LIGHT to "Light",ThemeManager.DARK to "Dark",ThemeManager.SEPIA to "Sepia",ThemeManager.AMOLED to "AMOLED Black",ThemeManager.MIDNIGHT to "Midnight Blue")
        themes.forEach{(key,label)-> root.addView(button(if(ThemeManager.get(this)==key)"✓  $label" else label){ThemeManager.set(this,key);recreate()},lp())}
    }

    private fun addFonts(root:LinearLayout){
        section(root,"QUIZ TYPOGRAPHY")
        val fonts=linkedMapOf("sans-serif" to "Modern Sans","serif" to "Serif / textbook","monospace" to "Monospace / coding","sans-serif-condensed" to "Condensed Sans","sans-serif-light" to "Light Sans")
        val current=getSharedPreferences("ui",MODE_PRIVATE).getString("quiz_font_family","sans-serif")?:"sans-serif"
        fonts.forEach{(key,label)->root.addView(button(if(current==key)"✓  $label" else label){getSharedPreferences("ui",MODE_PRIVATE).edit().putString("quiz_font_family",key).apply();recreate()},lp())}
    }

    private fun addAdaptive(root:LinearLayout){
        section(root,"ADAPTIVE ENGINE")
        val state=AppManagers.adaptive.state()
        val dark=ThemeManager.isDark(this)
        val cardBg=ThemeManager.elevated(this)
        val border=if(dark) Color.rgb(48,61,75) else Color.rgb(220,226,230)

        fun card(pad:Int=16)=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(pad),dp(pad),dp(pad),dp(pad))
            background=GradientDrawable().apply{setColor(cardBg);cornerRadius=dp(16).toFloat();setStroke(dp(1),border)}
        }
        fun label(text:String,size:Float=12.5f)=TextView(this).apply{
            this.text=text;this.textSize=size;setTextColor(ThemeManager.muted(this@SettingsActivity))
        }
        fun title(text:String,size:Float=17f)=TextView(this).apply{
            this.text=text;this.textSize=size;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))
        }
        fun bar(value:Int, tint:Int):ProgressBar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{
            max=100;progress=value.coerceIn(0,100);progressTintList=android.content.res.ColorStateList.valueOf(tint);backgroundTintList=android.content.res.ColorStateList.valueOf(if(dark)Color.rgb(42,52,64) else Color.rgb(231,235,238))
        }
        fun metric(value:String, caption:String)=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(11),dp(12),dp(11));background=GradientDrawable().apply{setColor(if(dark)Color.rgb(20,28,37) else Color.rgb(248,249,249));cornerRadius=dp(12).toFloat()}
            addView(TextView(this@SettingsActivity).apply{text=value;textSize=21f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))},LinearLayout.LayoutParams(-1,dp(28)))
            addView(label(caption,11.5f),LinearLayout.LayoutParams(-1,-2))
        }

        val hero=card()
        val heroTop=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val heroCopy=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        heroCopy.addView(title("Adaptive Engine",19f))
        heroCopy.addView(label(if(state.safeMode)"Protective mode active" else "Learning from runtime behaviour",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,0)})
        heroTop.addView(heroCopy,LinearLayout.LayoutParams(0,-2,1f))
        val toggle=Switch(this).apply{
            isChecked=AppManagers.adaptive.isAutonomyEnabled();text="";contentDescription="Autonomous runtime optimisation"
            buttonTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(this@SettingsActivity))
            setOnCheckedChangeListener{_,checked->AppManagers.adaptive.setAutonomyEnabled(checked);Toast.makeText(this@SettingsActivity,if(checked)"Autonomous optimisation enabled" else "Autonomous optimisation paused",Toast.LENGTH_SHORT).show()}
        }
        heroTop.addView(toggle,LinearLayout.LayoutParams(dp(56),dp(48)))
        hero.addView(heroTop)
        val healthRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(16),0,0)}
        healthRow.addView(title("System health",15f),LinearLayout.LayoutParams(0,-2,1f))
        val healthColor=when { state.health>=80 -> Color.rgb(32,128,91); state.health>=55 -> Color.rgb(163,111,31); else -> Color.rgb(170,55,65) }
        healthRow.addView(TextView(this).apply{text="${state.health}%";textSize=22f;typeface=Typeface.DEFAULT_BOLD;setTextColor(healthColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(58),dp(30)))
        hero.addView(healthRow)
        hero.addView(bar(state.health,if(state.health>=80)Color.rgb(39,151,107)else if(state.health>=55)Color.rgb(190,139,52)else Color.rgb(185,65,77)),LinearLayout.LayoutParams(-1,dp(7)).apply{setMargins(0,dp(7),0,0)})
        hero.addView(label("${state.systemModel.replaceFirstChar{it.uppercase()}} device profile  •  ${if(state.safeMode)"safe mode"else"normal operation"}",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val metrics=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        metrics.addView(metric("${state.learningScore}%","learning"),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(0,0,dp(4),0)})
        metrics.addView(metric("${state.confidence}%","confidence"),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(dp(4),0,dp(4),0)})
        metrics.addView(metric("${state.autonomousChanges}","changes"),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(metrics,LinearLayout.LayoutParams(-1,dp(68)).apply{setMargins(0,0,0,dp(10))})

        val learning=card()
        learning.addView(title("Learning signal"))
        learning.addView(label("Confidence",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(4))})
        learning.addView(bar(state.confidence,ThemeManager.accent(this)),LinearLayout.LayoutParams(-1,dp(6)))
        learning.addView(label("Uncertainty ${state.uncertainty}%  •  exploration ${state.exploration}%",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,0)})
        learning.addView(label("User model: ${state.userModel}  •  System model: ${state.systemModel}",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,0)})
        root.addView(learning,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val strategy=card()
        strategy.addView(title("Current study strategy"))
        strategy.addView(label(AppManagers.adaptive.studyStrategy(),13.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,0)})
        root.addView(strategy,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val policy=card()
        policy.addView(title("Runtime policy"))
        policy.addView(label("Prefetch depth",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(4))})
        policy.addView(bar((state.preferredPrefetch/3f*100f).toInt(),ThemeManager.accent(this)),LinearLayout.LayoutParams(-1,dp(6)))
        policy.addView(label("${state.preferredPrefetch} question${if(state.preferredPrefetch==1)""else"s"}  •  cache ${PerformanceManager.adaptiveCacheTtlMs()/1000}s",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,0)})
        policy.addView(label("Next policy: ${AppManagers.adaptive.currentProposal().action.key}",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(2))})
        policy.addView(label(AppManagers.adaptive.currentProposal().reason,12.5f))
        root.addView(policy,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val activity=card()
        activity.addView(title("Engine activity"))
        activity.addView(label("${state.observations} observations  •  ${state.answers} answers  •  ${state.correct} correct  •  ${state.wrong} wrong",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(8))})
        activity.addView(label("Last action: ${state.lastAction}  •  outcome: ${state.lastOutcome}",12f))
        activity.addView(label("Rollbacks: ${state.rollbackCount}",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(8))})
        val history=state.recentActions
        if(history.isEmpty()) activity.addView(label("No autonomous changes yet.",12f))
        else history.take(8).forEachIndexed{idx,line->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(8),0,dp(8))}
            row.addView(TextView(this).apply{text="${idx+1}";textSize=11f;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));background=rounded(ThemeManager.explanationBg(this@SettingsActivity),10);},LinearLayout.LayoutParams(dp(28),dp(28)))
            row.addView(label(line,11.5f),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(10),0,0,0)})
            activity.addView(row)
        }
        root.addView(activity,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val safety=card()
        safety.addView(title("Safety boundaries"))
        safety.addView(label("The engine can tune only prefetch, cache lifetime and safe mode. It cannot alter question content, progress records, database schema, backups or executable code.",12.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(8))})
        safety.addView(label("Rollback count: ${state.rollbackCount}  •  Safe mode: ${if(state.safeMode)"active"else"ready"}",12f))
        root.addView(safety,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        root.addView(button("Reset Adaptive Learning History"){AppManagers.adaptive.resetLearning();Toast.makeText(this,"Adaptive history reset",Toast.LENGTH_SHORT).show();recreate()},lp())
    }

    private fun section(root:LinearLayout,t:String){root.addView(TextView(this).apply{text=t;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(16),0,dp(8))})}
    private fun lp()=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}
    private fun button(t:String,click:()->Unit)=TextView(this).apply{text=t;textSize=14f;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),0,dp(16),0);setTextColor(ThemeManager.text(this@SettingsActivity));background=rounded(ThemeManager.elevated(this@SettingsActivity),14);setOnClickListener{click()}}
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
}
