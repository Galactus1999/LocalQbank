# Rovex v8.3.432 — CI Compile Repair 2

- versionCode: 524
- versionName: 8.3.432

## CI failure repaired
The v8.3.431 CI run reached `:app:compileDebugKotlin` and failed because the new bounded retrieval/recovery APIs were referenced but not actually present in QBankDb, and the new workers incorrectly called `.use {}` on the process-scoped QBankDb.

## Changes
- Added `QBankDb.questionRefsForIdsBounded(LongArray)`: live-source SQL lookup, bounded to 100 unique IDs, no whole-corpus materialization.
- Added `QBankDb.pendingDeletingSourceIds()` for durable deletion recovery.
- Kept `questionRefsForIds()` compatible while routing it through the bounded lookup.
- Removed invalid `QBankDb.use {}` from deletion-recovery and FTS-maintenance workers.
- Added regression coverage for bounded lookup and tombstone recovery.
- Corrected the existing deletion regression's dirty-index expectation: a successful source deletion leaves the logical FTS index usable (`dirty=0`) while physical FTS garbage is deferred.
- Preserved QBank tombstones, resumable deletion, bounded write batches, deferred FTS maintenance, and bounded Frankenstein/Ren retrieval.
