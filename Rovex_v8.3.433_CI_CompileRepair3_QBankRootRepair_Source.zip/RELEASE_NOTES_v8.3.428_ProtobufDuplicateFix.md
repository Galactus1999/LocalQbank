# Rovex v8.3.428 — Release CI Protobuf Duplicate-Class Repair

## Defect
Release CI failed at `:app:checkReleaseDuplicateClasses` because both:
- `com.google.protobuf:protobuf-java:4.32.1`
- `com.google.protobuf:protobuf-javalite:3.25.5`
contained the same `com.google.protobuf.*` classes.

## Repair
The app module now excludes only the full `protobuf-java` artifact transitively. The Android Lite protobuf runtime remains available. Rovex source has no direct `com.google.protobuf` imports.

## Verification status
- Source edit: complete.
- Static source audits: must pass after packaging.
- Release compilation: pending next CI run.
- APK/device verification: pending a successful release build.
