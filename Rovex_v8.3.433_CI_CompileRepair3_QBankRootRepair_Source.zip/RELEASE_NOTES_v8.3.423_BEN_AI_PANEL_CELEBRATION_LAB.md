# Rovex v8.3.423 — BEN + AI Panel + Celebration Lab

## Baseline
- Starting source: v8.3.422 / versionCode 514
- Package/applicationId: `com.localqbank.library`
- This candidate increments monotonically to versionCode 515 / versionName 8.3.423.

## User-facing changes

### BEN + AI
- Removed `RELATED Qs` from the BEN + AI action row.
- Removed `PDF TEXT` from the BEN + AI action row.
- Kept local evidence retrieval internal to Ben's context-building pipeline; the chat surface no longer exposes those two evidence-viewer actions.
- Remaining actions are compacted to `RUN FREE AI`, `SEARCH`, `SAVE NOTES`, and `CLOSE`.
- Added edge-to-edge window-inset handling so the bottom controls remain above the Android gesture/navigation area.
- The top edge remains unpadded so the BEN + AI header can sit flush against the physical top edge.
- Preserved the existing full-screen modal/dialog architecture and streaming chat behavior.

### Celebration Lab
- Added a dedicated Celebration Lab from Quiz > Question settings.
- Users can choose exact accepted-answer counts at which celebrations fire.
- Presets:
  - Every 10 questions (default)
  - Every 25 questions
  - High-yield milestones (10, 20, 30, 50, 100)
  - Custom comma/semicolon/whitespace-separated question counts
- Users can choose celebration style:
  - Rotate through all 10 procedural effects
  - Random effect
  - Fixed effect
- Users can choose the fixed effect index when using Pick One.
- Milestone sound can be enabled/disabled.
- Preview is visual-only and cannot modify quiz progress.
- Celebration persistence is isolated in `RovexCelebrationPreferences`; the planner is presentation-only.
- Existing answer persistence remains authoritative; celebration failures remain non-fatal.

## Tests added
- Custom celebration target parsing/normalization.
- Invalid milestone target fallback.
- Exact milestone triggering.
- Ten-style rotation.
- Fixed-style determinism.

## Verification performed
- Chat architecture audit: PASS.
- Ruthless static audit: PASS.
- Coroutine cancellation audit: PASS.
- Frankenstein policy audit: PASS.
- Performance/search architecture audit: PASS.
- Existing broad architecture regression audit still reports known pre-existing debt in unrelated Activities and MainActivity AppContainer boundary; no opportunistic rewrite was performed.
- Existing `verify_defect_regressions.sh` still reports the known unrelated Main Search hierarchy-retrieval defect; this change does not modify Main Search.

## Build status
LOCAL GRADLE: BLOCKED.

The wrapper requires Gradle 9.3.1 from `downloads.gradle.org`, but DNS resolution is unavailable in the current environment. Therefore this candidate is NOT claimed CI-green, JVM-green, APK-built, device-tested, or release-ready.

## Required next gate
Run GitHub Actions CI for v8.3.423 and inspect the complete logs. Only after compilation and all JVM tests pass should APK/device verification proceed.
