# v8.3.426 source audit

## Supplied CI log
The supplied `logs_98144847519.zip` is a GitHub Actions build log, not an Android runtime/logcat capture. Its JVM test stage failed compilation in the newly added online files:
- `RovexOnline.kt:35` Result<FirebaseUser> return mismatch.
- `RovexOnline.kt:60` type inference failures.
- `RovexOnlineActivity.kt:55,142,274,283,295` unresolved `rounded`.
- `RovexOnlineActivity.kt:92,96,110,121,125,129,130,135,139,146` CardScope was being used where Android Context was required.
- `RovexOnlineActivity.kt:145` CardScope lacked `add(View, LayoutParams)`.

All of these source defects were corrected in v8.3.426.

## Runtime root cause from source forensic audit
The reported sequence—delete one QBank, then slow loading/search/Frankenstein/Ben+AI/metrics and device heating—maps to a concrete post-delete defect.

`QBankDb.deleteSource()` correctly removed the deleted source's FTS rows. However, after the normalized delete it called the old `markSearchIndexCleanIfCountsMatch()`, which unconditionally marked the search index dirty and scheduled `rebuildSearchIndexIfNeeded()`.

That rebuild scanned the entire remaining question corpus, constructed large FTS documents and inserted the complete remaining corpus into FTS in one large transaction. For a large local corpus this can create sustained CPU, SQLite I/O and write contention. Frankenstein and Ben retrieval share the same QBank database/search path, while analytics and QBank loading also query the database. This explains the application-wide slowdown and heating immediately after a delete.

## Repair
v8.3.426:
1. Captures whether the FTS index was already dirty before deletion.
2. Tracks whether source-scoped FTS cleanup succeeds.
3. If the index was clean and FTS cleanup succeeds, publishes it clean directly. No full-corpus rebuild occurs.
4. If the index was already dirty, preserves the dirty state rather than creating a new rebuild spike after deletion.
5. If FTS cleanup itself fails, retains dirty state and schedules repair for correctness.
6. If normalized deletion fails after FTS cleanup, the failure path marks the index dirty and schedules reconciliation so a partial FTS deletion cannot be published as clean.
7. Adds an instrumented regression proving source/test/question/FTS rows are removed and a previously clean index remains clean.
8. Preserves the normalized-table search fallback for dirty/incomplete FTS.
9. Leaves the existing QBank deletion transaction, progress cleanup, cache invalidation and AppState mutation semantics intact.

## Static verification
PASS:
- coroutine cancellation audit
- chat/Ben streaming architecture audit
- performance/search architecture audit
- QBank regression audit
- ruthless static audit
- XML/layout audit
- Firebase OAuth configuration audit
- Kotlin structural delimiter audit for modified Kotlin files
- old `markSearchIndexCleanIfCountsMatch` call removed
- deletion repair symbols present
- regression test present

## Build limitation
The supplied CI log proves the v8.3.425 compilation failure. v8.3.426 source corrections are source-audited but must not be called compiled/green until GitHub Actions or another real Android build completes successfully.
