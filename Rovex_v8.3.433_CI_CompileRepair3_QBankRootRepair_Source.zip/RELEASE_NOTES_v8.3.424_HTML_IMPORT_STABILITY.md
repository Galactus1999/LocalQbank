# Rovex v8.3.424 — HTML QBank Import Stability Repair

## Defect
Large HTML QBanks could finish parsing but appear frozen during the database-writing stage. The UI symptom was typically a progress value around the parser/database transition (for example, `Writing 12523 parsed questions to local database...`).

## Root cause
`QBankDb.importBundle()` previously held the entire normalized QBank import and per-question FTS insertion inside one SQLite transaction. A large corpus could therefore hold the SQLite write transaction for a long interval and defer the expensive transaction commit until the end.

The import path was also keyed primarily to source-file size, so a relatively compact HTML file containing many thousands of questions could still enter this giant-transaction path.

## Repair
- HTML QBank persistence now commits bounded batches for imports above 500 questions.
- Batch size is 250 questions.
- SQLite WAL/non-exclusive transactions are used for the bounded batches.
- Progress continues every 25 questions.
- If a batch or subsequent persistence operation fails, the partially-created source is cleaned up so a failed import is not presented as a completed QBank.
- FTS remains marked dirty during the import and is reconciled through the existing bounded search-index repair mechanism.
- Existing parser, section metadata, question media resolution, search ownership, and AppManagers ownership remain unchanged.

## Regression coverage
Added an Android instrumented regression test importing 1,250 synthetic questions and asserting:
- import completion;
- incremental progress callbacks;
- exact imported question count;
- source/test persistence.

## Flashcard audit
The APKG importer remains batch-transactional with durable checkpoints, cancellation, media extraction limits, modern/legacy collection handling, and a foreground WorkManager owner. No speculative IPC/model/runtime rewrite was made in this repair. Android 16's current long-running WorkManager/foreground-service quota behavior remains a separate runtime-validation item.

## Verification status
Static/source verification is performed on the prepared source tree. Local Android Gradle compilation remains environment-dependent and is not claimed green unless the actual build passes. Device import performance remains a CI/device evidence gate.
