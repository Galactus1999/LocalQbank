# Rovex v8.3.425 — Import crash repair + production online foundation

## 1. Immediate defect repaired

The previous CI failure was a Kotlin API mismatch in `RovexCelebrationPlannerDialog.kt`:
`EditText.singleLine` was being used as though it were a mutable property. Android's API exposes
`setSingleLine(Boolean)` for this usage. The source now uses `setSingleLine(false)`.

This repair is intentionally isolated and was checked before adding the online layer.

## 2. Online support implemented

Rovex now has a real offline-first online boundary instead of a decorative leaderboard UI:

- Google authentication through Firebase Authentication + Android Credential Manager.
- Uses the Firebase-generated **web/server OAuth client ID** through `default_web_client_id`, matching
  Firebase's current Google-sign-in guidance.
- Existing `google-services.json` was inspected: the `com.localqbank.library` Android OAuth client and
  a Web OAuth client are both present.
- A deterministic shareable Rovex ID is derived from the Firebase UID; email addresses are not used as
  the friend identifier.
- Firestore friend-code lookup, friend requests, accept/decline, mirrored friendship state, and a
  private Friends Arena are implemented.
- Only identity/profile metadata and competitive aggregates go online. QBank content, answers, imported
  APKG/HTML data, notes, PDFs and Ben/AI conversations are not uploaded.
- Firestore Android offline persistence remains authoritative for the online write queue: study events
  can be written while offline and synchronized by Firestore when connectivity returns.
- Quiz-completed and flashcard-reviewed events are submitted asynchronously from `StudyEventSpine`; the
  foreground study path does not wait for Firebase network completion.
- Competitive aggregates are **server-authoritative**. The Android client is not permitted by Firestore
  rules to write `questionsSolved`, `correct`, `accuracyPercent`, `flashcardsReviewed`, `todaySolved`, or
  `xp` directly.
- Firebase Cloud Functions 2nd gen processes immutable study-event documents transactionally and updates
  the aggregate profile. Duplicate trigger delivery is made idempotent with a processed marker.
- Friend profile reads are permitted only for established friends (or the owner).
- Firebase project files are included: `firebase.json`, `.firebaserc`, `firestore.rules`,
  `firestore.indexes.json`, and `functions/`.

## 3. Backend implementation

`functions/index.js` uses current Firebase 2nd-gen Firestore triggers. The current package versions were
checked against the npm registry on 2026-09-26:

- `firebase-functions` 7.4.0
- `firebase-admin` 14.5.0
- Node.js 22 runtime

The backend uses a Firestore transaction for the aggregate update so concurrent events are serialized and
an event cannot increment the same counters twice after a trigger retry.

## 4. Research basis

Firebase's current Android Google authentication documentation recommends Firebase Auth with Credential
Manager, `GetGoogleIdOption`, `GetCredentialRequest`, and the **web/server** client ID in
`setServerClientId`. It also requires the Android app's SHA-1 fingerprint and enabling Google as an
Authentication provider. See:
https://firebase.google.com/docs/auth/android/google-signin

Firebase's current Firestore documentation states that Android offline persistence is enabled by default
and synchronizes local changes when connectivity returns. See:
https://firebase.google.com/docs/firestore/enterprise/enable-offline

Firebase's current Cloud Functions documentation supports Firestore `onDocumentCreated` / auth-context
triggers and recommends idempotent processing; Firestore transactions provide atomic, retry-safe updates.
See:
https://firebase.google.com/docs/functions/firestore-events
https://firebase.google.com/docs/firestore/manage-data/transactions

## 5. Verification performed source-side

- CI compile defect identified from uploaded logs and corrected.
- Pure Kotlin online identity helper compilation with `-Werror`: PASS.
- Deterministic Rovex-ID behavior proof: PASS.
- Node.js Cloud Function syntax check: PASS.
- Firestore rules structural audit: PASS.
- Online architecture audit: PASS.
- Coroutine cancellation audit: PASS; no online coroutine file lacks an explicit cancellation boundary.
- Existing chat architecture audit: PASS.
- Existing performance/search regression audit: PASS.
- Existing ruthless static audit: PASS.
- Google OAuth configuration audit: PASS (Android + Web OAuth clients present).
- Source ZIP integrity check: required before release packaging.

## 6. Verification deliberately NOT claimed

The local environment cannot resolve `downloads.gradle.org`, so local Gradle compilation cannot be claimed
from this environment. The exact source must therefore pass the repository's GitHub Actions workflow before
being called build-green/APK-verified.

The Firebase Console state cannot be inferred from `google-services.json`. Before the first production
online test, the Firebase project must have:

1. Google sign-in provider enabled.
2. The production Rovex signing certificate SHA-1 registered (the repository CI already enforces the
   persistent release certificate fingerprint).
3. Cloud Firestore provisioned.
4. `firestore.rules` deployed.
5. `functions/` deployed with Firebase CLI.

These are backend deployment gates, not UI placeholders. No successful production login or friend sync is
claimed until an actual device completes Google sign-in, creates a profile, sends/accepts a friend request,
and observes synchronized competitive progress from two accounts.
