# Rovex v8.3.429 — QBank Overload Root Repair

## Version
- versionName: 8.3.429
- versionCode: 521
- package: com.localqbank.library

## Primary repair
Fixed the root performance chain behind QBank-open crashes/black screens, Ben+AI/Frankenstein stalls, slow measurements, device heating, and QBank deletion stalls.

### Changes
- QBank delete no longer synchronously scans/deletes the entire FTS4 corpus by unindexed `source_id`.
- QBank normalized deletion is split into bounded 250-question transactions.
- Progress cleanup uses indexed `progress_v2.test_id` ownership instead of broad stable-key LIKE scans.
- Search no longer schedules a full FTS rebuild merely because the index is dirty.
- FTS remains the first retrieval lane while dirty; normalized joins prevent deleted questions from resurfacing.
- FTS maintenance moved to unique WorkManager work requiring device idle and battery-not-low.
- FTS rebuild uses 100-row write batches plus a mutation-generation guard.
- Sub-QBank progress summaries are now set-based SQL aggregation instead of a Kotlin loop over every question.
- TestList/QBank loading no longer materializes the full progress snapshot merely to calculate sub-QBank summaries.
- Added instrumentation regression coverage for deletion/FTS behavior and set-based sub-QBank summaries.

## Preserved
- Ben/Frankenstein authoritative retrieval architecture.
- QBank normalized tables as source of truth.
- Existing cache invalidation and QBank hierarchy behavior.
- Previous v8.3.426 QBank-delete repair intent.
- v8.3.428 protobuf duplicate-class correction.

## Verification
Static audits pass. Gradle compilation remains externally blocked in the current environment by DNS failure resolving `downloads.gradle.org`.
