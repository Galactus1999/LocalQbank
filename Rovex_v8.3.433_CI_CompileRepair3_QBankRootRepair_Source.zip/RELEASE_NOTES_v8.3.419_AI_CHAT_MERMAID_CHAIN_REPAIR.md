# Rovex v8.3.419 — AI Chat Mermaid Chain Repair

## CI root cause addressed
v8.3.418 compiled successfully and executed 97 JVM unit tests, but one renderer regression failed:
`RovexRichRendererTest.inlineMermaidSurvivesProviderCollapsedWhitespace` at the assertion for the later `Anticholinergic` node.

## Root cause
`parseFlowGraph()` historically extracted only the first Mermaid edge operator from a physical line. Provider-collapsed AI responses can place multiple Mermaid edges on one line, e.g. `A --> B B --> C C --> D`. The first edge was rendered, while later bare nodes/edges could disappear.

## Repair
- Added a high-confidence repeated-edge parser for collapsed Mermaid flow lines.
- Parses every supported edge operator on a line, including optional `|edge label|` syntax.
- Preserves the existing single-edge parser as a compatibility fallback for unusual Mermaid syntax.
- Deduplication remains downstream through `edges.distinct()` in the SVG renderer.
- Added a regression test proving later nodes and edges survive a collapsed chain.
- No WebView JavaScript, network, provider, or AI behavior was changed.

## Verification
- Repository static audits: PASS.
- Exact Python reproduction of the collapsed edge grammar: PASS; all six expected edges were recognized.
- Local Gradle Android/JVM execution is not claimed here unless CI verifies it. Previous environment could not resolve Gradle distribution DNS.
