# Rovex v8.3.433 — CI Compile Repair 3 / Frankenstein Bounded Retrieval Contract

## Evidence source

CI log inspected: `logs_98168068499.zip`.

The workflow successfully acquired the v8.3.432 source and reached `:app:compileDebugKotlin` during the JVM-unit-test workflow. The build did **not** reach test execution or APK packaging.

## First actionable compiler failure

The first actionable errors were all in `FrankensteinContextEngine.kt` around the newly added bounded retrieval block:

- line 151: Kotlin could not infer the result type of `runCatching`.
- line 153+: cascading inference/map errors.
- `exam` / `source` errors later were cascades after `related` lost its concrete type.

The v8.3.432 block also incorrectly referred to `QBankDb.QuestionRef`, while `QuestionRef` is a package-level data class in `QBankDb.kt`, not a nested class. The CI cascade therefore also included unresolved member/type errors.

## Root cause

The v8.3.432 integration added the bounded retrieval API and callers, but the caller's generic type boundary was under-specified and the type was referenced through the wrong owner. This is an integration/compile-contract defect, not evidence that the bounded retrieval architecture itself was wrong.

## v8.3.433 repair

1. Explicitly typed the result:
   `val related: List<RelatedQuestion> = runCatching<List<RelatedQuestion>> { ... }`
2. Corrected `QBankDb.QuestionRef` to package-level `QuestionRef`.
3. Explicitly typed the reference map:
   `Map<Long, QuestionRef>`.
4. Used `wanted.asList().mapNotNull` to make the collection contract unambiguous.
5. Added an empty-candidate fast path.
6. Kept `db.close()` in `finally`.
7. No change to QBank deletion semantics, tombstoning, deferred FTS cleanup, bounded retrieval policy, or AI resource governor.

## Targeted proof

A standalone Kotlin probe reproducing the exact repaired bounded-retrieval type pattern compiled successfully:

`TARGETED_KOTLIN_PROBE=PASS`

No syntax/expecting/unclosed-token diagnostics were produced by a standalone Kotlin parse/compile attempt of `FrankensteinContextEngine.kt`; unresolved Android/project dependencies in that isolated invocation are expected because the Android/Gradle classpath is absent.

## Static project audits

PASS:
- coroutine cancellation audit
- Frankenstein policy audit
- chat architecture audit
- performance/search architecture audit
- search/QBank regression audit
- root architecture audit
- ruthless static audit

One legacy `verify_defect_regressions.sh` check still reports `Main Search does not use authoritative hierarchy retrieval`. This is an existing audit-contract mismatch with the current architecture and is not caused by v8.3.433; the other current search/root audits pass. It must not be represented as a clean compile gate.

## Build limitation

A full Gradle compile could not be run locally because Gradle 9.3.1 is not cached and this environment cannot resolve `downloads.gradle.org` (`curl: (6) Could not resolve host`). Therefore v8.3.433 is **source-audited and targeted-compile-checked, but not yet CI-green**.

## Acceptance status

- Source repair: COMPLETE
- Targeted Kotlin contract proof: PASS
- Static audits: PASS except noted legacy audit-contract mismatch
- Full Gradle compile: PENDING CI
- Release APK: NOT VERIFIED
- Device QBank deletion/black-screen/AI stress test: NOT VERIFIED
