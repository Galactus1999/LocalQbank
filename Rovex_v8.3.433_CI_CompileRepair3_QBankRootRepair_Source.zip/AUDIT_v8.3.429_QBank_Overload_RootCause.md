# Rovex v8.3.429 — QBank Crash / Ben+AI / Frankenstein Overload Root-Cause Audit

## User-observed failure

The supplied screenshots show three correlated symptoms:

1. Opening a QBank/sub-QBank can transition through a black screen and then collapse.
2. Ben+AI and Frankenstein stop producing responses while the QBank operation is active.
3. QBank deletion can appear stuck/not complete, followed by slow measurements and device heating.

No new device logcat/ANR trace was supplied with the screenshots, so the exact native crash/ANR stack cannot be claimed as independently proven. The source audit, however, identifies a deterministic overload chain that matches the timing and cross-feature symptoms.

## Root cause A — global FTS repair could monopolize the SQLite writer

`QBankDb.ensureSearchIndex()` previously scheduled a whole-corpus FTS repair whenever the global `dirty` flag was observed. Frankenstein, Ben/Ren, and local search all call this path.

The old repair deleted the entire `question_fts` table and then inserted every QBank question in one large SQLite write transaction. A large local corpus could therefore cause sustained CPU, SQLite write-lock contention, WAL/I/O pressure, and heat. Because the same process owns the QBank database, unrelated foreground features that read that database can become slow at the same time.

This is consistent with the report that QBank navigation, Frankenstein, Ben+AI, and measurement panels all became slow together.

Android's current SQLite guidance explicitly notes that only one write transaction can occur at a time and recommends batching writes; Android's ANR guidance also identifies main-thread I/O and lock contention as common causes of responsiveness failures.

## Root cause B — deleting a QBank synchronously scanned the entire FTS corpus

`question_fts.source_id` is declared `UNINDEXED`. The previous delete path executed:

`DELETE FROM question_fts WHERE source_id=?`

before deleting the normalized QBank rows.

Because `source_id` is not an FTS search index column, that operation can require a scan of the complete FTS corpus. For a large library, this made a user-initiated delete compete with foreground reads even though the delete executor itself was low priority.

The normalized QBank tables are authoritative, and all user search queries join `question_fts` to `question`, `test`, and `source`. Therefore stale FTS rows for already-deleted questions cannot surface as valid QBank results. v8.3.429 removes this expensive synchronous FTS delete from the user delete path.

The FTS index is marked dirty and reconciled later during idle-only maintenance.

## Root cause C — opening a sub-QBank performed an unnecessary full-question Kotlin scan

`TestListActivity` staged metadata correctly, but its second phase called `testProgressSummaries()` with a full `ProgressSnapshot`. The old implementation then walked every question in the source, constructed a stable key, and performed a Kotlin map lookup for each question.

That means opening a sub-QBank with tens of thousands of questions could immediately consume the shared `qbank-worker` after navigation.

v8.3.429 replaces this with a set-based SQLite aggregation using:

- authoritative `test.num_questions`;
- indexed `progress_v2.test_id`;
- grouped solved/correct counts;
- persisted per-test position metadata.

The caller no longer loads the entire progress snapshot merely to draw sub-QBank summaries.

## Root cause D — search treated a dirty index as unusable

When FTS was marked dirty, search skipped FTS and fell back directly to normalized-table LIKE scans. Frankenstein and Ben can issue several bounded retrieval variants, so repeatedly scanning the entire normalized question corpus is itself capable of creating high CPU/I/O pressure.

v8.3.429 changes the policy:

- FTS remains the first retrieval lane even while marked dirty.
- Normalized joins prevent stale deleted FTS rows from surfacing deleted questions.
- LIKE retrieval is used only when the FTS query fails/returns no useful result.
- Interactive search no longer schedules a full index rebuild.

## Root cause E — maintenance was coupled to interactive use

The previous repair executor was an in-process background executor. It could start while the user was actively studying/searching. v8.3.429 moves repair scheduling to a unique WorkManager job requiring:

- Android device idle;
- battery not low;
- a short initial delay;
- unique-work coalescing.

The rebuild itself is also split into small transactions of 100 rows, rather than one corpus-wide write transaction. A mutation-generation guard prevents a concurrent import/delete from being incorrectly published as a clean index.

## QBank deletion redesign

The delete path is now resumable by construction:

1. Read only source/test metadata.
2. Remove progress using indexed `progress_v2.test_id` ownership.
3. Delete question-owned rows in 250-question write batches.
4. Delete test/source rows in a final short transaction.
5. Verify zero remaining tests/questions for the source.
6. Mark FTS dirty without scanning the complete FTS corpus.
7. Schedule idle maintenance only after the authoritative normalized deletion succeeds.

If the process is interrupted between batches, a subsequent delete call continues cleaning the same source rather than relying on one huge rollback.

## Ben / Frankenstein protection

No Ben business owner was replaced. The repair is below the retrieval layer and preserves the existing deterministic QBank retrieval contract.

The important behavioral change is that Ben/Frankenstein no longer cause an FTS rebuild merely by searching while the index is dirty.

## Verification performed

PASS:

- coroutine cancellation audit;
- chat architecture audit;
- performance/search architecture audit;
- search/QBank regression audit;
- ruthless static audit;
- online architecture audit;
- XML/layout audit through ruthless audit;
- main-activity layout-ID audit;
- Kotlin delimiter/balance audit for changed Kotlin files;
- no `Thread.sleep()` introduced;
- version monotonicity: v8.3.428/versionCode 520 -> v8.3.429/versionCode 521.

Instrumentation regression added:

- QBank deletion leaves no normalized source/test/question rows;
- stale FTS rows do not return deleted questions;
- dirty state is preserved until idle maintenance;
- idle maintenance reconciles the stale FTS rows;
- sub-QBank progress summary returns correct totals/solved/correct/resume values using the new aggregate path.

## Remaining external gate

The source cannot be declared compile-green in this environment because Gradle 9.3.1 cannot be downloaded: `downloads.gradle.org` DNS resolution fails. Therefore this audit does not claim a successful APK build or device run.

The required final proof remains:

1. GitHub Actions compile/unit/instrumented tests;
2. release APK creation;
3. install on the OnePlus CPH2691 / Android 16 test device;
4. reproduce: open QBank -> open sub-QBank -> open question;
5. delete a large QBank while observing responsiveness;
6. run Frankenstein search and Ben+AI during/after the operations;
7. verify no ANR/crash, no sustained heating caused by QBank maintenance, and successful QBank deletion;
8. complete APK/signing/Zstd/Firebase SHA-1 and release artifact gates.
