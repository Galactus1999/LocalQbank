# Rovex v8.3.426 — QBank deletion performance/root-cause repair

## Root cause

A deleted QBank was followed by a full rebuild of the entire remaining FTS search corpus.

The delete path removed the deleted source's `question_fts` rows successfully, but then called the old `markSearchIndexCleanIfCountsMatch()`, which unconditionally marked the index dirty and immediately scheduled `rebuildSearchIndexIfNeeded()`. That rebuild:
- scans every remaining question and builds a large concatenated search document;
- inserts every remaining question into FTS inside one transaction;
- consumes substantial CPU/SQLite I/O;
- competes with foreground QBank reads, Frankenstein retrieval, Ben+AI and diagnostic/measurement DB work;
- can cause sustained device heat and apparent application-wide slowness.

This was unnecessary when the FTS index was clean before deletion, because deleting the source's FTS rows is itself an exact incremental index mutation.

## Repair

- Capture the pre-delete FTS dirty state.
- Track whether source-scoped FTS cleanup actually succeeded.
- If the index was clean before deletion and FTS cleanup succeeds, publish the index clean immediately without rebuilding the remaining corpus.
- If the index was already dirty, preserve the dirty state instead of creating a new full rebuild spike immediately after deletion.
- If FTS cleanup itself fails, retain dirty state and schedule repair for correctness.
- If normalized deletion fails after FTS cleanup, also mark the index dirty and schedule reconciliation so a partial FTS deletion can never be published as clean.
- Keep normalized QBank deletion and FTS cleanup semantics intact.
- Add an instrumented regression proving source/test/question/FTS rows are removed and a previously clean index remains clean.

## Build-log defects repaired

The v8.3.425 CI log also contained Kotlin compilation failures in the newly added online UI/auth code. v8.3.426 fixes:
- `RovexOnlineAuth.signInWithGoogle()` Result return-type mismatch.
- `RovexOnlineActivity` missing `rounded()` helper.
- CardScope accidentally passing CardScope as Android Context.
- CardScope `add(View, LayoutParams)` overload missing.
- associated type-inference/context errors reported by CI.

## Stability principle

No search-index rebuild is triggered merely because a normal QBank deletion completed.

Search remains correct through the authoritative normalized tables even while an index is dirty; the existing search fallback can serve normalized-table results.

## Verification

Source-level audit completed:
- QBank deletion path reviewed end-to-end.
- FTS dirty/clean transition reviewed.
- Online compile-error locations from the supplied CI log corrected.
- Regression test added.
- Whole-project static/runtime-risk audit must be rerun in CI before APK acceptance.

Local/CI compilation must not be claimed until an actual build passes.
