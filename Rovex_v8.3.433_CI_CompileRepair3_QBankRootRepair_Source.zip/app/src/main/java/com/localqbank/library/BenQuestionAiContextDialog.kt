package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.lifecycle.lifecycleScope
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.localqbank.library.ai.context.ContextPackBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Full-screen AI handoff surface. The current question is already visible in QuizActivity; this panel avoids duplicating it and lets Free AI lead after Ben builds bounded local context. */
class BenQuestionAiContextDialog {
    private var activeChromeController: RovexChatChromeController? = null
    private var activeAiJob: Job? = null
    private var streamSequence: Long = 0L
    private var chatGeneration: Long = 0L
    /** Latest bounded local evidence envelope used by this dialog. UI actions can inspect it without re-querying. */
    private var activeContext: FrankensteinContextEngine.ContextBundle? = null

    fun show(activity: QuizActivity, q: Question, selectedOption: String?) {
        ProductionCrashReporter.breadcrumb(activity, "AI_CONTEXT_OPENED")
        RovexSoundFeedback.playClick(activity)
        activeContext = null
        val dialog = Dialog(activity)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
            background = ThemeManager.backgroundDrawable(activity)
        }
        val topChrome = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(RovexColorFlowTextView(activity).apply {
            text = "BEN + AI"
            textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.aiText(activity))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(activity).apply {
            text = "EXAM INTELLIGENCE"; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.aiText(activity)); background = rounded(activity, ThemeManager.explanationBg(activity), 12f)
            setPadding(dp(activity, 10), dp(activity, 7), dp(activity, 10), dp(activity, 7))
        })
        val textSizeButton = TextView(activity).apply {
            text = "TEXT"; textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(activity)); background = rounded(activity, ThemeManager.elevated(activity), 10f)
            setPadding(dp(activity, 8), dp(activity, 7), dp(activity, 8), dp(activity, 7))
        }
        header.addView(textSizeButton, LinearLayout.LayoutParams(dp(activity, 48), dp(activity, 32)).apply { leftMargin = dp(activity, 6) })
        topChrome.addView(header, LinearLayout.LayoutParams(-1, dp(activity, 30)))

        val modeScroll = HorizontalScrollView(activity).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val modeRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        val modes = listOf(BenQuestionAiMode.PYQ_CONTEXT, BenQuestionAiMode.PYT_CONTEXT, BenQuestionAiMode.FUTURE_RELATED, BenQuestionAiMode.OTHER_OPTIONS)
        var reenableFollowUp: (() -> Unit)? = null
        var activeMode = BenQuestionAiMode.PYQ_CONTEXT
        val chips = linkedMapOf<BenQuestionAiMode, TextView>()
        fun chip(mode: BenQuestionAiMode) = TextView(activity).apply {
            text = mode.label; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(activity, 4), 0, dp(activity, 4), 0); isClickable = true; isFocusable = true
        }
        modes.forEach { mode ->
            val c = chip(mode); chips[mode] = c
            modeRow.addView(c, LinearLayout.LayoutParams(dp(activity, 132), dp(activity, 32)).apply { leftMargin = dp(activity, 2); rightMargin = dp(activity, 2) })
        }
        modeScroll.addView(modeRow, android.view.ViewGroup.LayoutParams(-2, dp(activity, 34)))
        topChrome.addView(modeScroll, LinearLayout.LayoutParams(-1, dp(activity, 36)).apply { topMargin = dp(activity, 2) })

        val status = TextView(activity).apply {
            text = "${currentBenExamProfile(activity).label} • Local evidence first • Free AI / Google optional"
            textSize = 9.5f; setTextColor(ThemeManager.muted(activity)); setPadding(dp(activity, 3), 0, dp(activity, 3), 0)
        }
        topChrome.addView(status, LinearLayout.LayoutParams(-1, dp(activity, 14)).apply { topMargin = dp(activity, 1) })
        root.addView(topChrome, LinearLayout.LayoutParams(-1, dp(activity, 80)))

        val web = BenChatWebView(activity).apply {
            RovexChatDocument.configure(this)
            settings.loadsImagesAutomatically = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient = object : RovexSafeWebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val u = request.url.toString(); if (u.startsWith("https://")) activity.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, request.url)); return true
                }
            }
            setBackgroundColor(Color.TRANSPARENT)
            isVerticalScrollBarEnabled=true
            isHorizontalScrollBarEnabled=true
            overScrollMode=android.view.View.OVER_SCROLL_IF_CONTENT_SCROLLS
            scrollBarStyle=android.view.View.SCROLLBARS_INSIDE_OVERLAY
        }
        web.settings.textZoom = activity.getSharedPreferences("chat_ui", android.content.Context.MODE_PRIVATE).getInt("ben_ai_text_zoom", 100).coerceIn(75,160)
        web.isHorizontalScrollBarEnabled = true
        web.overScrollMode = android.view.View.OVER_SCROLL_IF_CONTENT_SCROLLS
        textSizeButton.setOnClickListener { showChatTextSize(activity, web) }
        val chatFrame = FrameLayout(activity).apply { clipChildren = false; clipToPadding = false }
        chatFrame.addView(web, FrameLayout.LayoutParams(-1, -1))
        val revealControls = TextView(activity).apply {
            text = "⌃"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(activity))
            background = rounded(activity, ThemeManager.elevated(activity), 12f)
            elevation = dp(activity, 4).toFloat(); minWidth = dp(activity, 38); minimumHeight = dp(activity, 30)
        }
        chatFrame.addView(revealControls, FrameLayout.LayoutParams(dp(activity, 38), dp(activity, 30), Gravity.TOP or Gravity.END).apply { topMargin = dp(activity, 5); rightMargin = dp(activity, 4) })
        root.addView(chatFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        dialog.setOnDismissListener {
            chatGeneration++
            activeAiJob?.cancel()
            activeAiJob = null
            runCatching { web.stopLoading() }
            runCatching { web.loadUrl("about:blank") }
            runCatching { (web.parent as? android.view.ViewGroup)?.removeView(web) }
            runCatching { web.removeAllViews() }
            runCatching { web.destroy() }
            activeChromeController = null
        }

        val bottomChrome = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val chatHistory = mutableListOf<Pair<String, String>>()
        val followUpInput = EditText(activity).apply {
            hint = "Ask a follow-up about this answer…"
            textSize = 14f
            setSingleLine(false)
            maxLines = 3
            setTextColor(ThemeManager.text(activity))
            setHintTextColor(ThemeManager.muted(activity))
            setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8))
            background = rounded(activity, ThemeManager.elevated(activity), 12f)
        }
        val followRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        followRow.addView(followUpInput, LinearLayout.LayoutParams(0, dp(activity, 40), 1f).apply { rightMargin = dp(activity, 5) })
        val followUp = TextView(activity).apply {
            text = "ASK"; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(activity)); background = rounded(activity, ThemeManager.elevated(activity), 10f)
            setPadding(dp(activity, 8), 0, dp(activity, 8), 0)
        }
        reenableFollowUp = { followUp.isEnabled = true }
        followUp.setOnClickListener {
            RovexSoundFeedback.playClick(activity)
            val query = followUpInput.text.toString().trim()
            if (query.isBlank()) { followUpInput.error = "Enter a follow-up question" }
            else {
                followUp.isEnabled = false
                askFollowUp(activity, web, q, chatHistory, query, followUpInput) { followUp.isEnabled = true }
            }
        }
        followRow.addView(followUp, LinearLayout.LayoutParams(dp(activity, 74), dp(activity, 40)))
        bottomChrome.addView(followRow, LinearLayout.LayoutParams(-1, dp(activity, 40)).apply { topMargin = dp(activity, 2) })

        val actionsScroll = HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setPadding(0, 0, dp(activity, 2), 0)
        }
        val actions = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(activity, 2), 0, dp(activity, 2))
        }
        fun action(label: String, click: () -> Unit) = TextView(activity).apply {
            text = label
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(ThemeManager.text(activity))
            background = rounded(activity, ThemeManager.pastelAccentFill(activity, 0), 16f)
            elevation = dp(activity, 2).toFloat()
            setPadding(dp(activity, 8), 0, dp(activity, 8), 0)
            setOnClickListener { click() }
        }
        var freeButton: TextView? = null
        val free = action("RUN FREE AI") {
            if (activeAiJob?.isActive == true) {
                activeAiJob?.cancel()
                activeAiJob = null
                status.text = "BEN + AI • GENERATION STOPPED"
                freeButton?.text = "RUN FREE AI"
            } else {
                renderFree(activity, web, status, activeMode, q, selectedOption, prebuiltContext = null, chatHistory = chatHistory, buttonState = { freeButton?.text = it })
            }
        }
        freeButton = free
        val google = action("SEARCH") {
            val query = "${currentBenExamProfile(activity).label} ${q.text} ${activeMode.prompt} Options: ${q.options.joinToString(" | ") { it.label + " " + it.text.take(300) }}"
            activity.startActivity(android.content.Intent(activity, GoogleSearchActivity::class.java).putExtra("query", query).putExtra("questionId", q.id))
        }
        val save = action("SAVE NOTES") {
            val text = web.contentDescription?.toString().orEmpty().trim()
            if (text.isBlank()) Toast.makeText(activity, "Generate an AI answer first", Toast.LENGTH_SHORT).show()
            else { activity.saveAiResponseToNotes(q.id, text); Toast.makeText(activity, "Saved to My Notes", Toast.LENGTH_SHORT).show() }
        }
        val close = action("CLOSE") { dialog.dismiss() }
        listOf(free, google, save, close).forEachIndexed { i, v ->
            actions.addView(v, LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 32)).apply {
                leftMargin = if (i == 0) 0 else dp(activity, 4)
                rightMargin = if (i == 3) 0 else dp(activity, 4)
            })
        }
        actionsScroll.addView(actions, android.view.ViewGroup.LayoutParams(-2, dp(activity, 36)))
        bottomChrome.addView(actionsScroll, LinearLayout.LayoutParams(-1, dp(activity, 38)).apply { topMargin = dp(activity, 2) })
        root.addView(bottomChrome, LinearLayout.LayoutParams(-1, dp(activity, 80)).apply { topMargin = dp(activity, 2) })

        // Keep chat chrome stable. Auto-hiding it on every touch/scroll was competing with
        // WebView's gesture handling and produced the jumpy Ben + AI scrolling experience.
        activeChromeController = RovexChatChromeController(web, topChrome, bottomChrome, revealControls, { true }, collapseTop = true, revealAtBottom = false)

        fun renderMode() { chips.forEach { (m, v) -> val on = m == activeMode; v.background = rounded(activity, if (on) ThemeManager.accent(activity) else ThemeManager.elevated(activity), 13f); v.setTextColor(if (on) Color.WHITE else ThemeManager.text(activity)) }; renderLocal(activity, web, status, activeMode, q, selectedOption, chatHistory) }
        chips.forEach { (m, v) -> v.setOnClickListener { activeMode = m; activeAiJob?.cancel(); activeAiJob = null; reenableFollowUp?.invoke(); renderMode() } }

        dialog.setContentView(root)
        // The dialog intentionally draws edge-to-edge at the top, but the bottom action row must
        // never sit underneath Android's gesture/navigation area. Apply only the navigation inset
        // so the BEN + AI header remains flush with the physical top edge.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            val system = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // Keep a small visual safety gap above the gesture handle while leaving the top edge
            // completely unpadded so the BEN + AI header touches the physical screen border.
            view.setPadding(0, 0, 0, maxOf(nav.bottom, system.bottom, ime.bottom) + dp(activity, 6))
            insets
        }
        ViewCompat.requestApplyInsets(root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.let { window ->
            // Keep the chat chrome flush with the top edge. The question Activity already owns
            // system-bar presentation; this full-screen dialog should not reserve a second
            // status-bar band above the BEN + AI header.
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            window.attributes = window.attributes.apply { x = 0; y = 0 }
            window.decorView.setPadding(0, 0, 0, 0)
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
            window.setBackgroundDrawableResource(android.R.color.transparent)
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
            window.setDimAmount(0f)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        dialog.show()
        dialog.window?.setLayout(android.view.WindowManager.LayoutParams.MATCH_PARENT, android.view.WindowManager.LayoutParams.MATCH_PARENT)
        renderMode()
    }


    private fun showChatTextSize(activity: QuizActivity, web: WebView) {
        val values = intArrayOf(80,90,100,115,130,145)
        val labels = arrayOf("Small","Compact","Normal","Large","Extra large","Huge")
        val current = activity.getSharedPreferences("chat_ui", android.content.Context.MODE_PRIVATE).getInt("ben_ai_text_zoom",100).coerceIn(75,160)
        val checked = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(activity).setTitle("Ben + AI chat text size")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                val zoom=values[which]
                activity.getSharedPreferences("chat_ui", android.content.Context.MODE_PRIVATE).edit().putInt("ben_ai_text_zoom",zoom).apply()
                web.settings.textZoom=zoom
                dialog.dismiss()
            }.setNegativeButton("CANCEL",null).show()
    }

    private fun renderLocal(activity: QuizActivity, web: WebView, status: TextView, mode: BenQuestionAiMode, q: Question, selectedOption: String?, chatHistory: MutableList<Pair<String, String>>) {
        val generation = ++chatGeneration
        activeAiJob?.cancel()
        activeAiJob = null
        status.text = "BEN • COLLECTING LOCAL CONTEXT → FREE AI"
        activity.lifecycleScope.launch(Dispatchers.IO) {
            val context = runCatching { AppManagers.frankensteinContext.buildEnhanced(q) }.getOrNull()
            activeContext = context
            val noLocal = context?.relatedQuestions.isNullOrEmpty() && context?.pdfEvidence.isNullOrEmpty()
            val localSummary = buildCompactContextHtml(activity, mode, context)
            activity.runOnUiThread {
                if (generation != chatGeneration || activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                web.loadDataWithBaseURL(null, localSummary, "text/html", "UTF-8", null)
                web.contentDescription = stripForNote(localSummary)
                status.text = if (noLocal) "BEN • NO LOCAL CONTEXT • FREE AI TAKES THE LEAD" else "BEN • CONTEXT READY • FREE AI TAKES THE LEAD"
                // Free AI is the answerer in this surface. Ben only retrieves and packages context.
                renderFree(activity, web, status, mode, q, selectedOption, context, chatHistory, {}, localSummary)
            }
        }
    }

    private fun renderFree(
        activity: QuizActivity,
        web: WebView,
        status: TextView,
        mode: BenQuestionAiMode,
        q: Question,
        selectedOption: String?,
        prebuiltContext: FrankensteinContextEngine.ContextBundle? = null,
        chatHistory: MutableList<Pair<String, String>> = mutableListOf(),
        buttonState: (String) -> Unit = {},
        initialDocument: String? = null
    ) {
        activeAiJob?.cancel()
        val generation = ++chatGeneration
        val streamId = "ai-stream-" + (++streamSequence)
        // Append a stable placeholder; subsequent stream deltas replace only this message.
        val placeholder = "<section id='" + streamId + "' class='chat-turn ai'><div class='chat-role'>AI</div><div class='chat-content'>" + rovexMarkdownBody("*Preparing answer…*", true) + "</div></section>"
        if (initialDocument != null) {
            val seeded = initialDocument.replace("</body>", placeholder + "</body>")
            web.loadDataWithBaseURL(null, seeded, "text/html", "UTF-8", null)
            activeChromeController?.markProgrammaticScroll()
            web.postDelayed({ RovexChatDocument.scrollBottom(web) }, 100)
        } else {
            RovexChatDocument.append(web, streamId, "AI", rovexMarkdownBody("*Preparing answer…*", true), true)
        }
        buttonState("STOP")
        status.text = "BEN + AI • FREE AI STREAMING"
        activeAiJob = activity.lifecycleScope.launch(Dispatchers.IO) {
            val context = prebuiltContext ?: runCatching { AppManagers.frankensteinContext.buildEnhanced(q) }.getOrNull()
            val builder = ContextPackBuilder(activity)
            val packet = builder.forQuestion(q, selectedOption, learnerNote = mode.prompt).toPromptBlock() +
                "\n\n" + builder.questionAiEvidence(q, mode) +
                "\n\n" + compactContextPrompt(context)
            val system = "You are the primary Free AI answerer inside Rovex. Ben is only a context/retrieval assistant here. Answer the CURRENT QUESTION directly; the user already sees the stem and options, so do not repeat them. Use supplied QBank key/explanation as authoritative local truth when present, use related questions and PDF excerpts only as supporting context, never invent PYQ/PYT provenance, and clearly separate general knowledge from local evidence. Return concise exam-oriented Markdown with headings, short paragraphs, and restrained bold key takeaways. Put a blank line between paragraphs/blocks and keep every Markdown table row on its own physical line. Never use pipes or ASCII separators as decorative prose. Emit a Markdown table only when the answer genuinely contains a table. For diagrams/charts, you may emit explicit fenced `mermaid`, `chart`, `tree`, or `slides` blocks; use Markdown images when an image belongs in the answer. The client preserves these authored rich blocks. Never convert ordinary prose into a table and never output CSS, <style> blocks, HTML document wrappers, or CSS selector source such as body{...}; return only the actual answer content."
            val buffer = StringBuilder()
            var lastUi = 0L
            var renderJob: Job? = null
            val renderScope = CoroutineScope(currentCoroutineContext() + Dispatchers.Default)
            var completed = false
            try {
                val result = AppManagers.cloudAi.generateStreaming(
                    prompt = packet,
                    system = system,
                    maxTokens = 2200,
                    timeoutMs = 30_000L,
                    explicitCloudAction = true,
                    onChunk = { delta ->
                    if (delta.startsWith(BenCloudAiGateway.STREAM_PROVIDER_FALLBACK_MARKER)) buffer.setLength(0) else buffer.append(delta)
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - lastUi >= 90L || delta.contains('\n')) {
                        lastUi = now
                        val snapshot = buffer.toString()
                        renderJob?.cancel()
                        renderJob = renderScope.launch {
                            val safe = BenResponsePolicy.normalize(snapshot).orEmpty()
                            val rendered = runCatching { rovexMarkdownBody(safe, RovexTableDisplayPrefs.showTables(activity)) }.getOrElse { android.text.TextUtils.htmlEncode(safe) }
                            withContext(Dispatchers.Main.immediate) {
                                if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) {
                                    RovexChatDocument.replace(web, streamId, rendered, true)
                                    RovexChatDocument.trim(web, 30)
                                    web.contentDescription = safe.take(BenResponsePolicy.MAX_RESPONSE_CHARS)
                                }
                            }
                        }
                    }
                    }
                )
                renderJob?.join()
                if (result != null) {
                    val finalAnswer = BenResponsePolicy.normalize(result.text).orEmpty().trim()
                    if (finalAnswer.isNotBlank()) {
                        val answer = "## Free AI\n\n$finalAnswer\n\n*${result.provider.label} • ${result.model}*"
                        val rendered = runCatching { rovexMarkdownBody(answer, RovexTableDisplayPrefs.showTables(activity)) }.getOrElse { android.text.TextUtils.htmlEncode(answer) }
                        activity.runOnUiThread {
                            if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) {
                                chatHistory.removeAll { it.first == "AI" && it.second.startsWith("## Free AI") && it.second.contains("Preparing answer") }
                                chatHistory += "AI" to answer
                                RovexChatDocument.replace(web, streamId, rendered, true)
                                web.contentDescription = finalAnswer.take(BenResponsePolicy.MAX_RESPONSE_CHARS)
                                status.text = "BEN + AI • ${result.provider.label} • STREAM COMPLETE"
                                buttonState("RUN FREE AI")
                            }
                        }
                        completed = true
                    }
                }
                if (!completed) {
                    activity.runOnUiThread {
                        if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) {
                            val fallback = "## Free AI unavailable\n\nNo configured Free AI provider responded. Ben's local context is still available."
                            chatHistory += "AI" to fallback
                            RovexChatDocument.replace(web, streamId, rovexMarkdownBody(fallback, true), true)
                            status.text = "BEN + AI • FREE AI UNAVAILABLE"
                            buttonState("RUN FREE AI")
                        }
                    }
                }
            } catch (t: CancellationException) {
                activity.runOnUiThread {
                    if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) {
                        status.text = "BEN + AI • GENERATION STOPPED"
                        buttonState("RUN FREE AI")
                    }
                }
                throw t
            } catch (t: Exception) {
                android.util.Log.w("Rovex.BenAiChat", "stream failed", t)
                activity.runOnUiThread {
                    if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) {
                        val fallback = "## Free AI error\n\nThe provider stopped before a complete answer was received. Try again."
                        chatHistory += "AI" to fallback
                        RovexChatDocument.replace(web, streamId, rovexMarkdownBody(fallback, true), true)
                        status.text = "BEN + AI • REQUEST FAILED"
                        buttonState("RUN FREE AI")
                    }
                }
            } finally {
                if (activeAiJob?.isActive != true) activeAiJob = null
            }
        }
    }

    private fun askFollowUp(
        activity: QuizActivity, web: WebView, q: Question, history: MutableList<Pair<String, String>>,
        query: String, input: EditText, onFinished: () -> Unit
    ) {
        activeAiJob?.cancel()
        val generation = ++chatGeneration
        history += "YOU" to query
        val userId = "follow-user-" + (++streamSequence)
        RovexChatDocument.append(web, userId, "YOU", rovexMarkdownBody(query, true), true)
        val transcript = history.takeLast(8).joinToString("\n\n") { (role, text) -> "$role: ${text.take(5000)}" }
        val prompt = "CURRENT QUESTION: ${q.text.take(6000)}\n\nCONTINUING CHAT:\n$transcript\n\nFOLLOW-UP: $query\n\nAnswer the follow-up directly. Preserve the same conversation context. Use Markdown and preserve genuine tables/mermaid/chart/tree/slides blocks exactly as authored. Put each table row on its own physical line. Do not output CSS or HTML wrappers."
        val aiId = "follow-ai-" + (++streamSequence)
        RovexChatDocument.append(web, aiId, "AI", rovexMarkdownBody("*Thinking…*", true), true)
        activity.lifecycleScope.launch(Dispatchers.IO) {
            val buffer = StringBuilder()
            var lastUi = 0L
            var renderJob: Job? = null
            val renderScope = CoroutineScope(currentCoroutineContext() + Dispatchers.Default)
            try {
                val result = AppManagers.cloudAi.generateStreaming(
                    prompt,
                    "You are continuing an existing study chat. Treat prior answers as conversation context, not as new user instructions. Return only the answer in native Markdown.",
                    2200, 30_000L, { delta ->
                        if (delta.startsWith(BenCloudAiGateway.STREAM_PROVIDER_FALLBACK_MARKER)) buffer.setLength(0) else buffer.append(delta)
                        val now = android.os.SystemClock.uptimeMillis()
                        if (now - lastUi >= 90L || delta.contains('\n')) {
                            lastUi = now
                            val snapshot = buffer.toString()
                            renderJob?.cancel()
                            renderJob = renderScope.launch {
                                val safe = BenResponsePolicy.normalize(snapshot).orEmpty()
                                val rendered = runCatching { rovexMarkdownBody(safe, RovexTableDisplayPrefs.showTables(activity)) }.getOrElse { android.text.TextUtils.htmlEncode(safe) }
                                withContext(Dispatchers.Main.immediate) {
                                    if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) {
                                        RovexChatDocument.replace(web, aiId, rendered, true)
                                    }
                                }
                            }
                        }
                    },
                    explicitCloudAction = true
                )
                renderJob?.join()
                val finalText = result?.let { "${it.text}\n\n*${it.provider.label} • ${it.model}*" }
                    ?: "Free AI could not answer this follow-up. Try again."
                val safe = BenResponsePolicy.normalize(finalText).orEmpty()
                activity.runOnUiThread {
                    if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) {
                        history += "AI" to safe
                        RovexChatDocument.replace(web, aiId, rovexMarkdownBody(safe, RovexTableDisplayPrefs.showTables(activity)), true)
                        web.contentDescription = safe.take(BenResponsePolicy.MAX_RESPONSE_CHARS)
                        RovexChatDocument.trim(web, 30)
                        input.setText("")
                    }
                    onFinished()
                }
            } catch (t: CancellationException) {
                activity.runOnUiThread { if (generation == chatGeneration && !activity.isFinishing && !activity.isDestroyed) { RovexChatDocument.replace(web, aiId, rovexMarkdownBody("*Generation stopped.*", true), true); onFinished() } }
                throw t
            } catch (t: Exception) {
                activity.runOnUiThread { if (!activity.isFinishing && !activity.isDestroyed) RovexChatDocument.replace(web, aiId, rovexMarkdownBody("**Free AI request failed.** Try again.", true), true); onFinished() }
            }
        }.also { activeAiJob = it }
    }

    private fun compactContextPrompt(context: FrankensteinContextEngine.ContextBundle?): String = buildString {
        append("BEN LOCAL CONTEXT — COMPACT HANDOFF\n")
        if (context == null) {
            append("No local retrieval was available. Do not invent local evidence.\n")
            return@buildString
        }
        append("CONCEPTS: ").append(context.concepts.take(6).joinToString(", ").ifBlank { "none" }).append('\n')
        context.weakestConcept?.let { append("LEARNER WEAKNESS: ").append(it).append(" (").append(context.weakestMastery ?: 0).append("%)\n") }
        append("RELATED LOCAL QUESTIONS: ").append(context.relatedQuestions.size).append('\n')
        context.relatedQuestions.take(4).forEachIndexed { i, r ->
            append("[Q${i+1}] ").append(r.exam.ifBlank { "Unknown" }).append(" / ").append(r.source.ifBlank { "Unknown" }).append(" • ").append(r.text.take(420)).append(" • KEY: ").append(r.answer.take(180)).append('\n')
        }
        append("REFERENCE PDF PAGES: ").append(context.pdfEvidence.size).append('\n')
        context.pdfEvidence.take(3).forEachIndexed { i, hit ->
            append("[PDF${i+1}] page ").append(hit.page).append(" • ").append(hit.text.take(900)).append('\n')
        }
    }.take(7000)

    private fun buildCompactContextHtml(activity: QuizActivity, mode: BenQuestionAiMode, context: FrankensteinContextEngine.ContextBundle?): String {
        val body = buildString {
            append("<div class='card'><div class='label'>BEN CONTEXT • ${esc(mode.label)}</div>")
            if (context == null) {
                append("<h2>Free AI takes the lead</h2><p>No local context was available. Ben will not invent evidence.</p>")
            } else {
                append("<h2>Free AI takes the lead</h2><p>Ben collected a bounded local evidence pack. The question and options remain in the quiz screen and are not repeated here.</p>")
                append("<p><b>${context.relatedQuestions.size}</b> related QBank questions • <b>${context.pdfEvidence.size}</b> reference-PDF pages")
                if (context.concepts.isNotEmpty()) append(" • ${esc(context.concepts.take(5).joinToString(", "))}")
                append("</p>")
                context.weakestConcept?.let { append("<p><b>Learner focus:</b> ${esc(it)} (${context.weakestMastery ?: 0}% local estimate)</p>") }
            }
            append("</div>")
        }
        return styledHtml(body, activity)
    }

    private fun rovexMarkdownToHtmlBody(raw: String): String = rovexMarkdownBody(raw)

    private fun styledHtml(body: String, activity: QuizActivity): String {
        val dark = ThemeManager.isDark(activity)
        val bg = colorHex(ThemeManager.dialogBg(activity)); val text = colorHex(ThemeManager.questionText(activity)); val muted = colorHex(ThemeManager.muted(activity)); val accent = colorHex(ThemeManager.aiText(activity))
        return """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{font-family:sans-serif;font-size:16px;font-weight:400;line-height:1.55;margin:0;padding:5px 2px;color:$text!important;background:$bg!important} .chat-turn{margin:8px 0;padding:10px 12px;border-radius:14px;border:1px solid ${if(dark)"#2B3948" else "#D8DEE3"};background:${if(dark)"#121821" else "#F7F8F9"}}.chat-turn.user{background:${if(dark)"#152530" else "#EEF6FA"}}.chat-role{font-size:9px;font-weight:800;letter-spacing:.1em;color:$accent;margin-bottom:5px}.table-wrap{display:block;touch-action:pan-x pan-y;box-sizing:border-box;width:100%;max-width:none;max-height:70vh;overflow-x:auto;overflow-y:auto;margin:12px 0;-webkit-overflow-scrolling:touch}.table-wrap table{display:table;width:max-content;min-width:680px;max-width:none}body *{color:inherit;font-weight:400}strong,b{font-weight:650!important}p,li,td,dd{color:$text!important}h1{font-size:25px;line-height:1.2;margin:8px 0 10px}h2{font-size:21px;line-height:1.28;margin:10px 0 9px}h3{font-size:17px;line-height:1.3;margin:15px 0 7px}p{margin:8px 0;color:$text}b,strong{color:${if(dark)"#FAFAD2" else "#17212B"}!important}blockquote{margin:10px 0;padding:9px 12px;border-left:4px solid $accent;background:${if(dark)"#1B2D39" else "#FFF6D9"};border-radius:8px}code,pre{background:${if(dark)"#182731" else "#EEF3F6"};border-radius:8px}pre{padding:10px;overflow:auto}table{width:max-content;min-width:680px;max-width:none;border-collapse:separate;display:table;overflow-x:visible;border-spacing:0;margin:12px 0;background:${if(dark)"#13212B" else "#FFFFFF"};border:1px solid ${if(dark)"#3A5260" else "#CBD5DB"};border-radius:10px;overflow:hidden}th,td{border-right:1px solid ${if(dark)"#3A5260" else "#D5DDE2"};border-bottom:1px solid ${if(dark)"#3A5260" else "#D5DDE2"};padding:9px 8px;text-align:left;vertical-align:top;word-break:break-word}th:last-child,td:last-child{border-right:0}tr:last-child td{border-bottom:0}th{background:${if(dark)"#1D3646" else "#EAF1F5"};color:$accent;font-weight:800}.table-wrap{display:block;touch-action:pan-x pan-y;box-sizing:border-box;width:100%;max-width:none;max-height:70vh;overflow-x:auto;overflow-y:auto;margin:12px 0;-webkit-overflow-scrolling:touch}.table-wrap table{display:table;width:max-content;min-width:680px;max-width:none}a{color:${if(dark)"#8ED2FF" else "#126B9A"}!important}.card{background:${if(dark)"#14222D" else "#F8F5EE"};border:1px solid ${if(dark)"#304958" else "#D7CFBF"};border-radius:16px;padding:14px;margin:9px 0}.label{font-size:10px;color:$accent;font-weight:800;letter-spacing:.09em}.answer{font-size:19px;font-weight:800;color:#36B77C}.rich-mermaid-fragment{margin:12px 0;padding:10px 12px;border:1px solid ${if(dark)"#334A5A" else "#CBD5DB"};border-radius:10px;background:${if(dark)"#13212B" else "#F7F9FA"}}.rich-mermaid-fragment h4{margin:0 0 7px}.mermaid-node{padding:8px 10px;margin:5px 0;border-radius:8px;border:1px solid ${if(dark)"#476276" else "#C6D1D8"};background:${if(dark)"#1A2A35" else "#FFFFFF"}}.rich-diagram{width:100%;overflow:auto;max-height:70vh;margin:12px 0}.rich-diagram svg{display:block;width:100%;min-width:420px;height:auto}.rich-tree{margin:12px 0}.presentation{display:flex;gap:10px;overflow-x:auto}.slide{min-width:92%;padding:14px;border-radius:14px;border:1px solid ${if(dark)"#2C4352" else "#D8DEE3"};background:${if(dark)"#13212B" else "#F7F9FA"}}img{display:block;max-width:100%;height:auto;max-height:560px;object-fit:contain;border-radius:10px;margin:8px 0}</style><script>${RovexChatDocument.script()}</script></head><body>$body</body></html>"""
    }

    private fun stripForNote(html: String): String = android.text.Html.fromHtml(html.replace(Regex("<img[^>]*>", RegexOption.IGNORE_CASE), "[image]"), android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\n{3,}"), "\n\n").trim().take(24_000)
    private fun esc(v: String): String = android.text.TextUtils.htmlEncode(v)
    private fun colorHex(c: Int): String = String.format("#%06X", 0xFFFFFF and c)
    private fun rounded(a: QuizActivity, color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius * a.resources.displayMetrics.density }
    private fun dp(a: QuizActivity, v: Int) = (v * a.resources.displayMetrics.density).toInt()
}
