package com.localqbank.library

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.android.gms.tasks.Tasks
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException

/**
 * Authentication boundary for Rovex Online. Google never receives Rovex study data; Firebase
 * Authentication supplies the stable user identity used by the Firestore security rules.
 */
object RovexOnlineAuth {
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()

    fun currentUser(): FirebaseUser? = auth.currentUser

    suspend fun signInWithGoogle(activity: Activity): Result<FirebaseUser> = try {
        val manager = CredentialManager.create(activity)
        val first = try {
            getCredential(manager, activity, filterAuthorized = true)
        } catch (_: NoCredentialException) {
            getCredential(manager, activity, filterAuthorized = false)
        }
        val credential = first.credential
        if (credential !is CustomCredential ||
            credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            error("Google sign-in returned an unsupported credential type")
        }
        val google = try {
            GoogleIdTokenCredential.createFrom(credential.data)
        } catch (e: GoogleIdTokenParsingException) {
            throw IllegalStateException("Google sign-in credential could not be decoded", e)
        }
        val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
        val user = withContext(Dispatchers.IO) {
            Tasks.await(auth.signInWithCredential(firebaseCredential), 30, TimeUnit.SECONDS).user
        } ?: error("Firebase signed in without a user")
        Result.success(user)
    } catch (e: CancellationException) {
        throw e
    } catch (t: Throwable) {
        Result.failure(t)
    }

    private suspend fun getCredential(
        manager: CredentialManager,
        activity: Activity,
        filterAuthorized: Boolean
    ) = manager.getCredential(
        activity,
        GetCredentialRequest.Builder()
            .addCredentialOption(
                GetGoogleIdOption.Builder()
                    .setServerClientId(activity.getString(R.string.default_web_client_id))
                    .setFilterByAuthorizedAccounts(filterAuthorized)
                    .setAutoSelectEnabled(filterAuthorized)
                    .build()
            )
            .build()
    )

    suspend fun signOut(activity: Activity) {
        auth.signOut()
        try {
            CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Firebase sign-out is already complete; Credential Manager state clearing is best-effort.
        }
    }

    fun normalizedName(raw: String?): String = RovexOnlineIdentity.normalizedName(raw)

    fun rovexId(uid: String): String = RovexOnlineIdentity.rovexId(uid)

}

data class RovexOnlineProfile(
    val uid: String,
    val displayName: String,
    val rovexId: String,
    val questionsSolved: Int,
    val correct: Int,
    val accuracyPercent: Int,
    val todaySolved: Int,
    val flashcardsReviewed: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val xp: Long,
    val updatedAtMillis: Long
)

data class RovexFriendRequest(
    val otherUid: String,
    val name: String,
    val rovexId: String,
    val status: String,
    val createdAtMillis: Long
)

/** Firestore data boundary. It contains no QBank content, answers, notes, PDFs or AI chats. */
class RovexOnlineRepository(private val context: Context) {
    private val app = context.applicationContext
    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()

    fun identityProfile(user: FirebaseUser): RovexOnlineProfile = RovexOnlineProfile(
        uid = user.uid,
        displayName = RovexOnlineAuth.normalizedName(user.displayName),
        rovexId = RovexOnlineAuth.rovexId(user.uid),
        questionsSolved = 0, correct = 0, accuracyPercent = 0, todaySolved = 0, flashcardsReviewed = 0,
        currentStreak = 0, longestStreak = 0, xp = 0L, updatedAtMillis = 0L
    )

    fun ensureIdentityProfile(user: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        val p = identityProfile(user)
        val data = mapOf(
            "uid" to p.uid,
            "displayName" to p.displayName,
            "rovexId" to p.rovexId,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val batch = db.batch()
        batch.set(db.collection("users").document(p.uid), data, SetOptions.merge())
        batch.set(db.collection("friendCodes").document(p.rovexId), mapOf("uid" to p.uid, "displayName" to p.displayName), SetOptions.merge())
        return batch.commit()
    }

    fun submitStudyEvent(user: FirebaseUser, event: StudyEventSpine.Event): com.google.android.gms.tasks.Task<Void> {
        val id = java.util.UUID.randomUUID().toString()
        val data = mutableMapOf<String, Any>(
            "uid" to user.uid,
            "type" to event.name,
            "source" to event.source,
            "clientTimestamp" to event.timestamp,
            "createdAt" to FieldValue.serverTimestamp()
        )
        event.stableKey?.let { data["stableKeyHash"] = RovexOnlineIdentity.stableKeyHash(it) }
        event.metadata["correct"]?.let { data["correct"] = it == "true" }
        return db.collection("studyEvents").document(user.uid).collection("events").document(id).set(data)
    }

    fun findUidByRovexId(code: String): com.google.android.gms.tasks.Task<com.google.firebase.firestore.DocumentSnapshot> =
        db.collection("friendCodes").document(code.trim().uppercase(Locale.US)).get()

    fun sendFriendRequest(targetUid: String, targetCode: String, requester: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        require(targetUid != requester.uid) { "You cannot add yourself." }
        val root = db.collection("friendRequests")
        val incoming = root.document(targetUid).collection("incoming").document(requester.uid)
        val outgoing = db.collection("friendRequestsBySender").document(requester.uid)
            .collection("outgoing").document(targetUid)
        return db.collection("users").document(requester.uid).collection("friends").document(targetUid).get()
            .continueWithTask { friendTask ->
                if (!friendTask.isSuccessful) throw (friendTask.exception ?: IllegalStateException("Could not check friendship"))
                if (friendTask.result.exists()) throw IllegalStateException("Already friends")
                incoming.get().continueWithTask { requestTask ->
                    if (!requestTask.isSuccessful) throw (requestTask.exception ?: IllegalStateException("Could not check friend request"))
                    val current = requestTask.result.getString("status")
                    if (current == "pending") throw IllegalStateException("Friend request already pending")
                    if (current == "accepted") throw IllegalStateException("Already friends")
                    val data = mapOf(
                        "requesterUid" to requester.uid,
                        "requesterName" to RovexOnlineAuth.normalizedName(requester.displayName),
                        "requesterCode" to RovexOnlineAuth.rovexId(requester.uid),
                        "targetUid" to targetUid,
                        "targetCode" to targetCode.trim().uppercase(Locale.US),
                        "status" to "pending",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                    val batch = db.batch()
                    batch.set(incoming, data, SetOptions.merge())
                    batch.set(outgoing, data, SetOptions.merge())
                    batch.commit()
                }
            }
    }

    fun incoming(user: FirebaseUser): com.google.android.gms.tasks.Task<com.google.firebase.firestore.QuerySnapshot> =
        db.collection("friendRequests").document(user.uid).collection("incoming")
            .whereEqualTo("status", "pending").get()

    fun outgoing(user: FirebaseUser): com.google.android.gms.tasks.Task<com.google.firebase.firestore.QuerySnapshot> =
        db.collection("friendRequestsBySender").document(user.uid).collection("outgoing").get()

    fun acceptRequest(requesterUid: String, user: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        val incoming = db.collection("friendRequests").document(user.uid).collection("incoming").document(requesterUid)
        val outgoing = db.collection("friendRequestsBySender").document(requesterUid).collection("outgoing").document(user.uid)
        val myFriend = db.collection("users").document(user.uid).collection("friends").document(requesterUid)
        val batch = db.batch()
        batch.set(myFriend, mapOf("uid" to requesterUid, "addedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
        batch.update(incoming, mapOf("status" to "accepted", "respondedAt" to FieldValue.serverTimestamp()))
        batch.update(outgoing, mapOf("status" to "accepted", "respondedAt" to FieldValue.serverTimestamp()))
        return batch.commit()
    }

    fun declineRequest(requesterUid: String, user: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        val incoming = db.collection("friendRequests").document(user.uid).collection("incoming").document(requesterUid)
        val outgoing = db.collection("friendRequestsBySender").document(requesterUid).collection("outgoing").document(user.uid)
        val batch = db.batch()
        batch.update(incoming, mapOf("status" to "declined", "respondedAt" to FieldValue.serverTimestamp()))
        batch.update(outgoing, mapOf("status" to "declined", "respondedAt" to FieldValue.serverTimestamp()))
        return batch.commit()
    }

    fun finalizeAcceptedOutgoing(user: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        return outgoing(user).continueWithTask { task ->
            if (!task.isSuccessful) throw (task.exception ?: IllegalStateException("Could not read friend requests"))
            val batch = db.batch()
            task.result.documents.filter { it.getString("status") == "accepted" }.forEach { doc ->
                val otherUid = doc.id
                val mine = db.collection("users").document(user.uid).collection("friends").document(otherUid)
                batch.set(mine, mapOf("uid" to otherUid, "addedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
            }
            batch.commit()
        }
    }

    fun friendUids(user: FirebaseUser): com.google.android.gms.tasks.Task<com.google.firebase.firestore.QuerySnapshot> =
        db.collection("users").document(user.uid).collection("friends").limit(50).get()

    fun flushPendingWrites(): com.google.android.gms.tasks.Task<Void> = db.waitForPendingWrites()

    fun profile(uid: String): com.google.android.gms.tasks.Task<com.google.firebase.firestore.DocumentSnapshot> =
        db.collection("users").document(uid).get()

    fun profileFromDocument(doc: com.google.firebase.firestore.DocumentSnapshot): RovexOnlineProfile? {
        if (!doc.exists()) return null
        return RovexOnlineProfile(
            uid = doc.id,
            displayName = doc.getString("displayName") ?: "Rovex Student",
            rovexId = doc.getString("rovexId") ?: "RVX-????-????",
            questionsSolved = (doc.getLong("questionsSolved") ?: 0L).toInt().coerceAtLeast(0),
            correct = (doc.getLong("correct") ?: 0L).toInt().coerceAtLeast(0),
            accuracyPercent = (doc.getLong("accuracyPercent") ?: 0L).toInt().coerceIn(0, 100),
            todaySolved = (doc.getLong("todaySolved") ?: 0L).toInt().coerceAtLeast(0),
            flashcardsReviewed = (doc.getLong("flashcardsReviewed") ?: 0L).toInt().coerceAtLeast(0),
            currentStreak = (doc.getLong("currentStreak") ?: 0L).toInt().coerceAtLeast(0),
            longestStreak = (doc.getLong("longestStreak") ?: 0L).toInt().coerceAtLeast(0),
            xp = (doc.getLong("xp") ?: 0L).coerceAtLeast(0L),
            updatedAtMillis = doc.getTimestamp("updatedAt")?.toDate()?.time ?: 0L
        )
    }

    fun removeFriend(otherUid: String, user: FirebaseUser): com.google.android.gms.tasks.Task<Void> =
        db.collection("users").document(user.uid).collection("friends").document(otherUid).delete()

    companion object {
        fun syncNow(context: Context) {
            val app = context.applicationContext
            if (FirebaseAuth.getInstance().currentUser == null) return
            val request = androidx.work.OneTimeWorkRequestBuilder<RovexOnlineSyncWorker>()
                .setConstraints(
                    androidx.work.Constraints.Builder()
                        .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                        .build()
                )
                .build()
            androidx.work.WorkManager.getInstance(app).enqueueUniqueWork(
                "rovex-online-sync", androidx.work.ExistingWorkPolicy.KEEP, request
            )
        }
    }
}


object RovexOnlineSyncCoordinator {
    private val installed = java.util.concurrent.atomic.AtomicBoolean(false)
    private val listener: (StudyEventSpine.Event) -> Unit = { event ->
        if (event.name == "quiz_completed" || event.name == "flashcard_reviewed") {
            val user = FirebaseAuth.getInstance().currentUser
            if (user != null) {
                // Firestore Android persistence queues this write while offline; when connectivity
                // returns the event reaches the server trigger without blocking study UI.
                runCatching { RovexOnlineRepository(RovexApplicationContextHolder.context).submitStudyEvent(user, event) }
            }
        }
    }

    fun install(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        StudyEventSpine.subscribe(listener)
    }
}

class RovexOnlineSyncWorker(
    appContext: Context,
    workerParams: androidx.work.WorkerParameters
) : androidx.work.CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): androidx.work.ListenableWorker.Result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val user = FirebaseAuth.getInstance().currentUser ?: return@withContext androidx.work.ListenableWorker.Result.success()
        try {
            val repo = RovexOnlineRepository(applicationContext)
            Tasks.await(repo.ensureIdentityProfile(user), 30, TimeUnit.SECONDS)
            androidx.work.ListenableWorker.Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ProductionCrashReporter.breadcrumb(applicationContext, "ONLINE_IDENTITY_SYNC_FAILED:${e.javaClass.simpleName}")
            if (runAttemptCount < 4) androidx.work.ListenableWorker.Result.retry()
            else androidx.work.ListenableWorker.Result.failure()
        }
    }
}
