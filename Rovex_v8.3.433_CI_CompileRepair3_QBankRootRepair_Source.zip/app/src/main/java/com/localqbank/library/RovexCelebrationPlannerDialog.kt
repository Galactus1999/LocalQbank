package com.localqbank.library

import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/**
 * Presentation-only Celebration Lab. Persistence and trigger policy remain in
 * RovexCelebrationPreferences; this class does not own quiz/study state.
 */
object RovexCelebrationPlannerDialog {
    fun show(activity: QuizActivity, previewTarget: View) {
        val plan = RovexCelebrationPreferences.load(activity)
        val dialog = Dialog(activity)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 18), dp(activity, 16), dp(activity, 18), dp(activity, 16))
            background = rounded(activity, ThemeManager.elevated(activity), 24f)
        }
        fun title(text: String, size: Float = 19f) = TextView(activity).apply {
            this.text = text
            textSize = size
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(activity))
        }
        fun subtitle(text: String) = TextView(activity).apply {
            this.text = text
            textSize = 11.5f
            setTextColor(ThemeManager.muted(activity))
            setPadding(0, dp(activity, 3), 0, dp(activity, 10))
        }
        fun section(text: String) = TextView(activity).apply {
            this.text = text
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.muted(activity))
            setPadding(0, dp(activity, 10), 0, dp(activity, 5))
        }
        fun plannerButton(text: String, selected: Boolean = false, click: () -> Unit) = TextView(activity).apply {
            this.text = text
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(if (selected) Color.WHITE else ThemeManager.text(activity))
            background = rounded(activity, if (selected) ThemeManager.accent(activity) else ThemeManager.panel(activity), 14f)
            setOnClickListener { click() }
        }

        root.addView(title("Celebration Lab"), LinearLayout.LayoutParams(-1, dp(activity, 28)))
        root.addView(subtitle("Choose exactly when Rovex celebrates your progress. This affects visual feedback only; answers and scoring are unchanged."))
        root.addView(section("QUESTION SET / MILESTONE"))

        val targetsInput = EditText(activity).apply {
            setText(plan.targets.joinToString(","))
            hint = "Example: 10,20,30,50,100"
            textSize = 13f
            setSingleLine(false)
            maxLines = 3
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(ThemeManager.text(activity))
            setHintTextColor(ThemeManager.muted(activity))
            setPadding(dp(activity, 12), dp(activity, 9), dp(activity, 12), dp(activity, 9))
            background = rounded(activity, ThemeManager.panel(activity), 14f)
        }
        root.addView(targetsInput, LinearLayout.LayoutParams(-1, dp(activity, 54)))

        val presets = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf(
            "EVERY 10" to (10..100 step 10).toList(),
            "EVERY 25" to listOf(25, 50, 75, 100),
            "HIGH-YIELD" to listOf(10, 20, 30, 50, 100)
        ).forEachIndexed { i, pair ->
            val b = plannerButton(pair.first) { targetsInput.setText(pair.second.joinToString(",")) }
            presets.addView(b, LinearLayout.LayoutParams(0, dp(activity, 38), 1f).apply { if (i > 0) setMargins(dp(activity, 5), 0, 0, 0) })
        }
        root.addView(presets, LinearLayout.LayoutParams(-1, dp(activity, 38)).apply { topMargin = dp(activity, 6) })

        root.addView(section("CELEBRATION STYLE"))
        val styleLabels = listOf(
            RovexCelebrationPreferences.STYLE_ROTATE to "ROTATE ALL 10",
            RovexCelebrationPreferences.STYLE_RANDOM to "RANDOM",
            RovexCelebrationPreferences.STYLE_FIXED to "PICK ONE"
        )
        var selectedStyle = plan.style
        val styleRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        fun refreshStyleButtons() {
            for (i in 0 until styleRow.childCount) {
                val v = styleRow.getChildAt(i) as TextView
                val selected = styleLabels[i].first == selectedStyle
                v.setTextColor(if (selected) Color.WHITE else ThemeManager.text(activity))
                v.background = rounded(activity, if (selected) ThemeManager.accent(activity) else ThemeManager.panel(activity), 14f)
            }
        }
        styleLabels.forEachIndexed { i, pair ->
            val b = plannerButton(pair.second, pair.first == selectedStyle) {
                selectedStyle = pair.first
                refreshStyleButtons()
            }
            styleRow.addView(b, LinearLayout.LayoutParams(0, dp(activity, 38), 1f).apply { if (i > 0) setMargins(dp(activity, 5), 0, 0, 0) })
        }
        root.addView(styleRow, LinearLayout.LayoutParams(-1, dp(activity, 38)))
        refreshStyleButtons()

        root.addView(section("FIXED STYLE (only used with PICK ONE)"))
        var fixedVariant = plan.fixedVariant
        val fixedLabel = TextView(activity).apply {
            text = "Style ${fixedVariant + 1} / 10"
            textSize = 11f
            setTextColor(ThemeManager.text(activity))
        }
        val fixedSeek = SeekBar(activity).apply {
            max = 9
            progress = fixedVariant
            progressTintList = ColorStateList.valueOf(ThemeManager.accent(activity))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        fixedVariant = p
                        fixedLabel.text = "Style ${p + 1} / 10"
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(fixedLabel, LinearLayout.LayoutParams(-1, dp(activity, 22)))
        root.addView(fixedSeek, LinearLayout.LayoutParams(-1, dp(activity, 30)))

        val sound = CheckBox(activity).apply {
            text = "Play milestone sound"
            textSize = 12f
            isChecked = plan.sound
            setTextColor(ThemeManager.text(activity))
            buttonTintList = ColorStateList.valueOf(ThemeManager.accent(activity))
        }
        root.addView(sound, LinearLayout.LayoutParams(-1, dp(activity, 42)))

        root.addView(TextView(activity).apply {
            text = "Preview is visual-only and never changes quiz progress. Custom counts are exact accepted-answer counts for this quiz session."
            textSize = 10.5f
            setTextColor(ThemeManager.muted(activity))
            setPadding(0, dp(activity, 2), 0, dp(activity, 8))
        }, LinearLayout.LayoutParams(-1, dp(activity, 36)))

        val buttons = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        val preview = plannerButton("PREVIEW") {
            val previewPlan = RovexCelebrationPreferences.Plan(style = selectedStyle, fixedVariant = fixedVariant)
            val celebration = (activity.findViewById<ViewGroup>(android.R.id.content)
                .findViewWithTag<RovexCelebrationView>("rovex_celebration_host")
                ?: RovexCelebrationHost.install(activity.findViewById(android.R.id.content)))
            celebration.post { celebration.celebrateAt(previewTarget, RovexCelebrationPreferences.variantFor(previewPlan, 0)) }
        }
        val cancel = plannerButton("CANCEL") { dialog.dismiss() }
        val save = plannerButton("SAVE PLAN") {
            val targets = RovexCelebrationPreferences.parseTargets(targetsInput.text?.toString())
            if (targets.isEmpty()) {
                targetsInput.error = "Enter at least one question number"
            } else {
                RovexCelebrationPreferences.save(activity, RovexCelebrationPreferences.Plan(targets, selectedStyle, fixedVariant, sound.isChecked))
                Toast.makeText(activity, "Celebration plan saved • ${targets.joinToString(", ")}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        listOf(preview, cancel, save).forEachIndexed { i, v ->
            buttons.addView(v, LinearLayout.LayoutParams(0, dp(activity, 42), 1f).apply { if (i > 0) setMargins(dp(activity, 6), 0, 0, 0) })
        }
        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(activity, 42)))

        dialog.setContentView(ScrollView(activity).apply {
            isFillViewport = true
            addView(root)
        })
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels * 0.94f).toInt().coerceAtMost(dp(activity, 460)), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun dp(activity: QuizActivity, value: Int): Int = (value * activity.resources.displayMetrics.density).toInt()
    private fun rounded(activity: QuizActivity, color: Int, radius: Float): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(activity, radius.toInt()).toFloat() }
}
