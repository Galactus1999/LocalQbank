package com.localqbank.library

import android.content.Context

/**
 * Small, UI-facing persistence policy for question milestone celebrations.
 * It intentionally owns only celebration preferences; it is not a study/business manager.
 */
object RovexCelebrationPreferences {
    private const val PREFS = "rovex_celebrations"
    private const val KEY_TARGETS = "targets"
    private const val KEY_STYLE = "style"
    private const val KEY_FIXED_VARIANT = "fixed_variant"
    private const val KEY_SOUND = "sound"

    const val STYLE_ROTATE = "rotate"
    const val STYLE_RANDOM = "random"
    const val STYLE_FIXED = "fixed"

    private val DEFAULT_TARGETS = (10..100 step 10).toList()

    data class Plan(
        val targets: List<Int> = DEFAULT_TARGETS,
        val style: String = STYLE_ROTATE,
        val fixedVariant: Int = 0,
        val sound: Boolean = true
    )

    fun load(context: Context): Plan {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Plan(
            targets = parseTargets(p.getString(KEY_TARGETS, null)),
            style = p.getString(KEY_STYLE, STYLE_ROTATE).orEmpty().takeIf { it in setOf(STYLE_ROTATE, STYLE_RANDOM, STYLE_FIXED) } ?: STYLE_ROTATE,
            fixedVariant = p.getInt(KEY_FIXED_VARIANT, 0).coerceIn(0, 9),
            sound = p.getBoolean(KEY_SOUND, true)
        )
    }

    fun save(context: Context, plan: Plan) {
        val normalized = plan.copy(
            targets = normalizeTargets(plan.targets),
            style = plan.style.takeIf { it in setOf(STYLE_ROTATE, STYLE_RANDOM, STYLE_FIXED) } ?: STYLE_ROTATE,
            fixedVariant = plan.fixedVariant.coerceIn(0, 9)
        )
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TARGETS, normalized.targets.joinToString(","))
            .putString(KEY_STYLE, normalized.style)
            .putInt(KEY_FIXED_VARIANT, normalized.fixedVariant)
            .putBoolean(KEY_SOUND, normalized.sound)
            .apply()
    }

    fun parseTargets(raw: String?): List<Int> {
        if (raw.isNullOrBlank()) return DEFAULT_TARGETS
        return normalizeTargets(raw.split(',', ';', ' ', '\n', '\t').mapNotNull { it.toIntOrNull() })
            .ifEmpty { DEFAULT_TARGETS }
    }

    fun normalizeTargets(values: Collection<Int>): List<Int> = values
        .filter { it in 1..100_000 }
        .distinct()
        .sorted()

    fun shouldCelebrate(answeredCount: Int, targets: List<Int>): Boolean = answeredCount > 0 && answeredCount in targets

    fun variantFor(plan: Plan, celebrationIndex: Int): Int = when (plan.style) {
        STYLE_RANDOM -> kotlin.random.Random.nextInt(0, 10)
        STYLE_FIXED -> plan.fixedVariant.coerceIn(0, 9)
        else -> celebrationIndex.mod(10)
    }
}
