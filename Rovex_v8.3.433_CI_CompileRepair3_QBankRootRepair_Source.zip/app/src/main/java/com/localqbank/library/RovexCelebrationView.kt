package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Short, non-blocking milestone celebration.
 *
 * The renderer deliberately keeps the effect procedural and bounded: no bitmaps, no coroutines,
 * no allocations per particle frame. Ten visual variants are available so repeated 10-question
 * milestones do not look identical.
 */
class RovexCelebrationView(context: Context) : View(context) {
    private data class Particle(val angle: Float, val distance: Float, val size: Float, val delay: Float, val phase: Float)
    private val particles = List(32) { i ->
        val r = Random(0x524F5645 + i)
        Particle(
            r.nextFloat() * (Math.PI.toFloat() * 2f),
            0.38f + r.nextFloat() * 0.62f,
            1.4f + r.nextFloat() * 2.6f,
            r.nextFloat() * 0.22f,
            r.nextFloat()
        )
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var progress = 1f
    private var running = false
    private var startMs = 0L
    private var centerX = Float.NaN
    private var centerY = Float.NaN
    private var variant = 0

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            progress = ((android.os.SystemClock.uptimeMillis() - startMs) / DURATION_MS.toFloat()).coerceIn(0f, 1f)
            invalidate()
            if (progress < 1f) postOnAnimation(this) else {
                running = false
                visibility = GONE
            }
        }
    }

    init {
        isClickable = false
        isFocusable = false
        visibility = GONE
    }

    fun celebrate(variant: Int = 0) {
        if (!isAttachedToWindow || width <= 0 || height <= 0) return
        centerX = Float.NaN
        centerY = Float.NaN
        start(variant)
    }

    fun celebrateAt(target: View, variant: Int = 0) {
        if (!isAttachedToWindow || width <= 0 || height <= 0) return
        val targetLocation = IntArray(2)
        val rootLocation = IntArray(2)
        target.getLocationOnScreen(targetLocation)
        getLocationOnScreen(rootLocation)
        centerX = targetLocation[0] - rootLocation[0] + target.width * 0.5f
        centerY = targetLocation[1] - rootLocation[1] + target.height * 0.5f
        start(variant)
    }

    private fun start(requestedVariant: Int) {
        variant = requestedVariant.mod(VARIANT_COUNT)
        running = true
        visibility = VISIBLE
        progress = 0f
        startMs = android.os.SystemClock.uptimeMillis()
        removeCallbacks(tick)
        postOnAnimation(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!running) return
        val d = resources.displayMetrics.density
        val cx = if (centerX.isNaN()) width * 0.5f else centerX
        val cy = if (centerY.isNaN()) height * 0.5f else centerY
        val maxR = minOf(width, height) * 0.44f
        val eased = 1f - (1f - progress) * (1f - progress)

        when (variant) {
            0 -> drawBurst(canvas, cx, cy, maxR, d, eased)
            1 -> drawRings(canvas, cx, cy, maxR, d)
            2 -> drawConfetti(canvas, cx, cy, maxR, d)
            3 -> drawStarburst(canvas, cx, cy, maxR, d)
            4 -> drawSpiral(canvas, cx, cy, maxR, d)
            5 -> drawFountain(canvas, cx, cy, maxR, d)
            6 -> drawPulse(canvas, cx, cy, maxR, d)
            7 -> drawMeteors(canvas, cx, cy, maxR, d)
            8 -> drawOrbit(canvas, cx, cy, maxR, d)
            else -> drawRadial(canvas, cx, cy, maxR, d)
        }
    }

    private fun drawBurst(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float, eased: Float) {
        particles.forEach { p ->
            val local = ((progress - p.delay) / (1f - p.delay)).coerceIn(0f, 1f)
            val r = maxR * p.distance * (1f - (1f - local) * (1f - local))
            val x = cx + cos(p.angle) * r
            val y = cy + sin(p.angle) * r * 0.78f
            setGlow(alpha = 210f * (1f - local), size = p.size * d * (0.6f + 0.7f * eased), color = COLOR_GOLD)
            canvas.drawCircle(x, y, p.size * d * (0.6f + 0.7f * eased), paint)
            paint.clearShadowLayer()
        }
    }

    private fun drawRings(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.4f * d
        repeat(4) { i ->
            val local = ((progress * 1.18f - i * 0.16f).coerceIn(0f, 1f))
            val r = maxR * (0.15f + 0.72f * local)
            paint.alpha = (170f * (1f - local)).toInt().coerceIn(0, 170)
            paint.color = if (i % 2 == 0) COLOR_CYAN else COLOR_GOLD
            canvas.drawCircle(cx, cy, r, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawConfetti(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        particles.forEachIndexed { i, p ->
            val local = ((progress - p.delay) / (1f - p.delay)).coerceIn(0f, 1f)
            val r = maxR * p.distance * local
            val x = cx + cos(p.angle) * r
            val y = cy + sin(p.angle) * r + local * local * maxR * 0.18f
            paint.color = if (i % 3 == 0) COLOR_GOLD else if (i % 3 == 1) COLOR_CYAN else COLOR_PINK
            paint.alpha = (220f * (1f - local)).toInt().coerceIn(0, 220)
            val s = (2.5f + p.size * d) * (1f - 0.25f * local)
            canvas.save()
            canvas.rotate((p.phase * 720f + progress * 420f) % 360f, x, y)
            canvas.drawRect(x - s, y - s * 0.45f, x + s, y + s * 0.45f, paint)
            canvas.restore()
        }
    }

    private fun drawStarburst(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * d
        val rays = 16
        repeat(rays) { i ->
            val angle = (Math.PI * 2.0 * i / rays).toFloat()
            val local = (progress * 1.25f - (i % 4) * 0.05f).coerceIn(0f, 1f)
            val r0 = maxR * 0.12f
            val r1 = maxR * (0.2f + 0.72f * local)
            paint.color = if (i % 2 == 0) COLOR_CYAN else COLOR_GOLD
            paint.alpha = (210f * (1f - local)).toInt().coerceIn(0, 210)
            canvas.drawLine(cx + cos(angle) * r0, cy + sin(angle) * r0, cx + cos(angle) * r1, cy + sin(angle) * r1, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawSpiral(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        particles.forEachIndexed { i, p ->
            val local = ((progress * 1.1f + i * 0.012f) % 1f)
            val angle = p.angle + progress * 5.5f + i * 0.07f
            val r = maxR * (0.08f + 0.72f * local)
            val x = cx + cos(angle) * r
            val y = cy + sin(angle) * r * 0.72f
            paint.color = if (i % 2 == 0) COLOR_GOLD else COLOR_CYAN
            paint.alpha = (190f * (1f - progress)).toInt().coerceIn(0, 190)
            canvas.drawCircle(x, y, (1.5f + p.size) * d, paint)
        }
    }

    private fun drawFountain(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        particles.forEachIndexed { i, p ->
            val local = ((progress - p.delay) / (1f - p.delay)).coerceIn(0f, 1f)
            val spread = (i / particles.size.toFloat() - 0.5f) * 2f
            val x = cx + spread * maxR * 0.72f * local
            val y = cy - maxR * (1.15f * local - 1.1f * local * local)
            paint.color = if (i % 2 == 0) COLOR_CYAN else COLOR_GOLD
            paint.alpha = (210f * (1f - local)).toInt().coerceIn(0, 210)
            canvas.drawCircle(x, y, (1.6f + p.size * 0.65f) * d, paint)
        }
    }

    private fun drawPulse(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        val wave = (progress * 3f).coerceIn(0f, 3f)
        repeat(3) { i ->
            val local = (wave - i).coerceIn(0f, 1f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = (3f - local * 2f) * d
            paint.color = if (i % 2 == 0) COLOR_GOLD else COLOR_CYAN
            paint.alpha = (190f * (1f - local)).toInt().coerceIn(0, 190)
            canvas.drawCircle(cx, cy, maxR * (0.1f + 0.7f * local), paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawMeteors(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        particles.forEachIndexed { i, p ->
            val local = ((progress * 1.2f + p.phase * 0.25f) % 1f)
            val angle = p.angle
            val r = maxR * (1.0f - local)
            val x = cx + cos(angle) * r
            val y = cy + sin(angle) * r * 0.72f
            val tail = maxR * 0.16f
            paint.strokeWidth = (1.5f + p.size) * d
            paint.color = if (i % 2 == 0) COLOR_PINK else COLOR_GOLD
            paint.alpha = (210f * (1f - local)).toInt().coerceIn(0, 210)
            canvas.drawLine(x, y, x - cos(angle) * tail, y - sin(angle) * tail, paint)
            canvas.drawCircle(x, y, (1.5f + p.size * 0.5f) * d, paint)
        }
    }

    private fun drawOrbit(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.8f * d
        paint.color = COLOR_CYAN
        paint.alpha = 120
        canvas.drawOval(cx - maxR * 0.72f, cy - maxR * 0.25f, cx + maxR * 0.72f, cy + maxR * 0.25f, paint)
        paint.color = COLOR_GOLD
        paint.alpha = 180
        particles.take(12).forEachIndexed { i, p ->
            val angle = p.angle + progress * 7f + i * 0.03f
            val x = cx + cos(angle) * maxR * 0.72f
            val y = cy + sin(angle) * maxR * 0.25f
            canvas.drawCircle(x, y, (2f + p.size * 0.55f) * d, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawRadial(canvas: Canvas, cx: Float, cy: Float, maxR: Float, d: Float) {
        val rotation = progress * 2.2f
        repeat(24) { i ->
            val angle = (Math.PI * 2.0 * i / 24.0).toFloat() + rotation
            val wave = 0.25f + 0.68f * ((progress * 1.15f + i * 0.021f) % 1f)
            val r = maxR * wave
            paint.color = if (i % 3 == 0) COLOR_GOLD else if (i % 3 == 1) COLOR_CYAN else COLOR_PINK
            paint.alpha = (210f * (1f - progress)).toInt().coerceIn(0, 210)
            paint.strokeWidth = (1.5f + d) 
            canvas.drawLine(cx + cos(angle) * r * 0.82f, cy + sin(angle) * r * 0.82f, cx + cos(angle) * r, cy + sin(angle) * r, paint)
        }
    }

    private fun setGlow(alpha: Float, size: Float, color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = alpha.toInt().coerceIn(0, 255)
        paint.setShadowLayer(7f * resources.displayMetrics.density * (alpha / 210f), 0f, 0f, color)
    }

    companion object {
        private const val DURATION_MS = 1150L
        private const val VARIANT_COUNT = 10
        private const val COLOR_GOLD = 0xFFFFB238.toInt()
        private const val COLOR_CYAN = 0xFF4CC9F0.toInt()
        private const val COLOR_PINK = 0xFFFF6FB5.toInt()
    }
}

/** Installs a reusable celebration overlay over any Activity content root. */
object RovexCelebrationHost {
    private const val TAG = "rovex_celebration_host"
    fun install(root: ViewGroup): RovexCelebrationView {
        (root.findViewWithTag<RovexCelebrationView>(TAG))?.let { return it }
        val v = RovexCelebrationView(root.context).apply { tag = TAG }
        root.addView(v, ViewGroup.LayoutParams(-1, -1))
        return v
    }
}
