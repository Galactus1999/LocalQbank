package com.localqbank.library

import java.security.MessageDigest
import java.util.Locale

/** Pure, deterministic online identity helpers. No Android/Firebase dependency. */
object RovexOnlineIdentity {
    fun normalizedName(raw: String?): String {
        val value = raw.orEmpty().trim().replace(Regex("\\s+"), " ")
        return value.take(40).ifBlank { "Rovex Student" }
    }

    fun stableKeyHash(stableKey: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(stableKey.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.take(24)
    }

    fun rovexId(uid: String): String {
        require(uid.isNotBlank()) { "Firebase UID must not be blank" }
        val digest = MessageDigest.getInstance("SHA-256").digest(uid.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }
        return "RVX-${hex.substring(0, 4).uppercase(Locale.US)}-${hex.substring(4, 8).uppercase(Locale.US)}"
    }
}
