package com.localqbank.library

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

/**
 * Presentation layer for Rovex Online. It owns no online state: Firebase/Auth/Firestore remain
 * behind RovexOnlineAuth and RovexOnlineRepository.
 */
class RovexOnlineActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var content: LinearLayout
    private val repo by lazy { RovexOnlineRepository(this) }
    private val auth get() = FirebaseAuth.getInstance()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SystemUi.immersive(this)
        buildShell()
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) render()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            background = ThemeManager.backgroundDrawable(this@RovexOnlineActivity)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this@RovexOnlineActivity).apply {
            text = "←"; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RovexOnlineActivity))
            background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 16)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(50), dp(50)))
        header.addView(TextView(this@RovexOnlineActivity).apply {
            text = "Rovex Online"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setPadding(dp(13), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        status = TextView(this@RovexOnlineActivity).apply {
            textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)); setPadding(dp(3), dp(8), dp(3), dp(8))
        }
        root.addView(status)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        AdaptiveTypographyManager.apply(root)
    }

    private fun render() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val user = auth.currentUser
        if (user == null) renderSignedOut() else renderSignedIn(user)
    }

    private suspend fun <T> onlineResult(block: suspend () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (t: Throwable) {
        Result.failure(t)
    }

    private fun renderSignedOut() {
        status.text = "Offline-first. Online features are optional."
        card("FRIENDS • PROGRESS • CHALLENGES") {
            add(TextView(this@RovexOnlineActivity).apply {
                text = "Connect Rovex to your Google account to create a private friend identity and sync competitive progress. QBank content, notes, PDFs and AI chats stay local."
                textSize = 12.5f; setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setPadding(0, 0, 0, dp(14))
            })
            add(action("CONTINUE WITH GOOGLE", ThemeManager.accent(this@RovexOnlineActivity)) {
                lifecycleScope.launch {
                    status.text = "Opening Google sign-in…"
                    val result = RovexOnlineAuth.signInWithGoogle(this@RovexOnlineActivity)
                    result.onSuccess { signedIn ->
                        status.text = "Signed in as ${RovexOnlineAuth.normalizedName(signedIn.displayName)}"
                        syncAndRender(signedIn)
                    }.onFailure { e ->
                        status.text = "Google sign-in failed: ${friendlyError(e)}"
                    }
                }
            })
        }
        card("WHAT GOES ONLINE") {
            add(TextView(this@RovexOnlineActivity).apply {
                text = "✓ profile name + Rovex ID\n✓ questions solved / correct / accuracy\n✓ study streak\n✓ XP and friend relationships\n\n✕ question text / answers\n✕ imported QBanks / APKGs\n✕ notes / PDFs\n✕ Ben / AI conversations"
                textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)); setLineSpacing(0f, 1.15f)
            })
        }
    }

    private fun renderSignedIn(user: FirebaseUser) {
        status.text = "Connected • ${user.email.orEmpty()}"
        val code = RovexOnlineAuth.rovexId(user.uid)
        card("YOUR ROVEX ID") {
            add(TextView(this@RovexOnlineActivity).apply {
                text = code; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.accent(this@RovexOnlineActivity)); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8))
            })
            add(TextView(this@RovexOnlineActivity).apply {
                text = "Share this code with friends. It does not expose your email address.\nCompetitive counters are calculated by the online backend from study events."
                textSize = 11f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)); gravity = Gravity.CENTER
            })
            add(action("SYNC MY PROGRESS", ThemeManager.accent(this@RovexOnlineActivity)) { syncAndRender(user) })
            add(action("SIGN OUT", ThemeManager.muted(this@RovexOnlineActivity)) {
                lifecycleScope.launch { RovexOnlineAuth.signOut(this@RovexOnlineActivity); render() }
            })
        }
        card("YOUR PROGRESS") {
            add(TextView(this@RovexOnlineActivity).apply { text = "Loading synced progress…"; textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) })
        }
        lifecycleScope.launch { loadOwnProgress(user) }
        card("ADD A FRIEND") {
            val input = EditText(this@RovexOnlineActivity).apply {
                hint = "RVX-ABCD-1234"; textSize = 14f; setSingleLine(true)
                setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setHintTextColor(ThemeManager.muted(this@RovexOnlineActivity))
                background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 14)
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            add(input, LinearLayout.LayoutParams(-1, dp(52)))
            add(action("SEND FRIEND REQUEST", ThemeManager.accent(this@RovexOnlineActivity)) {
                sendFriendRequest(input.text.toString())
            })
        }
        loadSocial(user)
    }

    private suspend fun loadOwnProgress(user: FirebaseUser) {
        val profile = withContext(Dispatchers.IO) {
            onlineResult {
                Tasks.await(repo.profile(user.uid), 20, TimeUnit.SECONDS).let { repo.profileFromDocument(it) }
            }.getOrNull()
        } ?: return
        if (auth.currentUser?.uid != user.uid) return
        var index = -1
        for (i in 0 until content.childCount) {
            val child = content.getChildAt(i)
            if (child is LinearLayout && (child.getChildAt(0) as? TextView)?.text?.toString() == "YOUR PROGRESS") {
                index = i
                break
            }
        }
        if (index < 0) return
        val box = content.getChildAt(index) as? LinearLayout ?: return
        if (box.childCount > 1) box.removeViews(1, box.childCount - 1)
        box.addView(progressText(profile), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
    }

    private fun loadSocial(user: FirebaseUser) {
        lifecycleScope.launch {
            val social = withContext(Dispatchers.IO) {
                onlineResult {
                    val incoming = Tasks.await(repo.incoming(user), 20, TimeUnit.SECONDS).documents.map {
                        RovexFriendRequest(
                            it.id,
                            it.getString("requesterName") ?: "Rovex Student",
                            it.getString("requesterCode") ?: "RVX-????-????",
                            it.getString("status") ?: "pending",
                            it.getTimestamp("createdAt")?.toDate()?.time ?: 0L
                        )
                    }
                    Tasks.await(repo.finalizeAcceptedOutgoing(user), 20, TimeUnit.SECONDS)
                    val friendDocs = Tasks.await(repo.friendUids(user), 20, TimeUnit.SECONDS).documents
                    val profiles = friendDocs.mapNotNull { doc ->
                        val uid = doc.getString("uid") ?: doc.id
                        runCatching { repo.profileFromDocument(Tasks.await(repo.profile(uid), 20, TimeUnit.SECONDS)) }.getOrNull()
                    }
                    Triple(incoming, profiles, null as String?)
                }.getOrElse { Triple(emptyList(), emptyList(), friendlyError(it)) }
            }
            if (social.third != null) {
                addMessage("Social data unavailable", social.third!!)
                return@launch
            }
            if (social.first.isNotEmpty()) {
                card("FRIEND REQUESTS") {
                    social.first.forEach { request ->
                        val row = LinearLayout(this@RovexOnlineActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(5), 0, dp(8)) }
                        row.addView(TextView(this@RovexOnlineActivity).apply {
                            text = "${request.name} • ${request.rovexId}"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexOnlineActivity))
                        })
                        row.addView(action("ACCEPT", ThemeManager.accent(this@RovexOnlineActivity)) { accept(request.otherUid) })
                        row.addView(action("DECLINE", ThemeManager.muted(this@RovexOnlineActivity)) { decline(request.otherUid) })
                        content.addView(row)
                    }
                }
            }
            card("FRIENDS ARENA") {
                if (social.second.isEmpty()) {
                    add(TextView(this@RovexOnlineActivity).apply { text = "No friends yet. Add a Rovex ID above to start your private leaderboard."; textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) })
                } else {
                    social.second.sortedWith(compareByDescending<RovexOnlineProfile> { it.xp }.thenByDescending { it.questionsSolved }).forEachIndexed { index, p ->
                        add(friendRow(index + 1, p))
                    }
                }
            }
        }
    }

    private fun sendFriendRequest(raw: String) {
        val code = raw.trim().uppercase()
        if (!Regex("RVX-[A-Z0-9]{4}-[A-Z0-9]{4}").matches(code)) { toast("Enter a valid Rovex ID, e.g. RVX-ABCD-1234"); return }
        val user = auth.currentUser ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { onlineResult {
                val target = Tasks.await(repo.findUidByRovexId(code), 15, TimeUnit.SECONDS)
                val uid = target.getString("uid") ?: error("Rovex ID not found")
                Tasks.await(repo.sendFriendRequest(uid, code, user), 20, TimeUnit.SECONDS)
            }}
            result.onSuccess { toast("Friend request sent"); render() }.onFailure { toast(friendlyError(it)) }
        }
    }

    private fun accept(uid: String) {
        val user = auth.currentUser ?: return
        lifecycleScope.launch {
            onlineResult { withContext(Dispatchers.IO) { Tasks.await(repo.acceptRequest(uid, user), 20, TimeUnit.SECONDS) } }
                .onSuccess { toast("Friend added"); render() }
                .onFailure { toast(friendlyError(it)) }
        }
    }

    private fun decline(uid: String) {
        val user = auth.currentUser ?: return
        lifecycleScope.launch {
            onlineResult { withContext(Dispatchers.IO) { Tasks.await(repo.declineRequest(uid, user), 20, TimeUnit.SECONDS) } }
                .onSuccess { toast("Request declined"); render() }
                .onFailure { toast(friendlyError(it)) }
        }
    }

    private fun syncAndRender(user: FirebaseUser) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { onlineResult {
                Tasks.await(repo.ensureIdentityProfile(user), 30, TimeUnit.SECONDS)
                Tasks.await(repo.flushPendingWrites(), 30, TimeUnit.SECONDS)
            } }
            result.onSuccess { RovexOnlineRepository.syncNow(this@RovexOnlineActivity); render() }
                .onFailure { toast("Progress sync failed: ${friendlyError(it)}") }
        }
    }

    private fun progressText(p: RovexOnlineProfile): TextView = TextView(this@RovexOnlineActivity).apply {
        text = "${p.questionsSolved} questions solved\n${p.correct} correct • ${p.accuracyPercent}% accuracy\n${p.todaySolved} solved today\n${p.flashcardsReviewed} flashcards reviewed\n⚡ ${p.xp} XP"
        textSize = 12f; setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setLineSpacing(0f, 1.15f)
    }

    private fun friendRow(rank: Int, p: RovexOnlineProfile): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 15)
        addView(TextView(this@RovexOnlineActivity).apply { text = "#$rank"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(this@RovexOnlineActivity)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(42), -1))
        val copy = LinearLayout(this@RovexOnlineActivity).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(TextView(this@RovexOnlineActivity).apply { text = p.displayName; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexOnlineActivity)) })
        copy.addView(TextView(this@RovexOnlineActivity).apply { text = "${p.xp} XP • ${p.questionsSolved} solved • ${p.accuracyPercent}% • ${p.flashcardsReviewed} cards"; textSize = 10.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) })
        addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun card(title: String, block: CardScope.() -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 18) }
        box.addView(TextView(this@RovexOnlineActivity).apply { text = title; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(this@RovexOnlineActivity)); setPadding(0, 0, 0, dp(9)) })
        CardScope(box).apply(block)
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private inner class CardScope(private val box: LinearLayout) {
        fun add(v: android.view.View) {
            box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }

        fun add(v: android.view.View, params: LinearLayout.LayoutParams) {
            if (params.topMargin == 0) params.topMargin = dp(5)
            box.addView(v, params)
        }
    }

    private fun action(label: String, tint: Int, click: () -> Unit) = TextView(this@RovexOnlineActivity).apply {
        text = label; textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(tint)
        background = rounded(ThemeManager.panel(this@RovexOnlineActivity), 13); setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { click() }
    }

    private fun addMessage(title: String, message: String) {
        card(title) { add(TextView(this@RovexOnlineActivity).apply { text = message; textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) }) }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun friendlyError(t: Throwable): String {
        val e = t.cause ?: t
        val message = e.message.orEmpty()
        return when {
            message.contains("PERMISSION_DENIED", true) -> "Online access is not configured for this account yet."
            message.contains("NOT_FOUND", true) -> "Rovex ID not found."
            message.contains("DEADLINE_EXCEEDED", true) -> "Network timed out. Try again."
            message.isBlank() -> e.javaClass.simpleName
            else -> message.take(180)
        }
    }
}
