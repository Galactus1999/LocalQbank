package com.localqbank.library

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Repairs the optional FTS index only while Android considers the device idle.
 * QBank truth lives in normalized tables, so interactive search never waits for this worker.
 */
class QBankSearchIndexMaintenanceWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val ready = QBankDb(applicationContext).repairSearchIndexForMaintenance()
            if (ready) Result.success() else Result.retry()
        } catch (t: CancellationException) {
            throw t
        } catch (t: Throwable) {
            ProductionCrashReporter.recordNonFatal(t, "QBANK_SEARCH_INDEX_MAINTENANCE")
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE_WORK = "rovex_qbank_search_index_maintenance"

        fun enqueue(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiresDeviceIdle(true)
                .setRequiresBatteryNotLow(true)
                .build()
            val request = OneTimeWorkRequestBuilder<QBankSearchIndexMaintenanceWorker>()
                .setConstraints(constraints)
                .setInitialDelay(30, TimeUnit.SECONDS)
                .addTag(UNIQUE_WORK)
                .build()
            WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                UNIQUE_WORK, ExistingWorkPolicy.KEEP, request
            )
        }
    }
}
