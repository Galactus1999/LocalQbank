package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexOnlineIdentityTest {
    @Test fun codeIsDeterministicAndSafeToShare() {
        val a = RovexOnlineIdentity.rovexId("firebase-user-123")
        val b = RovexOnlineIdentity.rovexId("firebase-user-123")
        assertEquals(a, b)
        assertTrue(Regex("RVX-[A-Z0-9]{4}-[A-Z0-9]{4}").matches(a))
        assertNotEquals(a, RovexOnlineIdentity.rovexId("firebase-user-456"))
        assertTrue(RovexOnlineIdentity.stableKeyHash("question-123").matches(Regex("[0-9a-f]{24}")))
    }

    @Test fun displayNameIsBoundedAndNormalized() {
        assertEquals("Rohit Kokane", RovexOnlineIdentity.normalizedName("  Rohit   Kokane  "))
        assertEquals("Rovex Student", RovexOnlineIdentity.normalizedName("   "))
        assertTrue(RovexOnlineIdentity.normalizedName("x".repeat(100)).length <= 40)
    }
}
