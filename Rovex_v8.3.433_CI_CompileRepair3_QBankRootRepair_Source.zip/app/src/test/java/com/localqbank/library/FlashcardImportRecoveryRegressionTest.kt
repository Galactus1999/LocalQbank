package com.localqbank.library

import org.junit.Assert.assertTrue
import org.junit.Test

class FlashcardImportRecoveryRegressionTest {
    @Test
    fun modernAnkiHierarchyDelimiterNormalizesToRovexTree() {
        val raw = "CoreBTR\u001fGeneral Physiology\u001fPyqs"
        val normalized = raw.replace("\u001f", "::").replace("\u001e", "::")
        assertTrue(normalized == "CoreBTR::General Physiology::Pyqs")
    }

    @Test
    fun markdownExplanationProducesBoldHtml() {
        val html = rovexMarkdownBody("This is **schizophrenia** and **clozapine**.")
        assertTrue(html.contains("<strong>schizophrenia</strong>"))
        assertTrue(html.contains("<strong>clozapine</strong>"))
    }

    @Test
    fun importedHtmlMarkupRemainsMarkupInsteadOfVisibleSource() {
        val html = rovexMarkdownBody("<p><strong>Correct answer:</strong> D. Rufinamide</p><p>14<sup>th</sup> edition</p>")
        assertTrue(html.contains("<strong>Correct answer:</strong>"))
        assertTrue(html.contains("<sup>th</sup>"))
        assertTrue(!html.contains("&lt;p&gt;"))
    }

    @Test
    fun freshApkgStageIsNotMistakenForResume() {
        assertTrue(!isApkgResumeCheckpoint("STAGED", 0))
        assertTrue(!isApkgResumeCheckpoint("VALIDATED", 0))
        assertTrue(isApkgResumeCheckpoint("CHECKPOINT", 200))
        assertTrue(isApkgResumeCheckpoint("IMPORTING", 0))
    }
}
