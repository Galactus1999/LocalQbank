package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexMarkdownTableRecoveryTest {
    @Test fun screenshotShapedWrappedHeaderDelimiterAndBodyAreRecovered() {
        val input = """3. Clinical Presentation | Symptom | Typical Finding |
| Diagnostic Tool | --------- | ----------------- |
| ----------------- | Persistent cough | Mass on chest X-ray | | CXR | Hemoptysis | Bronchial wall thickening | | CT-bronchography | Dyspnea | Mediastinal shift | | Chest CT | Weight loss, night sweats | Lymphadenopathy | | PET-CT | Chest pain | Pleural effusion | | Ultrasound, thoracentesis | > Image interpretation: In Q1 and Q2, a 60-year-old with lung cancer presents with JVP elevation."""
        val recovered = RovexMarkdownTableRecovery.recover(input)
        assertTrue(recovered.contains("| Symptom | Typical Finding | Diagnostic Tool |"))
        assertTrue(recovered.contains("| Persistent cough | Mass on chest X-ray | CXR |"))
        assertTrue(recovered.contains("| Hemoptysis | Bronchial wall thickening | CT-bronchography |"))
        assertTrue(recovered.contains("| Dyspnea | Mediastinal shift | Chest CT |"))
        assertTrue(recovered.contains("| Weight loss, night sweats | Lymphadenopathy | PET-CT |"))
        assertTrue(recovered.contains("| Chest pain | Pleural effusion | Ultrasound, thoracentesis |"))
        assertTrue(recovered.contains("> Image interpretation:"))
        assertFalse(recovered.contains("| ----------------- | Persistent cough"))
    }

    @Test fun validGfmTableIsByteForByteUnchanged() {
        val input = """Intro

| A | B |
| --- | --- |
| 1 | 2 |
| 3 | 4 |

After"""
        assertEquals(input, RovexMarkdownTableRecovery.recover(input))
    }

    @Test fun escapedAndCodePipesDoNotBecomeExtraColumns() {
        val input = """| A | B |
| --- | --- |
| `x|y` | a\|b |"""
        assertEquals(input, RovexMarkdownTableRecovery.recover(input))
    }

    @Test fun collapsedProviderTableIsRecoveredWithoutTouchingPrefix() {
        val input = "Intro | text | ### Re-framed | Distractor | New stem | Correct answer | Fact | | --- | --- | --- | --- | | A | Stem A | TTG-1 | intestinal isoform |"
        val recovered = RovexMarkdownTableRecovery.recover(input)
        assertTrue(recovered.contains("| Distractor | New stem | Correct answer | Fact |"))
        assertTrue(recovered.contains("| A | Stem A | TTG-1 | intestinal isoform |"))
        assertTrue(recovered.startsWith("Intro | text | ### Re-framed"))
    }

    @Test fun ordinaryPipeProseWithoutDelimiterIsUntouched() {
        val input = "Risk | smoking | persistence\nNext | paragraph"
        assertEquals(input, RovexMarkdownTableRecovery.recover(input))
    }

    @Test fun inlineBlockquoteAfterRecoveredRowsIsSeparatedFromTable() {
        val input = """Clinical | Symptom | Typical Finding |
| Diagnostic Tool | ------- | -------- |
| -------- | cough | opacity | | CXR | > interpretation continues here"""
        val recovered = RovexMarkdownTableRecovery.recover(input)
        assertTrue(recovered.contains("| cough | opacity | CXR |"))
        assertTrue(recovered.contains("\n> interpretation continues here"))
        assertFalse(recovered.contains("| CXR | > interpretation"))
    }

    @Test fun splitCellsRespectsEscapedAndInlineCodePipes() {
        assertEquals(listOf("a", "b\\|c", "`d|e`", "f"), RovexMarkdownTableRecovery.splitCells("| a | b\\|c | `d|e` | f |"))
    }

    @Test fun wrappedHeaderWithDoubleTrailingPipeIsRecovered() {
        val markdown = """
            Drug Interactions | Interaction | Effect |
            | Clinical Implication | ------------- | -------- ||
            | CYP3A4 inducers (e.g., rifampicin, carbamazepine itself) | ↓ metabolism → ↓ serum levels | Dose escalation may be required |
            | CYP3A4 inhibitors (e.g., ketoconazole, erythromycin) | ↓ metabolism → ↑ serum levels | Risk of toxicity; monitor levels |
        """.trimIndent()

        val recovered = RovexMarkdownTableRecovery.recover(markdown)
        assertTrue(recovered.contains("| Interaction | Effect | Clinical Implication |"))
        assertTrue(recovered.contains("| --- | --- | --- |"))
        assertTrue(recovered.contains("| CYP3A4 inducers"))
        assertTrue(recovered.contains("Risk of toxicity; monitor levels"))
    }

}

