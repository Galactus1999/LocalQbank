package com.localqbank.library

import org.junit.Assert.assertTrue
import org.junit.Test

class BenQuestionAiContextPolicyTest {
    private fun question(): Question = Question(
        1L, "q1", 0, null,
        "A child has infantile spasms.",
        "A child has infantile spasms.",
        "C", "ACTH is first-line.",
        null, null, null,
        listOf(
            Option("A", "Valproate", false),
            Option("B", "Levetiracetam", false),
            Option("C", "ACTH", true)
        ),
        emptyList(), emptyList()
    )

    private fun context(): FrankensteinContextEngine.ContextBundle =
        FrankensteinContextEngine.ContextBundle(
            question = question(),
            concepts = listOf("infantile spasms"),
            weakestConcept = null,
            weakestMastery = null,
            relatedQuestions = listOf(
                FrankensteinContextEngine.RelatedQuestion(
                    11L, "INI-CET", "local PYT", "Which EEG pattern is classic?", "Hypsarrhythmia", category = "PYT"
                ),
                FrankensteinContextEngine.RelatedQuestion(
                    12L, "NEET-PG", "local QBank", "First-line treatment?", "ACTH", category = "Topic"
                )
            ),
            relatedSources = listOf("INI-CET / local PYT", "NEET-PG / local QBank"),
            personalNote = null,
            localEvidenceCount = 2,
            summary = "Infantile spasms"
        )

    @Test
    fun pytPolicyRequiresWholeTopicExamTeachingAndQuestionMapping() {
        val evidence = BenQuestionAiContextPolicy().evidence(question(), context(), BenQuestionAiMode.PYT_CONTEXT)
        assertTrue(evidence.contains("EXAM-TEACHING REQUIREMENT"))
        assertTrue(evidence.contains("underlying topic"))
        assertTrue(evidence.contains("subtopic it tested"))
        assertTrue(evidence.contains("Which EEG pattern is classic?"))
    }

    @Test
    fun otherOptionsPolicyRequiresExamOrientedDistractorAnalysis() {
        val evidence = BenQuestionAiContextPolicy().evidence(question(), context(), BenQuestionAiMode.OTHER_OPTIONS)
        assertTrue(evidence.contains("exam-oriented detail"))
        assertTrue(evidence.contains("when it becomes correct"))
        assertTrue(evidence.contains("valid exam-style reframing"))
        assertTrue(evidence.contains("common close-distractor trap"))
    }
}
