package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class RovexDailyNotificationContentTest {
    @Test fun quoteIsDeterministicForSameDay() {
        val day = java.time.LocalDate.of(2026, 9, 25)
        assertEquals(RovexDailyNotificationContent.quoteFor(day), RovexDailyNotificationContent.quoteFor(day))
    }

    @Test fun adjacentDaysNormallyAdvanceQuote() {
        val a = java.time.LocalDate.of(2026, 9, 25)
        val b = a.plusDays(1)
        assertNotEquals(RovexDailyNotificationContent.quoteFor(a), RovexDailyNotificationContent.quoteFor(b))
    }

    @Test fun quoteLibraryIsLargeEnoughForARealDailyRotation() {
        assertTrue(RovexDailyNotificationContent.quoteCount() >= 30)
    }

    @Test fun nextTriggerMovesToTomorrowWhenTimeAlreadyPassed() {
        val now = ZonedDateTime.of(2026, 9, 25, 20, 30, 0, 0, ZoneId.of("Asia/Kolkata"))
        val delay = RovexDailyNotificationContent.nextTriggerMillis(now, 20, 0)
        assertTrue(delay > 23L * 60L * 60L * 1000L)
    }

    @Test fun nextTriggerStaysWithinOneDay() {
        val now = ZonedDateTime.of(2026, 9, 25, 7, 30, 0, 0, ZoneId.of("Asia/Kolkata"))
        val delay = RovexDailyNotificationContent.nextTriggerMillis(now, 8, 0)
        assertTrue(delay in 29L * 60L * 1000L..31L * 60L * 1000L)
    }
}
