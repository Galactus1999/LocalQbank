package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexCelebrationPreferencesTest {
    @Test
    fun parsesAndNormalizesCustomQuestionTargets() {
        assertEquals(listOf(10, 25, 50, 100), RovexCelebrationPreferences.parseTargets("50, 10, 25, 25, 100"))
        assertEquals(listOf(10, 20), RovexCelebrationPreferences.parseTargets("10;20"))
    }

    @Test
    fun invalidTargetsFallBackToSafeDefaults() {
        assertEquals((10..100 step 10).toList(), RovexCelebrationPreferences.parseTargets("-4,0,abc"))
    }

    @Test
    fun celebrationTriggersOnlyAtConfiguredQuestionCounts() {
        val targets = listOf(10, 25, 50)
        assertTrue(RovexCelebrationPreferences.shouldCelebrate(10, targets))
        assertFalse(RovexCelebrationPreferences.shouldCelebrate(11, targets))
        assertTrue(RovexCelebrationPreferences.shouldCelebrate(25, targets))
    }

    @Test
    fun rotateStyleCyclesThroughAllTenVariants() {
        val plan = RovexCelebrationPreferences.Plan(style = RovexCelebrationPreferences.STYLE_ROTATE)
        assertEquals((0..9).toList(), (0..9).map { RovexCelebrationPreferences.variantFor(plan, it) })
    }

    @Test
    fun fixedStyleStaysStable() {
        val plan = RovexCelebrationPreferences.Plan(style = RovexCelebrationPreferences.STYLE_FIXED, fixedVariant = 7)
        assertEquals(listOf(7, 7, 7), (0..2).map { RovexCelebrationPreferences.variantFor(plan, it) })
    }
}
