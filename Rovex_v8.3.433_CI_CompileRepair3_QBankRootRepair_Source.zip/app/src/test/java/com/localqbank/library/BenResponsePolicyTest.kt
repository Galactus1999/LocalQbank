package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BenResponsePolicyTest {
    @Test fun markdownWhitespaceIsPreserved() {
        val raw = """## Heading

Paragraph one.

| A | B |
| --- | --- |
| 1 | 2 |

```mermaid
flowchart TD
A[One] --> B[Two]
```
"""
        val normalized = BenResponsePolicy.normalize(raw)!!
        assertTrue(normalized.contains("## Heading\n\nParagraph one."))
        assertTrue(normalized.contains("| A | B |\n| --- | --- |\n| 1 | 2 |"))
        assertTrue(normalized.contains("```mermaid\nflowchart TD\nA[One] --> B[Two]\n```"))
    }

    @Test fun mermaidNodeBracesSurviveResponsePolicy() {
        val raw = """```mermaid
flowchart TD
A[Patient] --> B{Stage?}
B -->|I-II| C[Observe]
```"""
        val normalized = BenResponsePolicy.normalize(raw)!!
        assertTrue(normalized.contains("B{Stage?}"))
        assertTrue(normalized.contains("B -->|I-II| C[Observe]"))
    }

    @Test fun cssLookingCodeInsideFenceIsPreserved() {
        val raw = """```text
body{color:red}
```"""
        val normalized = BenResponsePolicy.normalize(raw)!!
        assertTrue(normalized.contains("body{color:red}"))
    }

    @Test fun controlCharactersAreRemovedWithoutDestroyingMarkdownStructure() {
        val normalized = BenResponsePolicy.normalize("# A\u0000\n\n**bold**")!!
        assertEquals("# A \n\n**bold**", normalized)
    }
    @Test fun incompleteStreamingMermaidFencePreservesBraceSyntax() {
        val raw = "```mermaid\nflowchart TD\nA[Diagnosis] --> B{Stage: I-II}"
        val normalized = BenResponsePolicy.normalize(raw)!!
        assertTrue(normalized.contains("B{Stage: I-II}"))
    }

    @Test fun cssRuleIsRemovedWithoutCorruptingMermaidBraces() {
        val raw = "body{color:red}\n\n```mermaid\nflowchart TD\nA[Start] --> B{Stage?}\n```"
        val normalized = BenResponsePolicy.normalize(raw)!!
        assertTrue(normalized.contains("B{Stage?}"))
        assertTrue(normalized.contains("```mermaid"))
        assertTrue(!normalized.contains("body{color:red}"))
    }

    @Test fun htmlEventAndStyleAttributesAreStrippedWithoutFallbackToUnsafeRawText() {
        val raw = "<p onclick=\"alert(1)\" style=\"color:red\">Safe</p>"
        val normalized = BenResponsePolicy.normalize(raw)!!
        assertTrue(normalized.contains("Safe"))
        assertTrue(!normalized.contains("onclick", ignoreCase = true))
        assertTrue(!normalized.contains("style=", ignoreCase = true))
    }

}
