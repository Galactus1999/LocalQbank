#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REN="$ROOT/app/src/main/java/com/localqbank/library/RenActivity.kt"
BEN="$ROOT/app/src/main/java/com/localqbank/library/BenQuestionAiContextDialog.kt"
DOC="$ROOT/app/src/main/java/com/localqbank/library/RovexChatDocument.kt"
POL="$ROOT/app/src/main/java/com/localqbank/library/BenResponsePolicy.kt"
fail=0
pass(){ echo "PASS: $1"; }
check(){ if "$@"; then pass "$1"; else echo "FAIL: $1"; fail=1; fi }
check test -s "$DOC"
check grep -q 'RovexChatDocument.configure(this)' "$REN"
check grep -q 'RovexChatDocument.configure(this)' "$BEN"
check grep -q 'generateStreaming' "$REN"
if [[ $(grep -c 'generateStreaming' "$BEN") -ge 2 ]]; then pass "BEN + AI initial/follow-up lanes use streaming"; else echo "FAIL: BEN + AI initial/follow-up lanes use streaming"; fail=1; fi
if grep -q 'RovexChatDocument.append' "$REN" && grep -q 'RovexChatDocument.replace' "$REN"; then pass "Frankenstein incremental DOM append/replace is present"; else echo "FAIL: Frankenstein incremental DOM append/replace is present"; fail=1; fi
if grep -q 'RovexChatDocument.append' "$BEN" && grep -q 'RovexChatDocument.replace' "$BEN"; then pass "BEN + AI incremental DOM append/replace is present"; else echo "FAIL: BEN + AI incremental DOM append/replace is present"; fail=1; fi
if ! grep -q 'renderChatTranscript' "$BEN"; then pass "BEN + AI no legacy transcript rebuild helper remains"; else echo "FAIL: BEN + AI no legacy transcript rebuild helper remains"; fail=1; fi
check grep -q 'normalizeRichMarkdownWhitespace' "$POL"
check grep -q 'protectedBlocks' "$POL"
if ! grep -R 'addJavascriptInterface' "$REN" "$BEN" "$DOC" >/dev/null; then pass "No chat WebView JavaScript interface is exposed"; else echo "FAIL: No chat WebView JavaScript interface is exposed"; fail=1; fi
exit "$fail"
