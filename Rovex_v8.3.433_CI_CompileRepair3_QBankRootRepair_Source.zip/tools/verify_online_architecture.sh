#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 - "$ROOT" <<'PY'
import json, pathlib, re, sys
root=pathlib.Path(sys.argv[1])
gradle=(root/'app/build.gradle.kts').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
online=(root/'app/src/main/java/com/localqbank/library/RovexOnline.kt').read_text()
activity=(root/'app/src/main/java/com/localqbank/library/RovexOnlineActivity.kt').read_text()
rules=(root/'firestore.rules').read_text()
config=json.loads((root/'app/google-services.json').read_text())
client=next(c for c in config['client'] if c.get('client_info',{}).get('android_client_info',{}).get('package_name')=='com.localqbank.library')
types={x.get('client_type') for x in client.get('oauth_client',[])}
assert 1 in types and 3 in types, 'Android + Web OAuth clients required'
for dep in ['com.google.firebase:firebase-auth','com.google.firebase:firebase-firestore','androidx.credentials:credentials','androidx.credentials:credentials-play-services-auth','com.google.android.libraries.identity.googleid:googleid']:
    assert dep in gradle, f'missing dependency {dep}'
assert 'android:name=".RovexOnlineActivity"' in manifest
assert 'setServerClientId(activity.getString(R.string.default_web_client_id))' in online
assert 'FirebaseAuth.getInstance().currentUser' in online
assert 'WorkManager.getInstance(app).enqueueUniqueWork' in online
assert 'NetworkType.CONNECTED' in online
assert 'friendRequests' in rules and 'friendCodes' in rules and 'match /friends/{friendUid}' in rules
assert 'setOnClickListener' in activity
assert 'loadOwnProgress(user)' in activity
assert 'ensureIdentityProfile(user)' in online
assert 'submitStudyEvent(user, event)' in online
assert 'onDocumentCreatedWithAuthContext' in (root/'functions/index.js').read_text()
assert 'withContext(Dispatchers.IO)' in activity
print('ONLINE_GOOGLE_OAUTH_CONFIG=PASS')
print('ONLINE_FIREBASE_DEPENDENCIES=PASS')
print('ONLINE_FIRESTORE_RULES=PASS')
print('ONLINE_OFFLINE_FIRST_SYNC_BOUNDARY=PASS')
PY
printf 'ONLINE_ARCHITECTURE_AUDIT=PASS\n'
