const { onDocumentCreatedWithAuthContext } = require("firebase-functions/v2/firestore");
const { setGlobalOptions } = require("firebase-functions/v2");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
setGlobalOptions({ maxInstances: 4, timeoutSeconds: 30 });
const db = getFirestore();

const EVENT_XP = {
  quiz_completed: 10,
  flashcard_reviewed: 5,
};

/**
 * Server-authoritative competitive progress.
 * The Android client can submit immutable study events, but cannot write the aggregate counters.
 * Firestore triggers may retry, so event processing is idempotent inside one transaction.
 */
exports.acceptStudyEvent = onDocumentCreatedWithAuthContext(
  "studyEvents/{userId}/events/{eventId}",
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const uid = event.params.userId;
    // Firestore Security Rules already guarantee that only the authenticated uid can create
    // this path. Auth-context identifiers can be unavailable/unknown in some trigger paths,
    // so do not make legitimate events depend on a fragile authId mapping. Reject only explicit
    // non-user/system principals here.
    if (["unauthenticated", "api_key", "service_account", "system"].includes(event.authType)) {
      await snap.ref.set({ accepted: false, rejection: "NON_USER_PRINCIPAL", processedAt: FieldValue.serverTimestamp() }, { merge: true });
      return;
    }

    const data = snap.data() || {};
    const type = data.type;
    if (!Object.prototype.hasOwnProperty.call(EVENT_XP, type)) {
      await snap.ref.set({ accepted: false, rejection: "INVALID_EVENT", processedAt: FieldValue.serverTimestamp() }, { merge: true });
      return;
    }

    const profileRef = db.collection("users").doc(uid);
    await db.runTransaction(async (tx) => {
      const eventSnap = await tx.get(snap.ref);
      if (eventSnap.get("processedAt")) return;

      const profileSnap = await tx.get(profileRef);
      const current = profileSnap.exists ? profileSnap.data() : {};
      const correct = type === "quiz_completed" && data.correct === true;
      const attempted = Number(current.questionsSolved || 0) + (type === "quiz_completed" ? 1 : 0);
      const correctCount = Number(current.correct || 0) + (correct ? 1 : 0);
      const flashcards = Number(current.flashcardsReviewed || 0) + (type === "flashcard_reviewed" ? 1 : 0);
      const xp = Number(current.xp || 0) + EVENT_XP[type] + (correct ? 15 : 0);
      const accuracy = attempted > 0 ? Math.floor((correctCount * 100) / attempted) : 0;
      const eventCreatedAt = data.createdAt && typeof data.createdAt.toDate === "function" ? data.createdAt.toDate() : new Date();
      const todayKey = new Date().toISOString().slice(0, 10);
      const eventDayKey = eventCreatedAt.toISOString().slice(0, 10);
      const todaySolved = eventDayKey === todayKey ? Number(current.todaySolved || 0) + (type === "quiz_completed" ? 1 : 0) : Number(current.todaySolved || 0);

      tx.set(profileRef, {
        uid,
        questionsSolved: attempted,
        correct: correctCount,
        accuracyPercent: accuracy,
        flashcardsReviewed: flashcards,
        todaySolved,
        xp,
        updatedAt: FieldValue.serverTimestamp(),
      }, { merge: true });
      tx.update(snap.ref, {
        accepted: true,
        processedAt: FieldValue.serverTimestamp(),
      });
    });
  }
);
