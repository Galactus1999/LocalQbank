# Rovex v8.3.420 — AI Chat Deep CI Hardening

## Root causes repaired

1. **False-negative Mermaid regression assertion**
   - CI v8.3.419 executed 98 JVM tests and failed only `RovexRichRendererTest.collapsedMermaidChainRetainsLaterNodesAndEdges`.
   - The renderer emits `class="edge "` for solid flow edges because the optional `dashed` class slot is always serialized. The test incorrectly required the exact attribute substring `class="edge"`.
   - The assertion now checks the `edge` CSS class token rather than a fragile HTML attribute serialization.

2. **Future Kotlin compiler errors from heterogeneous SQLite bind arrays**
   - CI compiler warnings explicitly stated that intersection-type inference for several `arrayOf(...)` calls "will become an error in a future release".
   - Affected `FlashcardDb.kt` and `QBankDb.kt` calls now explicitly use `arrayOf<Any?>(...)`, matching Android SQLite's bind-argument contract and preventing unstable reified/intersection inference.

## Scope

No business logic, database schema, renderer architecture, AI provider behavior, cancellation policy, or chat UI behavior was changed by the future-error hardening. The Mermaid renderer itself was not weakened to satisfy the test.

## Verification

- v8.3.419 CI: production/test compilation passed; 98 JVM tests ran; exactly 1 failed.
- v8.3.419 failure was isolated to the test assertion at `RovexRichRendererTest.kt:218`.
- v8.3.420 source ZIP integrity checked after packaging.
- Full Android compilation/JVM test/release/device verification remains a CI gate and must not be claimed until executed.
