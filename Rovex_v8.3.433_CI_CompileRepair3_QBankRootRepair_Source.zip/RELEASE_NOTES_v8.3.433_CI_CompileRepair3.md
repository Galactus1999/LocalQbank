# Rovex v8.3.433 — CI Compile Repair 3

Corrects the v8.3.432 Frankenstein bounded-retrieval integration contract exposed by CI.

## Changes
- Explicit `List<RelatedQuestion>` result type for bounded retrieval.
- Correct package-level `QuestionRef` reference.
- Explicit reference map type.
- Unambiguous `LongArray.asList().mapNotNull` conversion.
- Empty candidate fast path.
- Preserved database close/finally semantics.

## Stability scope
No changes to QBank deletion semantics, tombstones, deletion recovery, deferred FTS cleanup, or bounded AI retrieval architecture.

## Verification
Targeted Kotlin probe passes. Full Gradle CI compile remains the authoritative next gate.
