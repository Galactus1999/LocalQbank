# Rovex v8.3.427 — online UI compile correction

## Purpose
Correct the remaining Kotlin compilation error reported by CI for v8.3.426.

## Root cause
`RovexOnlineActivity.renderSignedIn()` builds the ADD A FRIEND card through `CardScope`. Inside that receiver, `this` refers to `CardScope`, not the Activity `Context`. The `EditText` constructor therefore received `CardScope` where Android requires a `Context`.

## Fix
Changed the constructor to explicitly use `this@RovexOnlineActivity`.

No online behavior, Firestore logic, authentication flow, QBank/search logic, or BEN/Frankenstein runtime architecture was changed by this correction.

Version: 8.3.427
versionCode: 519
