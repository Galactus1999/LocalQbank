# v8.3.416 — AI Chat CI Syntax Repair

## CI evidence
The uploaded GitHub Actions run `logs_98105804650.zip` reached `:app:compileDebugKotlin` and failed in `BenQuestionAiContextDialog.kt` at line 320. The root compiler errors were an unclosed `generateStreaming(...)` call: `renderJob` and `result` were parsed outside the call, followed by cascading syntax errors.

## Repair
Closed the first BEN + AI streaming `generateStreaming(...)` invocation immediately after the `onChunk` lambda, before `renderJob?.join()`.

## Preserved
- streaming architecture
- incremental `RovexChatDocument` rendering
- cancellation handling
- stale-generation protection
- final-answer replacement
- provider fallback handling

## Version
- versionName: 8.3.416
- versionCode: 508

## Verification status
Static/source inspection completed for the repaired call and adjacent follow-up/Ren streaming calls. Android compilation remains pending GitHub CI; no local Gradle compile is claimed because the environment cannot resolve `downloads.gradle.org`.
