# v8.3.418 — AI Chat Test Syntax Repair

## Defect
CI run `logs_98107486454.zip` reached Kotlin compilation but failed in `RovexRichRendererTest.kt`.

Root compiler error:
- line 63: unresolved reference `https`
- malformed string literal caused cascading parser errors on `html` and subsequent lines.

## Root cause
The XSS regression test contained unescaped double quotes inside a Kotlin double-quoted string:

`src="https://example.com/a.png" onerror="alert(1)"`

## Repair
Escaped the HTML attribute quotes in the Kotlin string literal. No production chat/rendering logic was changed.

Version: 8.3.418
versionCode: 510

## Verification
Source inspection confirms the malformed literal is repaired. Android CI/build/runtime verification is still required.
