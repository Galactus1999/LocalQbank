# AUDIT PROOF v8.3.576

## Source of truth
v8.3.575 CI run `logs_101643450102.zip` failed in `:app:testDebugUnitTest` with 5 LargeHtmlScannerRegressionTest failures after Kotlin compilation succeeded.

## Root cause repair
Replaced the v8.3.575 `normalize()` implementation's platform `JSONObject.optString()`/typed-null normalization path with a single `firstNonNull()` + `clean()` path. Explicit `JSONObject.NULL` is skipped before alias selection. Option labels and all nullable metadata use the same safe path.

## Regression cases exercised in an isolated JVM harness
- TESTS_LIST first question
- QUESTIONS_DATA question alias
- explicit JSON null fallback from raw_text/text to question and options to choices
- JavaScript comment containing a fake TESTS_LIST assignment

All four representative cases emitted the expected question(s).

## Additional static checks
- versionName 8.3.576 / versionCode 663
- package/applicationId preserved as com.localqbank.library
- LargeHtmlScanner quote literal remains syntactically correct
- no setRequiresDeviceIdle(true) + setBackoffCriteria combination found in worker source
- extractImages nullable regex group warning removed safely

## Verification boundary
Android GitHub CI for v8.3.576 is PENDING. No Android build/CI/device PASS is claimed.
