# Rovex v8.3.576 — LargeHtmlScanner CI Test Repair

## CI failure repaired
The authoritative CI log `logs_101626728955.zip` reached `:app:testDebugUnitTest` and failed 5 `LargeHtmlScannerRegressionTest` cases after compilation succeeded. The five failures were: explicit JSON null alias fallback, JavaScript-comment assignment filtering, standard TESTS_LIST emission, root QUESTIONS_DATA emission, and root question-alias fallback.

## Root cause addressed
The scanner normalization path mixed raw `JSONObject.opt()` sentinel values (`JSONObject.NULL`) with nullable Java `optString(..., null)` calls. This created a fragile Android `org.json`/Kotlin nullability boundary and allowed malformed-question telemetry to become an importer failure if the breadcrumb path itself failed.

## Fix
- Reworked question normalization to use typed `optJSONArray`/`optJSONObject` access and explicit string/null helpers.
- Preserved alias order: `raw_text -> text -> question -> stem -> question_text`.
- Preserved option aliases: `options -> choices -> answers`.
- Preserved one-option acceptance required by the scanner tests.
- Added `correctAnswer` to answer aliases.
- Made malformed-question breadcrumb reporting non-fatal with `runCatching`, without broad `catch(Throwable)`.
- Preserved the streaming scanner and JavaScript comment/string lexical filtering.

## Version
- versionName: `8.3.576`
- versionCode: `663`
- applicationId: `com.localqbank.library`

## Verification boundary
- Authoritative CI log independently inspected: PASS.
- All 5 failing tests identified: PASS.
- Corrected scanner compiled with a local JVM stub harness and all five reproductions emitted the expected questions: PASS (isolated harness, not Android build).
- XML parsing: PASS.
- Idle WorkManager/backoff static gate: PASS.
- Full Android Gradle build: PENDING CI.
- Device validation: PENDING CI/build.
