# Rovex v8.3.304 — Offline Final Source Audit

Prepared for direct upload/build. This source is the v8.3.304 handoff with the UI revolution and Daily Study Hub wired into `MainActivity`/`RovexHomeRevolution`.

## Release identity
- versionName: 8.3.304
- versionCode: 398
- applicationId: com.localqbank.library

## UI/runtime markers verified offline
- `RovexHomeRevolution.apply(this)` is called from `MainActivity`.
- `RovexLiveBackdrop` is present in the replacement home shell.
- `RovexDailyStudyHub.install(a, content, pF)` is wired into the replacement home shell.
- Daily Progress Heatmap is present.
- Daily Schedule Planner is present.
- Android Calendar export uses `Intent.ACTION_INSERT`; Rovex does not require calendar-account access for this flow.
- v8.3.304 marker `ROVEX_PHASE_304_DAILY_STUDY_HUB` is present.
- UI revolution marker `ROVEX_UI_REVOLUTION_303` is retained as the preceding UI baseline marker.

## Offline repair included
The Daily Schedule Planner dialog was corrected so `Save Plan` actually saves the plan and `Calendar` exports the first schedule block. The earlier staging implementation incorrectly intercepted the positive button and could turn Save Plan into Calendar export.

The animated home backdrop was also made visibility-aware so its animation scheduling stops when the drawable is hidden, reducing unnecessary background invalidation.

## Verification boundary
This is a source-level offline final package. No claim of Android/CI compilation is made here. Build/device verification must be performed by the upload/build environment.
