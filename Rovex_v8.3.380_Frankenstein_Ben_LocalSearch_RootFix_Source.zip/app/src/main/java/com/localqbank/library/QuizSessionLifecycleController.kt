package com.localqbank.library


/**
 * Presentation-lifecycle bridge for QuizActivity.
 *
 * It owns no quiz/business state. It only sequences the existing ViewModel persistence
 * seams when the Android Activity enters/leaves the foreground.
 */
class QuizSessionLifecycleController(
    private val viewModel: QuizViewModel,
    private val activity: android.app.Activity,
    private val recordCurrentTime: () -> Unit
) {
    fun onPause() {
        recordCurrentTime()
        viewModel.persistResumePosition()
        runCatching { viewModel.persistSessionCursor() }
        viewModel.checkpointSession()
    }

    fun onStop() {
        // The cursor checkpoint is small and remains synchronous for crash-safety. Cloud backup
        // can involve network/storage work, so it must not block Activity.onStop.
        viewModel.checkpointSession()
        ResilienceManager.activityStopped(activity, activity)
        PerformanceManager.submitMaintenance { runCatching { BackupManager(activity.applicationContext).flushCloudBackup() } }
    }

    fun onResume() {
        ResilienceManager.activityStarted(activity, activity)
        ResilienceManager.heartbeat(activity)
    }
}
