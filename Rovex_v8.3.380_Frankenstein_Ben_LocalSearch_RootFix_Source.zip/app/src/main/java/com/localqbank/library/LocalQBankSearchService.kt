package com.localqbank.library

import android.content.Context

/**
 * Single deterministic retrieval contract for every local-QBank consumer.
 *
 * This class deliberately owns retrieval composition, not ranking, UI, learner state or AI.
 * The authoritative corpus remains QBankDb. Every caller gets the same bounded terminology
 * expansion and the same literal+alias recall behavior, preventing Frankenstein, Search and
 * the neural evidence pipeline from silently implementing different search engines.
 */
class LocalQBankSearchService(context: Context) {
    private val app = context.applicationContext
    private val db = QBankDb(app)

    data class Result(
        val hits: List<SearchHit>,
        val variants: List<String>,
        val primaryCount: Int,
        val aliasCount: Int
    )

    fun search(
        query: String,
        limit: Int = 100,
        extraVariants: Collection<String> = emptyList(),
        visualOnly: Boolean = false
    ): Result {
        val safeLimit = limit.coerceIn(1, 1200)
        val normalized = ClinicalKnowledgeLayer.normalize(query)
        if (normalized.length < 2) return Result(emptyList(), emptyList(), 0, 0)

        val variants = linkedSetOf<String>().apply {
            add(normalized)
            ClinicalQueryExpansion.expand(normalized).forEach(::add)
            extraVariants.forEach { value ->
                val v = ClinicalKnowledgeLayer.normalize(value)
                if (v.length >= 2) add(v)
            }
        }.filter { it.isNotBlank() }.take(16)

        runCatching { db.ensureSearchIndex() }
            .onFailure {
                ProductionCrashReporter.breadcrumb(
                    RovexApplicationContextHolder.context,
                    "LOCAL_SEARCH_INDEX_PREP_FAILED:${it.javaClass.simpleName}"
                )
            }

        val primary = runCatching {
            if (visualOnly) db.searchImageQuestions(normalized, safeLimit)
            else db.search(normalized, safeLimit)
        }.getOrElse {
            ProductionCrashReporter.breadcrumb(
                RovexApplicationContextHolder.context,
                "LOCAL_SEARCH_PRIMARY_FAILED:${it.javaClass.simpleName}"
            )
            emptyList()
        }

        // Alias/semantic-language rescue is deliberately bounded. Search every alias only when
        // primary recall is sparse; this avoids turning ordinary typing into N full-table scans.
        val aliasVariants = variants.drop(1).take(if (primary.size >= minOf(8, safeLimit)) 0 else 8)
        val aliases = if (aliasVariants.isEmpty()) emptyList() else {
            aliasVariants.asSequence()
                .flatMap { variant ->
                    runCatching {
                        if (visualOnly) db.searchImageQuestions(variant, safeLimit)
                        else db.search(variant, safeLimit)
                    }.getOrDefault(emptyList()).asSequence()
                }
                .distinctBy { it.id }
                .take(safeLimit)
                .toList()
        }

        val merged = (primary + aliases).distinctBy { it.id }.take(safeLimit)
        return Result(merged, variants, primary.size, aliases.size)
    }

    companion object {
        /** True when a short prompt is more naturally a local-corpus topic lookup than a generated explanation. */
        fun isLikelyTopicQuery(command: String): Boolean {
            val q = command.trim().lowercase()
            if (q.length < 3) return false
            val explicitInterrogative = Regex("\\b(what|which|why|how|when|where|who|explain|define|mechanism|management|treatment|diagnosis|investigation)\\b").containsMatchIn(q)
            if (explicitInterrogative) return false
            val words = q.split(Regex("\\s+")).filter { it.isNotBlank() }
            return words.size in 1..6
        }
    }

    fun ids(
        query: String,
        limit: Int = 100,
        extraVariants: Collection<String> = emptyList(),
        visualOnly: Boolean = false
    ): LongArray = search(query, limit, extraVariants, visualOnly).hits.map { it.id }.toLongArray()
}
