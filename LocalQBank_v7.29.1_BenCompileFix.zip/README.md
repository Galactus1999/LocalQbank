# LocalQBank v7.29.0 — CI Compile Fix

## Release purpose
Corrected two Kotlin API-compatibility issues exposed by the GitHub Android build for v7.29.0.

### Fixes
- Replaced `WindowInsetsCompat.Type.safeDrawing()` with the compatible union of `systemBars()` and `displayCutout()` in the adaptive layout/system UI layer. This preserves cutout-aware, edge-to-edge-safe layout without relying on a newer Core API than the project's dependency/toolchain exposes.
- Replaced the Kotlin `singleLine=true` property assignment with the platform-compatible `setSingleLine(true)` call in `KnowledgeVaultActivity`.
- Bumped version to 7.29.0 / versionCode 58.

## Verification
Static source/resource checks were rerun after the fixes. Android compilation must still be performed by the repository's GitHub Actions environment because the packaging environment does not contain the Android SDK/Gradle toolchain.


## v7.29.0 Ben-centered architecture
BIO is now a thin orchestrator: simple capabilities can execute directly, while multi-step requests are planned through BIO. A bounded offline BenCognitiveEngine provides intent hints, local summarisation, key-point extraction and study-plan suggestions. EngineMeshCoordinator links specialist engines through typed events without adding heavy work to the UI thread.


### v7.29.0 Ben-centered refinement
BIO is intentionally thin and only orchestrates multi-step requests. Simple capabilities can execute directly. Ben now has a bounded offline cognitive core for intent detection, local summaries, key-point extraction and study planning, plus a user-facing Ben workspace. EngineMeshCoordinator provides typed event coordination without doing heavy work on the UI thread. No runtime executable self-modification or network dependency is introduced.


### Architecture principle
Ben is the centre, not a bottleneck. Simple requests route directly to specialist capabilities; BIO is invoked only for multi-step coordination. The local cognitive layer provides bounded intent detection, summarisation, key-point extraction and study-plan suggestions. The event mesh links engine state without performing heavy work on the UI thread.
