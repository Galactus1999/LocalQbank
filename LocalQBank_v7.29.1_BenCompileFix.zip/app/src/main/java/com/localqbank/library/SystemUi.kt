package com.localqbank.library

import android.app.Activity
import android.view.View
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Shared system-bar policy. Status/navigation bars remain visible; content is inset safely. */
object SystemUi {
    fun immersive(activity: Activity) {
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        val controller=WindowCompat.getInsetsController(activity.window,activity.window.decorView)
        controller.systemBarsBehavior=androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.show(WindowInsetsCompat.Type.statusBars())
        controller.show(WindowInsetsCompat.Type.navigationBars())
        controller.isAppearanceLightStatusBars=!ThemeManager.isDark(activity)
        controller.isAppearanceLightNavigationBars=!ThemeManager.isDark(activity)
        val content=activity.findViewById<View>(android.R.id.content)
        if(content!=null){
            AdaptiveLayoutManager.install(activity, content, topExtraDp=8, bottomExtraDp=4, keepStatusBarVisible=true)
        }
    }
    fun padTopInset(view:View,baseTopDp:Int,baseBottomDp:Int,baseStartDp:Int,baseEndDp:Int){
        val d=view.resources.displayMetrics.density;val top=(baseTopDp*d).toInt();val bottom=(baseBottomDp*d).toInt();val start=(baseStartDp*d).toInt();val end=(baseEndDp*d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view){v,insets->val safe=insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout());v.setPadding(start,top+safe.top,end,bottom);insets};ViewCompat.requestApplyInsets(view)
    }
    fun padBottomInset(view:View,baseTopDp:Int,baseBottomDp:Int){
        val d=view.resources.displayMetrics.density;val top=(baseTopDp*d).toInt();val bottom=(baseBottomDp*d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view){v,insets->val safe=insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout());v.setPadding(v.paddingLeft,top,v.paddingRight,bottom+safe.bottom);insets};ViewCompat.requestApplyInsets(view)
    }
}
