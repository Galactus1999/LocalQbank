# Rovex v8.3.195 — EmbeddingGemma post-inference lifecycle isolation

- Preserves the proven Qualcomm NPU/LiteRT inference path from v8.3.194.
- Keeps the diagnostic runtime alive until the worker has attempted the terminal Binder reply.
- Moves diagnostic native runtime teardown out of `diagnosticReport()` so runtime destruction cannot mask a valid 3/3 inference result.
- Adds durable markers around post-inference validation, semantic scoring, report construction, terminal reply, worker unbind/destroy, and diagnostic runtime close.
- Treats runtime close as best-effort after terminal reply.
- Stores the diagnostic engine in the worker field for controlled post-reply cleanup.
- Version: 8.3.195 / versionCode 290.
- Android/Gradle compilation remains a CI gate; local compilation is not claimed.
