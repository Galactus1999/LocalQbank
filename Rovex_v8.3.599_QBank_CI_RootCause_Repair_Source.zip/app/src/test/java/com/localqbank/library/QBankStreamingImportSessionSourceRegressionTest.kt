package com.localqbank.library

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class QBankStreamingImportSessionSourceRegressionTest {
    @Test
    fun extractedStreamingSessionRetainsNullableBinderHelper() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/QBankStreamingImportSession.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/QBankStreamingImportSession.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText()
        assertTrue(
            "QBankStreamingImportSession.kt must retain its extracted bindNullable helper",
            source != null && source.contains(
                "private fun bindNullable(statement: android.database.sqlite.SQLiteStatement, index: Int, value: String?)"
            )
        )
    }
}
