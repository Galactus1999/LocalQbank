package com.localqbank.library

import android.app.Activity

/** Release-safe no-op. The real JankStats implementation exists only in debug builds. */
object JankStatsMonitor {
    fun onResumed(activity: Activity) = Unit
    fun onPaused(activity: Activity) = Unit
    fun onDestroyed(activity: Activity) = Unit
}
