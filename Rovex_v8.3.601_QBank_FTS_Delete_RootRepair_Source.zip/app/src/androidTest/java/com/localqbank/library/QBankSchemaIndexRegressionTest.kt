package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Guards the indexes required by large-QBank delete/search paths. */
@RunWith(AndroidJUnit4::class)
class QBankSchemaIndexRegressionTest {
    private lateinit var db: SQLiteDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        QBankDb.resetDatabaseForTest(context)
        // Opening through QBankDb creates the authoritative schema before the raw assertion handle.
        QBankDb(context).sources()
        db = context.openOrCreateDatabase("qbank.db", 0, null)
    }

    @Test
    fun destructiveChildLookupIndexesExist() {
        assertTrue(hasIndex("option_item", "idx_option_item_question"))
        assertTrue(hasIndex("question_image", "idx_question_image_question"))
        assertTrue(hasIndex("question_note_image", "idx_question_note_image_question"))
        assertTrue(hasIndex("source", "idx_source_live_imported"))
    }

    private fun hasIndex(table: String, expected: String): Boolean =
        db.rawQuery("PRAGMA index_list($table)", null).use { c ->
            var found = false
            while (c.moveToNext()) {
                if (c.getString(c.getColumnIndexOrThrow("name")) == expected) {
                    found = true
                    break
                }
            }
            found
        }
}
