package com.localqbank.library

import org.junit.Assert.assertTrue
import org.junit.Test

class FlashcardImportRecoveryRegressionTest {
    @Test
    fun modernAnkiHierarchyDelimiterNormalizesToRovexTree() {
        val raw = "CoreBTR\u001fGeneral Physiology\u001fPyqs"
        val normalized = raw.replace("\u001f", "::").replace("\u001e", "::")
        assertTrue(normalized == "CoreBTR::General Physiology::Pyqs")
    }

    @Test
    fun markdownExplanationProducesBoldHtml() {
        val html = rovexMarkdownBody("This is **schizophrenia** and **clozapine**.")
        assertTrue(html.contains("<b>schizophrenia</b>"))
        assertTrue(html.contains("<b>clozapine</b>"))
    }
}
