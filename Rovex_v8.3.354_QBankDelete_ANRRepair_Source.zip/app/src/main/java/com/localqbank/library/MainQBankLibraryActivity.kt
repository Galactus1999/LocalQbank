package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

/**
 * Main imported-QBank library. The list is deliberately independent from TestListActivity:
 * this screen owns source-level edit/delete/reorder while TestListActivity owns test-level work.
 */
class MainQBankLibraryActivity : Activity() {
    private lateinit var list: LinearLayout
    private var appliedThemeKey: String? = null
    private val importRequestCode = 5197
    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Float = 18f) = GradientDrawable().apply {
        setColor(c); cornerRadius = r * resources.displayMetrics.density
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        shell()
        RovexBottomNavigation.install(this, RovexBottomNavigation.Destination.QBANK.index, b)
        load()
        appliedThemeKey = ThemeManager.get(this)
    }

    override fun onResume() {
        super.onResume()
        if (isFinishing || isDestroyed) return
        val theme = ThemeManager.get(this)
        if (appliedThemeKey != null && appliedThemeKey != theme) {
            appliedThemeKey = theme
            recreate()
            return
        }
        appliedThemeKey = theme
        if (::list.isInitialized) load()
    }


    override fun onSaveInstanceState(outState: Bundle) {
        RovexBottomNavigation.saveInstanceState(outState, RovexBottomNavigation.Destination.QBANK.index)
        super.onSaveInstanceState(outState)
    }

    private fun openImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/html"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        runCatching { startActivityForResult(intent, importRequestCode) }.onFailure {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, importRequestCode)
        }
    }

    @Deprecated("Activity result API retained for compatibility with the existing Activity architecture")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != importRequestCode || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<android.net.Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) if (!uris.contains(clip.getItemAt(i).uri)) uris.add(clip.getItemAt(i).uri) }
        if (uris.isEmpty()) return
        uris.forEach { uri -> runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        startActivity(Intent(this, HtmlImportActivity::class.java).putParcelableArrayListExtra("uris", uris))
    }

    private fun shell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(14), d(12), d(14), d(12))
            background = ThemeManager.backgroundDrawable(this@MainQBankLibraryActivity)
        }
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        h.addView(TextView(this).apply {
            text = "Imported QBanks"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@MainQBankLibraryActivity))
        }, LinearLayout.LayoutParams(0, d(52), 1f))
        h.addView(TextView(this).apply {
            text = "＋ IMPORT"; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = bg(ThemeManager.accent(this@MainQBankLibraryActivity), 14f)
            setPadding(d(12), 0, d(12), 0)
            setOnClickListener { openImportPicker() }
        }, LinearLayout.LayoutParams(d(100), d(44)))
        root.addView(h)
        root.addView(TextView(this).apply {
            text = "Main QBank list • tap to open subject/test content • long-press to manage a QBank"
            textSize = 12.5f; setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity)); setPadding(0, 0, 0, d(12))
        })
        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER; isFillViewport = true }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "← BACK"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@MainQBankLibraryActivity)); background = bg(ThemeManager.elevated(this@MainQBankLibraryActivity), 14f)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(-1, d(46)).apply { topMargin = d(10) })
        setContentView(root)
    }

    private fun load() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        list.addView(TextView(this).apply {
            text = "Loading imported QBanks…"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity)); setPadding(0, d(24), 0, d(24))
        })
        AppManagers.qbankLoading.loadSources { raw ->
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                renderSources(applyOrder(raw))
            }
        }
    }

    private fun applyOrder(raw: List<Source>): List<Source> {
        val rank = MainRepository(applicationContext).use { it.qbankLibraryOrder().withIndex().associate { x -> x.value to x.index } }
        return raw.sortedWith(compareBy<Source> { rank[it.id] ?: Int.MAX_VALUE }.thenByDescending { it.id })
    }

    private fun persistOrder(sources: List<Source>) {
        MainRepository(applicationContext).use { it.setQBankLibraryOrder(sources.map { source -> source.id }) }
    }

    private fun renderSources(sources: List<Source>) {
        list.removeAllViews()
        if (sources.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No imported QBank yet.\nUse IMPORT to add one."
                textSize = 16f; gravity = Gravity.CENTER; setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity))
                setPadding(d(20), d(50), d(20), d(50))
            })
            return
        }
        persistOrder(sources)
        sources.forEachIndexed { i, source ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(d(16), d(14), d(16), d(14))
                background = bg(ThemeManager.panel(this@MainQBankLibraryActivity), 18f)
                isClickable = true; isFocusable = true
                setOnClickListener {
                    startActivity(Intent(this@MainQBankLibraryActivity, TestListActivity::class.java)
                        .putExtra("sourceId", source.id).putExtra("sourceName", source.fileName))
                }
                setOnLongClickListener { showManageDialog(sources, i); true }
            }
            card.addView(TextView(this).apply {
                text = "${i + 1}. ${source.fileName}"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.text(this@MainQBankLibraryActivity)); maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            val meta = if (source.seriesNumber.isBlank()) source.provider.ifBlank { "Imported QBank" }
            else source.provider.ifBlank { "Imported QBank" } + " • Series ${source.seriesNumber}"
            card.addView(TextView(this).apply {
                text = meta; textSize = 12f; setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity)); setPadding(0, d(5), 0, 0)
            })
            card.addView(TextView(this).apply {
                text = "OPEN QBANK  ›   •   LONG-PRESS TO MANAGE"; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.accent(this@MainQBankLibraryActivity)); setPadding(0, d(10), 0, 0)
            })
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(9) })
        }
    }

    private fun showManageDialog(current: List<Source>, index: Int) {
        val source = current[index]
        val options = mutableListOf("Edit name / series")
        if (index > 0) options.add("Move QBank up")
        if (index < current.lastIndex) options.add("Move QBank down")
        options.add("Delete QBank")
        AlertDialog.Builder(this)
            .setTitle(source.fileName)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "Edit name / series" -> editSource(source)
                    "Move QBank up" -> move(current, index, -1)
                    "Move QBank down" -> move(current, index, 1)
                    "Delete QBank" -> deleteSource(source)
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun editSource(source: Source) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(4), d(20), 0) }
        val name = EditText(this).apply { setText(source.fileName); setSingleLine(true); hint = "QBank display name" }
        val series = EditText(this).apply { setText(source.seriesNumber); setSingleLine(true); hint = "Series number (optional)" }
        box.addView(name, LinearLayout.LayoutParams(-1, d(56)))
        box.addView(series, LinearLayout.LayoutParams(-1, d(56)))
        val dialog = AlertDialog.Builder(this).setTitle("Edit QBank").setView(box).setNegativeButton("CANCEL", null).setPositiveButton("SAVE", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val newName = name.text.toString().trim()
                if (newName.isBlank()) { name.error = "Name cannot be empty"; return@setOnClickListener }
                val ok = MainRepository(applicationContext).use { it.updateSourceMetadata(source.id, newName, series.text.toString()) }
                if (ok) {
                    AppManagers.qbankLoading.invalidate(source.id); PerformanceManager.invalidate()
                    dialog.dismiss(); load()
                } else RovexUndoSnackbar.show(window.decorView,"Could not update this QBank.")
            }
        }
        dialog.show()
    }

    private fun move(current: List<Source>, index: Int, delta: Int) {
        val target = index + delta
        if (target !in current.indices) return
        val reordered = current.toMutableList().apply { add(target, removeAt(index)) }
        persistOrder(reordered)
        renderSources(reordered)
    }

    private fun deleteSource(source: Source) {
        AlertDialog.Builder(this)
            .setTitle("Delete QBank?")
            .setMessage("This removes the imported QBank and its questions from Rovex. Flashcard data is not deleted by this action.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("DELETE") { _, _ ->
                // Large QBanks may cascade through many rows. Keep all destructive DB work off
                // the UI thread and contain failures so the Activity cannot crash to the launcher.
                PerformanceManager.submitQBankDeletion {
                    val result = runCatching { MainRepository(applicationContext).use { it.deleteSource(source.id) } }
                    AppManagers.qbankLoading.invalidate(source.id)
                    PerformanceManager.invalidate()
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        result.onSuccess { deleted ->
                            if (deleted) {
                                MainRepository(applicationContext).use { repo ->
                                    repo.setQBankLibraryOrder(repo.qbankLibraryOrder().filter { id -> id != source.id })
                                }
                                Toast.makeText(this, "QBank deleted", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "QBank was not found or was already deleted", Toast.LENGTH_SHORT).show()
                            }
                            load()
                        }.onFailure {
                            Toast.makeText(this, "Could not delete QBank safely: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                            load()
                        }
                    }
                }
            }.show()
    }

}
