package com.localqbank.library

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import java.io.*
import java.nio.charset.Charset
import java.util.LinkedHashMap
import java.util.regex.Pattern
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

class HtmlImportActivity : Activity() {
    private companion object { const val LARGE_FILE_LIMIT = 40L * 1024L * 1024L; const val LARGE_COMPATIBILITY_FALLBACK_LIMIT = 64L * 1024L * 1024L }
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var progressPercent: TextView
    private lateinit var sectionList: LinearLayout
    private lateinit var web: WebView
    private val files = mutableListOf<Uri>()
    private var index = 0
    private var lastSrcdocCount = 0
    private val openDocumentRequestCode = 4108
    @Volatile private var pendingWebExtraction: PendingWebExtraction? = null
    private val webExtractionLock = Any()
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private data class WebExtractionPayload(val fileName: String, val tests: List<ImportedTest>)
    private data class PendingWebExtraction(val requestId: String, val gate: DeferredImportGate<WebExtractionPayload>)

    /** Bridges asynchronous WebView extraction back to the already-running import worker.
     * Keeping one coordinator job alive avoids racing a second enqueue against its running gate.
     */

    override fun onDestroy() {
        // WebView owns Chromium resources outside the Activity heap; explicitly tear it down
        // so repeated large imports cannot retain a renderer/client reference after navigation.
        if (::web.isInitialized) {
            runCatching { web.stopLoading() }
            runCatching { web.clearHistory() }
            runCatching { (web.parent as? ViewGroup)?.removeView(web) }
            runCatching { web.destroy() }
        }
        pendingWebExtraction?.gate?.fail(IllegalStateException("Import screen was closed during HTML extraction"))
        super.onDestroy()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        AppManagers.initialize(applicationContext)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        val title = RovexWaveTextView(this).apply { text = "Import HTML QBank"; textSize = 22f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        SystemUi.padTopInset(title, 18, 8, 0, 0)
        root.addView(title)
        status = TextView(this).apply { setPadding(0, 12, 0, 8); textSize=13.5f; setTextColor(ThemeManager.text(this@HtmlImportActivity)) }
        root.addView(status)
        val progressRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        progress = ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; progress=0 }
        progressPercent=TextView(this).apply{text="0%";textSize=12f;typeface=android.graphics.Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(this@HtmlImportActivity));gravity=Gravity.CENTER}
        progressRow.addView(progress,LinearLayout.LayoutParams(0,dp(10),1f).apply{setMargins(0,0,dp(10),0)})
        progressRow.addView(progressPercent,LinearLayout.LayoutParams(dp(44),dp(28)))
        root.addView(progressRow)
        sectionList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(8),0,dp(8))}
        val sectionScroll=ScrollView(this).apply{isFillViewport=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        sectionScroll.addView(sectionList)
        root.addView(sectionScroll,LinearLayout.LayoutParams(-1,dp(180)))
        val frame = FrameLayout(this)
        web = WebView(this).apply { layoutParams = FrameLayout.LayoutParams(1, 1) }
        frame.addView(web)
        root.addView(frame, LinearLayout.LayoutParams(1,1))
        setContentView(root)
        TransitionCoordinator.install(this)
        val incoming = intent.getParcelableArrayListExtra<Uri>("uris")
        if (incoming != null) files.addAll(incoming)
        // Also accept HTML files opened directly from a file manager/browser via ACTION_VIEW.
        intent.data?.let { if (!files.contains(it)) files.add(it) }
        intent.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) {
                val u = clip.getItemAt(i).uri
                if (!files.contains(u)) files.add(u)
            }
        }
        if (files.isEmpty()) {
            // The library launches this Activity as the import surface. If it was not
            // launched with preselected URIs, open the Storage Access Framework instead
            // of immediately finishing and making the IMPORT button appear broken.
            openDocumentPicker()
            return
        }
        // Keep access to selected document URIs after this Activity is destroyed/recreated.
        // Without this, persisted question images can become unreadable later, especially
        // for DAMS/QBank files selected through the Storage Access Framework.
        files.forEach { u ->
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { /* Provider may not support persistable permissions. */ }
        }
        configureWeb()
        processNext()
    }

    private fun openDocumentPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/html"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        runCatching { startActivityForResult(intent, openDocumentRequestCode) }
            .onFailure {
                // Some OEM document providers are stricter about the MIME filter.
                // Fall back to the generic file picker without changing import parsing.
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, openDocumentRequestCode)
            }
    }

    @Deprecated("Activity result API retained for compatibility with the existing Activity architecture")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != openDocumentRequestCode) return
        if (resultCode != RESULT_OK || data == null) { finish(); return }
        files.clear()
        data.data?.let { files.add(it) }
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri.let { if (!files.contains(it)) files.add(it) }
        }
        if (files.isEmpty()) { finish(); return }
        files.forEach { uri ->
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        configureWeb()
        processNext()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWeb() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) web.settings.safeBrowsingEnabled = true
        android.webkit.CookieManager.getInstance().setAcceptCookie(false)
        // Imported HTML is untrusted. Do not expose a JavascriptInterface/native bridge to it;
        // extraction results are read back through evaluateJavascript instead.
        web.webViewClient = object : RovexSafeWebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, request: android.webkit.WebResourceRequest?): Boolean = true
            override fun onPageFinished(v: WebView?, url: String?) {
                val pending = pendingWebExtraction ?: return
                v?.evaluateJavascript("window.__rovexImportResult=null;" + HtmlImportWebExtractor.EXTRACT_JS, null)
                scheduleWebExtractionResultRead(v, pending, android.os.SystemClock.elapsedRealtime())
            }
        }
    }


    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    private fun setImportProgress(value:Int, label:String?=null){
        runOnUiThread{
            if(isFinishing||isDestroyed)return@runOnUiThread
            val p=value.coerceIn(0,100);progress.progress=p;progressPercent.text="$p%";if(!label.isNullOrBlank())status.text=label
        }
    }

    private fun addSectionProgress(title:String, percent:Int, detail:String){
        runOnUiThread{
            if(isFinishing||isDestroyed)return@runOnUiThread
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@HtmlImportActivity));cornerRadius=dp(12).toFloat()}}
            row.addView(TextView(this@HtmlImportActivity).apply{text=title;textSize=13f;typeface=android.graphics.Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@HtmlImportActivity));maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END})
            val line=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val bar=ProgressBar(this@HtmlImportActivity,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=percent.coerceIn(0,100)}
            line.addView(bar,LinearLayout.LayoutParams(0,dp(7),1f).apply{setMargins(0,dp(5),dp(8),0)})
            line.addView(TextView(this@HtmlImportActivity).apply{text="${percent.coerceIn(0,100)}%";textSize=10.5f;setTextColor(ThemeManager.accent(this@HtmlImportActivity));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(40),dp(24)))
            row.addView(line)
            row.addView(TextView(this@HtmlImportActivity).apply{text=detail;textSize=10.5f;setTextColor(ThemeManager.text(this@HtmlImportActivity));setPadding(0,dp(3),0,0)})
            sectionList.addView(row,0,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,dp(3))})
        }
    }

    private fun addImportEvent(title:String, detail:String){
        addSectionProgress(title, 100, detail)
    }

    private fun updateImportDatabaseProgress(done:Int,total:Int){
        val pct = 45 + ((done.toDouble() / total.coerceAtLeast(1).toDouble()) * 50.0).toInt().coerceIn(0,50)
        setImportProgress(pct, "Writing questions to local database • $done/$total")
        if(done == 1 || done % 100 == 0 || done == total) addImportEvent("Database import", "$done/$total questions committed safely")
    }

    /**
     * The human filename is NOT a QBank identity. Many exports are literally named
     * index.html / qbank.html, so using the display filename as a UNIQUE database key
     * silently made importing a second QBank delete/hide the first one. The document URI
     * is a stable identity for the selected document and keeps same-named QBanks isolated.
     */
    private fun importIdentity(uri: Uri): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(uri.toString().toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return "rvx-uri-$digest"
    }

    private fun commitBundle(
        importKey: String,
        displayName: String,
        provider: String,
        tests: List<ImportedTest>
    ): Int {
        val repository = (application as LocalQBankApplication).appContainer.newHtmlImportRepository()
        return try {
            repository.importBundle(
                importKey, displayName, provider, tests,
                onProgress = { done, total -> updateImportDatabaseProgress(done, total) },
                onReplacementProgress = { deleted, total ->
                    if (total > 0) {
                        val pct = 40 + ((deleted.toDouble() / total.toDouble()) * 5.0).toInt().coerceIn(0, 5)
                        setImportProgress(pct, "Finishing previous QBank deletion • $deleted/$total old questions removed")
                    } else {
                        setImportProgress(40, "Finishing previous QBank deletion…")
                    }
                }
            )
        } finally {
            repository.close()
        }
    }

    private fun processNext() {
        if (index >= files.size) {
            progress.visibility = View.GONE
            status.text = "Import complete"
            Toast.makeText(this, "Imported ${files.size} HTML file(s)", Toast.LENGTH_LONG).show()
            setResult(RESULT_OK)
            finish()
            return
        }
        val uri = files[index]
        if (!ImportSecurityPolicy.acceptsImportUri(uri.toString())) {
            status.text = "Skipped: unsupported import URI scheme."
            index++
            processNext()
            return
        }
        val reportedSize = fileSize(uri)
        // Some SAF/cloud providers report no size (or -1 from statSize). Do not treat that
        // as a zero-byte file or route it into readBytes(); stage it with a hard byte cap on
        // the import worker, then choose the parser using the actual copied size.
        if (reportedSize > 0 && !ImportSecurityPolicy.acceptsSize(reportedSize)) {
            status.text = "Skipped: file exceeds the safe import limit (${ImportSecurityPolicy.MAX_HTML_BYTES / (1024L * 1024L)} MB)."
            index++
            processNext()
            return
        }
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = false
        progress.progress=0;progressPercent.text="0%";sectionList.removeAllViews()
        status.text = "Preparing ${index + 1}/${files.size}…"
        val accepted = AppManagers.importer.enqueue(displayName(uri), reportedSize.coerceAtLeast(1L), work = {
            var unknownSizeStage: File? = null
            try {
                val sourceUri: Uri
                val actualSize: Long
                if (reportedSize > 0) {
                    sourceUri = uri
                    actualSize = reportedSize
                } else {
                    val staged = File(cacheDir, "q_import_unknown_${System.currentTimeMillis()}.html")
                    unknownSizeStage = staged
                    copyToFile(uri, staged) { done -> setImportProgress(5 + done * 20 / 100, "Staging document with unknown size… $done%") }
                    actualSize = staged.length()
                    if (!ImportSecurityPolicy.acceptsSize(actualSize)) {
                        throw IllegalArgumentException("The selected document exceeds the safe import limit or contains no readable bytes.")
                    }
                    sourceUri = Uri.fromFile(staged)
                }
                val prefix = openBoundedPrefix(sourceUri, 64 * 1024)
                val detection = UniversalImportAdapterRegistry.detect(displayName(uri), prefix)
                setImportProgress(6, "Source hint: ${detection.provider} • ${detection.strategy}")

                // Marrow/offline combined exports are streamed directly from the content
                // URI. This avoids loading a 20–40+ MB outer HTML document into RAM and,
                // more importantly, avoids scanning thousands of unrelated JS assignments.
                if (looksLikeSrcdocExport(sourceUri, scanWholeFile = actualSize >= LARGE_FILE_LIMIT)) {
                    setImportProgress(8, "Scanning embedded QBank sections…")
                    val marrowTests = parseMarrowSrcdocsFromUri(sourceUri, mediaBaseUri = uri.toString()) { sectionNo, title, questionCount ->
                        addSectionProgress(title, 100, "Section $sectionNo • $questionCount questions parsed")
                        setImportProgress((8 + (lastSrcdocCount.coerceAtLeast(1) * 2)).coerceAtMost(40), "Parsed section $sectionNo • $questionCount questions")
                    }
                    val marrowCount = marrowTests.sumOf { it.questions.size }
                    if (marrowCount > 0) {
                        val sourceName = displayName(uri)
                        val sectionCount = marrowTests.size
                        val expectedSections = lastSrcdocCount
                        val emptySections = marrowTests.count { it.questions.isEmpty() }
                        if (sectionCount >= 1 && emptySections == 0 && (expectedSections == 0 || sectionCount >= expectedSections)) {
                            setImportProgress(42, "Parsed $marrowCount questions • preparing database import…")
                            val count = commitBundle(importIdentity(uri), sourceName, HtmlImportParser.detectProvider(marrowTests, displayName(uri), ""), marrowTests)
                            runOnUiThread {
                                if (!isFinishing && !isDestroyed) {
                                    setImportProgress(100, "Imported $count questions in $sectionCount section(s)")
                                    index++
                                }
                            }
                            return@enqueue
                        }
                    }
                }

                if (actualSize >= LARGE_FILE_LIMIT) {
                    importLargeFile(uri, actualSize, stagedInput = unknownSizeStage)
                } else {
                    setImportProgress(12, "Reading QBank for compatibility extraction…")
                    val text = readSmall(sourceUri, LARGE_FILE_LIMIT)
                    setImportProgress(28, "Extracting questions and sections…")
                    val hasKnownNativePayload = HtmlImportParser.hasKnownNativePayload(text)
                    val nativeTests = if (hasKnownNativePayload) {
                        HtmlImportParser.parseCombinedHtmlNative(text, uri.toString()).map { test ->
                            test.copy(questions = test.questions.map { q -> HtmlImportParser.resolveQuestionMedia(q, uri.toString()) })
                        }
                    } else emptyList()
                    val nativeCount = nativeTests.sumOf { it.questions.size }
                    val tests = if (hasKnownNativePayload && nativeCount > 0) {
                        // A known, statically parseable export stays on the non-executing native
                        // path. Unknown formats or zero-result parses use the compatibility
                        // extractor; there is no arbitrary "more than four means complete" rule.
                        nativeTests
                    } else {
                        setImportProgress(34, "Using compatibility extraction for this QBank format…")
                        extractWithWebView(text, uri.toString()).tests.map { test ->
                            test.copy(questions = test.questions.map { q -> HtmlImportParser.resolveQuestionMedia(q, uri.toString()) })
                        }
                    }
                    val parsedCount = tests.sumOf { it.questions.size }
                    if (parsedCount <= 0) throw IllegalArgumentException("No questions could be extracted from ${displayName(uri)}. The existing QBank was not replaced.")
                    setImportProgress(48, "Writing $parsedCount extracted questions to local database…")
                    val count = commitBundle(importIdentity(uri), displayName(uri), HtmlImportParser.detectProvider(tests, displayName(uri), text), tests)
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) {
                            status.text = "Imported $count questions in ${tests.size} section(s)"
                            index++
                        }
                    }
                }
            } finally {
                unknownSizeStage?.let { runCatching { it.delete() } }
            }
        }, onSuccess = {
            runOnUiThread {
                if (!isFinishing && !isDestroyed) processNext()
            }
        }, onFailure = { error ->
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    status.text = "Import failed: ${error.message ?: "unknown error"}"
                    ProductionCrashReporter.recordNonFatal(error, "HTML_IMPORT", mapOf("file_index" to index.toString()))
                    RovexUndoSnackbar.show(status, "Import failed: ${error.message ?: "unknown error"}", "SKIP"){ index++; processNext() }
                }
            }
        })
        if (!accepted) {
            status.text = "Another import is already running. Please wait…"
        }
    }

    private fun importLargeFile(uri: Uri, size: Long, stagedInput: File? = null) {
        runOnUiThread { status.text = "Large file (${formatMb(size)} MB) — importing without loading it into memory…" }
        val tmp = stagedInput ?: File(cacheDir, "q_import_${System.currentTimeMillis()}.html")
        val ownsStagedFile = stagedInput == null
        try {
            if (ownsStagedFile) copyToFile(uri, tmp) { done -> setImportProgress(5 + done * 20 / 100, "Staging large QBank safely… $done%") }
            setImportProgress(28, "Streaming questions from staged QBank…")
            addImportEvent("Streaming engine", "Large-file mode active: parsing and writing incrementally")
            // Preflight the complete stream before creating/replacing a database source.
            // Previously beginStreamingImport() deleted the existing source first, and a
            // scanner that found an unsupported array shape could emit zero questions yet
            // still call finish(true), leaving a successfully reported empty QBank.
            // The first pass is read-only and validates both the data-array boundary and
            // at least one normalized question before any destructive DB operation.
            var validatedQuestions = 0
            setImportProgress(28, "Validating large QBank structure before database changes…")
            val preflightScanner = LargeHtmlScanner(
                tmp,
                onStage = { stage ->
                    setImportProgress(28, "$stage • $validatedQuestions valid questions found…")
                }
            ) { _, _ ->
                validatedQuestions++
                if (validatedQuestions % 250 == 0) {
                    setImportProgress(28, "Validating large QBank • $validatedQuestions valid questions found…")
                }
            }
            val validatedCount = try {
                preflightScanner.scan()
            } catch (unsupported: Exception) {
                if (size <= LARGE_COMPATIBILITY_FALLBACK_LIMIT) {
                    importLargeCompatibilityFallback(uri, tmp, size, unsupported)
                    return
                }
                throw IllegalArgumentException(
                    "This HTML export uses a structure the streaming parser cannot safely recognise at this size. " +
                        "The existing QBank was not replaced. Scanner diagnostics: ${preflightScanner.diagnosticsSummary}.",
                    unsupported
                )
            }
            if (validatedCount <= 0) {
                if (size <= LARGE_COMPATIBILITY_FALLBACK_LIMIT) {
                    importLargeCompatibilityFallback(uri, tmp, size, null)
                    return
                }
                throw IllegalArgumentException(
                    "No valid questions were detected in this large HTML file. The existing QBank was not replaced. " +
                        "Scanner diagnostics: ${preflightScanner.diagnosticsSummary}. " +
                        "This file exceeds the bounded compatibility-fallback budget; provide a supported export structure or split the file."
                )
            }
            setImportProgress(30, "Validated $validatedCount questions • preparing safe database import…")

            val repository = (application as LocalQBankApplication).appContainer.newHtmlImportRepository()
            var session: QBankDb.StreamingImportSession? = null
            var imported = 0
            var currentSection: String? = null
            try {
                val activeSession = repository.beginStreamingImport(
                    importIdentity(uri),
                    displayName(uri),
                    "HTML QBank"
                ) { deleted, total ->
                    if (total > 0) {
                        val pct = 30 + ((deleted.toDouble() / total.toDouble()) * 4.0).toInt().coerceIn(0, 4)
                        setImportProgress(pct, "Finishing previous QBank replacement • $deleted/$total old questions removed")
                    } else {
                        setImportProgress(31, "Preparing database transaction…")
                    }
                }
                session = activeSession
                setImportProgress(35, "Writing validated questions to local database…")
                val writtenCount = LargeHtmlScanner(tmp) { section, q ->
                    if (currentSection != null && currentSection != section) activeSession.commitSection()
                    currentSection = section
                    activeSession.addQuestion(section, HtmlImportParser.resolveQuestionMedia(q, uri.toString()))
                    imported++
                    if (imported % 50 == 0) {
                        val pct = (35 + imported.toLong() * 57L / validatedCount.coerceAtLeast(1)).toInt().coerceIn(35, 92)
                        setImportProgress(pct, "Importing questions • $imported/$validatedCount written")
                    }
                }.scan()
                if (writtenCount <= 0 || imported <= 0) {
                    throw IllegalArgumentException("The validated QBank produced no database rows. Import cancelled instead of saving an empty bank.")
                }
                if (writtenCount != validatedCount || imported != validatedCount) {
                    throw IllegalStateException("Import validation mismatch: found $validatedCount questions but wrote $imported. The partial import was rolled back.")
                }
                activeSession.finish(true)
                session = null
                runOnUiThread {
                    setImportProgress(100, "Imported $imported questions successfully")
                    addImportEvent("Import complete", "$imported questions validated and written")
                    index++
                }
            } catch (t: Exception) {
                runCatching { session?.abort() }
                throw t
            } finally {
                repository.close()
            }
        } finally {
            // The staged HTML can be hundreds of MB. Never leave it in app cache after an
            // import failure/success; this was a direct contributor to the 333 MB cache observed
            // on the device.
            if (ownsStagedFile) runCatching { tmp.delete() }
        }
    }

    /**
     * Compatibility fallback for unsupported 40–64 MiB exports. It is invoked only after
     * the read-only streaming preflight found no usable supported payload, before any source
     * replacement begins. Larger files remain streaming-only to avoid a potentially unsafe
     * full-document WebView/JSON allocation.
     */
    private fun importLargeCompatibilityFallback(uri: Uri, stagedFile: File, size: Long, cause: Throwable?) {
        setImportProgress(30, "Streaming parser could not recognise this ${formatMb(size)} MB export • trying compatibility extraction…")
        if (cause != null) android.util.Log.w("HtmlImportActivity", "Large HTML compatibility fallback", cause)
        val html = readSmall(Uri.fromFile(stagedFile), LARGE_COMPATIBILITY_FALLBACK_LIMIT)
        val payload = extractWithWebView(html, uri.toString())
        val tests = payload.tests.map { test ->
            test.copy(questions = test.questions.map { q -> HtmlImportParser.resolveQuestionMedia(q, uri.toString()) })
        }
        val questionCount = tests.sumOf { it.questions.size }
        if (questionCount <= 0) {
            throw IllegalArgumentException("Neither the streaming nor compatibility parser found valid questions. The existing QBank was not replaced.")
        }
        setImportProgress(48, "Writing $questionCount compatibility-extracted questions…")
        val count = commitBundle(importIdentity(uri), displayName(uri), HtmlImportParser.detectProvider(tests, displayName(uri), html), tests)
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                setImportProgress(100, "Imported $count questions from large HTML export")
                addImportEvent("Compatibility import", "$count questions extracted and committed")
                index++
            }
        }
    }

    private fun looksLikeSrcdocExport(uri: Uri, scanWholeFile: Boolean = false): Boolean {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                val marker = Pattern.compile("srcdoc\\s*=", Pattern.CASE_INSENSITIVE)
                val buffer = ByteArray(64 * 1024)
                var carry = ""
                var bytesRead = 0L
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    bytesRead += n
                    val chunk = carry + String(buffer, 0, n, Charsets.UTF_8)
                    if (marker.matcher(chunk).find()) return@use true
                    carry = chunk.takeLast(32)
                    if (!scanWholeFile && bytesRead >= 1024L * 1024L) return@use false
                }
                false
            } ?: false
        } catch (e: Exception) {
            android.util.Log.w("HtmlImportActivity", "Unable to inspect srcdoc marker: ${e.message}")
            false
        }
    }

    /**
     * Streaming srcdoc extractor. It reads the outer HTML line-by-line and keeps only
     * one embedded document in memory at a time. Marrow encodes quotes inside srcdoc
     * as &quot;, so the attribute delimiter is safe to use as the boundary.
     */
    private class CountingInputStream(input:InputStream, private val total:Long, private val onProgress:(Int)->Unit):FilterInputStream(input){
        private var done=0L;private var last=-1
        override fun read():Int{val n=super.read();if(n>=0)tick(1);return n}
        override fun read(b:ByteArray,off:Int,len:Int):Int{val n=super.read(b,off,len);if(n>0)tick(n.toLong());return n}
        private fun tick(n:Long){done+=n;if(total>0){val p=(done*100/total).toInt().coerceIn(0,100);if(p!=last){last=p;onProgress(p)}}}
    }

    private fun parseMarrowSrcdocsFromUri(
        uri: Uri,
        mediaBaseUri: String = uri.toString(),
        onSection: (Int,String,Int)->Unit = {_,_,_->}
    ): List<ImportedTest> {
        val out = mutableListOf<ImportedTest>()
        lastSrcdocCount = 0
        val total=fileSize(uri)
        contentResolver.openInputStream(uri)?.use { raw ->
            val input=CountingInputStream(raw,total){p->setImportProgress(5 + (p * 30 / 100),"Reading QBank structure • $p%") }
            BufferedReader(InputStreamReader(input, Charsets.UTF_8), 64 * 1024).use { reader ->
                val attr = Pattern.compile("srcdoc\\s*=\\s*([\\\"'])", Pattern.CASE_INSENSITIVE)
                while (true) {
                    val line = reader.readLine() ?: break
                    val m = attr.matcher(line)
                    if (!m.find()) continue
                    val quote = m.group(1)?.firstOrNull() ?: continue
                    val content = StringBuilder()
                    var tail = line.substring(m.end())
                    var closed = false
                    while (true) {
                        val close = tail.indexOf(quote)
                        if (close >= 0) {
                            content.append(tail, 0, close)
                            closed = true
                            break
                        }
                        content.append(tail).append('\n')
                        tail = reader.readLine() ?: break
                    }
                    if (!closed || content.isEmpty()) continue

                    val decoded = HtmlImportParser.decodeHtmlEntitiesPreserveMarkup(content.toString())
                    val title = Regex("<title\\s*>\\s*(.*?)\\s*</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                        .find(decoded)?.groupValues?.getOrNull(1)?.replace(Regex("\\s+"), " ")?.trim()
                        ?.takeIf { it.isNotBlank() } ?: "Marrow Section ${out.size + 1}"
                    val parsed = HtmlImportParser.parseNamedQuestionsAssignments(decoded, title)
                    val questions = parsed.sumOf { it.questions.size }
                    if (questions > 0) {
                        // Count question-bearing embedded documents, not every srcdoc iframe.
                        // Help/metadata iframes must not make a valid export fail its section-count check.
                        lastSrcdocCount++
                        onSection(lastSrcdocCount, title, questions)
                        out.addAll(parsed)
                    }
                }
            }
        } ?: error("Cannot open $uri")
        return HtmlImportParser.dedupeImportedTests(out).map { test ->
            test.copy(questions = test.questions.map { q -> HtmlImportParser.resolveQuestionMedia(q, mediaBaseUri) })
        }
    }

    /** Reads only a bounded signature prefix; never buffers an entire selected export. */
    private fun openBoundedPrefix(uri: Uri, maxBytes: Int): String {
        return try {
            val input = if (uri.scheme == "file") FileInputStream(uri.path ?: return "") else contentResolver.openInputStream(uri)
            input?.use {
                val buffer = ByteArray(maxBytes.coerceAtLeast(1))
                val count = it.read(buffer)
                if (count <= 0) "" else String(buffer, 0, count, Charsets.UTF_8)
            }.orEmpty()
        } catch (_: Exception) { "" }
    }

    private fun fileSize(uri: Uri): Long {
        try { contentResolver.openFileDescriptor(uri, "r")?.use { if (it.statSize > 0) return it.statSize } }
        catch (e: Exception) { android.util.Log.w("HtmlImportActivity", "Unable to inspect URI descriptor size: ${e.message}") }
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                val column = c.getColumnIndex(OpenableColumns.SIZE)
                if (column >= 0 && c.moveToFirst() && !c.isNull(column)) {
                    val size = c.getLong(column)
                    if (size > 0L) return size
                }
            }
        } catch (e: Exception) {
            android.util.Log.w("HtmlImportActivity", "Unable to query URI size: ${e.message}")
        }
        return -1L // Unknown is distinct from an empty document.
    }

    private fun displayName(uri: Uri): String {
        var name: String? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        return name ?: uri.lastPathSegment ?: "Imported QBank.html"
    }

    private fun readSmall(uri: Uri, maxBytes: Long = LARGE_FILE_LIMIT): String {
        contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
                if (total > maxBytes) throw IllegalArgumentException("Document size exceeded the bounded HTML parser limit; retry using the large-file import path.")
                out.write(buffer, 0, n)
            }
            val bytes = out.toByteArray()
            if (bytes.size >= 3 && bytes[0].toInt()==0xEF && bytes[1].toInt()==0xBB && bytes[2].toInt()==0xBF)
                return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
            if (bytes.size >= 2 && bytes[0].toInt()==0xFF && bytes[1].toInt()==0xFE)
                return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            if (bytes.size >= 2 && bytes[0].toInt()==0xFE && bytes[1].toInt()==0xFF)
                return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
            // Most QBank exports are UTF-8; WebView can then resolve relative image URLs
            // against the selected document URI through loadDataWithBaseURL().
            return String(bytes, Charsets.UTF_8)
        } ?: error("Cannot open $uri")
    }

    private fun copyToFile(uri: Uri, dest: File, onProgress: (Int) -> Unit) {
        val total = fileSize(uri)
        var done = 0L
        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    if (done + n > ImportSecurityPolicy.MAX_HTML_BYTES) {
                        throw IllegalArgumentException("Selected HTML exceeds the ${ImportSecurityPolicy.MAX_HTML_BYTES / (1024L * 1024L)} MB safe import limit.")
                    }
                    out.write(buf, 0, n); done += n
                    if (total > 0) onProgress(((done * 100) / total).toInt().coerceIn(0, 100))
                }
                out.fd.sync()
            }
        } ?: error("Cannot open $uri")
    }

    private fun formatMb(v: Long) = String.format(java.util.Locale.US, "%.0f", v / 1048576.0)

    private fun extractWithWebView(html: String, baseUri: String): WebExtractionPayload {
        val gate = DeferredImportGate<WebExtractionPayload>(120, TimeUnit.SECONDS)
        val request = PendingWebExtraction(java.util.UUID.randomUUID().toString(), gate)
        synchronized(webExtractionLock) {
            check(pendingWebExtraction == null) { "Another WebView extraction is already pending" }
            pendingWebExtraction = request
        }
        try {
            runOnUiThread {
                if (isFinishing || isDestroyed) {
                    gate.fail(IllegalStateException("Import screen is no longer active"))
                } else {
                    web.stopLoading()
                    val markerScript = "<script>Object.defineProperty(window,'__rovexImportRequestId',{value:'${request.requestId}',writable:false,configurable:false});window.__rovexImportResult=null;</script>"
                    val headTag = Regex("<head\\b[^>]*>", RegexOption.IGNORE_CASE).find(html)
                    val requestHtml = if (headTag != null) {
                        html.substring(0, headTag.range.last + 1) + markerScript + html.substring(headTag.range.last + 1)
                    } else {
                        "<html><head>$markerScript</head><body>" + html + "</body></html>"
                    }
                    web.loadDataWithBaseURL(baseUri, requestHtml, "text/html", "UTF-8", null)
                }
            }
            val payload = gate.await()
            if (payload.tests.isEmpty() || payload.tests.sumOf { it.questions.size } <= 0) {
                throw IllegalArgumentException("The compatibility extractor found no valid questions")
            }
            runOnUiThread { if (!isFinishing && !isDestroyed) web.stopLoading() }
            return payload
        } finally {
            synchronized(webExtractionLock) {
                if (pendingWebExtraction === request) pendingWebExtraction = null
            }
        }
    }

    private fun scheduleWebExtractionResultRead(
        view: WebView?,
        request: PendingWebExtraction,
        startedAt: Long
    ) {
        if (view == null) {
            request.gate.fail(IllegalStateException("WebView was unavailable during extraction"))
            return
        }
        mainHandler.postDelayed({
            if (pendingWebExtraction !== request || isFinishing || isDestroyed) return@postDelayed
            view.evaluateJavascript("window.__rovexImportResult ? JSON.stringify(window.__rovexImportResult) : null") { encoded ->
                if (pendingWebExtraction !== request) return@evaluateJavascript
                try {
                    val decoded = org.json.JSONTokener(encoded ?: "null").nextValue()
                    val resultJson = decoded as? String
                    if (!resultJson.isNullOrBlank() && resultJson != "null") {
                        val root = org.json.JSONObject(resultJson)
                        val callbackId = root.optString("requestId", "")
                        if (callbackId != request.requestId) {
                            request.gate.fail(IllegalStateException("HTML extraction returned a stale request ID"))
                            return@evaluateJavascript
                        }
                        val tests = HtmlImportParser.parseTests(root.optJSONArray("tests") ?: org.json.JSONArray())
                        val name = root.optString("fileName", "Imported QBank.html")
                        request.gate.complete(WebExtractionPayload(name, tests))
                        return@evaluateJavascript
                    }
                } catch (e: Exception) {
                    request.gate.fail(e)
                    return@evaluateJavascript
                }
                if (android.os.SystemClock.elapsedRealtime() - startedAt >= 115_000L) {
                    request.gate.fail(TimeoutException("HTML extractor did not publish a result within 115 seconds"))
                } else {
                    scheduleWebExtractionResultRead(view, request, startedAt)
                }
            }
        }, 200L)
    }


}
