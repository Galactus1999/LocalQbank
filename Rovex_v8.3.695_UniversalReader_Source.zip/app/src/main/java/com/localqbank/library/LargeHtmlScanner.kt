package com.localqbank.library

import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.EOFException
import java.io.InputStreamReader
import java.util.regex.Pattern
import android.util.Log

/**
 * Streaming parser for very large combined QBank HTML files. It owns no Activity/UI state.
 * One question object is materialized at a time and delivered through the callback.
 */
class LargeHtmlScanner(
    private val file: File,
    private val onStage: ((String) -> Unit)? = null,
    private val onQuestion: (String, ImportedQuestion) -> Unit
) {
    private val seen = HashSet<String>()
    private val maxQuestionChars = 16 * 1024 * 1024
    private var rootQuestionMode = false
    private var genericDataMode = false
    private var emittedQuestions = 0
    private var matchedArrayName: String? = null
    private var candidateArraysFound = 0
    private val candidateArrayNames = LinkedHashSet<String>()

    /** Compact, content-free diagnostics suitable for an import error message. */
    val diagnosticsSummary: String
        get() = "recognized arrays=$candidateArraysFound; names=${candidateArrayNames.joinToString().ifBlank { "none" }}; normalized questions=$emittedQuestions"

    /**
     * Returns the number of normalized, de-duplicated questions emitted by this scan.
     *
     * Prefer explicit combined-QBank arrays (for example TESTS_LIST) over generic arrays
     * such as APP_DATA. Some DAMS exports contain metadata/folder arrays before the actual
     * question payload. Selecting the first syntactically recognized array can therefore
     * produce zero questions even though a valid TESTS_LIST occurs later in the same file.
     * Each tier is attempted only until it emits valid questions; a zero-result tier has no
     * callback side effects, so it is safe to continue to the next candidate tier.
     */
    fun scan(): Int {
        // Preserve the explicit alias priority, but exhaust every assignment of an alias
        // before falling through to the next alias. Some generated HTML pages declare an
        // empty runtime `TESTS_LIST`/`questions` variable before the real export payload.
        // The old implementation inspected only the first matching assignment for each
        // alias, then reread the entire 60–180 MB file for every remaining alias. That made
        // a valid later assignment invisible and turned one import into up to 21 full scans.
        val tiers = PREFERRED_TEST_ARRAY_NAMES.map { setOf(it) } +
            ROOT_QUESTION_ARRAY_NAMES.map { setOf(it) } +
            FALLBACK_DATA_ARRAY_NAMES.map { setOf(it) }
        var foundAnyArray = false
        candidateArraysFound = 0
        candidateArrayNames.clear()
        for (tier in tiers) {
            val alias = tier.single()
            onStage?.invoke("Searching for $alias data array…")
            BufferedReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8), 256 * 1024).use { r ->
                while (seekToDataArray(r, tier)) {
                    foundAnyArray = true
                    candidateArraysFound++
                    val name = matchedArrayName.orEmpty().lowercase()
                    candidateArrayNames.add(name)
                    rootQuestionMode = name in ROOT_QUESTION_ARRAY_NAMES
                    genericDataMode = name in FALLBACK_DATA_ARRAY_NAMES
                    onStage?.invoke("Parsing $name payload…")
                    seen.clear()
                    emittedQuestions = 0

                    // seekToDataArray() consumes the opening '['. Parse this candidate
                    // without materializing the containing array, then consume its closing
                    // bracket before continuing the same reader to a later assignment.
                    while (true) {
                        skipWs(r)
                        val c = peek(r)
                        if (c < 0) break
                        if (c == ']'.code) { r.read(); break }
                        if (c == ','.code) { r.read(); continue }
                        if (c != '{'.code) { skipValue(r); continue }
                        when {
                            rootQuestionMode -> parseRootQuestion(r)
                            genericDataMode -> parseGenericDataObject(r)
                            else -> parseTestObject(r)
                        }
                        skipWs(r)
                        if (peek(r) == ','.code) r.read()
                    }
                    if (emittedQuestions > 0) return emittedQuestions
                    // A recognized but empty/metadata-only array is not proof that the
                    // export contains no questions. Continue searching for another
                    // assignment with the same alias before trying a less-specific alias.
                }
            }
        }
        if (!foundAnyArray) throw IllegalArgumentException("No supported QBank data array found")
        return 0
    }

    private fun seekToDataArray(r: BufferedReader, allowedNames: Set<String>): Boolean {
        // Lexically scan JavaScript code only. Never use a regex to decide whether the
        // current '[' belongs to a supported assignment: this boundary is critical to
        // import correctness and previously failed because regex escaping/rolling windows
        // made the result fragile across revisions.
        val window = StringBuilder()
        var quote = 0
        var escape = false
        var lineComment = false
        var blockComment = false
        val stringToken = StringBuilder()
        var lastStringToken: String? = null
        var pendingPropertyName: String? = null

        while (true) {
            val c = r.read()
            if (c < 0) return false
            val ch = c.toChar()

            if (lineComment) {
                if (ch == '\n' || ch == '\r') {
                    lineComment = false
                    window.setLength(0)
                }
                continue
            }
            if (blockComment) {
                if (ch == '*' && peek(r) == '/'.code) {
                    r.read()
                    blockComment = false
                    window.setLength(0)
                }
                continue
            }
            if (quote != 0) {
                if (escape) {
                    if (ch != '\n' && ch != '\r') stringToken.append(ch)
                    escape = false
                } else if (ch == '\\') {
                    escape = true
                } else if (ch.code == quote) {
                    quote = 0
                    lastStringToken = stringToken.toString()
                    stringToken.setLength(0)
                } else {
                    stringToken.append(ch)
                }
                continue
            }

            if (ch == '/' && peek(r) == '/'.code) {
                r.read()
                lineComment = true
                window.setLength(0)
                continue
            }
            if (ch == '/' && peek(r) == '*'.code) {
                r.read()
                blockComment = true
                window.setLength(0)
                continue
            }
            if (ch == '"' || ch == '\'' || ch == '`') {
                quote = ch.code
                stringToken.setLength(0)
                lastStringToken = null
                pendingPropertyName = null
                window.setLength(0)
                continue
            }

            if (ch == ':') {
                val quotedKey = lastStringToken
                val unquotedKey = window.toString().trimEnd().takeLastWhile { isIdentifierPart(it) }
                val key = quotedKey ?: unquotedKey.takeIf { it.isNotEmpty() }
                pendingPropertyName = key?.lowercase()?.takeIf { it in allowedNames }
                lastStringToken = null
                window.setLength(0)
                continue
            }

            if (ch == '[') {
                assignmentName(window.toString(), allowedNames)?.let { name ->
                    matchedArrayName = name.lowercase()
                    return true
                }
                pendingPropertyName?.let { name ->
                    matchedArrayName = name
                    return true
                }
                pendingPropertyName = null
            } else if (!ch.isWhitespace()) {
                lastStringToken = null
                if (pendingPropertyName != null) pendingPropertyName = null
            }

            window.append(ch)
            if (window.length > 512) {
                window.delete(0, window.length - 512)
            }
        }
    }

    /**
     * Exact, regex-free recognition of the assignment immediately before '['.
     *
     * Accepted forms include:
     *   TESTS_LIST = [
     *   const TESTS_LIST = [
     *   let
     *       questionData
     *       = [
     *   window.QUESTIONS_DATA = [
     *
     * The lexical scanner has already discarded comments and quoted strings.
     */
    private fun assignmentName(candidate: String, allowedNames: Set<String>): String? {
        val left = candidate.substringBeforeLast('=').trimEnd()
        if (left == candidate) return null

        var i = left.length - 1
        while (i >= 0 && isIdentifierPart(left[i])) i--
        if (i == left.length - 1) return null

        val name = left.substring(i + 1)
        if (name.lowercase() !in allowedNames) return null

        var prefix = left.substring(0, i + 1).trimEnd()
        if (prefix.endsWith("window.")) {
            prefix = prefix.removeSuffix("window.").trimEnd()
        }

        // HTML may precede inline JavaScript, e.g. "<script>const TESTS_LIST".
        // Keep only the syntactic tail after the nearest markup boundary.
        prefix = prefix.substringAfterLast('>').trim()

        if (prefix.isEmpty()) return name

        // Permit declaration keywords with arbitrary whitespace/newlines and JavaScript
        // automatic-semicolon-insertion boundaries. Some DAMS exports place the payload
        // immediately after a function/initializer block without a semicolon, e.g.
        // `function init() {} const TESTS_LIST = [...]`. Restricting this to the tail after
        // the last semicolon silently rejects that real assignment, causing the large-file
        // preflight to report zero questions even though the small-file parser finds them.
        // A closing brace or line break is also a valid boundary for this declaration tail.
        val declarationTail = prefix.substringAfterLast(';').substringAfterLast('}').trim()
        val declaration = declarationTail.lineSequence().lastOrNull()?.trim().orEmpty()
        return declaration
            .takeIf { it == "const" || it == "let" || it == "var" }
            ?.let { name }
    }

    private fun isIdentifierPart(ch: Char): Boolean =
        ch.isLetterOrDigit() || ch == '_' || ch == '$'

    private companion object {
        // Prefer named combined-test payloads before root question arrays and generic
        // application metadata. This avoids stopping at an earlier APP_DATA array that
        // contains folder metadata but no question objects.
        // Lists preserve preference order. Generic runtime names such as `tests`,
        // `questions`, and `items` are deliberately last because HTML applications often
        // declare them as empty UI state before the actual export payload.
        val PREFERRED_TEST_ARRAY_NAMES = listOf(
            "tests_list", "test_list", "testlist", "test_data", "testdata", "tests",
            "quiz_data", "quizdata", "quiz_list", "quizlist", "quizzes",
            "exam_data", "examdata", "exam_list", "examlist", "papers",
            "paper_data", "question_sets", "question_sets_data", "assessment_data",
            "assessments", "export_data", "quizbank", "quiz_bank", "qbank_export",
            "qbankexport", "question_bank_export", "questionbank_export", "questionbankexport",
            "question_bank_json", "questionbankjson", "exam_papers"
        )
        val ROOT_QUESTION_ARRAY_NAMES = listOf(
            "questions_data", "questionsdata", "questiondata", "questions_json",
            "question_data", "questionbankdata", "questionbank", "qbankdata", "question_set",
            "questions_list", "question_list", "questionlist", "questions", "items",
            "question_bank", "question_bank_data", "quiz_questions", "exam_questions",
            "questionnaire_data", "questionnaire", "qbank", "qbank_data",
            "exam_data", "examdata", "assessment_data",
            "question_sets", "export_data", "quizbank", "quiz_bank", "qbank_export",
            "qbankexport", "question_bank_export", "questionbank_export", "questionbankexport",
            "question_bank_json", "questionbankjson", "exam_papers"
        )
        val FALLBACK_DATA_ARRAY_NAMES = listOf("app_data", "appdata", "data", "payload")
    }

    private fun parseRootQuestion(r: BufferedReader) {
        try {
            val raw=readObject(r)
            if (raw.length > maxQuestionChars) return
            val o=org.json.JSONObject(raw)
            val q=normalize(o) ?: return
            val key="Imported Section|"+(q.sourceId ?: "")+"|"+q.text.take(180)
            if (seen.add(key)) {
                onQuestion("Imported Section", q)
                emittedQuestions++
            }
        } catch (e: Exception) {
            // Malformed card data is recoverable. Logging must not turn a recoverable parse
            // failure into a JVM-unit-test crash when Android framework stubs are present.
            runCatching {
                android.util.Log.w("LargeHtmlScanner", "Malformed streamed question skipped: ${e.message}")
            }
            runCatching { ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "LargeHtmlScanner.question_skipped") }
        }
    }

    /**
     * Compatibility fallback for legacy APP_DATA arrays whose questions are nested under
     * folders/lessons rather than directly under a test object's `questions` property.
     * The ordinary TESTS_LIST and root-question paths remain streaming question-by-question.
     * Here only one top-level data object is materialized at a time, with the existing
     * bounded object-size guard; recursive schema recognition is delegated to the same
     * HtmlImportParser walker used by the regular importer.
     */
    private fun parseGenericDataObject(r: BufferedReader) {
        try {
            val raw = readObject(r)
            if (raw.length > maxQuestionChars) return
            val root = org.json.JSONObject(raw)
            // Some providers put question records directly in a generic `data`/`payload`
            // array, while others nest them under folders/tests. Support both shapes.
            val directQuestion = normalize(root)
            if (directQuestion != null) {
                val key = "Imported Section|" + (directQuestion.sourceId ?: "") + "|" + directQuestion.text.take(180)
                if (seen.add(key)) {
                    onQuestion("Imported Section", directQuestion)
                    emittedQuestions++
                }
                return
            }
            val tests = HtmlImportParser.walkStrictJson(root, listOf("Imported Section"))
            for (test in tests) {
                val section = test.title.ifBlank { "Imported Section" }
                for (q in test.questions) {
                    val key = section + "|" + (q.sourceId ?: "") + "|" + q.text.take(180)
                    if (seen.add(key)) {
                        onQuestion(section, q)
                        emittedQuestions++
                    }
                }
            }
        } catch (e: Exception) {
            runCatching {
                android.util.Log.w("LargeHtmlScanner", "Malformed generic QBank data skipped: ${e.message}")
            }
        }
    }

    private fun parseTestObject(r: BufferedReader, depth: Int = 0) {
        if (depth >= 8) { skipValue(r); return }
        expect(r, '{')
        var title = "DAMS PYQ"
        while (true) {
            skipWs(r)
            val c = peek(r)
            if (c == '}'.code) { r.read(); return }
            if (c == ','.code) { r.read(); continue }
            if (c != '"'.code) { skipValue(r); continue }
            val key = readString(r)
            skipWs(r); expect(r, ':'); skipWs(r)
            when (key.lowercase()) {
                "title", "name", "subject", "section", "chapter", "lesson", "test_name", "testname" -> {
                    val v = readSimpleStringOrValue(r)
                    if (v.isNotBlank() && v.length < 150) title = v
                }
                "questions", "items", "question_list", "questionlist", "question_data", "questiondata",
                "question_list_data", "questionlistdata", "mcqs", "question_items", "questionitems",
                "questionnaire", "answer_items", "quiz_questions", "exam_questions" ->
                    parseQuestionsArray(r, title)
                // DAMS/paper exports frequently wrap the real questions one or more levels
                // below paper_data / test_data / data. The old scanner treated these keys
                // as opaque values, so it recognized `paper_data` at the top level but
                // emitted zero questions. Recurse only through known container keys; keep
                // unrelated metadata streaming-skipped and never materialize the whole file.
                "paper_data", "paperdata", "test_data", "testdata", "quiz_data", "quizdata",
                "data", "payload", "question_bank", "questionbank", "question_set", "question_set_data",
                "paper_questions", "paperquestions", "question_paper", "questionpaper", "subject_data", "subjectdata",
                "chapter_data", "chapterdata", "lesson_data", "lessondata", "content", "children", "nodes",
                "sections", "tests", "test", "papers", "exams", "quiz", "results", "exam_data", "examdata" ->
                    parseQuestionContainer(r, title, depth + 1)
                else -> skipValue(r)
            }
        }
    }

    private fun parseQuestionContainer(r: BufferedReader, section: String, depth: Int) {
        if (depth >= 8) { skipValue(r); return }
        skipWs(r)
        when (peek(r)) {
            '['.code -> {
                r.read()
                while (true) {
                    skipWs(r)
                    when (peek(r)) {
                        -1 -> return
                        ']'.code -> { r.read(); return }
                        ','.code -> r.read()
                        '{'.code -> parseTestObject(r, depth + 1)
                        else -> skipValue(r)
                    }
                }
            }
            '{'.code -> parseTestObject(r, depth + 1)
            else -> skipValue(r)
        }
    }

    private fun parseQuestionsArray(r: BufferedReader, section: String) {
        skipWs(r)
        if (peek(r) != '['.code) { skipValue(r); return }
        r.read()
        while (true) {
            skipWs(r)
            val c = peek(r)
            if (c == -1 || c == ']'.code) { if (c == ']'.code) r.read(); return }
            if (c == ','.code) { r.read(); continue }
            if (c != '{'.code) { skipValue(r); continue }
            val raw = readObject(r)
            if (raw.length <= maxQuestionChars) parseCandidate(raw, section)
        }
    }

    private fun parseCandidate(src: String, section: String) {
        try {
            val o = org.json.JSONObject(src)
            val q = normalize(o) ?: return
            val key = section + "|" + (q.sourceId ?: "") + "|" + q.text.take(180)
            if (seen.add(key)) {
                onQuestion(section, q)
                emittedQuestions++
            }
        } catch (_: Exception) {
            // A malformed/non-JSON object is skipped without aborting the whole import.
        }
    }

    private fun normalize(q: org.json.JSONObject): ImportedQuestion? {
        // Keep explicit JSON null out of every alias chain. JSONObject.NULL is a sentinel,
        // not Kotlin null, so all candidates are inspected through one deterministic helper.
        val text = clean(firstNonNull(q, "raw_text", "text", "question", "stem", "question_text", "questionText", "question_body", "questionBody", "question_html", "questionHtml", "stem_html", "stemHtml", "question_title", "questionTitle", "que", "que_text", "queText"))
        // Keep the streaming importer aligned with HtmlImportParser.parseOptions().
        // DAMS/legacy exports commonly use option_list or optionList; previously the
        // small-file parser accepted these aliases while the large-file scanner silently
        // rejected every question, producing the exact zero-question preflight failure.
        val options = firstNonNull(q, "options", "choices", "answers", "option_list", "optionList", "answer_options", "answerOptions", "option_data", "optionData")
        val opts = mutableListOf<ImportedOption>()
        when (options) {
            is org.json.JSONArray -> {
                for (i in 0 until options.length()) {
                    val x = options.opt(i)
                    if (x is org.json.JSONObject) {
                        val optionText = clean(firstNonNull(x, "text", "value", "option", "option_text", "optionText", "html"))
                        val label = clean(x.opt("label")).ifBlank { "${'A'.code + i}" }
                        opts.add(
                            ImportedOption(
                                label,
                                optionText,
                                x.optBoolean("correct", false) || x.optBoolean("is_correct", false) || x.optBoolean("isCorrect", false)
                            )
                        )
                    } else if (x != null && x != org.json.JSONObject.NULL) {
                        opts.add(ImportedOption("${'A'.code + i}", clean(x), false))
                    }
                }
            }
            is org.json.JSONObject -> {
                val keys = options.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = options.opt(key)
                    if (value != null && value != org.json.JSONObject.NULL) {
                        opts.add(ImportedOption(key, clean(value), false))
                    }
                }
            }
        }

        val ans = clean(firstNonNull(q, "correct_answer", "correctAnswer", "correct_option", "correctOption", "correct", "answer", "ans", "answer_key", "answerKey"))
            .ifBlank { null }
        val ex = clean(firstNonNull(q, "explanation", "solution", "expl", "explanation_text", "explanationText", "solution_text", "solutionText", "answer_explanation", "answerExplanation"))
        val imgs = (
            extractImages(text) +
                extractImagesFromValue(firstNonNull(q, "question_images", "questionImages", "images", "img", "image", "questionImage"))
            ).distinct()
        val exImgs = (
            extractImages(ex) +
                extractImagesFromValue(firstNonNull(q, "explanation_images", "explanationImages", "explanationImage"))
            ).distinct()
        if (text.isBlank() || opts.isEmpty()) return null

        return ImportedQuestion(
            clean(firstNonNull(q, "id", "question_id")).ifBlank { null },
            text,
            clean(firstNonNull(q, "raw_text")).ifBlank { null },
            ans,
            ex.ifBlank { null },
            clean(firstNonNull(q, "bot")).ifBlank { null },
            clean(firstNonNull(q, "video")).ifBlank { null },
            clean(firstNonNull(q, "audio")).ifBlank { null },
            opts,
            imgs,
            exImgs
        )
    }

    private fun firstNonNull(q: org.json.JSONObject, vararg keys: String): Any? {
        for (key in keys) {
            if (!q.has(key) || q.isNull(key)) continue
            val value = q.opt(key)
            if (value != null && value != org.json.JSONObject.NULL) return value
        }
        return null
    }

    private fun clean(v: Any?): String = when (v) {
        null, org.json.JSONObject.NULL -> ""
        is String -> v
        else -> v.toString()
    }

    private fun extractImages(s: String): List<String> {
        val out = LinkedHashMap<String, Boolean>()
        val p = Pattern.compile("<img[^>]+(?:src|data-src|data-original|data-lazy-src)=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
        val m = p.matcher(s)
        while (m.find()) m.group(1)?.let { out[it] = true }
        val srcset = Pattern.compile("""\bsrcset=["']([^"']+)["']""", Pattern.CASE_INSENSITIVE).matcher(s)
        while (srcset.find()) groupSrcset(srcset.group(1), out)
        if (s.trim().startsWith("data:image", true)) out[s.trim()] = true
        return out.keys.toList()
    }

    private fun extractImagesFromValue(value: Any?): List<String> {
        val out = LinkedHashMap<String, Boolean>()
        fun add(v: String) {
            val x = v.trim()
            if (x.isBlank() || x.equals("null", true)) return
            if (x.startsWith("data:image", true) || x.startsWith("http://", true) || x.startsWith("https://", true) || x.startsWith("content://", true) || x.startsWith("file://", true)) out[x] = true
            else extractImages(x).forEach { out[it] = true }
        }
        when (value) {
            is org.json.JSONArray -> for (i in 0 until value.length()) add(value.optString(i))
            is Collection<*> -> value.forEach { add(it?.toString().orEmpty()) }
            else -> add(value?.toString().orEmpty())
        }
        return out.keys.toList()
    }

    private fun groupSrcset(value: String?, out: MutableMap<String, Boolean>) {
        value.orEmpty().split(',').forEach { part ->
            part.trim().split(Regex("\\s+")).firstOrNull()?.takeIf { it.isNotBlank() }?.let { out[it] = true }
        }
    }

    private fun readObject(r: BufferedReader): String {
        val out = StringBuilder()
        var depth = 0
        var quote = false
        var escape = false
        while (true) {
            val c = r.read()
            if (c < 0) throw EOFException("Unexpected end of QBank JSON")
            out.append(c.toChar())
            if (out.length > maxQuestionChars) throw IllegalArgumentException("Question object is too large")
            if (quote) {
                if (escape) escape = false else if (c == '\\'.code) escape = true else if (c == '"'.code) quote = false
            } else {
                when (c) {
                    '"'.code -> quote = true
                    '{'.code -> depth++
                    '}'.code -> { depth--; if (depth == 0) return out.toString() }
                }
            }
        }
    }

    private fun readSimpleStringOrValue(r: BufferedReader): String {
        skipWs(r)
        return if (peek(r) == '"'.code) readString(r) else {
            val b = StringBuilder()
            while (true) {
                val c = peek(r)
                if (c < 0 || c == ','.code || c == '}'.code) break
                b.append(r.read().toChar())
            }
            b.toString().trim()
        }
    }

    private fun readString(r: BufferedReader): String {
        expect(r, '"')
        val out = StringBuilder()
        var escape = false
        while (true) {
            val c = r.read()
            if (c < 0) throw EOFException("Unterminated JSON string")
            if (escape) {
                out.append(when (c) { 'n'.code -> '\n'; 'r'.code -> '\r'; 't'.code -> '\t'; 'b'.code -> '\b'; 'f'.code -> '\u000C'; else -> c.toChar() })
                escape = false
            } else if (c == '\\'.code) escape = true
            else if (c == '"'.code) return out.toString()
            else out.append(c.toChar())
        }
    }

    private fun skipValue(r: BufferedReader) {
        skipWs(r)
        when (peek(r)) {
            '"'.code -> readString(r)
            '{'.code -> { readContainer(r, '{'.code, '}'.code) }
            '['.code -> { readContainer(r, '['.code, ']'.code) }
            else -> while (true) { val c = peek(r); if (c < 0 || c == ','.code || c == '}'.code || c == ']'.code) break; r.read() }
        }
    }

    private fun readContainer(r: BufferedReader, open: Int, close: Int) {
        var depth = 0; var quote = false; var escape = false
        while (true) {
            val c = r.read(); if (c < 0) throw EOFException("Unexpected end of JSON")
            if (quote) { if (escape) escape = false else if (c == '\\'.code) escape = true else if (c == '"'.code) quote = false; continue }
            if (c == '"'.code) quote = true else if (c == open) depth++ else if (c == close && --depth == 0) return
        }
    }

    private fun skipWs(r: BufferedReader) { while (true) { val c = peek(r); if (c < 0 || !c.toChar().isWhitespace()) return; r.read() } }
    private fun peek(r: BufferedReader): Int { r.mark(1); val c = r.read(); r.reset(); return c }
    private fun expect(r: BufferedReader, ch: Char) { val c = r.read(); if (c != ch.code) throw IllegalArgumentException("Expected '$ch' in QBank data") }
    }

