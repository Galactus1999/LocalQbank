package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper

class FlashcardActivity: Activity() {
    private lateinit var db: FlashcardDb
    private val executor=Executors.newSingleThreadExecutor()
    private val mainHandler=Handler(Looper.getMainLooper())
    private var importControl: ApkgImporter.Control?=null
    private lateinit var list:LinearLayout
    private lateinit var reviewButton:TextView
    private lateinit var bookmarkButton:TextView
    private lateinit var srsSummary:TextView
    private val expanded=mutableSetOf<String>()
    private var deckFilter="ALL"
    private val stateListener:()->Unit={if(!isFinishing && !isDestroyed && ::list.isInitialized)runOnUiThread{render()}}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun rounded(fill:Int,r:Int)=GradientDrawable().apply{setColor(fill);cornerRadius=dp(r).toFloat()}
    private fun semanticFill(kind:String):Int = when(ThemeManager.get(this)) {
        ThemeManager.AMOLED -> when(kind){"primary"->Color.rgb(18,55,70);"secondary"->Color.rgb(18,78,78);"neutral"->Color.rgb(28,30,34);else->Color.rgb(24,44,48)}
        ThemeManager.MIDNIGHT -> when(kind){"primary"->Color.rgb(25,69,96);"secondary"->Color.rgb(18,78,88);"neutral"->Color.rgb(29,42,61);else->Color.rgb(26,54,65)}
        ThemeManager.DARK -> when(kind){"primary"->Color.rgb(25,73,86);"secondary"->Color.rgb(18,91,94);"neutral"->Color.rgb(32,38,45);else->Color.rgb(27,55,60)}
        ThemeManager.SEPIA -> when(kind){"primary"->Color.rgb(120,91,54);"secondary"->Color.rgb(86,122,103);"neutral"->Color.rgb(224,213,188);else->Color.rgb(128,102,64)}
        else -> when(kind){"primary"->Color.rgb(37,113,128);"secondary"->Color.rgb(20,116,105);"neutral"->Color.rgb(229,235,239);else->Color.rgb(225,241,239)}
    }
    private fun button(text:String,fill:Int=semanticFill("primary"),click:()->Unit)=TextView(this).apply{this.text=text;textSize=13.5f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(if(ThemeManager.isDark(this@FlashcardActivity))Color.WHITE else if(fill==semanticFill("neutral"))ThemeManager.text(this@FlashcardActivity) else Color.WHITE);background=GradientDrawable().apply{setColor(fill);cornerRadius=16f*resources.displayMetrics.density;setStroke(dp(1),Color.argb(55,100,120,140))};setOnClickListener{click()}}

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        try {
            SystemUi.immersive(this)
            db=FlashcardDb(this)
            setContentView(build())
        TransitionCoordinator.install(this)
            AppState.register(stateListener)
            safeRender()
            intent.data?.let{importUri(it)}
            if (intent.data==null && ApkgImporter.hasPending(this)) showPendingImport()
        } catch (t:Throwable) {
            val msg=t.message ?: t.javaClass.simpleName
            Toast.makeText(this,"Unable to open Flashcards: $msg",Toast.LENGTH_LONG).show()
            finish()
        }
    }
    override fun onResume(){super.onResume();if(::list.isInitialized)safeRender()}

    private fun build():View {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@FlashcardActivity))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(4),dp(8),dp(4));setBackground(GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(semanticFill("primary"),semanticFill("secondary"))).apply{cornerRadius=16f})}
        val back=TextView(this).apply{text="←";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{finish()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(44),dp(42)))
        val title=TextView(this).apply{text="Flashcards";textSize=21f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)};bar.addView(title,LinearLayout.LayoutParams(0,dp(42),1f));root.addView(bar)
        AdaptiveTypographyManager.apply(root)

        val review=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(12),dp(12),dp(6))}
        reviewButton=button("REVIEW DUE",semanticFill("primary")){startReview(false)}
        bookmarkButton=button("★ BOOKMARKED",semanticFill("secondary")){startReview(true)}
        review.addView(reviewButton,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)});review.addView(bookmarkButton,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)});root.addView(review)
        val studyMenu=button("⚡  STUDY MENU  •  Due / New / Hard / Again / Marked / Custom",semanticFill("primary")){showStudyMenu()};root.addView(studyMenu,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(dp(12),dp(2),dp(12),dp(5))})
        val tools=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),0,dp(12),dp(5))}
        val settings=button("⚙  SRS SETTINGS",Color.rgb(74,82,91)){showSrsSettings()};val stats=button("▣  STATS",Color.rgb(88,70,137)){showStats()}
        tools.addView(settings,LinearLayout.LayoutParams(0,dp(44),1f).apply{setMargins(0,0,dp(4),0)});tools.addView(stats,LinearLayout.LayoutParams(0,dp(44),1f).apply{setMargins(dp(4),0,0,0)});root.addView(tools)
        srsSummary=TextView(this).apply{textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(16),dp(1),dp(16),dp(9));maxLines=2};root.addView(srsSummary)
        val import=button("＋  IMPORT .APKG",semanticFill("primary")){pickApkg()};root.addView(import,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(dp(16),dp(5),dp(16),dp(10))})
        val section=TextView(this).apply{text="DECK LIBRARY";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(16),dp(3),dp(16),dp(4))};root.addView(section)
        val filters=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),0,dp(12),dp(5))}
        listOf("ALL","ADAPTIVE","IMPORTED").forEach{f->
            val chip=TextView(this).apply{
                text=f;textSize=11f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;isClickable=true;isFocusable=true;minHeight=dp(40)
                setTextColor(if(deckFilter==f)Color.WHITE else ThemeManager.text(this@FlashcardActivity))
                background=GradientDrawable().apply{setColor(if(deckFilter==f)semanticFill("primary") else semanticFill("neutral"));cornerRadius=14f*resources.displayMetrics.density;setStroke(dp(1),Color.argb(45,100,120,140))}
                setOnClickListener{selectDeckFilter(f)}
            }
            filters.addView(chip,LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(2),0,dp(2),0)})
        };root.addView(filters)
        val scroll=ScrollView(this).apply{isFillViewport=true};list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(2),dp(12),dp(20))};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));return root
    }

    private fun selectDeckFilter(filter:String){
        deckFilter=filter
        expanded.clear()
        render()
    }

    private fun refreshTop(){if(!::reviewButton.isInitialized)return;reviewButton.text="REVIEW DUE  •  ${db.reviewCount()}";bookmarkButton.text="★ BOOKMARKED  •  ${db.bookmarkCount()}";if(::srsSummary.isInitialized){val s=db.dueStatsAll();srsSummary.text="PENDING  •  Learning ${s.learning}  •  Hard ${s.hard}  •  Good ${s.good}  •  Easy ${s.easy}"}}
    private fun pickApkg(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE);putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/octet-stream","application/zip","application/x-zip-compressed"))},91)}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req==91&&res==RESULT_OK)data?.data?.let{importUri(it)}}
    private fun showPendingImport(){
        AlertDialog.Builder(this).setTitle("Interrupted import found")
            .setMessage("A previous flashcard import did not finish.\n\nProgress: ${ApkgImporter.pendingDescription(this) ?: "checkpoint available"}\n\nYou can safely resume it, or discard the partial import and start again.")
            .setNegativeButton("Discard"){_,_->ApkgImporter.discardPending(this);Toast.makeText(this,"Interrupted import discarded",Toast.LENGTH_SHORT).show()}
            .setPositiveButton("Resume"){_,_->resumeImport()}.show()
    }
    private fun resumeImport(){runImport { control -> ApkgImporter.resume(this,{msg->mainHandler.post{currentImportDialog?.setMessage(msg)}},control) }}
    private var currentImportDialog:AlertDialog?=null
    private fun importUri(uri:android.net.Uri){
        try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Throwable){}
        runImport { control -> ApkgImporter.importFile(this,uri,{msg->mainHandler.post{currentImportDialog?.setMessage(msg)}},control) }
    }
    private fun runImport(job:(ApkgImporter.Control)->ApkgImporter.Result){
        val control=ApkgImporter.Control()
        importControl=control
        val dialog=AlertDialog.Builder(this).setTitle("Importing flashcards")
            .setMessage("Starting…\nThe import can resume if interrupted.").setCancelable(false)
            .setNegativeButton("Cancel import",null).create()
        currentImportDialog=dialog
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                control.cancelled=true
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).isEnabled=false
                dialog.setMessage("Stopping safely at the last checkpoint…")
            }
        }
        dialog.show()
        executor.execute {
            try {
                val r=job(control)
                runOnUiThread {
                    if(!isFinishing){
                        dialog.dismiss(); currentImportDialog=null; importControl=null
                        Toast.makeText(this,"Imported ${r.cards} cards from ${r.decks} deck(s)${if(r.skipped>0)" • skipped ${r.skipped} damaged item(s)" else ""}",Toast.LENGTH_LONG).show()
                        safeRender()
                    }
                }
            } catch(e:Throwable) {
                runOnUiThread {
                    if(!isFinishing){
                        dialog.dismiss(); currentImportDialog=null; importControl=null
                        val pending=ApkgImporter.hasPending(this)
                        AlertDialog.Builder(this)
                            .setTitle(if(control.cancelled)"Import paused safely" else "Import needs attention")
                            .setMessage(if(pending){
                                "The completed batches are safe.\n\n${if(control.cancelled)"The import was cancelled at a checkpoint." else (e.message ?: "An import error occurred.")}\n\nYou can resume from the last checkpoint without starting over."
                            } else (e.message ?: "unsupported or damaged deck"))
                            .setNegativeButton("Close",null)
                            .setPositiveButton("Resume"){_,_->resumeImport()}
                            .show()
                    }
                }
            }
        }
    }

    private data class Node(val name:String,val full:String,val depth:Int,val deck:FlashcardDb.Deck?,val children:MutableList<Node>)
    private fun safeRender(){
        if(!::list.isInitialized)return
        runCatching { render() }.onFailure {
            list.removeAllViews()
            list.addView(TextView(this).apply {
                text="Flashcard library could not be loaded. Your QBank data is unaffected.\n\n${it.javaClass.simpleName}: ${it.message ?: "unknown error"}"
                textSize=14f; setTextColor(ThemeManager.text(this@FlashcardActivity)); setPadding(dp(16),dp(24),dp(16),dp(24))
            })
        }
    }

    private fun render(){if(!::list.isInitialized)return;list.removeAllViews();refreshTop();val decks=db.decks();if(decks.isEmpty()){list.addView(TextView(this).apply{text="No flashcard decks yet. Import an .apkg deck to begin.";textSize=15f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(12),dp(24),dp(12),dp(24))});return};val visibleDecks=decks.filter{deckFilter=="ALL" || if(deckFilter=="ADAPTIVE") it.source?.contains("Adaptive",true)==true else it.source?.contains("Adaptive",true)!=true};if(visibleDecks.isEmpty()){list.addView(TextView(this).apply{text="No decks in this section yet.";textSize=14f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(12),dp(24),dp(12),dp(24))});return};val byFull=visibleDecks.associateBy{it.name};val roots=mutableListOf<Node>();val nodes=HashMap<String,Node>();fun nodeFor(path:String):Node{nodes[path]?.let{return it};val parts=path.split("::");val node=Node(parts.last(),parts.joinToString("::"),parts.size-1,byFull[parts.joinToString("::")],mutableListOf());nodes[node.full]=node;if(parts.size>1){val parent=nodeFor(parts.dropLast(1).joinToString("::"));parent.children.add(node)}else roots.add(node);return node};visibleDecks.forEach{nodeFor(it.name)}
        fun countTree(n:Node):Int=(n.deck?.count?:0)+n.children.sumOf{countTree(it)}
        fun addNode(n:Node){val own=n.deck;val has=n.children.isNotEmpty();val total=countTree(n);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10+n.depth*20),dp(9),dp(10),dp(9));background=GradientDrawable().apply{setColor(if(n.depth==0) semanticFill("neutral") else ThemeManager.elevated(this@FlashcardActivity));cornerRadius=14f}};val arrow=TextView(this).apply{text=if(has){if(expanded.contains(n.full))"▼" else "▶"}else"•";textSize=14f;setTextColor(ThemeManager.accent(this@FlashcardActivity));gravity=Gravity.CENTER};row.addView(arrow,LinearLayout.LayoutParams(dp(28),dp(48)));val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL};body.addView(TextView(this).apply{text=n.name;textSize=if(n.depth==0)17f else 15.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@FlashcardActivity));maxLines=2});body.addView(TextView(this).apply{
                    if(own!=null){
                        val ds=db.dueStats(own.id)
                        text=when {
                            ds.due>0 -> "${own.count} cards  •  ${ds.due} due now  •  Learning ${ds.learning}  •  Hard ${ds.hard}  •  Good ${ds.good}  •  Easy ${ds.easy}"
                            else -> "${own.count} cards  •  0 due now  •  Next reviews are scheduled automatically"
                        }
                    } else text=if(has)"$total cards  •  subdecks" else "Category"
                    textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(3),0,0);maxLines=3
                });row.addView(body,LinearLayout.LayoutParams(0,-2,1f));if(own!=null&&own.count>0){val study=button("STUDY",Color.rgb(35,103,120)){startStudy(own.id)};row.addView(study,LinearLayout.LayoutParams(dp(62),dp(38)).apply{setMargins(dp(6),0,0,0)})};val more=TextView(this).apply{text="⋮";textSize=22f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@FlashcardActivity));setOnClickListener{showDeckActions(n)}};row.addView(more,LinearLayout.LayoutParams(dp(42),dp(42)).apply{setMargins(dp(4),0,0,0)});row.setOnClickListener{if(has){if(expanded.contains(n.full))expanded.remove(n.full)else expanded.add(n.full);render()}else if(own!=null)startStudy(own.id)};row.setOnLongClickListener{showDeckActions(n);true};list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(4),dp(4),dp(4),dp(4))});if(expanded.contains(n.full))n.children.sortedBy{it.name.lowercase()}.forEach{addNode(it)}};roots.sortedBy{it.name.lowercase()}.forEach{addNode(it)}
        AdaptiveTypographyManager.apply(list)
    }

    private fun popupShell(title:String, subtitle:String):LinearLayout{
        return LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(12),dp(18),dp(18))
            setBackgroundColor(ThemeManager.dialogBg(this@FlashcardActivity))
            addView(TextView(this@FlashcardActivity).apply{text=title;textSize=21f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@FlashcardActivity));setPadding(0,dp(2),0,dp(2))})
            addView(TextView(this@FlashcardActivity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(3),0,dp(10))})
        }
    }
    private fun popupSection(parent:LinearLayout,title:String,subtitle:String,fill:Int=ThemeManager.elevated(this),accent:Int=ThemeManager.accent(this)):LinearLayout{
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(11),dp(14),dp(11));background=GradientDrawable().apply{setColor(fill);cornerRadius=14f*resources.displayMetrics.density;setStroke(dp(1),Color.argb(40,110,130,145))}}
        card.addView(TextView(this).apply{text=title;textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(accent)})
        card.addView(TextView(this).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(4),0,0)})
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        return card
    }
    private fun showSheet(title:String, subtitle:String, buildBody:(LinearLayout, Dialog)->Unit){
        val dialog=Dialog(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(14));background=GradientDrawable().apply{setColor(ThemeManager.dialogBg(this@FlashcardActivity));cornerRadius=24f*resources.displayMetrics.density}}
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val titles=LinearLayout(this@FlashcardActivity).apply{orientation=LinearLayout.VERTICAL}
        titles.addView(TextView(this@FlashcardActivity).apply{text=title;textSize=21f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@FlashcardActivity))})
        titles.addView(TextView(this@FlashcardActivity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(3),0,0)})
        head.addView(titles,LinearLayout.LayoutParams(0,-2,1f))
        head.addView(TextView(this).apply{text="×";textSize=26f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@FlashcardActivity));background=rounded(ThemeManager.elevated(this@FlashcardActivity),14);setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(dp(44),dp(44)))
        root.addView(head)
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(10),0,dp(4))}
        buildBody(body,dialog)
        scroll.addView(body)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        dialog.setContentView(root)
        dialog.setOnShowListener{dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),(resources.displayMetrics.heightPixels*0.78f).toInt())}
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),(resources.displayMetrics.heightPixels*0.78f).toInt())
        AdaptiveTypographyManager.apply(root)
    }

    private fun sheetCard(parent:LinearLayout,title:String,subtitle:String,click:(Dialog)->Unit){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));isClickable=true;isFocusable=true;background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@FlashcardActivity));cornerRadius=16f*resources.displayMetrics.density;setStroke(dp(1),Color.argb(45,100,120,140))};setOnClickListener{click(parent.getTag() as? Dialog ?: return@setOnClickListener)}}
        card.addView(TextView(this).apply{text=title;textSize=14.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@FlashcardActivity))})
        card.addView(TextView(this).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(4),0,0)})
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
    }

    private fun showStudyMenu(){
        val specs=arrayOf(
            Triple("Due now","Questions currently scheduled for review • ${db.modeCount("due")}","due"),
            Triple("All cards","Review the complete deck library • ${db.modeCount("all")}","all"),
            Triple("New / unseen","Cards you have not studied yet • ${db.modeCount("unseen")}","unseen"),
            Triple("Hard","Cards repeatedly rated difficult • ${db.modeCount("hard")}","hard"),
            Triple("Again / failed","Cards that need another pass • ${db.modeCount("again")}","again"),
            Triple("Bookmarked","Your saved flashcard bookmarks • ${db.modeCount("bookmarked")}","bookmarked"),
            Triple("Marked","Cards explicitly marked for study • ${db.modeCount("marked")}","marked")
        )
        val limits=intArrayOf(0,0,0,0,0,0,0)
        showSheet("Study menu","A visual study launcher instead of a plain text dialog"){body,dialog->
            body.setTag(dialog)
            specs.forEachIndexed{i,(title,sub,mode)->
                sheetCard(body,title,sub){d->startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",-1L).putExtra("mode",mode).putExtra("limit",limits[i]));d.dismiss()}
            }
            listOf(10 to "10-card sprint",25 to "25-card sprint",50 to "50-card sprint",100 to "100-card sprint").forEach{(limit,label)->
                sheetCard(body,label,"Short focused review block"){d->startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",-1L).putExtra("mode","all").putExtra("limit",limit));d.dismiss()}
            }
        }
    }

    private fun showSrsSettings(){
        val fields=arrayOf("New cards / day","Maximum reviews / day","Again learning delay (minutes)")
        val keys=arrayOf("new_per_day","max_reviews_per_day","learning_again_min")
        val defaults=intArrayOf(30,200,10)
        showSheet("SRS settings","Adaptive review controls stored locally"){body,dialog->
            val inputs=mutableListOf<EditText>()
            fields.indices.forEach{i->{
                val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(11),dp(14),dp(11));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@FlashcardActivity));cornerRadius=15f*resources.displayMetrics.density}}
                card.addView(TextView(this).apply{text=fields[i];textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@FlashcardActivity))})
                card.addView(TextView(this).apply{text=when(i){0->"How many unseen cards may enter review each day.";1->"Maximum scheduled reviews shown per day.";else->"Delay before an Again card becomes available."};textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(4),0,dp(7))})
                val input=EditText(this).apply{inputType=2;setText(db.settingInt(keys[i],defaults[i]).toString());setSingleLine(true);setTextColor(ThemeManager.text(this@FlashcardActivity));background=rounded(ThemeManager.bg(this@FlashcardActivity),10);setPadding(dp(10),0,dp(10),0)}
                card.addView(input,LinearLayout.LayoutParams(-1,dp(44)));inputs.add(input);body.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
            }}
            val save=TextView(this).apply{text="SAVE SETTINGS";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=rounded(ThemeManager.accent(this@FlashcardActivity),14);setOnClickListener{inputs.forEachIndexed{i,v->db.setSetting(keys[i],v.text.toString().toIntOrNull()?.coerceAtLeast(1)?.toString()?:defaults[i].toString())};Toast.makeText(this@FlashcardActivity,"SRS settings saved",Toast.LENGTH_SHORT).show();dialog.dismiss();safeRender()}}
            body.addView(save,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(10),0,dp(4))})
        }
    }

    private fun showStats(){
        val today=db.reviewedToday();val total=db.totalReviews();val due=db.reviewCount();val all=db.modeCount("all")
        showSheet("Flashcard statistics","A quick view of your review engine"){body,_->
            sheetStat(body,"TODAY","Reviewed: $today • Remaining due: $due",ThemeManager.statsFill(this),ThemeManager.statsText(this))
            sheetStat(body,"LIBRARY","Total cards: $all • Total reviews: $total",ThemeManager.elevated(this),ThemeManager.accent(this))
            sheetStat(body,"BOOKMARKS","Bookmarked cards: ${db.bookmarkCount()}",ThemeManager.peacockFill(this),ThemeManager.peacockText(this))
            sheetStat(body,"DAILY LIMITS","New: ${db.settingInt("new_per_day",30)} • Reviews: ${db.settingInt("max_reviews_per_day",200)}",ThemeManager.elevated(this),ThemeManager.accent(this))
        }
    }

    private fun sheetStat(parent:LinearLayout,title:String,text:String,fill:Int,accent:Int){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=GradientDrawable().apply{setColor(fill);cornerRadius=15f*resources.displayMetrics.density}}
        card.addView(TextView(this).apply{this.text=title;textSize=11f;typeface=Typeface.DEFAULT_BOLD;setTextColor(accent);letterSpacing=.06f})
        card.addView(TextView(this).apply{this.text=text;textSize=13.5f;setTextColor(ThemeManager.text(this@FlashcardActivity));setPadding(0,dp(5),0,0)})
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
    }

    private fun startStudy(id:Long){startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",id))}
    private fun startReview(bookmarks:Boolean){startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",-1L).putExtra("bookmarksOnly",bookmarks))}
    private fun showDeckActions(n:Node){
        val own=n.deck
        val hasChildren=n.children.isNotEmpty()
        showSheet(n.name,"Deck actions • ${if(own!=null) "${own.count} cards" else "category"}"){body,dialog->
            body.setTag(dialog)
            if(own!=null) sheetCard(body,"Study deck","Open this deck in the focused reviewer"){d->if(own.count>0)startStudy(own.id)else Toast.makeText(this,"This deck has no cards.",Toast.LENGTH_SHORT).show();d.dismiss()}
            if(hasChildren) sheetCard(body,"Expand / collapse","Show or hide subdecks"){d->if(expanded.contains(n.full))expanded.remove(n.full)else expanded.add(n.full);d.dismiss();safeRender()}
            if(own!=null) sheetCard(body,"Unsuspend cards","Make suspended cards available again"){d->val n2=db.unsuspendDeck(own.id,false);Toast.makeText(this,"Unsuspended $n2 card(s)",Toast.LENGTH_SHORT).show();d.dismiss();safeRender()}
            if(hasChildren && own==null) sheetCard(body,"Unsuspend subdecks","Restore cards across this category"){d->val count=n.children.sumOf{it.deck?.count?:0};n.children.forEach{it.deck?.let{x->db.unsuspendDeck(x.id,false)}};Toast.makeText(this,"Unsuspended cards in $count-card category",Toast.LENGTH_SHORT).show();d.dismiss();safeRender()}
            if(own!=null) sheetCard(body,if(hasChildren)"Delete deck" else "Delete deck","Remove this deck while keeping subdecks if any"){d->confirmDelete(n,false,d)}
            if(hasChildren) sheetCard(body,"Delete category + subdecks","Permanently remove this branch of the flashcard library"){d->confirmDelete(n,true,d)}
        }
    }

    private fun confirmDelete(n:Node,all:Boolean,parent:Dialog){
        val msg=if(all)"Delete ${n.full} and every subdeck? This permanently removes those flashcards from Rovex." else "Delete ${n.full}? Its subdecks will remain."
        AlertDialog.Builder(this).setTitle("Confirm deletion").setMessage(msg).setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->
            val removed=if(all)db.deleteDeckTree(n.full) else n.deck?.let{db.deleteDeck(it.id,false)} ?: 0
            Toast.makeText(this,if(removed>0)"Deleted $removed deck(s)" else "Nothing was deleted",Toast.LENGTH_SHORT).show();parent.dismiss();safeRender()
        }.show()
    }

    override fun onDestroy(){AppState.unregister(stateListener);executor.shutdownNow();if(::db.isInitialized)db.close();super.onDestroy()}
}
