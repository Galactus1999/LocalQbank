package com.localqbank.library

import android.content.Context
import kotlin.math.min

/** Offline-first cognitive layer for Ren. Deterministic, bounded, and QBank-grounded. */
class RenCognitiveEngine(context: Context) {
    private val app = context.applicationContext

    data class Insight(val title: String, val body: String, val actions: List<String> = emptyList())

    fun answer(command: String, currentQuestion: Question? = null): Insight {
        val text = command.trim()
        if (text.isBlank()) return Insight("Ren", "Tell me what you want to study, save, summarise or practise.")
        val lower = text.lowercase()
        return when {
            currentQuestion != null && ("summar" in lower || "explain" in lower || "key point" in lower || "high yield" in lower) -> summarise(currentQuestion)
            "flashcard" in lower || "flash card" in lower ->
                Insight("Flashcards", "I will only create cards when you explicitly ask. Each card keeps the MCQ on the front and reveals only the correct answer option.", listOf("Generate adaptive cards"))
            "note" in lower || "summary" in lower ->
                Insight("Knowledge", "I can turn the current question into a structured note, extracting high-yield points instead of copying the whole explanation.", listOf("Create auto-note"))
            "wrong" in lower || "mistake" in lower -> {
                val ids = AppManagers.studyIntelligence.smartMix(30)
                Insight("Weakness review", "I prepared a local adaptive pool of ${ids.size} questions, prioritising due and weak items.", listOf("Start adaptive mix"))
            }
            "what should i study" in lower || "what should i revise" in lower || "study plan" in lower ->
                Insight("Study plan", AppManagers.adaptive.studyStrategy(), listOf("Open Study Tools"))
            else -> searchQBank(text)
        }
    }

    private fun searchQBank(command: String): Insight {
        val query = command
            .replace(Regex("(?i)\\b(find|search|show|give|open|questions?|qbank|topic|subject|about)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (query.length < 3) return Insight("Ren", "I need a little more detail. Try a subject, topic, or exact clinical term.")
        val match = runCatching { AppManagers.studyIntelligence.matchSubject(query, 50) }.getOrNull()
        if (match != null && match.ids.isNotEmpty()) {
            val refs = PerformanceManager.refs(app)
            val ids = match.ids.toSet()
            val examples = refs.asSequence().filter { it.id in ids }.take(5).map { "Q${it.position + 1} • ${it.testTitle}" }.toList()
            return Insight(
                "QBank search: ${query.replaceFirstChar { it.uppercase() }}",
                "Found ${match.ids.size} matching question${if (match.ids.size == 1) "" else "s"}.\n\n" + examples.joinToString("\n") + "\n\nThe match is grounded in your imported QBank data, not an invented answer.",
                listOf("Open matching questions")
            )
        }
        return Insight("No strong QBank match", "I searched the local question index for “$query” but did not find a strong match. Try a broader term or another spelling.")
    }

    fun summarise(q: Question): Insight {
        val answer = plain(q.correctAnswer ?: q.options.firstOrNull { it.correct }?.label.orEmpty())
        val exp = plain(q.explanation.orEmpty())
        val points = extractKeyPoints(exp)
        val body = buildString {
            if (answer.isNotBlank()) append("Answer: ").append(answer.take(260)).append("\n\n")
            append("Key points\n")
            if (points.isEmpty()) append("Review the original explanation for the full context.")
            else points.forEach { append("• ").append(it).append('\n') }
        }.trim()
        return Insight("Ren's local summary", body, listOf("Save as note", "Create flashcard"))
    }

    fun extractKeyPoints(text: String): List<String> {
        val clean = plain(text)
        if (clean.isBlank()) return emptyList()
        val sentences = clean.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.length >= 35 }
        val markers = listOf("most common", "important", "first line", "gold standard", "diagnosis", "treatment", "management", "contraindication", "adverse", "associated", "classically", "hallmark", "preferred", "mcq", "exam")
        return sentences
            .sortedWith(compareByDescending<String> { s -> markers.count { s.contains(it, true) } }.thenByDescending { s -> min(s.length, 220) })
            .distinct()
            .take(7)
            .map { it.take(220) }
    }

    fun capabilities(): List<String> = listOf("Local QBank search", "Intent detection", "Question summarisation", "Key-point extraction", "Adaptive study planning", "Bounded engine actions")

    private fun plain(html: String): String = android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()
}
