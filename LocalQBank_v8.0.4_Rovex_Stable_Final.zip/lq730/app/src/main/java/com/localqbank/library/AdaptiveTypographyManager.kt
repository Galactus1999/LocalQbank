package com.localqbank.library

import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight typography policy for the existing Views architecture.
 * It adapts only constrained labels/buttons; long-form reading remains user-controlled.
 */
object AdaptiveTypographyManager {
    private const val BASE_TAG = 0x7f0f1001

    fun apply(root: View) {
        root.post { walk(root) }
    }

    private fun walk(v: View) {
        if (v is TextView) tune(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
    }

    private fun tune(v: TextView) {
        val text = v.text?.toString()?.trim().orEmpty()
        if (text.isEmpty() || v.width <= 0) return
        // Preserve deliberate reading sizes and only tune compact UI controls.
        val compact = v.height > 0 && v.height <= dp(v, 58)
        val actionLike = text.length <= 34 && (v.isClickable || v is android.widget.Button)
        val headingLike = text.length <= 42 && (v.typeface?.isBold == true)
        if (!compact && !actionLike && !headingLike) return
        val base = (v.getTag(BASE_TAG) as? Float) ?: v.textSize.also { v.setTag(BASE_TAG, it) }
        val density = v.resources.displayMetrics.density
        val widthDp = v.width / density
        val lengthPressure = when {
            text.length > 44 -> .78f
            text.length > 30 -> .86f
            text.length > 20 -> .93f
            else -> 1f
        }
        val widthPressure = when {
            widthDp < 70f -> .72f
            widthDp < 100f -> .82f
            widthDp < 150f -> .90f
            else -> 1f
        }
        val scale = min(lengthPressure, widthPressure)
        val minPx = sp(v, if (actionLike) 10f else 11f)
        val maxPx = sp(v, min(22f, base / density * 1.08f))
        v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, max(minPx, min(maxPx, base * scale)))
        v.setIncludeFontPadding(false)
    }

    private fun dp(v: View, value: Int) = (value * v.resources.displayMetrics.density).toInt()
    private fun sp(v: View, value: Float) = value * v.resources.displayMetrics.scaledDensity
}
