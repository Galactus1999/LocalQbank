package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*

/** A small local-first Ren workspace. No network/LLM dependency is required. */
class RenActivity : Activity() {
    private var openMatchButton: TextView? = null
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        val scroll=ScrollView(this).apply{setBackgroundColor(ThemeManager.bg(this@RenActivity));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(28))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        bar.addView(TextView(this).apply{text="‹";textSize=34f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@RenActivity));setOnClickListener{finish()}},LinearLayout.LayoutParams(dp(44),dp(48)))
        bar.addView(TextView(this).apply{text="Ren";textSize=24f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@RenActivity))},LinearLayout.LayoutParams(0,dp(48),1f))
        root.addView(bar)
        root.addView(TextView(this).apply{text="Local cognitive assistant";textSize=12f;setTextColor(ThemeManager.muted(this@RenActivity));setPadding(dp(44),0,0,dp(14))})
        val input=EditText(this).apply{hint="Ask Ren: make flashcards from my wrong questions…";textSize=15f;setTextColor(ThemeManager.text(this@RenActivity));setHintTextColor(ThemeManager.muted(this@RenActivity));setSingleLine(false);minLines=2;gravity=Gravity.TOP;setPadding(dp(14),dp(12),dp(14),dp(12));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@RenActivity));cornerRadius=dp(16).toFloat();setStroke(dp(1),ThemeManager.explanationBg(this@RenActivity))}}
        root.addView(input,LinearLayout.LayoutParams(-1,dp(92)))
        val answer=TextView(this).apply{text="Ren is ready. He works with your local QBank and can route useful actions to the study, knowledge and flashcard engines.";textSize=14f;setTextColor(ThemeManager.text(this@RenActivity));setPadding(dp(16),dp(16),dp(16),dp(16));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@RenActivity));cornerRadius=dp(16).toFloat()}}
        root.addView(answer)
        openMatchButton=TextView(this).apply{text="OPEN MATCHING QUESTIONS";textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(Color.WHITE);visibility=android.view.View.GONE;background=GradientDrawable().apply{setColor(ThemeManager.accent(this@RenActivity));cornerRadius=dp(13).toFloat()}}
        root.addView(openMatchButton,LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(8),0,0)})
        val ask=TextView(this).apply{text="Ask Ren";textSize=14f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=GradientDrawable().apply{setColor(ThemeManager.accent(this@RenActivity));cornerRadius=dp(14).toFloat()};setOnClickListener{respond(input,answer)} }
        root.addView(ask,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(10),0,dp(12))})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(16),0,0)}
        listOf("What should I study?","Make flashcards from my wrong questions","Create a note from the current question","Find cardiology questions").forEach{cmd->
            val b=TextView(this).apply{text=cmd;textSize=13f;setTextColor(ThemeManager.text(this@RenActivity));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(14),0);background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@RenActivity));cornerRadius=dp(13).toFloat()};setOnClickListener{input.setText(cmd);respond(input,answer)}}
            actions.addView(b,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,0,0,dp(8))})
        }
        root.addView(actions)
        root.addView(TextView(this).apply{text="Cognitive capabilities\n• intent detection  • local summarisation  • key-point extraction  • adaptive study planning\n\nRen does not invent QBank facts or modify source questions.";textSize=11.5f;setTextColor(ThemeManager.muted(this@RenActivity));setPadding(dp(4),dp(10),dp(4),0)})
        scroll.addView(root);setContentView(scroll); AdaptiveTypographyManager.apply(root)
        TransitionCoordinator.install(this)
    }
    private fun respond(input:EditText,answer:TextView){
        val cmd=input.text?.toString().orEmpty()
        openMatchButton?.visibility=android.view.View.GONE
        if(cmd.isBlank()){answer.text="Tell Ren what you want to do.";return}
        AppManagers.renMemory.putWorking(cmd)
        val lower=cmd.lowercase()
        if (lower.contains("what should i study") || lower.contains("what should i do")) {
            val plans=runCatching { AppManagers.strategy.recommend(20) }.getOrDefault(emptyList())
            answer.text=if(plans.isEmpty()) {
                "Study plan\n\nNo strong priority signal yet. Start with a short mixed block to establish your baseline."
            } else {
                buildString {
                    append("Study plan\n\n")
                    plans.forEachIndexed { i,p -> append("${i+1}. ${p.title}\n${p.reason}\n\n") }
                    append(AdaptiveExplainability.explain(AppManagers.adaptive.state()))
                }.trim()
            }
            AppManagers.renMemory.putStudy(answer.text.toString())
            return
        }
        val insight=runCatching{AppManagers.renCognitive.answer(cmd)}.getOrElse{RenCognitiveEngine.Insight("Ren","I could not complete that request safely. Try a simpler command.")}
        answer.text="${insight.title}\n\n${insight.body}${if(insight.actions.isEmpty())""else"\n\nSuggested: ${insight.actions.joinToString(" • ")}"}"
        if (insight.actions.contains("Open matching questions")) {
            val query=cmd.replace(Regex("(?i)\\b(find|search|show|give|open|questions?|qbank|topic|subject|about)\\b"), " ").replace(Regex("\\s+"), " ").trim()
            val match=runCatching{AppManagers.studyIntelligence.matchSubject(query,100)}.getOrNull()
            if(match!=null && match.ids.isNotEmpty()) {
                openMatchButton?.apply{visibility=android.view.View.VISIBLE;setOnClickListener{startActivity(Intent(this@RenActivity,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",match.ids.joinToString(",")).putExtra("sessionLabel","Ren • $query").putExtra("practiceMode",true).putExtra("title","Ren • $query"))}}
            }
        }
        AppManagers.renMemory.putStudy(answer.text.toString())
    }
}
