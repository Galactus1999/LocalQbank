package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs

/** High-speed, exam-oriented flashcard reviewer with safe offline SRS controls. */
class FlashcardStudyActivity : Activity() {
    private lateinit var db: FlashcardDb
    private lateinit var cardView: WebView
    private lateinit var counter: TextView
    private lateinit var progress: ProgressBar
    private lateinit var bookmark: TextView
    private lateinit var mark: TextView
    private lateinit var reveal: TextView
    private lateinit var ratingRow: LinearLayout
    private lateinit var modeLabel: TextView

    private var deckId = 0L
    private var mode = "due"
    private var position = 0
    private var showingBack = false
    private var reverse = false
    private var shuffle = false
    private var sessionLimit = 0
    private var count = 0
    private var studied = 0
    private var downX = 0f
    private var downY = 0f
    private var startedAt = 0L
    private var elapsedSeconds = 0L
    private var lastRatedCardId = 0L
    private var cardViewDestroyed = false
    private val timerHandler = Handler(Looper.getMainLooper())
    private val timerTick = object : Runnable { override fun run() { if (!isFinishing) { elapsedSeconds=(System.currentTimeMillis()-startedAt)/1000L; updateModeLabel(); timerHandler.postDelayed(this,1000L) } } }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun rounded(fill:Int,r:Int)=android.graphics.drawable.GradientDrawable().apply{setColor(fill);cornerRadius=dp(r).toFloat()}
    private fun button(text:String, fill:Int, click:(TextView)->Unit)=TextView(this).apply{this.text=text;textSize=12.5f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);background=android.graphics.drawable.GradientDrawable().apply{setColor(fill);cornerRadius=dp(14).toFloat()};setOnClickListener{click(this)}}

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        try {
            SystemUi.immersive(this); db=FlashcardDb(this)
            deckId=intent.getLongExtra("deckId",0L)
            mode=intent.getStringExtra("mode") ?: when { intent.getBooleanExtra("bookmarksOnly",false)->"bookmarked"; deckId<0L->"due"; else->"deck" }
            sessionLimit=intent.getIntExtra("limit",0).coerceAtLeast(0)
            reverse=intent.getBooleanExtra("reverse",false); shuffle=intent.getBooleanExtra("shuffle",false)
            position=getPreferences(0).getInt(key("pos"),0).coerceAtLeast(0)
            startedAt=System.currentTimeMillis(); setContentView(build()); show(); timerHandler.post(timerTick)
        } catch(t:Throwable) { Toast.makeText(this,"Unable to open flashcards: ${t.message ?: t.javaClass.simpleName}",Toast.LENGTH_LONG).show(); finish() }
    }
    private fun key(s:String)="${s}_${deckId}_${mode}"
    private fun currentCount():Int { val raw=if(mode=="deck")db.modeCount("all",deckId)else db.modeCount(mode);return if(sessionLimit>0)minOf(raw,sessionLimit)else raw }
    private fun currentCard():FlashcardDb.Card?=if(mode=="deck")db.modeCardAt("all",position,deckId)else db.modeCardAt(mode,position)

    private fun build():LinearLayout {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@FlashcardStudyActivity))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(3),dp(8),dp(3));setBackgroundColor(ThemeManager.bg(this@FlashcardStudyActivity))}
        bar.addView(TextView(this).apply{text="←";textSize=22f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@FlashcardStudyActivity));background=rounded(ThemeManager.elevated(this@FlashcardStudyActivity),12);setOnClickListener{finish()}},LinearLayout.LayoutParams(dp(44),dp(42)))
        counter=TextView(this).apply{textSize=15f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@FlashcardStudyActivity));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(6),0,dp(6),0)}
        modeLabel=TextView(this).apply{textSize=10.5f;setTextColor(ThemeManager.muted(this@FlashcardStudyActivity));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(6),0,dp(6),0);maxLines=2}
        val headerLabels=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL};headerLabels.addView(counter);headerLabels.addView(modeLabel);bar.addView(headerLabels,LinearLayout.LayoutParams(0,dp(46),1f))
        val menu=TextView(this).apply{text="⋮";textSize=24f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@FlashcardStudyActivity));setOnClickListener{showReviewerMenu()}};bar.addView(menu,LinearLayout.LayoutParams(dp(44),dp(42)));root.addView(bar)
        AdaptiveTypographyManager.apply(root)
        progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100};root.addView(progress,LinearLayout.LayoutParams(-1,dp(4)))
        cardView=WebView(this).apply{
            settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.allowFileAccess=true;settings.allowContentAccess=true;settings.loadsImagesAutomatically=true;settings.cacheMode=WebSettings.LOAD_DEFAULT
            webViewClient=object:WebViewClient(){
                // A killed WebView renderer process would otherwise crash the whole app.
                // Recover by tearing down this view and closing the session safely instead.
                override fun onRenderProcessGone(view:WebView?,detail:android.webkit.RenderProcessGoneDetail?):Boolean {
                    runCatching { view?.destroy() }; cardViewDestroyed=true
                    if(!isFinishing){ Toast.makeText(this@FlashcardStudyActivity,"The card renderer crashed. Closing this session to keep the app stable.",Toast.LENGTH_LONG).show(); finish() }
                    return true
                }
            }
            setBackgroundColor(ThemeManager.elevated(this@FlashcardStudyActivity))
            setOnTouchListener{_,e->when(e.actionMasked){MotionEvent.ACTION_DOWN->{downX=e.rawX;downY=e.rawY;false};MotionEvent.ACTION_UP->{val dx=e.rawX-downX;val dy=e.rawY-downY;if(abs(dx)>dp(140)&&abs(dx)>abs(dy)*1.5f){if(dx>0)previousCard()else nextCard();true}else false};else->false}}
            setOnClickListener{if(!showingBack){showingBack=true;show()}}
        }
        root.addView(cardView,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(dp(10),dp(8),dp(10),dp(5))})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(10),0,dp(10),0)}
        bookmark=button("☆",Color.rgb(88,70,137)){currentCard()?.let{bookmark.text=if(db.toggleBookmarked(it.id))"★"else"☆"}}
        mark=button("⚑",Color.rgb(90,92,100)){currentCard()?.let{mark.text=if(db.toggleMarked(it.id))"⚑"else"⚐"}}
        val info=button("ⓘ",Color.rgb(68,86,100)){showCardInfo()};val skip=button("SKIP",Color.rgb(70,78,86)){nextCard()}
        actions.addView(bookmark,LinearLayout.LayoutParams(dp(56),dp(44)).apply{setMargins(0,0,dp(4),0)});actions.addView(mark,LinearLayout.LayoutParams(dp(56),dp(44)).apply{setMargins(dp(4),0,dp(4),0)});actions.addView(info,LinearLayout.LayoutParams(dp(56),dp(44)).apply{setMargins(dp(4),0,dp(4),0)});actions.addView(skip,LinearLayout.LayoutParams(0,dp(44),1f).apply{setMargins(dp(4),0,0,0)});root.addView(actions)
        reveal=button("SHOW ANSWER",Color.rgb(35,103,120)){showingBack=true;show()};root.addView(reveal,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(dp(10),dp(5),dp(10),dp(5))})
        ratingRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(10),0,dp(10),dp(10));visibility=LinearLayout.GONE}
        val ratingLabels=arrayOf("AGAIN\n${db.settingInt("learning_again_min",10)}m","HARD\n1d","GOOD\n3d","EASY\n7d");val fills=intArrayOf(Color.rgb(160,65,65),Color.rgb(151,112,45),Color.rgb(35,103,120),Color.rgb(88,70,137))
        for(i in 0..3){val r=button(ratingLabels[i],fills[i]){if(it.isEnabled){it.isEnabled=false;rateAndNext(i+1)}};r.textSize=11f;ratingRow.addView(r,LinearLayout.LayoutParams(0,dp(52),1f).apply{if(i>0)setMargins(dp(4),0,0,0)})};root.addView(ratingRow);return root
    }

    private fun showReviewerMenu(){
        val c=currentCard();val items=arrayOf(
            "Study set / custom study","Reverse card","Shuffle: ${if(shuffle)"ON"else"OFF"}","10-card sprint","25-card sprint","Session size: ${if(sessionLimit==0)"Unlimited"else sessionLimit}",
            "Undo last rating","Bury until tomorrow","Suspend this card","Card information","End session")
        AlertDialog.Builder(this).setTitle("Study controls").setItems(items){_,w->when(w){
            0->chooseMode();1->{reverse=!reverse;show()};2->{shuffle=!shuffle;show()};3->restartWithLimit(10);4->restartWithLimit(25);5->chooseSessionSize();
            6->if(lastRatedCardId!=0L&&db.undoLast(lastRatedCardId)){studied=(studied-1).coerceAtLeast(0);position=0;lastRatedCardId=0L;Toast.makeText(this,"Last rating undone",Toast.LENGTH_SHORT).show();show()}else Toast.makeText(this,"Nothing to undo",Toast.LENGTH_SHORT).show();
            7->c?.let{db.buryUntilTomorrow(it.id);Toast.makeText(this,"Buried until tomorrow",Toast.LENGTH_SHORT).show();nextCard()};
            8->c?.let{db.setSuspended(it.id,true);Toast.makeText(this,"Card suspended",Toast.LENGTH_SHORT).show();nextCard()};9->showCardInfo();10->finish() }}.show()
    }
    private fun chooseMode(){val labels=arrayOf("Due now","All cards","New / unseen","Hard","Again / failed","Bookmarked","Marked");val values=arrayOf("due","all","unseen","hard","again","bookmarked","marked");val selected=values.indexOf(if(mode=="deck")"all"else mode);AlertDialog.Builder(this).setTitle("Choose study set").setSingleChoiceItems(labels,selected){d,w->mode=values[w];position=0;studied=0;showingBack=false;d.dismiss();show()}.show()}
    private fun chooseSessionSize(){val labels=arrayOf("Unlimited","10 cards","25 cards","50 cards","100 cards");val vals=intArrayOf(0,10,25,50,100);AlertDialog.Builder(this).setTitle("Session size").setSingleChoiceItems(labels,vals.indexOf(sessionLimit)){d,w->sessionLimit=vals[w];position=0;studied=0;showingBack=false;d.dismiss();show()}.show()}
    private fun restartWithLimit(limit:Int){sessionLimit=limit;position=0;studied=0;showingBack=false;show()}
    private fun showCardInfo(){val c=currentCard()?:return;AlertDialog.Builder(this).setTitle("Card information").setMessage("Deck: ${db.decks().firstOrNull{it.id==c.deckId}?.name ?: "Unknown"}\n\nTags: ${c.tags?.takeIf{it.isNotBlank()} ?: "—"}\n\nInterval: ${c.interval} day(s)\nEase: ${"%.2f".format(c.ease)}\nReviews: ${c.reps}\nLapses: ${c.lapses}\nLast rating: ${ratingName(c.lastRating)}\nStatus: ${if(c.suspended)"Suspended"else if(c.bookmarked)"Bookmarked"else"Active"}").setPositiveButton("Close",null).show()}
    private fun ratingName(v:Int)=when(v){1->"Again";2->"Hard";3->"Good";4->"Easy";else->"Not reviewed"}
    private fun updateModeLabel(){val setName=when(mode){"due"->"DUE";"unseen"->"NEW";"hard"->"HARD";"again"->"AGAIN";"bookmarked"->"BOOKMARKED";"marked"->"MARKED";else->"DECK"};val speed=if(elapsedSeconds>0)studied*60L/elapsedSeconds else 0;modeLabel.text="$setName  •  $speed cards/min  •  ${elapsedSeconds/60}m ${elapsedSeconds%60}s"}
    private fun rateAndNext(rating:Int){val c=currentCard()?:return;try{db.review(c.id,rating);lastRatedCardId=c.id;studied++;if(sessionLimit>0&&studied>=sessionLimit){finishSession();return};count=currentCount();if(mode=="deck"||mode=="all")position++;if(count<=0){finishSession();return};if(position>=count)position=0;showingBack=false;savePosition();show()}catch(t:Throwable){Toast.makeText(this,"Could not save rating: ${t.message ?: t.javaClass.simpleName}",Toast.LENGTH_LONG).show()}}
    private fun nextCard(){count=currentCount();if(count<=0){finishSession();return};position=if(shuffle&&count>1){var n=(0 until count).random();if(n==position)n=(n+1)%count;n}else(position+1)%count;showingBack=false;savePosition();show()}
    private fun previousCard(){count=currentCount();if(count<=0)return;position=(position-1+count)%count;showingBack=false;savePosition();show()}
    private fun savePosition(){getPreferences(0).edit().putInt(key("pos"),position).apply()}
    private fun finishSession(){AlertDialog.Builder(this).setTitle("Session complete").setMessage("You reviewed $studied card${if(studied==1)""else"s"}.\n\nTime: ${elapsedSeconds/60}m ${elapsedSeconds%60}s\nSpeed: ${if(elapsedSeconds>0)studied*60L/elapsedSeconds else 0} cards/min").setNegativeButton("Decks"){_,_->finish()}.setPositiveButton("Again"){_,_->position=0;studied=0;showingBack=false;show()}.show()}
    private fun show(){if(!::cardView.isInitialized)return;count=currentCount();if(count<=0){counter.text="0 cards";modeLabel.text="Nothing available in this study set";cardView.loadDataWithBaseURL(null,"<html><body><h2 style='text-align:center;margin-top:35%'>No cards here</h2><p style='text-align:center'>Try another study set from ⋮</p></body></html>","text/html","UTF-8",null);reveal.visibility=LinearLayout.GONE;ratingRow.visibility=LinearLayout.GONE;progress.progress=100;return};if(position>=count)position=0;val c=currentCard()?:return;counter.text="${position+1} / $count";progress.progress=((position+1).toFloat()/count*100f).toInt();bookmark.text=if(c.bookmarked)"★"else"☆";mark.text=if(c.marked)"⚑"else"⚐";val html=if(showingBack xor reverse)c.back else c.front;val dark=ThemeManager.isDark(this); val fg=if(dark)"#F2F5F8"else"#15263B"; val bg=if(dark)"#090909"else"#FFFFFF"; val border=if(dark)"#66788A"else"#8A98A8";val doc="""<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><style>html,body{background:$bg!important;color:$fg!important}body{font-family:sans-serif;font-size:19px;line-height:1.58;padding:20px;overflow-wrap:anywhere}img{display:block;max-width:100%;width:auto;height:auto;margin:12px auto;object-fit:contain}table{border-collapse:collapse;max-width:100%;width:auto;display:block;overflow-x:auto}td,th{padding:7px;border:1px solid $border}blockquote{border-left:4px solid #6c8ea5;padding-left:12px}</style></head><body>$html</body></html>""";cardView.loadDataWithBaseURL("file:///android_asset/",doc,"text/html","UTF-8",null);reveal.visibility=if(showingBack)LinearLayout.GONE else LinearLayout.VISIBLE;ratingRow.visibility=if(showingBack)LinearLayout.VISIBLE else LinearLayout.GONE
        for(i in 0 until ratingRow.childCount) ratingRow.getChildAt(i).isEnabled = true
        updateModeLabel();savePosition()}
    override fun onPause(){savePosition();timerHandler.removeCallbacks(timerTick);super.onPause()}
    override fun onResume(){super.onResume();if(::db.isInitialized&&::cardView.isInitialized){startedAt=System.currentTimeMillis()-elapsedSeconds*1000L;timerHandler.post(timerTick);runCatching{show()}}}
    override fun onDestroy(){timerHandler.removeCallbacks(timerTick);if(::cardView.isInitialized && !cardViewDestroyed){cardViewDestroyed=true;runCatching{cardView.destroy()}};if(::db.isInitialized)db.close();super.onDestroy()}
}
