#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $*"; exit 1; }
PASS(){ echo "PASS: $*"; }
DB="$ROOT/app/src/main/java/com/localqbank/library/QBankDb.kt"
LOAD="$ROOT/app/src/main/java/com/localqbank/library/QBankLoadingEngine.kt"
STATE="$ROOT/app/src/main/java/com/localqbank/library/AppState.kt"
HOME="$ROOT/app/src/main/java/com/localqbank/library/RovexHomeRevolution.kt"
NAV="$ROOT/app/src/main/java/com/localqbank/library/QuizNavigationUseCase.kt"
FV="$ROOT/app/src/main/java/com/localqbank/library/FlashcardViewModel.kt"
FR="$ROOT/app/src/main/java/com/localqbank/library/FlashcardReviewRepository.kt"
FD="$ROOT/app/src/main/java/com/localqbank/library/FlashcardDb.kt"
FA="$ROOT/app/src/main/java/com/localqbank/library/FlashcardActivity.kt"
IMP="$ROOT/app/src/main/java/com/localqbank/library/HtmlImportActivity.kt"
BUILD="$ROOT/app/build.gradle.kts"

grep -q 'versionCode = 481' "$BUILD" || fail "versionCode 480 missing"
grep -q 'versionName = "8.3.389"' "$BUILD" || fail "versionName 8.3.389 missing"
PASS "release version advanced to 8.3.389 / 481"

grep -q 'PerformanceManager.invalidateProgress()' "$STATE" || fail "progress-only invalidation missing"
grep -q 'reason.startsWith("flashcard_")' "$STATE" || fail "cross-domain flashcard invalidation guard missing"
grep -q 'reason == "import_completed"' "$STATE" || fail "structural QBank invalidation missing"
PASS "QBank structural invalidation is separated from progress/flashcard invalidation"

! grep -q 'PerformanceManager.lightRefs(a.applicationContext)' "$HOME" || fail "Home still performs full QuestionRef scan"
PASS "Home no longer scans full QBank refs for progress widgets"

! grep -q 'clearCompletion(testId)' "$NAV" || fail "opening a QBank still resets completion"
PASS "opening a QBank does not reset durable completion"

grep -q 'fun testProgressSummaries' "$DB" || fail "test progress summary method missing"
block="$(awk '/fun testProgressSummaries\(/{on=1} /private fun escapeLike/{on=0} on{print}' "$DB")"
! grep -q 'FROM question q' <<<"$block" || fail "sub-QBank progress summary still walks question corpus"
grep -q 'FROM progress_v2' <<<"$block" || fail "sub-QBank progress summary does not use sparse progress"
PASS "sub-QBank progress uses test metadata + sparse progress aggregation"

grep -q 'metadataWaiters' "$LOAD" || fail "section metadata waiter/coalescing layer missing"
grep -q 'bundleWaiters' "$LOAD" || fail "section bundle waiter/coalescing layer missing"
grep -q 'loadSectionMetadata(sourceId)' "$LOAD" || fail "bundle does not reuse metadata loader"
grep -q 'sourceWaiters' "$LOAD" || fail "source load coalescing missing"
PASS "QBank source/metadata/bundle loads are request-coalesced"

grep -q 'data class LibraryStats' "$FD" || fail "flashcard aggregate stats missing"
grep -q 'libraryStats()' "$FR" || fail "flashcard repository aggregate contract missing"
grep -q 'repository.libraryStats()' "$FV" || fail "flashcard ViewModel still performs N+1 stats reads"
grep -q 'refreshIfStale' "$FV" || fail "flashcard stale-refresh guard missing"
grep -q 'screenVisible' "$FA" || fail "hidden FlashcardActivity refresh guard missing"
PASS "Flashcard catalog/stat reads are aggregated and lifecycle-gated"

grep -q 'LARGE_FILE_LIMIT = 8L' "$IMP" || fail "streaming import threshold was not lowered"
grep -q 'dirtyTests' "$DB" || fail "streaming importer still updates every accumulated test per batch"
PASS "large/multi-section HTML import uses earlier streaming and dirty-test commits"

PASS "deep architecture regression checks complete"
