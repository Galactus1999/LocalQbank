package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.isActive
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle

/** Presentation-only renderer for Settings. It does not own application engines or persistence. */
class SettingsScreen(private val activity: SettingsActivity, private val viewModel: SettingsViewModel) {
    private val lifecycleScope get() = activity.lifecycleScope
    private val neuralModelManager get() = activity.neuralModelManager
    private val section: String get() = activity.intent.getStringExtra("section") ?: "all"
    private val embeddingModelRequestCode = SettingsActivity.REQUEST_EMBEDDING_MODEL
    private val generativeModelRequestCode = SettingsActivity.REQUEST_GENERATIVE_MODEL
    private val embeddingTokenizerRequestCode = SettingsActivity.REQUEST_EMBEDDING_TOKENIZER
    private fun dp(v:Int)= (v*activity.resources.displayMetrics.density).toInt()

    fun buildRoot():ScrollView = build()

    private fun build():ScrollView{
        if(section=="all") return buildSettingsMenu()
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(28));setBackgroundColor(ThemeManager.bg(activity))}
        root.addView(TextView(activity).apply{text=when(section){"adaptive"->"Adaptive Engine";"appearance"->"Appearance & Themes";"fonts"->"Quiz Typography";else->"Settings"};textSize=27f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));setPadding(0,0,0,dp(6))})
        root.addView(TextView(activity).apply{text="Dedicated ${section.replaceFirstChar{it.uppercase()}} controls";textSize=13f;setTextColor(ThemeManager.muted(activity));setPadding(0,0,0,dp(18))})
        if(section=="appearance") addAppearance(root)
        if(section=="fonts") addFonts(root)
        if(section=="adaptive") addAdaptive(root)
        return ScrollView(activity).apply{addView(root);isFillViewport=true}
    }

    private fun buildSettingsMenu():ScrollView{
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(20),dp(20),dp(28));setBackgroundColor(ThemeManager.bg(activity))}
        val header=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val back=TextView(activity).apply{text="←";textSize=25f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(activity));background=rounded(ThemeManager.elevated(activity),16);setOnClickListener{activity.finish()}}
        header.addView(back,LinearLayout.LayoutParams(dp(52),dp(52)))
        header.addView(TextView(activity).apply{text="Settings";textSize=28f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));setPadding(dp(14),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        root.addView(header)
        root.addView(TextView(activity).apply{text="Tune the study experience, intelligence and data safety.";textSize=14f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(14),0,dp(16))})
        val items=listOf(
            Triple("Theme","Light, Dark, Sepia, AMOLED and Midnight","theme"),
            Triple("Fonts","Quiz typography and reading density","fonts"),
            Triple("Colour flow","Two-colour flow, normal text and greeting panel","colour_flow"),
            Triple("Adaptive Engine","Learning, runtime policy and autonomy","adaptive"),
            Triple("Ben AI Safety","Local-model kill switch and conservative memory guard","ben_ai"),
            Triple("Backup & Restore","Protect progress and restore local backups","backup")
        )
        items.forEach{(title,sub,key)->
            val card=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(14),dp(12),dp(14));background=rounded(ThemeManager.elevated(activity),18)}
            val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
            copy.addView(TextView(activity).apply{text=title;textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
            copy.addView(TextView(activity).apply{text=sub;textSize=12f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,0)})
            card.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            card.addView(TextView(activity).apply{text="›";textSize=27f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(activity))},LinearLayout.LayoutParams(dp(38),dp(42)))
            card.setOnClickListener{when(key){"theme"->showThemeDialog();"fonts"->showFontDialog();"colour_flow"->showColourFlowDialog();"adaptive"->activity.startActivity(Intent(activity,SettingsActivity::class.java).putExtra("section","adaptive"));"ben_ai"->showBenAiSafetyDialog();"backup"->activity.startActivity(Intent(activity,BackupActivity::class.java))}}
            root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        root.addView(TextView(activity).apply{text="Changes are applied locally. Dr. Frankenstein and the adaptive engines cannot modify executable code or your source QBank at runtime.";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(dp(4),dp(18),dp(4),0)})
        return ScrollView(activity).apply{addView(root);isFillViewport=true}
    }

    private fun showBenAiSafetyDialog(){
        val policy = BenAiRuntimePolicy(activity)
        val dialog=Dialog(activity)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Ben AI Safety";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Control any future on-device model before it can consume significant memory or native resources.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(14))})
        val enabled=android.widget.Switch(activity).apply{text="Allow Ben local model";isChecked=policy.enabled;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,checked->policy.setEnabled(checked)}}
        root.addView(enabled)
        val conservative=android.widget.Switch(activity).apply{text="Conservative memory guard";isChecked=policy.conservativeMode;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,checked->policy.setConservativeMode(checked)}}
        root.addView(conservative)
        root.addView(TextView(activity).apply{text="When enabled, future model backends must pass the conservative 1.2 GB model-size gate before loading. Turning off the model switch is a persistent kill switch.";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(8),0,dp(12))})
        root.addView(TextView(activity).apply{text="STOP BEN MODEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(8));setOnClickListener{policy.forceStop();enabled.isChecked=false}})
        root.addView(TextView(activity).apply{text="DONE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show()
    }

    private fun showThemeDialog(){
        val keys=arrayOf(ThemeManager.LIGHT,ThemeManager.DARK,ThemeManager.SEPIA,ThemeManager.AMOLED,ThemeManager.MIDNIGHT)
        val labels=arrayOf("Light","Dark","Sepia","AMOLED Black","Midnight Blue")
        val descriptions=arrayOf("Clean daylight reading","Low-glare night reading","Warm textbook paper","True black for OLED","Deep blue, high contrast")
        val dialog=Dialog(activity)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Theme";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Choose the reading environment that feels right.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(12))})
        val current=ThemeManager.get(activity)
        keys.forEachIndexed{index,key->
            val selected=current==key
            val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(10),dp(10));background=rounded(if(selected)ThemeManager.optionBg(activity) else ThemeManager.elevated(activity),16)}
            val swatch=TextView(activity).apply{text="  ";background=rounded(themeSwatch(key),10);setPadding(dp(5),dp(5),dp(5),dp(5))}
            row.addView(swatch,LinearLayout.LayoutParams(dp(38),dp(38)))
            val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(6),0)}
            copy.addView(TextView(activity).apply{text=labels[index];textSize=15.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
            copy.addView(TextView(activity).apply{text=descriptions[index];textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(2),0,0)})
            row.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(activity).apply{text=if(selected)"✓" else "";textSize=20f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity))},LinearLayout.LayoutParams(dp(28),dp(38)))
            row.setOnClickListener{viewModel.setTheme(key);dialog.dismiss();activity.recreate()}
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        root.addView(TextView(activity).apply{text="CANCEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root)
        dialog.setOnShowListener{_ -> dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showFontDialog(){
        val keys=arrayOf("sans-serif","serif","sans-serif-condensed","monospace")
        val labels=arrayOf("Modern Sans","Textbook Serif","Compact Sans","Monospace")
        val samples=arrayOf("A  B  C  •  123","Question • Explanation","Rapid revision text","A = B + C")
        val current=viewModel.quizFont()
        val dialog=Dialog(activity)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Fonts";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Preview how question text will feel before applying it.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(12))})
        keys.forEachIndexed{index,key->
            val selected=current==key
            val row=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(11),dp(12),dp(11));background=rounded(if(selected)ThemeManager.optionBg(activity) else ThemeManager.elevated(activity),16)}
            val top=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            top.addView(TextView(activity).apply{text=labels[index];textSize=15.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));typeface=Typeface.create(key,Typeface.BOLD)},LinearLayout.LayoutParams(0,-2,1f))
            top.addView(TextView(activity).apply{text=if(selected)"✓" else "";textSize=20f;setTextColor(ThemeManager.accent(activity));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(30)))
            row.addView(top)
            row.addView(TextView(activity).apply{text=samples[index];textSize=15f;typeface=Typeface.create(key,Typeface.NORMAL);setTextColor(ThemeManager.text(activity));setPadding(0,dp(5),0,0)})
            row.setOnClickListener{viewModel.setQuizFont(key);dialog.dismiss();activity.recreate()}
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        root.addView(TextView(activity).apply{text="CANCEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root)
        dialog.setOnShowListener{_ -> dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showColourFlowDialog(){
        var c1=viewModel.flowColorOne()
        var c2=viewModel.flowColorTwo()
        var panel=viewModel.flowGreetingColor()
        var flow=viewModel.flowTextEnabled()
        val dialog=Dialog(activity)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Colour flow";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Choose two colours. They blend and travel across the flow labels.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(12))})
        val preview=TextView(activity).apply{text="Performance  •  Flashcards  •  Solved";textSize=16f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(dp(8),dp(10),dp(8),dp(10))}
        root.addView(preview,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(10))})
        fun refresh(){
            preview.background=GradientDrawable().apply{cornerRadius=dp(12).toFloat();setColor(if(ThemeManager.get(activity)==ThemeManager.AMOLED)Color.BLACK else ThemeManager.elevated(activity));setStroke(dp(1),RovexColorFlowTextView.mix(c1,c2,.5f))}
            preview.paint.shader=android.graphics.LinearGradient(0f,0f,preview.width.coerceAtLeast(dp(220)).toFloat(),0f,intArrayOf(c1,RovexColorFlowTextView.mix(c1,c2,.5f),c2),null,android.graphics.Shader.TileMode.CLAMP)
            preview.invalidate()
        }
        fun addSpectrum(label:String,initial:Int,onChange:(Int)->Unit){
            root.addView(TextView(activity).apply{text=label;textSize=12f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.muted(activity));setPadding(dp(2),dp(3),0,dp(1))})
            val bar=RovexColorSpectrumView(activity).apply{color=initial;this.onColorChanged={onChange(it);refresh()}}
            root.addView(bar,LinearLayout.LayoutParams(-1,dp(88)).apply{setMargins(0,0,0,dp(4))})
        }
        addSpectrum("FLOW COLOUR 1",c1){c1=it;refresh()}
        addSpectrum("FLOW COLOUR 2",c2){c2=it;refresh()}
        val normal=CheckBox(activity).apply{text="Keep colour-flow labels as normal text";textSize=13f;isChecked=!flow;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,checked->flow=!checked}}
        root.addView(normal)
        root.addView(TextView(activity).apply{text="Greeting panel colour";textSize=13f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));setPadding(dp(2),dp(12),0,dp(2))})
        val panelBar=RovexColorSpectrumView(activity).apply{color=if(panel==0)Color.rgb(35,101,126) else panel;onColorChanged={panel=it}}
        root.addView(panelBar,LinearLayout.LayoutParams(-1,dp(88)).apply{setMargins(0,0,0,dp(4))})
        root.addView(TextView(activity).apply{text="The panel behind Good morning / afternoon / evening uses this colour.";textSize=11f;setTextColor(ThemeManager.muted(activity));setPadding(dp(2),0,0,dp(8))})
        val buttons=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        buttons.addView(TextView(activity).apply{text="RESET";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setOnClickListener{viewModel.resetColourFlow();dialog.dismiss();activity.recreate()}},LinearLayout.LayoutParams(0,dp(46),1f))
        buttons.addView(TextView(activity).apply{text="SAVE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setOnClickListener{viewModel.saveColourFlow(c1,c2,flow,panel);dialog.dismiss();activity.recreate()}},LinearLayout.LayoutParams(0,dp(46),1f))
        root.addView(buttons)
        refresh()
        dialog.setContentView(root);dialog.setOnShowListener{dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)};dialog.show();dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun themeSwatch(key:String):Int=when(key){
        ThemeManager.LIGHT->Color.rgb(247,249,246)
        ThemeManager.DARK->Color.rgb(48,61,75)
        ThemeManager.SEPIA->Color.rgb(246,239,218)
        ThemeManager.AMOLED->Color.rgb(0,0,0)
        else->Color.rgb(24,54,92)
    }

    private fun addAppearance(root:LinearLayout){
        section(root,"APPEARANCE")
        val themes=linkedMapOf(ThemeManager.LIGHT to "Light",ThemeManager.DARK to "Dark",ThemeManager.SEPIA to "Sepia",ThemeManager.AMOLED to "AMOLED Black",ThemeManager.MIDNIGHT to "Midnight Blue")
        themes.forEach{(key,label)-> root.addView(button(if(ThemeManager.get(activity)==key)"✓  $label" else label){viewModel.setTheme(key);activity.recreate()},lp())}
    }

    private fun addFonts(root:LinearLayout){
        section(root,"QUIZ TYPOGRAPHY")
        val fonts=linkedMapOf("sans-serif" to "Modern Sans","serif" to "Serif / textbook","monospace" to "Monospace / coding","sans-serif-condensed" to "Condensed Sans","sans-serif-light" to "Light Sans")
        val current=viewModel.quizFont()
        fonts.forEach{(key,label)->root.addView(button(if(current==key)"✓  $label" else label){viewModel.setQuizFont(key);activity.recreate()},lp())}
    }

    private fun addAdaptive(root:LinearLayout){
        val state=AppManagers.adaptive.state()
        val dark=ThemeManager.isDark(activity)
        val cardBg=ThemeManager.elevated(activity)
        val border=if(dark) Color.rgb(48,61,75) else Color.rgb(220,226,230)

        fun card(pad:Int=16)=LinearLayout(activity).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(pad),dp(pad),dp(pad),dp(pad))
            background=GradientDrawable().apply{setColor(cardBg);cornerRadius=dp(16).toFloat();setStroke(dp(1),border)}
        }
        fun label(text:String,size:Float=12f)=TextView(activity).apply{
            this.text=text;this.textSize=size;setTextColor(ThemeManager.muted(activity))
        }
        fun title(text:String,size:Float=17f)=TextView(activity).apply{
            this.text=text;this.textSize=size;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))
        }
        fun bar(value:Int,tint:Int)=ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal).apply{
            max=100;progress=value.coerceIn(0,100)
            progressTintList=android.content.res.ColorStateList.valueOf(tint)
            backgroundTintList=android.content.res.ColorStateList.valueOf(if(ThemeManager.get(activity)==ThemeManager.AMOLED) Color.BLACK else if(dark)Color.rgb(42,52,64) else Color.rgb(231,235,238))
        }
        fun metric(value:String,caption:String)=LinearLayout(activity).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10))
            background=rounded(if(ThemeManager.get(activity)==ThemeManager.AMOLED)Color.BLACK else if(dark)Color.rgb(20,28,37) else Color.rgb(248,249,249),12)
            addView(TextView(activity).apply{text=value;textSize=20f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))},LinearLayout.LayoutParams(-1,dp(27)))
            addView(label(caption,10.5f))
        }
        fun addSectionHeader(text:String,sub:String){
            root.addView(TextView(activity).apply{this.text=text.uppercase();textSize=11f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity));setPadding(dp(2),dp(12),dp(2),dp(3))})
            root.addView(TextView(activity).apply{this.text=sub;textSize=11f;setTextColor(ThemeManager.muted(activity));setPadding(dp(2),0,dp(2),dp(7))})
        }
        fun addCollapsible(titleText:String,subtitle:String,open:Boolean=false,body:LinearLayout.()->Unit){
            val shell=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
            val header=LinearLayout(activity).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12))
                background=rounded(cardBg,14)
            }
            val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
            copy.addView(title(titleText,15.5f))
            copy.addView(label(subtitle,10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,0)})
            header.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            val chevron=TextView(activity).apply{text=if(open)"⌃" else "⌄";textSize=20f;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity))}
            header.addView(chevron,LinearLayout.LayoutParams(dp(30),dp(34)))
            val content=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(7),0,dp(2));visibility=if(open)View.VISIBLE else View.GONE}
            body(content)
            header.setOnClickListener{
                content.visibility=if(content.visibility==View.VISIBLE)View.GONE else View.VISIBLE
                chevron.text=if(content.visibility==View.VISIBLE)"⌃" else "⌄"
            }
            shell.addView(header,LinearLayout.LayoutParams(-1,-2))
            shell.addView(content,LinearLayout.LayoutParams(-1,-2))
            root.addView(shell,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
        }

        addSectionHeader("CONTROL ROOM","A compact view of learning, Ben, runtime health and safety. Tap a section to expand details.")

        val hero=card()
        val heroTop=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val heroCopy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
        heroCopy.addView(title("Adaptive Engine",20f))
        heroCopy.addView(label(if(state.safeMode)"Protective mode active" else "Learning from runtime behaviour",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,0)})
        heroTop.addView(heroCopy,LinearLayout.LayoutParams(0,-2,1f))
        heroTop.addView(Switch(activity).apply{
            isChecked=AppManagers.adaptive.isAutonomyEnabled();contentDescription="Autonomous runtime optimisation"
            buttonTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(activity))
            setOnCheckedChangeListener{_,checked->viewModel.setAdaptiveAutonomy(checked);Toast.makeText(activity,if(checked)"Autonomous optimisation enabled" else "Autonomous optimisation paused",Toast.LENGTH_SHORT).show()}
        },LinearLayout.LayoutParams(dp(56),dp(48)))
        hero.addView(heroTop)
        val healthColor=when{state.health>=80->Color.rgb(32,128,91);state.health>=55->Color.rgb(163,111,31);else->Color.rgb(170,55,65)}
        hero.addView(LinearLayout(activity).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(13),0,0)
            addView(title("System health",14f),LinearLayout.LayoutParams(0,-2,1f))
            addView(TextView(activity).apply{text="${state.health}%";textSize=22f;typeface=Typeface.DEFAULT_BOLD;setTextColor(healthColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(62),dp(32)))
        })
        hero.addView(bar(state.health,healthColor),LinearLayout.LayoutParams(-1,dp(7)).apply{setMargins(0,dp(6),0,0)})
        hero.addView(label("${state.systemModel.replaceFirstChar{it.uppercase()}} device profile  •  ${if(state.safeMode)"safe mode" else "normal operation"}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

        val topologyCard=card(10)
        topologyCard.addView(AdaptiveEngineDashboardView(activity).apply{
            minimumHeight=dp(220);update(state,BenNeuralTelemetry.snapshot(),"0",AppManagers.battery.snapshot().level.name)
        },LinearLayout.LayoutParams(-1,dp(220)))
        root.addView(topologyCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

        val liveStatus=label("LIVE • waiting",12f)
        val liveModel=label("Model: none",10.5f)
        val liveMetrics=label("Last inference: —",10.5f)
        val liveCounters=label("Requests 0 • neural 0 • fallback 0 • blocked 0",10.5f)
        val liveResources=label("RAM / thermal: reading…",10.5f)
        val liveError=label("",10.5f)
        addCollapsible("Live runtime","Neural telemetry, latency, fallback and device conditions",false){
            addView(liveStatus,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(3))})
            addView(liveModel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),0)})
            addView(liveMetrics,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(3),dp(12),0)})
            addView(liveCounters,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(3),dp(12),0)})
            addView(liveResources,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(3),dp(12),0)})
            addView(liveError,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(3),dp(12),dp(4))})
        }
        lifecycleScope.launch {
            activity.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while(isActive){
                    val snapshot=withContext(Dispatchers.Default){Triple(AppManagers.adaptive.state(),BenNeuralTelemetry.snapshot(),BenAiResourceGovernor(activity).snapshot(true))}
                    val liveState=snapshot.first;val t=snapshot.second;val gov=snapshot.third
                    liveStatus.text="LIVE • ${t.stage.name.replace('_',' ')} • ${t.stageDetail}"
                    liveModel.text="Model: ${t.activeModel} • ${t.modelKind}"
                    liveMetrics.text="Last ${t.lastElapsedMs} ms • semantic ${t.lastSemanticMs} ms • generation ${t.lastGenerationMs} ms • evidence ${t.lastEvidenceCount}"
                    liveCounters.text="Requests ${t.totalRequests} • neural ${t.neuralRequests} • fallback ${t.fallbackRequests} • blocked ${t.blockedRequests}"
                    liveResources.text="RAM available ${gov.availableMemoryMb} MB • thermal ${gov.thermalStatus} • power-save ${if(gov.powerSave)"ON" else "OFF"}"
                    liveError.text=t.lastError?.let{"Last error: $it"} ?: "Verifier: ${if(t.lastVerified)"PASS" else "—"} • confidence ${t.lastConfidence}%"
                    topologyCard.getChildAt(0)?.let{if(it is AdaptiveEngineDashboardView)it.update(liveState,t,gov.availableMemoryMb.toString(),gov.thermalStatus.toString())}
                    delay(750)
                }
            }
        }

        addSectionHeader("LEARNING & STRATEGY","What the adaptive engine is learning and how it is currently steering study behaviour.")
        val metrics=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL}
        metrics.addView(metric("${state.learningScore}%","learning"),LinearLayout.LayoutParams(0,dp(66),1f).apply{setMargins(0,0,dp(4),0)})
        metrics.addView(metric("${state.confidence}%","confidence"),LinearLayout.LayoutParams(0,dp(66),1f).apply{setMargins(dp(4),0,dp(4),0)})
        metrics.addView(metric("${state.autonomousChanges}","changes"),LinearLayout.LayoutParams(0,dp(66),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(metrics,LinearLayout.LayoutParams(-1,dp(66)).apply{setMargins(0,0,0,dp(8))})
        addCollapsible("Learning signals","Confidence, uncertainty, exploration and user model",false){
            addView(label("Confidence",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(4))})
            addView(bar(state.confidence,ThemeManager.accent(activity)),LinearLayout.LayoutParams(-1,dp(6)).apply{setMargins(dp(12),0,dp(12),0)})
            addView(label("Uncertainty ${state.uncertainty}%  •  exploration ${state.exploration}%",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(5),dp(12),0)})
            addView(label("User model: ${state.userModel}  •  System model: ${state.systemModel}",11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(9),dp(12),dp(5))})
        }
        addCollapsible("Study strategy","Current adaptive recommendation and next policy action",false){
            addView(label(AppManagers.adaptive.studyStrategy(),12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(7))})
            addView(label("Next policy: ${AppManagers.adaptive.currentProposal().action.key}",11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(2))})
            addView(label(AppManagers.adaptive.currentProposal().reason,11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(2))})
            addView(label(AdaptiveExplainability.explain(state),10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(5),dp(12),dp(5))})
        }
        addCollapsible("Runtime policy","Prefetch, cache and adaptive changes",false){
            addView(label("Prefetch depth ${state.preferredPrefetch}",11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(4))})
            addView(bar((state.preferredPrefetch/3f*100f).toInt(),ThemeManager.accent(activity)),LinearLayout.LayoutParams(-1,dp(6)).apply{setMargins(dp(12),0,dp(12),0)})
            addView(label("Cache ${PerformanceManager.adaptiveCacheTtlMs()/1000}s  •  observations ${state.observations}  •  answers ${state.answers}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(5),dp(12),dp(5))})
        }

        addSectionHeader("BEN • COGNITIVE CORE","Deterministic intelligence remains authoritative. Neural models are optional accelerators behind the governor.")
        addCollapsible("Ben brain","Cognitive switches, specialist routing and verification",false){
            val bc=BenCognitiveControl(activity)
            fun benSwitch(caption:String,checked:Boolean,change:(Boolean)->Unit){
                addView(Switch(activity).apply{text=caption;isChecked=checked;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,v->change(v)}},LinearLayout.LayoutParams(-1,dp(45)).apply{setMargins(dp(6),0,dp(6),0)})
            }
            benSwitch("Cognitive Core",bc.cognitiveCoreEnabled){bc.setCognitiveCoreEnabled(it)}
            benSwitch("Medical Knowledge Graph",bc.knowledgeGraphEnabled){bc.setKnowledgeGraphEnabled(it)}
            benSwitch("Planner / Reasoner",bc.plannerEnabled){bc.setPlannerEnabled(it)}
            benSwitch("Local RAG / QBank Retrieval",bc.retrievalEnabled){bc.setRetrievalEnabled(it)}
            benSwitch("Persistent Knowledge Index",bc.knowledgeIndexEnabled){bc.setKnowledgeIndexEnabled(it)}
            benSwitch("Specialist Routing",bc.specialistRoutingEnabled){bc.setSpecialistRoutingEnabled(it)}
            benSwitch("Learner Memory",bc.learnerMemoryEnabled){bc.setLearnerMemoryEnabled(it)}
            benSwitch("Experience Memory",bc.experienceMemoryEnabled){bc.setExperienceMemoryEnabled(it)}
            benSwitch("Answer Verifier",bc.verifierEnabled){bc.setVerifierEnabled(it)}
            val fr=AppManagers.benBrain.frankenstein().stats()
            addView(label("${fr.observations} routed requests • ${fr.verificationRate}% verified • last specialist ${fr.lastSpecialist}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(7),dp(12),dp(3))})
            if(fr.lastConcepts.isNotBlank())addView(label("Recent concepts: ${fr.lastConcepts}",10f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(3))})
            addView(label("${BenSpecialistRegistry.entries().size} deterministic clinical specialist routes",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(6))})
            val ki=AppManagers.benBrain.knowledgeIndex().stats()
            val buildStatus=BenKnowledgeBuildCoordinator.status(activity)
            addView(label("Knowledge index: ${ki.concepts} concepts • ${ki.edges} edges • ${ki.observations} observations",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(2))})
            addView(label("QBank learning: ${buildStatus.state} • ${buildStatus.progress}% • ${buildStatus.processed} questions processed",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(4))})
            addView(button("Build / Resume Ben knowledge from QBank"){BenKnowledgeBuildCoordinator.start(activity,rebuild=false);Toast.makeText(activity,"Ben QBank learning started/resumed in background",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(2),dp(8),dp(3))})
            addView(button("Rebuild Ben knowledge from QBank"){BenKnowledgeBuildCoordinator.start(activity,rebuild=true);Toast.makeText(activity,"Ben knowledge rebuild started in background",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(2),dp(8),dp(3))})
            addView(label("Episodic memory: ${AppManagers.benBrain.experience().summary()}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(5),dp(12),dp(2))})
            addView(button("Reset Ben episodic memory"){AppManagers.benBrain.experience().reset();Toast.makeText(activity,"Ben episodic memory reset",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(2),dp(8),dp(3))})
            addView(button("Reset Ben knowledge graph"){AppManagers.benBrain.knowledgeIndex().reset();Toast.makeText(activity,"Ben knowledge graph reset",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(2),dp(8),dp(3))})
            addView(button("Reset Ben to safe defaults"){bc.resetToSafeDefaults();Toast.makeText(activity,"Ben reset to safe defaults",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(2),dp(8),dp(5))})
        }

        val neuralModels=neuralModelManager
        val recommendedModel=BenNeuralModelRegistry.embeddingGemma300m
        val installedEmbedding=neuralModels.installed(recommendedModel)
        val embeddingTokenizer=neuralModels.installedEmbeddingGemmaTokenizer()
        addCollapsible("Neural Lab","EmbeddingGemma retrieval accelerator + Gemma 3 270M generation accelerator",false){
            addView(button("Open Ben Model Lab • diagnostics and direct tests"){activity.startActivity(Intent(activity,BenModelLabActivity::class.java))},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(2),dp(8),dp(7))})
            val policy=BenAiRuntimePolicy(activity)
            addView(label("Neural policy: ${if(policy.circuitOpen)"BLOCKED / circuit open" else if(policy.enabled)"ARMED / governor controlled" else "OFF"}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(5))})
            addView(label("EmbeddingGemma: ${if(installedEmbedding!=null)"model installed (${installedEmbedding.bytes/(1024*1024)} MB)" else "model missing"} • tokenizer ${if(embeddingTokenizer!=null)"installed" else "missing"}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(2))})
            addView(label("Target: 768-d semantic vectors; 512-token Android export currently held for compatibility validation.",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(5))})
            addView(button(if(installedEmbedding==null)"Install EmbeddingGemma 300M model file" else "Replace EmbeddingGemma 300M model file"){activity.openSettingsDocument(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE)},embeddingModelRequestCode)},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(3),dp(8),dp(4))})
            addView(button(if(embeddingTokenizer==null)"Install official sentencepiece.model" else "Replace official sentencepiece.model"){activity.openSettingsDocument(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE)},embeddingTokenizerRequestCode)},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(3),dp(8),dp(4))})
            if(installedEmbedding!=null && embeddingTokenizer!=null){
                addView(button("Run EmbeddingGemma contract + semantic test"){
                    BenAiRuntimePolicy(activity).resetCircuit()
                    Toast.makeText(activity,"EmbeddingGemma diagnostic running off the UI thread…",Toast.LENGTH_SHORT).show()
                    lifecycleScope.launch(Dispatchers.IO){
                        val result=BenEmbeddingGemmaEngine(activity).diagnostic()
                        launch(Dispatchers.Main){
                            if(result==null){
                                val snap=BenNeuralTelemetry.snapshot();Toast.makeText(activity,"EmbeddingGemma diagnostic failed: ${snap.lastError?:"unknown runtime failure"}",Toast.LENGTH_LONG).show()
                            }else AlertDialog.Builder(activity).setTitle("EmbeddingGemma diagnostic").setMessage(result).setPositiveButton("OK",null).show()
                        }
                    }
                },LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(3),dp(8),dp(4))})
                addView(button("Test semantic pair only"){
                    BenAiRuntimePolicy(activity).resetCircuit()
                    lifecycleScope.launch(Dispatchers.IO){
                        val score=BenEmbeddingGemmaEngine(activity).compare("nephrotic syndrome causes edema","protein loss in urine lowers plasma oncotic pressure and causes edema")
                        launch(Dispatchers.Main){Toast.makeText(activity,if(score==null)"EmbeddingGemma semantic test failed; deterministic retrieval remains active" else "Cosine similarity: ${"%.3f".format(score)}",Toast.LENGTH_LONG).show()}
                    }
                },LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(2),dp(8),dp(4))})
            }
            val gen=BenNeuralModelRegistry.gemma3_270m
            val installedGen=neuralModels.installed(gen)
            addView(label("Gemma 3 270M: ${if(installedGen!=null) "installed (${installedGen.bytes/(1024*1024)} MB)" else "not installed"} • optional generation accelerator",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(2))})
            addView(button(if(installedGen==null)"Install Gemma 3 270M" else "Replace Gemma 3 270M"){activity.openSettingsDocument(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE)},generativeModelRequestCode)},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(3),dp(8),dp(4))})
            if(installedGen!=null){
                addView(button("Test grounded Ben neural pipeline (QBank + verifier)"){
                    val prompt="Explain the mechanism of edema in nephrotic syndrome and give the key NEET-PG exam trap."
                    Toast.makeText(activity,"Grounded Ben pipeline running off the UI thread…",Toast.LENGTH_SHORT).show()
                    lifecycleScope.launch(Dispatchers.IO){
                        val result=BenGroundedNeuralPipeline(activity).run(prompt)
                        launch(Dispatchers.Main){AlertDialog.Builder(activity).setTitle("Ben grounded result • ${result.elapsedMs} ms").setMessage("Evidence: ${result.evidenceCount} local QBank hits\nModel used: ${result.modelUsed}\nVerifier: ${if(result.verified)"PASS" else "FALLBACK/REVIEW"}\nConfidence: ${result.confidence}%\n\n${result.answer}").setPositiveButton("OK",null).show()}
                    }
                },LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(2),dp(8),dp(3))})
                addView(button("Test Gemma 3 270M one-shot generation"){
                    val prompt="Using only general medical-study reasoning, explain why a patient with nephrotic syndrome develops edema. Give 3 concise points and state that this is a draft requiring Ben verification."
                    Toast.makeText(activity,"Gemma generation test running off the UI thread…",Toast.LENGTH_SHORT).show()
                    BenNeuralTelemetry.begin("Gemma generation test")
                    BenNeuralTelemetry.stage(BenNeuralTelemetry.Stage.GENERATION,"Generating one-shot draft","Gemma 3 270M","Generation")
                    lifecycleScope.launch(Dispatchers.IO){
                        val result=BenLiteRtLmGenerator(activity).generate(prompt)
                        launch(Dispatchers.Main){
                            if(result==null){BenNeuralTelemetry.error("Gemma generation test blocked/failed");Toast.makeText(activity,"Neural test blocked/failed; deterministic Ben remains active",Toast.LENGTH_LONG).show()}
                            else{BenNeuralTelemetry.generation(result.elapsedMs,true);BenNeuralTelemetry.complete(0,false,0,result.elapsedMs,true);AlertDialog.Builder(activity).setTitle("Ben neural draft • ${result.elapsedMs} ms").setMessage(result.text).setPositiveButton("OK",null).show()}
                        }
                    }
                },LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(2),dp(8),dp(3))})
                addView(button("Remove Gemma 3 270M model"){neuralModels.delete(gen);Toast.makeText(activity,"Generative model removed",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(2),dp(8),dp(4))})
            }
        }

        addSectionHeader("SYSTEM & SAFETY","Device resources, resilience and hard boundaries. These controls are intentionally separated from Ben's cognition.")
        addCollapsible("Resource governor","RAM, thermal, power and model circuit breaker",false){
            val governor=BenAiResourceGovernor(activity);val snap=governor.snapshot(true);val policy=BenAiRuntimePolicy(activity)
            addView(label("Available RAM ${snap.availableMemoryMb} MB",11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(4))})
            addView(bar((snap.availableMemoryMb.toFloat()/2048f*100f).toInt(),ThemeManager.accent(activity)),LinearLayout.LayoutParams(-1,dp(6)).apply{setMargins(dp(12),0,dp(12),dp(3))})
            addView(label("Thermal ${snap.thermalStatus} • power-save ${if(snap.powerSave)"ON" else "OFF"} • foreground ${snap.foreground}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(4),dp(12),dp(3))})
            addView(label("Hard gate: ${BenAiResourceGate.MIN_FREE_HEADROOM_MB} MB headroom • thermal ceiling ${BenAiResourceGate.MAX_THERMAL_STATUS}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(3))})
            addView(label("Backend failures ${policy.consecutiveFailures}/${BenAiRuntimePolicy.MAX_CONSECUTIVE_FAILURES} • circuit ${if(policy.circuitOpen)"OPEN" else "closed"}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(5))})
            addView(button("Open Ben AI Safety"){showBenAiSafetyDialog()},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(3),dp(8),dp(5))})
        }
        addCollapsible("Battery engine","Power governor and foreground-study policy",false){
            val bs=AppManagers.battery.snapshot();val bp=AppManagers.battery.policy(RovexBatteryManager.WorkClass.INTERACTIVE)
            addView(label("${AppManagers.battery.statusLine()} • ${bs.level.name}",11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(4))})
            addView(label("Prefetch ${bp.prefetchDepth} • image concurrency ${bp.imageConcurrency} • import batch ${bp.importBatchSize}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(4))})
            addView(label("Foreground study remains allowed; background/bulk work is reduced when power or thermal conditions require it.",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(5))})
        }
        addCollapsible("Resilience & recovery","Crash protection, safe mode and protected sessions",false){
            val rh=AppManagers.resilienceHealth.snapshot()
            addView(label("Health ${rh.overall}% • ${if(rh.safeMode)"protective safe mode" else "normal runtime"}",11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(3))})
            addView(bar(rh.overall,if(rh.overall>=80)Color.rgb(39,151,107) else ThemeManager.accent(activity)),LinearLayout.LayoutParams(-1,dp(6)).apply{setMargins(dp(12),0,dp(12),dp(4))})
            addView(label("Process interruptions ${rh.crashCount} • suspected UI stalls ${ResilienceManager.suspectedStalls(activity)}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(3))})
            rh.recovery?.let{r->addView(label("Protected session: question ${r.position+1}${if(r.session.isBlank())"" else " • ${r.session}"}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(3))})}
        }
        addCollapsible("Companion engines","Flashcards and knowledge vault remain independently controlled",false){
            val fs=AppManagers.flashcardIntelligence.stats();val ks=AppManagers.knowledge.stats()
            addView(label("Flashcard Engine: ${if(fs.available)"ready" else "unavailable"} • manual creation only",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(4))})
            addView(button("Open Flashcards"){activity.startActivity(Intent(activity,FlashcardActivity::class.java))},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),0,dp(8),dp(4))})
            addView(label("Knowledge Vault: ${ks.notes} notes • ${ks.tables} tables • ${ks.images} images",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(4),dp(12),dp(4))})
            addView(button("Open Knowledge Vault"){activity.startActivity(Intent(activity,KnowledgeVaultActivity::class.java))},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),0,dp(8),dp(5))})
        }

        addSectionHeader("ENGINE ACTIVITY","Recent adaptive actions and the boundaries that protect study data.")
        addCollapsible("Recent activity","Observations, outcomes and autonomous changes",false){
            addView(label("${state.observations} observations • ${state.answers} answers • ${state.correct} correct • ${state.wrong} wrong",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(3))})
            addView(label("Last action: ${state.lastAction} • outcome: ${state.lastOutcome} • rollbacks ${state.rollbackCount}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(4))})
            state.recentActions.take(6).forEachIndexed{idx,line->addView(label("${idx+1}. $line",10f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(3),dp(12),dp(2))})}
        }
        addCollapsible("Dr. Frankenstein orchestrator","Capability registry and multi-engine control plane",false){
            addView(label("Guardian: ${AppManagers.guardian.snapshot()}",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(5))})
            AppManagers.bio.capabilities().forEach{cap->addView(label("${cap.name} • ${cap.owner} • ${cap.mutates}",10f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(2),dp(12),dp(2))})}
        }
        addCollapsible("Safety boundaries","What adaptive and Ben systems are not allowed to modify",true){
            addView(label("Adaptive Engine may tune safe runtime policy only. Ben neural inference is optional and governor-gated. No engine may alter question content, progress records, database schema, backups or executable code at runtime.",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),dp(6),dp(12),dp(5))})
            addView(label("Reset controls are explicit, destructive actions: episodic memory, knowledge graph and adaptive learning history.",10.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(12),0,dp(12),dp(6))})
        }

        root.addView(button("Reset Adaptive Learning History"){viewModel.resetAdaptiveLearning();Toast.makeText(activity,"Adaptive history reset",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,dp(16))})
    }

    private fun sectionView(title:String, subtitle:String):View = LinearLayout(activity).apply{
        orientation=LinearLayout.VERTICAL; setPadding(dp(2),dp(10),dp(2),dp(5))
        addView(TextView(activity).apply{text=title;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity))})
        addView(TextView(activity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(3),0,dp(4))})
    }
    private fun labelBlock(t:String)=TextView(activity).apply{text=t;textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(dp(12),dp(4),dp(12),dp(6))}
    private fun engineCard(title:String, subtitle:String, action:String, click:()->Unit)=LinearLayout(activity).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(10),dp(12))
        background=GradientDrawable().apply{setColor(ThemeManager.elevated(activity));cornerRadius=dp(16).toFloat();setStroke(dp(1),if(ThemeManager.isDark(activity))Color.rgb(48,61,75)else Color.rgb(220,226,230))}
        val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
        copy.addView(TextView(activity).apply{text=title;textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        copy.addView(TextView(activity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(3),0,0)})
        addView(copy,LinearLayout.LayoutParams(0,-2,1f))
        addView(TextView(activity).apply{text="OPEN";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));background=rounded(ThemeManager.explanationBg(activity),11);setPadding(dp(10),0,dp(10),0);setOnClickListener{click()}},LinearLayout.LayoutParams(dp(78),dp(38)))
    }
    private fun section(root:LinearLayout,t:String){root.addView(TextView(activity).apply{text=t;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(16),0,dp(8))})}
    private fun lp()=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}
    private fun button(t:String,click:()->Unit)=TextView(activity).apply{text=t;textSize=14f;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),0,dp(16),0);setTextColor(ThemeManager.text(activity));background=rounded(ThemeManager.elevated(activity),14);setOnClickListener{click()}}
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
}
