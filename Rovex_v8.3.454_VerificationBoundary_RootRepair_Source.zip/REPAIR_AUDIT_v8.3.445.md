# Rovex v8.3.445 — CI Runtime Regression Root Repair

Evidence: logs_98411185051.zip (36 instrumented tests, 17 failures).

## Root causes
1. Two DB regression suites opened qbank.db through a raw SQLite connection immediately after provider reset, before the authoritative QBankDatabaseProvider had recreated the schema. This caused `no such table: question_image` / `question_fts` and cascaded setup failures.
2. QBank search tokenization removed punctuation by concatenation, turning `question-A` into `questionA` and causing import-identity search assertions to miss valid rows.
3. Settings sectionBanner intentionally uppercases labels, while Stage7 instrumentation asserted title case `Engine overview`.

## Repairs
- Force provider schema initialization with the existing QBankDb wrapper before test-only raw connections.
- Preserve punctuation-sensitive search characters `%`, `_`, and backslash, but treat other punctuation as token boundaries.
- Align Stage7 assertions with the actual uppercase `ENGINE OVERVIEW` UI contract.
- No additional database owner introduced.
- Package: com.localqbank.library.
- versionName: 8.3.445; versionCode: 537.

## Verification
STATIC PASS: diff-scoped sanity checks completed.
BLOCKED: local Gradle execution because downloads.gradle.org DNS resolution is unavailable.
CI/device execution is required before any runtime PASS claim.
