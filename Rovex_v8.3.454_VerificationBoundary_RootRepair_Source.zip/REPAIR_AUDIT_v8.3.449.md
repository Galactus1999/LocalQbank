# Rovex v8.3.449 Repair Audit

Root repairs from CI run logs_98502147129.zip:
1. Hyphenated identity searches now use FTS token boundaries and cannot fall through to substring LIKE, preventing `question-A` from matching `question-A2`.
2. `%`, `_`, and backslash remain on the escaped SQLite LIKE path.
3. Identity/deletion regression tests resolve source IDs through authoritative QBankDb.sources() after provider-owned imports instead of relying on a potentially stale raw SQLite cursor.

Verification status:
- Static source repair: PASS
- Local Gradle build: BLOCKED unless Gradle dependencies are available
- CI: NOT YET EXECUTED for v8.3.449
- Device: NOT YET EXECUTED for v8.3.449

The EmbeddingGemma real-inference assumption remains SKIPPED/BLOCKED unless device artifacts permit it; this repair does not alter the neural backend.
