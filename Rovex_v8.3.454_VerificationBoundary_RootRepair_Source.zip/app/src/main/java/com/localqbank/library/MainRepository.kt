package com.localqbank.library

import android.content.Context

/**
 * Presentation-facing persistence seam for Home.
 * QBankDb/ProgressStore remain the authoritative storage implementations.
 */
class MainRepository(context: Context) : AutoCloseable {
    private val app = context.applicationContext
    // Database handles are opened lazily because ViewModel factories run on the main thread.
    // The first actual repository operation is executed by the owning background path.
    private val db by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { QBankDb(app) }
    private val progress by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { ProgressStore(app) }

    data class ResumeTarget(val testId: String, val position: Int, val title: String, val questionId: Long = 0L, val stableKey: String = "")

    fun questionExists(id: Long): Boolean = db.questionExists(id)
    fun progressSnapshot(): ProgressSnapshot = PerformanceManager.progress(app)
    fun testById(id: String): Test? = db.testById(id)
    fun sourceResume(sourceId: Long): String? = progress.sourceResume(sourceId)
    fun flushBackup() = BackupManager(app).flushCloudBackup()
    fun sourceResumeByName(sourceName: String): String? = progress.sourceResumeByName(sourceName)
    fun dailyGoal(): Int = db.getProgressMeta("rovex:goal:daily")?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    fun weeklyGoal(): Int = db.getProgressMeta("rovex:goal:weekly")?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    fun setDailyGoal(value: Int) = db.putProgressMeta("rovex:goal:daily", value.coerceIn(0,10000).toString())
    fun setWeeklyGoal(value: Int) = db.putProgressMeta("rovex:goal:weekly", value.coerceIn(0,50000).toString())
    fun qbankLibraryOrder(): List<Long> = db.getProgressMeta("rovex:qbank:order").orEmpty().split(',').mapNotNull{it.toLongOrNull()}
    fun setQBankLibraryOrder(ids: List<Long>) = db.putProgressMeta("rovex:qbank:order", ids.distinct().joinToString(","))
    fun latestResumeTarget(sources: List<Source>): ResumeTarget? {
        // The live study-session cursor is the strongest resume source: it is checkpointed
        // synchronously by QuizViewModel and contains the exact question position, not merely
        // the last QBank that happened to be opened. Fall back to the durable progress meta for
        // older sessions/backups that predate the session store.
        runCatching { StudySessionStore(app).current() }.getOrNull()?.let { session ->
            if (session.testId.isNotBlank() && !session.id.endsWith(":collection", true)) {
                db.testById(session.testId)?.let { test ->
                    val completed = db.getProgressMeta("${test.id}:completed") == "1"
                    if (!completed) {
                        val stable = session.stableKey.takeIf { it.isNotBlank() }
                        val resolved = stable?.let { runCatching { db.questionByStableKey(it) }.getOrNull() }
                        val position = resolved?.position ?: session.position.coerceIn(0, (test.count - 1).coerceAtLeast(0))
                        return ResumeTarget(test.id, position, test.title, resolved?.id ?: 0L, stable.orEmpty())
                    }
                }
            }
        }
        val raw = db.getProgressMeta("last_resume_global")
        if (!raw.isNullOrBlank()) {
            val parts = raw.split("|", limit = 4)
            val testId = parts.getOrNull(0).orEmpty()
            val pos = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val test = testId.takeIf { it.isNotBlank() }?.let { db.testById(it) }
            if (test != null && db.getProgressMeta("${test.id}:completed") != "1") {
                val safePos = pos.coerceIn(0, (test.count - 1).coerceAtLeast(0))
                val question = runCatching { db.questionAt(test.id, safePos) }.getOrNull()
                return ResumeTarget(test.id, question?.position ?: safePos, test.title, question?.id ?: 0L, question?.stableKey.orEmpty())
            }
        }
        return resumeTargets(sources).values.firstOrNull()
    }

    fun resumeTarget(source: Source): ResumeTarget? {
        val raw = sourceResumeByName(source.fileName) ?: sourceResume(source.id) ?: return null
        val parts = raw.split("|", limit = 2)
        val testId = parts.getOrNull(0).orEmpty()
        if (testId.isBlank()) return null
        val test = db.testById(testId) ?: return null
        if (db.getProgressMeta("${test.id}:completed") == "1") return null
        val safePos = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, (test.count - 1).coerceAtLeast(0)) ?: 0
        val question = runCatching { db.questionAt(test.id, safePos) }.getOrNull()
        return ResumeTarget(test.id, question?.position ?: safePos, test.title, question?.id ?: 0L, question?.stableKey.orEmpty())
    }

    fun resumeTargets(sources: List<Source>): Map<Long, ResumeTarget> = buildMap {
        sources.forEach { source -> resumeTarget(source)?.let { put(source.id, it) } }
    }

    fun requestSourceDeletion(sourceId: Long): Boolean = db.requestSourceDeletion(sourceId)

    fun deleteSource(sourceId: Long): Boolean = db.deleteSource(sourceId)

    fun updateSourceMetadata(sourceId: Long, name: String, series: String): Boolean =
        db.updateSourceMetadata(sourceId, name, series)

    override fun close() {
        runCatching { db.close() }
    }
}
