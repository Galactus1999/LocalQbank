package com.localqbank.library

import android.content.Context
import android.os.Process
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Resumes source-tombstoned QBank deletions after an app/process death. It is deliberately
 * low-priority and delayed so recovery never competes aggressively with foreground study.
 */
class QBankDeletionRecoveryWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_LOWEST)
            val db = QBankDb(applicationContext)
            // Recover legacy hidden QBanks first. This operation only changes visibility and never deletes
            // legacy rows. Only explicit delete_requested=1 sources are eligible for destructive
            // recovery, so process death can never silently destroy an imported QBank.
            db.restoreLegacyTombstonedSources()
            var failed = false
            // Re-query after each pass so a delete requested while this worker is already running
            // is picked up without waiting for an app restart. The delete itself is idempotent and
            // resumable, so process death between passes is safe.
            while (true) {
                val ids = db.pendingDeletingSourceIds()
                if (ids.isEmpty()) break
                ids.forEach { id ->
                    val ok = runCatching { QBankDb(applicationContext).deleteSource(id, repairSearchIndex = false) }.getOrDefault(false)
                    if (!ok) failed = true
                }
                if (failed) break
            }
            if (failed) Result.retry() else Result.success()
        } catch (t: CancellationException) {
            throw t
        } catch (t: Exception) {
            ProductionCrashReporter.recordNonFatal(t, "QBANK_DELETE_RECOVERY")
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE = "rovex_qbank_delete_recovery"
        fun enqueue(context: Context) {
            val request = OneTimeWorkRequestBuilder<QBankDeletionRecoveryWorker>()
                .setInitialDelay(0, TimeUnit.SECONDS)
                .addTag(UNIQUE)
                .build()
            WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                UNIQUE, ExistingWorkPolicy.APPEND_OR_REPLACE, request
            )
        }
    }
}
