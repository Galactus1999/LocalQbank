package com.localqbank.library

import android.content.Context
import kotlinx.coroutines.CancellationException
import java.util.Locale

/**
 * Builds the bounded "Frankenstein Context" envelope used by Ben and selected accelerators.
 *
 * It is retrieval-only: it never changes QBank truth, progress, SRS or notes. The QBank remains
 * authoritative; this layer assembles useful context around the current question so the cloud
 * model does not have to rediscover the student's local corpus from scratch.
 */
class FrankensteinContextEngine(context: Context) {
    private val app = context.applicationContext
    private val learner = BenLearnerModel(app)
    private val questionAiPolicy = BenQuestionAiContextPolicy()

    data class RelatedQuestion(
        val id: Long,
        val exam: String,
        val source: String,
        val text: String,
        val answer: String,
        val similarity: Double? = null,
        val category: String = ""
    )

    data class ContextBundle(
        val question: Question,
        val concepts: List<String>,
        val weakestConcept: String?,
        val weakestMastery: Int?,
        val relatedQuestions: List<RelatedQuestion>,
        val relatedSources: List<String>,
        val personalNote: String?,
        val localEvidenceCount: Int,
        val summary: String,
        val examPromptContext: String = "",
        val pdfEvidence: List<BenPdfResearchStore.PageHit> = emptyList()
    ) {
        fun promptBlock(): String = buildString {
            append("FRANKENSTEIN CONTEXT — LOCAL EVIDENCE ONLY\n")
            append(examPromptContext).append("\n")
            append("This envelope was assembled from Rovex's local QBank, learner memory and notes.\n")
            append("Never claim that a row is a true PYQ or that an exam repeated a question unless its local provenance explicitly establishes that.\n\n")
            append("CONCEPTS: ").append(concepts.joinToString(", ").ifBlank { "not confidently mapped" }).append('\n')
            weakestConcept?.let { append("LEARNER WEAKNESS: $it (${weakestMastery ?: 0}% local mastery estimate)\n") }
            personalNote?.let { append("STUDENT NOTE: ").append(it.take(1200)).append('\n') }
            append("RELATED LOCAL QUESTIONS: ").append(relatedQuestions.size).append('\n')
            relatedQuestions.forEachIndexed { i, row ->
                append("[LOCAL-${i + 1}] EXAM/SOURCE: ${row.exam.ifBlank { "Unknown" }} | ${row.source.ifBlank { "Unknown source" }}\n")
                append("QUESTION: ${row.text.take(900)}\nKEY: ${row.answer.take(260)}")
                row.similarity?.let { append(" • semantic=${"%.3f".format(it)}") }
                append("\n")
            }
            if (relatedSources.isNotEmpty()) append("LOCAL SOURCE CLUSTERS: ${relatedSources.joinToString(" • ")}\n")
        }
    }

    /**
     * Enhanced context path: deterministic retrieval is always first. If EmbeddingGemma is already
     * warm, it cheaply reranks the bounded candidate set; it never cold-starts the native runtime
     * merely because a user opened a context panel.
     */
    suspend fun buildEnhanced(question: Question): ContextBundle {
        val base = build(question)
        if (base.relatedQuestions.size < 2) return base
        // Passive context construction must never cold-start native inference. Ask the
        // authoritative isolated service whether EmbeddingGemma is already warm; only then
        // perform the bounded rerank through the same IPC path used by Ben's main pipeline.
        val inference = BenInferenceProcessClient(app)
        if (!inference.embeddingWarmSuspend()) {
            inference.close()
            return base
        }
        val candidates = base.relatedQuestions.map { it.text + "\n" + it.answer }
        val reranked = try {
            inference.rerankSuspend(question.text, candidates, minOf(8, candidates.size))
        } catch (t: CancellationException) {
            inference.close()
            throw t
        } catch (_: Exception) {
            null
        }
        if (reranked == null || !reranked.usedModel || reranked.indices.isEmpty()) {
            inference.close()
            return base
        }
        // RerankResult.indices is an IntArray. Convert to a List before using the
        // indexed nullable transform so the compiler has a concrete Int element type
        // and the candidate index remains distinct from the rank used for scores.
        val ranked = reranked.indices.toList().mapIndexedNotNull { rank, candidateIndex ->
            base.relatedQuestions.getOrNull(candidateIndex)?.copy(
                similarity = reranked.scores.getOrNull(rank)
            )
        }
        inference.close()
        if (ranked.isEmpty()) return base
        return base.copy(
            relatedQuestions = ranked,
            relatedSources = ranked.map { "${it.exam} / ${it.source}" }.distinct().take(8),
            summary = "${ranked.size} semantically reranked local questions • ${base.concepts.take(3).joinToString(", ").ifBlank { "no confident concepts" }}"
        )
    }

    fun questionAiEvidence(question: Question, mode: BenQuestionAiMode): String =
        questionAiPolicy.evidence(question, build(question), mode)

    fun savedQuestionAiEvidence(questionId: Long, mode: BenQuestionAiMode): String = runCatching {
        val db = QBankDb(app)
        try { db.questionById(questionId)?.let { questionAiEvidence(it, mode) }.orEmpty() } finally { db.close() }
    }.getOrDefault("")

    fun build(question: Question): ContextBundle {
        val understanding = runCatching { ClinicalKnowledgeLayer(app).understand(question.text) }.getOrNull()
        val concepts = understanding?.concepts?.map { it.canonical }?.distinct()?.take(8).orEmpty()
        val weakest = concepts.minByOrNull { learner.stats(it).mastery }
        val weakestMastery = weakest?.let { learner.stats(it).mastery }
        val note = runCatching {
            val db = QBankDb(app)
            try { db.notes().firstOrNull { it.first == question.id }?.second?.trim()?.takeIf { it.isNotBlank() } }
            finally { db.close() }
        }.getOrNull()

        // Fast path: one bounded semantic/lexical retrieval over the actual question text.
        // The previous implementation opened/searches the QBank once per token (up to eight
        // SQLite searches). That multiplied latency for every Frankenstein context request.
        // Never materialize the entire QBank corpus for one AI context request. On large imports
        // this created a massive QuestionRef list and competed with Quiz/QBank SQLite work.
        // Retrieval already returns bounded question IDs; resolve only those rows.
        val ids = linkedSetOf<Long>()
        runCatching { AppManagers.renCognitive.searchQuestionIds(question.text, 32) }
            .getOrDefault(LongArray(0))
            .forEach { id -> if (id != question.id) ids += id }

        // Only if the exact-question retrieval is sparse, use a very small lexical fallback.
        // This keeps recall for short/noisy questions without returning to the old 8x fan-out.
        if (ids.size < 8) {
            Regex("[A-Za-z][A-Za-z-]{3,}")
                .findAll(question.text)
                .map { it.value.lowercase(Locale.US) }
                .distinct()
                .take(3)
                .forEach { token ->
                    runCatching { AppManagers.renCognitive.searchQuestionIds(token, 12) }
                        .getOrDefault(LongArray(0))
                        .forEach { id -> if (id != question.id) ids += id }
                }
        }
        val related: List<RelatedQuestion> = runCatching<List<RelatedQuestion>> {
            val db = QBankDb(app)
            try {
                val wanted = ids.take(16).toLongArray()
                if (wanted.isEmpty()) return@runCatching emptyList()
                val refs: List<QuestionRef> = db.questionRefsForIdsBounded(wanted)
                val byId: Map<Long, QuestionRef> = refs.associateBy { ref -> ref.id }
                wanted.asList().mapNotNull { id ->
                    val ref = byId[id] ?: return@mapNotNull null
                    val q = db.questionById(id) ?: return@mapNotNull null
                    RelatedQuestion(
                        id,
                        ref.testTitle,
                        ref.sourceName,
                        q.text,
                        q.correctAnswer.orEmpty(),
                        null,
                        ref.category
                    )
                }
            } finally {
                db.close()
            }
        }.getOrDefault(emptyList())
        val sources = related.map { "${it.exam} / ${it.source}" }.distinct().take(8)
        val pdfEvidence = runCatching { BenPdfResearchStore(app).search(question.text, 6) }.getOrDefault(emptyList())
        val summary = buildString {
            append(related.size).append(" related local questions")
            if (concepts.isNotEmpty()) append(" • ").append(concepts.take(3).joinToString(", "))
            weakest?.let { append(" • weakness: ").append(it).append(" ").append(weakestMastery).append('%') }
            if (note != null) append(" • personal note available")
        }
        return ContextBundle(question, concepts, weakest, weakestMastery, related, sources, note, related.size + concepts.size + if (note != null) 1 else 0, summary, benExamPromptContext(app), pdfEvidence)
    }
}
