package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

class SearchActivity: AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var searchBox: EditText
    private lateinit var results: RecyclerView
    private lateinit var empty: TextView
    private lateinit var countText: TextView
    private val rows = mutableListOf<SearchRow>()
    private val executor = LifecycleExecutor(Executors.newSingleThreadExecutor { r -> Thread(r, "qbank-search") })
    private val generation = AtomicLong(0)
    private val localSearch by lazy { LocalQBankSearchService(applicationContext) }
    private var filter = "all"
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        try {
            db=QBankDb(this)
        } catch (t: Exception) {
            showSearchStartupError(t)
            return
        }
        setContentView(build())
        TransitionCoordinator.install(this)
        searchBox.requestFocus()
        searchBox.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox,InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun showSearchStartupError(t: Throwable) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            background = ThemeManager.backgroundDrawable(this@SearchActivity)
        }
        root.addView(TextView(this).apply {
            text = "Search is temporarily unavailable"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@SearchActivity))
        })
        root.addView(TextView(this).apply {
            text = "Your QBank data is safe. Close Search and continue studying."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.muted(this@SearchActivity))
            setPadding(0, dp(10), 0, dp(18))
        })
        root.addView(TextView(this).apply {
            text = "CLOSE"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.bg(this@SearchActivity))
            background = rounded(ThemeManager.accent(this@SearchActivity), 14f)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(140), dp(44)))
        setContentView(root)
        android.util.Log.e("Rovex.Search", "Search database startup failed", t)
    }

    private fun build():View {
        val dark=ThemeManager.isDark(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=ThemeManager.backgroundDrawable(this@SearchActivity)}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(8),dp(12),dp(8));setBackgroundColor(Color.rgb(26,70,99))}
        val back=TextView(this).apply{
            text="←";textSize=23f;setTextColor(Color.WHITE);gravity=Gravity.CENTER
            background=rounded(if(dark)Color.rgb(31,43,58) else Color.rgb(28,70,103),12f)
            setOnClickListener{finish()}
            contentDescription="Back"
        }
        bar.addView(back,LinearLayout.LayoutParams(dp(56),dp(56)).apply{setMargins(0,0,dp(8),0)})
        val title=TextView(this).apply{text="Search QBank";textSize=20f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)}
        bar.addView(title,LinearLayout.LayoutParams(0,-2,1f));root.addView(bar)

        val input=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(5))}
        searchBox=EditText(this).apply{
            hint="Search questions, sections, QBanks…";textSize=16f;setSingleLine(true)
            setTextColor(ThemeManager.text(this@SearchActivity));setHintTextColor(ThemeManager.muted(this@SearchActivity))
            setBackground(rounded(ThemeManager.elevated(this@SearchActivity),16f));setPadding(dp(14),0,dp(10),0)
            imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        input.addView(searchBox,LinearLayout.LayoutParams(0,dp(52),1f));root.addView(input)
        val hint=TextView(this).apply{text="Type a topic, subsection, question, option, explanation or QBank name";textSize=12f;setTextColor(ThemeManager.muted(this@SearchActivity));setPadding(dp(16),0,dp(16),dp(5))};root.addView(hint)

        val chipScroll=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=false;setPadding(dp(10),dp(3),dp(10),dp(5))}
        val chips=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val filters=listOf("all" to "All","correct" to "Solved","unsolved" to "Unsolved","wrong" to "Wrong","bookmark" to "Bookmarked","important" to "Important","revise" to "Revise","doubt" to "Doubt","favorite" to "Favourite")
        filters.forEach{(key,label)->
            val chip=TextView(this).apply{text=label;textSize=12f;gravity=Gravity.CENTER;setPadding(dp(14),0,dp(14),0);minHeight=dp(38);setTypeface(null,Typeface.BOLD);isClickable=true}
            chip.setOnClickListener{
                filter=key
                styleChipRow(chips)
                generation.incrementAndGet()
                runSearch(searchBox.text.toString())
            }
            chip.tag=key;chips.addView(chip,LinearLayout.LayoutParams(-2,dp(38)).apply{setMargins(0,0,dp(6),0)})
        }
        chipScroll.addView(chips);root.addView(chipScroll);styleChipRow(chips)

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(2),dp(16),dp(4))}
        countText=TextView(this).apply{text="";textSize=12f;setTextColor(ThemeManager.muted(this@SearchActivity))};row.addView(countText,LinearLayout.LayoutParams(0,-2,1f))
        val clear=TextView(this).apply{text="Clear";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@SearchActivity));setOnClickListener{searchBox.text.clear();searchBox.requestFocus()}}
        row.addView(clear);root.addView(row)

        results=RecyclerView(this).apply{AppManagers.runtime.configureRecyclerView(this, fixedSize=false);layoutManager=LinearLayoutManager(this@SearchActivity);adapter=SearchAdapter(rows){open(it)};itemAnimator=null;setHasFixedSize(false);overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        root.addView(results,LinearLayout.LayoutParams(-1,0,1f))
        empty=TextView(this).apply{text="Start typing to search";textSize=16f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@SearchActivity))};root.addView(empty,LinearLayout.LayoutParams(-1,0,1f));results.visibility=View.GONE

        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=2f;setPadding(dp(7),dp(7),dp(7),dp(7));setBackgroundColor(Color.rgb(26,70,99))}
        val dash=navButton("⌂  Dashboard",false);dash.setOnClickListener{finish()}
        val search=navButton("⌕  Search",true)
        nav.addView(dash,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(4),0)});nav.addView(search,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(4),0,0,0)});root.addView(nav)

        searchBox.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){scheduleSearch(s?.toString() ?: "")}
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        return root
    }

    private fun navButton(text:String,selected:Boolean)=TextView(this).apply{
        this.text=text;textSize=13f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(if(selected)ThemeManager.accent(this@SearchActivity) else Color.WHITE)
        background=rounded(if(selected)ThemeManager.elevated(this@SearchActivity) else Color.rgb(43,82,111),12f)
    }

    private fun styleChipRow(chips:LinearLayout){
        for(i in 0 until chips.childCount){val v=chips.getChildAt(i) as TextView;val selected=v.tag==filter;v.setTextColor(if(selected)Color.WHITE else ThemeManager.text(this));v.background=rounded(if(selected)ThemeManager.accent(this) else ThemeManager.elevated(this),18f)}
    }

    private fun scheduleSearch(q:String){
        val serial=generation.incrementAndGet()
        android.os.Handler(mainLooper).postDelayed({if(generation.get()==serial) runSearch(q)},230)
    }

    private fun runSearch(q:String){
        if (!::db.isInitialized || isFinishing || isDestroyed) return
        val text=q.trim(); val serial=generation.get()
        if(text.isBlank()){
            rows.clear(); results.visibility=View.GONE; empty.visibility=View.VISIBLE
            empty.text="Start typing to search"; countText.text=""; return
        }
        executor.execute {
            try {
                val found=mutableListOf<SearchRow>()
                val progress=PerformanceManager.progress(applicationContext)
                // One retrieval contract for questions and hierarchy. This deliberately does not
                // require FTS to be healthy before returning results: LocalQBankSearchService
                // contains the bounded FTS + LIKE + clinical-alias recall ladder.
                localSearch.searchSections(text, 60).forEach { section ->
                    found += SearchRow.Section(section)
                }
                localSearch.search(text, 300).hits.forEach { hit ->
                    if(matchesFilter(hit, progress)) found += SearchRow.Question(hit)
                }
                val deduped=found.distinctBy {
                    when(it){
                        is SearchRow.Section -> "S:${it.x.testId}"
                        is SearchRow.Question -> "Q:${it.x.id}"
                    }
                }
                runOnUiThread{
                    if(isFinishing || serial!=generation.get()) return@runOnUiThread
                    rows.clear(); rows.addAll(deduped)
                    results.visibility=if(rows.isEmpty())View.GONE else View.VISIBLE
                    empty.visibility=if(rows.isEmpty())View.VISIBLE else View.GONE
                    empty.text=if(rows.isEmpty())"No matching results" else ""
                    val questionResultCount = deduped.count { it is SearchRow.Question }
                    countText.text=when {
                        questionResultCount > 0 -> "$questionResultCount questions"
                        deduped.isNotEmpty() -> "${deduped.size} sections"
                        else -> ""
                    }
                    results.adapter?.notifyDataSetChanged()
                }
            } catch(t:Exception){
                if(t is kotlinx.coroutines.CancellationException) throw t
                android.util.Log.e("Rovex.Search", "Search retrieval failed", t)
                runOnUiThread{
                    if(!isFinishing&&serial==generation.get()){
                        rows.clear(); results.visibility=View.GONE; empty.visibility=View.VISIBLE
                        empty.text="Search temporarily unavailable. Your QBank data is safe."; countText.text=""
                    }
                }
            }
        }
    }

    private fun matchesFilter(h:SearchHit, progress: ProgressSnapshot):Boolean {
        val p = progress.record(h.stableKey)
        return when(filter){
            "all"->true
            "correct"->p?.status=="correct"
            "wrong"->p?.status=="wrong"
            "unsolved"->p?.status.isNullOrBlank()
            "bookmark"->!p?.bookmark.isNullOrBlank()
            else->p?.bookmark==filter
        }
    }

    private fun open(row:SearchRow){
        val testId = when(row){
            is SearchRow.Section -> row.x.testId
            is SearchRow.Question -> row.x.testId
        }
        if (testId.isBlank()) return
        val serial = generation.incrementAndGet()
        PerformanceManager.submit {
            val valid = runCatching {
                QBankDb(applicationContext).let { db2 ->
                    try { db2.testById(testId) != null && db2.questionCount(testId) > 0 } finally { db2.close() }
                }
            }.getOrDefault(false)
            runOnUiThread {
                if (isFinishing || isDestroyed || serial != generation.get() || !valid) return@runOnUiThread
                when(row){
                    is SearchRow.Section -> startActivity(Intent(this,QuizActivity::class.java)
                        .putExtra("testId",row.x.testId)
                        .putExtra("title",row.x.title)
                        .putExtra("position",0)
                        .putExtra("sectionLabel",row.x.path.ifBlank{row.x.title})
                        .putExtra("practiceMode",true))
                    is SearchRow.Question -> {
                        // A search result is a study set, not a one-question launch. Preserve the
                        // exact retrieval order so Next/Previous follows the visible result set.
                        val sessionIds = buildSearchSessionIds(rows.filterIsInstance<SearchRow.Question>().map { it.x.id })
                        startActivity(Intent(this,QuizActivity::class.java)
                            .putExtra("testId",row.x.testId)
                            .putExtra("questionId",row.x.id)
                            .putExtra("title",row.x.testTitle)
                            .putExtra("position",sessionIds.indexOf(row.x.id.toString()).coerceAtLeast(0))
                            .putExtra("sessionIds",sessionIds)
                            .putExtra("collectionMode",true)
                            .putExtra("sessionLabel", "Search: ${searchBox.text.toString().trim()}")
                            .putExtra("sectionLabel",row.x.path ?: row.x.testTitle)
                            .putExtra("practiceMode",true))
                    }
                }
            }
        }
    }
    private fun rounded(c:Int,r:Float)=GradientDrawable().apply{setColor(c);cornerRadius=r*resources.displayMetrics.density}
    override fun onResume(){super.onResume();if(::searchBox.isInitialized && ::db.isInitialized)runSearch(searchBox.text.toString())}
    override fun onDestroy(){executor.close();if(::db.isInitialized)runCatching{db.close()};super.onDestroy()}
}

sealed class SearchRow{data class Section(val x:SectionHit):SearchRow();data class Question(val x:SearchHit):SearchRow()}

class SearchAdapter(private val items:List<SearchRow>,private val click:(SearchRow)->Unit):RecyclerView.Adapter<SearchAdapter.VH>(){
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){val tag=TextView(v.context);val title=TextView(v.context);val sub=TextView(v.context);init{v.orientation=LinearLayout.VERTICAL;v.setPadding(16,14,16,14);v.addView(tag);v.addView(title);v.addView(sub)}}
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{val v=LinearLayout(p.context);v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(10,5,10,5)};return VH(v)}
    override fun onBindViewHolder(h:VH,i:Int){val row=items[i];val c=h.itemView.context;val dark=ThemeManager.isDark(c);h.itemView.background=GradientDrawable().apply{setColor(if(dark)ThemeManager.elevated(c) else Color.rgb(247,250,253));cornerRadius=16f*c.resources.displayMetrics.density};when(row){is SearchRow.Section->{h.tag.text=if(row.x.path.isBlank())"QBANK" else "SUB-QBANK";h.title.text=row.x.title;h.sub.text="${row.x.sourceName}  •  ${row.x.count} questions${if(row.x.path.isBlank())"" else "  •  "+row.x.path}"};is SearchRow.Question->{h.tag.text="QUESTION";h.title.text="Q${row.x.position+1}. "+Html.fromHtml(row.x.text,Html.FROM_HTML_MODE_LEGACY).toString().trim().take(220);h.sub.text="${row.x.sourceName}  •  ${row.x.testTitle}${if(row.x.path.isNullOrBlank())"" else "  •  "+row.x.path}"}};h.tag.textSize=11f;h.tag.setTypeface(null,Typeface.BOLD);h.tag.setTextColor(ThemeManager.accent(c));h.title.textSize=15f;h.title.setTextColor(ThemeManager.text(c));h.title.ellipsize=TextUtils.TruncateAt.END;h.sub.textSize=12f;h.sub.setTextColor(ThemeManager.muted(c));h.title.setPadding(0,4,0,0);h.sub.setPadding(0,5,0,0);h.itemView.setOnClickListener{click(row)}}
    override fun getItemCount()=items.size
}



internal fun buildSearchSessionIds(ids: List<Long>): String = ids.asSequence()
    .filter { it > 0L }
    .distinct()
    .take(500)
    .joinToString(",")
