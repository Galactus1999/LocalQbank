# Rovex Phase-0 Test Compile Repair — v8.3.439

## Root cause proven by CI Run 395 / 36305031456
The emulator boot/KVM issue was resolved enough for the instrumented action to launch Gradle. The actual failure then occurred at `:app:compileDebugAndroidTestKotlin`.

The compiler errors were in the existing Android-test sources, not the application production sources:
- `QBankDbSearchRegressionTest.kt`: `SearchHit` exposes `id`, not `questionId`.
- `QBankDeletionIsolationTest.kt`: `SearchHit` exposes `id`, not `questionId`.
- `RovexStage7InstrumentedTest.kt`: Espresso `matches` was imported from `ViewMatchers` instead of `ViewAssertions`.
- `RovexStage7InstrumentedTest.kt`: direct `ViewModel.clear()` is not public; the test now owns the ViewModel through a `ViewModelStore` and calls `store.clear()` for normal lifecycle cleanup.

## Offline repairs
- Replaced erroneous `.questionId` test references with `.id`.
- Corrected Espresso `matches` import.
- Reworked the FlashcardViewModel test to use `ViewModelProvider` + `ViewModelStore` and lifecycle-safe cleanup.
- Incremented source version to 8.3.439 / versionCode 531.
- Refreshed the offline Phase-0 gate to the new authoritative revision.

## Static verification
`tools/phase0_offline_gate.py`: PASS.
No remaining Android-test occurrences of `.questionId`, `ViewMatchers.matches`, or `viewModel.clear()`.

## Build verification
Local Gradle compilation remains BLOCKED because Gradle 9.3.1 is not cached and `downloads.gradle.org` DNS is unavailable in the offline environment. CI is required for actual Kotlin compilation and instrumented execution.
