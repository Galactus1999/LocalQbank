# Rovex v8.3.454 — Verification-Boundary Root Repair

## Scope
This batch does not change the QBank production algorithm. It hardens the verification boundary after rescanning v8.3.453.

## Findings corrected
1. `tools/phase0_offline_gate.py` was still hard-coded to obsolete v8.3.441/versionCode 533.
   - Corrected to validate the authoritative package/version fields without falsely requiring an obsolete release number.
2. The gate expected an obsolete tokenizer implementation and counted an obsolete `ESCAPE '\\'` spelling.
   - Corrected to validate the current raw-token literal-syntax boundary and actual `ESCAPE CHAR(92)` SQL path.
3. The source archive contained historical `.github/ci/rovex_446_overlay2.py`, a source-mutating CI overlay.
   - Removed. The offline gate now explicitly rejects source-mutating overlay scripts.
4. Source script executable bits were normalized for the packaged `gradlew` and audit scripts.

## Existing functional repairs rechecked
- Hyphen-bearing search uses quoted FTS before any fail-closed path.
- Legacy tombstone recovery is explicit and only restores `deleting=1, delete_requested=0` sources with surviving content.
- Public `Source.fileName` is display-name based; regression tests use public display names rather than internal import keys.
- Internal import identity remains `safeImportKey(importKey)` and `source.file_name` remains UNIQUE; no false migration claim was introduced.
- Incremental deletion/FTS cleanup architecture remains intact.

## Static verification executed
PASS:
- tools/verify_search_qbank_regressions.sh
- tools/verify_root_architecture.sh
- tools/verify_defect_regressions.sh
- tools/verify_search_regression_repair.sh
- tools/phase0_offline_gate.py

## Runtime verification
v8.3.451 CI: debug/test APK build PASS; 36 instrumentation tests executed; 2 recovery tests FAILED.
v8.3.453 CI/device: NOT VERIFIED by this batch.
v8.3.454 CI/device: NOT VERIFIED.
No runtime or device PASS is claimed for v8.3.454.
