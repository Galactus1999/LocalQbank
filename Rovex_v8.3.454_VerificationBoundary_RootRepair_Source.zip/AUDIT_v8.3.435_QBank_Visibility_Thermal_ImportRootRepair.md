# Deep Root Audit — Rovex v8.3.435

## Device evidence interpreted

The supplied screenshot shows Rovex 8.3.434 with approximately 2.02 GB application data and 333 MB cache, while the QBank UI reports no imported QBanks. A separate screenshot shows SQLite error 2067: `UNIQUE constraint failed: source.file_name`.

The source audit of v8.3.434 found that `source.deleting` was overloaded as both a hidden/tombstone flag and the recovery worker's deletion criterion. The v8.3.434 production importer already generated URI-derived `rvx-uri-*` keys, but the schema/legacy compatibility path still used `file_name TEXT UNIQUE`, leaving a fragile unique-key boundary. Large HTML staging files were also not guaranteed to be removed. Home refresh still materialized all lightweight question references and the full progress snapshot.

## Root repairs in v8.3.435

### A. QBank visibility/data preservation
- Added `source.delete_requested`.
- Explicit delete/replacement sets `deleting=1, delete_requested=1`.
- Legacy tombstones with `delete_requested=0` are recovery candidates, not deletion candidates.
- `restoreLegacyTombstonedSources()` restores any legacy source with surviving test/question content.
- `sources()` performs that recovery before catalog rendering.
- Recovery worker only calls destructive `deleteSource()` for `delete_requested=1`.
- This removes the root ambiguity that could turn a crash/legacy hidden source into a permanent disappearance.

### B. Import identity
- Production URI identity remains stable and opaque.
- `safeImportKey()` hashes legacy/compatibility keys, so raw human filenames are no longer used as new internal identity values.
- Human `display_name` remains the user-visible filename.
- Same display filename from different documents remains isolated.
- Reimport of the same URI still replaces only that identity.

### C. Home performance / thermal load
- Replaced Home's full `PerformanceManager.lightRefs()` + full progress snapshot path with `QBankDb.homeStudyStats()` SQL aggregation.
- Home now reads only sparse progress rows needed for today/week/28-day metrics and joins them to live QBank ownership.
- No full question-reference corpus is materialized on ordinary Home refresh.
- Ben knowledge indexing is constrained to charging + battery-not-low + device-idle + storage-not-low.
- Automatic backups are constrained to charging + battery-not-low + device-idle; cloud backup additionally requires network.

### D. Cache growth
- Large HTML staging files under `cacheDir/q_import_*` are now deleted in `finally` after both success and failure.
- The streaming repository is closed deterministically.
- This prevents future large-import cache accumulation.

## External research incorporated

- Android SQLite guidance recommends reading fewer rows/columns, pushing aggregation into SQLite, using indexes, WAL, and bounded/batched transactions; Android notes only one write transaction can occur at a time. Source: Android Developers SQLite performance guidance.
- Android background-work guidance warns that background processes can be memory- and battery-intensive and recommends the appropriate constrained API.
- Android thermal APIs expose thermal status so apps can back off expensive activity under thermal stress.
- GitHub research covered the public `question-bank`, `html-parser`, and `sqlite-android` ecosystems and targeted repositories including Anki HTML importer, medical QBank HTML projects, SQLite import/export projects, and exam-bank SQLite applications. Relevant examples: Ziinc/anki-plugin-html-importer, emmettg15/qbank-project, drhimam/MedQbank20251010, CAPTW/exam-weaver-archive, androidmads/SQLiteImporterExporter. The goal was to extract architecture patterns rather than copy unverified code.

## Static proof

PASS:
- verify_performance_search_architecture.sh
- verify_search_qbank_regressions.sh
- ruthless_audit.sh
- audit_coroutine_cancellation.py
- audit_frankenstein_policy.py
- verify_root_architecture.sh
- delimiter balance for modified Kotlin source/tests
- no legacy `restoreCompleteTombstonedSources` call remains
- Home no longer calls `PerformanceManager.lightRefs()` in `refreshDynamic()`
- `q_import_*` staging file is enclosed by deterministic cleanup
- Ben knowledge worker has idle/charging/battery/storage constraints

## Build limitation

The environment attempted `./gradlew --offline :app:compileDebugKotlin --no-daemon`, but the Gradle wrapper attempted to obtain Gradle 9.3.1 and DNS could not resolve `downloads.gradle.org`. Therefore this report does not claim a green Gradle build, APK, or device runtime test.
