# Rovex v8.3.453 — Recovery Test + Verification Root Repair

## CI evidence
The supplied v8.3.451 CI run selected the exact source archive SHA-256:
`b5ed66cc6c89aefe0d86cd3f92f020a06f2a077fc455355b5a6654ffb974cd39`.
It built the debug and Android-test targets successfully and executed 36 instrumented tests.
Two substantive tests failed with `NoSuchElementException`:
- `QBankDeletionIsolationTest.crashRecoveryOnlyResumesExplicitDeletionAndRestoresLegacyHiddenData`
- `QBankImportIdentityRegressionTest.legacyHiddenQBankIsRecoveredWithoutDeletingItsData`

The same run also reported one EmbeddingGemma assumption skip. That is not treated as a QBank regression.

## Root cause proven from source + CI
`QBankDb.sources()` returns `COALESCE(display_name,file_name)` as the public `Source.fileName` value.
The failing recovery tests incorrectly searched this public field using the internal import key.
Examples fixed:
- `rvx-uri-legacy` -> public display name `old.html`
- `legacy-hidden` -> public display name `legacy.html`
- `explicit-delete` -> public display name `same.html`

The production recovery API was not changed in this batch.

## Verification-script regression also found
`tools/verify_defect_regressions.sh` still required Main Search to call `QBankDb.searchSections()` and `QBankDb.search()` directly.
Current architecture intentionally routes Main Search through the authoritative `LocalQBankSearchService`.
The verifier was corrected to assert:
- `localSearch.searchSections(text, 60)`
- `localSearch.search(text, 300)`
This aligns the verifier with the actual authoritative architecture instead of forcing a stale implementation detail.

## Static verification executed
PASS:
- `tools/verify_search_qbank_regressions.sh`
- `tools/verify_root_architecture.sh`
- `tools/verify_defect_regressions.sh`
- `tools/verify_search_regression_repair.sh`

The earlier malformed Kotlin escaping is absent.
The old premature hyphen-search empty-list branch is absent from the FTS decision point.
The `source.file_name UNIQUE` schema constraint remains present; no false claim of its removal is made.

## Runtime verification status
- v8.3.451 compilation: VERIFIED by CI.
- v8.3.451 instrumentation: FAILED — exactly the two recovery-test failures above.
- v8.3.453 compilation: NOT YET VERIFIED.
- v8.3.453 instrumentation: NOT YET VERIFIED.
- Physical-device validation: NOT VERIFIED.

No runtime PASS is claimed for v8.3.453 until a new CI run actually executes the artifact.
