# Rovex v8.3.441 — QBank Delete Responsiveness / Root Repair

## Baseline

- Source: v8.3.440 / versionCode 532
- Repair release: v8.3.441 / versionCode 533
- Package: `com.localqbank.library`

## User-visible failure

Long-pressing a main QBank, selecting Delete, and then opening another QBank could leave the deleted QBank visible while the application became unusually heavy.

## Root cause

The previous code already moved the physical deletion off the UI thread and used a tombstone, but the UI catalog was refreshed only after `QBankDb.deleteSource()` completed. `deleteSource()` physically removes questions in repeated SQLite write batches, so a large QBank remained visible for the duration of the cleanup and the same SQLite/database resources were simultaneously needed by foreground navigation.

This was a lifecycle/ownership problem, not merely a missing delete statement.

## Repair

1. Added `QBankDb.requestSourceDeletion(sourceId)`. It performs only a short durable transaction: `deleting=1` and `delete_requested=1`.
2. Main QBank UI and `MainViewModel` now use the request boundary instead of waiting for physical cleanup.
3. The QBank disappears from authoritative catalog queries immediately because all live-source queries already require `deleting=0`.
4. `QBankDeletionRecoveryWorker` owns the physical cleanup and re-queries pending explicit deletions so new requests are not lost while a worker is already active.
5. Worker scheduling uses `APPEND_OR_REPLACE` so a new deletion request is chained safely instead of being discarded by `KEEP`.
6. Physical question cleanup is reduced to 50-row batches with cooperative yielding. The existing low-priority deletion executor is preserved.
7. Removed the legacy-tombstone recovery scan from every interactive `sources()` catalog read; recovery remains an application-start/background responsibility.
8. FTS remains an acceleration layer. No synchronous corpus-wide FTS deletion was reintroduced.
9. Existing import replacement still uses the full synchronous `deleteSource()` path because replacement requires completion before inserting the replacement identity.

## Safety contract

`requestSourceDeletion` does not destroy question/test data. If the process dies after the tombstone, `pendingDeletingSourceIds()` identifies only explicit delete intents and the recovery worker resumes `deleteSource()` safely. Legacy hidden rows remain protected by `delete_requested=0`.

## Regression coverage

Added `deleteRequestHidesImmediatelyBeforePhysicalCleanup` to `QBankDeletionIsolationTest`: it proves the target source becomes invisible immediately, the unrelated source remains visible, the target questions still exist at the hand-off boundary, and the resumable physical cleanup can subsequently finish.

## External design basis

Android recommends keeping long database operations away from the UI thread because blocked work prevents drawing/input and can lead to ANR behavior. WorkManager supports resumable long-running background work. Mature study software such as Anki separates collection/deletion maintenance from the immediate deck-list interaction and provides database maintenance/optimization separately.

## Verification status

- Changed-file delimiter scan: PASS
- Deletion architecture scan: PASS
- No production `Thread.sleep`: PASS
- Shared `QBankDatabaseProvider` preserved: PASS
- Source catalog excludes tombstones: PASS
- Existing physical deletion/FTS architecture preserved: PASS
- Instrumented regression added: PASS at source-definition level
- Gradle compilation: pending CI verification
- Device runtime deletion/heavy-load reproduction: pending device verification
