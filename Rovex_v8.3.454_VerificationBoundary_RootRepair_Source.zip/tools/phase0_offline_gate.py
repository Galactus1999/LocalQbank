#!/usr/bin/env python3
"""Strict offline Phase-0 gate for the current Rovex source baseline."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'app'
MAIN=APP/'src/main/java/com/localqbank/library'
TEST=APP/'src/androidTest/java/com/localqbank/library'
errors=[]; warnings=[]

def fail(msg): errors.append(msg)
def has(path, needle): return needle in path.read_text(encoding='utf-8')

gradle=(APP/'build.gradle.kts').read_text(encoding='utf-8')
if 'applicationId = "com.localqbank.library"' not in gradle: fail('package/applicationId mismatch')
m=re.search(r'versionName\s*=\s*"([^"]+)"',gradle); vc=re.search(r'versionCode\s*=\s*(\d+)',gradle)
if not m: fail('authoritative versionName missing')
if not vc: fail('authoritative versionCode missing')
else:
    version_code=int(vc.group(1))
    if version_code <= 0: fail('authoritative versionCode is not positive')

# Broad Throwable catches are forbidden at application failure boundaries. Cancellation remains explicit.
for p in MAIN.rglob('*.kt'):
    s=p.read_text(encoding='utf-8')
    if re.search(r'catch\s*\([^)]*:\s*Throwable\s*\)',s): fail(f'broad Throwable catch remains: {p.relative_to(ROOT)}')

# Identity/deletion contracts.
db=MAIN/'QBankDb.kt'; ds=db.read_text(encoding='utf-8')
if 'file_name TEXT UNIQUE NOT NULL' not in ds: fail('source.file_name UNIQUE contract unexpectedly changed')
if re.search(r'DROP\s+TABLE\s+source|ALTER\s+TABLE\s+source[^\n]*(DROP|UNIQUE)',ds,re.I): fail('source identity migration appears destructive/invalid')
for needle in [
    'ensureQBankColumn(db, "source", "delete_requested", "INTEGER NOT NULL DEFAULT 0")',
    'WHERE deleting=1 AND delete_requested=1',
    'put("deleting", 1); put("delete_requested", 1)',
    'fun requestSourceDeletion(sourceId: Long): Boolean',
    'UPDATE source SET deleting=1,delete_requested=1 WHERE id=?',
    'check(deleted) { "Previous import is still being removed; retry import after recovery completes" }',
    'return "rvx-legacy-$digest"',
]:
    if needle not in ds: fail(f'missing deletion/import identity contract: {needle}')

# Actual escapeLike path: literal characters must survive the raw-token boundary and
# reach SQL parameters where escapeLike() quotes them. The FTS tokenizer may normalize
# a separate FTS token stream; that is not allowed to erase literal-search syntax.
if 'val hasLikeLiteralSyntax=rawTokens.any' not in ds: fail('search literal-syntax detection missing')
literal_line=next((line for line in ds.splitlines() if 'hasLikeLiteralSyntax=rawTokens.any' in line), '')
if not literal_line or '%' not in literal_line or '_' not in literal_line or r"\\" not in literal_line:
    fail('search literal-syntax detection no longer preserves %, _, or backslash')
if ds.count('ESCAPE CHAR(92)') < 12: fail('insufficient SQLite ESCAPE clauses in authoritative search SQL')
search_test=(TEST/'QBankDbSearchRegressionTest.kt').read_text(encoding='utf-8')
for needle in ['acid%base','acid\\\\base','likeFallbackEscapesPercentThroughActualEscapeLikeSqlPath','likeFallbackEscapesBackslashThroughActualEscapeLikeSqlPath']:
    if needle not in search_test: fail(f'missing literal ESCAPE regression coverage: {needle}')

delete_test=(TEST/'QBankDeletionIsolationTest.kt').read_text(encoding='utf-8')
for needle in ['crashRecoveryOnlyResumesExplicitDeletionAndRestoresLegacyHiddenData','delete_requested=0','delete_requested=1','pendingDeletingSourceIds()']:
    if needle not in delete_test: fail(f'missing deletion recovery regression coverage: {needle}')
identity_test=(TEST/'QBankImportIdentityRegressionTest.kt').read_text(encoding='utf-8')
for needle in ['sameDisplayFilenameDoesNotDeleteOtherImportedQBank','reimportSameIdentityReplacesOnlyThatQBank','index.html']:
    if needle not in identity_test: fail(f'missing import identity regression coverage: {needle}')

# Duplicate XML IDs: only duplicates within one layout are illegal.
ANDROID='http://schemas.android.com/apk/res/android'
for p in (APP/'src/main/res').rglob('*.xml'):
    try: root=ET.parse(p).getroot()
    except ET.ParseError as e: fail(f'XML parse failure {p.relative_to(ROOT)}: {e}'); continue
    ids=[]
    for e in root.iter():
        v=e.attrib.get(f'{{{ANDROID}}}id')
        if v and v.startswith('@+id/'): ids.append(v[5:])
    dup=sorted({x for x in ids if ids.count(x)>1})
    if dup: fail(f'duplicate IDs within layout {p.relative_to(ROOT)}: {dup}')

# Targeted findViewById generic-type audit for IDs whose XML declaration is unambiguous.
xml_types={}
for p in (APP/'src/main/res').rglob('*.xml'):
    try: root=ET.parse(p).getroot()
    except ET.ParseError: continue
    for e in root.iter():
        rid=e.attrib.get(f'{{{ANDROID}}}id')
        if rid and rid.startswith('@+id/'):
            xml_types.setdefault(rid[5:],set()).add(e.tag.split('.')[-1])
subclasses={
 'TextView':{'TextView','Button','EditText','AutoCompleteTextView','CheckedTextView','CheckBox','RadioButton','Switch','ToggleButton','MultiAutoCompleteTextView','AppCompatTextView','MaterialTextView','AppCompatButton','SwitchCompat'},
 'ImageView':{'ImageView','ImageButton'},
 'View':None,
 'LinearLayout':{'LinearLayout'}, 'FrameLayout':{'FrameLayout'}, 'RelativeLayout':{'RelativeLayout'},
 'ScrollView':{'ScrollView'}, 'HorizontalScrollView':{'HorizontalScrollView'},
 'RecyclerView':{'RecyclerView'}, 'WebView':{'WebView'}, 'ProgressBar':{'ProgressBar'},
 'CheckBox':{'CheckBox'}, 'RadioButton':{'RadioButton'}, 'EditText':{'EditText'},
}
for p in MAIN.rglob('*.kt'):
    s=p.read_text(encoding='utf-8')
    for typ,rid in re.findall(r'findViewById\s*<\s*([A-Za-z0-9_$.]+)\s*>\s*\(\s*R\.id\.([A-Za-z0-9_]+)\s*\)',s):
        simple=typ.split('.')[-1]; tags=xml_types.get(rid)
        if not tags or len(tags)!=1 or simple not in subclasses: continue
        tag=next(iter(tags)); allowed=subclasses[simple]
        if allowed is not None and tag not in allowed and tag not in {'android.widget.'+simple}:
            fail(f'findViewById<{simple}> incompatible with XML {tag} for id {rid} in {p.relative_to(ROOT)}')

# CI/source mutation boundary: source archives must not contain source-mutating CI overlays or workflow logic.
for p in (ROOT/'.github').rglob('*') if (ROOT/'.github').exists() else []:
    if p.is_file():
        s=p.read_text(encoding='utf-8',errors='ignore')
        if p.name.endswith('_overlay.py') or re.search(r'phase0_apply_repairs|Persist corrected|git\s+(commit|push).*source|sed\s+-i|perl\s+-i|read_text\(\).*write_text',s,re.I):
            fail(f'CI source mutation detected: {p.relative_to(ROOT)}')

# Required regression tests are present.
required_tests=['QBankDbSearchRegressionTest.kt','QBankDeletionIsolationTest.kt','QBankImportIdentityRegressionTest.kt']
for t in required_tests:
    if not (TEST/t).exists(): fail(f'missing instrumented regression test: {t}')

if errors:
    print('PHASE0_OFFLINE_GATE=FAIL')
    print('\n'.join(' - '+x for x in errors))
    sys.exit(1)
print('PHASE0_OFFLINE_GATE=PASS')
print(' - version/package contract PASS')
print(' - Throwable boundary audit PASS')
print(' - import identity/delete-intent contracts PASS')
print(' - actual SQLite ESCAPE path coverage PASS')
print(' - XML duplicate-ID audit PASS')
print(' - targeted findViewById/XML type audit PASS')
print(' - CI source-mutation boundary PASS')
print(' - mandatory instrumented regression tests present PASS')
