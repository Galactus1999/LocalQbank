# GitHub Patch Audit — v8.3.448

Authoritative GitHub repository: `Galactus1999/LocalQbank`
Default branch: `main`
Audited: 2026-09-28

## Source baseline

GitHub `main` stores `Rovex_v8.3.445_CI_RuntimeRegression_RootRepair_Source.zip` as the repository source archive. The current adaptive discovery workflow explicitly applies `.github/ci/rovex_446_overlay2.py` to that exact archive before Gradle build/test.

## Online patch chain reviewed

The current GitHub history was inspected through the latest commits. The relevant post-v8.3.445 repair chain includes:

- `dd24a9190ca3d27796f6d40af46c7bc2592fd7cd` — add v8.3.446 CI repair overlay
- `01e1332d61d27446f6acc3bb689eabb3c25ad2e4` — apply v8.3.446 overlay to v8.3.445 baseline
- `4e9d34b5ff43db3292147e6bb44246576ad98242` — harden overlay against v8.3.445 baseline
- `e46d1af3d8c4988782e13b147ac438070b02d224` — relax brittle overlay match counts
- `2c3215e99709120b640df236de2fecb03b335177` — fix multi-occurrence token replacement
- `5aacccadd97511beb7de33a432bf851aa34f87f6` / `56c208fc4cf68d08735cd7f327c59ce52b395c20` — remove brittle QBankDb overlay count assertions
- `55683ef94cb599e2f2209527dab812dbd48c499a` / `75de534ef40a67249c9927d0cbbc7e355d2350eb` — simplify the v8.3.446 overlay
- `9f0fa1a7d48c309ac4f7b2c5c8c7b5b352392788` — fix generated LIKE argument token reference
- `d739c1ed670e2fd9c86ed7de6944f40f389257dc` — harden Ben brain instrumentation visibility assertion
- `839acfb174a35e7d95c2ebbbffc3c25f0d7dce0d` — fix punctuation search false positives and legacy recovery tests
- `b0f66e7d0a1c63343d8c478d3ed1b97ec7c5f979` — fix active overlay search/recovery regressions
- `8d4a92e85bb3189f875243c4980d3b9e31a64339` — fix overlay Python escaping
- `4aacaf89266ba60fceb52921c7bb668229f35037` — harden deletion recovery/test isolation
- `d2f0f09c905dfb012b5e26a18b1c647504dcc7d3` — fix overlay Python syntax
- `c6dbe99d354ed9f9da734bd06ee4ebcb3c7db689` — fix overlay2 token-reference compile error
- `3fe7a52cd11cc43c249d363586db520690fdb72f` — fix v8.3.446 instrumentation root causes
- `8ca0229a801d4b9ebd38635340ae42fd392c7863`, `08100f3e4f2d4d849d7593c729fa9999ac661aac`, `1905df785c4a19bafc08098edee88b0bed7f9fdc`, `8418ce25ce45cc357a5c6b4a1bf6843985218b27`, `71922da95ac210b6f3e56abf903a7718cd02d983`, `11a04524eb13838d531beddd9629f045c2347af0` — iterative overlay token ownership/compatibility/duplicate cleanup
- `10ab789bc2ce8003a561d2528bd0e963a1d5fa85` — fix literal LIKE token binding/import identity lookup
- `08e475e65bb2d21e0ed61526fa73697c67681e3a` — bind LIKE clauses to literal search tokens
- `61ee4881f3c5ab62407f1494d0ab70121f575f80` — fix literal punctuation search fallback before FTS
- `34b81ff43377e5b43b4f3731f1a55feed1d81339` — correct literal search fallback scope and ordering

## Merge result

The active GitHub overlay logic has been incorporated directly into the source:

- punctuation-bearing search terms bypass FTS and use normalized SQLite LIKE/ESCAPE first;
- FTS uses `ftsTokens`, while literal SQL uses `likeTokens`;
- `%`, `_`, `\\`, and `-` are preserved as literal query syntax;
- LIKE uses `ESCAPE CHAR(92)`;
- deletion/import tests no longer rely on returned question counts as source IDs;
- legacy recovery resolves source IDs by stable identity rather than assuming numeric ID 1;
- Settings/Ben instrumentation scrolls to the adaptive control before visibility assertion;
- version advanced to versionCode 540 / versionName 8.3.448.

The active patch file is retained at `.github/ci/rovex_446_overlay2.py` for provenance and CI reproducibility.

## Important verification boundary

This audit is source/static only. Android Gradle compilation and instrumented execution were not claimed as PASS because the local environment cannot resolve `downloads.gradle.org` for Gradle 9.3.1. GitHub CI remains the execution gate.
