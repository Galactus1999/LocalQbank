# Rovex Phase-0 Test Compile Repair — v8.3.440

## Evidence-driven repair

CI instrumented Run #396 (logs supplied with this repair batch) progressed through emulator boot and reached
`:app:compileDebugAndroidTestKotlin`. The blocking compiler error was:

`BenInferenceProcessStressTest.kt:36` — `BenAiResourceGovernor.Snapshot` was called with an obsolete
six-argument positional constructor. The current production data class has four parameters:

- `availableMemoryMb: Int`
- `thermalStatus: Int`
- `powerSave: Boolean`
- `foreground: Boolean = true`

The test-only call was replaced with named arguments matching the current production contract. No production
Ben IPC/runtime implementation was changed.

## Version

- versionName: `8.3.440`
- versionCode: `532`

## Required validation

- Re-run the strict offline Phase-0 gate.
- Re-run whole-project static/source/runtime-risk audits.
- Re-run CI against this exact source through Android instrumented compilation.
- Do not claim instrumented PASS until the tests actually execute and pass.
- Keep the no-online-application-source rule: this ZIP remains an offline source artifact unless an approved
source handoff is used for CI.
