# Rovex Phase 0 Offline Root-Repair Audit — v8.3.438

## Authoritative baseline
- Input: `Rovex_v8.3.437_QBank_Visibility_ColdWarm_Repair_Source.zip`
- Baseline SHA-256: `29ebd145975e0be1f27b3fa78458b6a417f6dbd132044b7385c83944c86fc55f`
- Corrected release: v8.3.438 / versionCode 530
- Package: `com.localqbank.library`
- All application-source changes were performed offline from the uploaded ZIP.

## Root repairs

### 1. SQLite LIKE/ESCAPE regression
The prior search regression test exercised `_` but could not exercise `%` or backslash because search-token normalization stripped those characters before `escapeLike()` was reached.

Repair:
- preserve `%` and backslash in the search-token normalization used by both generic and image search;
- retain the existing `escapeLike()` implementation and explicit SQLite `ESCAPE '\\'` SQL clauses;
- add instrumented tests for literal `%` and literal backslash with wildcard distractor rows;
- retain the underscore regression test.

Proof:
- exact Kotlin regex probe: `PASS`;
- direct SQLite `LIKE ... ESCAPE '\\'` semantic probe for `%`, `_`, and backslash: `PASS`;
- static gate verifies the production tokenizer, escape clauses, and tests: `PASS`.

### 2. Broad `Throwable` application failure boundaries
The source contained broad `Throwable` catches in flashcard actions, search, online result boundaries, QBank recovery/maintenance workers, the cancellation helper, and QBank loading submission boundaries.

Repair:
- narrowed application failure boundaries to `Exception`;
- preserved explicit `CancellationException` propagation where coroutine code requires it;
- preserved QBank loading in-flight cleanup semantics.

Proof:
- post-repair whole-production scan finds zero `catch (...: Throwable)` boundaries: `PASS`;
- coroutine cancellation audit: `PASS`.

### 3. Deletion/import recovery regression coverage
Added a durable recovery regression that distinguishes explicit `delete_requested=1` tombstones from legacy hidden rows with `delete_requested=0`, and proves only the explicit deletion resumes destructively.

Existing same-display-filename/different-document identity tests remain in place.

### 4. Verification-process defects
- Updated the stale search-regression verifier to match the current shared `LocalQBankSearchService` architecture rather than reverting the application to the older direct-retrieval topology.
- Refreshed the architecture baseline to the actual v8.3.437 accepted source shape.
- Registered `RovexOnlineSyncCoordinator` in `ManagerContractRegistry` because it was already a bounded coordinator but missing from the registry.
- Added `tools/phase0_offline_gate.py`, which fails closed on version/package, broad Throwable catches, source identity/deletion contracts, actual ESCAPE coverage, duplicate IDs, targeted `findViewById`/XML type mismatches, CI source mutation, and required regression-test presence.

## Static proof
- `phase0_offline_gate.py`: PASS
- `ruthless_audit.sh`: PASS
- `verify_search_qbank_regressions.sh`: PASS
- `verify_search_regression_repair.sh`: PASS
- `verify_performance_search_architecture.sh`: PASS
- `verify_root_architecture.sh`: PASS
- `audit_chat_architecture.sh`: PASS
- `verify_online_architecture.sh`: PASS
- `audit_coroutine_cancellation.py`: PASS
- `audit_architecture.py`: PASS; only pre-existing large-file warnings remain
- `architecture_regression_audit.py`: PASS
- `audit_frankenstein_policy.py`: PASS
- XML duplicate-ID scan: PASS
- targeted `findViewById<T>()` vs unique XML widget-type scan: PASS

## Build/device evidence
Local Android Gradle execution is blocked because Gradle 9.3.1 is not cached and `downloads.gradle.org` is not resolvable in this environment (`curl: (6) Could not resolve host`).

Therefore this offline audit does **not** claim:
- Android compilation PASS;
- JVM test execution PASS;
- instrumented test execution PASS;
- release APK PASS;
- signing/certificate PASS;
- OnePlus/Android 16 device PASS.

Those remain CI/device gates. The corrected source ZIP is the artifact to submit to the CI workflow; CI must consume it without mutating application source.

## Acceptance status
- Offline source repair: **100% complete and statically proven**.
- Phase 0 release/device verification: **not yet 100%** because executable Gradle/device evidence is unavailable in this environment.
