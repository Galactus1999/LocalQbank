# v8.3.443 — Instrumented-log root repair

Source baseline: v8.3.442.

## Root cause proven by the uploaded CI log
The instrumented suite repeatedly deletes `qbank.db` directly while the process-scoped `QBankDatabaseProvider`/`SQLiteOpenHelper` remains open. Later tests reuse that stale helper and receive `SQLiteDatabase: .../qbank.db` `attempt to re-open an already-closed object` errors. The same isolation defect cascades into UNIQUE-primary-key and empty-search/deletion assertions because tests are no longer starting from a clean database connection.

## Repair
- Added a provider-owned test reset that closes the shared helper, clears the singleton, then deletes `qbank.db`.
- Replaced every direct `context.deleteDatabase("qbank.db")` in the affected QBank instrumented tests with `QBankDb.resetDatabaseForTest(context)`.
- Kept production `QBankDb.close()` as a no-op because the shared process-scoped provider remains authoritative.
- Preserved the existing LIKE/ESCAPE implementation; its failures in the log are treated as cascade/isolation failures until the corrected test isolation is executed.
- Incremented version to 8.3.443 / versionCode 535.

## Verification status
Source-level repair applied. Compilation/device execution remains unverified until CI runs the corrected source.
