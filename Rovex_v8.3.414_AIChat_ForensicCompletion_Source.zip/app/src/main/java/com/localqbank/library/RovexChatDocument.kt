package com.localqbank.library

import android.webkit.WebView
import org.json.JSONObject

/**
 * Small, fixed local chat document controller.
 *
 * The WebView owns only a static document shell and never executes AI-authored JavaScript.
 * AI content is inserted as already-sanitized/rendered HTML through a fixed DOM API.
 * Messages can be appended/replaced without rebuilding the entire transcript.
 */
object RovexChatDocument {
    private const val JS = """
        window.RovexChat={
          nearBottom:function(){return (window.innerHeight+window.scrollY)>=Math.max(document.body.scrollHeight-180,0);},
          scrollIfNeeded:function(stick){if(stick)window.scrollTo(0,document.body.scrollHeight);},
          append:function(id,r,h,s){
            if(document.getElementById(id)) return;
            var stick=s ? this.nearBottom() : false;
            var sec=document.createElement('section');
            sec.id=id;
            sec.className='turn chat-turn '+(r==='YOU'?'user':'ai');
            var role=document.createElement('div');
            role.className='role chat-role';
            role.textContent=r;
            var content=document.createElement('div');
            content.className='content chat-content';
            content.innerHTML=h;
            sec.appendChild(role);
            sec.appendChild(content);
            document.body.appendChild(sec);
            this.scrollIfNeeded(stick);
          },
          replace:function(id,h,s){
            var sec=document.getElementById(id);
            if(!sec) return;
            var stick=s ? this.nearBottom() : false;
            var content=sec.querySelector('.chat-content');
            if(!content) return;
            content.innerHTML=h;
            this.scrollIfNeeded(stick);
          },
          remove:function(id){var sec=document.getElementById(id);if(sec)sec.remove();},
          trim:function(maxTurns){
            var turns=document.querySelectorAll('.chat-turn');
            var excess=turns.length-Math.max(1,maxTurns);
            for(var i=0;i<excess;i++){if(turns[i])turns[i].remove();}
          },
          clear:function(){document.body.innerHTML='';},
          scrollBottom:function(){window.scrollTo(0,document.body.scrollHeight);}
        };
    """.trimIndent()

    fun configure(web: WebView) {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = false
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
    }

    fun script(): String = JS

    fun wrapDocument(css: String, body: String): String =
        """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
        <meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; img-src https: data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'\">
        <style>$css</style><script>$JS</script></head><body>$body</body></html>""".trimIndent()

    fun append(web: WebView, id: String, role: String, html: String, scroll: Boolean = true) {
        web.evaluateJavascript(
            "window.RovexChat&&window.RovexChat.append(${JSONObject.quote(id)},${JSONObject.quote(role)},${JSONObject.quote(html)},$scroll);",
            null
        )
    }

    fun replace(web: WebView, id: String, html: String, scroll: Boolean = true) {
        web.evaluateJavascript(
            "window.RovexChat&&window.RovexChat.replace(${JSONObject.quote(id)},${JSONObject.quote(html)},$scroll);",
            null
        )
    }

    fun remove(web: WebView, id: String) {
        web.evaluateJavascript("window.RovexChat&&window.RovexChat.remove(${JSONObject.quote(id)});", null)
    }

    fun trim(web: WebView, maxTurns: Int) {
        web.evaluateJavascript("window.RovexChat&&window.RovexChat.trim(${maxTurns.coerceIn(1,64)});", null)
    }

    fun scrollBottom(web: WebView) {
        web.evaluateJavascript("window.RovexChat&&window.RovexChat.scrollBottom();", null)
    }
}
