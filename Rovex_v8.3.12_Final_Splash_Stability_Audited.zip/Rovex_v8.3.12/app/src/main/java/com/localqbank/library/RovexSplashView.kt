package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Short, self-contained Rovex launch animation.
 *
 * The effect is intentionally drawn on the Canvas instead of using a large bitmap,
 * video, or background thread. This keeps APK size and startup risk low. All work
 * happens on the UI thread for at most ~1.8 seconds and stops when the view detaches.
 */
class RovexSplashView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        const val DURATION_MS = 1850L
    }

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val inkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("serif", Typeface.BOLD_ITALIC)
        isSubpixelText = true
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val inkPath = Path()

    private var startTime = 0L
    private var running = false
    private var completionSent = false
    private var onFinished: (() -> Unit)? = null

    private val inkColors = intArrayOf(
        Color.rgb(53, 210, 188),
        Color.rgb(151, 93, 255),
        Color.rgb(255, 91, 151),
        Color.rgb(255, 181, 72),
        Color.rgb(66, 151, 255)
    )

    fun setOnFinished(listener: () -> Unit) {
        onFinished = listener
    }

    fun start() {
        if (running || completionSent) return
        startTime = SystemClock.uptimeMillis()
        running = true
        invalidate()
    }

    fun skipToEnd() {
        if (completionSent) return
        running = false
        completionSent = true
        onFinished?.invoke()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        running = false
        onFinished = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val maxRadius = kotlin.math.hypot(w.toDouble(), h.toDouble()).toFloat() * 0.58f

        // Deep-water base with a subtle center glow.
        backgroundPaint.shader = RadialGradient(
            cx, cy, maxRadius,
            intArrayOf(Color.rgb(23, 31, 43), Color.rgb(7, 12, 20), Color.BLACK),
            floatArrayOf(0f, 0.48f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, backgroundPaint)
        backgroundPaint.shader = null

        val elapsed = if (running) (SystemClock.uptimeMillis() - startTime).coerceAtLeast(0L) else DURATION_MS
        val t = (elapsed.toFloat() / DURATION_MS).coerceIn(0f, 1f)

        // Dark water rings expand from the Rovex wordmark toward the screen edge.
        for (i in 0 until 7) {
            val phase = ((t * 1.12f + i * 0.135f) % 1.0f)
            val radius = maxRadius * (0.06f + phase * 0.96f)
            val alpha = ((1f - phase) * 92f).toInt().coerceIn(0, 92)
            wavePaint.strokeWidth = (2.5f + (1f - phase) * 7f)
            wavePaint.color = Color.argb(alpha, 1, 7, 14)
            canvas.drawCircle(cx, cy, radius, wavePaint)
        }

        // Ink droplets are carried outward with the expanding wave field.
        for (i in 0 until 18) {
            val baseAngle = i * 2.399963f
            val localPhase = ((t * (0.82f + (i % 4) * 0.06f) + i * 0.037f) % 1.0f)
            val radius = maxRadius * (0.10f + localPhase * 0.82f)
            val wobble = sin((t * 8.0f + i) * 1.7f) * (8f + i % 5 * 3f)
            val x = cx + cos(baseAngle) * radius + cos(baseAngle + 1.4f) * wobble
            val y = cy + sin(baseAngle) * radius + sin(baseAngle + 1.4f) * wobble
            val size = (2.5f + (1f - localPhase) * 10f + (i % 3) * 1.5f).coerceAtMost(15f)
            val alpha = ((1f - localPhase) * 190f).toInt().coerceIn(0, 190)
            inkPaint.color = withAlpha(inkColors[i % inkColors.size], alpha)
            canvas.drawCircle(x, y, size, inkPaint)
            if (size > 6f) {
                inkPaint.color = withAlpha(Color.WHITE, (alpha * 0.14f).toInt())
                canvas.drawCircle(x - size * 0.22f, y - size * 0.22f, size * 0.24f, inkPaint)
            }
        }

        // A small liquid-like halo around the wordmark gives the impression that
        // the ink originates from the centre before the waves carry it outward.
        val haloRadius = min(w, h) * (0.12f + 0.06f * sin(t * Math.PI).toFloat())
        glowPaint.shader = RadialGradient(
            cx, cy, haloRadius,
            Color.argb(105, 255, 202, 96),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, haloRadius, glowPaint)
        glowPaint.shader = null

        drawRovex(canvas, cx, cy, min(w, h), t)

        if (running) {
            if (elapsed >= DURATION_MS) {
                running = false
                if (!completionSent) {
                    completionSent = true
                    post { onFinished?.invoke() }
                }
            } else {
                postInvalidateOnAnimation()
            }
        }
    }

    private fun drawRovex(canvas: Canvas, cx: Float, cy: Float, minDimension: Float, t: Float) {
        val textSize = (minDimension * 0.145f).coerceIn(52f, 112f)
        textPaint.textSize = textSize
        textPaint.shader = LinearGradient(
            cx - textSize * 2.1f, cy - textSize,
            cx + textSize * 2.1f, cy + textSize,
            intArrayOf(Color.rgb(255, 239, 173), Color.rgb(212, 157, 57), Color.rgb(255, 220, 120)),
            floatArrayOf(0f, 0.52f, 1f), Shader.TileMode.CLAMP
        )
        textPaint.setShadowLayer(22f, 0f, 0f, Color.argb(115, 255, 193, 67))
        val scale = (0.90f + 0.10f * (1f - t)).coerceIn(0.9f, 1f)
        canvas.save()
        canvas.scale(scale, scale, cx, cy)
        canvas.drawText("Rovex", cx, cy - (textPaint.ascent() + textPaint.descent()) * 0.5f, textPaint)
        canvas.restore()
        textPaint.clearShadowLayer()
        textPaint.shader = null
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
}
