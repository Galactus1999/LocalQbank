# Rovex v8.3.12 — Final Splash + Stability Audit

## Release changes
- Added a launcher-only RovexSplashActivity.
- Added a Canvas-based ~1.85 s water-wave / flowing-ink animation.
- Centered golden Rovex wordmark uses a built-in serif bold-italic typeface, avoiding font asset dependency.
- Animation uses UI-thread Canvas invalidation only; no background thread, video, WebView, bitmap sequence, or long-running service.
- Animation cancels on view detachment and opens MainActivity exactly once.
- Configuration-change recreation skips the animation instead of trapping the user in it.
- MainActivity remains responsible for the functional app startup; existing manager/database architecture is unchanged.
- Launcher intent targets RovexSplashActivity only; deep-link/file entry points remain direct.
- Version bumped to 8.3.12 / versionCode 110.
- Provenance anchor refreshed for v8.3.12; private signing material remains outside the source tree.

## Stability audit
- Manifest activity/launcher routing checked.
- XML parsing checked.
- Resource-name collision scan checked.
- findViewById generic types cross-checked against XML where applicable.
- No native TextView autosize usage.
- No unsafe SQLite PRAGMA execSQL pattern.
- No new blocking calls, locks, sleeps, or background splash worker.
- Splash callback is lifecycle guarded; detached view clears its callback and stops animation.
- No splash animation starts from MainActivity or other Activities.
- Existing zstd Android AAR, compileSdk 37, targetSdk 36, Gradle 9.3.1 and package ID retained.
- Existing backup/restore, APKG, and provenance architecture retained.

## Verification limitation
Local Gradle APK compilation is not claimed as verified because the environment cannot download the pinned Gradle distribution due network/DNS restrictions. CI compilation/device smoke testing remains the final executable verification step.
