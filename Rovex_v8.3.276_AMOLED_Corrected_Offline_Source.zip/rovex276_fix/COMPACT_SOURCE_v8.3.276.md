Rovex v8.3.276 compact offline source package

The checked-in Qualcomm/LiteRT native runtime binaries under
app/src/main/jniLibs/arm64-v8a/ were intentionally omitted from this compact
source package. The v8.3.276 app/build.gradle.kts + tools/prepare_litert_qualcomm_v75_jit.sh
already treat these proprietary Qualcomm runtime libraries as build-time artifacts:
the packaging task fetches the official LiteRT Qualcomm v75 runtime and stages the
required libraries before native packaging.

No Kotlin/Java/XML/resources/business logic were removed by compaction.
