package com.localqbank.library

import java.util.concurrent.atomic.AtomicLong

/** In-memory IPC counters exported through the single Rovex diagnostics center. */
object BenIpcDiagnostics {
    private val binds = AtomicLong(0)
    private val rebinds = AtomicLong(0)
    private val binderDeaths = AtomicLong(0)
    private val generationTimeouts = AtomicLong(0)
    private val oneShotTimeouts = AtomicLong(0)
    private val cancellations = AtomicLong(0)
    private val terminalEvents = AtomicLong(0)

    fun bound() { binds.incrementAndGet() }
    fun rebound() { rebinds.incrementAndGet() }
    fun binderDied() { binderDeaths.incrementAndGet() }
    fun generationTimeout() { generationTimeouts.incrementAndGet() }
    fun oneShotTimeout() { oneShotTimeouts.incrementAndGet() }
    fun cancellation() { cancellations.incrementAndGet() }
    fun terminal() { terminalEvents.incrementAndGet() }

    fun snapshot(): Map<String, String> = linkedMapOf(
        "Bind events" to binds.get().toString(), "Rebind events" to rebinds.get().toString(),
        "Binder deaths" to binderDeaths.get().toString(), "Generation timeouts" to generationTimeouts.get().toString(),
        "One-shot timeouts" to oneShotTimeouts.get().toString(), "Cancellations" to cancellations.get().toString(),
        "Terminal events" to terminalEvents.get().toString()
    )
}
