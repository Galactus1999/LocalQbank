package com.localqbank.library

import android.content.Context
import android.os.Build
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Single, bounded diagnostic/test-data registry for Rovex.
 * It stores telemetry and test outcomes, never prompts, question text, answers, or study content.
 * Future engines can publish bounded key/value metrics here without creating another diagnostics UI.
 */
object RovexDiagnosticsDataCenter {
    private const val PREFS = "rovex_diagnostics"
    private const val KEY_SECTIONS = "sections"
    private const val KEY_RUNS = "runs"
    private const val KEY_LAST_EMBEDDING = "last_embedding_report"
    private const val MAX_RUNS = 24
    private const val MAX_REPORT_CHARS = 18000

    data class Run(val atMs: Long, val name: String, val passed: Boolean, val durationMs: Long, val details: String)

    fun record(context: Context, section: String, key: String, value: String) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val root = runCatching { JSONObject(prefs.getString(KEY_SECTIONS, "{}") ?: "{}") }.getOrDefault(JSONObject())
        val obj = root.optJSONObject(section) ?: JSONObject().also { root.put(section, it) }
        obj.put(key.take(80), value.take(500))
        prefs.edit().putString(KEY_SECTIONS, root.toString().take(18000)).apply()
    }

    fun recordRun(context: Context, name: String, passed: Boolean, durationMs: Long, details: String = "") {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = runCatching { JSONArray(prefs.getString(KEY_RUNS, "[]") ?: "[]") }.getOrDefault(JSONArray())
        val next = JSONArray()
        val run = JSONObject().apply {
            put("atMs", System.currentTimeMillis()); put("name", name.take(100)); put("passed", passed)
            put("durationMs", durationMs.coerceAtLeast(0L)); put("details", details.take(1600))
        }
        next.put(run)
        for (i in 0 until minOf(old.length(), MAX_RUNS - 1)) next.put(old.optJSONObject(i) ?: JSONObject())
        prefs.edit().putString(KEY_RUNS, next.toString()).apply()
    }

    fun recordEmbeddingReport(context: Context, report: String) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LAST_EMBEDDING, report.take(MAX_REPORT_CHARS)).apply()
        record(context, "EmbeddingGemma", "last_report_at", System.currentTimeMillis().toString())
    }

    fun runs(context: Context): List<Run> {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val a = runCatching { JSONArray(prefs.getString(KEY_RUNS, "[]") ?: "[]") }.getOrDefault(JSONArray())
        return (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { Run(it.optLong("atMs"), it.optString("name"), it.optBoolean("passed"), it.optLong("durationMs"), it.optString("details")) } }
    }

    fun lastEmbeddingReport(context: Context): String = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_EMBEDDING, "") ?: ""

    fun collectCurrent(context: Context): Map<String, Map<String, String>> {
        val app = context.applicationContext
        val out = linkedMapOf<String, Map<String, String>>()
        val version = runCatching { app.packageManager.getPackageInfo(app.packageName, 0) }.getOrNull()
        val governor = BenAiResourceGovernor(app).snapshot(true)
        val health = AppManagers.resilienceHealth.snapshot()
        val adaptive = AppManagers.adaptive.state()
        val telemetry = BenNeuralTelemetry.snapshot()
        val policy = BenAiRuntimePolicy(app)
        val models = app.getSystemService(android.app.ActivityManager::class.java)
        val memory = android.app.ActivityManager.MemoryInfo().also { models?.getMemoryInfo(it) }
        out["Build"] = linkedMapOf(
            "Version" to (version?.versionName ?: "unknown"),
            "Version code" to (if (Build.VERSION.SDK_INT >= 28) version?.longVersionCode?.toString() else "legacy"),
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Device" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "SoC" to if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE,
            "ABI" to Build.SUPPORTED_ABIS.joinToString(", ")
        )
        out["Adaptive"] = linkedMapOf(
            "Health" to "${adaptive.health}%", "Learning" to "${adaptive.learningScore}%", "Confidence" to "${adaptive.confidence}%",
            "Uncertainty" to "${adaptive.uncertainty}%", "Exploration" to "${adaptive.exploration}%", "Autonomy" to if (AppManagers.adaptive.isAutonomyEnabled()) "enabled" else "paused",
            "Safe mode" to adaptive.safeMode.toString(), "Observations" to adaptive.observations.toString(), "Autonomous changes" to adaptive.autonomousChanges.toString()
        )
        out["Resources"] = linkedMapOf(
            "Available RAM MB" to governor.availableMemoryMb.toString(), "Total RAM MB" to (memory.totalMem / 1048576L).toString(),
            "Thermal status" to governor.thermalStatus.toString(), "Power save" to governor.powerSave.toString(), "Foreground" to governor.foreground.toString(),
            "Heap used MB" to ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576L).toString()
        )
        out["Ben safety"] = linkedMapOf(
            "Neural enabled" to policy.enabled.toString(), "Conservative mode" to policy.conservativeMode.toString(),
            "Circuit open" to policy.circuitOpen.toString(), "Consecutive failures" to policy.consecutiveFailures.toString()
        )
        out["Neural telemetry"] = linkedMapOf(
            "Stage" to telemetry.stage.name, "Stage detail" to telemetry.stageDetail, "Active model" to telemetry.activeModel,
            "Last latency ms" to telemetry.lastElapsedMs.toString(), "Semantic ms" to telemetry.lastSemanticMs.toString(),
            "Generation ms" to telemetry.lastGenerationMs.toString(), "Evidence" to telemetry.lastEvidenceCount.toString(),
            "Verified" to telemetry.lastVerified.toString(), "Confidence" to telemetry.lastConfidence.toString(),
            "Total requests" to telemetry.totalRequests.toString(), "Neural requests" to telemetry.neuralRequests.toString(),
            "Fallback requests" to telemetry.fallbackRequests.toString(), "Blocked requests" to telemetry.blockedRequests.toString(),
            "Last error" to (telemetry.lastError ?: "none")
        )
        out["IPC"] = BenIpcDiagnostics.snapshot()
        out["EmbeddingGemma"] = linkedMapOf(
            "Model installed" to ((app as LocalQBankApplication).appContainer.neuralModelManager.installed(BenNeuralModelRegistry.embeddingGemma300m) != null).toString(),
            "Tokenizer installed" to ((app as LocalQBankApplication).appContainer.neuralModelManager.installedEmbeddingGemmaTokenizer() != null).toString(),
            "Last diagnostic" to if (lastEmbeddingReport(app).isBlank()) "not collected" else "available"
        )
        val sectionsJson = runCatching { JSONObject(app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SECTIONS, "{}") ?: "{}") }.getOrDefault(JSONObject())
        sectionsJson.keys().forEach { key ->
            val obj = sectionsJson.optJSONObject(key) ?: return@forEach
            val target = out.getOrPut(key) { linkedMapOf() }.toMutableMap()
            obj.keys().forEach { metric -> target[metric] = obj.optString(metric) }
            out[key] = target
        }
        return out
    }

    fun exportText(context: Context): String = buildString {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(Date())
        appendLine("ROVEX / COMPLETE TEST & DIAGNOSTICS EXPORT")
        appendLine("Generated: $now")
        appendLine("Privacy: no prompts, question text, answers, or study content are collected by this registry.")
        appendLine()
        collectCurrent(context).forEach { (section, values) ->
            appendLine("[$section]")
            values.forEach { (key, value) -> appendLine("$key = $value") }
            appendLine()
        }
        val embedding = lastEmbeddingReport(context)
        if (embedding.isNotBlank()) { appendLine("[LAST EMBEDDINGGEMMA FULL REPORT]"); appendLine(embedding); appendLine() }
        appendLine("[TEST HISTORY]")
        runs(context).forEach { run ->
            appendLine("${Date(run.atMs)} | ${run.name} | ${if (run.passed) "PASS" else "FAIL"} | ${run.durationMs} ms | ${run.details}")
        }
    }.take(60000)

    fun clearHistory(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_RUNS).remove(KEY_LAST_EMBEDDING).apply()
    }
}
