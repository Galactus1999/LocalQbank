# Rovex v8.3.698 — CI Regression Test Repair

## Evidence
The uploaded GitHub Actions log for v8.3.697 compiled the Android source and test source, then failed one of 202 JVM tests: `QBankStreamingImportSessionSourceRegressionTest.largeHtmlImportPreflightsQuestionsBeforeReplacingDatabaseSource`, assertion at line 41. The failing assertion required the old error literal `No valid questions were detected in this large HTML file`, which no longer matched the v8.3.299-first dual-parser preflight introduced in v8.3.697. The next assertion also expected a diagnostic literal that the new path did not emit.

## Changes
- Updated the regression test to assert the current dual-parser failure contract and preservation of the existing QBank.
- Added the adaptive scanner's `diagnosticsSummary` to the terminal preflight error, so real zero-question failures carry useful evidence.
- Kept the original v8.3.299 scanner as the first parser, the adaptive scanner as fallback, and all existing staged/transactional import protections.
- Bumped versionName to 8.3.698 and versionCode to 784.

## Verification boundary
The uploaded CI log establishes the exact previous failure. Source-level patch checks and archive integrity can be run locally; this report does not claim a new Gradle test run or a green CI result unless a subsequent run actually passes.
