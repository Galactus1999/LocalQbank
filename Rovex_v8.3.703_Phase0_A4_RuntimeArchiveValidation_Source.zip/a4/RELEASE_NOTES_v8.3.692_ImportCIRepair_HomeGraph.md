# Rovex v8.3.692 — Import CI Repair + Home Graph Redesign

- Version: `8.3.692`
- versionCode: `778`
- Application ID: `com.localqbank.library`
- Source baseline: v8.3.690 / versionCode 776 (the current working source archive)

## Root causes confirmed in source

1. **Compatibility regression in small/medium HTML imports.** The Activity accepted native heuristic extraction as complete whenever it found more than four questions. That count threshold did not establish that all provider-specific questions/sections had been extracted. The existing JavaScript/DOM extractor was only used for a narrow suspicious-partial case.
2. **Asynchronous import-coordinator race.** The WebView fallback scheduled `loadDataWithBaseURL()` and returned from the active coordinator job. The coordinator then invoked `onSuccess` and called `processNext()` while the same file was still awaiting WebView extraction. The bridge also tried to enqueue a second job, making correctness depend on callback timing and the coordinator's running gate.
3. **Unknown Storage Access Framework file sizes.** `fileSize()` relied on `ParcelFileDescriptor.statSize` and returned zero when the provider did not expose a size. The caller treated that as a small file, potentially reading a large cloud/document-provider stream into memory.
4. **Marrow section validation counted every `srcdoc` iframe.** Metadata/help iframes were treated as expected question sections, causing otherwise valid imports to fall through to the generic large-file scanner.
5. **Large-file scanner format coverage was narrow.** The scanner's explicit alias lists did not cover several common quiz/exam/export array names.

## Repairs

- Use the existing WebView/JavaScript compatibility extractor for small/medium HTML files instead of trusting a question-count heuristic to prove native-parser completeness.
- Add `DeferredImportGate<T>`: the current import worker waits for the WebView result with a bounded timeout and commits the parsed bundle itself. The bridge no longer enqueues a nested import. This removes the double-scheduling race and keeps the coordinator's single-job ownership intact.
- Query `OpenableColumns.SIZE` when `statSize` is unavailable. Represent unknown size as `-1`, stream unknown-size inputs to a capped temporary file, then select the path using the actual byte count. The temporary file is removed on both success and failure.
- Enforce `ImportSecurityPolicy.MAX_HTML_BYTES` while staging, even if a provider reports an incorrect/unknown size.
- Search the full large-file stream for `srcdoc` markers before selecting the Marrow streaming path; count only question-bearing embedded documents in the section-consistency check.
- Expand large scanner aliases for common quiz, exam, paper, assessment, question-bank, and export arrays; support direct question records inside generic `data`/`payload` arrays.
- Add request-ID fencing so delayed extraction results cannot satisfy a later import; the request token is embedded in the loaded document and checked before accepting the result.
- Remove the JavaScript-to-native `addJavascriptInterface` bridge from this import path. The app-owned extractor publishes a result object, which the Activity reads through `evaluateJavascript`; this follows Android's warning about exposing native bridges to untrusted imported HTML.
- Add tests for one-shot deferred callback completion/failure/timeout, common quiz aliases, nested object-root question arrays, known-native-payload classification, and source-level guards against nested import enqueue and unknown-size misrouting.

## Scope and invariants

- Database persistence still uses the existing `HtmlImportRepository` / `QBankDb` import APIs.
- Large recognized HTML payloads retain the streaming preflight → transactional write → count-match → commit flow.
- A zero-question or failed parse must not replace the existing QBank.
- Original selected-document URI remains the import identity and media base; temporary staging URIs are not used as QBank identities.
- No parallel import coordinator or database writer was introduced.

## Verification status

- Source changes and tests: implemented; static review pending final audit.
- Pure Kotlin `DeferredImportGate` compilation/harness: pending.
- XML parse and per-layout duplicate-ID audit: pending.
- Gradle/JVM tests, Android compilation, instrumented tests, CI, device import fixtures, and performance measurements: not yet verified for this exact source.
- The v8.3.299 repository ZIP was confirmed to exist by repository listing, but its binary contents could not be downloaded into the current runtime for a direct source-to-source diff. The regression findings above are based on direct inspection of the current source, not an unverified claim about the exact v8.3.299 implementation.

## Remaining safety boundary

- For a large export that the streaming scanner cannot recognize, the compatibility fallback is bounded to 64 MiB. Above that limit, import fails safely and leaves the existing QBank unchanged rather than allocating a full WebView/JSON copy of a very large document. This is a deliberate memory-safety limit, not a claim that every arbitrary HTML format above 64 MiB is supported.
- Import-format completeness, exact source comparison with v8.3.299, and runtime behavior remain unverified until real v8.3.299 fixtures and representative provider exports are exercised through the exact v8.3.691 build on Android.


## Follow-up from CI run 18 Oct 2026

The attached CI log compiled production Kotlin but failed two JVM tests. This release fixes the causes rather than weakening the checks:

1. `quizData`/`quiz_data` aliases were present in both the preferred test-array tier and the root-question tier. The root tier overwrote section-aware parsing and emitted `Imported Section` instead of the export title (`Cardiology`). The aliases now remain in the preferred tier, preserving section titles.
2. The preflight source-contract test searched for the obsolete exact expression `val validatedCount = preflightScanner.scan()`, although production correctly wraps `scan()` in `try/catch` for safe compatibility fallback. The assertion now locates the `preflightScanner.scan()` call and still verifies preflight ordering before `beginStreamingImport`; production behavior was not weakened.
3. The Home `TodayProgressGraphView` height increases from 76dp to 136dp. The chart now uses a smoother curved series, a cached subtle area fill, readable percentage grid/labels, visible time endpoints, and highlighted answer markers. It continues to plot only persisted answers and does not invent samples.

The new source has not yet passed CI: this environment cannot resolve `downloads.gradle.org`, so the updated test suite could not be rerun locally.
