package com.localqbank.library

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import java.util.Collections
import java.util.WeakHashMap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.Drawable
import android.os.SystemClock
import kotlin.math.cos
import kotlin.math.sin

/**
 * Low-cost ambient motion: slow, non-geometric light ribbons and sparse drifting particles.
 * This is a background accent, not a foreground animation or a blur simulation.
 */
internal class RovexAmbientMotionDrawable(
    context: Context,
    private val colorA: Int,
    private val colorB: Int
) : Drawable() {
    private val density = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val startedAt = SystemClock.uptimeMillis()
    private var frameScheduled = false
    private var drawableAlpha = 255
    private val frame = Runnable {
        frameScheduled = false
        if (appForeground && isVisible) invalidateSelf()
    }
    @Volatile private var appForeground = false
    private var hostVisible = true

    init { RovexAmbientMotionLifecycle.register(context, this) }

    internal fun setAppForeground(active: Boolean) {
        appForeground = active
        super.setVisible(hostVisible && active, false)
        if (!active) {
            if (frameScheduled) unscheduleSelf(frame)
            frameScheduled = false
        } else if (hostVisible) invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 1f || h <= 1f || !isVisible || !appForeground) return
        val phase = ((SystemClock.uptimeMillis() - startedAt) % 28000L) / 28000f * (Math.PI * 2.0)
        val accent = mix(colorA, colorB, ((sin(phase) + 1.0) * .5).toFloat())
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        for (i in 0..2) {
            val drift = sin(phase + i * 1.7).toFloat()
            val y = h * (.30f + i * .19f) + drift * h * .055f
            path.reset()
            path.moveTo(-w * .12f, y + h * .13f)
            path.cubicTo(
                w * (.18f + .07f * cos(phase + i).toFloat()), y - h * .22f,
                w * (.56f + .08f * sin(phase * .72 + i).toFloat()), y + h * .24f,
                w * 1.12f, y - h * .10f
            )
            // Layered translucent strokes give the ribbon depth without per-frame shader allocation.
            paint.shader = null
            paint.color = accent
            paint.strokeWidth = h * if (i == 1) .032f else .021f
            paint.alpha = ((if (i == 1) 34 else 22) * drawableAlpha / 255)
            canvas.drawPath(path, paint)
            paint.strokeWidth = h * if (i == 1) .013f else .009f
            paint.alpha = ((if (i == 1) 82 else 48) * drawableAlpha / 255)
            canvas.drawPath(path, paint)
            paint.strokeWidth = (1.15f * density).coerceAtLeast(1f)
            paint.alpha = ((if (i == 1) 142 else 92) * drawableAlpha / 255)
            canvas.drawPath(path, paint)
        }
        paint.shader = null
        paint.style = Paint.Style.FILL
        for (i in 0 until 14) {
            val seed = i * 2.3999632
            val x = (((i * 37) % 101) / 100f) * w + sin(phase * .55 + seed).toFloat() * w * .025f
            val y = (((i * 61 + 13) % 97) / 96f) * h + cos(phase * .42 + seed).toFloat() * h * .018f
            val pulse = ((sin(phase * .8 + seed) + 1.0) * .5).toFloat()
            paint.color = Color.argb(((18 + pulse * 34) * drawableAlpha / 255).toInt(), 235, 244, 255)
            canvas.drawCircle(x, y, (0.7f + pulse * 1.4f) * density, paint)
        }
        paint.style = Paint.Style.STROKE
        paint.alpha = drawableAlpha
        canvas.restore()
        if (!frameScheduled) {
            frameScheduled = true
            scheduleSelf(frame, SystemClock.uptimeMillis() + 125L) // approximately 8 fps; cap full-screen redraw cost
        }
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        hostVisible = visible
        val effective = visible && appForeground
        val changed = super.setVisible(effective, restart)
        if (!effective && frameScheduled) {
            unscheduleSelf(frame)
            frameScheduled = false
        } else if (effective) invalidateSelf()
        return changed
    }

    override fun setAlpha(alpha: Int) { drawableAlpha = alpha.coerceIn(0, 255); invalidateSelf() }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        paint.colorFilter = colorFilter
        invalidateSelf()
    }
    @Deprecated("Deprecated by Android")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT

    private fun mix(a: Int, b: Int, amount: Float): Int {
        val f = amount.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
        )
    }
}