package com.localqbank.library

import java.net.URI
import java.io.File

/** Narrow allow-list for image preview requests originating from imported flashcard HTML. */
internal object FlashcardImageUriPolicy {
    private const val MAX_DATA_IMAGE_CHARS = 8 * 1024 * 1024

    fun validatePreviewSource(raw: String?, mediaDirectory: File): String? {
        if (raw.isNullOrBlank() || raw.length > MAX_DATA_IMAGE_CHARS) return null
        val candidate = raw.trim()
        val uri = runCatching { URI(candidate) }.getOrNull() ?: return null
        return when (uri.scheme?.lowercase()) {
            "https" -> candidate.takeIf { uri.host?.isNotBlank() == true && uri.userInfo == null }
            // Keep legacy HTTP-hosted deck images functional, but the preview WebView blocks mixed content.
            "http" -> candidate.takeIf { uri.host?.isNotBlank() == true && uri.userInfo == null }
            "data" -> candidate.takeIf {
                uri.rawSchemeSpecificPart?.startsWith("image/", ignoreCase = true) == true &&
                    candidate.startsWith("data:image/", ignoreCase = true)
            }
            "file" -> {
                val targetFile = runCatching { File(uri) }.getOrNull() ?: return null
                val target = runCatching { targetFile.canonicalFile.toPath() }.getOrNull() ?: return null
                val root = runCatching { mediaDirectory.canonicalFile.toPath() }.getOrNull() ?: return null
                candidate.takeIf { target != root && target.startsWith(root) && target.toFile().isFile }
            }
            else -> null
        }
    }
}
