package com.localqbank.library

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import java.util.Collections
import java.util.WeakHashMap

/** Stops ambient redraws whenever the app has no resumed Activity. */
internal object RovexAmbientMotionLifecycle : Application.ActivityLifecycleCallbacks {
    private val resumed = Collections.newSetFromMap(WeakHashMap<Activity, Boolean>())
    private val drawables = Collections.newSetFromMap(WeakHashMap<RovexAmbientMotionDrawable, Boolean>())
    @Volatile private var foreground = false
    private var registered = false

    @Synchronized fun register(context: Context, drawable: RovexAmbientMotionDrawable) {
        drawables.add(drawable)
        val app = context.applicationContext as? Application ?: return
        if (!registered) {
            app.registerActivityLifecycleCallbacks(this)
            registered = true
        }
        drawable.setAppForeground(foreground)
    }

    @Synchronized private fun updateForeground(active: Boolean) {
        foreground = active
        drawables.toList().forEach { it.setAppForeground(active) }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {}
    @Synchronized override fun onActivityResumed(activity: Activity) {
        resumed.add(activity)
        updateForeground(true)
    }
    @Synchronized override fun onActivityPaused(activity: Activity) {
        resumed.remove(activity)
        updateForeground(resumed.isNotEmpty())
    }
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivityDestroyed(activity: Activity) {}
}
