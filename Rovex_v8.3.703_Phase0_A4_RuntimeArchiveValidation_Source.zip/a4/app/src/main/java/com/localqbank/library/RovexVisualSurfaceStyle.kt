package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.RadialGradient
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View

/** Premium surface primitives. Uses bounded translucency/highlights; no device-wide blur dependency. */
object RovexVisualSurfaceStyle {
    fun glass(context: Context, radiusDp: Float, prominent: Boolean = false): Drawable {
        val d = context.resources.displayMetrics.density
        val r = radiusDp.coerceIn(8f, 28f) * d
        val dark = ThemeManager.isDark(context)
        if (!RovexSurfaceSettings.isGlassEnabled(context)) {
            val solid = if (dark) ThemeManager.elevated(context) else Color.rgb(250, 252, 255)
            val stroke = if (dark) Color.argb(72, 210, 226, 245) else Color.argb(105, 54, 91, 160)
            return GradientDrawable().apply {
                cornerRadius = r
                setColor(solid)
                setStroke(d.toInt().coerceAtLeast(1), stroke)
            }
        }
        val palette = if (prominent) RovexVisualColors.elevated(context) else RovexVisualColors.surface(context)
        val alpha = if (dark) { if (prominent) 190 else 172 } else { if (prominent) 174 else 150 }
        val fillColor = Color.argb(alpha, Color.red(palette), Color.green(palette), Color.blue(palette))
        val accent = ThemeManager.accent(context)
        val tint = Color.argb(if (prominent) 18 else 10, Color.red(accent), Color.green(accent), Color.blue(accent))
        val fill = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            fillColor, fillColor,
            Color.argb((alpha * .92f).toInt(), Color.red(palette), Color.green(palette), Color.blue(palette))
        )).apply { cornerRadius = r }
        val tintLayer = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(tint, Color.TRANSPARENT)).apply { cornerRadius = r }
        val sheen = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
            Color.argb(if (dark) 28 else 34, 255, 255, 255), Color.TRANSPARENT,
            Color.argb(if (dark) 18 else 10, 0, 0, 0)
        )).apply { cornerRadius = r }
        val border = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = r
            setStroke(d.toInt().coerceAtLeast(1), Color.argb(if (dark) 76 else 88, 255, 255, 255))
        }
        return LayerDrawable(arrayOf(fill, tintLayer, sheen, border, RovexGlassOpticsDrawable(accent, dark, ThemeManager.get(context), r)))
    }
    fun apply(view:View,context:Context,radiusDp:Float,prominent:Boolean=false,touch:Boolean=true){
        view.background=glass(context,radiusDp,prominent)
        if(touch&&(view.isClickable||view.hasOnClickListeners())) RovexTouchFeedback.bind(view)
    }
}

/**
 * Static theme-coloured glass caustics. Only selected corner arcs and short rim segments glow;
 * no animator, invalidation loop, blur mask, or per-frame allocation is used.
 */

/**
 * Static optical highlight for a glass surface. A broad, off-centre radial reflection and a
 * restrained top-edge glint replace the old repeated neon arcs. This is an overlay highlight,
 * not backdrop refraction; it allocates no bitmap and runs no animation.
 */
private class RovexGlassOpticsDrawable(
    private val accent: Int,
    private val darkTheme: Boolean,
    private val themeName: String,
    private val radiusPx: Float
) : Drawable() {
    private val reflection = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val highlight = RectF()
    private var reflectionShader: RadialGradient? = null
    private var drawableAlpha = 255
    private var cornerRadius = 4f

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        super.onBoundsChange(bounds)
        val inset = 1.25f
        rect.set(bounds.left + inset, bounds.top + inset, bounds.right - inset, bounds.bottom - inset)
        if (rect.width() < 4f || rect.height() < 4f) {
            reflectionShader = null
            return
        }
        cornerRadius = radiusPx.coerceAtMost(minOf(rect.width(), rect.height()) / 2f).coerceAtLeast(4f)
        highlight.set(
            rect.left - rect.width() * .12f,
            rect.top - rect.height() * .42f,
            rect.left + rect.width() * .84f,
            rect.top + rect.height() * .72f
        )
        val centerAlpha = when (themeName) { ThemeManager.AMOLED -> 18; ThemeManager.SPACE -> 27; ThemeManager.PANDORA -> 25; else -> if (darkTheme) 24 else 30 }
        val accentAlpha = when (themeName) { ThemeManager.AMOLED -> 5; ThemeManager.SPACE -> 14; ThemeManager.PANDORA -> 12; else -> if (darkTheme) 11 else 13 }
        reflectionShader = RadialGradient(
            highlight.centerX(), highlight.centerY(),
            maxOf(highlight.width(), highlight.height()) * .58f,
            intArrayOf(
                Color.argb(centerAlpha, 255, 255, 255),
                Color.argb(accentAlpha, Color.red(accent), Color.green(accent), Color.blue(accent)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, .42f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() < 4 || b.height() < 4) return
        if (b.width() < 4 || b.height() < 4 || rect.width() < 4f || rect.height() < 4f) return
        val save = canvas.save()
        canvas.clipRect(b)
        reflection.shader = reflectionShader
        reflection.alpha = drawableAlpha
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, reflection)
        reflection.shader = null

        // A short, low-contrast top glint; no long corner arcs or decorative bottom streaks.
        edge.color = Color.WHITE
        edge.strokeWidth = .9f
        edge.alpha = (if (darkTheme) 78 else 86) * drawableAlpha / 255
        val y = rect.top + .8f
        canvas.drawLine(rect.left + radiusPx * .72f, y, rect.right - radiusPx * 1.05f, y, edge)
        edge.color = accent
        edge.strokeWidth = 1.1f
        edge.alpha = (when (themeName) { ThemeManager.AMOLED -> 24; ThemeManager.SPACE -> 58; ThemeManager.PANDORA -> 52; else -> if (darkTheme) 48 else 38 }) * drawableAlpha / 255
        canvas.drawLine(rect.left + radiusPx * 1.1f, rect.bottom - .8f,
            rect.left + radiusPx * 1.75f, rect.bottom - .8f, edge)
        canvas.restoreToCount(save)
    }

    override fun setAlpha(alpha: Int) { drawableAlpha = alpha.coerceIn(0, 255); invalidateSelf() }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        reflection.colorFilter = colorFilter
        edge.colorFilter = colorFilter
        invalidateSelf()
    }
    @Deprecated("Deprecated by Android")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}
