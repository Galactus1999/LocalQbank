# Phase 0 A2 — Study-event / XP integrity (v8.3.701)

## Source-level root causes confirmed

1. `firestore.rules` allowed a signed-in user to write `xp`, `questionsSolved`, `correct`, `accuracyPercent`, `todaySolved`, `flashcardsReviewed`, streak values and client projection markers on their own `users/{uid}` document. The client could therefore inflate leaderboard values without using the Cloud Function.
2. `RovexOnlineRepository.submitStudyEvent()` included a client-controlled `correct` boolean, and `functions/index.js` used it to increment `correct` and award +15 XP.
3. Every event used a random UUID and the trigger had no daily quota. The transaction protected a single event document against trigger retries, but did not limit many distinct forged event documents.
4. `RovexOnlineActivity.loadOwnProgress()` wrote a local projection back into the same online profile document, overwriting the server's aggregate fields.

## Implemented in this source snapshot

- Client `users/{uid}` create/update rules now restrict writes to identity fields (`uid`, `displayName`, `rovexId`, `updatedAt`). Aggregate counters and XP are Admin-SDK/server-owned. Client profile deletion is denied.
- Removed the client `syncPersonalProgress()` write API and its call site. The online screen still renders the computed local projection locally; it no longer sends that projection to Firestore.
- Cloud Function validates UID, event type, source/type pairing, optional stable-key hash format and client timestamp.
- Cloud Function ignores client-supplied correctness for scoring, adds only fixed event XP, and marks accepted events `correctnessVerified: false`. Correct answers are not yet verifiable because this architecture does not submit trusted answer evidence to a server-side question bank.
- Added server-UTC-day per-user quotas: 300 quiz events and 1,000 flashcard events per day. Quota increment, profile aggregate increment, and event `processedAt` are atomic in the same transaction; duplicate trigger delivery remains idempotent.
- Strengthened study-event Firestore create validation and added emulator regression cases for profile-field spoofing, immutable events, and event shape.
- Bumped Android version to 8.3.701 / versionCode 787.

## Verification performed

- `node --check functions/index.js`: PASS.
- `node --check firestore-tests/firestore.rules.test.js`: PASS.
- `node firestore-tests/static-security-contract.test.js`: PASS.
- ZIP integrity: must be checked after packaging.

## Not verified / deployment requirements

- Firestore Emulator tests require the pinned npm dependencies and a running emulator; prior npm install timed out. Do not claim emulator tests passed unless they actually execute.
- Android Gradle build, GitHub Actions, Firebase deploy, and device runtime were not executed in this environment.
- Existing online aggregate values were previously client-writable, so their historical integrity cannot be assumed. A production rollout should reset/rebuild legacy competitive aggregates or clearly mark them unverified before treating the leaderboard as trustworthy.
- Correct-count/accuracy aggregation is intentionally not increased from client claims. Implement a trusted answer-verification design against server-held question evidence before re-enabling verified correctness XP/counts.
- Rate ceilings bound abuse but do not prove that every event represents genuine study. A motivated user can still submit fake events up to the ceiling; these events should be considered bounded self-reported activity, not cryptographically proven answers.
