const fs = require('node:fs');
const path = require('node:path');
const { initializeTestEnvironment, assertSucceeds, assertFails } = require('@firebase/rules-unit-testing');
const { doc, setDoc, updateDoc, deleteDoc, getDoc, serverTimestamp } = require('firebase/firestore');
const { after, before, beforeEach, describe, it } = require('mocha');

const PROJECT_ID = 'rovex-rules-regression';
let env;
const code = 'RVX-AB12-CD34';

before(async () => {
  const rules = fs.readFileSync(path.join(__dirname, '..', 'firestore.rules'), 'utf8');
  env = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules },
  });
});
after(async () => { if (env) await env.cleanup(); });
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async context => {
    await setDoc(doc(context.firestore(), 'friendCodes', code), { uid: 'owner-a', displayName: 'Owner A' });
  });
});

describe('friendCodes ownership contract', () => {
  it('denies unauthenticated create', async () => {
    const db = env.unauthenticatedContext().firestore();
    await assertFails(setDoc(doc(db, 'friendCodes', 'RVX-1111-2222'), { uid: 'user-a', displayName: 'A' }));
  });
  it('allows a user to create an unused valid code for themselves', async () => {
    const db = env.authenticatedContext('user-b').firestore();
    await assertSucceeds(setDoc(doc(db, 'friendCodes', 'RVX-1111-2222'), { uid: 'user-b', displayName: 'User B' }));
  });
  it('denies cross-user overwrite of an existing code', async () => {
    const db = env.authenticatedContext('attacker').firestore();
    await assertFails(setDoc(doc(db, 'friendCodes', code), { uid: 'attacker', displayName: 'Attacker' }));
  });
  it('allows the owner to refresh display name without changing uid', async () => {
    const db = env.authenticatedContext('owner-a').firestore();
    await assertSucceeds(updateDoc(doc(db, 'friendCodes', code), { displayName: 'Owner A Updated' }));
  });
  it('denies an owner changing the uid binding', async () => {
    const db = env.authenticatedContext('owner-a').firestore();
    await assertFails(updateDoc(doc(db, 'friendCodes', code), { uid: 'owner-b' }));
  });
  it('denies malformed code and unexpected fields', async () => {
    const db = env.authenticatedContext('owner-b').firestore();
    await assertFails(setDoc(doc(db, 'friendCodes', 'not-a-code'), { uid: 'owner-b', displayName: 'B' }));
    await assertFails(setDoc(doc(db, 'friendCodes', 'RVX-1111-2222'), { uid: 'owner-b', displayName: 'B', admin: true }));
  });
  it('denies a non-owner deleting a code', async () => {
    const db = env.authenticatedContext('attacker').firestore();
    await assertFails(deleteDoc(doc(db, 'friendCodes', code)));
  });
  it('keeps code lookup private to clients', async () => {
    const db = env.authenticatedContext('owner-a').firestore();
    await assertFails(getDoc(doc(db, 'friendCodes', code)));
  });
});


describe('server-owned progress contract', () => {
  it('allows identity-only profile creation', async () => {
    const db = env.authenticatedContext('user-c').firestore();
    await assertSucceeds(setDoc(doc(db, 'users', 'user-c'), {
      uid: 'user-c', displayName: 'User C', rovexId: 'RVX-1111-2222', updatedAt: serverTimestamp()
    }));
  });
  it('denies client-supplied XP or aggregate counters on profile creation', async () => {
    const db = env.authenticatedContext('user-d').firestore();
    await assertFails(setDoc(doc(db, 'users', 'user-d'), {
      uid: 'user-d', displayName: 'User D', rovexId: 'RVX-3333-4444', xp: 999999,
      questionsSolved: 999999, correct: 999999, updatedAt: serverTimestamp()
    }));
  });
  it('denies clients overwriting server-owned XP after profile creation', async () => {
    await env.withSecurityRulesDisabled(async context => {
      await setDoc(doc(context.firestore(), 'users', 'user-e'), {
        uid: 'user-e', displayName: 'User E', rovexId: 'RVX-5555-6666', xp: 10,
        questionsSolved: 1, correct: 0, accuracyPercent: 0, todaySolved: 1,
        flashcardsReviewed: 0, updatedAt: new Date()
      });
    });
    const db = env.authenticatedContext('user-e').firestore();
    await assertFails(updateDoc(doc(db, 'users', 'user-e'), { xp: 999999 }));
    await assertSucceeds(updateDoc(doc(db, 'users', 'user-e'), { displayName: 'Updated E' }));
  });
  it('accepts a well-formed study event but denies event mutation/deletion', async () => {
    const db = env.authenticatedContext('user-f').firestore();
    const eventRef = doc(db, 'studyEvents', 'user-f', 'events', 'event-1');
    await assertSucceeds(setDoc(eventRef, {
      uid: 'user-f', type: 'quiz_completed', source: 'quiz', clientTimestamp: Date.now(),
      createdAt: serverTimestamp(), correct: true
    }));
    await assertFails(updateDoc(eventRef, { correct: false }));
    await assertFails(deleteDoc(eventRef));
  });
  it('rejects mismatched event type/source and malformed stable-key hash', async () => {
    const db = env.authenticatedContext('user-g').firestore();
    await assertFails(setDoc(doc(db, 'studyEvents', 'user-g', 'events', 'bad-1'), {
      uid: 'user-g', type: 'quiz_completed', source: 'flashcards', clientTimestamp: Date.now(), createdAt: serverTimestamp()
    }));
    await assertFails(setDoc(doc(db, 'studyEvents', 'user-g', 'events', 'bad-2'), {
      uid: 'user-g', type: 'quiz_completed', source: 'quiz', clientTimestamp: Date.now(), createdAt: serverTimestamp(), stableKeyHash: 'not-a-hash'
    }));
  });
});
