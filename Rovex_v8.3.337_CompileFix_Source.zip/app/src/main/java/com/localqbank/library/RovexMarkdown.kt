package com.localqbank.library

import android.text.Html
import android.text.Spanned

/** Dependency-free presentation helpers. WebView is used only for rich, local chat layout. */
fun rovexMarkdownToSpanned(raw: String): Spanned {
    // IMPORTANT: Html.fromHtml() backs a plain TextView, not a browser engine. Android's
    // legacy parser has no real notion of <head>/<style> — it has no handler for <style>
    // the way it does for <script>, so a full document wrapper gets its raw CSS text
    // dumped straight into the visible Spanned output. Only ever hand it the body
    // fragment. The full document (rovexMarkdownToHtml) is for WebView consumers only.
    return Html.fromHtml(rovexMarkdownBody(raw), Html.FROM_HTML_MODE_LEGACY)
}

/** Full standalone HTML document — for WebView.loadDataWithBaseURL() only. Never pass this to Html.fromHtml(). */
fun rovexMarkdownToHtml(raw: String): String = wrapMarkdownDocument(rovexMarkdownBody(raw))

/** The rendered body fragment (a `<p>…</p>` tree), with no doctype/html/head/style wrapper. Safe for both Html.fromHtml() and WebView body injection. */
fun rovexMarkdownBody(raw: String): String {
    var s = raw.replace("\r\n", "\n").replace("\r", "\n")
        .replace(Regex("(?i)&lt;\\s*br\\s*/?\\s*&gt;"), "\n")
        .replace(Regex("(?i)<\\s*br\\s*/?\\s*>"), "\n")
        .replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        .replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
        .replace(Regex("(?is)<iframe[^>]*>.*?</iframe>"), "")
        .replace(Regex("(?is)<object[^>]*>.*?</object>"), "")
        .replace(Regex("(?is)<embed[^>]*>.*?</embed>"), "")
        .replace(Regex("(?i)on[a-z]+\\s*=\\s*(['\"]).*?\\1"), "")

    // Preserve explicit AI rich-content blocks. Ordinary prose/search output is never
    // promoted into a table/chart merely because the renderer supports those formats.
    val codeTokens = ArrayList<String>()
    val richTokens = ArrayList<String>()
    s = s.replace(Regex("(?s)```\\s*(mermaid|chart|tree|slides|presentation)\\s*\\n(.*?)```", RegexOption.IGNORE_CASE)) { m ->
        val token = "@@ROVEX_RICH_${richTokens.size}@@"
        richTokens += renderExplicitRichBlock(m.groupValues[1].lowercase(), m.groupValues[2])
        token
    }
    s = s.replace(Regex("(?s)```(?:[a-zA-Z0-9_+.-]+)?\\n(.*?)```")) { m ->
        val token = "@@ROVEX_CODE_${codeTokens.size}@@"
        codeTokens += "<pre>${android.text.TextUtils.htmlEncode(m.groupValues[1])}</pre>"
        token
    }

    val imageTokens = ArrayList<String>()
    s = s.replace(Regex("!\\[([^\\]]{0,240})\\]\\((https://[^\\s)]+|data:image/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=]+)\\)")) { m ->
        val token = "@@ROVEX_IMAGE_${imageTokens.size}@@"
        val alt = android.text.TextUtils.htmlEncode(m.groupValues[1]).replace("\"", "")
        val src = m.groupValues[2].replace("\"", "&quot;")
        imageTokens += "<img src=\"$src\" alt=\"$alt\">"
        token
    }

    val tableTokens = ArrayList<String>()
    // AI providers sometimes collapse Markdown line breaks around a table. Repair only
    // boundaries that are structurally unambiguous: a Markdown separator row must contain
    // at least two pipe-delimited cells, each made of 3+ dashes with optional alignment colons.
    // This keeps ordinary prose/search results from being promoted into tables.
    fun repairCollapsedMarkdownTables(input: String): String {
        val lines = input.split('\n').toMutableList()
        val separator = Regex("\\|+\\s*:?-{3,}:?\\s*(?:\\|\\s*:?-{3,}:?){1,}\\|")
        fun cells(raw: String): List<String> = raw.trim().trim('|').split('|').map { it.trim() }.filter { it.isNotEmpty() }
        fun separatorCells(raw: String): List<String> = raw.trim('|').split('|').map { it.trim() }.filter { it.matches(Regex(":?-{3,}:?")) }

        for (index in lines.indices) {
            val line = lines[index]
            if (!line.contains('|')) continue
            val compact = line.replace(Regex("\\s+"), " ").trim()
            val match = separator.find(compact) ?: continue
            val n = separatorCells(match.value).size
            if (n < 2) continue

            val before = compact.substring(0, match.range.first).trim()
            val after = compact.substring(match.range.last + 1).trim()
            // A normal Markdown table already has a standalone separator line. Leave it alone;
            // repair is needed only when header/rows are collapsed onto that separator line.
            if (before.isBlank() && after.isBlank()) continue
            val sameLineHeader = cells(before)
            val previousHeader = if (index > 0) cells(lines[index - 1]) else emptyList()
            val header = when {
                sameLineHeader.size >= n -> sameLineHeader.takeLast(n)
                previousHeader.size == n -> previousHeader
                previousHeader.size > n -> previousHeader.takeLast(n)
                else -> emptyList()
            }
            if (header.size != n) continue

            // The provider can collapse the whole table into one physical line. Once the
            // separator establishes the column count, parse all following pipe cells in groups
            // of N. This is deterministic and avoids guessing where prose becomes a table.
            val tailCells = cells(after)
            val rows = if (tailCells.size >= n) tailCells.chunked(n).filter { it.size == n } else emptyList()
            val table = buildString {
                append("| ").append(header.joinToString(" | ")).append(" |\n")
                append(match.value).append('\n')
                rows.forEach { row -> append("| ").append(row.joinToString(" | ")).append(" |\n") }
            }.trimEnd()

            val sameLineProse = if (sameLineHeader.size > n) sameLineHeader.dropLast(n).joinToString(" | ") else ""
            if (sameLineHeader.size >= n && sameLineProse.isNotBlank()) {
                lines[index] = sameLineProse + "\n" + table
            } else {
                // Header was already on the preceding line. Keep it out of the prose/table
                // duplication and replace the separator line with a normalized table.
                lines[index] = table
            }
        }
        return lines.joinToString("\n").replace(Regex("\\n{3,}"), "\n\n")
    }
    s = repairCollapsedMarkdownTables(s)
    val lines = s.split('\n')
    val pre = StringBuilder()
    var i = 0

    fun splitCells(line: String): List<String> =
        line.trim().trim('|').split('|').map { it.trim() }

    fun isSeparator(line: String): Boolean {
        val cells = splitCells(line)
        return cells.size >= 2 && cells.all { it.matches(Regex(":?-{3,}:?")) }
    }

    fun inlineCell(cell: String): String {
        var x = android.text.TextUtils.htmlEncode(cell)
        x = x.replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("~~(.+?)~~", RegexOption.DOT_MATCHES_ALL), "<del>$1</del>")
            .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
            .replace(Regex("`([^`\\n]+?)`"), "<code>$1</code>")
            .replace(Regex("\\[([^\\]]+)]\\((https://[^\\s)]+)\\)"), "<a href=\"$2\">$1</a>")
        return x
    }

    while (i < lines.size) {
        if (i + 1 < lines.size && lines[i].count { it == '|' } >= 2 && isSeparator(lines[i + 1])) {
            val token = "@@ROVEX_TABLE_${tableTokens.size}@@"
            var header = splitCells(lines[i])
            val separatorCount = splitCells(lines[i + 1]).size
            // A table requires a real header row whose column count matches the separator.
            // This is the key guard preventing Ben/search/context prose from becoming a table.
            if (separatorCount < 2 || header.size != separatorCount) {
                pre.append(lines[i]).append('\n'); i++; continue
            }
            val rows = ArrayList<List<String>>()
            i += 2
            while (i < lines.size && lines[i].count { it == '|' } >= 2 && lines[i].trim().isNotBlank()) {
                if (isSeparator(lines[i])) { i++; continue }
                rows += splitCells(lines[i]); i++
            }
            val columnCount = header.size.coerceAtLeast(rows.maxOfOrNull { it.size } ?: 0).coerceAtMost(12)
            val html = StringBuilder("<div class=\"table-wrap\"><table><thead><tr>")
            header.take(columnCount).forEach { html.append("<th>").append(inlineCell(it)).append("</th>") }
            html.append("</tr></thead><tbody>")
            rows.take(80).forEach { cells ->
                html.append("<tr>")
                for (c in 0 until columnCount) html.append("<td>").append(inlineCell(cells.getOrNull(c).orEmpty())).append("</td>")
                html.append("</tr>")
            }
            html.append("</tbody></table></div>")
            tableTokens += html.toString()
            pre.append(token).append('\n')
        } else {
            pre.append(lines[i]).append('\n'); i++
        }
    }

    s = android.text.TextUtils.htmlEncode(pre.toString())
    codeTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_CODE_$index@@", html) }
    richTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_RICH_$index@@", html) }
    imageTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_IMAGE_$index@@", html) }
    tableTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_TABLE_$index@@", html) }

    s = s.replace(Regex("(?m)^######\\s+(.+)$"), "<h6>$1</h6>")
        .replace(Regex("(?m)^#####\\s+(.+)$"), "<h5>$1</h5>")
        .replace(Regex("(?m)^####\\s+(.+)$"), "<h4>$1</h4>")
        .replace(Regex("(?m)^###\\s+(.+)$"), "<h3>$1</h3>")
        .replace(Regex("(?m)^##\\s+(.+)$"), "<h2>$1</h2>")
        .replace(Regex("(?m)^#\\s+(.+)$"), "<h1>$1</h1>")
        .replace(Regex("(?m)^>\\s?(.+)$"), "<blockquote>$1</blockquote>")
        .replace(Regex("(?m)^[-*+]\\s+"), "• ")
        .replace(Regex("(?m)^(\\d+)[.)]\\s+"), "$1. ")
        .replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("~~(.+?)~~", RegexOption.DOT_MATCHES_ALL), "<del>$1</del>")
        .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
        .replace(Regex("`([^`\\n]+?)`"), "<code>$1</code>")
        .replace(Regex("\\[([^\\]]+)]\\((https://[^\\s)]+)\\)"), "<a href=\"$2\">$1</a>")

    val blocks = Regex("(@@ROVEX_TABLE_\\d+@@|@@ROVEX_RICH_\\d+@@|<div class=\"table-wrap\">.*?</div>|<img\\s[^>]*>|<pre>.*?</pre>)", setOf(RegexOption.DOT_MATCHES_ALL))
    val protectedBlocks = ArrayList<String>()
    s = s.replace(blocks) { m ->
        val token = "@@ROVEX_BLOCK_${protectedBlocks.size}@@"; protectedBlocks += m.value; token
    }

    // Keep block-level tables/images/code OUTSIDE paragraph elements. A previous implementation
    // replaced the protected token after wrapping the whole document in <p>, producing invalid
    // <p><div>… HTML that Chromium could relocate or drop.
    val blockPattern = Regex("@@ROVEX_BLOCK_(\\d+)@@")
    val bodyOut = StringBuilder()
    var cursor = 0
    blockPattern.findAll(s).forEach { match ->
        val textPart = s.substring(cursor, match.range.first)
        if (textPart.isNotBlank()) {
            bodyOut.append("<p>")
                .append(textPart.trim().replace(Regex("\\n{2,}"), "</p><p>").replace("\n", "<br>"))
                .append("</p>")
        }
        bodyOut.append(protectedBlocks[match.groupValues[1].toInt()])
        cursor = match.range.last + 1
    }
    val tail = s.substring(cursor)
    if (tail.isNotBlank()) {
        bodyOut.append("<p>")
            .append(tail.trim().replace(Regex("\\n{2,}"), "</p><p>").replace("\n", "<br>"))
            .append("</p>")
    }
    return bodyOut.toString()
}


private fun escHtml(value: String): String = android.text.TextUtils.htmlEncode(value)

/**
 * Renders only explicit AI rich blocks. This is deliberately deterministic and dependency-free:
 * JavaScript/chart libraries are not loaded into the chat WebView. This keeps the chat offline,
 * fast and safer while still allowing the AI to author visual content.
 */
private fun renderExplicitRichBlock(kind: String, source: String): String = when (kind) {
    "mermaid" -> renderMermaidBlock(source)
    "chart" -> renderChartBlock(source)
    "tree" -> renderTreeBlock(source)
    "slides", "presentation" -> renderSlidesBlock(source)
    else -> "<pre>${escHtml(source)}</pre>"
}

private fun renderMermaidBlock(source: String): String {
    val clean = source.lines().map { it.trim() }.filter { it.isNotBlank() }
    if (clean.isEmpty()) return ""
    val lower = clean.first().lowercase()
    return when {
        lower.startsWith("pie") -> {
            val rows = clean.drop(1).mapNotNull { line ->
                val m = Regex("^\\\"?(.+?)\\\"?\\s*:\\s*([0-9]+(?:\\.[0-9]+)?)$").find(line) ?: return@mapNotNull null
                m.groupValues[1].trim(' ', '"') to m.groupValues[2].toDoubleOrNull()
            }.filter { it.second != null }.take(12)
            if (rows.isEmpty()) "<pre>${escHtml(source)}</pre>" else renderPieSvg(rows.map { it.first to it.second!! })
        }
        lower.startsWith("mindmap") -> renderTreeBlock(clean.drop(1).joinToString("\n"))
        lower.startsWith("flowchart") || lower.startsWith("graph") || clean.any { it.contains("-->") || it.contains("---") } -> renderFlowSvg(clean.drop(1))
        else -> "<pre>${escHtml(source)}</pre>"
    }
}

private fun renderFlowSvg(lines: List<String>): String {
    val edges = lines.mapNotNull { line ->
        val m = Regex("^([A-Za-z0-9_]+)\\s*[-.]{2,}>\\s*([A-Za-z0-9_]+)").find(line) ?: return@mapNotNull null
        m.groupValues[1] to m.groupValues[2]
    }.distinct().take(30)
    if (edges.isEmpty()) return "<pre>${escHtml(lines.joinToString("\\n"))}</pre>"
    val nodes = (edges.flatMap { listOf(it.first, it.second) }).distinct().take(24)
    val width = 720; val rowH = 72; val height = (nodes.size * rowH + 30).coerceAtMost(1800)
    val nodeHtml = nodes.mapIndexed { i, n ->
        val y = 15 + i * rowH
        "<rect x=30 y=$y width=250 height=44 rx=12 class=\"node\"/><text x=155 y=${y+28} text-anchor=\"middle\" class=\"label\">${escHtml(n)}</text>"
    }.joinToString("")
    val arrows = edges.map { (a,b) ->
        val y1 = 37 + nodes.indexOf(a) * rowH; val y2 = 37 + nodes.indexOf(b) * rowH
        "<line x1=280 y1=$y1 x2=420 y2=$y2 class=\"edge\" marker-end=\"url(#arrow)\"/>"
    }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $width $height\" role=\"img\" aria-label=\"AI flowchart\"><defs><marker id=\"arrow\" markerWidth=\"8\" markerHeight=\"8\" refX=\"7\" refY=\"4\" orient=\"auto\"><path d=\"M0,0 L8,4 L0,8 z\"/></marker></defs>$nodeHtml$arrows</svg></div>"
}

private fun renderPieSvg(rows: List<Pair<String, Double>>): String {
    val total = rows.sumOf { it.second }.takeIf { it > 0.0 } ?: return ""
    val cx = 140.0; val cy = 140.0; val r = 105.0
    var angle = -Math.PI / 2
    val paths = rows.mapIndexed { i, (label, value) ->
        val sweep = value / total * Math.PI * 2
        val end = angle + sweep
        val x1 = cx + r * kotlin.math.cos(angle); val y1 = cy + r * kotlin.math.sin(angle)
        val x2 = cx + r * kotlin.math.cos(end); val y2 = cy + r * kotlin.math.sin(end)
        val large = if (sweep > Math.PI) 1 else 0
        val d = "M $cx $cy L $x1 $y1 A $r $r 0 $large 1 $x2 $y2 Z"
        angle = end
        "<path d=\"$d\" class=\"slice s$i\"/><text x=\"310\" y=\"${35+i*28}\" class=\"legend\">${escHtml(label)} (${("%.1f".format(value))})</text>"
    }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 560 300\" role=\"img\" aria-label=\"AI pie chart\"><circle cx=\"$cx\" cy=\"$cy\" r=\"$r\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1\" opacity=\".15\"/>$paths</svg></div>"
}

private fun renderChartBlock(source: String): String {
    return try {
        val o = org.json.JSONObject(source.trim())
        val type = o.optString("type", "bar").lowercase()
        val labels = o.optJSONArray("labels") ?: return "<pre>${escHtml(source)}</pre>"
        val values = o.optJSONArray("values") ?: return "<pre>${escHtml(source)}</pre>"
        val pairs = (0 until minOf(labels.length(), values.length(), 24)).mapNotNull { i ->
            val v = values.optDouble(i, Double.NaN); if (v.isFinite()) labels.optString(i) to v else null
        }
        when (type) {
            "pie", "doughnut" -> renderPieSvg(pairs)
            "bar", "line" -> renderBarLineSvg(type, pairs)
            else -> "<pre>${escHtml(source)}</pre>"
        }
    } catch (_: Exception) { "<pre>${escHtml(source)}</pre>" }
}

private fun renderBarLineSvg(type: String, pairs: List<Pair<String, Double>>): String {
    if (pairs.isEmpty()) return ""
    val max = pairs.maxOf { kotlin.math.abs(it.second) }.coerceAtLeast(1.0)
    val width = 720; val height = 340; val base = 270; val left = 55; val usable = 620.0
    val step = usable / pairs.size
    val marks = pairs.mapIndexed { i, (label, value) ->
        val x = left + step * i + step * .18; val h = kotlin.math.abs(value) / max * 210.0; val y = base - h
        if (type == "line") "<circle cx=\"${x+step*.32}\" cy=\"$y\" r=\"5\" class=\"point\"/><text x=\"${x+step*.32}\" y=\"${base+25}\" text-anchor=\"middle\" class=\"legend\">${escHtml(label.take(14))}</text>"
        else "<rect x=\"$x\" y=\"$y\" width=\"${step*.64}\" height=\"$h\" rx=\"7\" class=\"bar\"/><text x=\"${x+step*.32}\" y=\"${base+25}\" text-anchor=\"middle\" class=\"legend\">${escHtml(label.take(14))}</text>"
    }.joinToString("")
    val line = if (type == "line") {
        val pts = pairs.mapIndexed { i, (_, v) -> val x=left+step*i+step*.32; val y=base-kotlin.math.abs(v)/max*210.0; "$x,$y" }.joinToString(" ")
        "<polyline points=\"$pts\" class=\"line\" fill=\"none\"/>"
    } else ""
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $width $height\" role=\"img\" aria-label=\"AI $type chart\"><line x1=\"$left\" y1=\"$base\" x2=\"680\" y2=\"$base\" class=\"axis\"/>$line$marks</svg></div>"
}

private fun renderTreeBlock(source: String): String {
    val lines = source.lines().map { it.trimEnd() }.filter { it.trim().isNotBlank() }.take(80)
    if (lines.isEmpty()) return ""
    return "<div class=\"rich-tree\"><pre>${escHtml(lines.joinToString("\\n"))}</pre></div>"
}

private fun renderSlidesBlock(source: String): String {
    val slides = source.split(Regex("(?m)^\\s*---+\\s*$")).map { it.trim() }.filter { it.isNotBlank() }.take(20)
    return if (slides.size <= 1) "<div class=\"slide\">${rovexMarkdownBody(slides.firstOrNull().orEmpty())}</div>"
    else "<div class=\"presentation\">" + slides.mapIndexed { i, slide -> "<article class=\"slide\"><div class=\"slide-number\">${i+1}</div>${rovexMarkdownBody(slide)}</article>" }.joinToString("") + "</div>"
}

private fun wrapMarkdownDocument(body: String): String = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>body{font-family:sans-serif;font-size:16px;line-height:1.52;margin:0;padding:2px;color:#EAF1F7}h1{font-size:25px;margin:8px 0}h2{font-size:21px;margin:16px 0 7px}h3{font-size:18px;margin:14px 0 6px}h4{font-size:16px;margin:12px 0 5px}p{margin:8px 0}blockquote{margin:10px 0;padding:9px 12px;border-left:4px solid #61B7FF;background:#182936;border-radius:8px}code,pre{background:#17232D;border-radius:8px;padding:2px 5px}pre{padding:10px;overflow:auto}.table-wrap{touch-action:pan-x pan-y;width:100%;max-width:100%;max-height:70vh;overflow:auto;margin:12px 0;padding-bottom:2px;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;scrollbar-gutter:stable}table{border-collapse:collapse;margin:0;background:#13212B;width:max-content;min-width:680px;max-width:none;table-layout:auto}th,td{box-sizing:border-box;border:1px solid #334A5A;padding:8px 9px;text-align:left;vertical-align:top;min-width:0;max-width:none;overflow-wrap:anywhere;word-break:break-word}th{background:#1C3445;color:#B9F4EF;white-space:normal}mark{background:#6B5520;color:#FFF2B0;padding:1px 4px;border-radius:4px}.card{background:#13212B;border:1px solid #2C4352;border-radius:14px;padding:12px;margin:10px 0}.label{font-size:12px;color:#8FCBFF;text-transform:uppercase;letter-spacing:.08em;font-weight:700}.answer{font-size:19px;font-weight:700;color:#62D7A1}img{display:block;max-width:100%;height:auto;max-height:520px;object-fit:contain;border-radius:10px;margin:10px auto;background:#0D151B}a{color:#7FCBFF}table{overflow-wrap:anywhere}.rich-diagram{width:100%;overflow:auto;max-height:70vh;margin:12px 0;padding:4px 0}.rich-diagram svg{display:block;width:100%;min-width:420px;height:auto;max-height:720px}.rich-diagram .node{fill:#1A2A35;stroke:#6FB6D8;stroke-width:1.5}.rich-diagram .label,.rich-diagram .legend{fill:currentColor;font:14px sans-serif}.rich-diagram .edge,.rich-diagram .axis{stroke:currentColor;stroke-width:2;opacity:.65}.rich-diagram .bar{fill:#62B6E8}.rich-diagram .line{stroke:#62D7A1;stroke-width:4}.rich-diagram .point{fill:#62D7A1}.rich-diagram .slice{stroke:#0D151B;stroke-width:2}.rich-diagram .s0{fill:#62B6E8}.rich-diagram .s1{fill:#62D7A1}.rich-diagram .s2{fill:#D8A85C}.rich-diagram .s3{fill:#B68DEB}.rich-diagram .s4{fill:#E7839A}.rich-tree{margin:12px 0}.rich-tree pre{white-space:pre;overflow:auto}.presentation{display:flex;gap:12px;overflow-x:auto;padding:4px 0 12px;scroll-snap-type:x mandatory}.slide{box-sizing:border-box;min-width:92%;max-width:92%;padding:18px;border-radius:16px;border:1px solid #2C4352;background:#13212B;scroll-snap-align:start}.slide-number{font-size:11px;font-weight:800;opacity:.7;margin-bottom:6px}</style></head><body>$body</body></html>"""
