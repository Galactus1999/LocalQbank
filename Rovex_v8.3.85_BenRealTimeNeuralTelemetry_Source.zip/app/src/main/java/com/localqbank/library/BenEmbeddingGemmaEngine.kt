package com.localqbank.library

import android.content.Context
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.max

/**
 * Optional CPU-first EmbeddingGemma 300M accelerator.
 *
 * It is deliberately a short-lived inference adapter: load -> embed a bounded batch -> close.
 * It never owns retrieval policy, scheduling, study state, or the canonical QBank corpus.
 * If the model is unavailable or the resource governor denies execution, callers keep their
 * deterministic FTS/concept retrieval path.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)

    data class Result<T>(
        val hits: List<SemanticHit<T>>,
        val elapsedMs: Long,
        val usedModel: Boolean
    )

    suspend fun <T> rerank(
        query: String,
        candidates: List<T>,
        textOf: (T) -> String,
        limit: Int = 8
    ): Result<T> = withContext(Dispatchers.Default) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile)
            ?: return@withContext Result(candidates.take(limit).map { SemanticHit(it, 0.0) }, 0L, false)
        if (!policy.mayStartModel(profile.estimatedModelMb) ||
            !governor.mayRun(policy, profile.estimatedRuntimeMb)
        ) {
            BenNeuralTelemetry.blocked("EmbeddingGemma blocked by policy/resource governor")
            return@withContext Result(candidates.take(limit).map { SemanticHit(it, 0.0) }, 0L, false)
        }

        val boundedQuery = query.trim().replace(Regex("\\s+"), " ").take(1200)
        if (boundedQuery.length < 2 || candidates.isEmpty()) {
            return@withContext Result(emptyList(), 0L, false)
        }

        val selected = candidates.take(8)
        return@withContext try {
            val modelBuffer = mapReadOnly(installed.file)
            val base = BaseOptions.builder()
                .setModelAssetBuffer(modelBuffer)
                .setDelegate(Delegate.CPU)
                .build()
            val options = TextEmbedder.TextEmbedderOptions.builder()
                .setBaseOptions(base)
                .build()
            val embedder = TextEmbedder.createFromOptions(app, options)
            try {
                val queryEmbedding = embedder.embed(
                    "task: search result | query: $boundedQuery"
                ).embeddingResult().embeddings().first()
                val scored = selected.map { candidate ->
                    val text = textOf(candidate).replace(Regex("\\s+"), " ").trim().take(1200)
                    val document = "title: none | text: $text"
                    val embedding = embedder.embed(document).embeddingResult().embeddings().first()
                    SemanticHit(candidate, TextEmbedder.cosineSimilarity(queryEmbedding, embedding))
                }.sortedByDescending { it.similarity }.take(limit.coerceIn(1, 8))
                policy.recordBackendSuccess()
                Result(scored, max(0L, System.currentTimeMillis() - started), true)
            } finally {
                embedder.close()
            }
        } catch (error: Exception) {
            BenNeuralTelemetry.error("EmbeddingGemma: ${error.javaClass.simpleName}")
            policy.recordBackendFailure()
            Result(candidates.take(limit).map { SemanticHit(it, 0.0) }, max(0L, System.currentTimeMillis() - started), false)
        }
    }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.Default) {
        val installed = models.installed(profile) ?: return@withContext null
        if (!policy.mayStartModel(profile.estimatedModelMb) || !governor.mayRun(policy, profile.estimatedRuntimeMb)) return@withContext null
        try {
            val buffer = mapReadOnly(installed.file)
            val base = BaseOptions.builder().setModelAssetBuffer(buffer).setDelegate(Delegate.CPU).build()
            val options = TextEmbedder.TextEmbedderOptions.builder().setBaseOptions(base).build()
            val embedder = TextEmbedder.createFromOptions(app, options)
            try {
                val a = embedder.embed("task: sentence similarity | query: ${first.trim().take(1200)}").embeddingResult().embeddings().first()
                val b = embedder.embed("task: sentence similarity | query: ${second.trim().take(1200)}").embeddingResult().embeddings().first()
                policy.recordBackendSuccess()
                TextEmbedder.cosineSimilarity(a, b)
            } finally { embedder.close() }
        } catch (error: Exception) {
            BenNeuralTelemetry.error("EmbeddingGemma: ${error.javaClass.simpleName}")
            policy.recordBackendFailure()
            null
        }
    }

    private fun mapReadOnly(file: File): MappedByteBuffer =
        RandomAccessFile(file, "r").use { raf ->
            raf.channel.map(FileChannel.MapMode.READ_ONLY, 0L, raf.length())
        }

}