package com.localqbank.library

import android.content.Context
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Ben's lightweight cognitive architecture.
 *
 * This is deliberately model-independent: retrieval, routing, memory, planning and
 * verification continue to work with the neural backend disabled. A future local model
 * is an accelerator behind BenInferenceBackend, never the owner of study state.
 */
class BenCognitiveArchitecture(context: Context) {
    private val app = context.applicationContext
    private val knowledge = BenKnowledgeGraph(app)
    private val learner = BenLearnerModel(app)
    private val planner = BenPlanner(knowledge, learner)
    private val verifier = BenAnswerVerifier(knowledge)
    private val control = BenCognitiveControl(app)
    private val frankenstein = BenFrankensteinEngine(app)
    private val experience = BenExperienceMemory(app)
    private val knowledgeIndex = BenLocalKnowledgeIndex(app)

    data class Plan(
        val query: String,
        val intent: String?,
        val concepts: List<String>,
        val domains: Set<String>,
        val tools: List<String>,
        val confidence: Int,
        val specialist: String = "clinical_retrieval",
        val retrievedQuestionCount: Int = 0,
        val indexedEvidenceCount: Int = 0,
        val knowledgeGraphEdges: Int = 0
    )

    data class Result(
        val answer: String,
        val plan: Plan,
        val verified: Boolean,
        val confidence: Int,
        val modelUsed: Boolean
    )

    fun answer(query: String, currentQuestion: Question? = null, baseAnswer: String? = null, modelUsed: Boolean = false): Result {
        val clean = BenResearchInputPolicy.normalize(query)
            ?: return Result("Give Ben a clinical term, topic, question, or study task.", Plan("", null, emptyList(), emptySet(), emptyList(), 0), true, 0, false)
        if (!control.cognitiveCoreEnabled) {
            val fallback = baseAnswer?.takeIf { it.isNotBlank() } ?: RenCognitiveEngine(app).answer(clean, currentQuestion).body
            return Result(BenResponsePolicy.normalize(fallback).orEmpty(), Plan(clean, null, emptyList(), emptySet(), listOf("legacy_local_fallback"), 35), true, 35, false)
        }
        val basePlan = if (control.plannerEnabled) planner.plan(clean, control.knowledgeGraphEnabled) else BenCognitiveArchitecture.Plan(clean, null, emptyList(), emptySet(), emptyList(), 30)
        val retrieval = if (control.retrievalEnabled) frankenstein.retrieve(clean, 12) else BenFrankensteinEngine.Retrieval(LongArray(0), emptyList(), listOf(clean), emptySet())
        val indexed = if (control.knowledgeIndexEnabled) runCatching { knowledgeIndex.retrieve(clean, retrieval.concepts, 8) }.getOrDefault(BenLocalKnowledgeIndex.Retrieval(emptyList(), 0)) else BenLocalKnowledgeIndex.Retrieval(emptyList(), 0)
        if (control.knowledgeIndexEnabled) runCatching { knowledgeIndex.observe(clean, retrieval.concepts, retrieval.domains) }
        val specialist = if (control.specialistRoutingEnabled) frankenstein.specialist(clean) else BenFrankensteinEngine.Specialist("clinical_retrieval", "Clinical retrieval", "Specialist routing disabled")
        val plan = basePlan.copy(
            concepts = if (basePlan.concepts.isNotEmpty()) basePlan.concepts else retrieval.concepts,
            domains = if (basePlan.domains.isNotEmpty()) basePlan.domains else retrieval.domains,
            tools = (basePlan.tools + specialist.id + if (retrieval.questionIds.isNotEmpty()) "local_rag" else "").filter { it.isNotBlank() }.distinct(),
            specialist = specialist.id,
            retrievedQuestionCount = retrieval.questionIds.size,
            indexedEvidenceCount = indexed.evidence.size,
            knowledgeGraphEdges = indexed.edgeCount,
            confidence = (basePlan.confidence + if (retrieval.questionIds.isNotEmpty()) 8 else 0 + indexed.evidence.size.coerceAtMost(4) + if (indexed.edgeCount > 0) 3 else 0).coerceIn(0, 95)
        )
        if (control.learnerMemoryEnabled) {
            learner.observeQuery(plan)
            if (currentQuestion != null) learner.observeQuestion(currentQuestion)
        }
        val candidate = baseAnswer?.takeIf { it.isNotBlank() }
            ?: RenCognitiveEngine(app).answer(clean, currentQuestion).body
        val verification = if (control.verifierEnabled) verifier.verify(clean, candidate, plan) else BenAnswerVerifier.Verification(true, plan.confidence)
        val final = if (verification.acceptable) candidate else verifier.repair(clean, candidate, plan)
        val confidence = ((plan.confidence * 0.7f) + (verification.score * 0.3f)).roundToInt().coerceIn(0, 100)
        val result = Result(BenResponsePolicy.normalize(final).orEmpty(), plan, verification.acceptable, confidence, modelUsed)
        if (control.experienceMemoryEnabled) {
            runCatching { frankenstein.observe(clean, plan, result) }
            runCatching { experience.record(clean, plan, result) }
        }
        return result
    }

    fun control(): BenCognitiveControl = control

    fun capabilitySummary(): List<String> = listOf(
        "Intent routing", "Clinical concept graph", "Local retrieval planning", "Learner memory",
        "Adaptive tool selection", "Answer verification", "Offline-first reasoning", "Optional neural accelerator", "Local knowledge index and concept-edge graph"
    )

    fun toolRegistry(): BenToolRegistry = BenToolRegistry(app)
    fun frankenstein(): BenFrankensteinEngine = frankenstein
    fun experience(): BenExperienceMemory = experience
    fun knowledgeIndex(): BenLocalKnowledgeIndex = knowledgeIndex
}

/** Compact concept graph built from the existing clinical lexicon plus learned usage edges. */
class BenKnowledgeGraph(context: Context) {
    private val app = context.applicationContext
    private val clinical = ClinicalKnowledgeLayer(app)

    data class Concept(
        val id: String,
        val label: String,
        val domains: Set<String>,
        val related: List<String>
    )

    fun resolve(query: String, max: Int = 8): List<Concept> = clinical.understand(query).concepts.take(max).map {
        Concept(it.id, it.canonical, it.domains, it.related)
    }

    fun expansions(query: String, max: Int = 32): List<String> = clinical.understand(query).expansions.take(max)

    fun understand(query: String): ClinicalKnowledgeLayer.Understanding = clinical.understand(query)

    fun relationCount(concepts: List<Concept>): Int = concepts.sumOf { it.related.size }.coerceAtMost(128)
}

/**
 * Persistent, bounded learner memory. It stores compact concept-level experience rather than
 * model weights. This makes Ben improve offline without adding RAM-heavy training.
 */
class BenLearnerModel(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("ben_learner", Context.MODE_PRIVATE)
    private val clinical = ClinicalKnowledgeLayer(app)

    data class ConceptStats(val seen: Int, val wrong: Int, val correct: Int) {
        val mastery: Int
            get() = if (seen == 0) 0 else ((correct * 100.0) / seen).roundToInt().coerceIn(0, 100)
    }

    fun observeQuery(plan: BenCognitiveArchitecture.Plan) {
        plan.concepts.take(8).forEach { touch(it) }
    }

    fun observeQuestion(question: Question) {
        val understanding = clinical.understand(question.text)
        val progress = runCatching { PerformanceManager.progress(app) }.getOrNull()
        val record = progress?.record(question.stableKey)
        understanding.concepts.take(8).forEach { concept ->
            when (record?.status) {
                "wrong" -> update(concept.canonical, 1, 1, 0)
                "correct" -> update(concept.canonical, 1, 0, 1)
                else -> touch(concept.canonical)
            }
        }
    }

    fun stats(concept: String): ConceptStats {
        val key = key(concept)
        return ConceptStats(prefs.getInt("$key.seen", 0), prefs.getInt("$key.wrong", 0), prefs.getInt("$key.correct", 0))
    }

    fun weakest(concepts: List<String>): String? = concepts.minByOrNull { stats(it).mastery }

    private fun touch(concept: String) = update(concept, 1, 0, 0)

    private fun update(concept: String, seen: Int, wrong: Int, correct: Int) {
        val k = key(concept)
        val old = stats(concept)
        prefs.edit()
            .putInt("$k.seen", (old.seen + seen).coerceAtMost(100_000))
            .putInt("$k.wrong", (old.wrong + wrong).coerceAtMost(100_000))
            .putInt("$k.correct", (old.correct + correct).coerceAtMost(100_000))
            .apply()
    }

    private fun key(value: String): String = "c_${value.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(80)}"
}

/** Fast deterministic router: chooses tools before any optional neural inference. */
class BenPlanner(
    private val knowledge: BenKnowledgeGraph,
    private val learner: BenLearnerModel
) {
    fun plan(query: String, knowledgeGraphEnabled: Boolean = true): BenCognitiveArchitecture.Plan {
        val understanding = if (knowledgeGraphEnabled) knowledgeUnderstanding(query) else
            ClinicalKnowledgeLayer.Understanding(query, query, emptyList(), null, emptySet(), emptyList())
        val concepts = understanding.concepts.map { it.canonical }.take(8)
        val tools = linkedSetOf<String>()
        when (understanding.intent) {
            "management" -> tools += "management_reasoner"
            "diagnosis_investigation" -> tools += "diagnostic_reasoner"
            "mechanism" -> tools += "mechanism_reasoner"
            "pathology" -> tools += "pathology_reasoner"
            "imaging" -> tools += "imaging_reasoner"
            "genetics" -> tools += "genetics_reasoner"
            "complication_adverse_effect" -> tools += "safety_reasoner"
            "epidemiology" -> tools += "epidemiology_reasoner"
            "association" -> tools += "association_reasoner"
            else -> tools += "clinical_retrieval"
        }
        if (query.contains("wrong", true) || query.contains("mistake", true) || query.contains("weak", true)) tools += "learner_weakness"
        tools += "qbank_retrieval"
        val weakest = learner.weakest(concepts)
        if (weakest != null) {
            tools += "weakness_context"
            if (learner.stats(weakest).wrong >= 2) tools += "misconception_check"
        }
        if (query.contains("trap", true) || query.contains("except", true) || query.contains("incorrect", true) || query.contains("not true", true)) tools += "exam_trap_detector"
        if (query.contains("guideline", true) || query.contains("dose", true) || query.contains("cutoff", true) || query.contains("criteria", true)) tools += "evidence_caution"
        val relationBoost = (knowledge.relationCount(knowledge.resolve(query)) * 2).coerceAtMost(20)
        val weaknessBoost = weakest?.let { (100 - learner.stats(it).mastery) / 5 } ?: 0
        val confidence = (45 + concepts.size * 6 + relationBoost + weaknessBoost.coerceAtMost(12)).coerceIn(0, 95)
        return BenCognitiveArchitecture.Plan(query, understanding.intent, concepts, understanding.domains, tools.toList(), confidence)
    }

    private fun knowledgeUnderstanding(query: String): ClinicalKnowledgeLayer.Understanding = knowledge.understand(query)
}

/** Compact local episodic memory: recent Ben decisions, not raw answers or source QBank data. */
class BenExperienceMemory(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("ben_experience_memory", Context.MODE_PRIVATE)
    private val maxEntries = 32

    data class Entry(val intent: String, val specialist: String, val confidence: Int, val verified: Boolean, val timestamp: Long)

    fun record(query: String, plan: BenCognitiveArchitecture.Plan, result: BenCognitiveArchitecture.Result) {
        val compact = listOf(System.currentTimeMillis(), plan.intent ?: "general", plan.specialist, result.confidence, if (result.verified) 1 else 0, query.take(120).replace('\n', ' ')).joinToString("\t")
        val rows = recentRaw().toMutableList()
        rows += compact
        prefs.edit().putString("rows", rows.takeLast(maxEntries).joinToString("\n")).apply()
    }

    fun recent(limit: Int = 8): List<Entry> = recentRaw().takeLast(limit.coerceIn(1, maxEntries)).mapNotNull { row ->
        val p = row.split('\t')
        if (p.size < 5) null else Entry(p[1], p[2], p[3].toIntOrNull()?.coerceIn(0,100) ?: 0, p[4] == "1", p[0].toLongOrNull() ?: 0L)
    }

    fun summary(): String {
        val rows = recent()
        if (rows.isEmpty()) return "No episodic experience yet."
        val verified = rows.count { it.verified }
        val specialists = rows.groupingBy { it.specialist }.eachCount().entries.sortedByDescending { it.value }.take(3)
        return "Recent ${rows.size} decisions • ${verified}/${rows.size} verified • dominant routes: ${specialists.joinToString { it.key + "×" + it.value }}"
    }

    fun reset() = prefs.edit().clear().apply()
    private fun recentRaw(): List<String> = prefs.getString("rows", "").orEmpty().lineSequence().filter { it.isNotBlank() }.toList()
}

class BenAnswerVerifier(private val knowledge: BenKnowledgeGraph) {
    data class Verification(val acceptable: Boolean, val score: Int)

    fun verify(query: String, answer: String, plan: BenCognitiveArchitecture.Plan): Verification {
        if (answer.isBlank()) return Verification(false, 0)
        var score = 45
        val lower = answer.lowercase(Locale.US)
        val conceptMatch = plan.concepts.any { lower.contains(it.lowercase(Locale.US).take(40)) }
        if (plan.concepts.isEmpty() || conceptMatch) score += 20
        if (plan.intent != null) score += 10
        if (conceptMatch) score += 10
        if (answer.length >= 40) score += 5
        if (answer.contains("could not", true) || answer.contains("try again", true)) score -= 20
        return Verification(score >= 50, score.coerceIn(0, 100))
    }

    fun repair(query: String, candidate: String, plan: BenCognitiveArchitecture.Plan): String = buildString {
        append(candidate.take(12000).trim())
        if (plan.concepts.isNotEmpty()) {
            append("\n\nBen checked this against local concepts: ")
            append(plan.concepts.take(4).joinToString(", "))
            append(".")
        }
        append("\n\nExam safety: verify the original QBank explanation when the question depends on a specific guideline, dose, cutoff, or image.")
    }
}


/** Deterministic tools exposed to Ben's planner. Tools never perform network I/O. */
class BenToolRegistry(private val context: Context) {
    data class Tool(val id: String, val description: String, val safeOffline: Boolean = true)

    fun tools(): List<Tool> = listOf(
        Tool("qbank_retrieval", "Search imported QBank question and explanation content"),
        Tool("clinical_retrieval", "Normalize medical concepts and expand related terminology"),
        Tool("learner_weakness", "Inspect local weak/wrong concept signals"),
        Tool("management_reasoner", "Prioritize treatment/management intent"),
        Tool("diagnostic_reasoner", "Prioritize diagnostic/investigation intent"),
        Tool("mechanism_reasoner", "Prioritize mechanism/pathophysiology intent"),
        Tool("study_planner", "Create a local adaptive study action"),
        Tool("flashcard_context", "Use existing flashcard/SRS context without auto-creating cards"),
        Tool("misconception_check", "Flag repeated local wrong-answer concept signals"),
        Tool("exam_trap_detector", "Detect common MCQ wording traps and negative stems"),
        Tool("evidence_caution", "Require source verification for dose, cutoff and guideline-sensitive claims"),
        Tool("association_reasoner", "Prioritize association/risk-factor reasoning"),
        Tool("epidemiology_reasoner", "Prioritize frequency, prevalence and commonest-pattern reasoning")
    )

    fun execute(toolId: String, query: String, limit: Int = 50): String? = runCatching {
        when (toolId) {
            "qbank_retrieval" -> {
                val ids = RenCognitiveEngine(context).searchQuestionIds(query, limit)
                "Matched ${ids.size} local question(s)."
            }
            "learner_weakness" -> AppManagers.adaptive.studyStrategy()
            "study_planner" -> AppManagers.adaptive.studyStrategy()
            else -> null
        }
    }.getOrNull()
}
