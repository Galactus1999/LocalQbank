package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test

class BenCognitiveControlTest {
    @Test fun defaultsAreSafeAndUseful() {
        val c = BenCognitiveControl(ApplicationProvider.getApplicationContext<Context>())
        assertTrue(c.cognitiveCoreEnabled)
        assertTrue(c.knowledgeGraphEnabled)
        assertTrue(c.learnerMemoryEnabled)
        assertTrue(c.verifierEnabled)
        assertTrue(c.plannerEnabled)
        assertTrue(c.retrievalEnabled)
        assertTrue(c.specialistRoutingEnabled)
        assertTrue(c.experienceMemoryEnabled)
    }
}
