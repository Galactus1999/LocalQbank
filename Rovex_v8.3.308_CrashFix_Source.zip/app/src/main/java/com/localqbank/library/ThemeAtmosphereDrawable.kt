package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.SystemClock
import kotlin.math.sin
import kotlin.math.cos

/**
 * Lightweight procedural atmosphere. It deliberately uses Canvas primitives rather than
 * bitmap/video assets so themes remain offline, small and memory-safe. Animation is paused
 * when the drawable is not visible and runs at a modest ~8 FPS while visible.
 */
class ThemeAtmosphereDrawable(private val context: Context) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stars = Array(96) { i -> Triple(((i * 47) % 101) / 100f, ((i * 71 + 11) % 101) / 100f, .5f + ((i * 17) % 10) / 10f) }
    private var phase = 0f
    private var visible = true

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        when (ThemeManager.get(context)) {
            ThemeManager.PANDORA -> pandora(c, w, h)
            ThemeManager.SPACE -> space(c, w, h)
            ThemeManager.AMOLED -> dark(c, w, h)
            ThemeManager.MINT -> light(c, w, h, Color.rgb(229,255,248), Color.rgb(233,245,255), Color.rgb(91,220,192))
            ThemeManager.SUNSET -> light(c, w, h, Color.rgb(255,242,225), Color.rgb(255,229,239), Color.rgb(255,151,90))
            ThemeManager.LAVENDER -> light(c, w, h, Color.rgb(241,235,255), Color.rgb(225,242,255), Color.rgb(170,125,255))
            ThemeManager.PASTEL -> light(c, w, h, Color.rgb(228,241,255), Color.rgb(249,234,255), Color.rgb(121,169,255))
            else -> light(c, w, h, Color.rgb(239,246,255), Color.rgb(250,244,255), Color.rgb(112,155,255))
        }
        if (visible && (ThemeManager.get(context) == ThemeManager.PANDORA || ThemeManager.get(context) == ThemeManager.SPACE || ThemeManager.get(context) == ThemeManager.AMOLED)) {
            phase = (phase + .035f) % 100f
            scheduleSelf({ invalidateSelf() }, SystemClock.uptimeMillis() + 120L)
        }
    }

    private fun light(c: Canvas, w: Float, h: Float, a: Int, b: Int, glow: Int) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, a, b, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        val pts = arrayOf(floatArrayOf(w*.08f,h*.10f),floatArrayOf(w*.92f,h*.16f),floatArrayOf(w*.18f,h*.88f),floatArrayOf(w*.78f,h*.82f))
        pts.forEachIndexed { i, q ->
            p.shader = RadialGradient(q[0], q[1], minOf(w,h)*.42f,
                intArrayOf(Color.argb(70-i*8,Color.red(glow),Color.green(glow),Color.blue(glow)),Color.TRANSPARENT),
                floatArrayOf(0f,1f), Shader.TileMode.CLAMP)
            c.drawCircle(q[0],q[1],minOf(w,h)*.42f,p)
        }
        p.shader = null
    }

    private fun pandora(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f,0f,w,h,Color.rgb(3,24,28),Color.rgb(20,66,54),Shader.TileMode.CLAMP); c.drawRect(0f,0f,w,h,p)
        // Cinematic atmospheric nebula / moonlight.
        glow(c,w*.76f,h*.16f,minOf(w,h)*.48f,Color.rgb(83,255,207),105)
        glow(c,w*.12f,h*.44f,minOf(w,h)*.38f,Color.rgb(45,146,255),70)
        // Layered distant mountains.
        mountain(c,w,h,.62f,Color.rgb(8,38,39),.14f)
        mountain(c,w,h,.72f,Color.rgb(5,29,30),.19f)
        // Bioluminescent forest.
        val base=h*.83f
        for (i in 0..18) {
            val x=(i/18f)*w + sin(phase*.25f+i)*w*.008f
            val treeH=h*(.10f + ((i*13)%9)/100f)
            tree(c,x,base,treeH,Color.rgb(8,54,43),Color.rgb(86,255,191))
        }
        // Moving fireflies / floating spores.
        for(i in 0..18){
            val x=((i*53)%100)/100f*w + sin(phase*.7f+i)*w*.012f
            val y=((i*29+17)%74)/100f*h + cos(phase*.45f+i)*h*.012f
            glow(c,x,y,minOf(w,h)*.012f,Color.rgb(111,255,208),90)
        }
        // Small flying-animal silhouettes with wing motion.
        for(i in 0..3){
            val x=((i*23+20)%90)/100f*w + sin(phase*.3f+i)*w*.025f
            val y=(.20f+i*.09f)*h + cos(phase*.5f+i)*h*.018f
            creature(c,x,y,minOf(w,h)*.018f,Color.rgb(7,25,29))
        }
    }

    private fun space(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f,0f,w,h,Color.rgb(1,3,13),Color.rgb(8,10,36),Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p)
        glow(c,w*.65f,h*.30f,minOf(w,h)*.55f,Color.rgb(74,89,255),105)
        glow(c,w*.18f,h*.76f,minOf(w,h)*.42f,Color.rgb(0,194,255),72)
        p.shader=null
        stars.forEachIndexed { i,s ->
            val tw=.45f+.55f*((sin(phase*.65f+i*.7f)+1f)/2f)
            p.color=Color.argb((100+100*tw).toInt(),190,220,255)
            c.drawCircle(s.first*w,s.second*h,s.third*(.45f+.22f*tw),p)
        }
        // Planet with shaded sphere and rings.
        val r=minOf(w,h)*.17f; val px=w*.72f; val py=h*.67f
        p.shader=RadialGradient(px-r*.35f,py-r*.45f,r,Color.rgb(205,232,255),Color.rgb(22,50,120),Shader.TileMode.CLAMP);c.drawCircle(px,py,r,p)
        p.shader=null;p.style=Paint.Style.STROKE;p.strokeWidth=r*.055f;p.color=Color.argb(180,154,198,255);c.drawOval(px-r*1.65f,py-r*.36f,px+r*1.65f,py+r*.36f,p);p.style=Paint.Style.FILL
        // Animated comet.
        val t=(phase*.012f)%1f; val cx=(-.15f+t*1.35f)*w; val cy=(.16f+t*.33f)*h
        p.strokeWidth=minOf(w,h)*.009f;p.strokeCap=Paint.Cap.ROUND;p.color=Color.argb(145,170,225,255);c.drawLine(cx-w*.10f,cy-h*.05f,cx,cy,p);glow(c,cx,cy,minOf(w,h)*.016f,Color.WHITE,170)
    }

    private fun dark(c:Canvas,w:Float,h:Float){
        p.style=Paint.Style.FILL;p.shader=LinearGradient(0f,0f,w,h,Color.rgb(0,3,9),Color.rgb(4,8,19),Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p)
        glow(c,w*.68f,h*.16f,minOf(w,h)*.64f,Color.rgb(40,88,255),92);glow(c,w*.14f,h*.78f,minOf(w,h)*.45f,Color.rgb(0,205,255),72)
        stars.forEachIndexed{i,s->p.color=Color.argb((120+80*((sin(phase*.6f+i)+1f)/2f)).toInt(),185,220,255);c.drawCircle(s.first*w,s.second*h,s.third*.65f,p)}
        glow(c,w*.86f,h*.13f,minOf(w,h)*.075f,Color.rgb(55,196,255),120);glow(c,w*.15f,h*.84f,minOf(w,h)*.04f,Color.rgb(133,75,255),100)
    }

    private fun mountain(c:Canvas,w:Float,h:Float,base:Float,color:Int,offset:Float){
        val path=Path();path.moveTo(0f,h*base);for(i in 0..8){val x=w*i/8f;val y=h*(base-offset-(i%3)*.045f);path.lineTo(x,y)};path.lineTo(w,h);path.lineTo(0f,h);path.close();p.shader=null;p.color=color;c.drawPath(path,p)
    }
    private fun tree(c:Canvas,x:Float,base:Float,height:Float,trunk:Int,leaf:Int){
        p.color=trunk;c.drawRect(x-height*.07f,base-height*.38f,x+height*.07f,base,p)
        for(i in 0..4){val yy=base-height*(.42f+i*.12f);val rr=height*(.22f-.018f*i);p.color=if(i%2==0)leaf else Color.rgb(20,100,72);c.drawCircle(x+sin(i.toFloat())*height*.08f,yy,rr,p)}
    }
    private fun creature(c:Canvas,x:Float,y:Float,r:Float,color:Int){p.color=color;c.drawOval(x-r*2.0f,y-r*.35f,x,y+r*.35f,p);c.drawOval(x,y-r*.35f,x+r*2f,y+r*.35f,p);c.drawCircle(x,y,r*.28f,p)}
    private fun glow(c:Canvas,x:Float,y:Float,r:Float,color:Int,alpha:Int){p.style=Paint.Style.FILL;p.shader=RadialGradient(x-r*.25f,y-r*.3f,r,Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color)),Color.TRANSPARENT,Shader.TileMode.CLAMP);c.drawCircle(x,y,r,p);p.shader=null}

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean { this.visible=visible; if(visible&&restart)invalidateSelf(); return super.setVisible(visible,restart) }
    override fun setAlpha(a:Int){p.alpha=a}
    override fun setColorFilter(f:ColorFilter?){p.colorFilter=f}
    override fun getOpacity()=PixelFormat.TRANSLUCENT
}
