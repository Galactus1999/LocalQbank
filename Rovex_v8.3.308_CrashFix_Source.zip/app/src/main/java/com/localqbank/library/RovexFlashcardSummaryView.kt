package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

/** Native Android equivalent of the supplied futuristic Flashcards analytical widget. */
class RovexFlashcardSummaryView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var cards=0; private var due=0; private var reviews=0
    fun setStats(total:Int,dueNow:Int,reviewCount:Int){cards=total.coerceAtLeast(0);due=dueNow.coerceAtLeast(0);reviews=reviewCount.coerceAtLeast(0);invalidate()}
    override fun onDraw(c:Canvas){
        val d=resources.displayMetrics.density;val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0)return
        val panel=if(ThemeManager.get(context)==ThemeManager.AMOLED)Color.rgb(24,27,34)else ThemeManager.panel(context);p.style=Paint.Style.FILL;p.color=panel;c.drawRoundRect(0f,0f,w,h,20*d,20*d,p)
        p.style=Paint.Style.STROKE;p.strokeWidth=1*d;p.color=Color.argb(42,79,231,226);for(i in 0..7){val path=Path();val y=52*d+i*9*d;path.moveTo(0f,y);var x=0f;while(x<=w*.72f){path.lineTo(x,y+sin(x/(20*d)+i)*5*d);x+=18*d};c.drawPath(path,p)}
        p.style=Paint.Style.FILL;p.color=ThemeManager.muted(context);p.textSize=9*d;p.isFakeBoldText=true;c.drawText("FLASHCARDS • PERFORMANCE",16*d,21*d,p);p.isFakeBoldText=false;p.color=ThemeManager.text(context);p.textSize=16*d;p.isFakeBoldText=true;c.drawText("Spaced repetition",16*d,43*d,p);p.isFakeBoldText=false;p.color=ThemeManager.muted(context);p.textSize=9*d;c.drawText("Imported decks • review load",16*d,58*d,p)
        val r=min(w,h)*.18f;val cx=w-52*d;val cy=42*d;p.style=Paint.Style.STROKE;p.strokeWidth=5*d;p.strokeCap=Paint.Cap.ROUND;p.color=Color.argb(35,255,255,255);c.drawCircle(cx,cy,r,p);val pct=if(cards>0)((cards-due).coerceIn(0,cards).toFloat()/cards)else 0f;p.color=Color.rgb(255,193,7);c.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,pct*360f,false,p);p.style=Paint.Style.FILL;p.textAlign=Paint.Align.CENTER;p.color=ThemeManager.text(context);p.textSize=9*d;p.isFakeBoldText=true;c.drawText("${(pct*100).roundToInt()}%",cx,cy+3*d,p);p.textAlign=Paint.Align.LEFT;p.isFakeBoldText=false
        p.color=ThemeManager.text(context);p.textSize=14*d;p.isFakeBoldText=true;c.drawText(cards.toString(),16*d,98*d,p);p.isFakeBoldText=false;p.color=ThemeManager.muted(context);p.textSize=9*d;c.drawText("cards total",16*d,112*d,p);c.drawText("$reviews reviews",130*d,112*d,p)
        p.color=if(due>0)Color.rgb(255,183,77)else Color.rgb(54,183,124);p.isFakeBoldText=true;p.textSize=10*d;c.drawText(if(due>0)"$due DUE NOW" else "UP TO DATE",16*d,139*d,p);p.isFakeBoldText=false;p.color=ThemeManager.muted(context);p.textSize=8.5f*d;c.drawText("Tap card to open flashcards",16*d,h-12*d,p)
    }
}