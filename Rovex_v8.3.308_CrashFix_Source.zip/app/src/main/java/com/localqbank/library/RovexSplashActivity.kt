package com.localqbank.library

import android.content.Intent
import android.os.Bundle
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/** Launcher-only splash. The QBank dashboard is the primary app surface. */
class RovexSplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        SystemUi.immersive(this)

        val splash = RovexSplashView(this)
        setContentView(splash)
        ProductionCrashReporter.stage(this, "SPLASH", "visible")
        splash.setOnFinished { openMain() }
        if(savedInstanceState==null){
            lifecycleScope.launch {
                val report=StartupHealthChecker().run(applicationContext)
                StartupHealthStore(applicationContext).save(report)
            }
        }

        // A recreation (for example, configuration change) should never trap the user
        // in the splash animation. The normal fresh launcher path still gets the full effect.
        if (savedInstanceState != null) splash.skipToEnd() else splash.start()
    }

    private fun openMain() {
        if (isFinishing || isDestroyed) return
        // The launcher must open the real Home dashboard. Section navigation is a secondary
        // surface reached from Home; opening QBank directly here makes Home effectively
        // disappear after a cold launch.
        ProductionCrashReporter.stage(this, "SPLASH", "opening_home_dashboard")
        startActivity(Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        })
        overridePendingTransition(0, 0)
        finish()
        overridePendingTransition(0, 0)
    }
}
