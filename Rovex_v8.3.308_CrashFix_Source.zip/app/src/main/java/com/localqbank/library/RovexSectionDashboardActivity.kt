package com.localqbank.library
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
class RovexSectionDashboardActivity:Activity(){
private lateinit var content:LinearLayout
private var active="qbank"
private var focusKind:String?=null
private var sectionGeneration=0L
private val sectionViews=HashMap<String,LinearLayout>()
private var renderTarget:LinearLayout?=null
private var renderedTheme:String?=null
private lateinit var navBar:LinearLayout
private lateinit var sectionScroll:ScrollView
private val sectionScrollY=HashMap<String,Int>()
private data class Row(
    val name:String,
    val total:Int,
    val solved:Int,
    val correct:Int,
    val testId:String="",
    val position:Int=0,
    val path:String="",
    val source:String="",
    val subject:String?=null,
    val kind:String?=null
){
    val accuracy:Int get()=if(solved==0)0 else correct*100/solved
    val mastery:Int get()=if(total==0)0 else solved*100/total
}
override fun onCreate(b:Bundle?){
    super.onCreate(b)
    focusKind=intent.getStringExtra("focusKind")?.takeIf{it.isNotBlank()}
    active=intent.getStringExtra("section")?.let{if(it=="cards")"flashcards" else it}
        ?.takeIf{it=="qbank"||it=="flashcards"||it=="mastery"||it=="tests"} ?: "qbank"
    renderedTheme=ThemeManager.get(this)
    buildShell()
    repaintNav()
    loadLiveData()
}

override fun onNewIntent(intent:Intent?){
    super.onNewIntent(intent)
    intent?:return
    setIntent(intent)
    focusKind=intent.getStringExtra("focusKind")?.takeIf{it.isNotBlank()}
    val requested=intent.getStringExtra("section")?.let{if(it=="cards")"flashcards" else it} ?: return
    if(requested!=active) switchSection(requested) else { sectionViews.clear(); render(snapshot ?: return); repaintNav() }
}
private fun isLandscape()=resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE
private fun buildShell(){
    val root=FrameLayout(this).apply{
        setBackgroundColor(ThemeManager.bg(this@RovexSectionDashboardActivity))
    }
    val scroll=ScrollView(this).apply{
        isFillViewport=true
        clipToPadding=false
        setPadding(0,0,0,if(isLandscape())d(58) else d(82))
    }
    sectionScroll=scroll
    content=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        setPadding(d(16),d(14),d(16),d(18))
    }
    scroll.addView(content)
    root.addView(scroll,FrameLayout.LayoutParams(-1,-1))
    root.addView(nav(),FrameLayout.LayoutParams(-1,if(isLandscape())d(44) else d(58),Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply{
        leftMargin=d(12);rightMargin=d(12);bottomMargin=d(12)
    })
    setContentView(root)
    RovexModernUi.applySection(root, this)
}

private data class DashboardSnapshot(
    val rows: List<Row>,
    val overall: Row,
    var cards: Triple<Int,Int,Int>? = null,
    val createdAt: Long = android.os.SystemClock.elapsedRealtime()
)

private var snapshot: DashboardSnapshot? = null
private var loadingData = false
private var loadingCards = false

private val canonicalSubjects = listOf(
    "Anatomy", "Physiology", "Biochemistry", "Pharmacology", "Pathology", "Microbiology",
    "Forensic Medicine", "Community Medicine / PSM", "General Medicine", "Dermatology",
    "Psychiatry", "Pediatrics", "Radiology", "Anesthesiology", "General Surgery",
    "Orthopedics", "ENT", "Ophthalmology", "Obstetrics & Gynecology"
)

private fun normalized(v: String): String = v
    .lowercase()
    .replace("&", " and ")
    .replace(Regex("[\\u2010-\\u2015\\u2212]"), "-")
    .replace(Regex("[^a-z0-9]+"), " ")
    .replace(Regex("\\s+"), " ")
    .trim()

private fun subjectHaystack(r: Row): String = normalized(listOf(r.path, r.name, r.source).joinToString(" "))

private fun hasAny(hay: String, vararg aliases: String): Boolean = aliases.any { alias ->
    val a=normalized(alias)
    Regex("(^| )${Regex.escape(a).replace("\\ ", "\\s+")}( |$)").containsMatchIn(hay)
}

private fun subjectFor(r:Row): String? {
    val hay = subjectHaystack(r)
    return when {
        Regex("\\b(anatomy|gross anatomy|embryology|histology|neuroanatomy)\\b").containsMatchIn(hay) -> "Anatomy"
        Regex("\\bphysiology\\b").containsMatchIn(hay) -> "Physiology"
        Regex("\\b(biochem|biochemistry)\\b").containsMatchIn(hay) -> "Biochemistry"
        Regex("\\b(pharmacology|pharmaco)\\b").containsMatchIn(hay) -> "Pharmacology"
        Regex("\\b(pathology|histopathology)\\b").containsMatchIn(hay) -> "Pathology"
        Regex("\\bmicrobiology\\b").containsMatchIn(hay) -> "Microbiology"
        Regex("\\b(forensic|toxicology|fmt)\\b").containsMatchIn(hay) -> "Forensic Medicine"
        Regex("\\b(community medicine|communitymedicine|psm|preventive and social medicine|preventive social medicine)\\b").containsMatchIn(hay) -> "Community Medicine / PSM"
        // Major QBanks use all of: General Medicine, Medicine, Internal Medicine,
        // Medicine & Allied, Medicine and Allied Subjects, Medicine Allied,
        // Respiratory Medicine and TB & Chest. Treat these as one canonical subject.
        Regex("\\b(general medicine|internal medicine|medicine and allied|medicine allied|medicine and allied subjects|medicine allied subjects|medical and allied|respiratory medicine|pulmonology|tb and chest|tb chest)\\b").containsMatchIn(hay) ||
            hasAny(hay, "medicine", "medicine & allied", "internal medicine") -> "General Medicine"
        Regex("\\b(dermatology|dvl|venereology)\\b").containsMatchIn(hay) -> "Dermatology"
        Regex("\\b(psychiatry|psychiatric)\\b").containsMatchIn(hay) -> "Psychiatry"
        Regex("\\b(pediatrics|paediatrics|paediatric|pediatric)\\b").containsMatchIn(hay) -> "Pediatrics"
        Regex("\\b(radiology|radiodiagnosis|radio diagnosis|radiodiagnostic)\\b").containsMatchIn(hay) -> "Radiology"
        Regex("\\b(anesthesiology|anaesthesiology|anesthesia|anaesthesia)\\b").containsMatchIn(hay) -> "Anesthesiology"
        // Surgery QBanks similarly vary between General Surgery, Surgery,
        // Surgery & Allied, Surgical Sciences and Surgery Allied.
        Regex("\\b(general surgery|surgery and allied|surgery allied|surgery and allied subjects|surgical sciences|surgical)\\b").containsMatchIn(hay) ||
            hasAny(hay, "surgery", "surgery & allied") -> "General Surgery"
        Regex("\\b(orthopedic|orthopaedic|orthopedics|orthopaedics)\\b").containsMatchIn(hay) -> "Orthopedics"
        Regex("(^| )ent( |$)|otorhinolaryngology|otolaryngology|ear nose throat").containsMatchIn(hay) -> "ENT"
        Regex("\\b(ophthalmology|ophthal|eye)\\b").containsMatchIn(hay) -> "Ophthalmology"
        Regex("\\b(obstetrics|gynaecology|gynecology|obgyn|obg)\\b").containsMatchIn(hay) -> "Obstetrics & Gynecology"
        else -> null
    }
}

private fun kindFor(r:Row): String {
    val hay = normalized(listOf(r.name, r.path, r.source).joinToString(" "))
    return when {
        Regex("\\bpyq\\b|previous year|previous year questions|previous-year").containsMatchIn(hay) -> "PYQ"
        Regex("\\bcustom\\b|customized|custom qbank").containsMatchIn(hay) -> "Custom"
        Regex("image test|image based test|image based questions|image-based test").containsMatchIn(hay) -> "Image Test"
        Regex("subject test|subject-wise test|subject wise test|subject test series").containsMatchIn(hay) -> "Subject Test"
        Regex("other test|grand test|mock test|test series|mixed test|full test").containsMatchIn(hay) -> "Other Test"
        else -> "QBank"
    }
}

private fun rowsForSubject(rows: List<Row>, subject: String): List<Row> = rows.filter { it.subject == subject }
private fun rowsForKind(rows: List<Row>, kind: String): List<Row> = rows.filter { it.kind == kind }

private fun switchSection(id:String){
    if(id!="qbank" && id!="flashcards" && id!="mastery" && id!="tests") return
    if(active==id){repaintNav();return}
    if(::sectionScroll.isInitialized) sectionScrollY[active]=sectionScroll.scrollY
    active=id
    sectionGeneration++
    repaintNav()
    val cached=snapshot
    if(cached!=null){
        render(cached)
        if(id=="flashcards" && cached.cards==null) loadFlashcards(sectionGeneration)
    }else{
        showSectionLoading()
        loadLiveData()
    }
}

private fun repaintNav(){if(!::navBar.isInitialized)return;for(i in 0 until navBar.childCount){(navBar.getChildAt(i) as? TextView)?.let{v->val id=v.tag?.toString().orEmpty();v.setTextColor(if(active==id)ThemeManager.accent(this) else ThemeManager.muted(this));v.background=if(active==id)android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.bg(this@RovexSectionDashboardActivity));cornerRadius=d(20).toFloat()} else null}}}

private fun loadLiveData(){
    if(snapshot!=null || loadingData) return
    loadingData=true
    PerformanceManager.submit{
        val rows=runCatching{
            val db=QBankDb(applicationContext)
            try {
                db.dashboardTestRows().map { r ->
                    val base=Row(r.name,r.total,r.solved,r.correct,r.testId,r.position,r.path,r.source)
                    base.copy(subject=subjectFor(base),kind=kindFor(base))
                }
            } finally { db.close() }
        }.getOrDefault(emptyList())
        val overall=Row("Main QBank",rows.sumOf{it.total},rows.sumOf{it.solved},rows.sumOf{it.correct})
        val next=DashboardSnapshot(rows,overall)
        runOnUiThread{
            loadingData=false
            if(!isFinishing&&!isDestroyed){
                snapshot=next
                sectionViews.clear()
                render(next)
                if(active=="flashcards") loadFlashcards(sectionGeneration)
            }
        }
    }
}

private fun showSectionLoading(){
    content.removeAllViews()
    val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(18),d(24),d(18),d(24))}
    box.addView(TextView(this).apply{
        text=when(active){"qbank"->"QBank";"tests"->"Subject Tests";"flashcards"->"Cards";else->"Mastery"}
        textSize=24f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))
    })
    box.addView(TextView(this).apply{
        text="Preparing cached study data…"
        textSize=12f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(6),0,0)
    })
    content.addView(box,LinearLayout.LayoutParams(-1,-2))
}

private fun loadFlashcards(token:Long=sectionGeneration){
    val s=snapshot ?: return
    if(s.cards!=null || loadingCards) return
    loadingCards=true
    PerformanceManager.submit{
        val cards=runCatching{SqliteFlashcardReviewRepository(applicationContext).use{Triple(it.modeCount("all"),it.reviewCount(),it.dueStatsAll().due)}}.getOrDefault(Triple(0,0,0))
        runOnUiThread{
            loadingCards=false
            if(!isFinishing&&!isDestroyed&&token==sectionGeneration&&snapshot===s){
                s.cards=cards
                render(s)
            }
        }
    }
}

private fun render(data:DashboardSnapshot){
    val cached=sectionViews[active]
    if(cached!=null){
        content.removeAllViews()
        renderTargetOrContent().addView(cached,LinearLayout.LayoutParams(-1,-2))
        return
    }
    val target=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
    val host=content
    renderTarget=target
    val cardData=data.cards ?: Triple(0,0,0)
    when(active){
        "qbank"->qbank(data.rows)
        "tests"->tests(data.rows)
        "flashcards"->cards(if(data.cards!=null) cardData else Triple(-1,-1,-1))
        "mastery"->mastery(data.rows,data.overall)
    }
    renderTarget=null
    // Do not cache the temporary Cards loading shell; the real flashcard counts replace it.
    if(active!="flashcards" || data.cards!=null) sectionViews[active]=target
    host.removeAllViews()
    host.addView(target,LinearLayout.LayoutParams(-1,-2))
    sectionScroll.post { sectionScroll.scrollTo(0,sectionScrollY[active] ?: 0) }
}

private fun renderTargetOrContent():LinearLayout = renderTarget ?: content

private fun title(a:String,b:String){
    renderTargetOrContent().addView(TextView(this).apply{text=a;textSize=25f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    renderTargetOrContent().addView(TextView(this).apply{text=b;textSize=12f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,0,0,d(14))})
}
private fun section(x:String){renderTargetOrContent().addView(TextView(this).apply{text=x.uppercase();textSize=10f;letterSpacing=.12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(2,d(12),0,d(7))})}
private fun panel():android.graphics.drawable.Drawable=android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.panel(this@RovexSectionDashboardActivity));cornerRadius=d(22).toFloat()}
private fun card(t:String,s:String,a:Int,act:String,go:()->Unit){
    val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(15),d(16),d(13));background=panel()}
    b.addView(TextView(this).apply{text=t;textSize=16f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    b.addView(TextView(this).apply{text=s;textSize=11.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,d(5))})
    b.addView(TextView(this).apply{text=act.uppercase();textSize=10f;setTypeface(null,Typeface.BOLD);setTextColor(a);gravity=Gravity.CENTER_VERTICAL;setPadding(0,d(4),0,0);setOnClickListener{go()}})
    renderTargetOrContent().addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(8)})
}
private fun progress(r:Row,index:Int){
    val fill=ThemeManager.pastelAccentFill(this,index);val fg=ThemeManager.pastelAccentText(this,index)
    val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(14),d(12),d(14),d(11));background=android.graphics.drawable.GradientDrawable().apply{setColor(fill);cornerRadius=d(17).toFloat()};isClickable=true;isFocusable=true;setOnClickListener{if(r.testId.isNotBlank())startActivity(Intent(this@RovexSectionDashboardActivity,QuizActivity::class.java).apply{putExtra("testId",r.testId);putExtra("title",r.name);putExtra("position",r.position);putExtra("sectionLabel",r.path);putExtra("practiceMode",true)})}}
    val line=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
    line.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.name;textSize=14f;setTypeface(null,Typeface.BOLD);setTextColor(fg)},LinearLayout.LayoutParams(0,-2,1f))
    line.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.mastery.toString()+"%";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(fg)})
    b.addView(line)
    b.addView(TextView(this).apply{text=r.path+"  •  "+r.solved.toString()+"/"+r.total+" solved  •  "+r.accuracy+"% accuracy";textSize=10.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(3),0,d(5))})
    b.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{progress=r.mastery;progressTintList=android.content.res.ColorStateList.valueOf(fg)})
    renderTargetOrContent().addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(6)})
}

private fun subjectKey(r:Row):String{
    val raw=r.path.trim()
    return raw.split(">", "/", "::").firstOrNull()?.trim().orEmpty().ifBlank{"General"}
}
private fun subjectRows(rows:List<Row>):List<Row> = rows.sortedBy{it.name.lowercase()}
private fun subjectGroups(rows:List<Row>):List<Pair<String,List<Row>>>{
    return rows.groupBy{subjectKey(it)}.toList().sortedBy{it.first.lowercase()}
}
private fun subjectCategoryBox(label:String,allItems:List<Row>,index:Int){
    val total=allItems.sumOf{it.total}; val solved=allItems.sumOf{it.solved}; val correct=allItems.sumOf{it.correct}
    val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(d(8),d(7),d(8),d(2))}
    val shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(14),d(13),d(14),d(12));background=panel()}
    val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
    val arrow=TextView(this).apply{text="›";textSize=23f;gravity=Gravity.CENTER;setTextColor(ThemeManager.pastelAccentText(this@RovexSectionDashboardActivity,index))}
    head.addView(TextView(this).apply{text=label;textSize=16f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))},LinearLayout.LayoutParams(0,-2,1f))
    head.addView(TextView(this).apply{text=allItems.size.toString()+" QBanks";textSize=10f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,0,d(8),0)})
    head.addView(TextView(this).apply{text=total.toString()+" Q";textSize=11f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.pastelAccentText(this@RovexSectionDashboardActivity,index))})
    head.addView(arrow,LinearLayout.LayoutParams(d(28),d(28)))
    shell.addView(head)
    shell.addView(TextView(this).apply{text=solved.toString()+" solved • "+(if(solved==0)0 else correct*100/solved)+"% accuracy";textSize=10.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,0)})
    shell.addView(wrap)
    var populated=false
    head.setOnClickListener{
        val open=wrap.visibility!=View.VISIBLE
        if(open && !populated){
            val kinds=focusKind?.let{listOf(it)} ?: listOf("QBank","PYQ","Custom","Subject Test","Image Test","Other Test")
            kinds.forEachIndexed { kindIndex, kind ->
                val items=allItems.filter { it.kind==kind }
                wrap.addView(TextView(this).apply{
                    text=kind.uppercase()+"  •  "+items.size+" QBANKS"
                    textSize=9.5f;letterSpacing=.08f;setTypeface(null,Typeface.BOLD)
                    setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(d(4),d(10),0,d(5))
                })
                if(items.isEmpty()){
                    wrap.addView(TextView(this).apply{
                        text="No imported items in this category"
                        textSize=10.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(d(4),0,0,d(5))
                    })
                } else {
                    items.sortedWith(compareBy<Row>{it.position}.thenBy{it.name.lowercase()}).forEachIndexed{ci,r->progressInto(wrap,r,ci+kindIndex)}
                }
            }
            populated=true
        }
        wrap.visibility=if(open)View.VISIBLE else View.GONE
        arrow.text=if(open)"⌄" else "›"
    }
    renderTargetOrContent().addView(shell,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(8)})
}

private fun unassignedCollectionBox(label:String,items:List<Row>,index:Int){
    if(items.isEmpty()) return
    subjectCategoryBox(label,items,index)
}

private fun progressInto(parent:ViewGroup,r:Row,index:Int){
    val fg=ThemeManager.pastelAccentText(this,index);val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(13),d(10),d(13),d(9));background=panel();isClickable=r.testId.isNotBlank();setOnClickListener{if(r.testId.isNotBlank())startActivity(Intent(this@RovexSectionDashboardActivity,QuizActivity::class.java).apply{putExtra("testId",r.testId);putExtra("title",r.name);putExtra("position",r.position);putExtra("sectionLabel",r.path);putExtra("practiceMode",true)})}}
    b.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.name;textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    b.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.solved.toString()+" / "+r.total+" solved • "+r.accuracy+"% accuracy";textSize=10f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(3),0,d(5))})
    b.addView(ProgressBar(this@RovexSectionDashboardActivity,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=r.mastery;progressTintList=android.content.res.ColorStateList.valueOf(fg)})
    parent.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(5)})
}

private fun qbank(rows:List<Row>){
    title("QBank","19 subjects with QBank / PYQ / Custom / test categories")
    analyticsHero(rows)
    section("19 SUBJECTS")
    canonicalSubjects.forEachIndexed{i,subject->subjectCategoryBox(subject,rowsForSubject(rows,subject),i)}
    section("CROSS-SUBJECT / UNASSIGNED COLLECTIONS")
    listOf("PYQ","Custom","Subject Test","Image Test","Other Test").forEachIndexed{i,label->
        val items=rows.filter { it.subject==null && it.kind==label }
        unassignedCollectionBox(label,items,canonicalSubjects.size+i)
    }
}

private fun analyticsHero(rows: List<Row>) {
    // Stats is intentionally removed from bottom navigation. Keep this legacy helper
    // as a no-op so stale internal references cannot reintroduce the removed UI.
}

private fun tests(rows:List<Row>){
    title("Subject Tests","Combined subject-wise Subject Test collections across the 19 canonical subjects")
    section("19 SUBJECTS • SUBJECT TESTS")
    canonicalSubjects.forEachIndexed{i,subject->
        subjectCategoryBox(subject,rowsForSubject(rows,subject).filter{it.kind=="Subject Test"},i)
    }
    val unassigned=rows.filter{it.subject==null && it.kind=="Subject Test"}
    if(unassigned.isNotEmpty()){
        section("UNASSIGNED SUBJECT TESTS")
        subjectCategoryBox("Unassigned",unassigned,canonicalSubjects.size)
    }
}

private fun cards(c:Triple<Int,Int,Int>){
    title("Cards","Flashcards • retention • review")
    val due=c.third
    val total=c.first
    val reviews=c.second
    val retention=if(reviews==0)0 else ((reviews-due).coerceAtLeast(0)*100/reviews)
    val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(16),d(16),d(14));background=panel()}
    hero.addView(TextView(this).apply{text="Flashcard Overview";textSize=12f;letterSpacing=.12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity))})
    hero.addView(TextView(this).apply{text="$total cards • $retention% retention";textSize=20f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,d(2))})
    hero.addView(TextView(this).apply{text="$due due today • $reviews reviews recorded";textSize=11f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity))})
    val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=if(total==0)0 else ((total-due).coerceAtLeast(0)*100/total);progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(this@RovexSectionDashboardActivity))}
    hero.addView(bar,LinearLayout.LayoutParams(-1,d(6)).apply{topMargin=d(12)})
    val open=TextView(this).apply{text="▶  Review Flashcards";gravity=Gravity.CENTER;textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.bg(this@RovexSectionDashboardActivity));background=android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.accent(this@RovexSectionDashboardActivity));cornerRadius=d(22).toFloat()};setPadding(0,d(11),0,d(11));setOnClickListener{startActivity(Intent(this@RovexSectionDashboardActivity,FlashcardActivity::class.java))}}
    hero.addView(open,LinearLayout.LayoutParams(-1,d(46)).apply{topMargin=d(12)});renderTargetOrContent().addView(hero,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(10)})
    section("REVIEW")
    card("Due today","$due cards are currently due according to the flashcard scheduler.",ThemeManager.pastelAccentText(this,1),"REVIEW"){startActivity(Intent(this,FlashcardActivity::class.java))}
    card("Study tools","Create, import and review cards using the existing flashcard workflow.",ThemeManager.accent(this),"OPEN TOOLS"){startActivity(Intent(this,FlashcardActivity::class.java))}
}

private fun mastery(rows:List<Row>,o:Row){
    title("Mastery","Retention • coverage • 19-subject progress")
    card("Overall QBank Mastery",o.mastery.toString()+"% of imported questions have been attempted at least once.",ThemeManager.accent(this),"OPEN QBANK"){switchSection("qbank")}
    section("SUBJECT MASTERY")
    canonicalSubjects.forEachIndexed{i,subject->
        val items=rowsForSubject(rows,subject)
        val total=items.sumOf{it.total};val solved=items.sumOf{it.solved};val correct=items.sumOf{it.correct}
        val r=Row(subject,total,solved,correct)
        progress(r,i)
    }
}

private fun nav():View{
    val l=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER
        setPadding(d(5),if(isLandscape())d(3) else d(5),d(5),if(isLandscape())d(3) else d(5))
        background=android.graphics.drawable.GradientDrawable().apply{
            setColor(ThemeManager.elevated(this@RovexSectionDashboardActivity))
            cornerRadius=d(30).toFloat()
        }
        elevation=d(12).toFloat()
    }
    navBar=l
    listOf("qbank" to "QBank","flashcards" to "Cards","mastery" to "Mastery").forEach{(id,label)->
        val item=TextView(this).apply{
            tag=id
            text=label
            gravity=Gravity.CENTER
            textSize=10.5f
            setTypeface(null,Typeface.BOLD)
            setPadding(d(9),0,d(9),0)
            setOnClickListener{switchSection(id)}
        }
        l.addView(item,LinearLayout.LayoutParams(0,-1,1f).apply{setMargins(d(2),0,d(2),0)})
    }
    repaintNav()
    return l
}

private val swipeDetector by lazy { RovexSectionSwipeDetector(this){ direction ->
    val order=listOf("qbank","flashcards","mastery")
    val i=order.indexOf(active).coerceAtLeast(0)
    switchSection(order[(i + direction + order.size)%order.size])
} }

override fun dispatchTouchEvent(ev:android.view.MotionEvent):Boolean{
    if(swipeDetector.onTouchEvent(ev)) return true
    return super.dispatchTouchEvent(ev)
}

override fun onResume(){
    super.onResume()
    if(!::content.isInitialized)return
    window.decorView.post {
        if(isFinishing || isDestroyed)return@post
        val theme=ThemeManager.get(this)
        if(theme!=renderedTheme){
            renderedTheme=theme
            sectionViews.clear()
            snapshot?.let { render(it) }
        }
        (content.parent as? ScrollView)?.setPadding(0,0,0,if(isLandscape())d(58) else d(82))
        renderThemeChrome()
    }
}
private fun renderThemeChrome(){
    if(!::navBar.isInitialized)return
    val accent=ThemeManager.accent(this@RovexSectionDashboardActivity)
    val dark=ThemeManager.isDark(this@RovexSectionDashboardActivity)
    navBar.background=android.graphics.drawable.GradientDrawable().apply{
        setColor(ThemeManager.elevated(this@RovexSectionDashboardActivity))
        cornerRadius=d(30).toFloat()
        setStroke(d(1),Color.argb(if(dark)120 else 95,Color.red(accent),Color.green(accent),Color.blue(accent)))
    }
    for(i in 0 until navBar.childCount){
        val v=navBar.getChildAt(i) as? TextView ?: continue
        val id=v.tag?.toString().orEmpty()
        val on=id==active
        v.setTextColor(if(on) accent else ThemeManager.muted(this@RovexSectionDashboardActivity))
        v.background=if(on) android.graphics.drawable.GradientDrawable().apply{
            setColor(ThemeManager.bg(this@RovexSectionDashboardActivity))
            cornerRadius=(22 * this@RovexSectionDashboardActivity.resources.displayMetrics.density)
            setStroke(d(1),accent)
        } else null
    }
}

private fun d(x:Int)=(x*resources.displayMetrics.density).toInt()
}