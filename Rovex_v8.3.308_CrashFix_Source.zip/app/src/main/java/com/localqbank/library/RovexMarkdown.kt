package com.localqbank.library

import android.text.Html
import android.text.Spanned

/** Dependency-free presentation helpers. WebView is used only for rich, local chat layout. */
fun rovexMarkdownToSpanned(raw: String): Spanned {
    // IMPORTANT: Html.fromHtml() backs a plain TextView, not a browser engine. Android's
    // legacy parser has no real notion of <head>/<style> — it has no handler for <style>
    // the way it does for <script>, so a full document wrapper gets its raw CSS text
    // dumped straight into the visible Spanned output. Only ever hand it the body
    // fragment. The full document (rovexMarkdownToHtml) is for WebView consumers only.
    return Html.fromHtml(rovexMarkdownBody(raw), Html.FROM_HTML_MODE_LEGACY)
}

/** Full standalone HTML document — for WebView.loadDataWithBaseURL() only. Never pass this to Html.fromHtml(). */
fun rovexMarkdownToHtml(raw: String): String = wrapMarkdownDocument(rovexMarkdownBody(raw))

/** The rendered body fragment (a `<p>…</p>` tree), with no doctype/html/head/style wrapper. Safe for both Html.fromHtml() and WebView body injection. */
fun rovexMarkdownBody(raw: String): String {
    var s = raw.replace("\r\n", "\n").replace("\r", "\n")
        .replace(Regex("(?i)&lt;\\s*br\\s*/?\\s*&gt;"), "\n")
        .replace(Regex("(?i)<\\s*br\\s*/?\\s*>"), "\n")
        .replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        .replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
        .replace(Regex("(?is)<iframe[^>]*>.*?</iframe>"), "")
        .replace(Regex("(?is)<object[^>]*>.*?</object>"), "")
        .replace(Regex("(?is)<embed[^>]*>.*?</embed>"), "")
        .replace(Regex("(?i)on[a-z]+\\s*=\\s*(['\"]).*?\\1"), "")

    // Protect fenced code before table recovery. This prevents a code sample containing pipes
    // or dashed separators from being mistaken for a Markdown table.
    val codeTokens = ArrayList<String>()
    s = s.replace(Regex("(?s)```(?:[a-zA-Z0-9_+.-]+)?\\n(.*?)```")) { m ->
        val token = "@@ROVEX_CODE_${codeTokens.size}@@"
        codeTokens += "<pre>${android.text.TextUtils.htmlEncode(m.groupValues[1])}</pre>"
        token
    }

    // AI providers occasionally wrap a Markdown separator across a visual/newline boundary or
    // accidentally concatenate it with the next row. Collapse whitespace *inside* separator
    // candidates and then split embedded separators into real rows. This repairs common output
    // such as `| Topic | Details | |-------|------|| Drug class |` without treating ordinary prose
    // containing a single pipe as a table.
    val separatorCandidate = Regex("\\|[-:\\s|]{3,}\\|")
    s = separatorCandidate.replace(s) { m -> m.value.replace(Regex("\\s+"), "") }
    val embeddedSeparator = Regex("\\|\\s*:?-{3,}:?\\s*(?:\\|\\s*:?-{3,}:?\\s*)+\\|?")
    s = embeddedSeparator.replace(s) { m -> "\n${m.value}\n" }

    val imageTokens = ArrayList<String>()
    s = s.replace(Regex("!\\[([^\\]]{0,240})\\]\\((https://[^\\s)]+|data:image/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=]+)\\)")) { m ->
        val token = "@@ROVEX_IMAGE_${imageTokens.size}@@"
        val alt = android.text.TextUtils.htmlEncode(m.groupValues[1]).replace("\"", "")
        val src = m.groupValues[2].replace("\"", "&quot;")
        imageTokens += "<img src=\"$src\" alt=\"$alt\">"
        token
    }

    val tableTokens = ArrayList<String>()
    val lines = s.split('\n')
    val pre = StringBuilder()
    var i = 0

    fun splitCells(line: String): List<String> =
        line.trim().trim('|').split('|').map { it.trim() }

    fun isSeparator(line: String): Boolean {
        val cells = splitCells(line)
        return cells.size >= 2 && cells.all { it.matches(Regex(":?-{3,}:?")) }
    }

    fun inlineCell(cell: String): String {
        var x = android.text.TextUtils.htmlEncode(cell)
        x = x.replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("~~(.+?)~~", RegexOption.DOT_MATCHES_ALL), "<del>$1</del>")
            .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
            .replace(Regex("`([^`\\n]+?)`"), "<code>$1</code>")
            .replace(Regex("\\[([^\\]]+)]\\((https://[^\\s)]+)\\)"), "<a href=\"$2\">$1</a>")
        return x
    }

    while (i < lines.size) {
        if (i + 1 < lines.size && lines[i].count { it == '|' } >= 2 && isSeparator(lines[i + 1])) {
            val token = "@@ROVEX_TABLE_${tableTokens.size}@@"
            val header = splitCells(lines[i])
            val rows = ArrayList<List<String>>()
            i += 2
            while (i < lines.size && lines[i].count { it == '|' } >= 2 && lines[i].trim().isNotBlank()) {
                if (isSeparator(lines[i])) { i++; continue }
                rows += splitCells(lines[i]); i++
            }
            val columnCount = header.size.coerceAtLeast(rows.maxOfOrNull { it.size } ?: 0).coerceAtMost(12)
            val html = StringBuilder("<div class=\"table-wrap\"><table><thead><tr>")
            header.take(columnCount).forEach { html.append("<th>").append(inlineCell(it)).append("</th>") }
            html.append("</tr></thead><tbody>")
            rows.take(80).forEach { cells ->
                html.append("<tr>")
                for (c in 0 until columnCount) html.append("<td>").append(inlineCell(cells.getOrNull(c).orEmpty())).append("</td>")
                html.append("</tr>")
            }
            html.append("</tbody></table></div>")
            tableTokens += html.toString()
            pre.append(token).append('\n')
        } else {
            pre.append(lines[i]).append('\n'); i++
        }
    }

    s = android.text.TextUtils.htmlEncode(pre.toString())
    codeTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_CODE_$index@@", html) }
    imageTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_IMAGE_$index@@", html) }
    tableTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_TABLE_$index@@", html) }

    s = s.replace(Regex("(?m)^######\\s+(.+)$"), "<h6>$1</h6>")
        .replace(Regex("(?m)^#####\\s+(.+)$"), "<h5>$1</h5>")
        .replace(Regex("(?m)^####\\s+(.+)$"), "<h4>$1</h4>")
        .replace(Regex("(?m)^###\\s+(.+)$"), "<h3>$1</h3>")
        .replace(Regex("(?m)^##\\s+(.+)$"), "<h2>$1</h2>")
        .replace(Regex("(?m)^#\\s+(.+)$"), "<h1>$1</h1>")
        .replace(Regex("(?m)^>\\s?(.+)$"), "<blockquote>$1</blockquote>")
        .replace(Regex("(?m)^[-*+]\\s+"), "• ")
        .replace(Regex("(?m)^(\\d+)[.)]\\s+"), "$1. ")
        .replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("~~(.+?)~~", RegexOption.DOT_MATCHES_ALL), "<del>$1</del>")
        .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
        .replace(Regex("`([^`\\n]+?)`"), "<code>$1</code>")
        .replace(Regex("\\[([^\\]]+)]\\((https://[^\\s)]+)\\)"), "<a href=\"$2\">$1</a>")

    val blocks = Regex("(@@ROVEX_TABLE_\\d+@@|<div class=\"table-wrap\">.*?</div>|<img\\s[^>]*>|<pre>.*?</pre>)", setOf(RegexOption.DOT_MATCHES_ALL))
    val protectedBlocks = ArrayList<String>()
    s = s.replace(blocks) { m ->
        val token = "@@ROVEX_BLOCK_${protectedBlocks.size}@@"; protectedBlocks += m.value; token
    }

    // Keep block-level tables/images/code OUTSIDE paragraph elements. A previous implementation
    // replaced the protected token after wrapping the whole document in <p>, producing invalid
    // <p><div>… HTML that Chromium could relocate or drop.
    val blockPattern = Regex("@@ROVEX_BLOCK_(\\d+)@@")
    val bodyOut = StringBuilder()
    var cursor = 0
    blockPattern.findAll(s).forEach { match ->
        val textPart = s.substring(cursor, match.range.first)
        if (textPart.isNotBlank()) {
            bodyOut.append("<p>")
                .append(textPart.trim().replace(Regex("\\n{2,}"), "</p><p>").replace("\n", "<br>"))
                .append("</p>")
        }
        bodyOut.append(protectedBlocks[match.groupValues[1].toInt()])
        cursor = match.range.last + 1
    }
    val tail = s.substring(cursor)
    if (tail.isNotBlank()) {
        bodyOut.append("<p>")
            .append(tail.trim().replace(Regex("\\n{2,}"), "</p><p>").replace("\n", "<br>"))
            .append("</p>")
    }
    return bodyOut.toString()
}

private fun wrapMarkdownDocument(body: String): String = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>body{font-family:sans-serif;font-size:16px;line-height:1.52;margin:0;padding:2px;color:#EAF1F7}h1{font-size:25px;margin:8px 0}h2{font-size:21px;margin:16px 0 7px}h3{font-size:18px;margin:14px 0 6px}h4{font-size:16px;margin:12px 0 5px}p{margin:8px 0}blockquote{margin:10px 0;padding:9px 12px;border-left:4px solid #61B7FF;background:#182936;border-radius:8px}code,pre{background:#17232D;border-radius:8px;padding:2px 5px}pre{padding:10px;overflow:auto}.table-wrap{width:100%;max-width:100%;overflow-x:auto;overflow-y:hidden;margin:12px 0;padding-bottom:2px;overscroll-behavior-x:contain;-webkit-overflow-scrolling:touch;scrollbar-gutter:stable}table{border-collapse:collapse;margin:0;background:#13212B;width:auto;min-width:100%;max-width:none;table-layout:auto}th,td{box-sizing:border-box;border:1px solid #334A5A;padding:8px 9px;text-align:left;vertical-align:top;min-width:96px;max-width:280px;overflow-wrap:anywhere;word-break:normal}th{background:#1C3445;color:#B9F4EF;white-space:normal}mark{background:#6B5520;color:#FFF2B0;padding:1px 4px;border-radius:4px}.card{background:#13212B;border:1px solid #2C4352;border-radius:14px;padding:12px;margin:10px 0}.label{font-size:12px;color:#8FCBFF;text-transform:uppercase;letter-spacing:.08em;font-weight:700}.answer{font-size:19px;font-weight:700;color:#62D7A1}img{display:block;max-width:100%;height:auto;max-height:520px;object-fit:contain;border-radius:10px;margin:10px auto;background:#0D151B}a{color:#7FCBFF}table{overflow-wrap:anywhere}</style></head><body>$body</body></html>"""
