from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
policy=(root/'app/src/main/java/com/localqbank/library/BenResponsePolicy.kt').read_text()
ren=(root/'app/src/main/java/com/localqbank/library/RenActivity.kt').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'no_old_lookbehind': '(?<=})' not in policy,
 'lazy_regexes': 'by lazy(LazyThreadSafetyMode.PUBLICATION)' in policy,
 'safe_regex_constructor': 'fun safeRegex(' in policy,
 'normalize_fallback': 'BenResponsePolicy fallback' in policy,
 'ren_fallback': 'cleanAiAnswer fallback' in ren,
 'runtime_identity_marker': 'REN_POLICY=${BenResponsePolicy.POLICY_REVISION}' in ren,
 'version_current': 'versionName = "8.3.304"' in gradle and 'versionCode = 398' in gradle,
}
for k,v in checks.items(): print(('PASS ' if v else 'FAIL ')+k)
if not all(checks.values()): sys.exit(1)
