from pathlib import Path
import re
root=Path(".")
hits=[]
for p in (root/"app"/"src"/"main").rglob("*"):
    if not p.is_file() or p.suffix.lower() not in {".kt",".java",".xml"}: continue
    s=p.read_text(encoding="utf-8",errors="ignore")
    for i,line in enumerate(s.splitlines(),1):
        if re.search(r'(setTextColor|textColor|foregroundTint|iconTint|tint)[^\n]*(?:Color\.BLACK|#000000|#000)',line,re.I):
            hits.append(f"{p}:{i}:{line.strip()}")
print("AMOLED_FOREGROUND_AUDIT")
print("hard-coded black foreground candidates:",len(hits))
for h in hits[:200]: print(h)
