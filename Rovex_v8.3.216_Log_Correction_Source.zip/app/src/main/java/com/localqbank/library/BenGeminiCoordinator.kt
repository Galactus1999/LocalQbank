package com.localqbank.library

import android.content.Context
import com.google.firebase.Firebase
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.Tool
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Cloud research collaborator. Local Ben remains authoritative for local retrieval and study state. */
class BenGeminiCoordinator(context: Context) {
    data class Source(val title: String, val uri: String)
    data class Result(val answer: String, val sources: List<Source>, val grounded: Boolean, val signedInEmail: String?, val searchEntryPointHtml: String? = null)
    private val app = context.applicationContext

    fun auth(): FirebaseAuth? = runCatching {
        if (FirebaseAppAvailability.ensureInitialized(app) != null) FirebaseAuth.getInstance() else null
    }.getOrNull()

    suspend fun research(query: String): Result = withContext(Dispatchers.IO) {
        val clean = BenResearchInputPolicy.normalize(query)
            ?: return@withContext Result("Give Ben a concrete research question.", emptyList(), false, auth()?.currentUser?.email)
        val firebaseAuth = auth()
            ?: return@withContext Result("Gemini is not configured. Add Firebase configuration and enable Google sign-in.", emptyList(), false, null)
        val user = firebaseAuth.currentUser
            ?: return@withContext Result("Sign in with your Google account before using Gemini web research.", emptyList(), false, null)

        val local = runCatching { AppManagers.benBrain.answer(clean) }.getOrNull()
        val localContext = buildString {
            append("Ben local context. Supporting context only; it is not current web evidence.\n")
            if (local != null) {
                append("Local intent: ").append(local.plan.intent ?: "general").append('\n')
                append("Local concepts: ").append(local.plan.concepts.joinToString(", ")).append('\n')
                append("Local specialist: ").append(local.plan.specialist).append('\n')
                append("Local confidence: ").append(local.confidence).append("/100\n")
                append("Local answer: ").append(local.answer.take(3500)).append('\n')
            }
        }
        val model = Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = MODEL,
            tools = listOf(Tool.googleSearch(), Tool.urlContext())
        )
        val prompt = """
You are Gemini, the web-research collaborator inside Ben (Dr. Frankenstein).
The user explicitly requested current web research.
Use Google Search when current or externally verifiable information matters. Prefer primary/official sources,
major medical organizations, peer-reviewed literature, and authoritative guidelines. Distinguish established
facts from uncertainty and conflicting evidence. Do not blindly accept Ben's local context. Return a concise, source-grounded synthesis that Ben can verify and present.
For every externally verifiable claim, cite the supporting web source using [1], [2], etc.
Keep citations adjacent to the claim they support. Never fabricate a citation number.
When a search result points to a primary/official page that needs deeper reading, use URL context.

$localContext
RESEARCH QUESTION:
$clean
""".trimIndent()
        val response = model.generateContent(prompt)
        val geminiText = response.text?.trim().orEmpty().ifBlank { "Gemini returned no textual result." }
        val metadata = response.candidates.firstOrNull()?.groundingMetadata
        val groundingChunks = metadata?.groundingChunks.orEmpty()
        val sources = groundingChunks.mapNotNull { chunk ->
            val web = chunk.web ?: return@mapNotNull null
            val uri = web.uri?.trim().orEmpty()
            val title = web.title?.trim().orEmpty().ifBlank { uri }
            if (uri.isBlank()) null else Source(title, uri)
        }.distinctBy { it.uri }.take(12)
        val externalEvidence = metadata?.groundingSupports.orEmpty()
            .flatMap { support ->
                support.groundingChunkIndices.mapNotNull { sourceIndex ->
                    val chunk = groundingChunks.getOrNull(sourceIndex)?.web ?: return@mapNotNull null
                    val uri = chunk.uri?.trim().orEmpty()
                    val title = chunk.title?.trim().orEmpty().ifBlank { uri }
                    if (uri.isBlank()) null else BenAnswerVerifier.EvidenceItem(
                        index = sourceIndex + 1,
                        text = "${title.take(220)} — ${support.segment.text.take(900)}"
                    )
                }
            }
            .distinctBy { it.index }
            .take(12)
        // Frankenstein remains the final local gate/orchestrator: Gemini supplies current
        // external research, while grounding evidence is converted into verifier-readable
        // evidence items. Web evidence never becomes QBank truth or study-state authority.
        val benFinal = runCatching {
            AppManagers.benBrain.answer(
                clean,
                baseAnswer = geminiText,
                modelUsed = true,
                evidence = externalEvidence
            )
        }.getOrNull()
        val finalText = benFinal?.answer?.takeIf { it.isNotBlank() } ?: geminiText
        Result(finalText, sources, sources.isNotEmpty(), user.email, metadata?.searchEntryPoint?.renderedContent)
    }

    companion object { const val MODEL = "gemini-3.7-flash" }
}

object FirebaseAppAvailability {
    fun isConfigured(context: Context): Boolean = ensureInitialized(context) != null

    @Synchronized
    fun ensureInitialized(context: Context): com.google.firebase.FirebaseApp? = runCatching {
        val app = com.google.firebase.FirebaseApp.getApps(context).firstOrNull()
            ?: com.google.firebase.FirebaseApp.initializeApp(context)
            ?: return@runCatching null
        // Firebase may be initialized by FirebaseInitProvider before Ben is first used.
        // App Check therefore must not be installed only on the manual-initialization path.
        // Install once per process and keep the provider out of the application startup path.
        if (!appCheckInstalled) {
            if (com.localqbank.library.BuildConfig.DEBUG) {
                FirebaseAppCheck.getInstance(app).installAppCheckProviderFactory(
                    com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory.getInstance()
                )
            } else {
                FirebaseAppCheck.getInstance(app).installAppCheckProviderFactory(
                    com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory.getInstance()
                )
            }
            appCheckInstalled = true
        }
        app
    }.getOrNull()

    @Volatile private var appCheckInstalled = false
}
