package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebView
import android.view.View
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Chat-first Dr. Frankenstein workspace. Detailed diagnostics live in Model Lab / Adaptive Engine. */
class RenActivity : Activity() {
    private var openMatchButton: TextView? = null
    private var liveStatus: TextView? = null
    private val liveScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var liveJob: Job? = null
    private var geminiJob: Job? = null
    private var geminiSearchEntry: WebView? = null
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(build())
    }

    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            background=ThemeManager.backgroundDrawable(this@RenActivity)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(42), dp(48)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6),0,dp(6),0) }
        titleBox.addView(TextView(this).apply { text="Dr. Frankenstein"; textSize=22f; typeface=Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RenActivity)) })
        titleBox.addView(TextView(this).apply { text="Local study intelligence"; textSize=11f; setTextColor(ThemeManager.muted(this@RenActivity)) })
        header.addView(titleBox, LinearLayout.LayoutParams(0,-2,1f))
        val lab = TextView(this).apply {
            text = "MODEL LAB"; textSize=10.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); background=rounded(ThemeManager.elevated(this@RenActivity),12)
            setPadding(dp(10),0,dp(10),0); setOnClickListener { startActivity(Intent(this@RenActivity, BenModelLabActivity::class.java)) }
        }
        header.addView(lab, LinearLayout.LayoutParams(dp(96),dp(48)))
        root.addView(header)

        val modelPill = TextView(this).apply {
            text = modelStatus(); textSize=11f; gravity=Gravity.CENTER_VERTICAL
            setTextColor(ThemeManager.muted(this@RenActivity)); setPadding(dp(10),0,dp(10),0)
            background=rounded(ThemeManager.elevated(this@RenActivity),11)
        }
        root.addView(modelPill, LinearLayout.LayoutParams(-1,dp(34)).apply{setMargins(dp(4),dp(4),dp(4),dp(8))})

        val answerScroll = ScrollView(this).apply { isFillViewport=true; clipToPadding=false }
        val answer = TextView(this).apply {
            text="Ask anything about your QBank, a medical concept, an explanation, or your study plan."
            textSize=16f; setTextColor(ThemeManager.text(this@RenActivity)); setPadding(dp(16),dp(16),dp(16),dp(18))
            background=rounded(ThemeManager.elevated(this@RenActivity),18)
            gravity=Gravity.TOP
        }
        answerScroll.addView(answer, android.widget.FrameLayout.LayoutParams(-1,-2))
        root.addView(answerScroll, LinearLayout.LayoutParams(-1,0,1f))
        geminiSearchEntry=WebView(this).apply{
            visibility=View.GONE
            setBackgroundColor(ThemeManager.elevated(this@RenActivity))
            settings.javaScriptEnabled=false
            settings.domStorageEnabled=false
            setPadding(dp(4),dp(2),dp(4),dp(2))
        }
        root.addView(geminiSearchEntry,LinearLayout.LayoutParams(-1,dp(92)).apply{setMargins(dp(4),0,dp(4),dp(4))})

        liveStatus = TextView(this).apply {
            text="BEN • READY"; textSize=10.5f; setTextColor(ThemeManager.muted(this@RenActivity)); setPadding(dp(4),dp(5),dp(4),dp(5))
        }
        root.addView(liveStatus, LinearLayout.LayoutParams(-1,dp(28)))

        val input = EditText(this).apply {
            hint="Ask Dr. Frankenstein…"; textSize=15f; setTextColor(ThemeManager.text(this@RenActivity)); setHintTextColor(ThemeManager.muted(this@RenActivity))
            setSingleLine(false); minLines=2; maxLines=5; gravity=Gravity.TOP; setPadding(dp(14),dp(12),dp(14),dp(12))
            background=rounded(ThemeManager.elevated(this@RenActivity),16)
        }
        root.addView(input, LinearLayout.LayoutParams(-1,dp(78)).apply{setMargins(0,dp(2),0,dp(8))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        openMatchButton=TextView(this).apply{ text="MATCH"; textSize=11f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); visibility=View.GONE; background=rounded(ThemeManager.accent(this@RenActivity),13) }
        row.addView(openMatchButton,LinearLayout.LayoutParams(dp(86),dp(48)).apply{setMargins(0,0,dp(8),0)})
        val ask=TextView(this).apply{ text="ASK BEN"; textSize=13f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=rounded(ThemeManager.accent(this@RenActivity),14); setOnClickListener{respond(input,answer,modelPill)} }
        row.addView(ask,LinearLayout.LayoutParams(0,dp(48),1f).apply{weight=1f})
        val gemini=TextView(this).apply{
            text="GEMINI WEB"; textSize=11f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); background=rounded(ThemeManager.elevated(this@RenActivity),14)
            setOnClickListener{researchWithGemini(input,answer,modelPill)}
        }
        row.addView(gemini,LinearLayout.LayoutParams(dp(120),dp(48)).apply{setMargins(dp(8),0,0,0)})
        root.addView(row)

        // Android 15+/API 36 edge-to-edge can ignore the legacy resize hint. Apply the IME
        // inset directly to the chat surface so the composer and its typed text always remain
        // above the keyboard. This also keeps the last lines visible while the user types.
        val baseLeft=root.paddingLeft;val baseTop=root.paddingTop;val baseRight=root.paddingRight;val baseBottom=root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root){_,insets->
            val ime=insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            val bottom=baseBottom+(if(ime>bars)ime else bars)
            root.setPadding(baseLeft,baseTop,baseRight,bottom)
            if(ime>0){
                input.post{
                    val r=Rect(0,0,input.width,input.height)
                    input.requestRectangleOnScreen(r,true)
                }
            }
            insets
        }
        ViewCompat.requestApplyInsets(root)
        input.setOnFocusChangeListener{_,hasFocus->
            if(hasFocus) input.post{input.requestRectangleOnScreen(Rect(0,0,input.width,input.height),true)}
        }
        return root
    }

    private fun modelStatus(): String {
        val m=BenNeuralModelManager(this)
        val e=m.installed(BenNeuralModelRegistry.embeddingGemma300m)!=null
        val g=m.installed(BenNeuralModelRegistry.gemma3_270m)!=null
        return when { e&&g -> "Neural: EmbeddingGemma + Gemma 3 270M ready"; e -> "Neural: EmbeddingGemma installed • generation fallback"; g -> "Neural: Gemma 3 270M installed • semantic fallback"; else -> "Neural: models not installed • deterministic Ben ready" }
    }

    private fun respond(input:EditText,answer:TextView,modelPill:TextView){
        val cmd=input.text?.toString().orEmpty().trim()
        openMatchButton?.visibility=View.GONE
        if(cmd.isBlank()){answer.text="Ask Ben a question first.";return}
        AppManagers.renMemory.putWorking(cmd)
        answer.text="Ben is working…"
        liveJob?.cancel()
        liveJob=liveScope.launch{
            while(isActive){
                val t=BenNeuralTelemetry.snapshot()
                val gov=BenAiResourceGovernor(this@RenActivity).snapshot(foreground=true)
                liveStatus?.text="BEN • ${t.stage.name.replace('_',' ')} • ${t.stageDetail}"
                modelPill.text="${t.activeModel} • RAM ${gov.availableMemoryMb} MB • thermal ${gov.thermalStatus}"
                if(t.stage==BenNeuralTelemetry.Stage.COMPLETE||t.stage==BenNeuralTelemetry.Stage.FALLBACK||t.stage==BenNeuralTelemetry.Stage.ERROR||t.stage==BenNeuralTelemetry.Stage.BLOCKED) break
                delay(180L)
            }
        }
        AppManagers.frankensteinSupport.respond(cmd){ insight, ids ->
            runOnUiThread{
                liveJob?.cancel()
                val t=BenNeuralTelemetry.snapshot()
                liveStatus?.text="BEN • ${if(t.lastGeneratorUsed||t.lastSemanticUsed) "NEURAL" else "DETERMINISTIC FALLBACK"} • ${t.lastElapsedMs} ms"
                modelPill.text="${t.activeModel} • evidence ${t.lastEvidenceCount} • verifier ${if(t.lastVerified) "PASS" else "REVIEW"}"
                if(isFinishing||isDestroyed)return@runOnUiThread
                answer.text=insight.body
                if(insight.actions.contains("Open matching questions")&&ids.isNotEmpty()){
                    openMatchButton?.visibility=View.VISIBLE
                    val query=cmd.replace(Regex("(?i)\\b(find|search|show|give|open|questions?|qbank|topic|subject|about)\\b")," ").replace(Regex("\\s+")," ").trim()
                    openMatchButton?.setOnClickListener{startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Dr. Frankenstein • $query").putExtra("practiceMode",true).putExtra("title","Dr. Frankenstein • $query"))}
                }
                AppManagers.renMemory.putStudy(answer.text.toString())
            }
        }
    }

    private fun researchWithGemini(input:EditText, answer:TextView, modelPill:TextView){
        val cmd=input.text?.toString().orEmpty().trim()
        if(cmd.isBlank()){ answer.text="Ask a research question first."; return }
        geminiJob?.cancel()
        val account=GoogleAccountManager(this)
        val current=account.currentEmail()
        if(current==null){
            answer.text="Google sign-in required for Gemini web research…"
            geminiJob=liveScope.launch{
                val login=account.signIn()
                if(login.isFailure){
                    answer.text="Google sign-in could not be completed: ${login.exceptionOrNull()?.message ?: "unknown error"}"
                    liveStatus?.text="GEMINI • SIGN-IN FAILED"
                    return@launch
                }
                runGeminiResearch(cmd,answer,modelPill,login.getOrNull())
            }
        } else {
            runGeminiResearch(cmd,answer,modelPill,current)
        }
    }

    private fun runGeminiResearch(cmd:String, answer:TextView, modelPill:TextView, email:String?){
        answer.text="Ben + Gemini are researching…"
        geminiSearchEntry?.visibility=View.GONE
        liveStatus?.text="BEN • GEMINI WEB RESEARCH"
        modelPill.text="Google account • ${email ?: "signed in"}"
        geminiJob=liveScope.launch{
            val result=runCatching{BenGeminiCoordinator(this@RenActivity).research(cmd)}.getOrElse{
                BenGeminiCoordinator.Result("Gemini research failed: ${it.message ?: "unknown error"}", emptyList(), false, email)
            }
            if(isFinishing||isDestroyed)return@launch
            answer.text=buildString{
                append(result.answer)
                if(result.grounded && result.sources.isNotEmpty()){
                    append("\n\nSOURCES")
                    result.sources.forEachIndexed{index,source->append("\n${index+1}. ${source.title}\n${source.uri}")}
                }
            }
            result.searchEntryPointHtml?.takeIf{it.isNotBlank()}?.let{html->
                geminiSearchEntry?.visibility=View.VISIBLE
                geminiSearchEntry?.loadDataWithBaseURL("https://www.google.com/",html,"text/html","UTF-8",null)
            }
            liveStatus?.text="BEN • ${if(result.grounded)"GEMINI GROUNDED" else "GEMINI RESPONSE"} • ${result.sources.size} sources"
            modelPill.text="Gemini • ${result.signedInEmail ?: email ?: "signed out"}"
            AppManagers.renMemory.putStudy(answer.text.toString())
        }
    }

    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
    override fun onDestroy(){liveJob?.cancel();geminiJob?.cancel();geminiSearchEntry?.stopLoading();geminiSearchEntry?.destroy();geminiSearchEntry=null;liveScope.cancel();super.onDestroy()}
}
