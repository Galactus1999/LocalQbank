# Rovex v8.3.482 — Phase 2C Warm Diagnostic Explicit Opt-In

## Purpose
Make the diagnostics-only warm EmbeddingGemma → grounded Ben test executable when the user's neural accelerator is OFF without weakening the production safety contract.

## Changes
- The warm diagnostic now detects AI accelerator OFF before starting the test.
- It asks for an explicit `ENABLE FOR TEST` confirmation.
- If confirmed, it temporarily enables the existing `BenAiRuntimePolicy`.
- The previous OFF state is restored automatically in `finally`, including cancellation/exception paths.
- The circuit breaker is not overridden or reset.
- No production interactive request is changed and no study data is modified.
- Diagnostic report records whether temporary policy opt-in was used.
- Version: 8.3.482 / versionCode 573.

## Verification status
- Static/source audit: pending final local audit.
- Local Gradle build: may be blocked if Gradle distribution DNS remains unavailable.
- CI/device: pending.
