package com.localqbank.library

import android.content.Context
import android.os.Build
import com.sentencepiece.Model
import com.sentencepiece.Scoring
import com.sentencepiece.SentencePieceAlgorithm
import com.qualcomm.qti.QnnDelegate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Direct EmbeddingGemma execution boundary.
 *
 * The user-selected EmbeddingGemma .tflite graph is executed directly by LiteRT.
 * No higher-level embedding wrapper is allowed to reinterpret the model tensor contract.
 *
 * SentencePiece is used only for tokenization. Retrieval policy, learner logic and study logic
 * remain outside this class. Any failure falls back to deterministic retrieval.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)
    data class Result<T>(val hits: List<SemanticHit<T>>, val elapsedMs: Long, val usedModel: Boolean)

    suspend fun <T> rerank(
        query: String,
        candidates: List<T>,
        textOf: (T) -> String,
        limit: Int = 8
    ): Result<T> = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile)
        val tokenizer = models.installedEmbeddingGemmaTokenizer()
        if (installed == null) {
            fail("EmbeddingGemma model is not installed")
            return@withContext fallback(candidates, limit, started)
        }
        if (tokenizer == null) {
            fail("EmbeddingGemma sentencepiece.model is not installed")
            return@withContext fallback(candidates, limit, started)
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, governor.snapshot(true))
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext fallback(candidates, limit, started)
        }
        val cleanQuery = clean(query)
        if (cleanQuery.length < 2 || candidates.isEmpty()) {
            return@withContext fallback(candidates, limit, started)
        }
        try {
            val runtime = Runtime(installed.file, tokenizer)
            runtime.use {
                BenNeuralTelemetry.stage(
                    BenNeuralTelemetry.Stage.SEMANTIC_RERANK,
                    "Semantic reranking via ${it.backend()}",
                    "EmbeddingGemma 300M",
                    it.backend()
                )
                val queryVector = it.embed(cleanQuery, Task.RETRIEVAL_QUERY)
                val selected = candidates.take(8)
                val scored = selected.map { candidate ->
                    val text = clean(textOf(candidate))
                    SemanticHit(candidate, cosine(queryVector, it.embed(text, Task.RETRIEVAL_DOCUMENT)))
                }.sortedByDescending { it.similarity }.take(limit.coerceIn(1, 8))
                policy.recordBackendSuccess()
                Result(scored, max(0L, System.currentTimeMillis() - started), true)
            }
        } catch (error: LinkageError) {
            fail("EmbeddingGemma native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            fallback(candidates, limit, started)
        } catch (error: Exception) {
            fail(runtimeMessage(error))
            policy.recordBackendFailure()
            fallback(candidates, limit, started)
        }
    }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile) ?: run {
            fail("EmbeddingGemma model is not installed")
            return@withContext null
        }
        val tokenizer = models.installedEmbeddingGemmaTokenizer() ?: run {
            fail("EmbeddingGemma sentencepiece.model is not installed")
            return@withContext null
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, governor.snapshot(true))
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext null
        }
        try {
            val runtime = Runtime(installed.file, tokenizer)
            runtime.use {
                BenNeuralTelemetry.stage(
                    BenNeuralTelemetry.Stage.SEMANTIC_RERANK,
                    "EmbeddingGemma inference via ${it.backend()}",
                    "EmbeddingGemma 300M",
                    it.backend()
                )
                val a = it.embed(clean(first), Task.SENTENCE_SIMILARITY)
                val b = it.embed(clean(second), Task.SENTENCE_SIMILARITY)
                if (a.size != b.size) throw IllegalStateException("Embedding dimension mismatch: ${a.size} vs ${b.size}")
                if (a.size < 128) throw IllegalStateException("Unexpected embedding dimension: ${a.size}")
                val score = cosine(a, b)
                policy.recordBackendSuccess()
                BenNeuralTelemetry.semantic(max(0L, System.currentTimeMillis() - started), true)
                score
            }
        } catch (error: LinkageError) {
            fail("EmbeddingGemma native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            null
        } catch (error: Exception) {
            fail(runtimeMessage(error))
            policy.recordBackendFailure()
            null
        }
    }

    /**
     * Non-destructive diagnostic for Adaptive Engine. It validates the installed artifact,
     * tokenizer, tensor contract, backend selection and a small semantic-similarity pair.
     * It never writes study data.
     */
    suspend fun diagnostic(): String? = withContext(Dispatchers.IO) {
        val installed = models.installed(profile) ?: run {
            fail("EmbeddingGemma model is not installed")
            return@withContext null
        }
        val tokenizerFile = models.installedEmbeddingGemmaTokenizer() ?: run {
            fail("EmbeddingGemma sentencepiece.model is not installed")
            return@withContext null
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, governor.snapshot(true))
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext null
        }
        val started = System.currentTimeMillis()
        try {
            Runtime(installed.file, tokenizerFile).use { runtime ->
                val score = cosine(
                    runtime.embed("task: sentence similarity | query: nephrotic syndrome causes edema", Task.SENTENCE_SIMILARITY),
                    runtime.embed("task: sentence similarity | query: protein loss lowers plasma oncotic pressure and produces edema", Task.SENTENCE_SIMILARITY)
                )
                policy.recordBackendSuccess()
                BenNeuralTelemetry.semantic(System.currentTimeMillis() - started, true)
                "Model: ${profile.name}\n" +
                    "Artifact: ${installed.bytes / (1024 * 1024)} MB\n" +
                    "Tokenizer: ${tokenizerFile.length() / (1024 * 1024)} MB\n" +
                    "Backend: ${runtime.backend()}\n" +
                    "Contract: ${runtime.contract()}\n" +
                    "Output: 768-d float32\n" +
                    "Semantic pair cosine: ${"%.4f".format(score)}\n" +
                    "Elapsed: ${System.currentTimeMillis() - started} ms\n\n" +
                    "No study data was changed. Deterministic retrieval remains authoritative."
            }
        } catch (error: LinkageError) {
            fail("EmbeddingGemma diagnostic native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            null
        } catch (error: Exception) {
            fail(runtimeMessage(error))
            policy.recordBackendFailure()
            null
        }
    }

    /** Direct model contract + inference implementation. */
    private inner class Runtime(model: File, tokenizerFile: File) : AutoCloseable {
        private lateinit var interpreter: Interpreter
        private lateinit var tokenizer: Model
        private val tokenizerAlgorithm = SentencePieceAlgorithm(true, Scoring.HIGHEST_SCORE)
        private var qnnDelegate: QnnDelegate? = null
        private var backendName: String = "CPU/XNNPACK"
        private val inputIdsIndex: Int
        private val attentionMaskIndex: Int?
        private val sequenceLength: Int
        private val inputIdType: DataType
        private val maskType: DataType?
        private val outputIndex: Int
        private val outputShape: IntArray
        private val contractDescription: String

        init {
            var interpreterLocal: Interpreter? = null
            try {
                // Do not use DJL SentencePiece JNI on Android. DJL's SentencePiece loader
                // is designed around its native-library extraction/cache mechanism and can
                // fail with "IllegalStateException: Cannot copy jni files" on Android.
                // SentencePiece4J is a pure-Java implementation, so tokenizer execution is
                // offline, deterministic, and does not require JNI/native file extraction.
                val tokenizerReady = Model.parseFrom(tokenizerFile.toPath())
                val qnnAttempt = createQnnDelegateIfSupported()
                val interpreterReady = try {
                    createAndAllocate(model, qnnAttempt)
                } catch (firstError: Exception) {
                    if (qnnAttempt != null) {
                        fail("EmbeddingGemma QNN HTP allocation failed; falling back to CPU/XNNPACK: ${firstError.javaClass.simpleName}: ${firstError.message?.take(240) ?: "no message"}")
                        qnnDelegate = null
                        backendName = "CPU/XNNPACK (QNN fallback)"
                        createAndAllocate(model, null)
                    } else {
                        throw firstError
                    }
                } catch (firstError: LinkageError) {
                    if (qnnAttempt != null) {
                        fail("EmbeddingGemma QNN HTP native linkage failed; falling back to CPU/XNNPACK: ${firstError.javaClass.simpleName}: ${firstError.message?.take(240) ?: "no message"}")
                        qnnDelegate = null
                        backendName = "CPU/XNNPACK (QNN fallback)"
                        createAndAllocate(model, null)
                    } else {
                        throw firstError
                    }
                }
                interpreterLocal = interpreterReady

                tokenizer = tokenizerReady
                interpreter = interpreterReady

                val inputCount = interpreter.inputTensorCount
            if (inputCount != 2) {
                throw IllegalStateException("EmbeddingGemma 512 expects 2 inputs (input_ids + attention_mask), got $inputCount")
            }

            val inputs = (0 until inputCount).map { i ->
                val t = interpreter.getInputTensor(i)
                InputInfo(i, t.name(), t.dataType(), t.shape())
            }
            val id = inputs.firstOrNull { looksLikeIds(it.name) }
                ?: inputs.firstOrNull { it.type == DataType.INT64 || it.type == DataType.INT32 }
                ?: throw IllegalStateException("No integer token-id input found. Contract=${describe(inputs)}")
            inputIdsIndex = id.index
            inputIdType = id.type
            sequenceLength = sequenceLength(id.shape)
            if (id.shape.size != 2 || id.shape[0] != 1 || sequenceLength != 512) {
                throw IllegalStateException("EmbeddingGemma 512 requires input shape [1,512], got ${id.shape.contentToString()}. Contract=${describe(inputs)}")
            }
            if (inputIdType != DataType.INT64 && inputIdType != DataType.INT32) {
                throw IllegalStateException("EmbeddingGemma 512 requires INT64/INT32 input_ids, got $inputIdType. Contract=${describe(inputs)}")
            }

            attentionMaskIndex = inputs.firstOrNull { it.index != inputIdsIndex && looksLikeMask(it.name) }?.index
                ?: inputs.firstOrNull { it.index != inputIdsIndex }?.index
            maskType = attentionMaskIndex?.let { interpreter.getInputTensor(it).dataType() }
            if (attentionMaskIndex == null) {
                throw IllegalStateException("EmbeddingGemma 512 attention_mask input is missing. Contract=${describe(inputs)}")
            }
            if (maskType != DataType.INT64 && maskType != DataType.INT32) {
                throw IllegalStateException("EmbeddingGemma 512 requires INT64/INT32 attention_mask, got $maskType. Contract=${describe(inputs)}")
            }
            val maskShape = interpreter.getInputTensor(attentionMaskIndex).shape()
            if (maskShape.contentEquals(id.shape).not()) {
                throw IllegalStateException("attention_mask shape ${maskShape.contentToString()} does not match input_ids ${id.shape.contentToString()}. Contract=${describe(inputs)}")
            }

            val outputs = (0 until interpreter.outputTensorCount).map { i ->
                val t = interpreter.getOutputTensor(i)
                OutputInfo(i, t.name(), t.dataType(), t.shape(), t.numElements())
            }
            val chosen = outputs.filter { it.type == DataType.FLOAT32 && it.elements >= 128 }
                .maxByOrNull { scoreOutput(it) }
                ?: throw IllegalStateException("No usable float embedding output. Contract=${describe(outputs)}")
            outputIndex = chosen.index
            outputShape = chosen.shape
            if (chosen.elements != 768 || chosen.type != DataType.FLOAT32) {
                throw IllegalStateException("EmbeddingGemma 512 expects 768 float32 values, got ${chosen.shape.contentToString()} ${chosen.type}. Contract=${describe(outputs)}")
            }
                contractDescription = "backend=$backendName; inputs=${describe(inputs)}; output=${describe(listOf(chosen))}"
            } catch (error: Exception) {
                try { interpreterLocal?.close() } catch (_: Exception) {}
                throw error
            } catch (error: LinkageError) {
                try { interpreterLocal?.close() } catch (_: Exception) {}
                throw error
            }
        }

        fun embed(text: String, task: Task): List<Float> {
            val ids = tokenize(task.prefix + text)
            val padded = LongArray(sequenceLength)
            val count = minOf(ids.size, sequenceLength)
            for (i in 0 until count) padded[i] = ids[i].toLong()
            val mask = LongArray(sequenceLength) { if (it < count) 1L else 0L }

            val inputs = arrayOfNulls<Any>(interpreter.inputTensorCount)
            inputs[inputIdsIndex] = tokenBuffer(padded, inputIdType)
            attentionMaskIndex?.let { inputs[it] = tokenBuffer(mask, maskType ?: inputIdType) }

            val output = FloatArray(interpreter.getOutputTensor(outputIndex).numElements())
            val outputs = hashMapOf<Int, Any>(outputIndex to output)
            interpreter.runForMultipleInputsOutputs(inputs.requireNoNulls(), outputs)
            if (output.size != 768) throw IllegalStateException("EmbeddingGemma produced ${output.size} values; expected 768")
            return output.toList()
        }

        private fun tokenize(text: String): IntArray {
            val ids = tokenizer.encodeNormalized(text, tokenizerAlgorithm).map { it }.toIntArray()
            // EmbeddingGemma/Gemma tokenizer uses BOS=2, EOS=1, PAD=0. SentencePiece itself
            // does not automatically apply the model's special-token policy here, so add the
            // same special tokens used by the Hugging Face Gemma tokenizer.
            val withSpecial = IntArray(ids.size + 2)
            withSpecial[0] = 2
            ids.copyInto(withSpecial, destinationOffset = 1)
            withSpecial[withSpecial.lastIndex] = 1
            return withSpecial
        }

        private fun tokenBuffer(values: LongArray, type: DataType): ByteBuffer {
            return when (type) {
                DataType.INT64 -> ByteBuffer.allocateDirect(values.size * Long.SIZE_BYTES)
                    .order(ByteOrder.nativeOrder())
                    .apply {
                        asLongBuffer().put(values)
                        rewind()
                    }
                DataType.INT32 -> ByteBuffer.allocateDirect(values.size * Int.SIZE_BYTES)
                    .order(ByteOrder.nativeOrder())
                    .apply {
                        asIntBuffer().put(values.map { it.toInt() }.toIntArray())
                        rewind()
                    }
                else -> throw IllegalStateException("EmbeddingGemma token tensors must be INT64 or INT32, got $type")
            }
        }

        fun backend(): String = backendName

        private fun createQnnDelegateIfSupported(): QnnDelegate? {
            if (!isQualcommDevice()) return null
            return try {
                val options = QnnDelegate.Options().apply {
                    setBackendType(QnnDelegate.Options.BackendType.HTP_BACKEND)
                    setSkelLibraryDir(app.applicationInfo.nativeLibraryDir)
                }
                QnnDelegate(options).also {
                    qnnDelegate = it
                    backendName = "Qualcomm QNN HTP"
                }
            } catch (error: LinkageError) {
                fail("QNN unavailable: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}")
                null
            } catch (error: Exception) {
                fail("QNN unavailable: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}")
                null
            }
        }

        private fun createInterpreter(model: File, delegate: QnnDelegate?): Interpreter {
            val options = Interpreter.Options().apply {
                setNumThreads(4)
                setCancellable(true)
                if (delegate == null) {
                    setUseXNNPACK(true)
                } else {
                    setUseXNNPACK(false)
                    addDelegate(delegate)
                }
            }
            return Interpreter(model, options)
        }

        private fun createAndAllocate(model: File, delegate: QnnDelegate?): Interpreter {
            val interpreter = createInterpreter(model, delegate)
            return try {
                interpreter.allocateTensors()
                interpreter
            } catch (error: Exception) {
                runCatching { interpreter.close() }
                throw error
            } catch (error: LinkageError) {
                runCatching { interpreter.close() }
                throw error
            }
        }

        private fun isQualcommDevice(): Boolean {
            val manufacturer = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER else Build.HARDWARE
            val model = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE
            return manufacturer.contains("qualcomm", true) || manufacturer.contains("qti", true) ||
                model.equals("SM8650", true) || model.equals("SM8550", true) ||
                model.equals("SM8750", true) || model.equals("SM8850", true) ||
                Build.HARDWARE.contains("qcom", true)
        }

        fun contract(): String = contractDescription

        override fun close() {
            try { interpreter.close() } catch (_: Exception) {}
        }
    }

    private enum class Task(val prefix: String) {
        RETRIEVAL_QUERY("task: search result | query: "),
        RETRIEVAL_DOCUMENT("title: none | text: "),
        SENTENCE_SIMILARITY("task: sentence similarity | query: ")
    }

    private data class InputInfo(val index: Int, val name: String, val type: DataType, val shape: IntArray)
    private data class OutputInfo(val index: Int, val name: String, val type: DataType, val shape: IntArray, val elements: Int)

    private fun looksLikeIds(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("input_ids") || n.contains("token") || n.contains("text_batch") || n.contains("ids")
    }

    private fun looksLikeMask(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("attention") || n.contains("mask")
    }

    private fun sequenceLength(shape: IntArray): Int = shape.lastOrNull() ?: 0

    private fun scoreOutput(info: OutputInfo): Int {
        val name = info.name.lowercase()
        var score = 0
        if (info.elements == 768) score += 1000
        if (name.contains("embed") || name.contains("encoding") || name.contains("sentence")) score += 500
        if (info.shape.size == 2) score += 100
        return score
    }

    private fun describe(items: List<Any>): String = items.joinToString(" | ") { item ->
        when (item) {
            is InputInfo -> "in#${item.index}:${item.name}:${item.type}:${item.shape.contentToString()}"
            is OutputInfo -> "out#${item.index}:${item.name}:${item.type}:${item.shape.contentToString()}"
            else -> item.toString()
        }
    }

    private fun runtimeMessage(error: Exception): String =
        "EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(320) ?: "no message"}"

    private fun fail(message: String) {
        BenNeuralTelemetry.error(message)
    }

    private fun cosine(a: List<Float>, b: List<Float>): Double {
        val n = minOf(a.size, b.size)
        if (n == 0) return 0.0
        var dot = 0.0
        var aa = 0.0
        var bb = 0.0
        for (i in 0 until n) {
            val x = a[i].toDouble()
            val y = b[i].toDouble()
            dot += x * y
            aa += x * x
            bb += y * y
        }
        return if (aa <= 0.0 || bb <= 0.0) 0.0 else
            (dot / (sqrt(aa) * sqrt(bb))).coerceIn(-1.0, 1.0)
    }

    private fun clean(value: String) = value.replace(Regex("\\s+"), " ").trim().take(1800)

    private fun <T> fallback(candidates: List<T>, limit: Int, started: Long) =
        Result(candidates.take(limit.coerceAtLeast(0)).map { SemanticHit(it, 0.0) }, max(0L, System.currentTimeMillis() - started), false)
}
