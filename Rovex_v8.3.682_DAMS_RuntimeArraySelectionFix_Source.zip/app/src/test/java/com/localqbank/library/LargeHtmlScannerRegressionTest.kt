package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Regression coverage for the current LargeHtmlScanner API.
 *
 * An earlier v8.3.568 experiment introduced tests for a transient progress/count API while the scanner
 * was being changed. That API was intentionally reverted after CI failures.
 * These tests exercise the actual production v8.3.570 scanner contract instead:
 * scan() emits questions through onQuestion and consumes the matched array '['.
 */
class LargeHtmlScannerRegressionTest {
    @Test
    fun jvmJsonImplementationIsAvailableForScannerTests() {
        val value = org.json.JSONObject("""{"text":"real-json"}""").optString("text")
        assertEquals("real-json", value)
    }

    @Test
    fun testArrayEmitsFirstQuestion() {
        val file = File.createTempFile("rovex-large-html", ".html")
        try {
            file.writeText("""
                <html><script>const TESTS_LIST = [
                  {"title":"Pathology","questions":[{"id":"q1","text":"What is the diagnosis?","options":[{"label":"A","text":"Option A"}]}]}
                ];</script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:What is the diagnosis?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun rootQuestionArrayUsesQuestionAliasWhenTextAliasesAreAbsent() {
        val file = File.createTempFile("rovex-large-html-root-alias", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q1","question":"Alias question?","choices":[{"label":"A","text":"Yes"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Alias question?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun rootQuestionArrayEmitsFirstQuestion() {
        val file = File.createTempFile("rovex-large-html-root", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q1","question":"Which is correct?","options":[{"label":"A","text":"Yes"}]}];</script>
            """.trimIndent())
            var count = 0
            LargeHtmlScanner(file) { _, question ->
                count++
                assertTrue(question.text.contains("Which is correct?"))
            }.scan()
            assertEquals(1, count)
        } finally {
            file.delete()
        }
    }

    @Test
    fun explicitJsonNullDoesNotMaskQuestionAndOptionAliases() {
        val file = File.createTempFile("rovex-large-html-null-alias", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q-null","raw_text":null,"text":null,"question":"Fallback question","options":null,"choices":[{"label":"A","text":"Yes"},{"label":"B","text":"No"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<ImportedQuestion>()
            LargeHtmlScanner(file) { _, question -> seen += question }.scan()
            assertEquals(1, seen.size)
            assertEquals("Fallback question", seen.single().text)
            assertEquals(listOf("Yes", "No"), seen.single().options.map { it.text })
        } finally {
            file.delete()
        }
    }


    @Test
    fun assignmentInsideJavascriptCommentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-comment", ".html")
        try {
            file.writeText("""
                <script>
                  // const TESTS_LIST = [{"question":"wrong","options":[{"text":"bad"}]}];
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"id":"q2","text":"Actual question","options":[{"label":"A","text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Actual question"), seen)
        } finally {
            file.delete()
        }
    }


    @Test
    fun blockCommentAssignmentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-block-comment", ".html")
        try {
            file.writeText("""
                <script>
                  /* const TESTS_LIST = [{"title":"Wrong","questions":[{"text":"bad","options":[{"text":"bad"}]}]}; */
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun quotedFakeAssignmentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-string", ".html")
        try {
            file.writeText("""
                <script>
                  const fake = "const TESTS_LIST = [{\\"title\\":\\"Wrong\\"}]";
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun windowQualifiedQuestionAliasIsRecognized() {
        val file = File.createTempFile("rovex-large-html-window", ".html")
        try {
            file.writeText("""
                <script>window.QUESTIONS_DATA = [{"question":"Window alias","options":[{"text":"Yes"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Window alias"), seen)
        } finally { file.delete() }
    }

    @Test
    fun declarationAndWhitespaceVariantsAreRecognized() {
        val file = File.createTempFile("rovex-large-html-whitespace", ".html")
        try {
            file.writeText("""
                <script>
                  let
                    questionData
                    =
                    [
                      {"question":"Whitespace alias","options":[{"text":"Yes"}]}
                    ];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Whitespace alias"), seen)
        } finally { file.delete() }
    }

    @Test
    fun identifierSubstringCannotHijackSupportedAlias() {
        val file = File.createTempFile("rovex-large-html-identifier", ".html")
        try {
            file.writeText("""
                <script>
                  const MY_TESTS_LIST = [{"title":"Wrong","questions":[{"text":"bad","options":[{"text":"bad"}]}]}];
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun scanReturnsValidatedQuestionCountAndRecognizesCaseInsensitiveAliases() {
        val file = File.createTempFile("rovex-large-html-alias-case", ".html")
        try {
            file.writeText("""
                <script>const tests_list = [
                  {"title":"Pathology","questions":[
                    {"id":"q1","text":"First question?","options":["A"]},
                    {"id":"q2","text":"Second question?","options":["B"]}
                  ]}
                ];</script>
            """.trimIndent())
            var emitted = 0
            val count = LargeHtmlScanner(file) { _, _ -> emitted++ }.scan()
            assertEquals(2, count)
            assertEquals(count, emitted)
        } finally {
            file.delete()
        }
    }

    @Test
    fun emptySupportedArrayReportsZeroInsteadOfSuccessfulImportCount() {
        val file = File.createTempFile("rovex-large-html-empty", ".html")
        try {
            file.writeText("<script>const TESTS_LIST = [];</script>")
            val count = LargeHtmlScanner(file) { _, _ -> throw AssertionError("No question should be emitted") }.scan()
            assertEquals(0, count)
        } finally {
            file.delete()
        }
    }



    @Test
    fun prefersCombinedTestsListOverEarlierAppDataMetadataArray() {
        val file = File.createTempFile("rovex-large-html-array-priority", ".html")
        try {
            file.writeText("""
                <html><script>
                  const APP_DATA = [{"title":"Metadata only","folders":[]}];
                  const TESTS_LIST = [{"title":"DAMS Pathology","questions":[
                    {"id":"dams-1","text":"Real question?","options":[
                      {"label":"A","text":"Correct option","correct":true},
                      {"label":"B","text":"Other option","correct":false}
                    ],"correct_answer":"A","explanation":"Because the evidence supports A."}
                  ]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertEquals(listOf("DAMS Pathology:Real question?"), seen)
        } finally {
            file.delete()
        }
    }


    @Test
    fun nestedAppDataFallbackFindsQuestionsUnderFoldersAndLessons() {
        val file = File.createTempFile("rovex-large-html-nested-appdata", ".html")
        try {
            file.writeText("""
                <html><script>
                  const APP_DATA = [{"title":"Metadata folder","folders":[
                    {"title":"Pathology","lessons":[
                      {"title":"Renal","questions":[
                        {"id":"nested-1","text":"Nested DAMS question?","options":[
                          {"label":"A","text":"Yes"},{"label":"B","text":"No"}
                        ]}
                      ]}
                    ]}
                  ]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertTrue(seen.single().endsWith(":Nested DAMS question?"))
        } finally {
            file.delete()
        }
    }

    @Test
    fun largeScannerAcceptsLegacyOptionListAndQuestionTextAliases() {
        val file = File.createTempFile("rovex-large-html-legacy-dams", ".html")
        try {
            file.writeText("""
                <html><script>const TESTS_LIST = [
                  {"title":"DAMS","questions":[
                    {"id":"dams-1","questionText":"Which finding is correct?","option_list":[
                      {"label":"A","option_text":"First option"},
                      {"label":"B","option_text":"Second option"}
                    ],"correct":"B","explanationText":"The second option is correct."}
                  ]}
                ];</script></html>
            """.trimIndent())
            val seen = mutableListOf<ImportedQuestion>()
            val count = LargeHtmlScanner(file) { _, question -> seen += question }.scan()
            assertEquals(1, count)
            assertEquals(1, seen.size)
            assertEquals("Which finding is correct?", seen.single().text)
            assertEquals(listOf("First option", "Second option"), seen.single().options.map { it.text })
            assertEquals("B", seen.single().correctAnswer)
        } finally {
            file.delete()
        }
    }


    @Test
    fun emptyRuntimeTestsArrayDoesNotMaskLaterDamsTestsList() {
        val file = File.createTempFile("rovex-large-html-runtime-tests", ".html")
        try {
            file.writeText("""
                <html><script>
                  const tests = [];
                  const TESTS_LIST = [{
                    "id":"dams-test-1", "title":"DAMS Pathology", "num_questions":1,
                    "questions":[{
                      "id":"dams-q1", "text":"Which finding is correct?",
                      "raw_text":"Which finding is correct?",
                      "options":[
                        {"label":"A","text":"Correct option","correct":true},
                        {"label":"B","text":"Incorrect option","correct":false}
                      ],
                      "correct_answer":"A", "explanation":"The first option is correct."
                    }]
                  }];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertEquals(listOf("DAMS Pathology:Which finding is correct?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun nestedItemsAliasIsRecognizedInsideCombinedTest() {
        val file = File.createTempFile("rovex-large-html-items-alias", ".html")
        try {
            file.writeText("""
                <script>const TESTS_LIST = [{"title":"DAMS","items":[
                  {"id":"q1","questionText":"Nested item question?","optionList":[
                    {"label":"A","text":"Yes"},{"label":"B","text":"No"}
                  ]}
                ]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(1, count)
            assertEquals(listOf("Nested item question?"), seen)
        } finally {
            file.delete()
        }
    }

}
