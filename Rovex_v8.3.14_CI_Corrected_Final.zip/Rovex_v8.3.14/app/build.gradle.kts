plugins {
    id("com.android.application")
}
android {
    namespace = "com.localqbank.library"
    compileSdk = 37
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildTypes {
        release {
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    defaultConfig {
        applicationId = "com.localqbank.library"
        minSdk = 26
        targetSdk = 36
        versionCode = 112
        versionName = "8.3.14"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.work:work-runtime-ktx:2.10.1")
    // Modern Anki .apkg uses Zstandard-compressed collection.anki21b and media.
    implementation("com.github.luben:zstd-jni:1.5.7-16@aar")
}
