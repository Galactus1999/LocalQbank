package com.localqbank.library

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.sin

/**
 * Theme-adaptive Rovex R made from small cubes. On attachment the cubes begin
 * dispersed and settle into the R mark. The animation runs once per attachment
 * and then remains static, keeping startup work bounded.
 */
class RovexWaveLogoView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val cells = mutableListOf<Pair<Int, Int>>()
    private var progress = 1f
    private var animator: ValueAnimator? = null
    private var accent = ThemeManager.accent(context)
    private var secondary = ThemeManager.text(context)

    init {
        val pattern = arrayOf("11110", "10001", "10001", "11110", "10100", "10010", "10001")
        pattern.forEachIndexed { r, row -> row.forEachIndexed { c, v -> if (v == '1') cells += c to r } }
        isClickable = false
        contentDescription = "Rovex logo"
    }

    fun refreshTheme() {
        accent = ThemeManager.accent(context)
        secondary = ThemeManager.text(context)
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startSettleAnimation()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    private fun startSettleAnimation() {
        animator?.cancel()
        progress = 0f
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1450L
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val cube = (minOf(width, height) * 0.145f).coerceAtLeast(3f)
        val gap = cube * 0.19f
        val gridW = 5 * cube + 4 * gap
        val gridH = 7 * cube + 6 * gap
        val left = (width - gridW) / 2f
        val top = (height - gridH) / 2f
        val maxTravel = minOf(width, height) * 0.72f

        cells.forEachIndexed { i, cell ->
            val delay = (i % 9) * 0.055f
            val t = ((progress - delay) / (1f - delay)).coerceIn(0f, 1f)
            val eased = 1f - (1f - t) * (1f - t)
            val angle = i * 2.39996
            val distance = maxTravel * (0.72f + ((i * 37) % 11) / 20f)
            val sx = (cos(angle) * distance).toFloat()
            val sy = (sin(angle) * distance).toFloat()
            val x = left + cell.first * (cube + gap) + sx * (1f - eased)
            val y = top + cell.second * (cube + gap) + sy * (1f - eased)
            val mixed = if (i % 4 == 0) secondary else accent
            paint.color = withAlpha(mixed, (225f + 30f * eased).toInt().coerceAtMost(255))
            val radius = cube * 0.16f
            canvas.drawRoundRect(RectF(x, y, x + cube, y + cube), radius, radius, paint)
        }
    }

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
}
