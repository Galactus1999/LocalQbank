# Rovex v8.3.524 — Friend Request No-Cloud-Function Transport

## Root cause
The v8.3.523 repair removed the client-side `friendCodes/{code}` lookup but used a Cloud Function to resolve the target Rovex ID. Firebase deployment showed the project must be on Blaze because Cloud Functions require Cloud Build/Artifact Registry. That made the repair unusable without a billing-plan change.

## Repair
Friend requests are now entirely Firestore client + security-rules driven:

1. Sender writes a self-owned `friendRequestIntents/{intentId}` document addressed by target Rovex ID. Firestore offline persistence can queue this write.
2. Recipient, when they next open Rovex Online, queries intents matching their own Rovex ID and status `queued`.
3. Recipient materializes the existing `friendRequests/{uid}/incoming/{requesterUid}` and `friendRequestsBySender/{requesterUid}/outgoing/{uid}` documents.
4. The intent is marked `delivered`.
5. No Cloud Function is required for friend-request delivery and recipient presence is irrelevant at send time.

Security rules restrict intent reads to the requester or the user whose Rovex ID matches `targetCode`. Recipient-created request documents must reference a real queued intent, the authenticated target user, and the target user's own Rovex ID.

## Scope
- `RovexOnline.kt` — recipient-side intent materialization.
- `RovexOnlineActivity.kt` — invoke materialization before rendering incoming requests; updated transport comments.
- `firestore.rules` — no-Function intent read/update and recipient materialization authorization.
- `functions/index.js` — removed unused `resolveFriendRequestIntent` export. Existing unrelated functions remain unchanged.
- `app/build.gradle.kts` — version 8.3.524 / versionCode 614.

## Verification status
- Source edit: PASS (static review pending).
- Firebase deployment: NOT YET RUN. Firestore rules should be deployed alone; no Functions deployment is required for friend requests.
- Android compile/CI/device runtime: PENDING.
