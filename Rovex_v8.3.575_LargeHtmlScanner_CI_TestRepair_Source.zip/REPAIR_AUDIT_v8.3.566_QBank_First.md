# Rovex v8.3.566 — QBank-First Repair Audit

## Baseline
- Source baseline: v8.3.565 / versionCode 654
- Current source: v8.3.566 / versionCode 655
- Package: `com.localqbank.library`
- Scope: P0 crash/build-log repair + QBankDb Stage 4 Study-State/Progress extraction
- Visual/interaction overhaul: explicitly deferred

## P0 crash
Device logcat identified:
`java.lang.IllegalArgumentException: Cannot set backoff criteria on an idle mode job`
from `QBankDeletionRecoveryWorker.enqueueIfNeeded()` while creating the WorkManager request during `LocalQBankApplication.onCreate()`.

Repair:
- retain `setRequiresDeviceIdle(true)`;
- remove incompatible `setBackoffCriteria(...)` from the idle request;
- preserve unique-work KEEP/migration semantics and durable recovery marker.

Static check: PASS — no `BackoffPolicy`/`setBackoffCriteria` remains in the recovery worker.

## Instrumented-log repairs
The v8.3.565 instrumented run reported 63 tests with 3 counted failures. Two were the same WorkManager idle/backoff exception in admission tests. The third was:
`foregroundInterruptionBetweenQuestionBatchesLeavesDurableRecoveryBoundary`
with expected physical remaining rows 51 but public `questionCount()` returning 0 because the deleted source is intentionally tombstoned and hidden from read-side APIs.

Repair:
- retain the public visibility assertion for the unrelated source;
- verify the deleted source's physical remaining question count directly against SQLite.

The EmbeddingGemma `assumption failed` line is an environment/capability assumption and was not counted as one of the three final failures.

## QBankDb Stage 4
Created `QBankStudyStateStore` and moved the following SQL/state responsibilities behind it:
- `progress_v2` read/write/delete/bulk replacement;
- `progress_meta` access and atomic resume metadata transaction;
- study streak/reminder/notification state;
- Home bookmark/progress aggregates;
- append-only study-attempt history and reconciliation.

QBankDb remains the public compatibility facade. Existing method signatures and callers are preserved.

## Regression protection
Added `QBankStudyStateExtractionTest` using the production QBankDb facade.
Added `idleAdmissionDoesNotUseIncompatibleBackoffCriteria` to the recovery admission suite.
Updated CI source identity checks for version 655, the study-state extraction, and the no-backoff idle-job invariant.

## Scope isolation
No changes to theme, animation, sound, Home visual design, borders, color grading, Pandora renderer, or general interaction UX are included in this release.

## Static verification
- Changed Kotlin delimiter balance: PASS
- QBankDb method-name preservation: PASS; no public method-name removals/additions from baseline
- No unrelated source files changed: PASS for source changes outside the explicitly listed QBank/worker/test/workflow files
- Coroutine cancellation audit: PASS (0 runCatching-sensitive coroutine files; 0 missing obvious cancellation/result boundaries)
- Search/QBank regression script: PASS for its first five checks, then stopped on a pre-existing contention gate (`QBank library critical visibility path still depends on serialized qbank-worker`); this was not introduced by v8.3.566 and was not changed in this batch.

## Build boundary
Local Gradle compilation attempted with `./gradlew :app:compileDebugKotlin --offline --no-daemon --stacktrace` but remains BLOCKED because Gradle 9.3.1 cannot resolve `downloads.gradle.org` in this environment.

Therefore:
- Android compile: BLOCKED
- JVM/instrumented tests in this environment: BLOCKED
- GitHub Actions CI: PENDING
- Device validation: PENDING
- APK/signing/SHA verification: PENDING

Do not label this source CI-green/device-verified until those gates actually pass.
