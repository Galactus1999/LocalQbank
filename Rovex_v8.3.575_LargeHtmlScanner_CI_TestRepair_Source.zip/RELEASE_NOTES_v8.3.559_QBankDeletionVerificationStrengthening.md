# Rovex v8.3.559 — QBank Deletion Verification Strengthening

## Baseline
- Previous source: v8.3.558 / versionCode 647
- Current source: v8.3.559 / versionCode 648
- Application ID: `com.localqbank.library`
- Scope: deletion/recovery characterization and WorkManager admission verification only
- Delete-manager extraction: **NOT performed**; characterization remains the gate before extraction.

## Changes

### 1. Strengthened deletion interruption characterization
`QBankDeletionIsolationTest` now exercises a real multi-batch source and interrupts after one destructive batch. It verifies:
- exactly one bounded batch is removed;
- the source remains tombstoned and absent from the visible catalog;
- the unrelated QBank remains intact;
- pending deletion remains durable;
- a later production `deleteSource()` pass resumes and completes the same deletion.

### 2. Recovery admission instrumented coverage
Added `QBankDeletionRecoveryAdmissionTest` covering:
- every admitted recovery request carries `DeviceIdle`;
- a pre-migration unique request is replaced with the constrained request;
- the migration marker is persisted only after replacement admission;
- subsequent admission uses `KEEP` and does not repeatedly recreate work;
- the recovery-needed marker is synchronously persisted and visible through a fresh Context wrapper.

Actual DeviceIdle execution remains a physical-device validation item; these tests do not claim to simulate Android idle state.

### 3. CI/source identity advanced
- versionName: `8.3.559`
- versionCode: `648`
- CI workflow identity and artifact name advanced to v8.3.559.
- Phase-0 mandatory instrumented-test gate now includes `QBankDeletionRecoveryAdmissionTest`.

## Offline verification
PASS:
- Phase-0 offline gate
- ruthless static audit
- architecture audit
- coroutine cancellation audit
- defect regression gates
- root architecture gate
- QBank/search regression gates
- performance/search architecture gate
- XML/type/delimiter structural checks

BLOCKED:
- Gradle/JVM execution: wrapper distribution `gradle-9.3.1` is not locally installed and `downloads.gradle.org` cannot be resolved in this offline environment.

PENDING:
- Android instrumented execution
- GitHub Actions CI
- physical-device deletion/recovery validation
- release/build/signing verification

No BUILD PASS, CI PASS, INSTRUMENTED TEST PASS, DEVICE PASS, or RELEASE VERIFIED claim is made by this offline repair.
