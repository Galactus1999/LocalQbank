# Rovex v8.3.565 — Deep Scan + Pandora Visual Repair

- Version: 8.3.565
- versionCode: 654
- Package: `com.localqbank.library`

## Repairs
- Restored missing Pandora renderer helpers detected by focused Kotlin compilation.
- Upgraded Pandora mountains to smooth multi-depth curved ranges.
- Upgraded alien trees to asymmetric path geometry with subtle bioluminescent veins.
- Upgraded flowers to Bezier petals, stalks, leaves, cores and filaments.
- Added restrained aurora veils and a curved luminous water/ground channel.
- Improved pulsing fireflies and seed motes while retaining the existing ~8 FPS animation budget.
- Fixed Pandora peacock-text contrast and Settings preview swatch.
- Fixed stale `QBankLoadingEngine.loadSectionBundle()` callbacks after cache invalidation.
- Removed obsolete unused private helpers.

## Verification boundary
Static/deep-source audits and focused Android-stub Kotlin compilation pass. Full Android Gradle/CI/device validation is still required before release status can be upgraded.
