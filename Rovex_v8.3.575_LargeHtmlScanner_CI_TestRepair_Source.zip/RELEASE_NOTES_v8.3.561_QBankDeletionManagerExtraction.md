# Rovex v8.3.561 — QBank Deletion Manager Extraction

- Version: v8.3.561 / versionCode 650
- Starting baseline: v8.3.560 QBank deletion visibility repair.
- Extracted the physical, resumable `QBankDb.deleteSource()` implementation into `QBankSourceDeletionManager`.
- `QBankDb.deleteSource()` remains the compatibility facade and delegates to the extracted manager.
- Preserved durable tombstone, bounded question deletion, cursor isolation, progress cleanup, search-index garbage marking, deferred FTS repair, recovery admission, and idempotent finalization.
- Manager resolves the provider-owned SQLite database per operation; it does not retain a stale database handle.
- Removed now-dead deletion helpers from `QBankDb`.
- Existing deletion/recovery tests continue to exercise the production `QBankDb.deleteSource()` delegation path.

Verification status:
- Static/source audit: pending final pass.
- Unit/instrumented/device/CI: not claimed here until executed.
