# Rovex v8.3.562 — Continue/Resume Cursor Repair

## Root cause
The Home Continue launch path was already structurally correct in the known-good v8.3.534 source. The regression risk was cursor arbitration: a stale `StudySessionStore` cursor could be newer by timestamp than the transactional SQLite resume cursor and therefore incorrectly win selection.

## Repair
- SQLite `last_resume_global` / `last_solved_global` cursors are authoritative when a valid durable cursor exists.
- `StudySessionStore` remains a fallback only when no durable transactional cursor is available.
- Home Continue now passes the exact resolved `questionId` to `QuizActivity` in addition to `testId` and `position`.
- Both the main Continue button and per-QBank Continue cards use the same exact-question launch contract.
- Added pure regression coverage for durable-cursor precedence and session fallback.

## Verification
- Static structural checks: PASS.
- Continue call-site audit: PASS.
- `QuizActivity` / `MainViewModel` regression scan: PASS.
- Local Gradle unit-test execution: BLOCKED because Gradle 9.3.1 is not cached and `downloads.gradle.org` cannot be resolved in the offline environment.
- CI/device verification: PENDING.
