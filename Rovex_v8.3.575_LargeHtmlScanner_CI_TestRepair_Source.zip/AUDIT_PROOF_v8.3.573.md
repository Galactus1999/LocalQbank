# v8.3.573 Source Audit Proof

## Input
Audited source baseline: v8.3.572 / versionCode 659.

## CI evidence reviewed
The supplied CI run completed `:app:compileDebugKotlin` and reached JVM tests, then failed:
- `LargeHtmlScannerRegressionTest.testArrayEmitsFirstQuestion`
- `LargeHtmlScannerRegressionTest.rootQuestionArrayEmitsFirstQuestion`
- `LargeHtmlScannerRegressionTest.rootQuestionArrayUsesQuestionAliasWhenTextAliasesAreAbsent`
- 145 tests completed, 3 failed
- `:app:testDebugUnitTest FAILED`

## Root causes
1. `LargeHtmlScanner.normalize()` used Kotlin Elvis chains directly on `JSONObject.opt()`. Explicit JSON null is `JSONObject.NULL`, not Kotlin null, so alias fallback stopped early and valid questions could be rejected.
2. `seekToDataArray()` searched raw JavaScript text and could match `TESTS_LIST = [` inside comments/strings.
3. `HtmlImportParser` had the same `JSONObject.NULL` sentinel hazard in two flexible-option helpers.
4. The source had stale CI workflows for v8.3.569/v8.3.570, while the source identified itself as v8.3.572. This could create duplicate/stale CI execution.
5. `setRequiresDeviceIdle(true)` and `setBackoffCriteria(...)` were checked only indirectly in the previous workflow; source audit confirms no current Kotlin file combines them.

## Repairs
- Added sentinel-aware `LargeHtmlScanner.firstNonNull()`.
- Hardened question, option, explanation and image alias resolution.
- Ignored `JSONObject.NULL` option values.
- Hardened `HtmlImportParser` equivalent helpers.
- Made scanner assignment discovery ignore JS line comments, block comments and quoted strings.
- Added regression tests for explicit JSON null alias fallback and comment false matches.
- Bumped source to v8.3.573 / versionCode 660.
- Removed stale 569/570 workflows and added one current `build-ben-qbank-573.yml`.
- Added a CI source gate that fails if any worker source contains both idle-mode admission and explicit backoff criteria.

## Static verification
- XML parse: PASS (37 XML files)
- Per-layout duplicate @+id scan: PASS
- `JSONObject.opt(...) ?: ...` scan: PASS — no remaining matches
- idle + explicit backoff same-file scan: PASS — no violations
- workflow YAML parse: PASS
- stale current-version assertions: PASS
- package/applicationId preserved: PASS by source inspection
- local Gradle test execution: BLOCKED because `downloads.gradle.org` DNS is unavailable in this environment

## Required external gate
Run the complete `build-ben-qbank-573` GitHub Actions workflow and inspect the full log. CI/device PASS is not claimed by this report.
