# Rovex v8.3.570 — QBank Re-import Tombstone Repair

## Root cause
A previously deleted QBank can remain physically present as an explicit tombstone while DeviceIdle recovery is deferred. Re-importing the same document identity synchronously attempted the entire physical deletion at the HTML import 28% boundary, so the UI appeared stuck.

## Repair
- Reclaims an existing import identity in bounded 8-batch deletion passes.
- Reports physical cleanup progress to the HTML import UI.
- Creates the replacement source only after the old tombstoned source is fully removed.
- Applies the same bounded replacement cleanup to normal HTML bundle imports.
- Added an instrumented regression test for explicit-tombstone re-import.
- Preserves DeviceIdle maintenance recovery and existing deletion isolation contracts.

Version: 8.3.570
VersionCode: 658


## CI regression-test repair

The failed v8.3.568 `LargeHtmlScannerTest` suite depended on a temporary scanner `scan(): Int`/progress constructor that was reverted. v8.3.570 adds regression tests against the actual scanner API, covering first-element emission for both test-array and root-question-array imports.
