# Rovex v8.3.573 — Scanner Null-Safety + Deep Audit Repair

## Version
- versionName: `8.3.573`
- versionCode: `660`
- package/applicationId: `com.localqbank.library`

## Root cause fixed
`org.json.JSONObject.opt()` may return `JSONObject.NULL` for an explicit JSON null. Kotlin's Elvis operator does not treat that sentinel as null. The streaming QBank scanner therefore stopped an alias chain at `JSONObject.NULL`, converted it to the literal string `"null"`, and rejected otherwise valid questions.

## Fix
- Added sentinel-aware `firstNonNull()` selection in `LargeHtmlScanner`.
- Applied the same protection to question text, options, explanations, and image fields.
- Prevented `JSONObject.NULL` option values from becoming literal `"null"` options.
- Hardened equivalent `HtmlImportParser` option/value helpers.

## Regression coverage
`LargeHtmlScannerRegressionTest.explicitJsonNullDoesNotMaskQuestionAndOptionAliases` verifies that explicit JSON nulls do not mask fallback aliases.

## CI/workflow hygiene
- Removed stale duplicate 8.3.569/8.3.570 workflows.
- Added one current `build-ben-qbank-573.yml`.
- Version and APK proof assertions target 8.3.573 / versionCode 660.

## Verification status
This source has been statically audited. CI/device verification remains pending until the new workflow actually executes.
