package com.localqbank.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** UI state owned by FlashcardViewModel; contains no Android Views or Context. */
data class FlashcardUiState(
    val decks: List<FlashcardDb.Deck> = emptyList(),
    val reviewCount: Int = 0,
    val bookmarkCount: Int = 0,
    val dueStats: FlashcardDb.DueStats = FlashcardDb.DueStats(0, 0, 0, 0, 0),
    val reviewedToday: Int = 0,
    val totalReviews: Int = 0,
    val allCardCount: Int = 0,
    val dailyNewLimit: Int = 30,
    val dailyReviewLimit: Int = 200,
    val settings: Map<String, String> = emptyMap(),
    val modeCounts: Map<String, Int> = emptyMap(),
    val deckDueStats: Map<Long, FlashcardDb.DueStats> = emptyMap(),
    val loading: Boolean = true,
    val error: String? = null
)

class FlashcardViewModel(private val repository: FlashcardReviewRepository) : ViewModel() {
    private val _uiState = MutableStateFlow(FlashcardUiState())
    val uiState: StateFlow<FlashcardUiState> = _uiState.asStateFlow()

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val decks = repository.decks()
                FlashcardUiState(
                    decks = decks,
                    reviewCount = repository.reviewCount(),
                    bookmarkCount = repository.bookmarkCount(),
                    dueStats = repository.dueStatsAll(),
                    reviewedToday = repository.reviewedToday(),
                    totalReviews = repository.totalReviews(),
                    allCardCount = repository.modeCount("all"),
                    dailyNewLimit = repository.settingInt("new_per_day", 30),
                    dailyReviewLimit = repository.settingInt("max_reviews_per_day", 200),
                    settings = repository.settingsSnapshot(),
                    modeCounts = listOf("due", "all", "unseen", "hard", "again", "bookmarked", "marked").associateWith { mode -> repository.modeCount(mode) },
                    deckDueStats = decks.associate { deck -> deck.id to repository.dueStats(deck.id) },
                    loading = false
                )
            }.onSuccess { _uiState.value = it }
             .onFailure { _uiState.value = _uiState.value.copy(loading = false, error = it.message ?: it.javaClass.simpleName) }
        }
    }

    fun saveSettings(values: Map<String, String>) {
        viewModelScope.launch(Dispatchers.IO) {
            values.forEach { (key, value) -> repository.setSetting(key, value) }
            refresh()
        }
    }

    fun unsuspendDeck(deckId: Long, includeChildren: Boolean, callback: (Int) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val count = repository.unsuspendDeck(deckId, includeChildren)
            withContext(Dispatchers.Main) { callback(count) }
            refresh()
        }
    }

    fun deleteDeck(deckId: Long, includeSubdecks: Boolean, callback: (Int) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val count = repository.deleteDeck(deckId, includeSubdecks)
            withContext(Dispatchers.Main) { callback(count) }
            refresh()
        }
    }

    fun deleteDeckTree(name: String, callback: (Int) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val count = repository.deleteDeckTree(name)
            withContext(Dispatchers.Main) { callback(count) }
            refresh()
        }
    }

    override fun onCleared() {
        repository.close()
        super.onCleared()
    }
}

class FlashcardViewModelFactory(private val repository: FlashcardReviewRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        require(modelClass.isAssignableFrom(FlashcardViewModel::class.java))
        return FlashcardViewModel(repository) as T
    }
}
