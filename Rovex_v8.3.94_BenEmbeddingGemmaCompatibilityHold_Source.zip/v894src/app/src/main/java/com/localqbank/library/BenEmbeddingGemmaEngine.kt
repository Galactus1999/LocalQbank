package com.localqbank.library

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * EmbeddingGemma adapter compatibility hold.
 *
 * The stable Maven Android MediaPipe Text Embedder artifact currently available to Rovex CI
 * is 0.10.35, while the public EmbeddingGemma TextFormatContext API is not present there.
 * We therefore fail closed instead of invoking an incompatible runtime. Deterministic retrieval
 * remains authoritative until a stable, resolvable EmbeddingGemma Android runtime is integrated.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)
    data class Result<T>(val hits: List<SemanticHit<T>>, val elapsedMs: Long, val usedModel: Boolean)

    private fun unavailableReason(): String =
        "EmbeddingGemma backend unavailable: stable MediaPipe Android artifact lacks the required TextFormatContext API"

    suspend fun <T> rerank(
        query: String,
        candidates: List<T>,
        textOf: (T) -> String,
        limit: Int = 8
    ): Result<T> = withContext(Dispatchers.Default) {
        models.installed(profile)
        policy.mayStartModel(profile.estimatedModelMb)
        governor.mayRun(policy, profile.estimatedRuntimeMb)
        BenNeuralTelemetry.error(unavailableReason())
        Result(candidates.take(limit.coerceAtLeast(0)).map { SemanticHit(it, 0.0) }, 0L, false)
    }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.Default) {
        models.installed(profile)
        BenNeuralTelemetry.error(unavailableReason())
        null
    }
}
