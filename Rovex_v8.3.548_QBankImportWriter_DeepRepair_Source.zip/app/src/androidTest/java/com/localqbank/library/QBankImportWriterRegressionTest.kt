package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Regression coverage for the physical QBankImportWriter extraction.
 * These tests deliberately exercise the public QBankDb.importBundle() path so that
 * the facade -> writer -> SQLite -> index lifecycle cannot silently diverge.
 */
@RunWith(AndroidJUnit4::class)
class QBankImportWriterRegressionTest {
    private lateinit var context: Context
    private lateinit var db: QBankDb

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
    }

    private fun question(index: Int, withMedia: Boolean = false) = ImportedQuestion(
        sourceId = "source-$index",
        text = "writer-question-$index",
        rawText = "raw-$index",
        correctAnswer = "A",
        explanation = "explanation-$index",
        bot = "bot-$index",
        video = "video-$index",
        audio = "audio-$index",
        options = listOf(
            ImportedOption("A", "answer-a-$index", true),
            ImportedOption("B", "answer-b-$index", false)
        ),
        questionImages = if (withMedia) listOf("question-image-$index") else emptyList(),
        explanationImages = if (withMedia) listOf("explanation-image-$index") else emptyList()
    )

    private fun testBundle(count: Int, withMedia: Boolean = false) = listOf(
        ImportedTest(
            originalId = "writer-test",
            title = "Writer Test",
            path = "writer/path",
            totalMarks = count.toDouble(),
            duration = 60,
            timePerQuestion = 1.5,
            questions = (0 until count).map { question(it, withMedia) },
            seriesNumber = "1"
        )
    )

    @Test
    fun smallImportPersistsNormalizedRowsMediaFtsAndProgress() {
        val progress = mutableListOf<Pair<Int, Int>>()
        val imported = db.importBundle(
            "writer-small",
            "writer-small.html",
            "TEST",
            testBundle(3, withMedia = true)
        ) { done, total -> progress += done to total }

        assertEquals(3, imported)
        assertEquals(1, db.sources().size)
        assertEquals(1, db.tests(db.sources().single().id).size)
        assertEquals(3, db.questionCount(db.tests(db.sources().single().id).single().id))
        assertTrue(progress.contains(1 to 3))
        assertTrue(progress.contains(3 to 3))

        val raw = context.openOrCreateDatabase("qbank.db", 0, null)
        raw.rawQuery("SELECT COUNT(*) FROM option_item", null).use { c ->
            assertTrue(c.moveToFirst())
            assertEquals(6, c.getInt(0))
        }
        raw.rawQuery("SELECT COUNT(*) FROM question_image", null).use { c ->
            assertTrue(c.moveToFirst())
            assertEquals(6, c.getInt(0))
        }
        raw.rawQuery("SELECT COUNT(*) FROM question_fts", null).use { c ->
            assertTrue(c.moveToFirst())
            assertEquals(3, c.getInt(0))
        }
        raw.close()

        assertEquals(1, db.search("writer-question-2").size)
    }

    @Test
    fun largeImportCrossesWriterBatchBoundaryWithoutLoss() {
        val progress = mutableListOf<Int>()
        val imported = db.importBundle(
            "writer-large",
            "writer-large.html",
            "TEST",
            testBundle(501)
        ) { done, total ->
            assertEquals(501, total)
            progress += done
        }

        assertEquals(501, imported)
        val source = db.sources().single()
        val test = db.tests(source).single()
        assertEquals(501, test.count)
        assertEquals(501, db.questionCount(test.id))
        assertTrue(progress.contains(1))
        assertTrue(progress.contains(250))
        assertTrue(progress.contains(500))
        assertTrue(progress.contains(501))
        assertEquals(1, db.search("writer-question-500").size)
    }

    @Test
    fun writerFailureRemovesPartialSourceAndDoesNotExposeHalfImport() {
        val raw = context.openOrCreateDatabase("qbank.db", 0, null)
        raw.execSQL(
            "CREATE TRIGGER fail_writer_import AFTER INSERT ON question " +
                "WHEN NEW.text='writer-question-2' BEGIN SELECT RAISE(ABORT, 'intentional writer regression test'); END"
        )
        raw.close()

        var failed = false
        try {
            db.importBundle("writer-fail", "writer-fail.html", "TEST", testBundle(5))
        } catch (_: Exception) {
            failed = true
        }

        assertTrue(failed)
        assertTrue(db.sources().isEmpty())
        assertEquals(0, db.search("writer-question-0").size)
        assertEquals(0, db.search("writer-question-2").size)

        val check = context.openOrCreateDatabase("qbank.db", 0, null)
        check.rawQuery("SELECT COUNT(*) FROM question", null).use { c ->
            assertTrue(c.moveToFirst())
            assertEquals(0, c.getInt(0))
        }
        check.execSQL("DROP TRIGGER IF EXISTS fail_writer_import")
        check.close()
    }

    @Test
    fun emptyImportDoesNotCreateSourceOrMutateCatalog() {
        val before = db.sources().size
        val imported = db.importBundle("writer-empty", "writer-empty.html", "TEST", emptyList())
        assertEquals(0, imported)
        assertEquals(before, db.sources().size)
        assertFalse(db.sources().any { it.fileName == "writer-empty" })
    }
    @Test
    fun committedImportSurvivesSearchIndexFinalizationFailure() {
        val context = this.context
        val raw = context.openOrCreateDatabase("qbank.db", 0, null)
        val writer = QBankImportWriter(
            db = raw,
            deleteSource = { sourceId -> db.deleteSource(sourceId, repairSearchIndex = false) },
            markSearchIndexDirty = { },
            finalizeSearchIndex = { throw IllegalStateException("intentional index-finalization failure") }
        )

        val imported = writer.import(
            importKey = "writer-finalize-failure",
            displayName = "writer-finalize-failure.html",
            provider = "TEST",
            tests = testBundle(2),
            onProgress = { _, _ -> }
        )

        assertEquals(2, imported)
        assertEquals(1, db.sources().size)
        val source = db.sources().single()
        val test = db.tests(source).single()
        assertEquals(2, db.questionCount(test.id))
        raw.close()
    }

    @Test
    fun sameDisplayNameWithDifferentImportKeysRemainsDistinct() {
        db.importBundle("writer-document-a", "index.html", "TEST", testBundle(2))
        db.importBundle("writer-document-b", "index.html", "TEST", testBundle(3))

        assertEquals(2, db.sources().size)
        val counts = db.sources().map { db.tests(it).sumOf { test -> test.count } }.sorted()
        assertEquals(listOf(2, 3), counts)
    }

}
