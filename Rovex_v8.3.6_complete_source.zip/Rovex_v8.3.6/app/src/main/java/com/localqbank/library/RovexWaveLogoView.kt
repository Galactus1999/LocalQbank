package com.localqbank.library

import android.content.Context
import android.graphics.BitmapFactory
import android.util.AttributeSet
import android.widget.ImageView

/**
 * Stable in-app Rovex logo. The supplied logo artwork is already a complete opaque
 * mark/wordmark, so it must not be used as an alpha mask for a gradient; doing that
 * painted the entire rectangular bitmap as a color block.
 */
class RovexWaveLogoView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ImageView(context, attrs) {
    init {
        scaleType = ScaleType.CENTER_INSIDE
        setImageResource(R.drawable.rovex_mark)
        contentDescription = "Rovex logo"
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // Keep a stable static bitmap; no per-frame animation or masking is needed here.
        if (drawable == null) setImageBitmap(BitmapFactory.decodeResource(resources, R.drawable.rovex_mark))
    }
}
