package com.localqbank.library

import android.content.Context
import kotlin.math.max

/**
 * Study Intelligence layer: deterministic, local and explainable.
 * It converts a user's natural subject/topic text into a ranked question pool.
 * No network service or opaque remote model is required.
 */
class StudyIntelligenceManager(context: Context) {
    private val app = context.applicationContext

    data class SubjectMatch(val ids: LongArray, val matched: Int, val subject: String)

    fun matchSubject(subject: String, limit: Int = Int.MAX_VALUE): SubjectMatch {
        val q = subject.trim()
        if (q.isBlank()) return SubjectMatch(longArrayOf(), 0, q)
        val tokens = q.lowercase().split(Regex("[^a-z0-9]+" )).filter { it.length >= 2 }.distinct()
        val refs = PerformanceManager.refs(app)
        val progress = PerformanceManager.progress(app)
        val now = System.currentTimeMillis()
        val ranked = refs.mapNotNull { ref ->
            var score = 0
            tokens.forEach { t ->
                if (ref.category.contains(t, true)) score += 70
                if (ref.testTitle.contains(t, true)) score += 55
                if (ref.sourceName.contains(t, true)) score += 30
                if (ref.text.contains(t, true)) score += 8
            }
            if (score == 0) return@mapNotNull null
            val r = progress.record(ref.stableKey)
            // Study intelligence favours questions that are due, wrong or unseen.
            if (r == null) score += 18
            else if (r.status == "wrong") score += 25
            else if (r.nextDue == 0L || now >= r.nextDue) score += 15
            else if (r.status == "correct") score -= 5
            Triple(ref, score, max(0, r?.attempts ?: 0))
        }.sortedWith(compareByDescending<Triple<QuestionRef, Int, Int>> { it.second }.thenBy { it.third })
        val selected = ranked.take(limit.coerceAtLeast(1)).map { it.first.id }.toLongArray()
        return SubjectMatch(selected, ranked.size, q)
    }


    fun smartMix(limit: Int = 100): LongArray {
        val refs = PerformanceManager.refs(app)
        val progress = PerformanceManager.progress(app)
        val now = System.currentTimeMillis()
        val model = runCatching { AppManagers.adaptive.state().userModel }.getOrDefault("cold")
        return refs.map { ref ->
            val r = progress.record(ref.stableKey)
            var score = 0
            when { r == null -> score += if (model == "cold") 40 else 20
                r.status == "wrong" -> score += if (model == "weak") 55 else 35
                r.nextDue == 0L || now >= r.nextDue -> score += 45
                r.status == "correct" -> score += if (model == "strong") 20 else 5 }
            score += (ref.category.length.coerceAtMost(20) / 10)
            ref.id to score
        }.sortedByDescending { it.second }.take(limit.coerceAtLeast(1)).map { it.first }.toLongArray()
    }

    fun explain(subject: String, count: Int): String =
        if (count == 0) "No strong matches found. Try a broader subject name, e.g. Pharmacology or Cardiology."
        else "Matched $count questions for “$subject”. Due, wrong and unseen questions are prioritised."
}
