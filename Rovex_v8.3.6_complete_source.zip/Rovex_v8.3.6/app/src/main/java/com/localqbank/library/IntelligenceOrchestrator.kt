package com.localqbank.library

/**
 * User-facing intelligence facade. Simple commands go directly to a specialist;
 * multi-engine requests are escalated to BIO. This keeps the common path fast.
 */
class IntelligenceOrchestrator(context: android.content.Context) {
    private val app = context.applicationContext

    data class Plan(val command: String, val questionIds: LongArray, val explanation: String, val orchestrated: Boolean = false)

    fun plan(command: String, limit: Int = 50): Plan {
        val text = command.trim()
        if (text.isBlank()) return Plan(text, longArrayOf(), "Tell me a subject, topic, or study goal.")
        val complex = AppManagers.bio.shouldOrchestrate(text)
        if (complex) {
            val routed = AppManagers.bio.plan(text, limit)
            return Plan(text, routed.questionIds, routed.explanation, true)
        }
        val lower = text.lowercase()
        return when {
            "wrong" in lower || "mistake" in lower -> {
                val ids = AppManagers.studyIntelligence.smartMix(limit).filter { id ->
                    val ref = PerformanceManager.refs(app).firstOrNull { it.id == id } ?: return@filter false
                    PerformanceManager.progress(app).record(ref.stableKey)?.status == "wrong"
                }.take(limit).toLongArray()
                Plan(text, ids, "Prioritised your wrong questions.")
            }
            "flashcard" in lower || "flash card" in lower -> Plan(text, longArrayOf(), "Use the Flashcard Engine for this direct action.")
            else -> {
                val match = AppManagers.studyIntelligence.matchSubject(text, limit)
                Plan(text, match.ids, AppManagers.studyIntelligence.explain(text, match.matched))
            }
        }
    }

    fun respond(command: String, currentQuestion: Question? = null): RenCognitiveEngine.Insight =
        AppManagers.renCognitive.answer(command, currentQuestion)

    fun createFlashcardsFromPlan(plan: Plan, reason: String = "Ren plan"): FlashcardIntelligenceManager.Result =
        AppManagers.flashcardIntelligence.createFromQuestions(plan.questionIds, reason)

    fun captureKnowledge(question: Question, reason: String = "Ren capture"): KnowledgeEngineManager.Result =
        AppManagers.knowledge.captureQuestion(question, reason)
}
