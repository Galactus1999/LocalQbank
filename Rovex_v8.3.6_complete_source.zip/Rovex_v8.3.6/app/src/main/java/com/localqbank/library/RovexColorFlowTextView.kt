package com.localqbank.library

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.TextView

/** Configurable two-colour flowing text. Preferences are shared across all flow labels. */
class RovexColorFlowTextView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : TextView(context, attrs) {
    private var animator: ValueAnimator? = null
    private var phase = 0f
    override fun onAttachedToWindow() { super.onAttachedToWindow(); startFlow() }
    override fun onDetachedFromWindow() { animator?.cancel(); animator = null; paint.shader = null; super.onDetachedFromWindow() }
    private fun startFlow() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3000L; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { phase = it.animatedValue as Float; applyFlow(); invalidate() }
            start()
        }
    }
    private fun applyFlow() {
        if (!flowEnabled(context) || width <= 0 || text.isNullOrBlank()) { paint.shader = null; return }
        val travel = width.toFloat() * 1.6f
        val start = -travel + phase * travel
        paint.shader = LinearGradient(start, 0f, start + travel, 0f, intArrayOf(colorOne(context), mix(colorOne(context), colorTwo(context), .5f), colorTwo(context), colorOne(context)), null, Shader.TileMode.MIRROR)
    }
    override fun onDraw(canvas: android.graphics.Canvas) { applyFlow(); super.onDraw(canvas) }
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { super.onSizeChanged(w,h,oldw,oldh); applyFlow() }
    companion object {
        private const val PREFS = "ui"
        private const val FLOW = "flow_text_enabled"
        private const val C1 = "flow_text_color_1"
        private const val C2 = "flow_text_color_2"
        fun flowEnabled(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(FLOW, true)
        fun colorOne(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(C1, Color.rgb(255,59,48))
        fun colorTwo(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(C2, Color.rgb(255,212,59))
        fun mix(a:Int,b:Int,t:Float):Int = Color.rgb((Color.red(a)+(Color.red(b)-Color.red(a))*t).toInt(),(Color.green(a)+(Color.green(b)-Color.green(a))*t).toInt(),(Color.blue(a)+(Color.blue(b)-Color.blue(a))*t).toInt())
    }
}
