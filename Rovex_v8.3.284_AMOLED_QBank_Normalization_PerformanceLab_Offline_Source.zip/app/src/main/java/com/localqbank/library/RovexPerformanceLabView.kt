package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

/** Compact graphical Performance Lab panel; all metrics remain driven by real study data. */
class RovexPerformanceLabView @JvmOverloads constructor(context:Context,attrs:AttributeSet?=null):View(context,attrs){
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private var accuracy=0;private var solved=0;private var wrong=0
    fun setUserStats(a:Int,s:Int,w:Int){accuracy=a.coerceIn(0,100);solved=s.coerceAtLeast(0);wrong=w.coerceAtLeast(0);invalidate()}
    fun setScores(a:Int,s:Int,w:Int){}
    override fun onDraw(c:Canvas){
        val d=resources.displayMetrics.density;val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0)return
        val panel=if(ThemeManager.get(context)==ThemeManager.AMOLED_DARK)Color.rgb(24,27,34) else ThemeManager.panel(context);paint.style=Paint.Style.FILL;paint.color=panel;c.drawRoundRect(0f,0f,w,h,20*d,20*d,paint)
        paint.color=ThemeManager.muted(context);paint.textSize=8.5f*d;paint.isFakeBoldText=true;c.drawText("PERFORMANCE LAB",14*d,18*d,paint);paint.isFakeBoldText=false
        paint.color=if(ThemeManager.get(context)==ThemeManager.AMOLED_DARK)Color.rgb(127,231,226) else ThemeManager.accent(context);paint.textSize=15*d;paint.isFakeBoldText=true;c.drawText("${accuracy}%",14*d,39*d,paint);paint.isFakeBoldText=false;paint.color=ThemeManager.muted(context);paint.textSize=7.5f*d;c.drawText("ACCURACY",14*d,49*d,paint)
        val left=76*d;val right=w-14*d;fun bar(y:Float,label:String,value:Int,fraction:Float,fill:Int){paint.color=ThemeManager.muted(context);paint.textSize=7.5f*d;c.drawText(label,left,y-4*d,paint);paint.color=Color.argb(30,255,255,255);c.drawRoundRect(left,y,right,y+6*d,3*d,3*d,paint);paint.color=fill;c.drawRoundRect(left,y,left+(right-left)*fraction.coerceIn(0f,1f),y+6*d,3*d,3*d,paint);paint.textAlign=Paint.Align.RIGHT;paint.color=fill;paint.isFakeBoldText=true;c.drawText(value.toString(),right,y-4*d,paint);paint.isFakeBoldText=false;paint.textAlign=Paint.Align.LEFT)}
        val total=maxOf(1,solved);bar(28*d,"Solved",solved,solved/total.toFloat(),Color.rgb(255,183,77));bar(55*d,"Wrong",wrong,wrong/total.toFloat(),Color.rgb(79,195,247))
        paint.color=ThemeManager.muted(context);paint.textSize=7.5f*d;c.drawText("Continue last study position  ›",14*d,h-11*d,paint)
    }
}
