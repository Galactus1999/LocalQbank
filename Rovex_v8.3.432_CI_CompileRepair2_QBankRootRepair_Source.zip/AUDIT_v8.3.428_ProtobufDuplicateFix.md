# Audit v8.3.428

## CI evidence
`logs_98150414878.zip` shows JVM unit tests succeeded, followed by release failure at `:app:checkReleaseDuplicateClasses`. The failure lists duplicate classes between protobuf-java-4.32.1.jar and protobuf-javalite-3.25.5.jar.

## Source evidence
No Rovex production Kotlin/Java source imports `com.google.protobuf`. The dependency was introduced transitively.

## Change
`app/build.gradle.kts` excludes `com.google.protobuf:protobuf-java` across configurations. This is intentionally narrower than removing or replacing the Android Lite protobuf runtime.

## Gate
This is not considered build-green until GitHub Actions completes the release build successfully.
