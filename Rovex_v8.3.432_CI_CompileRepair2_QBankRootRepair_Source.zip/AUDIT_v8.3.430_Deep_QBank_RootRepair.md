# Rovex v8.3.431 — Deep QBank / Ben / Frankenstein Root-Cause Audit

## Scope

Baseline: v8.3.429 QBank overload repair.

User-visible failure investigated:
- tapping/opening a QBank or sub-QBank could produce a black screen and process collapse;
- deleting one QBank could disturb other QBanks;
- QBank deletion could appear to fail or leave stale data;
- Ben+AI / Frankenstein could stop responding or become extremely slow after QBank operations;
- device CPU/thermal load could rise sharply.

## Root causes confirmed in source

### A. QBank deletion still had an unsafe physical-FTS coupling

v8.3.429 correctly removed the synchronous `DELETE FROM question_fts WHERE source_id=?`, but then marked the logical search index dirty immediately. Interactive search consequently had to treat FTS as unhealthy and could fall back to normalized-table search while maintenance was pending.

More importantly, FTS4 stores `source_id` as `UNINDEXED`; deleting by source can require a corpus-wide FTS scan. This is precisely the type of database work that must not share the foreground study path.

### B. Frankenstein still materialized the entire QBank corpus

`FrankensteinContextEngine.build()` called `PerformanceManager.refs(app)`, which loads every `QuestionRef`, including question text, before bounded semantic retrieval was resolved.

That made one AI context request proportional to the entire imported QBank corpus. The repair now resolves only the bounded question IDs returned by retrieval using `questionRefsForIdsBounded()`.

### C. Partial deletion could be visible as a live QBank

v8.3.429 deleted questions in batches but did not first hide/tombstone the source. A concurrent UI read could therefore observe a source while its question set was being progressively removed.

v8.3.431 adds `source.deleting` as a durable tombstone. User-facing source/test/question/search queries exclude tombstoned sources immediately.

### D. Process death during deletion had no durable resume boundary

v8.3.431 adds `QBankDeletionRecoveryWorker`. Tombstoned sources remain hidden and are safely resumed after process death/app restart.

### E. SQLite busy/lock contention could make deletion report failure

The deletion path now retries transient `SQLiteDatabaseLockedException` failures with bounded backoff and keeps each destructive transaction short.

A process-wide deletion lock also prevents two deletion/recovery operations from concurrently mutating the same QBank.

## v8.3.431 repair architecture

```text
User taps DELETE
       |
       v
short transaction: source.deleting = 1
       |
       +----> QBank disappears from navigation immediately
       |
       v
remove progress using indexed test_id
       |
       v
100-question bounded transactions
  - options
  - images
  - notes
  - legacy progress
  - questions
       |
       v
short final transaction
  - delete tests
  - delete source
  - verify zero remaining tests/questions
       |
       v
mark physical FTS garbage pending
       |
       v
IDLE-only maintenance compacts FTS
```

### Search invariant

FTS is an acceleration layer, not the authority.

After deletion, stale FTS rows may physically remain temporarily, but every interactive FTS result joins:

`question -> test -> source`

and requires `source.deleting=0`.

Therefore a deleted QBank cannot reappear in search, while the FTS index remains usable for other live QBanks. Physical cleanup is deferred to idle maintenance.

## AI repair

`FrankensteinContextEngine` no longer performs a full `PerformanceManager.refs(app)` load for each question context.

New flow:

```text
current question
      |
      v
bounded semantic/lexical IDs
      |
      v
questionRefsForIdsBounded(max 16)
      |
      v
load only required questions
```

This removes a major CPU/RAM/SQLite multiplier from Ben+AI / Frankenstein.

## Black-screen / crash mechanism

The source evidence supports a resource-contention chain rather than a single UI-color defect:

1. QBank deletion/search maintenance can compete for the SQLite writer.
2. Large QBanks make corpus-wide operations expensive.
3. Frankenstein previously materialized the entire QBank on a context request.
4. Quiz startup also performs database resolution and background progress initialization.
5. Under simultaneous load, the UI can miss frame/input deadlines; if native/VM memory or process pressure becomes severe, the Activity can disappear as a black screen followed by process termination.
6. v8.3.431 separates authoritative study data from optional FTS maintenance, tombstones deleting sources, bounds deletion transactions, and removes the full-corpus AI context scan.

The supplied screenshots demonstrate the symptom, but they are not a logcat/tombstone and therefore cannot prove a specific Android exception or signal. The source-level contention paths above are directly verified in the code.

## Regression checks

PASS:
- coroutine cancellation audit;
- performance/search architecture audit;
- search/QBank regression audit;
- ruthless static audit;
- Firebase OAuth configuration audit;
- XML/layout audit;
- MainActivity layout-ID audit;
- Kotlin delimiter balance for changed files;
- no `Thread.sleep()` introduced;
- no full-corpus `PerformanceManager.refs(app)` in Frankenstein/Ren context path;
- no synchronous FTS deletion by `source_id` in QBank deletion path;
- tombstoned sources excluded from source/test/question/search/AI retrieval paths.

New instrumented regression:
`QBankDeletionIsolationTest`

It verifies:
- deleting source A does not delete source B;
- source B remains launchable;
- source A question count becomes zero;
- source B question remains;
- search returns B's question;
- search does not return A's deleted question even while stale FTS garbage exists;
- logical FTS health remains clean;
- physical FTS cleanup is marked pending.

## Build proof

Attempted:
`./gradlew --offline :app:testDebugUnitTest --no-daemon`

Result: environment could not obtain Gradle 9.3.1 because `downloads.gradle.org` DNS resolution failed:

`curl: (6) Could not resolve host: downloads.gradle.org`

Therefore this audit does **not** claim a compiled APK or device-runtime pass.

## Acceptance status

Source/root repair: **COMPLETE**

Static/audit gate: **PASS**

Instrumented test added: **PASS at source/test-definition level; execution awaits Gradle/device environment**

Gradle compilation: **NOT VERIFIED — external environment/network gate**

APK/device crash reproduction: **NOT VERIFIED — requires successful build and installation**

## Recommended device proof sequence after CI build

1. Install v8.3.431.
2. Open QBank dashboard.
3. Expand a subject containing many QBanks.
4. Open one QBank/sub-QBank.
5. Open several questions.
6. Invoke Frankenstein and Ben+AI.
7. Delete one large QBank.
8. Immediately open a different QBank.
9. Repeat Frankenstein and Ben+AI.
10. Confirm the deleted QBank cannot be found by search/navigation.
11. Kill/restart the app during a large deletion and verify the tombstoned deletion resumes.
12. Confirm CPU/thermal behavior returns to normal after the foreground action rather than being held by FTS maintenance.

## External technical basis

Android's SQLite guidance recommends reading only required rows/columns, pushing aggregation/filtering into SQLite, using indexes, batching writes, and notes that only one write transaction can occur at a time. Those principles directly support the bounded deletion and set-based dashboard approach used here.
