# Rovex v8.3.431

## Deep QBank Root Repair

- Added durable `source.deleting` tombstone state.
- QBank deletion is now resumable and hidden from navigation before destructive work begins.
- Deleted questions are removed in 100-row transactions instead of one large writer transaction.
- Progress cleanup uses indexed `progress_v2.test_id` rather than wildcard stable-key scans.
- Removed synchronous FTS source deletion from the foreground delete path.
- Physical FTS garbage is deferred to idle maintenance; logical search remains live for unaffected QBanks.
- Added transient SQLite-lock retry and process-wide deletion serialization.
- Added `QBankDeletionRecoveryWorker` for process-death recovery.
- Added live-source filters throughout QBank/test/question/search retrieval paths.
- Removed full-corpus `PerformanceManager.refs(app)` materialization from Frankenstein question-context construction.
- Added bounded `questionRefsForIdsBounded()` retrieval for AI context.
- Added `QBankDeletionIsolationTest`.
- Preserved existing v8.3.429 QBank loading, search, and dashboard architecture.

## Verification

Static audits pass. Gradle compilation remains blocked in the current environment because Gradle 9.3.1 cannot be downloaded from `downloads.gradle.org` due DNS/network failure. No APK or device pass is claimed until CI/build verification succeeds.
