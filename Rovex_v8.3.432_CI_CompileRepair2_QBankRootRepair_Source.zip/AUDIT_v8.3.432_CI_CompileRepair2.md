# Rovex v8.3.432 — CI Compile Repair 2

## Trigger
CI log `logs_98162520581.zip` failed JVM unit-test compilation.

## Exact root causes
1. `FrankensteinContextEngine.kt` and `RenIntelligenceOrchestrator.kt` called `QBankDb.questionRefsForIdsBounded(...)`, but v8.3.431 did not actually define that method.
2. `QBankDeletionRecoveryWorker.kt` and `QBankSearchIndexMaintenanceWorker.kt` used `QBankDb(...).use { ... }`, but `QBankDb` is not `Closeable`; its `close()`-like shared database semantics are intentionally process-scoped.

The reported generic type-inference and unresolved-property errors were cascades from these missing contracts.

## Repair
- Added bounded `questionRefsForIdsBounded()` using a live-source SQL `IN` query, capped at 100 IDs, without materializing the QBank corpus.
- Kept the legacy `questionRefsForIds()` API but routed it through the bounded implementation.
- Added `pendingDeletingSourceIds()` for durable tombstone recovery.
- Removed invalid `use {}` calls around `QBankDb` from both workers.
- Preserved all v8.3.431 deletion isolation, tombstone, recovery, and deferred-FTS architecture.
- Version: 8.3.432 / versionCode 524.

## Proof
CI source errors are directly accounted for:
- `questionRefsForIdsBounded` now exists.
- `pendingDeletingSourceIds` now exists.
- No `QBankDb.use {}` remains in the new workers.
- Kotlin delimiter balance was rechecked after modification.

Full Gradle/Android build still requires the next CI run; no build-green claim is made here.
