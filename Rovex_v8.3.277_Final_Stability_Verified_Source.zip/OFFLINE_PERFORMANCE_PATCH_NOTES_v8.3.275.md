# Rovex v8.3.275 — Offline Performance + QBank Hierarchy Repair

## Changes
- Replaced the dashboard's per-question `QuestionRef` materialization + in-memory `groupBy` path with a single SQLite dashboard aggregation returning one row per test.
- Dashboard progress is aggregated directly from `progress_v2` using the stable question key.
- Section switching continues to reuse the immutable dashboard snapshot instead of re-querying for every tab change.
- QBank subject panels are now **lazy-rendered**: child QBank/test views are created only when a subject is expanded.
- QBank hierarchy now separates each of the fixed 19 subjects from collection type: QBank, PYQ, Custom, Subject Test, Image Test, and Other Test.
- Community Medicine and PSM remain one canonical subject.
- Cross-subject/unassigned collections are shown separately instead of silently being classified as a medical subject.
- Removed generated Python bytecode and Kotlin session artifacts from the source package.

## Verification performed offline
- Whole-project ruthless static audit: PASS.
- Architecture audit: PASS, with existing large-file warnings only.
- Dashboard source brace/parenthesis balance: PASS.
- Local Gradle compilation was attempted but could not start because the environment could not resolve `downloads.gradle.org`; no compile-green claim is made.
