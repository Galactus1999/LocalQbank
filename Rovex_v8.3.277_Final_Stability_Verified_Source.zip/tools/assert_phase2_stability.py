from pathlib import Path
import sys
r=Path(sys.argv[1] if len(sys.argv)>1 else ".")
d=next(r.rglob("RovexSectionDashboardActivity.kt")).read_text()
m=next(r.rglob("MainActivity.kt")).read_text()
f=next(r.rglob("BenQuestionAiContextDialog.kt")).read_text()
if d.count("private fun progress(")!=1: raise SystemExit("STABILITY: dashboard progress owner duplicated")
if "analyticsHero(rows)" not in d: raise SystemExit("STABILITY: QBank analytical hero missing")
if "setOnClickListener{if(r.testId.isNotBlank())" not in d: raise SystemExit("STABILITY: QBank subsection touch target missing")
if "sanitizeRovexAiDisplayText(it.text)" not in f: raise SystemExit("STABILITY: AI display sanitizer missing")
if not all(x in m for x in ("navHome","navQBank","navCards","navStats","navMastery")): raise SystemExit("STABILITY: five-section footer incomplete")
print("Phase-2 stability assertions PASS")
