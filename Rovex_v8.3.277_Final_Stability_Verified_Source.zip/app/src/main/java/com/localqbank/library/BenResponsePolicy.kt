package com.localqbank.library

/** Deterministic bounds and hygiene for text returned by optional Ben backends. */
object BenResponsePolicy {
    const val MAX_RESPONSE_CHARS = 16_384
    private val styleBlock = Regex("(?is)<style\\b[^>]*>.*?</style\\s*>")
    private val scriptBlock = Regex("(?is)<script\\b[^>]*>.*?</script\\s*>")
    private val htmlWrapper = Regex("(?is)</?(?:!doctype|html|head|body|main|section|article|div)(?:\\s+[^>]*)?>")
    private val cssProperty = Regex("(?i)\\b(?:font-family|font-size|line-height|margin(?:-[a-z]+)?|padding(?:-[a-z]+)?|color|background(?:-[a-z]+)?|border(?:-[a-z]+)?|border-radius|display|width|height|min-width|max-width|min-height|max-height|overflow|text-align|vertical-align|letter-spacing|font-weight|text-transform|object-fit|box-shadow|position|top|right|bottom|left|content)\\s*:")
    private val cssSelector = Regex("(?is)(?:[a-z][a-z0-9_-]*|[.#][a-z][a-z0-9_-]*)(?:\\s*(?:,|>|\\+|~)\\s*(?:[a-z][a-z0-9_-]*|[.#][a-z][a-z0-9_-]*))*")
    private val cssRule = Regex("(?s)(?:^|(?<=}))\\s*([^{}]{1,240})\\{([^{}]{1,5000})\\}")
    fun normalize(raw:String?):String? {
        var x=raw?.replace("\r\n","\n")?.replace("\r","\n") ?: return null
        x=x.replace(styleBlock," ").replace(scriptBlock," ").replace(htmlWrapper," ")
        repeat(5){x=cssRule.replace(x){m->val selector=m.groupValues[1].trim();val declarations=m.groupValues[2];if(cssSelector.matches(selector)&&cssProperty.containsMatchIn(declarations))" " else m.value}}
        return BoundedTextPolicy.normalize(x,MAX_RESPONSE_CHARS)
    }
}
