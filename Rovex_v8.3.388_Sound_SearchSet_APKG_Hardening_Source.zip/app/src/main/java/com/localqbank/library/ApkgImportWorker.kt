package com.localqbank.library

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/**
 * Process-death-safe owner for long-running APKG imports.
 * The importer itself remains the parser/transaction authority; this worker only owns lifecycle,
 * foreground execution, retry and persisted WorkManager state.
 */
class ApkgImportWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val control = ApkgImporter.Control()
        coroutineContext[ kotlinx.coroutines.Job ]?.invokeOnCompletion { control.cancelled = true }
        setForeground(createForegroundInfo("Preparing flashcard import…", 0))
        try {
            val uriString = inputData.getString(KEY_URI)
            val result = if (ApkgImporter.hasPending(applicationContext)) {
                ApkgImporter.resume(applicationContext, { message -> publishProgress(message) }, control)
            } else {
                require(!uriString.isNullOrBlank()) { "No APKG source was supplied." }
                ApkgImporter.importFile(applicationContext, android.net.Uri.parse(uriString), { message -> publishProgress(message) }, control)
            }
            setProgress(workDataOf("progress" to 100, "message" to "Import complete"))
            Result.success(workDataOf("cards" to result.cards, "decks" to result.decks, "skipped" to result.skipped))
        } catch (cancelled: CancellationException) {
            control.cancelled = true
            throw cancelled
        } catch (error: IllegalArgumentException) {
            Result.failure(workDataOf("error" to (error.message ?: "Invalid APKG")))
        } catch (error: java.io.IOException) {
            // Storage/provider failures are often transient; the checkpoint remains durable.
            Result.retry()
        } catch (error: Exception) {
            // A malformed/unsupported package must not enter an infinite WorkManager retry loop.
            // The durable checkpoint remains available for an explicit resume after repair.
            ProductionCrashReporter.breadcrumb(applicationContext, "ApkgImportWorker.failed:${error.javaClass.simpleName}")
            Result.failure(workDataOf("error" to (error.message ?: "Flashcard import failed")))
        }
    }

    private fun publishProgress(message: String) {
        val percent = when {
            message.contains("100%") -> 100
            message.contains("Importing cards…") -> parseFraction(message)
            else -> null
        }
        setProgressAsync(workDataOf("progress" to (percent ?: 0), "message" to message.take(220)))
        setForegroundAsync(createForegroundInfo(message.take(120), percent ?: 0))
    }

    private fun parseFraction(message: String): Int? {
        val m = Regex("Importing cards…\\s+(\\d+)/(\\d+)").find(message) ?: return null
        val a = m.groupValues[1].toLongOrNull() ?: return null
        val b = m.groupValues[2].toLongOrNull()?.coerceAtLeast(1L) ?: return null
        return ((a * 100L) / b).toInt().coerceIn(0, 99)
    }

    private fun createForegroundInfo(message: String, progress: Int): ForegroundInfo {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Flashcard imports", NotificationManager.IMPORTANCE_LOW))
        }
        val cancel = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(com.localqbank.library.R.drawable.rovex_launcher)
            .setContentTitle("Rovex flashcard import")
            .setContentText(message)
            .setProgress(100, progress.coerceIn(0, 100), progress <= 0)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancel)
            .build()
        return ForegroundInfo(NOTIFICATION_ID, notification)
    }

    companion object {
        const val KEY_URI = "apkg_uri"
        const val UNIQUE_WORK = "rovex_flashcard_import"
        private const val CHANNEL = "rovex_flashcard_imports"
        private const val NOTIFICATION_ID = 41021
    }
}
