package com.localqbank.library

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Move-only owner for accepted-answer presentation and milestone feedback.
 * It does not retain the host Activity; host-only operations are supplied as callbacks.
 */
class QuizAnswerPresentationController(
    private val context: Context,
    private val quizViewModel: QuizViewModel,
    private val content: () -> LinearLayout,
    private val host: () -> ViewGroup,
    private val counter: () -> TextView,
    private val isHostFinishing: () -> Boolean,
    private val sessionAnsweredCount: () -> Int,
    private val setSessionAnsweredCount: (Int) -> Unit,
    private val celebrationIndex: () -> Int,
    private val incrementCelebrationIndex: () -> Unit,
    private val dp: (Int) -> Int,
    private val rounded: (Int, Float) -> GradientDrawable,
    private val fontScale: () -> Float,
    private val fontFamily: () -> String,
    private val bookmarkButton: () -> TextView?,
    private val result: () -> TextView,
    private val enableScrollBar: () -> Unit,
    private val updateBookmarkButton: (Question, TextView) -> Unit,
    private val showMistakeTypeDialog: (Question) -> Unit,
    private val renderHtmlText: (String?, Float, Boolean, Int?, Long?, String) -> Unit,
    private val addImage: (String) -> Unit
) {
    fun triggerQuestionMilestone(): Boolean {
        val nextCount = sessionAnsweredCount() + 1
        setSessionAnsweredCount(nextCount)
        if (isHostFinishing()) return false
        val plan = RovexCelebrationPreferences.load(context)
        if (!RovexCelebrationPreferences.shouldCelebrate(nextCount, plan.targets)) return false
        val currentCelebrationIndex = celebrationIndex()
        incrementCelebrationIndex()
        val variant = RovexCelebrationPreferences.variantFor(plan, currentCelebrationIndex)
        runCatching {
            val hostView = host()
            val existing = hostView.findViewWithTag<RovexCelebrationView>("rovex_celebration_host")
            val celebration = existing ?: RovexCelebrationHost.install(hostView)
            val target = runCatching { counter() }.getOrElse { content() }
            celebration.post {
                if (!isHostFinishing()) celebration.celebrateAt(target, variant)
            }
        }.onFailure {
            ProductionCrashReporter.recordNonFatal(it, "QUIZ_MILESTONE_CELEBRATION")
        }
        return true
    }

    fun showAnsweredInPlace(q: Question, label: String, correct: Boolean) {
        val dark = ThemeManager.isDark(context)
        for (i in 0 until content().childCount) {
            val row = content().getChildAt(i) as? LinearLayout ?: continue
            val tag = row.tag?.toString() ?: continue
            if (!tag.startsWith("option:")) continue
            val optionLabel = tag.removePrefix("option:")
            val option = q.options.firstOrNull { it.label.equals(optionLabel, true) } ?: continue
            val isCorrect = option.correct || q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true || q.correctAnswer?.trim()?.equals(option.label.trim()+".", true) == true
            val isSelected = option.label.equals(label, true)
            val bg = when { isCorrect -> ThemeManager.correctBg(context); isSelected -> ThemeManager.wrongBg(context); else -> ThemeManager.elevated(context) }
            val fg = when { isCorrect -> ThemeManager.correctText(context); isSelected -> ThemeManager.wrongText(context); else -> ThemeManager.muted(context) }
            row.background = rounded(bg,20f); row.isClickable=false; row.isFocusable=false
            if (isSelected) {
                row.post {
                    if (correct) RovexPulseEffect.play(row) else RovexPulseEffect.shake(row)
                }
            }
            (row.getChildAt(0) as? TextView)?.apply { this.tag="quiz:option-label:" + if(isCorrect) "correct" else if(isSelected) "wrong" else "neutral"; setTextColor(fg); background=rounded(bg,50f) }
            (row.getChildAt(1) as? TextView)?.apply { this.tag="quiz:option:" + if(isCorrect) "correct" else if(isSelected) "wrong" else "neutral"; setTextColor(fg) }
        }
        val qContent = content()
        bookmarkButton()?.let { updateBookmarkButton(q, it) }
        result().visibility = View.GONE
        enableScrollBar()
        qContent.post {
            if (isHostFinishing() || quizViewModel.state.currentQuestion?.stableKey != q.stableKey) return@post
            try { appendAnswerDetails(q, !correct) }
            catch (e: Exception) {
                ProductionCrashReporter.recordNonFatal(e, "QUIZ_ANSWER_DETAILS", mapOf("question_key" to q.stableKey.take(120)))
            }
        }
    }

    fun appendAnswerDetails(q: Question, wrong: Boolean) {
        if (content().findViewWithTag<View>("explanation-panel:${q.stableKey}") != null) return
        if (wrong) {
            val why = TextView(context).apply {
                text = quizViewModel.mistakeType(q.stableKey)?.let { "Why I missed it: $it  •  Tap to change" } ?: "🧠 Why did I miss this?"
                textSize = 12.5f * fontScale(); setTypeface(null, Typeface.BOLD); setTextColor(ThemeManager.accent(context)); setPadding(dp(4),dp(10),dp(4),dp(4)); setOnClickListener{showMistakeTypeDialog(q)}
            }
            content().addView(why,LinearLayout.LayoutParams(-1,-2)); why.tag="explanation-why:${q.stableKey}"
        }
        val panel=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(4));background=rounded(ThemeManager.explanationBg(context),16f);tag="explanation-panel:${q.stableKey}"}
        panel.addView(TextView(context).apply{text="EXPLANATION";textSize=12.5f*fontScale();setTypeface(Typeface.create(fontFamily(),Typeface.BOLD));setTextColor(ThemeManager.explanationTitle(context));setLetterSpacing(.06f)},LinearLayout.LayoutParams(-1,dp(28)))
        content().addView(panel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(2))})
        renderHtmlText(rovexMarkdownBody(q.explanation ?: "<p>No explanation available.</p>", true),17f*fontScale(),false,ThemeManager.explanationText(context),q.id,"explanation")
        q.explanationImages.forEach{addImage(it)}
        val flashcardCta = TextView(context).apply {
            text = "MAKE FLASHCARD  •  ANSWER ONLY"
            textSize = 11.5f * fontScale()
            typeface = Typeface.DEFAULT_BOLD
            gravity = android.view.Gravity.CENTER
            setTextColor(ThemeManager.accent(context))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(context))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), ThemeManager.accent(context))
            }
            setPadding(dp(12), 0, dp(12), 0)
            contentDescription = "Make flashcard from this question"
            setOnClickListener {
                quizViewModel.createFlashcard(q.id, "Manual • ${if (wrong) "Wrong" else "Solved"}") { r ->
                    Toast.makeText(context, if (r.created > 0) "Flashcard created • answer-only reveal" else "Flashcard already exists", Toast.LENGTH_SHORT).show()
                }
            }
        }
        content().addView(flashcardCta, LinearLayout.LayoutParams(-1, dp(46)).apply { setMargins(0, dp(12), 0, dp(18)) })
    }
}
