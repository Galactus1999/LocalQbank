package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QBankSearchQueryBuilderTest {
    @Test fun allModeBuildsOnePredicatePerTokenAndTwelveArgsPerToken() {
        val plan = QBankSearchQueryBuilder.textLikePlan(listOf("acid", "base"), 400, true)
        assertTrue(plan.sql.contains(" AND "))
        assertEquals(24, plan.args.size)
        assertTrue(plan.sql.contains("ESCAPE CHAR(92)"))
    }

    @Test fun anyModeUsesOrWithoutChangingArgumentOrder() {
        val plan = QBankSearchQueryBuilder.textLikePlan(listOf("acid", "base"), 400, false)
        assertTrue(plan.sql.contains(" OR "))
        assertEquals("%acid%", plan.args.first())
        assertEquals("%base%", plan.args[12])
    }

    @Test fun specialLikeSyntaxIsEscapedThroughProductionHelper() {
        val plan = QBankSearchQueryBuilder.textLikePlan(listOf("%_\\"), 400, true)
        assertEquals(12, plan.args.size)
        assertEquals("%\\%\\_\\\\%", plan.args.first())
    }

    @Test fun rankingLikeClausesMustUseExplicitBackslashEscape() {
        val plan = QBankSearchQueryBuilder.textLikePlan(listOf("%_\\"), 400, true)
        val escapeCount = "ESCAPE CHAR(92)".toRegex().findAll(plan.sql).count()
        assertEquals(12, escapeCount)
    }

    @Test fun limitIsBounded() {
        assertTrue(QBankSearchQueryBuilder.textLikePlan(listOf("acid"), 0, true).sql.endsWith("LIMIT 1"))
        assertTrue(QBankSearchQueryBuilder.textLikePlan(listOf("acid"), 99999, true).sql.endsWith("LIMIT 1200"))
    }
}
