package com.localqbank.library

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseError
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

/**
 * Presentation layer for Rovex Online. It owns no online state: Firebase/Auth/Firestore remain
 * behind RovexOnlineAuth and RovexOnlineRepository.
 */
class RovexOnlineActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var content: LinearLayout
    private val repo by lazy { RovexOnlineRepository(this) }
    private val friendOutbox by lazy { RovexFriendRequestOutbox(this) }
    private val auth get() = FirebaseAuth.getInstance()
    private val presenceSubscriptions = mutableListOf<RovexPresenceManager.Subscription>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SystemUi.immersive(this)
        buildShell()
        render()
    }

    override fun onDestroy() {
        clearPresenceSubscriptions()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) {
            RovexOnlineRepository.syncNow(this)
            RovexOnlineRepository.syncFriendRequests(this)
            render()
        }
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            background = ThemeManager.backgroundDrawable(this@RovexOnlineActivity)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this@RovexOnlineActivity).apply {
            text = "←"; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RovexOnlineActivity))
            background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 16)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(50), dp(50)))
        header.addView(TextView(this@RovexOnlineActivity).apply {
            text = "Rovex Online"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setPadding(dp(13), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        status = TextView(this@RovexOnlineActivity).apply {
            textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)); setPadding(dp(3), dp(8), dp(3), dp(8))
        }
        root.addView(status)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        AdaptiveTypographyManager.apply(root)
    }

    private fun render() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val user = auth.currentUser
        if (user == null) renderSignedOut() else renderSignedIn(user)
    }

    private suspend fun <T> onlineResult(block: suspend () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (t: Exception) {
        Result.failure(t)
    }

    private fun renderSignedOut() {
        status.text = "Offline-first. Online features are optional."
        card("FRIENDS • PROGRESS • CHALLENGES") {
            add(TextView(this@RovexOnlineActivity).apply {
                text = "Connect Rovex to your Google account to create a private friend identity and sync competitive progress. QBank content, notes, PDFs and AI chats stay local."
                textSize = 12.5f; setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setPadding(0, 0, 0, dp(14))
            })
            add(action("CONTINUE WITH GOOGLE", ThemeManager.accent(this@RovexOnlineActivity)) {
                lifecycleScope.launch {
                    status.text = "Opening Google sign-in…"
                    val result = RovexOnlineAuth.signInWithGoogle(this@RovexOnlineActivity)
                    result.onSuccess { signedIn ->
                        status.text = "Signed in as ${RovexOnlineAuth.normalizedName(signedIn.displayName)}"
                        syncAndRender(signedIn)
                    }.onFailure { e ->
                        status.text = "Google sign-in failed: ${friendlyError(e)}"
                    }
                }
            })
        }
        card("WHAT GOES ONLINE") {
            add(TextView(this@RovexOnlineActivity).apply {
                text = "✓ profile name + Rovex ID\n✓ questions solved / correct / accuracy\n✓ study streak\n✓ XP and friend relationships\n\n✕ question text / answers\n✕ imported QBanks / APKGs\n✕ notes / PDFs\n✕ Ben / AI conversations"
                textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)); setLineSpacing(0f, 1.15f)
            })
        }
    }

    private fun renderSignedIn(user: FirebaseUser) {
        val network = hasValidatedInternet()
        status.text = if (network) "Internet available • ${RovexOnlineAuth.normalizedName(user.displayName)}"
        else "No validated internet • requests will queue"

        val code = RovexOnlineAuth.rovexId(user.uid)
        card("ROVEX ONLINE") {
            add(TextView(this@RovexOnlineActivity).apply {
                text = if (network) "Account connected" else "Account connected • offline mode"
                textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity))
            })
            add(TextView(this@RovexOnlineActivity).apply {
                text = code; textSize = 25f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.accent(this@RovexOnlineActivity)); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
            })
            val row = LinearLayout(this@RovexOnlineActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            row.addView(action("COPY ID", ThemeManager.accent(this@RovexOnlineActivity)) {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Rovex ID", code))
                toast("Rovex ID copied")
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(4) })
            row.addView(action("SHARE ID", ThemeManager.accent(this@RovexOnlineActivity)) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "My Rovex ID: $code")
                }, "Share Rovex ID"))
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(4) })
            add(row)
            add(action("SYNC NOW", ThemeManager.accent(this@RovexOnlineActivity)) { syncAndRender(user) })
            add(action("SIGN OUT", ThemeManager.muted(this@RovexOnlineActivity)) {
                lifecycleScope.launch { RovexOnlineAuth.signOut(this@RovexOnlineActivity); render() }
            })
        }

        card("MY PROGRESS") {
            add(TextView(this@RovexOnlineActivity).apply { text = "Loading…"; textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) })
        }
        lifecycleScope.launch { loadOwnProgress(user) }

        card("ADD FRIEND") {
            add(TextView(this@RovexOnlineActivity).apply {
                text = "Enter their Rovex ID. They do not need to be online."
                textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity))
            })
            val input = EditText(this@RovexOnlineActivity).apply {
                hint = "RVX-ABCD-1234"; textSize = 14f; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setHintTextColor(ThemeManager.muted(this@RovexOnlineActivity))
                background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 14); setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            add(input, LinearLayout.LayoutParams(-1, dp(52)))
            add(action("ADD / SEND REQUEST", ThemeManager.accent(this@RovexOnlineActivity)) { sendFriendRequest(input.text.toString()) })
            val pending = friendOutbox.size()
            if (pending > 0) add(TextView(this@RovexOnlineActivity).apply {
                text = "$pending request${if (pending == 1) "" else "s"} waiting for a connection. Rovex will retry automatically."
                textSize = 10.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity))
            })
        }
        loadSocial(user)
    }

    private suspend fun loadOwnProgress(user: FirebaseUser) {
        val projection = withContext(Dispatchers.IO) {
            runCatching {
                val progress = PerformanceManager.progress(applicationContext)
                val cards = SqliteFlashcardReviewRepository(applicationContext).use { it.totalReviews() }
                val streak = AppManagers.streak.snapshot()
                RovexOnlineProgressProjector.from(progress, cards, streak)
            }.getOrNull()
        } ?: return
        val profile = repo.identityProfile(user).copy(
            questionsSolved = projection.questionsSolved,
            correct = projection.correct,
            accuracyPercent = projection.accuracyPercent,
            todaySolved = projection.todaySolved,
            flashcardsReviewed = projection.flashcardsReviewed,
            currentStreak = projection.currentStreak,
            longestStreak = projection.longestStreak,
            xp = projection.xp,
            updatedAtMillis = projection.updatedAtMillis
        )
        // Keep the personal screen local-first. The Firestore write is best-effort and is queued
        // by Firestore persistence when offline; it is not required to render the user's data.
        withContext(Dispatchers.IO) {
            runCatching {
                Tasks.await(repo.ensureIdentityProfile(user), 8, TimeUnit.SECONDS)
                Tasks.await(repo.syncPersonalProgress(user, projection), 8, TimeUnit.SECONDS)
            }
        }
        if (auth.currentUser?.uid != user.uid) return
        var index = -1
        for (i in 0 until content.childCount) {
            val child = content.getChildAt(i)
            if (child is LinearLayout && (child.getChildAt(0) as? TextView)?.text?.toString() == "MY PROGRESS") {
                index = i
                break
            }
        }
        if (index < 0) return
        val box = content.getChildAt(index) as? LinearLayout ?: return
        if (box.childCount > 1) box.removeViews(1, box.childCount - 1)
        box.addView(progressText(profile), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
    }

    private fun clearPresenceSubscriptions() {
        presenceSubscriptions.forEach { it.reference.removeEventListener(it.listener) }
        presenceSubscriptions.clear()
    }

    private fun loadSocial(user: FirebaseUser) {
        clearPresenceSubscriptions()
        lifecycleScope.launch {
            val social = withContext(Dispatchers.IO) {
                var warning: String? = null
                runCatching { Tasks.await(repo.ensureIdentityProfile(user), 8, TimeUnit.SECONDS) }
                    .onFailure { warning = friendlyError(it) }
                runCatching { Tasks.await(repo.materializePendingFriendRequests(user), 8, TimeUnit.SECONDS) }
                    .onFailure { if (warning == null) warning = friendlyError(it) }
                val incoming = runCatching { Tasks.await(repo.incoming(user), 8, TimeUnit.SECONDS).documents.map {
                    RovexFriendRequest(
                        it.id,
                        it.getString("requesterName") ?: "Rovex Student",
                        it.getString("requesterCode") ?: "RVX-????-????",
                        it.getString("status") ?: "pending",
                        it.getTimestamp("createdAt")?.toDate()?.time ?: 0L
                    )
                } }.getOrElse { if (warning == null) warning = friendlyError(it); emptyList() }
                runCatching { Tasks.await(repo.finalizeAcceptedOutgoing(user), 8, TimeUnit.SECONDS) }
                    .onFailure { if (warning == null) warning = friendlyError(it) }
                val friendDocs = runCatching { Tasks.await(repo.friendUids(user), 8, TimeUnit.SECONDS).documents }
                    .getOrElse { if (warning == null) warning = friendlyError(it); emptyList() }
                val profiles = friendDocs.mapNotNull { doc ->
                    val uid = doc.getString("uid") ?: doc.id
                    runCatching { Tasks.await(repo.profile(uid), 5, TimeUnit.SECONDS) }
                        .mapCatching { repo.profileFromDocument(it) }.getOrNull()
                }
                Triple(incoming, profiles, warning)
            }
            // A partial Firebase failure must not hide requests/friends that were successfully
            // loaded. Only surface a warning when there is no usable social data at all.
            if (social.third != null && social.first.isEmpty() && social.second.isEmpty()) {
                addMessage("Some social data is temporarily unavailable", social.third!!)
            }
            if (social.first.isNotEmpty()) {
                card("FRIEND REQUESTS") {
                    social.first.forEach { request ->
                        val row = LinearLayout(this@RovexOnlineActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(5), 0, dp(8)) }
                        row.addView(TextView(this@RovexOnlineActivity).apply {
                            text = "${request.name} • ${request.rovexId}"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexOnlineActivity))
                        })
                        row.addView(action("ACCEPT", ThemeManager.accent(this@RovexOnlineActivity)) { accept(request.otherUid) })
                        row.addView(action("DECLINE", ThemeManager.muted(this@RovexOnlineActivity)) { decline(request.otherUid) })
                        content.addView(row)
                    }
                }
            }
            card("FRIENDS ARENA") {
                if (social.second.isEmpty()) {
                    add(TextView(this@RovexOnlineActivity).apply { text = "No friends yet. Add a Rovex ID above to start your private leaderboard."; textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) })
                } else {
                    social.second.sortedWith(compareByDescending<RovexOnlineProfile> { it.xp }.thenByDescending { it.questionsSolved }).forEachIndexed { index, p ->
                        val row = friendRow(index + 1, p)
                        add(row)
                        val subscription = RovexPresenceManager.observeFriend(
                            p.uid,
                            onState = { state ->
                                runOnUiThread {
                                    val statusView = row.tag as? TextView ?: return@runOnUiThread
                                    statusView.text = if (state.online) {
                                        "● Online"
                                    } else {
                                        "○ ${formatLastSeen(state.lastSeenMillis)}"
                                    }
                                    statusView.setTextColor(if (state.online) ThemeManager.accent(this@RovexOnlineActivity) else ThemeManager.muted(this@RovexOnlineActivity))
                                }
                            },
                            onError = { error ->
                                runOnUiThread {
                                    val statusView = row.tag as? TextView ?: return@runOnUiThread
                                    statusView.text = if (error.code == DatabaseError.PERMISSION_DENIED) "Presence unavailable" else "Presence unavailable"
                                    statusView.setTextColor(ThemeManager.muted(this@RovexOnlineActivity))
                                }
                            }
                        )
                        presenceSubscriptions += subscription
                    }
                }
            }
        }
    }

    private fun sendFriendRequest(raw: String) {
        val code = RovexFriendRequestState.normalize(raw)
        if (!RovexFriendRequestState.isValidCode(code)) {
            toast("Enter a valid Rovex ID, e.g. RVX-ABCD-1234")
            return
        }
        val user = auth.currentUser ?: return

        // Critical transport rule: never perform a client-side friendCodes/{code}.get().
        // The repository writes a recipient-scoped mailbox plus the sender's pending outgoing
        // record in one batch. Firestore persists that write offline; the recipient never needs
        // to be online at send time, and the UI does not wait for backend acknowledgement.
        val task = runCatching { repo.sendFriendRequestByCode(code, user) }.getOrElse { error ->
            handleFriendRequestFailure(code, error)
            return
        }

        friendOutbox.remove(code)
        toast(if (hasValidatedInternet()) {
            "Friend request queued for delivery — they do not need to be online"
        } else {
            "Friend request saved offline — it will send automatically when you reconnect"
        })
        render()

        // Transport failure is handled asynchronously. A transient failure is mirrored into the
        // legacy outbox so the request cannot disappear; recipient-side materialization is
        // deterministic and idempotent.
        task.addOnFailureListener { error ->
            if (isFinishing || isDestroyed) return@addOnFailureListener
            handleFriendRequestFailure(code, error)
        }
    }

    private fun handleFriendRequestFailure(code: String, error: Throwable) {
        val deviceInternet = hasValidatedInternet()
        if (!deviceInternet || RovexFriendRequestFailure.shouldQueue(error)) {
            friendOutbox.enqueue(code)
            RovexOnlineRepository.syncFriendRequests(this)
            toast(if (deviceInternet) {
                "Rovex backend did not acknowledge the request yet. It is saved and will retry."
            } else {
                "No internet connection. Request saved and will send automatically when you reconnect."
            })
            render()
        } else {
            toast(friendlyError(error))
        }
    }

    private fun hasValidatedInternet(): Boolean = runCatching {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return@runCatching false
        val caps = cm.getNetworkCapabilities(network) ?: return@runCatching false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }.getOrDefault(false)

    private fun accept(uid: String) {
        val user = auth.currentUser ?: return
        lifecycleScope.launch {
            onlineResult { withContext(Dispatchers.IO) { Tasks.await(repo.acceptRequest(uid, user), 20, TimeUnit.SECONDS) } }
                .onSuccess { toast("Friend added"); render() }
                .onFailure { toast(friendlyError(it)) }
        }
    }

    private fun decline(uid: String) {
        val user = auth.currentUser ?: return
        lifecycleScope.launch {
            onlineResult { withContext(Dispatchers.IO) { Tasks.await(repo.declineRequest(uid, user), 20, TimeUnit.SECONDS) } }
                .onSuccess { toast("Request declined"); render() }
                .onFailure { toast(friendlyError(it)) }
        }
    }

    private fun syncAndRender(user: FirebaseUser) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { onlineResult {
                Tasks.await(repo.ensureIdentityProfile(user), 30, TimeUnit.SECONDS)
                Tasks.await(repo.flushPendingWrites(), 30, TimeUnit.SECONDS)
            } }
            result.onSuccess { RovexOnlineRepository.syncNow(this@RovexOnlineActivity); render() }
                .onFailure { toast("Progress sync failed: ${friendlyError(it)}") }
        }
    }

    private fun progressText(p: RovexOnlineProfile): TextView = TextView(this@RovexOnlineActivity).apply {
        text = "${p.questionsSolved} questions solved\n${p.correct} correct • ${p.accuracyPercent}% accuracy\n${p.todaySolved} solved today\n${p.flashcardsReviewed} flashcards reviewed\n⚡ ${p.xp} XP"
        textSize = 12f; setTextColor(ThemeManager.text(this@RovexOnlineActivity)); setLineSpacing(0f, 1.15f)
    }

    private fun formatLastSeen(millis: Long?): String {
        if (millis == null || millis <= 0L) return "Offline"
        val delta = (System.currentTimeMillis() - millis).coerceAtLeast(0L)
        val minutes = delta / 60_000L
        return when {
            minutes < 1L -> "Last seen just now"
            minutes < 60L -> "Last seen ${minutes}m ago"
            minutes < 1440L -> "Last seen ${minutes / 60L}h ago"
            else -> "Last seen ${minutes / 1440L}d ago"
        }
    }

    private fun friendRow(rank: Int, p: RovexOnlineProfile): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 15)
        addView(TextView(this@RovexOnlineActivity).apply { text = "#$rank"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(this@RovexOnlineActivity)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(42), -1))
        val copy = LinearLayout(this@RovexOnlineActivity).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(TextView(this@RovexOnlineActivity).apply { text = p.displayName; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexOnlineActivity)) })
        copy.addView(TextView(this@RovexOnlineActivity).apply { text = "${p.xp} XP • ${p.questionsSolved} solved • ${p.accuracyPercent}% • ${p.flashcardsReviewed} cards"; textSize = 10.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) })
        val presence = TextView(this@RovexOnlineActivity).apply { text = "Checking presence…"; textSize = 10.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) }
        copy.addView(presence)
        tag = presence
        addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun card(title: String, block: CardScope.() -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(ThemeManager.elevated(this@RovexOnlineActivity), 18) }
        box.addView(TextView(this@RovexOnlineActivity).apply { text = title; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(this@RovexOnlineActivity)); setPadding(0, 0, 0, dp(9)) })
        CardScope(box).apply(block)
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private inner class CardScope(private val box: LinearLayout) {
        fun add(v: android.view.View) {
            box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }

        fun add(v: android.view.View, params: LinearLayout.LayoutParams) {
            if (params.topMargin == 0) params.topMargin = dp(5)
            box.addView(v, params)
        }
    }

    private fun action(label: String, tint: Int, click: () -> Unit) = TextView(this@RovexOnlineActivity).apply {
        text = label; textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(tint)
        background = rounded(ThemeManager.panel(this@RovexOnlineActivity), 13); setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { click() }
    }

    private fun addMessage(title: String, message: String) {
        card(title) { add(TextView(this@RovexOnlineActivity).apply { text = message; textSize = 11.5f; setTextColor(ThemeManager.muted(this@RovexOnlineActivity)) }) }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun friendlyError(t: Throwable): String {
        val e = t.cause ?: t
        val message = e.message.orEmpty()
        return when {
            message.contains("PERMISSION_DENIED", true) -> "Online access is not configured for this account yet."
            message.contains("Rovex ID not found", true) -> "Rovex ID not found. Check the code and try again."
            message.contains("DEADLINE_EXCEEDED", true) -> "Rovex server timed out. Your request can be retried."
            message.contains("client is offline", true) -> "Rovex could not reach its server. The request can be retried."
            message.isBlank() -> e.javaClass.simpleName
            else -> message.take(180)
        }
    }
}
