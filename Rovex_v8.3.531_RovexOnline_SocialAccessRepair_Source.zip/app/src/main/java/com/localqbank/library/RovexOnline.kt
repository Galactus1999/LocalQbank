package com.localqbank.library

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.android.gms.tasks.Tasks
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException

/**
 * Authentication boundary for Rovex Online. Google never receives Rovex study data; Firebase
 * Authentication supplies the stable user identity used by the Firestore security rules.
 */
object RovexOnlineAuth {
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()

    fun currentUser(): FirebaseUser? = auth.currentUser

    suspend fun signInWithGoogle(activity: Activity): Result<FirebaseUser> = try {
        val manager = CredentialManager.create(activity)
        val first = try {
            getCredential(manager, activity, filterAuthorized = true)
        } catch (_: NoCredentialException) {
            getCredential(manager, activity, filterAuthorized = false)
        }
        val credential = first.credential
        if (credential !is CustomCredential ||
            credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            error("Google sign-in returned an unsupported credential type")
        }
        val google = try {
            GoogleIdTokenCredential.createFrom(credential.data)
        } catch (e: GoogleIdTokenParsingException) {
            throw IllegalStateException("Google sign-in credential could not be decoded", e)
        }
        val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
        val user = withContext(Dispatchers.IO) {
            Tasks.await(auth.signInWithCredential(firebaseCredential), 30, TimeUnit.SECONDS).user
        } ?: error("Firebase signed in without a user")
        Result.success(user)
    } catch (e: CancellationException) {
        throw e
    } catch (t: Exception) {
        Result.failure(t)
    }

    private suspend fun getCredential(
        manager: CredentialManager,
        activity: Activity,
        filterAuthorized: Boolean
    ) = manager.getCredential(
        activity,
        GetCredentialRequest.Builder()
            .addCredentialOption(
                GetGoogleIdOption.Builder()
                    .setServerClientId(activity.getString(R.string.default_web_client_id))
                    .setFilterByAuthorizedAccounts(filterAuthorized)
                    .setAutoSelectEnabled(filterAuthorized)
                    .build()
            )
            .build()
    )

    suspend fun signOut(activity: Activity) {
        auth.signOut()
        try {
            CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Firebase sign-out is already complete; Credential Manager state clearing is best-effort.
        }
    }

    fun normalizedName(raw: String?): String = RovexOnlineIdentity.normalizedName(raw)

    fun rovexId(uid: String): String = RovexOnlineIdentity.rovexId(uid)

}

data class RovexOnlineProfile(
    val uid: String,
    val displayName: String,
    val rovexId: String,
    val questionsSolved: Int,
    val correct: Int,
    val accuracyPercent: Int,
    val todaySolved: Int,
    val flashcardsReviewed: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val xp: Long,
    val updatedAtMillis: Long
)

data class RovexFriendRequest(
    val otherUid: String,
    val name: String,
    val rovexId: String,
    val status: String,
    val createdAtMillis: Long
)

/** Firestore data boundary. It contains no QBank content, answers, notes, PDFs or AI chats. */
class RovexOnlineRepository(private val context: Context) {
    private val app = context.applicationContext
    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()

    fun identityProfile(user: FirebaseUser): RovexOnlineProfile = RovexOnlineProfile(
        uid = user.uid,
        displayName = RovexOnlineAuth.normalizedName(user.displayName),
        rovexId = RovexOnlineAuth.rovexId(user.uid),
        questionsSolved = 0, correct = 0, accuracyPercent = 0, todaySolved = 0, flashcardsReviewed = 0,
        currentStreak = 0, longestStreak = 0, xp = 0L, updatedAtMillis = 0L
    )

    fun ensureIdentityProfile(user: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        val p = identityProfile(user)
        val data = mapOf(
            "uid" to p.uid,
            "displayName" to p.displayName,
            "rovexId" to p.rovexId,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val batch = db.batch()
        batch.set(db.collection("users").document(p.uid), data, SetOptions.merge())
        batch.set(db.collection("friendCodes").document(p.rovexId), mapOf("uid" to p.uid, "displayName" to p.displayName), SetOptions.merge())
        return batch.commit()
    }


    fun syncPersonalProgress(user: FirebaseUser, projection: RovexOnlineProgressProjector.Projection): com.google.android.gms.tasks.Task<Void> {
        val data = mapOf(
            "uid" to user.uid,
            "questionsSolved" to projection.questionsSolved,
            "correct" to projection.correct,
            "accuracyPercent" to projection.accuracyPercent,
            "todaySolved" to projection.todaySolved,
            "flashcardsReviewed" to projection.flashcardsReviewed,
            "currentStreak" to projection.currentStreak,
            "longestStreak" to projection.longestStreak,
            "xp" to projection.xp,
            "progressSource" to "client_projection",
            "progressUpdatedAt" to projection.updatedAtMillis,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return db.collection("users").document(user.uid).set(data, SetOptions.merge())
    }

    fun submitStudyEvent(user: FirebaseUser, event: StudyEventSpine.Event): com.google.android.gms.tasks.Task<Void> {
        val id = java.util.UUID.randomUUID().toString()
        val data = mutableMapOf<String, Any>(
            "uid" to user.uid,
            "type" to event.name,
            "source" to event.source,
            "clientTimestamp" to event.timestamp,
            "createdAt" to FieldValue.serverTimestamp()
        )
        event.stableKey?.let { data["stableKeyHash"] = RovexOnlineIdentity.stableKeyHash(it) }
        event.metadata["correct"]?.let { data["correct"] = it == "true" }
        return db.collection("studyEvents").document(user.uid).collection("events").document(id).set(data)
    }

    /**
     * Write-first friend request transport with no Cloud Function dependency.
     *
     * Resolve the deterministic Rovex ID to its UID before writing. The recipient still does not
     * need to be online: friendCodes is a lightweight public identity index for signed-in users.
     * Persisting targetUid in the mailbox lets the recipient query only documents that belong to
     * that account, which makes the Firestore Rules contract query-safe instead of relying on a
     * path-level get() inside an unconstrained collection query.
     */
    fun sendFriendRequestByCode(code: String, requester: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        val normalized = code.trim().uppercase(Locale.US)
        require(RovexFriendRequestState.isValidCode(normalized)) { "Invalid Rovex ID" }
        val targetCodeRef = db.collection("friendCodes").document(normalized)
        return targetCodeRef.get().continueWithTask { lookup ->
            if (!lookup.isSuccessful) {
                throw (lookup.exception ?: IllegalStateException("Could not look up Rovex ID"))
            }
            val target = lookup.result
            val targetUid = target.getString("uid")?.trim().orEmpty()
            if (!target.exists() || targetUid.isEmpty()) {
                throw IllegalStateException("Rovex ID not found")
            }
            if (targetUid == requester.uid) {
                throw IllegalStateException("You cannot add yourself as a friend")
            }
            val requestId = db.collection("friendRequestMailboxes").document(normalized)
                .collection("requests").document().id
            val requesterCode = RovexOnlineAuth.rovexId(requester.uid)
            val data = mapOf(
                "requestId" to requestId,
                "requesterUid" to requester.uid,
                "requesterName" to RovexOnlineAuth.normalizedName(requester.displayName),
                "requesterCode" to requesterCode,
                "targetCode" to normalized,
                "targetUid" to targetUid,
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp()
            )
            val mailbox = db.collection("friendRequestMailboxes").document(normalized)
                .collection("requests").document(requestId)
            val outgoing = db.collection("friendRequestsBySender").document(requester.uid)
                .collection("outgoing").document(requestId)
            val batch = db.batch()
            batch.set(mailbox, data)
            batch.set(outgoing, data)
            batch.commit()
        }
    }

    /**
     * Materialize recipient-scoped mailbox entries. The mailbox path itself proves which Rovex
     * ID is being queried; Firestore rules map that code to the authenticated recipient.
     * Materialization is two-phase: first create/update the normal request documents, then
     * delete the mailbox entries after the first commit succeeds. This makes retries idempotent.
     */
    fun materializePendingFriendRequests(user: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        val myCode = RovexOnlineAuth.rovexId(user.uid)
        val mailbox = db.collection("friendRequestMailboxes").document(myCode).collection("requests")
            .whereEqualTo("targetUid", user.uid)
            .limit(50)
        return mailbox.get().continueWithTask { task ->
            if (!task.isSuccessful) throw (task.exception ?: IllegalStateException("Could not read friend request mailbox"))
            val docs = task.result.documents
            if (docs.isEmpty()) return@continueWithTask com.google.android.gms.tasks.Tasks.forResult(null)
            val batch = db.batch()
            val deletions = mutableListOf<com.google.firebase.firestore.DocumentReference>()
            docs.forEach { requestDoc ->
                val requesterUid = requestDoc.getString("requesterUid")?.trim().orEmpty()
                if (requesterUid.isEmpty() || requesterUid == user.uid) return@forEach
                val requestId = requestDoc.getString("requestId") ?: requestDoc.id
                val request = mapOf(
                    "intentId" to requestId,
                    "requesterUid" to requesterUid,
                    "requesterName" to (requestDoc.getString("requesterName") ?: "Rovex Student"),
                    "requesterCode" to (requestDoc.getString("requesterCode") ?: "RVX-????-????"),
                    "targetUid" to user.uid,
                    "targetCode" to myCode,
                    "status" to "pending",
                    "createdAt" to (requestDoc.getTimestamp("createdAt") ?: FieldValue.serverTimestamp())
                )
                val incoming = db.collection("friendRequests").document(user.uid).collection("incoming").document(requesterUid)
                // The sender already owns the outgoing document created by sendFriendRequestByCode().
                // The recipient is intentionally NOT allowed to write that sender-owned document.
                // Materialization therefore creates only the recipient-owned incoming request.
                batch.set(incoming, request, SetOptions.merge())
                deletions += requestDoc.reference
            }
            // Commit recipient-owned incoming requests first. The mailbox must still exist while
            // its security rule validates the incoming create. Delete mailbox entries only after
            // the incoming materialization has succeeded.
            batch.commit().continueWithTask { committed ->
                if (!committed.isSuccessful) throw (committed.exception ?: IllegalStateException("Could not materialize friend request"))
                val deleteBatch = db.batch()
                deletions.forEach { deleteBatch.delete(it) }
                deleteBatch.commit()
            }
        }
    }

    fun incoming(user: FirebaseUser): com.google.android.gms.tasks.Task<com.google.firebase.firestore.QuerySnapshot> =
        db.collection("friendRequests").document(user.uid).collection("incoming")
            .whereEqualTo("status", "pending").get()

    fun outgoing(user: FirebaseUser): com.google.android.gms.tasks.Task<com.google.firebase.firestore.QuerySnapshot> =
        db.collection("friendRequestsBySender").document(user.uid).collection("outgoing").get()

    fun acceptRequest(requesterUid: String, user: FirebaseUser): com.google.android.gms.tasks.Task<Void> =
        respondToRequest(requesterUid, user, "accepted")

    fun declineRequest(requesterUid: String, user: FirebaseUser): com.google.android.gms.tasks.Task<Void> =
        respondToRequest(requesterUid, user, "declined")

    /**
     * Respond using the request's immutable intentId instead of querying the sender's outgoing
     * collection. The recipient is authorized to update that exact outgoing document by the
     * targetCode rule, while the sender retains exclusive read access to the collection.
     */
    private fun respondToRequest(
        requesterUid: String,
        user: FirebaseUser,
        status: String
    ): com.google.android.gms.tasks.Task<Void> {
        require(status == "accepted" || status == "declined")
        val incoming = db.collection("friendRequests").document(user.uid).collection("incoming").document(requesterUid)
        return incoming.get().continueWithTask { lookup ->
            if (!lookup.isSuccessful) throw (lookup.exception ?: IllegalStateException("Could not locate incoming friend request"))
            val request = lookup.result
            if (!request.exists()) throw IllegalStateException("Friend request not found")
            val intentId = request.getString("intentId")?.trim().orEmpty()
            val storedRequester = request.getString("requesterUid")?.trim().orEmpty()
            if (intentId.isEmpty() || storedRequester != requesterUid) {
                throw IllegalStateException("Friend request is malformed")
            }
            val outgoing = db.collection("friendRequestsBySender").document(requesterUid)
                .collection("outgoing").document(intentId)
            val batch = db.batch()
            if (status == "accepted") {
                val myFriend = db.collection("users").document(user.uid).collection("friends").document(requesterUid)
                batch.set(myFriend, mapOf("uid" to requesterUid, "addedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
            }
            batch.update(incoming, mapOf("status" to status, "respondedAt" to FieldValue.serverTimestamp()))
            batch.update(outgoing, mapOf("status" to status, "respondedAt" to FieldValue.serverTimestamp(), "targetUid" to user.uid))
            batch.commit()
        }
    }

    fun finalizeAcceptedOutgoing(user: FirebaseUser): com.google.android.gms.tasks.Task<Void> {
        return outgoing(user).continueWithTask { task ->
            if (!task.isSuccessful) throw (task.exception ?: IllegalStateException("Could not read friend requests"))
            val batch = db.batch()
            task.result.documents.filter { it.getString("status") == "accepted" }.forEach { doc ->
                val otherUid = doc.getString("targetUid") ?: return@forEach
                val mine = db.collection("users").document(user.uid).collection("friends").document(otherUid)
                batch.set(mine, mapOf("uid" to otherUid, "addedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
            }
            batch.commit()
        }
    }

    fun friendUids(user: FirebaseUser): com.google.android.gms.tasks.Task<com.google.firebase.firestore.QuerySnapshot> =
        db.collection("users").document(user.uid).collection("friends").limit(50).get()

    fun flushPendingWrites(): com.google.android.gms.tasks.Task<Void> = db.waitForPendingWrites()

    fun profile(uid: String): com.google.android.gms.tasks.Task<com.google.firebase.firestore.DocumentSnapshot> =
        db.collection("users").document(uid).get()

    fun profileFromDocument(doc: com.google.firebase.firestore.DocumentSnapshot): RovexOnlineProfile? {
        if (!doc.exists()) return null
        return RovexOnlineProfile(
            uid = doc.id,
            displayName = doc.getString("displayName") ?: "Rovex Student",
            rovexId = doc.getString("rovexId") ?: "RVX-????-????",
            questionsSolved = (doc.getLong("questionsSolved") ?: 0L).toInt().coerceAtLeast(0),
            correct = (doc.getLong("correct") ?: 0L).toInt().coerceAtLeast(0),
            accuracyPercent = (doc.getLong("accuracyPercent") ?: 0L).toInt().coerceIn(0, 100),
            todaySolved = (doc.getLong("todaySolved") ?: 0L).toInt().coerceAtLeast(0),
            flashcardsReviewed = (doc.getLong("flashcardsReviewed") ?: 0L).toInt().coerceAtLeast(0),
            currentStreak = (doc.getLong("currentStreak") ?: 0L).toInt().coerceAtLeast(0),
            longestStreak = (doc.getLong("longestStreak") ?: 0L).toInt().coerceAtLeast(0),
            xp = (doc.getLong("xp") ?: 0L).coerceAtLeast(0L),
            updatedAtMillis = doc.getTimestamp("updatedAt")?.toDate()?.time ?: 0L
        )
    }

    fun removeFriend(otherUid: String, user: FirebaseUser): com.google.android.gms.tasks.Task<Void> =
        db.collection("users").document(user.uid).collection("friends").document(otherUid).delete()

    companion object {
        fun syncNow(context: Context) {
            val app = context.applicationContext
            if (FirebaseAuth.getInstance().currentUser == null) return
            val request = androidx.work.OneTimeWorkRequestBuilder<RovexOnlineSyncWorker>()
                .setConstraints(
                    androidx.work.Constraints.Builder()
                        .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                        .build()
                )
                .build()
            androidx.work.WorkManager.getInstance(app).enqueueUniqueWork(
                "rovex-online-sync", androidx.work.ExistingWorkPolicy.KEEP, request
            )
        }

        fun syncFriendRequests(context: Context) {
            val app = context.applicationContext
            if (FirebaseAuth.getInstance().currentUser == null) return
            val request = androidx.work.OneTimeWorkRequestBuilder<RovexFriendRequestSyncWorker>()
                .setConstraints(
                    androidx.work.Constraints.Builder()
                        .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                        .build()
                )
                .build()
            androidx.work.WorkManager.getInstance(app).enqueueUniqueWork(
                "rovex-friend-request-sync", androidx.work.ExistingWorkPolicy.KEEP, request
            )
        }
    }
}


object RovexOnlineSyncCoordinator {
    private val installed = java.util.concurrent.atomic.AtomicBoolean(false)
    private val listener: (StudyEventSpine.Event) -> Unit = { event ->
        if (event.name == "quiz_completed" || event.name == "flashcard_reviewed") {
            val user = FirebaseAuth.getInstance().currentUser
            if (user != null) {
                // Firestore Android persistence queues this write while offline; when connectivity
                // returns the event reaches the server trigger without blocking study UI.
                runCatching { RovexOnlineRepository(RovexApplicationContextHolder.context).submitStudyEvent(user, event) }
            }
        }
    }

    fun install(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        StudyEventSpine.subscribe(listener)
    }
}

class RovexFriendRequestSyncWorker(
    appContext: Context,
    workerParams: androidx.work.WorkerParameters
) : androidx.work.CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): androidx.work.ListenableWorker.Result =
        withContext(Dispatchers.IO) {
            val user = FirebaseAuth.getInstance().currentUser
                ?: return@withContext androidx.work.ListenableWorker.Result.success()
            val outbox = RovexFriendRequestOutbox(applicationContext)
            val pending = outbox.snapshot()
            if (pending.isEmpty()) return@withContext androidx.work.ListenableWorker.Result.success()
            try {
                val repo = RovexOnlineRepository(applicationContext)
                for (code in pending) {
                    try {
                        Tasks.await(repo.sendFriendRequestByCode(code, user), 20, TimeUnit.SECONDS)
                        // The intent is now durably owned by Firestore. The recipient materializes
                        // the real request when they next connect.
                        outbox.remove(code)
                    } catch (e: Exception) {
                        if (RovexFriendRequestFailure.shouldQueue(e)) {
                            ProductionCrashReporter.breadcrumb(applicationContext, "ONLINE_FRIEND_REQUEST_DEFERRED")
                            return@withContext if (runAttemptCount < 6) {
                                androidx.work.ListenableWorker.Result.retry()
                            } else {
                                androidx.work.ListenableWorker.Result.failure()
                            }
                        }
                        // Permanent user/data errors (for example an invalid/deleted ID) should
                        // not poison the entire outbox forever. Drop only that failed intent.
                        outbox.remove(code)
                    }
                }
                androidx.work.ListenableWorker.Result.success()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ProductionCrashReporter.breadcrumb(applicationContext, "ONLINE_FRIEND_OUTBOX_FAILED:${e.javaClass.simpleName}")
                if (runAttemptCount < 6) androidx.work.ListenableWorker.Result.retry()
                else androidx.work.ListenableWorker.Result.failure()
            }
        }
}

class RovexOnlineSyncWorker(
    appContext: Context,
    workerParams: androidx.work.WorkerParameters
) : androidx.work.CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): androidx.work.ListenableWorker.Result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val user = FirebaseAuth.getInstance().currentUser ?: return@withContext androidx.work.ListenableWorker.Result.success()
        try {
            val repo = RovexOnlineRepository(applicationContext)
            Tasks.await(repo.ensureIdentityProfile(user), 30, TimeUnit.SECONDS)
            androidx.work.ListenableWorker.Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ProductionCrashReporter.breadcrumb(applicationContext, "ONLINE_IDENTITY_SYNC_FAILED:${e.javaClass.simpleName}")
            if (runAttemptCount < 4) androidx.work.ListenableWorker.Result.retry()
            else androidx.work.ListenableWorker.Result.failure()
        }
    }
}
