package com.localqbank.library

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/**
 * Pure, deterministic content/scheduling helpers for Rovex's daily motivation and target
 * notifications. No network, AI inference, database mutation, or study scheduling lives here.
 */
object RovexDailyNotificationContent {
    private val quotes = listOf(
        "Small, consistent effort compounds into extraordinary results.",
        "You do not need a perfect day. You need the next focused session.",
        "Study the concept, then test the concept. Retrieval turns knowledge into recall.",
        "Progress is built one question, one correction, and one revision at a time.",
        "When a topic feels difficult, slow down enough to understand it—not enough to quit.",
        "A difficult question is feedback, not a verdict.",
        "Your future self benefits from the work you finish today.",
        "Consistency beats intensity when the goal is long-term mastery.",
        "Learn the why, remember the pattern, and practise the application.",
        "One focused hour is more valuable than a day spent worrying about studying.",
        "Mistakes are useful when you convert them into a rule you can recall next time.",
        "Keep the session simple: learn, retrieve, correct, repeat.",
        "The fastest route to mastery is honest feedback followed by deliberate practice.",
        "Do today's work before tomorrow's anxiety arrives.",
        "A strong revision system makes difficult knowledge easier to retrieve.",
        "You are allowed to find a topic hard. You are not required to leave it misunderstood.",
        "Every solved question is also a diagnostic of what your brain knows and misses.",
        "Make the next question count.",
        "Focus on the process you can control: attention, recall, correction, repetition.",
        "Knowledge becomes reliable when you can retrieve it without the page in front of you.",
        "Do not measure the session only by the questions you got right. Measure what you learned from the wrong ones.",
        "A calm, repeated routine can outperform occasional bursts of effort.",
        "Finish one small block before deciding whether you can do another.",
        "Your study history is built from ordinary days. Make today's one useful.",
        "Understand first. Memorize strategically. Retrieve repeatedly.",
        "The goal is not to know everything at once. The goal is to keep reducing what you do not know.",
        "Protect your attention; it is one of your most valuable study resources.",
        "A question you correct today is a question you are less likely to miss tomorrow.",
        "Keep moving: one concept, one question, one review.",
        "Good preparation is rarely dramatic. It is usually consistent.",
        "Use difficulty as a signal for where your next revision should go.",
        "You can restart a study session at any moment. The next five minutes still count.",
        "Strong recall is built, not wished for.",
        "Do the high-value work while your attention is available.",
        "A useful revision session leaves you with fewer uncertainties than you started with.",
        "Do not wait to feel motivated before beginning. Beginning often creates the momentum.",
        "Your mistakes can become your highest-yield revision list.",
        "Learn actively enough that the answer can come back when the question is unfamiliar.",
        "A focused attempt is progress even when the score is not.",
        "Keep the standard high and the next step small.",
        "Study for understanding; revise for retrieval; test for transfer.",
        "The best study plan is one you can execute repeatedly.",
        "Today is another opportunity to make tomorrow's recall easier.",
        "You do not need to finish everything. Finish the next important thing.",
        "When recall fails, identify the missing cue and build it deliberately.",
        "Small wins are still wins when they accumulate.",
        "A disciplined routine reduces the amount of willpower studying requires.",
        "Turn every explanation into something you can retrieve later.",
        "The question bank is not only an exam tool; it is a map of your knowledge gaps.",
        "Review the errors you keep repeating. That is where the highest-value learning often lives.",
        "One good correction can be worth more than ten passive rereads.",
        "Keep your attention on the question in front of you.",
        "Mastery grows quietly through repeated exposure and retrieval.",
        "If today's session is imperfect, make the next one better rather than abandoning the plan.",
        "A target gives direction; a routine turns it into progress.",
        "Study with curiosity: ask why the correct answer is correct and why the alternatives are wrong.",
        "The work you repeat becomes the skill you keep.",
        "Your next revision can begin with the last mistake you understood.",
        "Keep showing up. The cumulative effect is the point.",
        "A high-yield day is built from a few deliberate decisions repeated well.",
        "Recall is a skill: practise bringing the answer back, not just recognising it.",
        "Use wrong answers as coordinates for your next revision.",
        "The syllabus is large; your next useful action can still be small.",
        "Read less passively and retrieve more actively.",
        "A short focused block is enough to restart momentum.",
        "Do not chase every topic equally; let your data show where effort is needed.",
        "Revision works best when yesterday's difficulty becomes today's retrieval cue.",
        "The answer you explain clearly is the answer you are more likely to remember.",
        "Protect consistency on ordinary days; exams are won by accumulated ordinary days.",
        "When the score dips, inspect the errors before changing the whole plan.",
        "Learn the pattern behind the question, not only the option you selected.",
        "A focused correction is productive study even when it adds no new facts.",
        "Make your weak areas visible; hidden weaknesses are harder to revise.",
        "The next ten questions can teach you more than another hour of passive review.",
        "Use spaced review before the memory becomes fragile.",
        "A mistake remembered correctly becomes part of your preparation.",
        "Keep your study system simple enough to use on a tired day.",
        "Your progress is allowed to be uneven; your process should remain repeatable.",
        "Start with the highest-value gap, then keep going.",
        "Questions reveal knowledge gaps faster when you analyse the alternatives too.",
        "Do not confuse familiarity with recall. Test yourself.",
        "Every review is a chance to shorten the path from cue to answer.",
        "A stable routine turns revision from a decision into a habit.",
        "Use today's errors to design tomorrow's revision.",
        "You can improve accuracy without increasing study hours by improving feedback quality.",
        "One well-understood topic can make many future questions easier.",
        "Keep the question bank close to your learning loop: attempt, analyse, revise, repeat.",
        "The best time to correct a misconception is immediately after you notice it.",
        "Do not let one difficult chapter define the quality of the whole session.",
        "Study health improves when workload, recovery and revision stay sustainable.",
        "Use your strongest recall to reinforce your weakest links.",
        "A missed question is useful when you can name exactly why it was missed.",
        "Build confidence from evidence: attempts, corrections, recall and repetition.",
        "The goal of revision is not more exposure; it is better retrieval.",
        "If a topic keeps returning as a mistake, promote it to a deliberate revision target.",
        "Make the next study block specific: one topic, one goal, one measurable outcome.",
        "You do not need to feel ready to practise recall. Practising is how readiness grows.",
        "Keep difficult concepts in rotation until retrieval becomes easier.",
        "A good study dashboard should tell you what to do next, not just what happened.",
        "Use data to guide revision, but keep the plan simple enough to execute.",
        "Finish the correction before moving to the next distraction.",
        "Repeated retrieval turns fragile knowledge into exam-ready knowledge.",
        "The next correct answer is useful; understanding the previous wrong answer is often more useful.",
        "A sustainable pace protects the quality of your recall.",
        "Make weak topics smaller: one concept, one mechanism, one question at a time.",
        "Study momentum returns faster when the first task is concrete.",
        "Use yesterday's mistakes as today's warm-up.",
        "Your revision history is a map; follow the areas that need another pass.",
        "Good preparation is a feedback loop, not a single heroic session.",
        "Keep learning local, measurable and repeatable."
    )

    fun quoteFor(date: LocalDate): String {
        val index = Math.floorMod(date.toEpochDay().toInt(), quotes.size)
        return quotes[index]
    }

    fun quoteCount(): Int = quotes.size

    fun nextTriggerMillis(now: ZonedDateTime, hour: Int, minute: Int): Long {
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)
        var next = now.withHour(safeHour).withMinute(safeMinute).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return ChronoUnit.MILLIS.between(now, next).coerceAtLeast(60_000L)
    }

    fun todayStartMillis(zone: ZoneId = ZoneId.systemDefault()): Long =
        LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()
}
