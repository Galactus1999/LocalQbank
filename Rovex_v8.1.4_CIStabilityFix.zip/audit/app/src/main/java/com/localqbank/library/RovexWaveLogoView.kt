package com.localqbank.library

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.ImageView

/** Low-cost animated Rovex logo. The launcher icon remains static/adaptive; this is in-app only. */
class RovexWaveLogoView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ImageView(context, attrs) {
    private var bitmap: Bitmap? = null
    private var phase = 0f
    private var animator: ValueAnimator? = null
    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG)


    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        bitmap = BitmapFactory.decodeResource(resources, R.drawable.rovex_launcher_foreground)
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3000L
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel(); animator = null; bitmap = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val dst = fitRect(b.width, b.height)
        val colors = intArrayOf(0xFF237E97.toInt(), 0xFF7C4DFF.toInt(), 0xFF36B99A.toInt(), 0xFF237E97.toInt())
        val travel = width.toFloat() * 2f
        val start = -travel + phase * travel
        wavePaint.shader = LinearGradient(start, 0f, start + travel, 0f, colors, null, Shader.TileMode.MIRROR)
        canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        // Draw the logo alpha as a mask, then fill only that alpha with the moving gradient.
        maskPaint.shader = null
        maskPaint.xfermode = null
        canvas.drawBitmap(b, null, dst, maskPaint)
        wavePaint.xfermode = android.graphics.PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawRect(dst, wavePaint)
        wavePaint.xfermode = null
        canvas.restore()
    }

    private fun fitRect(bw: Int, bh: Int): android.graphics.RectF {
        val scale = minOf(width.toFloat() / bw, height.toFloat() / bh) * .92f
        val w = bw * scale; val h = bh * scale
        return android.graphics.RectF((width-w)/2f, (height-h)/2f, (width+w)/2f, (height+h)/2f)
    }
}
