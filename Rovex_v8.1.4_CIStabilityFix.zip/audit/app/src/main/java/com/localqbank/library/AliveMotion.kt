package com.localqbank.library

import android.view.View

/** Subtle, bounded touch feedback for the existing Views UI. No continuous animation or timers. */
object AliveMotion {
    fun install(view: View) {
        view.isHapticFeedbackEnabled = true
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    v.animate().cancel()
                    v.animate().scaleX(0.975f).scaleY(0.975f).setDuration(70L).start()
                    false
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(150L).start()
                    false
                }
                else -> false
            }
        }
    }
}
