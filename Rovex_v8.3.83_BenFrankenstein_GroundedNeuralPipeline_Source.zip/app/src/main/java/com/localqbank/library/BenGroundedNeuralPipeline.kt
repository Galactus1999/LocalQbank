package com.localqbank.library

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Controlled bridge between Ben's deterministic cognition and the optional neural accelerator.
 * The model never becomes the source of truth: local QBank evidence is supplied to the model,
 * then the draft is passed back through Ben's existing planner/verifier before it can be shown.
 */
class BenGroundedNeuralPipeline(context: Context) {
    private val app = context.applicationContext
    private val qbank = QBankDb(app)
    private val generator = BenLiteRtLmGenerator(app)
    private val cognitive = BenCognitiveArchitecture(app)

    data class Result(
        val answer: String,
        val modelUsed: Boolean,
        val verified: Boolean,
        val confidence: Int,
        val evidenceCount: Int,
        val elapsedMs: Long
    )

    suspend fun run(query: String): Result = withContext(Dispatchers.IO) {
        val clean = BenResearchInputPolicy.normalize(query)
            ?: return@withContext Result("Give Ben a clinical term, topic, question, or study task.", false, true, 0, 0, 0)

        val hits = runCatching { qbank.search(clean, 12) }.getOrElse { emptyList() }
        val evidence = hits.take(6).mapIndexed { index, hit ->
            "[${index + 1}] ${hit.text.replace(Regex("\\s+"), " ").trim().take(700)}"
        }
        val prompt = buildPrompt(clean, evidence)
        val draft = generator.generate(prompt, 160)
        if (draft == null) {
            val fallback = cognitive.answer(clean)
            return@withContext Result(fallback.answer, false, fallback.verified, fallback.confidence, evidence.size, 0)
        }

        val verified = runCatching {
            cognitive.answer(clean, baseAnswer = draft.text, modelUsed = true)
        }.getOrNull()

        if (verified == null || verified.answer.isBlank()) {
            val fallback = cognitive.answer(clean)
            return@withContext Result(fallback.answer, false, fallback.verified, fallback.confidence, evidence.size, draft.elapsedMs)
        }
        Result(
            answer = verified.answer,
            modelUsed = verified.modelUsed,
            verified = verified.verified,
            confidence = verified.confidence,
            evidenceCount = evidence.size,
            elapsedMs = draft.elapsedMs
        )
    }

    private fun buildPrompt(query: String, evidence: List<String>): String = buildString {
        append("Clinical study query:\n")
        append(query)
        append("\n\nLocal QBank evidence (use only when relevant):\n")
        if (evidence.isEmpty()) append("No matching local evidence was found.\n")
        else evidence.forEach { append(it).append('\n') }
        append("\nDraft a concise medical-study answer. Do not invent facts, doses, guidelines, citations, or patient-specific treatment. If the evidence is insufficient, say so. This is a draft for Ben's deterministic verifier.")
    }
}
