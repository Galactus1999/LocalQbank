package com.localqbank.library

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** One-shot CPU-first LiteRT-LM adapter. It owns no Ben business logic or scheduling. */
class BenLiteRtLmGenerator(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.gemma3_270m

    data class Result(val text: String, val elapsedMs: Long, val modelMb: Int)

    suspend fun generate(prompt: String, maxOutputTokens: Int = 192): Result? = withContext(Dispatchers.IO) {
        val clean = prompt.trim().take(6_000)
        if (clean.isBlank()) return@withContext null
        val installed = models.installed(profile) ?: return@withContext null
        val governor = BenAiResourceGovernor(app)
        val policy = BenAiRuntimePolicy(app)
        if (!governor.mayRun(policy, profile.estimatedRuntimeMb, foreground = true)) return@withContext null
        val start = System.nanoTime()
        runCatching {
            Engine(
                EngineConfig(
                    modelPath = installed.file.absolutePath,
                    backend = Backend.CPU(),
                    maxNumTokens = (maxOutputTokens + 512).coerceAtMost(1024),
                    cacheDir = File(app.cacheDir, "ben_litertlm").apply { mkdirs() }.absolutePath,
                )
            ).use { engine ->
                engine.initialize()
                engine.createConversation(
                    ConversationConfig(
                        samplerConfig = SamplerConfig(topK = 20, topP = 0.9, temperature = 0.2),
                        systemInstruction = Contents.of(
                            Content.Text("You are Ben, a local medical-study drafting accelerator. Use only supplied context. Be concise. If evidence is absent, say so. Do not invent doses, guidelines, citations or patient-specific treatment.")
                        )
                    )
                ).use { conversation ->
                    val message = conversation.sendMessage(
                        Contents.of(Content.Text(clean)),
                        maxOutputToken = maxOutputTokens.coerceIn(32, 192)
                    )
                    val text = message.contents.contents.filterIsInstance<Content.Text>().joinToString(" ") { it.text }
                    if (text.isBlank()) return@runCatching null
                    Result(text.trim().take(8_000), (System.nanoTime() - start) / 1_000_000L, profile.estimatedModelMb).also { policy.recordBackendSuccess() }
                }
            }
        }.onFailure { policy.recordBackendFailure() }.getOrNull()
    }
}
