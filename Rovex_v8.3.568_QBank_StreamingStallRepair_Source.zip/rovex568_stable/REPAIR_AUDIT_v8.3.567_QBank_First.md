# Rovex v8.3.567 — QBank-First Repair Audit

## Baseline
- Failed CI baseline: v8.3.566 / versionCode 655
- Current source: v8.3.567 / versionCode 656
- Package: `com.localqbank.library`
- Scope: QBank deletion isolation test repair
- Visual/interaction overhaul: explicitly deferred

## CI failure
The attached v8.3.566 instrumented run failed at:
`QBankDeletionIsolationTest.foregroundInterruptionBetweenQuestionBatchesLeavesDurableRecoveryBoundary`

Failure:
`expected:<1> but was:<0>` at the `keep-test` `questionCount()` assertion.

## Root cause
The test itself destroyed its unrelated fixture:
- setup created `keep-test` question id `2`;
- the test deleted the entire `question` table;
- the test then inserted `delete-test` questions with IDs `1..101`;
- ID `2` was therefore reused by `delete-test`;
- the unrelated `keep-test` question no longer existed.

The production deletion query is source-scoped (`t.source_id=?`) and does not target source 2.

## Repair
The test now:
1. removes only `delete-test` question-owned rows;
2. preserves the seeded `keep-test` question;
3. inserts 101 delete-test questions using IDs `1001..1101`;
4. preserves the 51-row physical-boundary assertion after two pause checks;
5. preserves the public isolation assertion that `questionCount("keep-test") == 1`.

No production deletion behavior was weakened or hidden behind a changed assertion.

## Recovery-worker invariant
The v8.3.566 source already removed the incompatible WorkManager backoff criteria from the DeviceIdle-constrained recovery request. The current source retains that repair.

## Static checks performed
- Target test fixture inspected: PASS
- Source-scoped deletion query inspected: PASS
- Version identity updated to 656 / 8.3.567: PASS
- Recovery worker contains no `setBackoffCriteria()` call: PASS
- Visual overhaul changes introduced: NO
- Android/Gradle compilation: NOT VERIFIED
- CI: PENDING
- Device: PENDING

Never call this release CI-green until the complete workflow succeeds.
