# Rovex v8.3.567 — QBank Deletion Isolation Test Repair

## Priority
QBankDb / QBank recovery only. Visual/interaction overhaul remains deferred.

## CI failure repaired
The v8.3.566 instrumented run failed in:

`QBankDeletionIsolationTest.foregroundInterruptionBetweenQuestionBatchesLeavesDurableRecoveryBoundary`

The assertion expected one live question in the unrelated `keep-test` QBank but received zero.

### Root cause
This was a **test-fixture defect**, not evidence that production deletion removed source 2.

The test setup initially seeded the unrelated `keep-test` question with `id=2`. The failing test then executed:

- `DELETE FROM question`
- inserted 101 `delete-test` questions with IDs `1..101`

That erased the `keep-test` question and then reused `id=2` for `delete-test`. The later isolation assertion therefore observed zero questions for `keep-test`.

### Repair
The test now:
- removes only the existing `delete-test` question and its dependent rows;
- preserves the seeded `keep-test` question;
- inserts the 101 destructive-test questions using non-conflicting IDs `1001..1101`;
- continues to assert exactly 51 physical `delete-test` rows after the deliberate interruption;
- continues to assert that the unrelated `keep-test` remains visible through the production `questionCount()` API.

This keeps the test aligned with the actual isolation contract instead of weakening the assertion.

## P0 recovery-worker state
The source already contains the v8.3.566 repair that removed incompatible WorkManager backoff configuration from the DeviceIdle-constrained QBank deletion recovery request. The current `QBankDeletionRecoveryWorker` therefore does not configure `setBackoffCriteria()` on its idle request.

## Scope isolation
No theme, animation, touch-sound, Home visual, border, color-grading, or other visual overhaul changes are included.

## Verification boundary
- Source modification: APPLIED
- Targeted source inspection: PASS
- Version identity: v8.3.567 / versionCode 656
- Local Gradle build: NOT VERIFIED in this environment
- CI build/instrumented tests: PENDING
- Device validation: PENDING

Do not describe this source package as CI-green until the complete GitHub Actions workflow succeeds.
