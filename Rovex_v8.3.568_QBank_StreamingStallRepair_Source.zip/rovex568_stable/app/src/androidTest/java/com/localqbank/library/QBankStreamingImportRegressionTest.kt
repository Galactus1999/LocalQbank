package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Exercises the real QBankDb streaming-import session across its bounded SQLite transactions. */
@RunWith(AndroidJUnit4::class)
class QBankStreamingImportRegressionTest {
    private lateinit var db: QBankDb

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
    }

    private fun question(index: Int) = ImportedQuestion(
        sourceId = "stream-$index",
        text = "streaming-question-$index",
        rawText = "streaming-question-$index",
        correctAnswer = "A",
        explanation = "explanation-$index",
        bot = null, video = null, audio = null,
        options = listOf(ImportedOption("A", "answer-$index", true)),
        questionImages = emptyList(),
        explanationImages = emptyList()
    )

    @Test
    fun streamingImportPersistsAcrossBoundedTransactions() {
        val session = db.beginStreamingImport("streaming-regression", "streaming-regression.html", "HTML")
        try {
            repeat(251) { session.addQuestion("Streaming Test", question(it)) }
            session.finish(true)
        } catch (t: Throwable) {
            runCatching { session.abort() }
            throw t
        }

        val source = db.sources().single()
        val test = db.tests(source.id).single()
        assertEquals(251, test.count)
        assertEquals(251, db.questionCount(test.id))
        assertEquals(1, db.search("streaming-question-250").size)
        assertTrue(db.sources().single().fileName.startsWith("rvx-"))
    }

    @Test
    fun failedStreamingSessionRemovesPartiallyCreatedSource() {
        val session = db.beginStreamingImport("streaming-failure", "streaming-failure.html", "HTML")
        session.addQuestion("Streaming Test", question(0))
        session.abort()

        assertTrue(db.sources().isEmpty())
        assertEquals(0, db.search("streaming-question-0").size)
    }
}
