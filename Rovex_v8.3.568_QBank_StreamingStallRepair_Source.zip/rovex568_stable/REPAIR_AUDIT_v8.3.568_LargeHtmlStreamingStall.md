# Rovex v8.3.568 — Large HTML Streaming Stall Audit

## Defect
Large HTML import visibly stopped at 28% during streaming.

## Root cause verified by source inspection
The screenshot's 28% state corresponds to the Activity's fixed transition into large-file streaming. There was no scanner-byte progress, and the streaming DB session opened a write transaction before the large HTML scanner began. That kept SQLite write ownership active while parsing a potentially very large file. The UI therefore had no visible progress during the expensive scan and the DB could contend with other work.

## Repairs
- Make streaming SQLite transaction admission lazy.
- Do not immediately reopen the transaction after a bounded commit.
- Add byte-level scanner progress to the import UI.
- Return emitted-question count from scanner.
- Abort safely when zero questions are emitted.
- Add regression tests for supported array shapes and scanner completion progress.
- Version 8.3.568 / versionCode 657.

## Static checks performed
- Changed Kotlin source delimiter balance: pending execution below.
- Scanner caller/call-site audit: single production call site updated.
- Old `scan()` call sites: no other production/test call sites before repair.
- Active CI version identity updated.
- Stale active Pandora verifier version identity updated.

## Execution status
Android Gradle/CI/device verification is pending. No BUILD PASS or CI PASS is claimed from source inspection.
