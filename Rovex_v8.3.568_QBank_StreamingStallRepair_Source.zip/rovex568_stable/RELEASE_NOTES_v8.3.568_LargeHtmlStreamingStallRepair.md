# Rovex v8.3.568 — Large HTML Streaming Import Stall Repair

## User-visible defect

Large HTML QBank import could remain at 28% with the Streaming engine shown as 100%.

## Root cause

The streaming UI reported only the entry point (28%) and had no byte-level progress while `LargeHtmlScanner` searched/parses the staged file. More importantly, `StreamingImportSession` opened its SQLite write transaction before parsing began and kept that write-lock interval open while the scanner read and decoded the large HTML file. That could make a large import appear frozen and unnecessarily contend with other SQLite work.

## Repair

- `StreamingImportSession` now acquires the SQLite write transaction lazily on the first question and does not immediately reopen it after each bounded commit.
- `LargeHtmlScanner` now reports staged-file scan progress.
- The Activity maps scan progress into the visible import progress instead of remaining at 28% until enough questions arrive.
- `LargeHtmlScanner.scan()` now returns the number of emitted questions.
- Large HTML import fails safely if the scanner emits zero importable questions instead of silently finalizing an empty import.
- Added JVM regression tests for section-based `TESTS_LIST` arrays, root `QUESTIONS_DATA` arrays, and scanner completion progress.
- Bumped version to 8.3.568 / versionCode 657.

## Scope

QBank/HTML import only. No visual overhaul and no unrelated Ben changes.
