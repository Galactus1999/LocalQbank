package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Permanent, exportable diagnostics surface for Ben and future Rovex performance tests. */
class RovexDiagnosticsDataCenter : AppCompatActivity() {
    private lateinit var reportView: TextView
    private lateinit var summaryView: TextView
    private lateinit var statusView: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var runButton: TextView
    private var diagnosticJob: Job? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        setContentView(build())
    }

    override fun onResume() {
        super.onResume()
        if (::reportView.isInitialized) {
            reportView.text = RovexDiagnosticsStore.latest(this) ?: "No completed EmbeddingGemma diagnostic is stored yet."
            refreshSnapshot()
        }
    }

    private fun build(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(28))
            setBackgroundColor(ThemeManager.bg(this@RovexDiagnosticsDataCenter))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter))
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(42), dp(48)))
        header.addView(TextView(this).apply {
            text = "Rovex Test & Diagnostics Center"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter)); setPadding(dp(6), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(header)
        root.addView(label("The single test window for EmbeddingGemma, Ben IPC, resources and future runtime measurements."), lpWrap(0, 10))

        val summary = card(); summary.addView(title("CURRENT SNAPSHOT")); summaryView = label(""); summary.addView(summaryView); root.addView(summary, cardLp(0, 10))

        val actions = card(); actions.addView(title("EMBEDDINGGEMMA FULL TEST"))
        actions.addView(label("Contract → tokenizer → backend/NPU → inference → semantic smoke test → RAM/thermal report. First runtime initialization can take around 20 seconds."), lpWrap(0, 6))
        statusView = label("Ready • no test running"); statusView.textSize = 13f; statusView.setTextColor(ThemeManager.text(this)); actions.addView(statusView, lpWrap(0, 4))
        progressBar = ProgressBar(this).apply { isIndeterminate = true; visibility = ProgressBar.GONE }
        actions.addView(progressBar, LinearLayout.LayoutParams(-1, dp(4)).apply { setMargins(0, dp(2), 0, dp(6)) })
        runButton = button("RUN FULL EMBEDDINGGEMMA TEST") { runEmbeddingDiagnostic() }
        actions.addView(runButton, lp(0, 8))
        actions.addView(button("OPEN BEN MODEL LAB") { startActivity(Intent(this, BenModelLabActivity::class.java)) }, lp(0, 4))
        actions.addView(button("REFRESH SNAPSHOT") { refreshSnapshot() }, lp(0, 4))
        actions.addView(button("SHARE COMPLETE DIAGNOSTICS") { shareDiagnostics() }, lp(0, 4))
        root.addView(actions, cardLp(0, 10))

        val report = card(); report.addView(title("LATEST TEST REPORT"))
        val stored = RovexDiagnosticsStore.latest(this)
        val storedStatus = RovexDiagnosticsStore.latestStatus(this)
        reportView = label(when {
            !stored.isNullOrBlank() -> stored
            !storedStatus.isNullOrBlank() -> "Latest diagnostic status: $storedStatus"
            else -> "No completed EmbeddingGemma diagnostic is stored yet."
        })
        reportView.textSize = 12f; reportView.setTextIsSelectable(true)
        report.addView(reportView, lpWrap(0, 6)); root.addView(report, cardLp(0, 10))

        val telemetry = card(); telemetry.addView(title("LIVE TELEMETRY")); telemetry.addView(label(telemetryText())); root.addView(telemetry, cardLp(0, 10))
        refreshSnapshot()
        return ScrollView(this).apply { addView(root); isFillViewport = true }
    }

    private fun runEmbeddingDiagnostic() {
        if (diagnosticJob?.isActive == true) return
        runButton.text = "STOP TEST"
        runButton.setOnClickListener { diagnosticJob?.cancel() }
        progressBar.visibility = ProgressBar.VISIBLE
        reportView.text = "Test started. Waiting for isolated Ben runtime…"
        statusView.text = "STARTING • binding isolated inference process…"
        val started = System.currentTimeMillis()
        diagnosticJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        BenInferenceProcessClient(this@RovexDiagnosticsDataCenter).use { client ->
                            client.diagnosticSuspend { progress ->
                                runOnUiThread { statusView.text = "RUNNING • $progress" }
                            }
                        }
                    }
                }
                if (result.isSuccess) {
                    val outcome = result.getOrNull()!!
                    val report = outcome.report
                    if (!report.isNullOrBlank()) {
                        RovexDiagnosticsStore.publish(this@RovexDiagnosticsDataCenter, report)
                        BenNeuralTelemetry.setDiagnosticReport(report)
                        reportView.text = report
                        statusView.text = "COMPLETE • report stored • ${System.currentTimeMillis() - started} ms wall time"
                    } else {
                        val reason = outcome.failure ?: "UNKNOWN_DIAGNOSTIC_FAILURE"
                        RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, reason)
                        reportView.text = "Diagnostic failed.\n\nReason: $reason\n\nNo study data was changed. Retry after reviewing the reason."
                        statusView.text = "FAILED • $reason"
                    }
                } else {
                    val reason = result.exceptionOrNull()?.message ?: "CLIENT_DIAGNOSTIC_EXCEPTION"
                    RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, reason)
                    reportView.text = "Diagnostic client failure.\n\nReason: $reason"
                    statusView.text = "FAILED • client exception"
                }
                refreshSnapshot()
            } catch (_: kotlinx.coroutines.CancellationException) {
                RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, "CANCELLED")
                reportView.text = "Test cancelled. No study data was changed."
                statusView.text = "CANCELLED"
            } finally {
                if (!isFinishing) finishDiagnosticUi()
            }
        }
    }

    private fun finishDiagnosticUi() {
        progressBar.visibility = ProgressBar.GONE
        runButton.text = "RUN FULL EMBEDDINGGEMMA TEST"
        runButton.setOnClickListener { runEmbeddingDiagnostic() }
    }

    private fun refreshSnapshot() {
        if (!::summaryView.isInitialized) return
        val t = BenNeuralTelemetry.snapshot()
        val g = BenAiResourceGovernor(this).snapshot(true)
        val latest = RovexDiagnosticsStore.latest(this)
        summaryView.text = "Stage: ${t.stage.name}\nModel: ${t.activeModel}\nLast latency: ${t.lastElapsedMs} ms\nConfidence: ${t.lastConfidence}%\nEvidence: ${t.lastEvidenceCount}\nVerified: ${if (t.lastVerified) "YES" else "NO"}\nRAM: ${g.availableMemoryMb} MB\nThermal: ${g.thermalStatus}\nPower-save: ${if (g.powerSave) "ON" else "OFF"}\nStored diagnostic: ${if (latest.isNullOrBlank()) "NONE" else "AVAILABLE"}"

    }

    private fun telemetryText(): String {
        val t = BenNeuralTelemetry.snapshot()
        return "Requests ${t.totalRequests} • neural ${t.neuralRequests} • fallback ${t.fallbackRequests} • blocked ${t.blockedRequests}\nSemantic runs ${t.semanticRuns} • generation runs ${t.generationRuns}\nLast error: ${t.lastError ?: "None"}"

    }

    private fun shareDiagnostics() {
        val t = BenNeuralTelemetry.snapshot()
        val gov = BenAiResourceGovernor(this).snapshot(true)
        val latest = RovexDiagnosticsStore.latest(this)
        val latestStatus = RovexDiagnosticsStore.latestStatus(this)
        val text = buildString {
            appendLine("ROVEX COMPLETE DIAGNOSTICS EXPORT")
            appendLine("exportedAt=${System.currentTimeMillis()}")
            appendLine("stage=${t.stage.name}")
            appendLine("stageDetail=${t.stageDetail}")
            appendLine("activeModel=${t.activeModel}")
            appendLine("modelKind=${t.modelKind}")
            appendLine("lastLatencyMs=${t.lastElapsedMs}")
            appendLine("lastSemanticMs=${t.lastSemanticMs}")
            appendLine("lastGenerationMs=${t.lastGenerationMs}")
            appendLine("evidenceCount=${t.lastEvidenceCount}")
            appendLine("verified=${t.lastVerified}")
            appendLine("confidence=${t.lastConfidence}")
            appendLine("totalRequests=${t.totalRequests}")
            appendLine("neuralRequests=${t.neuralRequests}")
            appendLine("fallbackRequests=${t.fallbackRequests}")
            appendLine("blockedRequests=${t.blockedRequests}")
            appendLine("semanticRuns=${t.semanticRuns}")
            appendLine("generationRuns=${t.generationRuns}")
            appendLine("ramAvailableMb=${gov.availableMemoryMb}")
            appendLine("thermalStatus=${gov.thermalStatus}")
            appendLine("powerSave=${gov.powerSave}")
            appendLine("lastError=${t.lastError ?: ""}")
            appendLine("latestDiagnosticStatus=${latestStatus ?: "NONE"}")
            appendLine()
            appendLine(latest ?: "No completed EmbeddingGemma report stored.")
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Rovex complete diagnostics")
            putExtra(Intent.EXTRA_TEXT, text.take(28000))
        }, "Share Rovex diagnostics"))
    }

    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(ThemeManager.elevated(this@RovexDiagnosticsDataCenter), 18) }
    private fun title(t: String) = TextView(this).apply { text = t; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter)) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 12f; setTextColor(ThemeManager.muted(this@RovexDiagnosticsDataCenter)) }
    private fun button(t: String, click: () -> Unit) = TextView(this).apply { text = t; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(ThemeManager.accent(this@RovexDiagnosticsDataCenter), 13); setOnClickListener { click() } }
    private fun lp(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun lpWrap(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun cardLp(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
}
