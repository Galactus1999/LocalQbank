# v8.3.421 — BEN + AI Evidence / Stability UI Repair

## Scope
Starting baseline: v8.3.420 / versionCode 512.

### User-visible repairs
- Removed `UPLOAD PDF` from the BEN + AI question chat surface.
- Added read-only `RELATED Qs` access to the bounded local related-question evidence.
- Added read-only `PDF TEXT` access to retrieved reference-PDF page excerpts.
- Expanded PYT mode instructions so Free AI teaches the underlying topic in an exam-oriented framework and maps retrieved related questions to the subtopics they tested.
- Expanded OTHER OPTIONS instructions to cover exam discriminators, when distractors become correct, common close-distractor traps, and valid exam-style reframings.
- Moved the BEN + AI dialog into true fullscreen mode so the header does not reserve a second status-bar band.
- Added ten bounded procedural milestone-celebration variants.
- Quiz milestones trigger every 10 accepted answers; the celebration is isolated from persistence and cannot make answer handling terminal.

## Stability / safety
- Evidence viewers are bounded to 40,000 characters.
- Evidence retrieval is read-only and reuses the latest bounded context when available.
- Viewer dialogs use selectable native text rather than an additional WebView/rendering path.
- Celebration failures are isolated with `runCatching` + non-fatal diagnostics.
- No package/applicationId change.
- versionCode increased monotonically 512 -> 513.

## Verification performed
- Added 2 regression tests; source scan now contains 98 `@Test` methods in `app/src/test` (not executed locally because Gradle is unavailable).
- SHA-256 of starting v8.3.420 source matched the supplied baseline before modification.
- `tools/audit_chat_architecture.sh`: PASS.
- `tools/audit_frankenstein_policy.py`: PASS.
- `tools/audit_coroutine_cancellation.py`: PASS.
- `tools/ruthless_audit.sh`: PASS.
- `tools/architecture.py` equivalent audit: PASS with known large-file warnings.
- `tools/architecture_regression_audit.py`: FAIL on pre-existing architecture debt (FlashcardActivity, FlashcardStudyActivity, NotesActivity, RenActivity, SearchActivity growth; direct persistence; singleton/object count; MainActivity AppContainer boundary). These are explicitly outside this repair scope.
- Local Gradle unit-test execution: BLOCKED because the wrapper attempted to download Gradle 9.3.1 and DNS could not resolve `downloads.gradle.org`.

## Not claimed
No CI-green, JVM-test-green, APK, install, device, signing, native-library, Firebase SHA-1, or runtime verification is claimed by this source-side repair.
