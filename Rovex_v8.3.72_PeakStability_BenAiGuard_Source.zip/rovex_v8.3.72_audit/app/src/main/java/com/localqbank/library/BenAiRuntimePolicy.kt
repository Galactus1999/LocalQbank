package com.localqbank.library

import android.content.Context

/**
 * User-visible governor for any future on-device Ben model runtime.
 *
 * Default is conservative and OFF: model inference must be explicitly enabled.
 * The persistent kill switch lets the user stop a problematic model without uninstalling.
 * This class owns policy only; it never starts threads or loads native/model resources.
 */
class BenAiRuntimePolicy(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)

    val conservativeMode: Boolean
        get() = prefs.getBoolean(KEY_CONSERVATIVE, true)

    fun setEnabled(value: Boolean) { prefs.edit().putBoolean(KEY_ENABLED, value).apply() }

    fun setConservativeMode(value: Boolean) { prefs.edit().putBoolean(KEY_CONSERVATIVE, value).apply() }

    fun mayStartModel(estimatedModelMb: Int): Boolean =
        BenAiRuntimeGate.mayStart(enabled, conservativeMode, estimatedModelMb)

    fun forceStop() { setEnabled(false) }

    companion object {
        const val CONSERVATIVE_MODEL_MB_LIMIT = BenAiRuntimeGate.CONSERVATIVE_MODEL_MB_LIMIT
        private const val PREFS = "ben_ai_runtime"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_CONSERVATIVE = "conservative_mode"
    }
}
