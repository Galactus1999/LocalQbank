package com.localqbank.library

/** Pure, deterministic gate for future Ben model runtimes. No Android APIs or I/O. */
object BenAiRuntimeGate {
    const val CONSERVATIVE_MODEL_MB_LIMIT = 1200

    fun mayStart(enabled: Boolean, conservativeMode: Boolean, estimatedModelMb: Int): Boolean {
        if (!enabled || estimatedModelMb <= 0) return false
        return !conservativeMode || estimatedModelMb <= CONSERVATIVE_MODEL_MB_LIMIT
    }
}
