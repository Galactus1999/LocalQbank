package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils
import androidx.core.view.MenuItemCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Shared persistent navigation shell for Rovex's five primary destinations.
 *
 * The navigation is installed into the Activity content container so screens with
 * programmatic layouts do not need to duplicate navigation XML. It is deliberately
 * a single owner: destinations only declare which tab is selected.
 */
object RovexBottomNavigation {
    const val STATE_KEY = "rovex.bottom_navigation.selected_index"
    private const val NAV_TAG = "rovex_bottom_navigation"
    private const val NAV_HEIGHT_DP = 64
    private const val HORIZONTAL_MARGIN_DP = 8
    private const val BOTTOM_MARGIN_DP = 6

    enum class Destination(val index: Int, val menuId: Int, val activity: Class<out Activity>, val titleRes: Int, val iconRes: Int) {
        HOME(0, R.id.nav_home, MainActivity::class.java, R.string.nav_home, R.drawable.ic_nav_home),
        QBANK(1, R.id.nav_qbank, MainQBankLibraryActivity::class.java, R.string.nav_qbank, R.drawable.ic_nav_qbank),
        FLASHCARDS(2, R.id.nav_flashcards, FlashcardActivity::class.java, R.string.nav_flashcards, R.drawable.ic_nav_flashcards),
        BEN(3, R.id.nav_ben, RenActivity::class.java, R.string.nav_ben, R.drawable.ic_nav_ben),
        NOTES(4, R.id.nav_notes, NotesActivity::class.java, R.string.nav_notes, R.drawable.ic_nav_notes)
    }

    fun install(activity: Activity, selectedIndex: Int, savedInstanceState: Bundle? = null) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val existing = content.findViewWithTag<View>(NAV_TAG)
        if (existing != null) {
            configure(activity, existing as BottomNavigationView, selectedIndex, savedInstanceState)
            return
        }

        val nav = BottomNavigationView(activity).apply {
            tag = NAV_TAG
            id = R.id.rovexPersistentBottomNavigation
            minimumHeight = dp(activity, NAV_HEIGHT_DP)
            elevation = dp(activity, 10).toFloat()
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            setPadding(dp(activity, 4), 0, dp(activity, 4), 0)
            background = UiDrawableUtils.roundedDrawable(activity, ThemeManager.elevated(activity), 22f)
            menu.clear()
            Destination.entries.forEach { destination ->
                val item = menu.add(0, destination.menuId, destination.index, destination.titleRes)
                item.setIcon(destination.iconRes)
                item.setCheckable(true)
                MenuItemCompat.setContentDescription(item, activity.getString(destination.titleRes))
            }
        }
        configure(activity, nav, selectedIndex, savedInstanceState)

        val originalLeft = content.paddingLeft
        val originalTop = content.paddingTop
        val originalRight = content.paddingRight
        val originalBottom = content.paddingBottom
        val navHeight = dp(activity, NAV_HEIGHT_DP)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            navHeight
        ).apply {
            gravity = Gravity.BOTTOM
            leftMargin = dp(activity, HORIZONTAL_MARGIN_DP)
            rightMargin = dp(activity, HORIZONTAL_MARGIN_DP)
            bottomMargin = dp(activity, BOTTOM_MARGIN_DP)
        }
        content.addView(nav, lp)

        // Keep the final row/action of every screen above the persistent bar and system
        // navigation area. Insets are consumed only for layout; no hardcoded system-bar size.
        ViewCompat.setOnApplyWindowInsetsListener(content) { view, insets ->
            val systemBottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            val extra = navHeight + dp(activity, BOTTOM_MARGIN_DP) + systemBottom
            view.setPadding(originalLeft, originalTop, originalRight, originalBottom + extra)
            insets
        }
        ViewCompat.requestApplyInsets(content)
    }

    fun saveInstanceState(outState: Bundle, selectedIndex: Int) {
        outState.putInt(STATE_KEY, selectedIndex.coerceIn(0, Destination.entries.lastIndex))
    }

    private fun configure(activity: Activity, nav: BottomNavigationView, selectedIndex: Int, savedInstanceState: Bundle?) {
        val restored = savedInstanceState?.getInt(STATE_KEY, selectedIndex) ?: selectedIndex
        val safeIndex = restored.coerceIn(0, Destination.entries.lastIndex)
        val accent = ThemeManager.accent(activity)
        val text = ThemeManager.text(activity)
        val muted = ThemeManager.muted(activity)
        nav.itemIconTintList = android.content.res.ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(accent, muted)
        )
        nav.itemTextColor = android.content.res.ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(accent, text)
        )
        nav.itemRippleColor = android.content.res.ColorStateList.valueOf(ColorUtils.setAlphaComponent(accent, 38))
        nav.itemBackgroundResource = android.R.color.transparent
        nav.background = UiDrawableUtils.roundedDrawable(activity, ThemeManager.elevated(activity), 22f)
        nav.setOnItemSelectedListener { item ->
            val destination = Destination.entries.firstOrNull { it.menuId == item.itemId } ?: return@setOnItemSelectedListener false
            if (destination.index == safeIndex) return@setOnItemSelectedListener true
            val intent = Intent(activity, destination.activity).apply {
                addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            activity.startActivity(intent)
            true
        }
        nav.setOnItemReselectedListener { }
        nav.selectedItemId = Destination.entries[safeIndex].menuId
        nav.menu.setGroupCheckable(0, true, true)
    }

    private fun dp(activity: Activity, value: Int): Int =
        (value * activity.resources.displayMetrics.density).toInt().coerceAtLeast(1)
}
