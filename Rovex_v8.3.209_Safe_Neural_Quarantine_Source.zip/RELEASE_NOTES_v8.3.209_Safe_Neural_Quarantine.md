# Rovex v8.3.209 — Safe Neural Execution Quarantine

Based directly on `Rovex_v8.3.207_CI_CompileFix_Source.zip`.

## Changes
- Normal Ben neural execution is centrally quarantined pending long-duration device validation.
- Deterministic Ben/QBank operation remains available.
- Existing isolated-process IPC, diagnostics, thermal governor, emergency stop and fallback architecture are preserved.
- Automatic IPC retry attempts reduced to one so a native/IPC failure cannot enter a restart loop.
- `QuizViewModel` persists transient SavedState before clearing its repository.
- Direct `androidx.lifecycle:lifecycle-viewmodel:2.9.2` dependency added for the `CreationExtras` factory API.
- Version bumped to 8.3.209 / versionCode 304.

## Important
The EmbeddingGemma/Gemma diagnostic implementations are retained for controlled validation. This change does not delete the validated NPU path; it prevents normal user-facing inference from invoking it.
