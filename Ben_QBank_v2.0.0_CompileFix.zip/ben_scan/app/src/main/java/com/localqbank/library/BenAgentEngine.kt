package com.localqbank.library

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

/**
 * Resource-aware autonomous loop. It adapts Ben's memory/mesh without running an LLM
 * continuously. Expensive semantic AI can be added later behind the same budget gate.
 */
object BenAgentEngine {
    private const val MAX_SECTIONS_PER_CYCLE = 120
    private const val MAX_WRONG_QUESTIONS = 250

    fun run(context: Context): Boolean {
        if (!hasResourceBudget(context)) return false
        val app = context.applicationContext
        val db = QBankDb(app)
        val store = BenAgentStore(app)
        val progress = ProgressStore(app)
        return try {
            val sectionOffset = store.cursor("section_cursor")
            val sections = db.agentSections(MAX_SECTIONS_PER_CYCLE, sectionOffset)
            if (sections.isEmpty() && sectionOffset > 0) {
                store.setCursor("section_cursor", 0)
            }
            val sectionByLabel = sections.associateBy { it.title.trim().lowercase() }
            var processed = 0
            sections.forEach { section ->
                val key = "section:${section.key}"
                store.upsertNode(key, section.title, "section")
                if (section.questionCount > 0) {
                    val signal = (section.questionCount.coerceAtMost(500) / 500.0) * 0.02
                    store.adjustConfidence(key, signal)
                }
                processed++
            }
            if (sections.isNotEmpty()) {
                val next = sectionOffset + sections.size
                store.setCursor("section_cursor", if (sections.size < MAX_SECTIONS_PER_CYCLE) 0 else next)
            }

            // Read only stable keys/categories; never materialise question text or explanations.
            val questionOffset = store.cursor("question_cursor")
            val refs = db.agentQuestions(MAX_WRONG_QUESTIONS * 4, questionOffset)
            if (refs.isEmpty() && questionOffset > 0) {
                store.setCursor("question_cursor", 0)
            }
            var wrongProcessed = 0
            refs.asSequence()
                .filter { progress.status(it.stableKey) == "wrong" }
                .take(MAX_WRONG_QUESTIONS)
                .groupBy { it.category.ifBlank { "Uncategorised" } }
                .forEach { (category, wrongs) ->
                    val key = "weak:${category.lowercase()}"
                    store.upsertNode(key, "Weak: $category", "weak", 0.35)
                    store.adjustConfidence(key, -(0.01 * wrongs.size.coerceAtMost(5)))
                    sectionByLabel[category.trim().lowercase()]?.let {
                        store.connect("section:${it.key}", key, 0.04)
                    }
                    wrongProcessed += wrongs.size
                }

            if (refs.isNotEmpty()) {
                val next = questionOffset + refs.size
                store.setCursor("question_cursor", if (refs.size < MAX_WRONG_QUESTIONS * 4) 0 else next)
            }
            store.observe("agent_cycle", "sections=$processed;wrong=$wrongProcessed", processed.toDouble())
            store.trimHistory()
            true
        } finally {
            progress.close()
            db.close()
            store.shutdown()
        }
    }

    fun hasResourceBudget(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mem)
        if (mem.lowMemory) return false

        val battery = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        if (battery?.isCharging == false) {
            val pct = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (pct in 0..19) return false
        }

        if (Build.VERSION.SDK_INT >= 29) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (pm?.isPowerSaveMode == true && battery?.isCharging != true) return false
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (pm != null && pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) return false
        }
        return true
    }
}
