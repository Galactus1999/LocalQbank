package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

class BenActivity : AppCompatActivity() {
    private lateinit var store: BenAgentStore
    private lateinit var mesh: BenMeshView
    private lateinit var status: TextView
    private val executor=Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store=BenAgentStore(this)
        setContentView(build())
        refreshMesh()
    }

    override fun onDestroy(){
        executor.shutdownNow()
        if(::store.isInitialized)store.shutdown()
        super.onDestroy()
    }

    private fun roundedDrawable(color: Int, radius: Float): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }

    private fun build(): LinearLayout {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,18,20,20);setBackgroundColor(Color.rgb(247,250,248))}
        val title=TextView(this).apply{text="🤖  Ben";textSize=30f;setTextColor(Color.rgb(18,48,79));typeface=android.graphics.Typeface.DEFAULT_BOLD}
        root.addView(title, LinearLayout.LayoutParams(-1,-2))
        status=TextView(this).apply{text="Local autonomous study agent • resource-aware";textSize=14f;setTextColor(Color.rgb(85,103,116));setPadding(0,3,0,8)}
        root.addView(status)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,12,14,12);background=roundedDrawable(Color.WHITE,18f)}
        val head=TextView(this).apply{text="Ben's living knowledge mesh";textSize=19f;typeface=android.graphics.Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(25,55,75))}
        card.addView(head)
        mesh=BenMeshView(this); card.addView(mesh,LinearLayout.LayoutParams(-1,330))
        root.addView(card,LinearLayout.LayoutParams(-1,0,1f))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val ask=Button(this).apply{text="Ask Ben";isAllCaps=false;setOnClickListener{showAsk()}}
        val study=Button(this).apply{text="Study with Ben";isAllCaps=false;setOnClickListener{startActivity(Intent(this@BenActivity,StudyToolsActivity::class.java))}}
        actions.addView(ask,LinearLayout.LayoutParams(0,56,1f)); actions.addView(study,LinearLayout.LayoutParams(0,56,1f))
        root.addView(actions)
        val info=TextView(this).apply{text="Ben can learn from the whole local QBank. Background learning is bounded by memory, battery, storage and thermal safeguards so he does not continuously load the device.";textSize=12f;setTextColor(Color.rgb(85,103,116));setPadding(2,8,2,0)}
        root.addView(info)
        return root
    }

    private fun refreshMesh(){
        executor.execute {
            runCatching {
                BenAgentEngine.run(applicationContext)
                val nodes=store.nodes()
                val edges=store.edges()
                val weak=store.weakCount()
                val events=store.eventCount()
                runOnUiThread{
                    if(!isFinishing && !isDestroyed){
                        mesh.submit(nodes,edges)
                        status.text="${nodes.size} active nodes • $weak weak areas • $events learning events"
                    }
                }
            }.onFailure {
                runOnUiThread { if(!isFinishing && !isDestroyed) status.text="Ben paused safely: ${it.message ?: "temporary resource error"}" }
            }
        }
    }

    private fun showAsk(){
        val input=EditText(this).apply{hint="Ask Ben about your QBank or study";minLines=3}
        AlertDialog.Builder(this).setTitle("Ask Ben").setView(input).setPositiveButton("Think"){_,_ ->
            store.observe("chat",input.text.toString())
            Toast.makeText(this,"Ben stored the request locally. Semantic local reasoning is the next intelligence layer.",Toast.LENGTH_LONG).show()
        }.setNegativeButton("Cancel",null).show()
    }
}
