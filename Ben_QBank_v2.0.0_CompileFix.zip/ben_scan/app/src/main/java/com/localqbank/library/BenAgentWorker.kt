package com.localqbank.library

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class BenAgentWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return runCatching {
            if (!BenAgentEngine.hasResourceBudget(applicationContext)) Result.retry()
            else if (BenAgentEngine.run(applicationContext)) Result.success() else Result.retry()
        }.getOrElse { Result.retry() }
    }
}
