package com.localqbank.library

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local persistent state for Ben. Keeps the agent's memory separate from the QBank database. */
class BenAgentStore(context: Context) : SQLiteOpenHelper(context, "ben_agent.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE node(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT UNIQUE NOT NULL, label TEXT NOT NULL, kind TEXT NOT NULL, weight REAL NOT NULL DEFAULT 1.0, confidence REAL NOT NULL DEFAULT 0.5, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE edge(from_key TEXT NOT NULL, to_key TEXT NOT NULL, strength REAL NOT NULL DEFAULT 0.1, updated_at INTEGER NOT NULL, PRIMARY KEY(from_key,to_key))")
        db.execSQL("CREATE TABLE event(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, ref TEXT, value REAL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_event_created ON event(created_at)")
        db.execSQL("CREATE INDEX idx_node_updated ON node(updated_at)")
        db.execSQL("CREATE TABLE meta(key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_event_created ON event(created_at)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_node_updated ON node(updated_at)")
        }
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)")
        }
    }

    fun observe(type: String, ref: String? = null, value: Double? = null) {
        writableDatabase.insert("event", null, ContentValues().apply {
            put("type", type)
            if (ref == null) putNull("ref") else put("ref", ref.take(240))
            if (value == null) putNull("value") else put("value", value)
            put("created_at", System.currentTimeMillis())
        })
    }

    fun upsertNode(key: String, label: String, kind: String, confidence: Double = 0.5) {
        val db = writableDatabase
        val existing = db.rawQuery("SELECT confidence,weight FROM node WHERE key=? LIMIT 1", arrayOf(key)).use { c ->
            if (c.moveToFirst()) c.getDouble(0) to c.getDouble(1) else null
        }
        val cv = ContentValues().apply {
            put("key", key.take(180)); put("label", label.take(120)); put("kind", kind.take(40))
            put("confidence", (existing?.first ?: confidence).coerceIn(0.0, 1.0))
            put("weight", existing?.second ?: 1.0)
            put("updated_at", System.currentTimeMillis())
        }
        db.insertWithOnConflict("node", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun adjustConfidence(key: String, delta: Double) {
        writableDatabase.execSQL(
            "UPDATE node SET confidence=MIN(1.0,MAX(0.0,confidence+?)), weight=MIN(10.0,weight+?), updated_at=? WHERE key=?",
            arrayOf(delta, if (delta >= 0) 0.02 else 0.05, System.currentTimeMillis(), key)
        )
    }

    fun connect(a: String, b: String, delta: Double = 0.05) {
        val from = a.take(180)
        val to = b.take(180)
        val change = delta.coerceAtLeast(0.0)
        val db = writableDatabase
        db.beginTransaction()
        try {
            val updated = db.compileStatement(
                "UPDATE edge SET strength=MIN(1.0,strength+?),updated_at=? WHERE from_key=? AND to_key=?"
            ).apply {
                bindDouble(1, change)
                bindLong(2, System.currentTimeMillis())
                bindString(3, from)
                bindString(4, to)
            }.executeUpdateDelete()
            if (updated == 0) {
                db.insertOrThrow("edge", null, ContentValues().apply {
                    put("from_key", from)
                    put("to_key", to)
                    put("strength", change.coerceAtMost(1.0))
                    put("updated_at", System.currentTimeMillis())
                })
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun cursor(name: String): Int = readableDatabase.rawQuery(
        "SELECT value FROM meta WHERE key=? LIMIT 1", arrayOf(name)
    ).use { c -> if (c.moveToFirst()) c.getString(0).toIntOrNull()?.coerceAtLeast(0) ?: 0 else 0 }

    fun setCursor(name: String, value: Int) {
        writableDatabase.insertWithOnConflict(
            "meta", null, ContentValues().apply { put("key", name); put("value", value.coerceAtLeast(0).toString()) },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    /** Retains bounded recent history so Ben's memory cannot grow forever. */
    fun trimHistory(maxEvents: Int = 5000) {
        val safeMax = maxEvents.coerceIn(500, 20000)
        writableDatabase.execSQL(
            "DELETE FROM event WHERE id NOT IN (SELECT id FROM event ORDER BY id DESC LIMIT ?)",
            arrayOf(safeMax)
        )
    }

    data class Node(val key:String,val label:String,val kind:String,val confidence:Double,val weight:Double)
    data class Edge(val from:String,val to:String,val strength:Double)

    fun nodes(limit: Int = 28): List<Node> = readableDatabase.rawQuery(
        "SELECT key,label,kind,confidence,weight FROM node ORDER BY weight DESC,updated_at DESC LIMIT ?",
        arrayOf(limit.coerceIn(1,100).toString())
    ).use { c -> buildList { while(c.moveToNext()) add(Node(c.getString(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4))) } }

    fun edges(limit: Int = 80): List<Edge> = readableDatabase.rawQuery(
        "SELECT from_key,to_key,strength FROM edge ORDER BY strength DESC LIMIT ?",
        arrayOf(limit.coerceIn(1,200).toString())
    ).use { c -> buildList { while(c.moveToNext()) add(Edge(c.getString(0),c.getString(1),c.getDouble(2))) } }

    /** Explicit lifecycle hook for the agent store. */
    fun shutdown() { super.close() }

    fun eventCount(): Long = readableDatabase.rawQuery("SELECT COUNT(*) FROM event", null).use { c -> c.moveToFirst(); c.getLong(0) }
    fun weakCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM node WHERE confidence < 0.55", null).use { c -> c.moveToFirst(); c.getInt(0) }
}
