# LocalQBank v8.0.1 — Neural Core / Adaptive Study Architecture

## Release intent
This release strengthens the application as a system rather than adding another isolated engine.
The previous v7.30.1 UI/stability work is retained, while the study core, state flow, navigation,
import reliability, adaptive strategy, Ben memory and performance architecture are hardened.

## The 16 architectural upgrades
1. **Canonical Study State Repository** — common progress reads/writes are exposed through `StudyStateRepository`.
2. **Study Event Spine** — `StudyEventSpine` provides a typed asynchronous lane for cross-engine coordination.
3. **Versioned engine contracts** — `EngineContractV2`/`StudyEngineV2` formalise capability and health boundaries.
4. **Ben remains a cognitive interface** — specialist engines stay bounded; Ben does not own raw persistence or executable code.
5. **Adaptive Engine safety** — existing reversible runtime policy remains the only autonomous actuation surface.
6. **Learning Graph** — deterministic question → category → test → source relationships are available without a remote graph service.
7. **Transition Coordinator** — consistent screen transition policy while preserving Android predictive-back/system animations.
8. **Navigation contract** — stable destination identifiers prevent labels from becoming routing APIs.
9. **Study Session Store** — current quiz cursor is persisted independently from crash recovery.
10. **Database/core hardening** — WAL, indexes, bounded queries and cached progress remain the persistence strategy.
11. **Serialized import pipeline** — imports can be queued through `ImportPipelineCoordinator`; large parsing stays off the UI thread.
12. **Performance Lab hooks** — cheap timing probes provide CI/device instrumentation points without storing question content.
13. **Tiered startup** — `StartupCoordinator` centralises critical startup and keeps heavy indexing lazy.
14. **Ben bounded memory** — working/study memory is local, bounded and never executable.
15. **Strategy + explainability** — `StudyStrategyEngine` ranks repair/due/new work and `AdaptiveExplainability` explains runtime policy.
16. **Security + Android 16 readiness** — import size/URI guards, hardened WebView policy, window-aware adaptive layout and target/compile API 36.

## UX corrections in this release
- Theme selector redesigned as a compact visual picker with swatches, descriptions and selected state.
- Font selector redesigned as a live typography preview rather than a plain dark text list.
- Notes redesigned as a Knowledge Vault surface with search, filters, subject grouping, metadata, separated key points/personal notes, and safer actions.
- Quiz session continuity now persists through the dedicated study session store.
- Screen transitions use one coordinator and avoid fighting Android's predictive-back system animations.

## Verification policy
The source includes compile-oriented XML/view-ID audits, runtime-risk audits, architecture contract checks,
unsafe blocking-call checks, import security checks and activity window-policy checks in CI.

The packaging environment does not contain the Android SDK/Gradle toolchain, so **GitHub Actions remains the
authoritative Android compilation/device-independent source build check**. This release does not claim a local
APK compile that was not actually performed.

## Research basis
Architecture decisions follow current Android guidance for data-layer repositories/source-of-truth,
offline-first local persistence, Navigation/predictive back, Macrobenchmark/Baseline Profiles, and adaptive
window sizing. See the official Android Developers documentation used during the architecture review.


## v8.0.1 build correction
- Fixed `NotesActivity` Kotlin compilation error: `EditText.singleLine` → `EditText.isSingleLine`.
- Upgraded Android Gradle Plugin to 8.10.1 and Gradle CI to 8.11.1 so compileSdk/targetSdk 36 uses an AGP version officially supporting API 36.
- Added CI static detection for accidental `singleLine=` assignments.
