package com.localqbank.library

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Controlled bridge between Ben's deterministic cognition and the optional neural accelerator.
 * The model never becomes the source of truth: local QBank evidence is supplied to the model,
 * then the draft is passed back through Ben's existing planner/verifier before it can be shown.
 */
class BenGroundedNeuralPipeline(context: Context) {
    private val app = context.applicationContext
    private val generator = BenLiteRtLmGenerator(app)
    private val cognitive = BenCognitiveArchitecture(app)
    private val embedding = BenEmbeddingGemmaEngine(app)
    private val clinical = ClinicalKnowledgeLayer(app)
    private val examTerms = BenExamTerminology(app)

    data class Result(
        val answer: String,
        val modelUsed: Boolean,
        val verified: Boolean,
        val confidence: Int,
        val evidenceCount: Int,
        val elapsedMs: Long
    )

    suspend fun run(query: String): Result = withContext(Dispatchers.IO) {
        BenNeuralTelemetry.begin("Grounded Ben query")
        val clean = BenResearchInputPolicy.normalize(query)
            ?: return@withContext Result("Give Ben a clinical term, topic, question, or study task.", false, true, 0, 0, 0)

        // Do not pin a SQLite handle for the lifetime of the neural pipeline. Ben may live for
        // the entire application process, while imports/restores can replace or rebuild the DB.
        // A short-lived handle per grounded request avoids stale connections and is bounded by
        // the existing background execution context.
        val qbank = QBankDb(app)
        try {
            val understanding = clinical.understand(clean)
            val examContext = examTerms.understand(clean)
            BenNeuralTelemetry.stage(BenNeuralTelemetry.Stage.FTS_RECALL, if (understanding.visualIntent) "Retrieving image-bearing QBank candidates" else "Retrieving local QBank candidates")
            val visualBase = linkedSetOf<String>().apply {
                understanding.concepts.take(6).forEach { add(it.canonical) }
                understanding.domains.filter { it.length >= 3 }.forEach { add(it) }
            }.joinToString(" ").ifBlank { clean }
            val hits = runCatching {
                if (understanding.visualIntent) qbank.searchImageQuestions(visualBase, 12) else qbank.search(clean, 12)
            }.getOrElse { emptyList() }
        BenNeuralTelemetry.stage(BenNeuralTelemetry.Stage.SEMANTIC_RERANK, if (understanding.visualIntent) "Semantic reranking ${hits.size} actual image-bearing candidates" else "Semantic reranking ${hits.size} candidates", "EmbeddingGemma 300M", "Embedding")
        val semanticQuery = (clean + " " + examContext.expanded.take(8).joinToString(" ")).trim().take(1800)
        val semantic = embedding.rerank(semanticQuery, hits, { it.text }, 8)
        BenNeuralTelemetry.semantic(semantic.elapsedMs, semantic.usedModel)
        val rankedHits = if (semantic.usedModel && semantic.hits.isNotEmpty()) semantic.hits.map { it.item } else hits.take(8)
        val evidence = rankedHits.take(6).mapIndexed { index, hit ->
            "[${index + 1}] ${hit.text.replace(Regex("\\s+"), " ").trim().take(700)}"
        }
        val prompt = buildPrompt(clean, evidence, examContext.promptContext, understanding.visualIntent, understanding.visualKinds)
        BenNeuralTelemetry.stage(BenNeuralTelemetry.Stage.GENERATION, "Generating grounded draft", "Gemma 3 270M", "Generation")
        val draft = generator.generate(prompt, 160)
        BenNeuralTelemetry.generation(draft?.elapsedMs ?: 0L, draft != null)
        if (draft == null) {
            BenNeuralTelemetry.stage(BenNeuralTelemetry.Stage.FALLBACK, "Neural generation unavailable; deterministic Ben answering")
            val fallback = cognitive.answer(clean)
            val elapsed = System.currentTimeMillis() - (BenNeuralTelemetry.snapshot().startedAtMs)
            val neuralUsed = semantic.usedModel
            BenNeuralTelemetry.complete(evidence.size, fallback.verified, fallback.confidence, elapsed.coerceAtLeast(0L), neuralUsed)
            return@withContext Result(fallback.answer, neuralUsed, fallback.verified, fallback.confidence, evidence.size, elapsed.coerceAtLeast(0L))
        }

        BenNeuralTelemetry.stage(BenNeuralTelemetry.Stage.VERIFICATION, "Verifying neural draft with Ben")
        val verified = runCatching {
            cognitive.answer(clean, baseAnswer = draft.text, modelUsed = true)
        }.getOrNull()

        if (verified == null || verified.answer.isBlank()) {
            BenNeuralTelemetry.stage(BenNeuralTelemetry.Stage.FALLBACK, "Verifier rejected draft; deterministic fallback")
            val fallback = cognitive.answer(clean)
            BenNeuralTelemetry.complete(evidence.size, fallback.verified, fallback.confidence, draft.elapsedMs, false)
            return@withContext Result(fallback.answer, false, fallback.verified, fallback.confidence, evidence.size, draft.elapsedMs)
        }
        BenNeuralTelemetry.complete(evidence.size, verified.verified, verified.confidence, draft.elapsedMs, true)
            Result(
                answer = verified.answer,
                modelUsed = verified.modelUsed,
                verified = verified.verified,
                confidence = verified.confidence,
                evidenceCount = evidence.size,
                elapsedMs = draft.elapsedMs
            )
        } finally {
            qbank.close()
        }
    }

    private fun buildPrompt(query: String, evidence: List<String>, examContext: String, visualIntent: Boolean, visualKinds: Set<String>): String = buildString {
        append("Clinical study query:\n")
        append(query)
        append("\n\nExam-language context (student shorthand only; not medical evidence):\n")
        append(examContext)
        append("\n\nLocal QBank evidence (use only when relevant):\n")
        if (evidence.isEmpty()) append("No matching local evidence was found.\n")
        else evidence.forEach { append(it).append('\n') }
        if (visualIntent) {
            append("\nVisual retrieval requirement: the user is asking for image-bearing questions. Never equate the words 'image', 'slide' or 'pathology' in a stem with an actual image. Ben's retrieval layer has already hard-filtered for imported question/explanation images. Visual kinds detected: ")
            append(visualKinds.joinToString(", "))
            append(".\n")
        }
        append("\nDraft a concise medical-study answer. Do not invent facts, doses, guidelines, citations, patient-specific treatment, or visual findings you have not been given. If evidence is insufficient, say so. This is a draft for Ben's deterministic verifier.")
    }
}
