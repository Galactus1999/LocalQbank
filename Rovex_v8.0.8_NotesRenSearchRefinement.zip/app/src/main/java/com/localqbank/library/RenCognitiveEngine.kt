package com.localqbank.library

import android.content.Context
import kotlin.math.min

/** Offline-first cognitive layer for Ren. Deterministic, bounded, and QBank-grounded. */
class RenCognitiveEngine(context: Context) {
    private val app = context.applicationContext

    data class Insight(val title: String, val body: String, val actions: List<String> = emptyList())

    fun answer(command: String, currentQuestion: Question? = null): Insight {
        val text = command.trim()
        if (text.isBlank()) return Insight("Ren", "Tell me what you want to study, save, summarise or practise.")
        val lower = text.lowercase()
        return when {
            currentQuestion != null && ("summar" in lower || "explain" in lower || "key point" in lower || "high yield" in lower) -> summarise(currentQuestion)
            "flashcard" in lower || "flash card" in lower ->
                Insight("Flashcards", "I will only create cards when you explicitly ask. Each card keeps the MCQ on the front and reveals only the correct answer option.", listOf("Generate adaptive cards"))
            "note" in lower || "summary" in lower ->
                Insight("Knowledge", "I can turn the current question into a structured note, extracting high-yield points instead of copying the whole explanation.", listOf("Create auto-note"))
            "wrong" in lower || "mistake" in lower -> {
                val ids = AppManagers.studyIntelligence.smartMix(30)
                Insight("Weakness review", "I prepared a local adaptive pool of ${ids.size} questions, prioritising due and weak items.", listOf("Start adaptive mix"))
            }
            "what should i study" in lower || "what should i revise" in lower || "study plan" in lower ->
                Insight("Study plan", AppManagers.adaptive.studyStrategy(), listOf("Open Study Tools"))
            else -> searchQBank(text)
        }
    }

    private fun searchQBank(command: String): Insight {
        val query = cleanSearchQuery(command)
        if (query.length < 3) return Insight("Ren", "I need a little more detail. Try a subject, topic, or exact clinical term.")
        val ordered = searchQuestionRefs(query, 100)
        if (ordered.isNotEmpty()) {
            val variants = clinicalVariants(query)
            val examples = ordered.take(5).map { "Q${it.position + 1} • ${it.testTitle}" }
            val variantNote = if (variants.size > 1) " I also checked closely related clinical terminology." else ""
            return Insight(
                "QBank search: ${query.replaceFirstChar { it.uppercase() }}",
                "Found ${ordered.size} relevant local question${if (ordered.size == 1) "" else "s"}.$variantNote\n\n" + examples.joinToString("\n") + "\n\nRen prioritised actual question content and explanations over source labels, reducing unrelated matches such as an X-ray question from another QBank.",
                listOf("Open matching questions")
            )
        }
        return Insight("No strong QBank match", "I searched the local question content for “$query” but did not find a strong match. Try a broader clinical term or another spelling.")
    }

    /** Returns the same ranked local results used by Ren's conversational search UI. */
    fun searchQuestionIds(command: String, limit: Int = 100): LongArray =
        searchQuestionRefs(cleanSearchQuery(command), limit).map { it.id }.toLongArray()

    private fun cleanSearchQuery(command: String): String = command
        .replace(Regex("(?i)\\b(find|search|show|give|open|questions?|qbank|topic|subject|about)\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun searchQuestionRefs(query: String, limit: Int): List<QuestionRef> {
        if (query.length < 2) return emptyList()
        val variants = clinicalVariants(query)
        val ranked = linkedMapOf<Long, Int>()
        val refById = PerformanceManager.refs(app).associateBy { it.id }
        val db = QBankDb(app)
        try {
            db.ensureSearchIndex()
            variants.forEachIndexed { variantIndex, variant ->
                db.search(variant).forEach { hit ->
                    val hay = "${hit.text} ${hit.testTitle} ${hit.path.orEmpty()} ${hit.sourceName}".lowercase()
                    val words = variant.lowercase().split(Regex("[^a-z0-9]+" )).filter { it.length >= 2 }.distinct()
                    var score = 100 - variantIndex * 3
                    score += words.count { hay.contains(it) } * 12
                    if (hay.contains(variant.lowercase())) score += 80
                    ranked[hit.id] = maxOf(ranked[hit.id] ?: Int.MIN_VALUE, score)
                }
            }
        } finally { db.close() }
        return ranked.entries.sortedByDescending { it.value }.mapNotNull { refById[it.key] }.take(limit.coerceIn(1, 200))
    }


    private fun clinicalVariants(query: String): List<String> {
        val normalized = query.lowercase().trim()
        val variants = linkedSetOf(query)
        if (normalized.contains("cancer") && normalized.contains("marker")) {
            variants += query.replace(Regex("(?i)cancer"), "tumor")
            variants += query.replace(Regex("(?i)cancer"), "tumour")
            variants += query.replace(Regex("(?i)cancer"), "neoplasm")
            variants += query.replace(Regex("(?i)cancer"), "malignancy")
            variants += query.replace(Regex("(?i)marker"), "biomarker")
        }
        if (normalized == "cancer") {
            variants += "tumor"
            variants += "tumour"
            variants += "neoplasm"
            variants += "malignancy"
        }
        if (normalized == "heart attack") variants += "myocardial infarction"
        if (normalized == "stroke") variants += "cerebrovascular accident"
        if (normalized == "heart failure") variants += "cardiac failure"
        return variants.toList()
    }


    fun summarise(q: Question): Insight {
        val answer = plain(q.correctAnswer ?: q.options.firstOrNull { it.correct }?.label.orEmpty())
        val exp = plain(q.explanation.orEmpty())
        val points = extractKeyPoints(exp)
        val body = buildString {
            if (answer.isNotBlank()) append("Answer: ").append(answer.take(260)).append("\n\n")
            append("Key points\n")
            if (points.isEmpty()) append("Review the original explanation for the full context.")
            else points.forEach { append("• ").append(it).append('\n') }
        }.trim()
        return Insight("Ren's local summary", body, listOf("Save as note", "Create flashcard"))
    }

    fun extractKeyPoints(text: String): List<String> {
        val clean = plain(text)
        if (clean.isBlank()) return emptyList()
        val sentences = clean.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.length >= 35 }
        val markers = listOf("most common", "important", "first line", "gold standard", "diagnosis", "treatment", "management", "contraindication", "adverse", "associated", "classically", "hallmark", "preferred", "mcq", "exam")
        return sentences
            .sortedWith(compareByDescending<String> { s -> markers.count { s.contains(it, true) } }.thenByDescending { s -> min(s.length, 220) })
            .distinct()
            .take(7)
            .map { it.take(220) }
    }

    fun capabilities(): List<String> = listOf("Local QBank search", "Intent detection", "Question summarisation", "Key-point extraction", "Adaptive study planning", "Bounded engine actions")

    private fun plain(html: String): String = android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()
}
