package com.localqbank.library

/**
 * Narrow adapter boundary for Ben's future on-device inference runtime.
 * Implementations must remain offline unless a future product decision explicitly
 * permits another transport. The stability build ships only the unavailable backend.
 */
interface BenInferenceBackend {
    val isAvailable: Boolean

    fun answer(prompt: String): String?
}
