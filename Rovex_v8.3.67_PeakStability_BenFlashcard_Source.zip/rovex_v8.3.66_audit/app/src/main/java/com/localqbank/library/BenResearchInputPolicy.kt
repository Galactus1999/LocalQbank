package com.localqbank.library

/** Deterministic, allocation-bounded input policy for Ben's local research gateway. */
object BenResearchInputPolicy {
    const val MAX_QUERY_CHARS = 4096

    fun normalize(raw: String): String? {
        if (raw.isEmpty()) return null
        // Strip embedded control characters while retaining ordinary Unicode clinical text.
        // Collapsing whitespace makes equivalent queries produce the same retrieval key and
        // prevents accidental multi-line payloads from expanding downstream work.
        val clean = buildString(minOf(raw.length, MAX_QUERY_CHARS + 256)) {
            var pendingSpace = false
            raw.forEach { ch ->
                if (length >= MAX_QUERY_CHARS) return@forEach
                when {
                    ch.isISOControl() && ch != '\n' && ch != '\t' -> Unit
                    ch.isWhitespace() -> pendingSpace = true
                    else -> {
                        if (pendingSpace && isNotEmpty()) append(' ')
                        pendingSpace = false
                        append(ch)
                    }
                }
                if (length >= MAX_QUERY_CHARS) return@forEach
            }
        }.trim()
        if (clean.isEmpty()) return null
        return if (clean.length <= MAX_QUERY_CHARS) clean else clean.take(MAX_QUERY_CHARS).trimEnd()
    }
}
