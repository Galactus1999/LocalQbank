package com.localqbank.library

/** Pure geometry policy for persisted draggable flashcard controls. */
object MovableControlPosition {
    data class Point(val x: Float, val y: Float)

    fun resolve(
        savedX: Float,
        savedY: Float,
        maxX: Int,
        maxY: Int,
        defaultXFraction: Float,
        defaultYFraction: Float
    ): Point {
        val safeMaxX = maxX.coerceAtLeast(0)
        val safeMaxY = maxY.coerceAtLeast(0)
        val x = if (savedX.isNaN()) safeMaxX * defaultXFraction else savedX * safeMaxX
        val y = if (savedY.isNaN()) safeMaxY * defaultYFraction else savedY * safeMaxY
        return Point(x.coerceIn(0f, safeMaxX.toFloat()), y.coerceIn(0f, safeMaxY.toFloat()))
    }

    fun normalized(x: Float, y: Float, maxX: Int, maxY: Int): Point {
        val safeMaxX = maxX.coerceAtLeast(1)
        val safeMaxY = maxY.coerceAtLeast(1)
        return Point(
            (x / safeMaxX).coerceIn(0f, 1f),
            (y / safeMaxY).coerceIn(0f, 1f)
        )
    }
}
