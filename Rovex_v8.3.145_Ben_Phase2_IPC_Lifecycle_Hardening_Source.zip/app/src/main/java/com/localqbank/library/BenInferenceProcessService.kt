package com.localqbank.library

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import android.os.Process
import android.os.PowerManager
import android.os.Build
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Isolated neural-runtime service.
 *
 * v8.3.145: single-flight/latest-request-wins generation, explicit remote cancellation, native
 * LiteRT-LM async streaming, and a release barrier before a replacement request may run.
 */
class BenInferenceProcessService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val singleFlight = Mutex()
    private val requests = ConcurrentHashMap<String, GenerationControl>()
    private val serviceGenerationId = AtomicLong(System.nanoTime())
    private val handlerThread by lazy { HandlerThread("ben-inference-binder").also { it.start() } }
    private var generator: BenLiteRtLmGenerator? = null
    private var embedding: BenEmbeddingGemmaEngine? = null
    private var generatorWarm = false
    private var embeddingWarm = false
    private lateinit var messenger: Messenger
    private val powerManager by lazy { getSystemService(PowerManager::class.java) }
    private val thermalListener = if (Build.VERSION.SDK_INT >= 29) object : PowerManager.OnThermalStatusChangedListener {
        override fun onThermalStatusChanged(status: Int) {
            if (status >= PowerManager.THERMAL_STATUS_SEVERE) activeGeneration?.cancel()
        }
    } else null
    @Volatile private var activeGeneration: GenerationControl? = null

    private class GenerationControl(
        val requestId: String,
        val clientGeneration: Long,
        val reply: Messenger,
    ) {
        val cancelled = AtomicBoolean(false)
        val terminalSent = AtomicBoolean(false)
        /** True only after the native generation/session has actually returned and the release barrier has completed. */
        val nativeReleased = AtomicBoolean(false)
        @Volatile var job: Job? = null
        @Volatile var nativeCancel: (() -> Unit)? = null

        fun cancel() {
            if (cancelled.compareAndSet(false, true)) runCatching { nativeCancel?.invoke() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        messenger = Messenger(Handler(handlerThread.looper) { message -> handle(message) })
        if (Build.VERSION.SDK_INT >= 29) runCatching { thermalListener?.let { powerManager?.addThermalStatusListener(it) } }
    }

    private fun handle(message: Message): Boolean {
        when (message.what) {
            CMD_GENERATE -> startGeneration(message)
            CMD_CANCEL -> cancelGeneration(message.data.getString(KEY_REQUEST_ID).orEmpty())
            CMD_RERANK, CMD_DIAGNOSTIC, CMD_COMPARE -> scope.launch { singleFlight.withLock { handleOneShot(message) } }
            CMD_PING -> sendReply(message.replyTo, REPLY_PING, Bundle().apply { putBoolean(KEY_OK, true) })
            else -> return false
        }
        return true
    }

    private fun startGeneration(message: Message) {
        val requestId = message.data.getString(KEY_REQUEST_ID).orEmpty()
        val reply = message.replyTo ?: return
        if (requestId.isBlank()) return
        activeGeneration?.cancel()
        val control = GenerationControl(
            requestId = requestId,
            clientGeneration = message.data.getLong(KEY_CLIENT_GENERATION),
            reply = reply,
        )
        requests[requestId] = control
        control.job = scope.launch {
            try {
                singleFlight.withLock {
                    if (control.cancelled.get()) {
                        control.nativeReleased.set(true)
                        return@withLock
                    }
                    activeGeneration = control
                    try {
                        runGeneration(control, message.data.getString(KEY_PROMPT).orEmpty(), message.data.getInt(KEY_MAX_TOKENS, 160))
                    } finally {
                        // A cancelled/thermally aborted native session must be torn down before
                        // the single-flight lock is released. This is the actual release barrier;
                        // sending a terminal Binder reply is deliberately NOT considered release.
                        if (control.cancelled.get()) closeGeneratorForRelease()
                        control.nativeReleased.set(true)
                        activeGeneration = null
                    }
                }
            } finally {
                requests.remove(requestId, control)
                control.nativeReleased.set(true)
            }
        }
    }

    private suspend fun runGeneration(control: GenerationControl, prompt: String, maxTokens: Int) {
        val governor = BenAiResourceGovernor(applicationContext)
        val policy = BenAiRuntimePolicy(applicationContext)
        val profile = BenNeuralModelRegistry.gemma3_270m
        val installed = BenNeuralModelManager(applicationContext).installed(profile)
        if (installed == null || !governor.mayRun(policy, profile.estimatedRuntimeMb, foreground = true)) {
            sendTerminal(control, failed = true, error = "Generation blocked by model/resource policy")
            return
        }
        val promptBudget = BenAiResourceGate.promptBudgetChars(governor.snapshot(foreground = true).thermalStatus)
        if (promptBudget <= 0) {
            sendTerminal(control, failed = true, error = "Thermal safety gate denied neural generation")
            return
        }
        try {
            if (generator == null) generator = BenLiteRtLmGenerator(applicationContext)
            val stream = generator!!.generateStream(
                prompt = prompt.take(promptBudget),
                maxOutputTokens = maxTokens,
                onCancel = { control.cancelled.get() },
                onNativeCancelReady = { cancel -> control.nativeCancel = cancel },
            )
            stream
                .catch { error ->
                    if (error is CancellationException || control.cancelled.get()) {
                        sendTerminal(control, cancelled = true)
                    } else {
                        policy.recordBackendFailure()
                        sendTerminal(control, failed = true, error = error.message ?: error.javaClass.simpleName)
                    }
                }
                .collect { chunk ->
                    if (!control.cancelled.get()) sendToken(control, chunk)
                }
            if (control.cancelled.get()) {
                sendTerminal(control, cancelled = true)
            } else {
                policy.recordBackendSuccess()
                sendTerminal(control, text = controlReplyText.remove(control.requestId).orEmpty())
            }
        } catch (error: Exception) {
            if (error is Error) throw error
            if (control.cancelled.get() || error is CancellationException) sendTerminal(control, cancelled = true)
            else {
                policy.recordBackendFailure()
                sendTerminal(control, failed = true, error = error.message ?: error.javaClass.simpleName)
            }
        }
    }

    private val controlReplyText = ConcurrentHashMap<String, StringBuilder>()

    private fun sendToken(control: GenerationControl, token: String) {
        if (control.cancelled.get()) return
        controlReplyText.getOrPut(control.requestId) { StringBuilder() }.append(token)
        sendReply(control.reply, REPLY_TOKEN, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_TOKEN, token)
        })
    }

    private fun sendTerminal(
        control: GenerationControl,
        text: String? = null,
        failed: Boolean = false,
        cancelled: Boolean = false,
        error: String? = null,
    ) {
        if (!control.terminalSent.compareAndSet(false, true)) return
        val finalText = text ?: controlReplyText.remove(control.requestId)?.toString().orEmpty()
        sendReply(control.reply, REPLY_GENERATE, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_TEXT, finalText)
            putBoolean(KEY_FAILED, failed)
            putBoolean(KEY_CANCELLED, cancelled)
            if (error != null) putString(KEY_ERROR, error)
        })
    }

    private fun cancelGeneration(requestId: String) {
        if (requestId.isBlank()) return
        val control = requests[requestId] ?: return
        control.cancel()
        // LiteRT-LM documents that CancelProcess() can leave a native session unusable, and
        // current upstream reports show that a pathological cancellation can delay session
        // release. Never let that wedge the single-flight barrier indefinitely: the isolated
        // process is disposable, so kill it after a short cancellation grace period.
        scope.launch {
            delay(CANCEL_GRACE_MS)
            if (!control.nativeReleased.get() && requests[requestId] === control) {
                BenNeuralTelemetry.error("Cancellation release grace exceeded; terminating isolated inference process")
                Process.killProcess(Process.myPid())
            }
        }
    }

    private suspend fun handleOneShot(message: Message) {
        val reply = message.replyTo
        val result = when (message.what) {
            CMD_RERANK -> runCatching {
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                val query = message.data.getString(KEY_QUERY).orEmpty()
                val candidates = message.data.getStringArrayList(KEY_CANDIDATES) ?: arrayListOf()
                val limit = message.data.getInt(KEY_LIMIT, 8)
                embedding!!.rerank(query, candidates.mapIndexed { index, text -> Candidate(index, text) }, { it.text }, limit.coerceIn(1, 8))
            }.getOrNull()?.let { r -> Bundle().apply {
                putIntArray(KEY_INDICES, r.hits.map { it.item.index }.toIntArray())
                putDoubleArray(KEY_SCORES, r.hits.map { it.similarity }.toDoubleArray())
                putLong(KEY_ELAPSED, r.elapsedMs)
                putBoolean(KEY_USED_MODEL, r.usedModel)
                putBoolean(KEY_FAILED, false)
            }} ?: Bundle().apply { putBoolean(KEY_FAILED, true) }
            CMD_DIAGNOSTIC -> runCatching {
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                embedding!!.diagnostic()
            }.getOrNull()?.let { Bundle().apply { putString(KEY_REPORT, it); putBoolean(KEY_FAILED, false) } }
                ?: Bundle().apply { putBoolean(KEY_FAILED, true) }
            CMD_COMPARE -> runCatching {
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                embedding!!.compare(message.data.getString(KEY_FIRST).orEmpty(), message.data.getString(KEY_SECOND).orEmpty())
            }.getOrNull()?.let { Bundle().apply { putDouble(KEY_SCORE, it); putBoolean(KEY_FAILED, false) } }
                ?: Bundle().apply { putBoolean(KEY_SCORE, Double.NaN); putBoolean(KEY_FAILED, true) }
            else -> Bundle().apply { putBoolean(KEY_FAILED, true) }
        }
        result.putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
        result.putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
        sendReply(reply, when (message.what) {
            CMD_RERANK -> REPLY_RERANK
            CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
            else -> REPLY_COMPARE
        }, result)
    }

    private data class Candidate(val index: Int, val text: String)

    private fun sendReply(target: Messenger?, what: Int, data: Bundle) {
        if (target == null) return
        runCatching { target.send(Message.obtain(null, what).apply { this.data = data }) }
    }

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    override fun onUnbind(intent: Intent?): Boolean {
        requests.values.forEach { it.cancel() }
        scope.launch { singleFlight.withLock { closeRuntimes() } }
        return false
    }

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 29) runCatching { thermalListener?.let { powerManager?.removeThermalStatusListener(it) } }
        requests.values.forEach { it.cancel() }
        // Do not close native runtimes concurrently with an in-flight generation. The process is
        // disposable and will be destroyed immediately after cancellation; avoiding an unsynchronised
        // close here prevents a second thread from racing the native session teardown.
        scope.launch {
            runCatching { singleFlight.withLock { closeRuntimes() } }
        }
        handlerThread.quitSafely()
        super.onDestroy()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) {
            // Runtime closure participates in the same barrier as generation/reranking. Never
            // close a native runtime concurrently with an active inference operation.
            scope.launch { runCatching { singleFlight.withLock { closeRuntimes() } } }
        }
    }

    private fun closeGeneratorForRelease() {
        // Called only after the LiteRT-LM streaming Flow has returned. Keep this separate from
        // closeRuntimes() because EmbeddingGemma may be independently warm for reranking.
        runCatching { generator?.close() }
        generator = null
        generatorWarm = false
    }

    private fun closeRuntimes() {
        closeGeneratorForRelease()
        runCatching { embedding?.close() }
        embedding = null
        embeddingWarm = false
    }

    companion object {
        const val CMD_GENERATE = 1
        const val CMD_RERANK = 2
        const val CMD_PING = 3
        const val CMD_DIAGNOSTIC = 4
        const val CMD_COMPARE = 5
        const val CMD_CANCEL = 6
        const val REPLY_GENERATE = 101
        const val REPLY_RERANK = 102
        const val REPLY_DIAGNOSTIC = 104
        const val REPLY_COMPARE = 105
        const val REPLY_PING = 103
        const val REPLY_TOKEN = 106
        const val KEY_REQUEST_ID = "requestId"
        const val KEY_CLIENT_GENERATION = "clientGeneration"
        const val KEY_PROMPT = "prompt"
        const val KEY_MAX_TOKENS = "maxTokens"
        const val KEY_QUERY = "query"
        const val KEY_CANDIDATES = "candidates"
        const val KEY_LIMIT = "limit"
        const val KEY_TEXT = "text"
        const val KEY_TOKEN = "token"
        const val KEY_INDICES = "indices"
        const val KEY_SCORES = "scores"
        const val KEY_ELAPSED = "elapsedMs"
        const val KEY_USED_MODEL = "usedModel"
        const val KEY_FAILED = "failed"
        const val KEY_CANCELLED = "cancelled"
        const val KEY_ERROR = "error"
        const val KEY_OK = "ok"
        const val KEY_REPORT = "report"
        const val KEY_FIRST = "first"
        const val KEY_SECOND = "second"
        const val KEY_SCORE = "score"
        private const val CANCEL_GRACE_MS = 2_500L
    }
}
