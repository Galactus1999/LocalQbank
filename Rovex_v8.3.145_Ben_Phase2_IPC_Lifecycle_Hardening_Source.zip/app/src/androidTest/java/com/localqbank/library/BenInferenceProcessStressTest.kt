package com.localqbank.library

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import android.app.ActivityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Device-only Phase 2 lifecycle stress suite. These tests intentionally exercise the real Binder
 * service and should be run on the target Qualcomm SM8650 device with the Gemma model installed.
 * They do not claim an Android build/device pass until executed by instrumentation.
 */
@RunWith(AndroidJUnit4::class)
class BenInferenceProcessStressTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun rapidLatestRequestWinsDoesNotCreateConcurrentClientGenerations() = runBlocking(Dispatchers.Default) {
        val client = BenInferenceProcessClient(context)
        try {
            val flows = (0 until 4).map { index ->
                async {
                    val events = mutableListOf<BenInferenceProcessClient.GenerationEvent>()
                    client.generateStream("Phase2 card $index: explain the supplied study context", 64).collect { events += it }
                    events
                }
            }
            val results = flows.awaitAll()
            assertTrue("At least one request must terminate", results.any { events ->
                events.any { it is BenInferenceProcessClient.GenerationEvent.Complete ||
                    it is BenInferenceProcessClient.GenerationEvent.Cancelled ||
                    it is BenInferenceProcessClient.GenerationEvent.ProcessDied ||
                    it is BenInferenceProcessClient.GenerationEvent.Failed }
            })
        } finally {
            client.close()
        }
    }

    @Test
    fun cancellationDuringGenerationTerminatesWithoutHangingCaller() = runBlocking {
        val client = BenInferenceProcessClient(context)
        try {
            val job = launch {
                client.generateStream("Generate a deliberately long bounded response for cancellation testing", 192).collect { }
            }
            delay(150)
            job.cancelAndJoin()
            assertTrue("Cancellation must return control to the caller", !job.isActive)
        } finally {
            client.close()
        }
    }

    @Test
    fun binderDeathDuringGenerationRecoversThroughDeterministicClientFailure() = runBlocking {
        val client = BenInferenceProcessClient(context)
        try {
            val job = launch {
                client.generateStream("Binder death stress: generate a bounded explanation", 192).collect { }
            }
            waitForInferenceProcess()
            killInferenceProcess()
            job.join()
            assertTrue("Generation must terminate after isolated-process death", !job.isActive)
        } finally {
            client.close()
        }
    }

    @Test
    fun binderDeathDuringEmbeddingRerankDoesNotHangCaller() = runBlocking {
        val client = BenInferenceProcessClient(context)
        try {
            val job = launch {
                client.rerankSuspend(
                    "nephrotic syndrome edema",
                    List(8) { "candidate $it with bounded medical evidence" },
                    8,
                )
            }
            waitForInferenceProcess()
            killInferenceProcess()
            job.join()
            assertTrue("Rerank caller must return after isolated-process death", !job.isActive)
        } finally {
            client.close()
        }
    }

    @Test
    fun rerankAndGenerationCanRecoverAfterLifecycleChurn() = runBlocking {
        repeat(3) {
            val client = BenInferenceProcessClient(context)
            try {
                client.rerankSuspend("nephrotic syndrome edema", listOf("hypoalbuminemia", "hypernatremia"), 2)
                client.generateSuspend("Give one concise exam-oriented explanation.", 48)
            } finally {
                client.close()
            }
            delay(100)
        }
        assertTrue(true)
    }

    private suspend fun waitForInferenceProcess() {
        repeat(40) {
            if (findInferencePid() != null) return
            delay(50)
        }
        assertTrue("Isolated inference process did not start", findInferencePid() != null)
    }

    private fun killInferenceProcess() {
        val pid = findInferencePid() ?: return
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val pfd = instrumentation.uiAutomation.executeShellCommand("kill -9 $pid")
        pfd.close()
    }

    private fun findInferencePid(): Int? {
        val am = context.getSystemService(ActivityManager::class.java) ?: return null
        return am.runningAppProcesses?.firstOrNull {
            it.processName == "${context.packageName}:inference_process"
        }?.pid
    }
}
