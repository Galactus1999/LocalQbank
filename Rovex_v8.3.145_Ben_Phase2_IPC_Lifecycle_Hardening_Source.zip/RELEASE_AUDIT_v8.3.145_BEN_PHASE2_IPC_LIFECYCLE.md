# Rovex v8.3.145 — Phase 2 IPC Lifecycle Hardening Audit

## Baseline
- v8.3.144 / versionCode 242
- v8.3.144 source SHA-256: `032c864b93d2038614b25055dc6541fd69281c2ef4a259a2054020514cde6b28`
- v8.3.145 / versionCode 243
- applicationId: `com.localqbank.library`

## Code corrections
1. **Native release barrier fixed.** `GenerationControl.nativeReleased` is now separate from `terminalSent`. A terminal Binder reply can occur before native teardown, but replacement heavy work cannot acquire the single-flight lock until release is complete.
2. **Cancellation watchdog fixed.** The watchdog now checks `nativeReleased`, not `terminalSent`. A pathological native cancellation can therefore actually trigger isolated-process termination after the grace period.
3. **Cancellation teardown hardened.** After the LiteRT-LM streaming Flow returns, cancelled/thermally-aborted generation explicitly closes the Gemma generator before releasing the single-flight barrier.
4. **All heavy native operations serialized.** Generation, EmbeddingGemma rerank/diagnostic/compare, memory-trim closure, unbind closure and shutdown now use the same barrier, preventing close-vs-inference races.
5. **Pending bind race fixed.** `onBindingDied`/`onServiceDisconnected` occurring before `onServiceConnected` now completes the pending suspend operation instead of leaving it hanging.
6. **Death-recipient cleanup added.** Old Binder death recipients are unlinked during connection teardown.
7. **Device stress suite added.** Instrumentation covers rapid latest-request-wins, cancellation, generation Binder death, EmbeddingGemma Binder death, and lifecycle churn.

## Static validation
- XML files inspected: 27
- XML parse errors: 0
- Duplicate IDs within individual XML files: 0
- `Thread.sleep` in Kotlin/Java source: 0
- `GlobalScope` in Kotlin/Java source: 0
- broad `catch(Throwable)` patterns: 0
- source ZIP integrity: PASS
- architecture audit: PASS for single intent-routing owner, orchestration/control contracts, and no undocumented orchestrator/coordinator classes.
- architecture regression script reports an existing singleton/object baseline delta (`46 > 44`); no new singleton/object was introduced by the Phase 2 changes, so this is retained as a pre-existing baseline issue rather than masking it.
- one historical `v8.3.143` release-notes filename remains; no stale executable `versionCode 241` assertion was found.

## Android build status
**NOT VERIFIED.** `./gradlew :app:compileDebugKotlin --offline --no-daemon` could not proceed because Gradle 9.3.1 is not locally available and `downloads.gradle.org` DNS resolution is blocked in this environment. No claim of Android compilation/CI success is made.

## Device validation status
**NOT VERIFIED HERE.** No ADB/device endpoint is available in this environment. The target SM8650 instrumentation suite is included in the source and is designed to run against the real device/model installation. Therefore Binder-death, NPU lock-release latency, warm/cold latency, thermal escalation/de-escalation, ANR absence and physical zombie-process checks remain pending actual device execution.

## Important invariant after v8.3.145
`terminalSent == true` means only that the client-visible terminal state was sent once. `nativeReleased == true` means the native generation/session release barrier has completed. These are intentionally separate states.
