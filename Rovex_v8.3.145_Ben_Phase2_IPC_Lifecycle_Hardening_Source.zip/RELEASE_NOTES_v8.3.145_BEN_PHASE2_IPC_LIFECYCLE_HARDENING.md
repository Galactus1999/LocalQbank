# Rovex v8.3.145 — Ben Phase 2 IPC Lifecycle Hardening

VersionCode: 243
Application ID: com.localqbank.library
Baseline: v8.3.144 / versionCode 242

## Implemented
- Added a real native-release barrier to isolated generation controls. Client terminal completion is no longer treated as native resource release.
- On cancellation or severe thermal abort, the generation Flow must return and the Gemma generator is explicitly closed before the single-flight lock is released.
- Cancellation watchdog now keys off `nativeReleased`, so a hung native cancellation can actually trigger isolated-process termination after the grace period.
- Serialized generation, EmbeddingGemma reranking, diagnostics, comparisons, memory-trim closure, and runtime shutdown through the same native single-flight barrier to prevent close-vs-inference races.
- Hardened pending Binder-bind lifecycle: binding death before `onServiceConnected()` now terminates the pending suspend operation instead of leaving it hanging.
- Unlink Binder death recipients during connection teardown.
- Added device instrumentation stress coverage for latest-request-wins, cancellation, generation Binder death, EmbeddingGemma Binder death, and lifecycle churn.

## Validation status
- Source ZIP baseline SHA-256 verified: `032c864b93d2038614b25055dc6541fd69281c2ef4a259a2054020514cde6b28`.
- XML parse: PASS; duplicate IDs within individual layouts: PASS.
- `Thread.sleep`: 0 in Kotlin/Java source. `GlobalScope`: 0. Broad `catch(Throwable)`: 0.
- Android Gradle compilation: NOT VERIFIED. Gradle 9.3.1 distribution download is currently blocked by DNS (`downloads.gradle.org`).
- Physical SM8650 device execution: NOT VERIFIED in this environment; the new instrumentation suite is prepared for execution on the target device.

## Safety invariant
A Binder terminal reply means only **client-visible terminal state**. `nativeReleased` is the separate **native lifecycle terminal state**. A replacement heavy neural operation may not acquire the service's single-flight barrier until native release is complete.
