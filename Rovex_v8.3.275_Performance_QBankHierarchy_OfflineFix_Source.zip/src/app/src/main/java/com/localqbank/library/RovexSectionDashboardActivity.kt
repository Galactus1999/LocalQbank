package com.localqbank.library
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
class RovexSectionDashboardActivity:Activity(){
private lateinit var content:LinearLayout
private var active="home"
private var sectionGeneration=0L
private lateinit var navBar:LinearLayout
private data class Row(val name:String,val total:Int,val solved:Int,val correct:Int,val testId:String="",val position:Int=0,val path:String="",val source:String=""){
    val accuracy:Int get()=if(solved==0)0 else correct*100/solved
    val mastery:Int get()=if(total==0)0 else solved*100/total
}
override fun onCreate(b:Bundle?){super.onCreate(b);active=intent.getStringExtra("section")?:"home";buildShell();repaintNav();loadLiveData(sectionGeneration,active)}
private fun buildShell(){
    val root=FrameLayout(this).apply{
        setBackgroundColor(ThemeManager.bg(this@RovexSectionDashboardActivity))
    }
    val scroll=ScrollView(this).apply{
        isFillViewport=true
        clipToPadding=false
        setPadding(0,0,0,d(82))
    }
    content=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL
        setPadding(d(16),d(14),d(16),d(18))
    }
    scroll.addView(content)
    root.addView(scroll,FrameLayout.LayoutParams(-1,-1))
    root.addView(nav(),FrameLayout.LayoutParams(-1,d(58),Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply{
        leftMargin=d(12);rightMargin=d(12);bottomMargin=d(12)
    })
    setContentView(root)
}

private data class DashboardSnapshot(
    val rows: List<Row>,
    val overall: Row,
    var cards: Triple<Int,Int,Int>? = null,
    val createdAt: Long = android.os.SystemClock.elapsedRealtime()
)

private var snapshot: DashboardSnapshot? = null
private var loadingData = false
private var loadingCards = false

private val canonicalSubjects = listOf(
    "Anatomy", "Physiology", "Biochemistry", "Pharmacology", "Pathology", "Microbiology",
    "Forensic Medicine", "Community Medicine / PSM", "General Medicine", "Dermatology",
    "Psychiatry", "Pediatrics", "Radiology", "Anesthesiology", "General Surgery",
    "Orthopedics", "ENT", "Ophthalmology", "Obstetrics & Gynecology"
)

private fun normalized(v: String): String = v.lowercase().replace("&", "and").replace(Regex("[^a-z0-9]+"), " ").trim()

private fun kindFor(r:Row): String {
    val hay = normalized(listOf(r.name, r.path, r.source).joinToString(" "))
    return when {
        Regex("\\bpyq\\b|previous year|previous-year").containsMatchIn(hay) -> "PYQ"
        Regex("\\bcustom\\b|customized|custom qbank").containsMatchIn(hay) -> "Custom"
        Regex("image test|image based test|image-based test").containsMatchIn(hay) -> "Image Test"
        Regex("subject test|subject-wise test|subject wise test").containsMatchIn(hay) -> "Subject Test"
        Regex("other test|grand test|mock test|test series|mixed test|full test").containsMatchIn(hay) -> "Other Test"
        else -> "QBank"
    }
}

private fun subjectFor(r:Row): String? {
    val hay = normalized(listOf(r.path, r.name, r.source).joinToString(" "))
    return when {
        Regex("\\banatomy\\b|gross anatomy|embryology|histology|neuroanatomy").containsMatchIn(hay) -> "Anatomy"
        Regex("\\bphysiology\\b").containsMatchIn(hay) -> "Physiology"
        Regex("biochem|biochemistry").containsMatchIn(hay) -> "Biochemistry"
        Regex("pharmacology|pharmaco").containsMatchIn(hay) -> "Pharmacology"
        Regex("pathology|histopathology").containsMatchIn(hay) -> "Pathology"
        Regex("microbiology").containsMatchIn(hay) -> "Microbiology"
        Regex("forensic|toxicology|\\bfmt\\b").containsMatchIn(hay) -> "Forensic Medicine"
        Regex("community medicine|communitymedicine|\\bpsm\\b|preventive and social medicine|preventive social medicine").containsMatchIn(hay) -> "Community Medicine / PSM"
        Regex("general medicine|internal medicine|medicine and allied|medicine allied|respiratory medicine|pulmonology|tb and chest").containsMatchIn(hay) -> "General Medicine"
        Regex("dermatology|dvl|venereology").containsMatchIn(hay) -> "Dermatology"
        Regex("psychiatry|psychiatric").containsMatchIn(hay) -> "Psychiatry"
        Regex("pediatrics|paediatrics|paediatric|pediatric").containsMatchIn(hay) -> "Pediatrics"
        Regex("radiology|radiodiagnosis|radio diagnosis|radiodiagnostic").containsMatchIn(hay) -> "Radiology"
        Regex("anesthesiology|anaesthesiology|anesthesia|anaesthesia").containsMatchIn(hay) -> "Anesthesiology"
        Regex("general surgery|surgery and allied|surgery allied|surgical").containsMatchIn(hay) -> "General Surgery"
        Regex("orthopedic|orthopaedic|orthopedics|orthopaedics").containsMatchIn(hay) -> "Orthopedics"
        Regex("\\bent\\b|otorhinolaryngology|otolaryngology|ear nose throat").containsMatchIn(hay) -> "ENT"
        Regex("ophthalmology|ophthal|\\beye\\b").containsMatchIn(hay) -> "Ophthalmology"
        Regex("obstetrics|gynaecology|gynecology|obgyn|\\bobg\\b").containsMatchIn(hay) -> "Obstetrics & Gynecology"
        else -> null
    }
}

private fun rowsForSubject(rows: List<Row>, subject: String): List<Row> = rows.filter { subjectFor(it) == subject }
private fun rowsForKind(rows: List<Row>, kind: String): List<Row> = rows.filter { kindFor(it) == kind }

private fun switchSection(id:String){
    if(active==id) return
    active=id
    sectionGeneration++
    repaintNav()
    val cached=snapshot
    if(cached!=null){
        render(cached)
        if(id=="flashcards" && cached.cards==null) loadFlashcards(sectionGeneration)
    }else{
        loadLiveData(sectionGeneration,id)
    }
}
private fun repaintNav(){if(!::navBar.isInitialized)return;for(i in 0 until navBar.childCount){(navBar.getChildAt(i) as? TextView)?.let{v->val id=v.tag?.toString().orEmpty();v.setTextColor(if(active==id)ThemeManager.accent(this) else ThemeManager.muted(this));v.background=if(active==id)android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.bg(this@RovexSectionDashboardActivity));cornerRadius=d(20).toFloat()} else null}}}

private fun loadLiveData(token:Long=sectionGeneration,requestedSection:String=active){
    if(loadingData) return
    loadingData=true
    PerformanceManager.submit{
        val rows=runCatching{
            val db = QBankDb(applicationContext)
            try {
                db.dashboardTestRows().map { r -> Row(r.name, r.total, r.solved, r.correct, r.testId, r.position, r.path, r.source) }
            } finally {
                db.close()
            }
        }.getOrDefault(emptyList())
        val overall=Row("Main QBank",rows.sumOf{it.total},rows.sumOf{it.solved},rows.sumOf{it.correct})
        val next=DashboardSnapshot(rows,overall)
        runOnUiThread{
            loadingData=false
            if(!isFinishing&&!isDestroyed&&token==sectionGeneration&&requestedSection==active){
                snapshot=next
                render(next)
                if(active=="flashcards") loadFlashcards(token)
            }
        }
    }
}

private fun loadFlashcards(token:Long=sectionGeneration){
    val s=snapshot ?: return
    if(s.cards!=null || loadingCards) return
    loadingCards=true
    PerformanceManager.submit{
        val cards=runCatching{SqliteFlashcardReviewRepository(applicationContext).use{Triple(it.modeCount("all"),it.reviewCount(),it.dueStatsAll().due)}}.getOrDefault(Triple(0,0,0))
        runOnUiThread{
            loadingCards=false
            if(!isFinishing&&!isDestroyed&&token==sectionGeneration&&snapshot===s){
                s.cards=cards
                render(s)
            }
        }
    }
}

private fun render(data:DashboardSnapshot){
    content.removeAllViews()
    val cardData=data.cards ?: Triple(0,0,0)
    when(active){"qbank"->qbank(data.rows);"flashcards"->cards(if(data.cards!=null) cardData else Triple(-1,-1,-1));"analytics"->stats(data.rows,data.overall);"mastery"->mastery(data.rows,data.overall);else->home(data.overall,cardData)}
}

private fun title(a:String,b:String){
    content.addView(TextView(this).apply{text=a;textSize=25f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    content.addView(TextView(this).apply{text=b;textSize=12f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,0,0,d(14))})
}
private fun section(x:String){content.addView(TextView(this).apply{text=x.uppercase();textSize=10f;letterSpacing=.12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(2,d(12),0,d(7))})}
private fun panel():android.graphics.drawable.Drawable=android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.panel(this@RovexSectionDashboardActivity));cornerRadius=d(22).toFloat()}
private fun card(t:String,s:String,a:Int,act:String,go:()->Unit){
    val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(15),d(16),d(13));background=panel()}
    b.addView(TextView(this).apply{text=t;textSize=16f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    b.addView(TextView(this).apply{text=s;textSize=11.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,d(5))})
    b.addView(TextView(this).apply{text=act.uppercase();textSize=10f;setTypeface(null,Typeface.BOLD);setTextColor(a);gravity=Gravity.CENTER_VERTICAL;setPadding(0,d(4),0,0);setOnClickListener{go()}})
    content.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(8)})
}
private fun progress(r:Row,index:Int){
    val fill=ThemeManager.pastelAccentFill(this,index);val fg=ThemeManager.pastelAccentText(this,index)
    val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(14),d(12),d(14),d(11));background=android.graphics.drawable.GradientDrawable().apply{setColor(fill);cornerRadius=d(17).toFloat()};isClickable=true;isFocusable=true;setOnClickListener{if(r.testId.isNotBlank())startActivity(Intent(this@RovexSectionDashboardActivity,QuizActivity::class.java).apply{putExtra("testId",r.testId);putExtra("title",r.name);putExtra("position",r.position);putExtra("sectionLabel",r.path);putExtra("practiceMode",true)})}}
    val line=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
    line.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.name;textSize=14f;setTypeface(null,Typeface.BOLD);setTextColor(fg)},LinearLayout.LayoutParams(0,-2,1f))
    line.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.mastery.toString()+"%";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(fg)})
    b.addView(line)
    b.addView(TextView(this).apply{text=r.path+"  •  "+r.solved.toString()+"/"+r.total+" solved  •  "+r.accuracy+"% accuracy";textSize=10.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(3),0,d(5))})
    b.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{progress=r.mastery;progressTintList=android.content.res.ColorStateList.valueOf(fg)})
    content.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(6)})
}
private fun home(o:Row,c:Triple<Int,Int,Int>){
    title("Rovex","Study cockpit")
    card("Continue studying","Resume the active QBank session from the existing Rovex workflow.",ThemeManager.accent(this),"CONTINUE"){finish()}
    section("LIVE DATA")
    card("QBank performance",o.solved.toString()+" solved  •  "+o.accuracy+"% accuracy  •  "+o.total+" questions available.",ThemeManager.accent(this),"VIEW STATS"){switchSection("analytics")}
    card("Flashcards",c.first.toString()+" cards  •  "+c.third+" due now  •  "+c.second+" reviews.",ThemeManager.pastelAccentText(this,1),"OPEN CARDS"){switchSection("flashcards")}
    section("FOCUS")
    card("All QBank subjects","Browse the complete imported subject/section hierarchy. Nothing is hard-coded.",ThemeManager.accent(this),"OPEN QBANK"){switchSection("qbank")}
}
private fun subjectKey(r:Row):String{
    val raw=r.path.trim()
    return raw.split(">", "/", "::").firstOrNull()?.trim().orEmpty().ifBlank{"General"}
}
private fun subjectRows(rows:List<Row>):List<Row> = rows.sortedBy{it.name.lowercase()}
private fun subjectGroups(rows:List<Row>):List<Pair<String,List<Row>>>{
    return rows.groupBy{subjectKey(it)}.toList().sortedBy{it.first.lowercase()}
}
private fun subjectCategoryBox(label:String,allItems:List<Row>,index:Int){
    val total=allItems.sumOf{it.total}; val solved=allItems.sumOf{it.solved}; val correct=allItems.sumOf{it.correct}
    val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(d(8),d(7),d(8),d(2))}
    val shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(14),d(13),d(14),d(12));background=panel()}
    val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
    val arrow=TextView(this).apply{text="›";textSize=23f;gravity=Gravity.CENTER;setTextColor(ThemeManager.pastelAccentText(this@RovexSectionDashboardActivity,index))}
    head.addView(TextView(this).apply{text=label;textSize=16f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))},LinearLayout.LayoutParams(0,-2,1f))
    head.addView(TextView(this).apply{text=allItems.size.toString()+" QBanks";textSize=10f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,0,d(8),0)})
    head.addView(TextView(this).apply{text=total.toString()+" Q";textSize=11f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.pastelAccentText(this@RovexSectionDashboardActivity,index))})
    head.addView(arrow,LinearLayout.LayoutParams(d(28),d(28)))
    shell.addView(head)
    shell.addView(TextView(this).apply{text=solved.toString()+" solved • "+(if(solved==0)0 else correct*100/solved)+"% accuracy";textSize=10.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,0)})
    shell.addView(wrap)
    var populated=false
    head.setOnClickListener{
        val open=wrap.visibility!=View.VISIBLE
        if(open && !populated){
            listOf("QBank","PYQ","Custom","Subject Test","Image Test","Other Test").forEachIndexed { kindIndex, kind ->
                val items=allItems.filter { kindFor(it)==kind }
                if(items.isNotEmpty()){
                    wrap.addView(TextView(this).apply{
                        text=kind.uppercase()+"  •  "+items.size+" QBANKS"
                        textSize=9.5f;letterSpacing=.08f;setTypeface(null,Typeface.BOLD)
                        setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(d(4),d(10),0,d(5))
                    })
                    items.sortedWith(compareBy<Row>{it.position}.thenBy{it.name.lowercase()}).forEachIndexed{ci,r->progressInto(wrap,r,ci+kindIndex)}
                }
            }
            populated=true
        }
        wrap.visibility=if(open)View.VISIBLE else View.GONE
        arrow.text=if(open)"⌄" else "›"
    }
    content.addView(shell,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(8)})
}

private fun unassignedCollectionBox(label:String,items:List<Row>,index:Int){
    if(items.isEmpty()) return
    subjectCategoryBox(label,items,index)
}

private fun progressInto(parent:ViewGroup,r:Row,index:Int){
    val fg=ThemeManager.pastelAccentText(this,index);val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(13),d(10),d(13),d(9));background=panel();isClickable=r.testId.isNotBlank();setOnClickListener{if(r.testId.isNotBlank())startActivity(Intent(this@RovexSectionDashboardActivity,QuizActivity::class.java).apply{putExtra("testId",r.testId);putExtra("title",r.name);putExtra("position",r.position);putExtra("sectionLabel",r.path);putExtra("practiceMode",true)})}}
    b.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.name;textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    b.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.solved.toString()+" / "+r.total+" solved • "+r.accuracy+"% accuracy";textSize=10f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(3),0,d(5))})
    b.addView(ProgressBar(this@RovexSectionDashboardActivity,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=r.mastery;progressTintList=android.content.res.ColorStateList.valueOf(fg)})
    parent.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(5)})
}

private fun qbank(rows:List<Row>){
    title("QBank","19 subjects with QBank / PYQ / Custom / test categories")
    analyticsHero(rows)
    section("19 SUBJECTS")
    canonicalSubjects.forEachIndexed{i,subject->subjectCategoryBox(subject,rowsForSubject(rows,subject),i)}
    section("CROSS-SUBJECT / UNASSIGNED COLLECTIONS")
    listOf("PYQ","Custom","Subject Test","Image Test","Other Test").forEachIndexed{i,label->
        val items=rows.filter { subjectFor(it)==null && kindFor(it)==label }
        unassignedCollectionBox(label,items,canonicalSubjects.size+i)
    }
}

private fun analyticsHero(rows:List<Row>){
    val total=rows.sumOf{it.total};val solved=rows.sumOf{it.solved};val correct=rows.sumOf{it.correct};val mastery=if(total==0)0 else solved*100/total;val accuracy=if(solved==0)0 else correct*100/solved
    val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(16),d(16),d(14));background=panel()}
    box.addView(TextView(this).apply{text="Main QBank";textSize=22f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    box.addView(TextView(this).apply{text=rows.size.toString()+" imported sub-QBanks • "+canonicalSubjects.size+" fixed subject groups";textSize=11.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,d(8))})
    val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
    fun stat(label:String,value:String){stats.addView(LinearLayout(this@RovexSectionDashboardActivity).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(d(5),d(7),d(5),d(7));background=ThemeManager.transparentSectionDrawable(this@RovexSectionDashboardActivity);addView(TextView(this@RovexSectionDashboardActivity).apply{text=label;textSize=8.5f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity))});addView(TextView(this@RovexSectionDashboardActivity).apply{text=value;textSize=14f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})},LinearLayout.LayoutParams(0,d(60),1f).apply{setMargins(d(3),0,d(3),0)})}
    stat("SOLVED",solved.toString());stat("ACCURACY",accuracy.toString()+"%");stat("MASTERY",mastery.toString()+"%");box.addView(stats);content.addView(box,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(10)})
}

private fun cards(c:Triple<Int,Int,Int>){
    title("Cards","Flashcards • retention • review")
    val due=c.third
    val total=c.first
    val reviews=c.second
    val retention=if(reviews==0)0 else ((reviews-due).coerceAtLeast(0)*100/reviews)
    val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(16),d(16),d(14));background=panel()}
    hero.addView(TextView(this).apply{text="Flashcard Overview";textSize=12f;letterSpacing=.12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity))})
    hero.addView(TextView(this).apply{text="$total cards • $retention% retention";textSize=20f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,d(2))})
    hero.addView(TextView(this).apply{text="$due due today • $reviews reviews recorded";textSize=11f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity))})
    val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=if(total==0)0 else ((total-due).coerceAtLeast(0)*100/total);progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(this@RovexSectionDashboardActivity))}
    hero.addView(bar,LinearLayout.LayoutParams(-1,d(6)).apply{topMargin=d(12)})
    val open=TextView(this).apply{text="▶  Review Flashcards";gravity=Gravity.CENTER;textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.bg(this@RovexSectionDashboardActivity));background=android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.accent(this@RovexSectionDashboardActivity));cornerRadius=d(22).toFloat()};setPadding(0,d(11),0,d(11));setOnClickListener{startActivity(Intent(this@RovexSectionDashboardActivity,FlashcardActivity::class.java))}}
    hero.addView(open,LinearLayout.LayoutParams(-1,d(46)).apply{topMargin=d(12)});content.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(10)})
    section("REVIEW")
    card("Due today","$due cards are currently due according to the flashcard scheduler.",ThemeManager.pastelAccentText(this,1),"REVIEW"){startActivity(Intent(this,FlashcardActivity::class.java))}
    card("Study tools","Create, import and review cards using the existing flashcard workflow.",ThemeManager.accent(this),"OPEN TOOLS"){startActivity(Intent(this,FlashcardActivity::class.java))}
}

private fun stats(rows:List<Row>,o:Row){
    title("Stats","Performance • accuracy • subject analysis")
    analyticsHero(rows)
    section("PERFORMANCE")
    card("Solved",o.solved.toString()+" questions have recorded progress.",ThemeManager.pastelAccentText(this,0),"OPEN QBANK"){switchSection("qbank")}
    card("Correct",o.correct.toString()+" correct answers • "+o.accuracy+"% accuracy.",ThemeManager.pastelAccentText(this,1),"REVIEW"){switchSection("qbank")}
    card("Wrong",(o.solved-o.correct).coerceAtLeast(0).toString()+" recorded wrong answers.",ThemeManager.pastelAccentText(this,2),"REVIEW"){switchSection("qbank")}
    section("SUBJECT PERFORMANCE")
    subjectRows(rows).forEachIndexed{index,r->progress(r,index)}
}
private fun mastery(rows:List<Row>,o:Row){
    title("Mastery","Retention • coverage • 19-subject progress")
    card("Overall QBank Mastery",o.mastery.toString()+"% of imported questions have been attempted at least once.",ThemeManager.accent(this),"OPEN QBANK"){switchSection("qbank")}
    section("SUBJECT MASTERY")
    canonicalSubjects.forEachIndexed{i,subject->
        val items=rowsForBucket(rows,subject)
        val total=items.sumOf{it.total};val solved=items.sumOf{it.solved};val correct=items.sumOf{it.correct}
        val r=Row(subject,total,solved,correct)
        progress(r,i)
    }
}

private fun nav():View{
    val l=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL
        gravity=Gravity.CENTER
        setPadding(d(5),d(5),d(5),d(5))
        background=android.graphics.drawable.GradientDrawable().apply{
            setColor(ThemeManager.elevated(this@RovexSectionDashboardActivity))
            cornerRadius=d(30).toFloat()
        }
        elevation=d(12).toFloat()
    }
    listOf("home" to "Home","qbank" to "QBank","flashcards" to "Cards","analytics" to "Stats","mastery" to "Mastery").forEach{(id,label)->
        val activeNow=active==id
        val item=TextView(this).apply{
            tag=id
            text=if(activeNow) "●  $label" else label
            gravity=Gravity.CENTER
            textSize=10.5f
            setTypeface(null,Typeface.BOLD)
            setTextColor(if(activeNow) ThemeManager.bg(this@RovexSectionDashboardActivity) else ThemeManager.muted(this@RovexSectionDashboardActivity))
            setPadding(d(9),0,d(9),0)
            background=if(activeNow) android.graphics.drawable.GradientDrawable().apply{
                setColor(ThemeManager.text(this@RovexSectionDashboardActivity))
                cornerRadius=d(22).toFloat()
            } else null
            setOnClickListener{
                if(active!=id){
                    active=id
                    loadLiveData()
                }
            }
        }
        l.addView(item,LinearLayout.LayoutParams(0,-1,1f).apply{setMargins(d(2),0,d(2),0)})
    }
    return l
}

override fun onResume(){
    super.onResume()
    // Theme changes can happen while this Activity remains alive. Rebuild the
    // chrome from ThemeManager instead of retaining the previous theme's drawable.
    if(::content.isInitialized){
        window.decorView.post {
            if(!isFinishing && !isDestroyed){
                val parent=content.parent as? ScrollView
                parent?.setPadding(0,0,0,d(82))
                renderThemeChrome()
            }
        }
    }
}
private fun renderThemeChrome(){
    val root=(content.parent?.parent as? FrameLayout) ?: return
    val footer=root.getChildAt(root.childCount-1) as? LinearLayout ?: return
    footer.background=android.graphics.drawable.GradientDrawable().apply{
        setColor(ThemeManager.elevated(this@RovexSectionDashboardActivity))
        cornerRadius=d(30).toFloat()
    }
    for(i in 0 until footer.childCount){
        val v=footer.getChildAt(i) as? TextView ?: continue
        val id=v.tag as? String ?: continue
        val on=id==active
        v.text=if(on) "●  "+when(id){"home"->"Home";"qbank"->"QBank";"flashcards"->"Cards";"analytics"->"Stats";else->"Mastery"} else when(id){"home"->"Home";"qbank"->"QBank";"flashcards"->"Cards";"analytics"->"Stats";else->"Mastery"}
        v.setTextColor(if(on) ThemeManager.bg(this) else ThemeManager.muted(this))
        v.background=if(on) android.graphics.drawable.GradientDrawable().apply{
            setColor(ThemeManager.text(this@RovexSectionDashboardActivity))
            cornerRadius=d(22).toFloat()
        } else null
    }
}

private fun openSearch(){startActivity(Intent(this,SearchActivity::class.java).apply{putExtra("focusSearch",true)})}
private fun d(x:Int)=(x*resources.displayMetrics.density).toInt()
}