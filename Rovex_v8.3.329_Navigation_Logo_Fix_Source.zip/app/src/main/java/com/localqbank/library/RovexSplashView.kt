package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * "Pulse → Synapse" launcher splash.
 *
 * Concept: the app is where medicine (Rovex's exam content) and on-device neural AI (Ben) meet.
 * The splash literalizes that: a cardiac trace sweeps across the screen like a monitor coming
 * to life, its peak shatters into firing synapses, and the network resolves into the wordmark.
 * Single-hue amber-on-OLED-black palette, matching the app's AMOLED brand rather than a generic
 * multicolour intro.
 *
 * Drop-in replacement for the previous RovexSplashView: same public surface
 * (setOnFinished/start/skipToEnd + attach/detach lifecycle), so RovexSplashActivity needs no changes.
 */
class RovexSplashView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        const val DURATION_MS = 2900L
        private const val T_SWEEP_END = 0.32f
        private const val T_SHATTER_END = 0.40f
        private const val T_NETWORK_SETTLE = 0.70f
        private const val T_WORDMARK_START = 0.50f
        private const val T_WORDMARK_END = 0.80f
        private const val NODE_COUNT = 34
    }

    private val amber = intArrayOf(255, 178, 56)
    private val amberDim = intArrayOf(140, 92, 28)
    private val amberHot = intArrayOf(255, 214, 140)

    private val bgPaint = Paint().apply { color = Color.BLACK }
    private val ecgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 4.5f
    }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.3f
    }
    private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isSubpixelText = true
    }
    private val taglinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isSubpixelText = true
    }

    private val ecgPath = Path()
    private val ecgMeasure = PathMeasure()
    private var ecgLength = 0f
    private var ecgBuilt = false
    private var originX = 0f
    private var originY = 0f
    private var hapticFired = false

    private var startTime = 0L
    private var running = false
    private var completionSent = false
    private var onFinished: (() -> Unit)? = null

    private val cursive: Typeface by lazy {
        runCatching {
            Typeface.createFromAsset(context.assets, "rovex_lobster_two.otf")
        }.getOrElse {
            Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
    }

    private data class Node(
        val angle: Float,
        val dist: Float,
        val size: Float,
        val spawnDelay: Float,
        val linkTo: Int
    )

    private val nodes: List<Node> by lazy {
        val rnd = Random(1105)
        (0 until NODE_COUNT).map { i ->
            Node(
                angle = rnd.nextFloat() * (Math.PI.toFloat() * 2f),
                dist = 0.18f + rnd.nextFloat() * 0.82f,
                size = 1.3f + rnd.nextFloat() * 2.6f,
                spawnDelay = (i.toFloat() / NODE_COUNT) * 0.55f,
                linkTo = max(0, i - 1 - rnd.nextInt(3))
            )
        }
    }

    fun setOnFinished(listener: () -> Unit) {
        onFinished = listener
    }

    fun start() {
        if (running || completionSent) return
        startTime = SystemClock.uptimeMillis()
        running = true
        hapticFired = false
        invalidate()
    }

    fun skipToEnd() {
        if (completionSent) return
        running = false
        completionSent = true
        onFinished?.invoke()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        running = false
        onFinished = null
        super.onDetachedFromWindow()
    }

    private fun buildEcgPath(w: Float, h: Float) {
        val y = h * 0.34f
        val left = w * 0.12f
        val right = w * 0.88f
        val span = right - left
        ecgPath.reset()
        ecgPath.moveTo(left, y)
        ecgPath.lineTo(left + span * 0.34f, y)
        ecgPath.lineTo(left + span * 0.39f, y + h * 0.012f)
        ecgPath.lineTo(left + span * 0.44f, y - h * 0.02f)
        ecgPath.lineTo(left + span * 0.49f, y + h * 0.09f)
        ecgPath.lineTo(left + span * 0.53f, y - h * 0.16f)
        ecgPath.lineTo(left + span * 0.57f, y + h * 0.05f)
        ecgPath.lineTo(left + span * 0.63f, y)
        ecgPath.lineTo(right, y)
        originX = left + span * 0.53f
        originY = y - h * 0.16f
        ecgMeasure.setPath(ecgPath, false)
        ecgLength = ecgMeasure.length
        ecgBuilt = true
    }

    private fun rgba(c: IntArray, a: Int) = Color.argb(a, c[0], c[1], c[2])

    private fun fireHaptic() {
        if (hapticFired) return
        hapticFired = true
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(18, 60))
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (!ecgBuilt) buildEcgPath(w, h)
        val cx = w * 0.5f
        val elapsed = if (running) {
            (SystemClock.uptimeMillis() - startTime).coerceAtLeast(0L)
        } else {
            DURATION_MS
        }
        val t = (elapsed.toFloat() / DURATION_MS).coerceIn(0f, 1f)

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val sweepT = (t / T_SWEEP_END).coerceIn(0f, 1f)
        val sweepEase = 1f - (1f - sweepT) * (1f - sweepT)
        if (sweepT > 0f) {
            val tmp = Path()
            ecgMeasure.getSegment(0f, ecgLength * sweepEase, tmp, true)
            ecgPaint.color = rgba(amber, 235)
            ecgPaint.setShadowLayer(10f, 0f, 0f, rgba(amber, 140))
            canvas.drawPath(tmp, ecgPaint)
            ecgPaint.clearShadowLayer()
        }

        if (t in T_SWEEP_END - 0.05f..T_SHATTER_END) {
            if (sweepT >= 0.99f) fireHaptic()
            val flashT = (
                (t - (T_SWEEP_END - 0.05f)) /
                    (T_SHATTER_END - (T_SWEEP_END - 0.05f))
                ).coerceIn(0f, 1f)
            val flashAlpha = (255 * (1f - flashT) * (1f - flashT))
                .toInt().coerceIn(0, 255)
            if (flashAlpha > 4) {
                glowPaint.color = rgba(amberHot, flashAlpha)
                canvas.drawCircle(originX, originY, 10f + 46f * flashT, glowPaint)
                RovexPulseEffect.drawRadialFlash(
                    canvas, originX, originY, 10f + 46f * flashT, flashAlpha
                )
            }
        }

        val netT = (
            (t - T_SHATTER_END) /
                (T_NETWORK_SETTLE - T_SHATTER_END)
            ).coerceIn(0f, 1f)
        val netEase = 1f - (1f - netT) * (1f - netT)
        val networkAlpha = ((t - T_SHATTER_END) / 0.06f)
            .coerceIn(0f, 1f)

        if (t > T_SHATTER_END) {
            val maxR = min(w, h) * 0.46f
            val positions = FloatArray(nodes.size * 2)
            for ((i, n) in nodes.withIndex()) {
                val local = (
                    (netEase - n.spawnDelay) /
                        (1f - n.spawnDelay)
                    ).coerceIn(0f, 1f)
                val localEase = 1f - (1f - local) * (1f - local)
                val r = maxR * n.dist * localEase
                val x = originX + cos(n.angle) * r
                val y = originY + sin(n.angle) * r * 0.78f +
                    (1f - localEase) * -18f
                positions[i * 2] = x
                positions[i * 2 + 1] = y

                if (i > 0 && local > 0f) {
                    val target = nodes[n.linkTo]
                    val tLocal = (
                        (netEase - target.spawnDelay) /
                            (1f - target.spawnDelay)
                        ).coerceIn(0f, 1f)
                    val tEase = 1f - (1f - tLocal) * (1f - tLocal)
                    val tr = maxR * target.dist * tEase
                    val tx = originX + cos(target.angle) * tr
                    val ty = originY + sin(target.angle) * tr * 0.78f +
                        (1f - tEase) * -18f
                    val edgeAlpha = (46 * local * networkAlpha)
                        .toInt().coerceIn(0, 46)
                    edgePaint.color = rgba(amberDim, edgeAlpha)
                    canvas.drawLine(x, y, tx, ty, edgePaint)

                    val fire = ((t * 1.4f + i * 0.09f) % 1f)
                    val fx = x + (tx - x) * fire
                    val fy = y + (ty - y) * fire
                    pulsePaint.color = rgba(
                        amberHot,
                        (200 * local * networkAlpha).toInt().coerceIn(0, 200)
                    )
                    canvas.drawCircle(fx, fy, 1.6f, pulsePaint)
                }

                nodePaint.color = rgba(
                    amber,
                    (190 * local * networkAlpha).toInt().coerceIn(0, 190)
                )
                canvas.drawCircle(x, y, n.size * (0.4f + 0.6f * local), nodePaint)
            }
        }

        drawWordmark(canvas, cx, h, t)

        if (running) {
            if (elapsed >= DURATION_MS) {
                running = false
                if (!completionSent) {
                    completionSent = true
                    post { onFinished?.invoke() }
                }
            } else {
                postInvalidateOnAnimation()
            }
        }
    }

    private fun drawWordmark(canvas: Canvas, cx: Float, h: Float, t: Float) {
        val wt = (
            (t - T_WORDMARK_START) /
                (T_WORDMARK_END - T_WORDMARK_START)
            ).coerceIn(0f, 1f)
        if (wt <= 0f) return
        val ease = 1f - (1f - wt) * (1f - wt)
        val y = h * 0.58f
        val scale = 0.86f + 0.14f * ease

        val breathe = if (t > T_WORDMARK_END) {
            0.6f + 0.4f * sin((t - T_WORDMARK_END) * 9f)
        } else {
            1f
        }

        textPaint.typeface = cursive
        textPaint.textSize = h * 0.085f * scale
        textPaint.color = rgba(amber, (255 * ease).toInt().coerceIn(0, 255))
        textPaint.setShadowLayer(
            22f * breathe,
            0f,
            0f,
            rgba(amber, (150 * ease * breathe).toInt().coerceIn(0, 150))
        )
        canvas.drawText("Rovex", cx, y, textPaint)
        textPaint.clearShadowLayer()

        val tagT = (
            (t - (T_WORDMARK_START + 0.14f)) / 0.30f
        ).coerceIn(0f, 1f)
        if (tagT > 0f) {
            taglinePaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            taglinePaint.textSize = h * 0.019f
            taglinePaint.letterSpacing = 0.32f
            taglinePaint.color = rgba(
                amberDim,
                (170 * tagT).toInt().coerceIn(0, 170)
            )
            canvas.drawText(
                "PREPARE  ·  RECALL  ·  EXCEL",
                cx,
                y + h * 0.045f,
                taglinePaint
            )
        }
    }
}
