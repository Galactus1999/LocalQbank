package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import java.security.MessageDigest

/**
 * Streaming normalized-QBank writer used by HTML import. Owns only the long-lived
 * section transaction/session; source lifecycle and search-index policy stay outside.
 */
internal class QBankStreamingImportSession(
    private val db: android.database.sqlite.SQLiteDatabase,
    private val sourceId: Long,
    private val fileName: String,
    private val finalizeSearchIndex: () -> Unit
) {
    private val tests=LinkedHashMap<String,Pair<String,Int>>()
    private var total=0
    private var closed=false
    private var inTransaction=false
    private var writeCoordinatorHeld=false
    // Reuse compiled statements across the streaming session. This avoids reparsing SQL
    // for every question/option/image and materially reduces large-import CPU overhead.
    private val questionStatement = db.compileStatement("INSERT INTO question(test_id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio) VALUES(?,?,?,?,?,?,?,?,?,?)")
    private val optionStatement = db.compileStatement("INSERT INTO option_item(question_id,position,label,text,is_correct) VALUES(?,?,?,?,?)")
    private val imageStatement = db.compileStatement("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)")
    private val ftsStatement: android.database.sqlite.SQLiteStatement? = try {
        db.compileStatement("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)")
    } catch (_: Exception) { null }

    init { beginTransaction() }

    private fun beginTransaction() {
        if (!inTransaction && !closed) {
            QBankWriteCoordinator.lock.lock()
            writeCoordinatorHeld=true
            try {
                db.beginTransactionNonExclusive()
                inTransaction=true
            } catch (t: Exception) {
                writeCoordinatorHeld=false
                QBankWriteCoordinator.lock.unlock()
                throw t
            }
        }
    }

    /** Commit the questions accumulated for the current HTML section, then start a fresh transaction. */
    fun commitSection() {
        if (closed || !inTransaction) return
        try {
            for ((_,pair) in tests) db.execSQL("UPDATE test SET num_questions=? WHERE id=?", arrayOf<Any?>(pair.second,pair.first))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
            inTransaction=false
            if (writeCoordinatorHeld) {
                writeCoordinatorHeld=false
                QBankWriteCoordinator.lock.unlock()
            }
        }
        beginTransaction()
    }

    fun addQuestion(section:String, q:ImportedQuestion) {
        check(!closed) { "Import session is closed" }
        beginTransaction()
        val title=section.trim().ifBlank { "Imported Section" }.take(120)
        val test=tests.getOrPut(title) {
            val original=title
            val id=makeId(fileName, original, tests.size)
            db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions,total_marks,duration_seconds,time_per_question,original_id,series_number) VALUES(?,?,?,?,?,?,?,?,?,?)", arrayOf<Any?>(id,sourceId,title,null,0,0.0,0,0.0,original,""))
            id to 0
        }
        val testId=test.first
        val pos=test.second
        questionStatement.bindString(1,testId); questionStatement.bindLong(2,pos.toLong()); bindNullable(questionStatement,3,q.sourceId); bindNullable(questionStatement,4,q.text); bindNullable(questionStatement,5,q.rawText); bindNullable(questionStatement,6,q.correctAnswer); bindNullable(questionStatement,7,q.explanation); bindNullable(questionStatement,8,q.bot); bindNullable(questionStatement,9,q.video); bindNullable(questionStatement,10,q.audio)
        val qid=questionStatement.executeInsert(); questionStatement.clearBindings()
        q.options.forEachIndexed { i,o -> optionStatement.bindLong(1,qid); optionStatement.bindLong(2,i.toLong()); bindNullable(optionStatement,3,o.label); bindNullable(optionStatement,4,o.text); optionStatement.bindLong(5,if(o.correct)1L else 0L); optionStatement.executeInsert(); optionStatement.clearBindings() }
        q.questionImages.forEachIndexed { i,u -> imageStatement.bindLong(1,qid); imageStatement.bindString(2,"question"); imageStatement.bindLong(3,i.toLong()); imageStatement.bindString(4,u); imageStatement.executeInsert(); imageStatement.clearBindings() }
        q.explanationImages.forEachIndexed { i,u -> imageStatement.bindLong(1,qid); imageStatement.bindString(2,"explanation"); imageStatement.bindLong(3,i.toLong()); imageStatement.bindString(4,u); imageStatement.executeInsert(); imageStatement.clearBindings() }
        ftsStatement?.let { st ->
            try { st.bindLong(1,qid); st.bindString(2,testId); st.bindLong(3,sourceId); st.bindString(4,q.text+" "+(q.rawText ?: "")+" "+(q.correctAnswer ?: "")+" "+(q.explanation ?: "")+" "+(q.bot ?: "")+" "+(q.video ?: "")+" "+(q.audio ?: "")+" "+title+" "+q.options.joinToString(" "){it.label+" "+it.text}+" "+fileName); st.executeInsert() } catch (e: Exception) {
                Log.w("QBankDb", "FTS row skipped: ${e.message}")
                ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.fts_row_skipped")
            } finally { st.clearBindings() }
        }
        tests[title]=testId to (pos+1)
        total++
        // Keep very large single-section QBanks from holding one SQLite transaction for hours.
        if(total % 250 == 0) commitSection()
    }

    /** Roll back only the active transaction and remove any already-committed partial import. */
    fun abort() {
        if (closed) return
        try {
            if (inTransaction) {
                db.endTransaction()
                inTransaction=false
                if (writeCoordinatorHeld) {
                    writeCoordinatorHeld=false
                    QBankWriteCoordinator.lock.unlock()
                }
            }
            QBankWriteCoordinator.lock.lock()
            try {
                db.beginTransactionNonExclusive()
                db.delete("source", "id=?", arrayOf(sourceId.toString()))
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
                QBankWriteCoordinator.lock.unlock()
            }
        } finally {
            if (writeCoordinatorHeld) {
                writeCoordinatorHeld=false
                QBankWriteCoordinator.lock.unlock()
            }
            questionStatement.close(); optionStatement.close(); imageStatement.close(); ftsStatement?.close()
            closed=true
        }
    }

    fun finish(success:Boolean) {
        if(closed) return
        if (!success) { abort(); return }
        var committed = false
        var failure: Exception? = null
        try {
            for ((_,pair) in tests) db.execSQL("UPDATE test SET num_questions=? WHERE id=?", arrayOf<Any?>(pair.second,pair.first))
            if(inTransaction) db.setTransactionSuccessful()
            if(inTransaction) db.endTransaction()
            inTransaction=false
            if (writeCoordinatorHeld) {
                writeCoordinatorHeld=false
                QBankWriteCoordinator.lock.unlock()
            }
            committed = true
        } catch (e: Exception) {
            failure = e
            // A failure after the last question was inserted must not leave a partially
            // visible source behind. The Activity cannot call abort() after this method
            // closes the session, so cleanup belongs here.
            runCatching { if (inTransaction) db.endTransaction() }
            inTransaction=false
            if (writeCoordinatorHeld) {
                writeCoordinatorHeld=false
                QBankWriteCoordinator.lock.unlock()
            }
            runCatching {
                QBankWriteCoordinator.lock.lock()
                try {
                    db.beginTransactionNonExclusive()
                    try {
                        db.delete("source", "id=?", arrayOf(sourceId.toString()))
                        db.setTransactionSuccessful()
                    } finally { db.endTransaction() }
                } finally { QBankWriteCoordinator.lock.unlock() }
            }.onFailure { cleanup ->
                Log.e("QBankDb", "Failed to clean partial streaming import source=$sourceId", cleanup)
                ProductionCrashReporter.recordNonFatal(cleanup, "QBANK_STREAM_IMPORT_PARTIAL_CLEANUP")
            }
        } finally {
            if(inTransaction) runCatching { db.endTransaction() }
            inTransaction=false
            if (writeCoordinatorHeld) {
                writeCoordinatorHeld=false
                QBankWriteCoordinator.lock.unlock()
            }
            questionStatement.close(); optionStatement.close(); imageStatement.close(); ftsStatement?.close()
            closed=true
        }
        if (failure != null) throw failure
        if (committed) {
            finalizeSearchIndex()
            // Streaming HTML imports do not pass through importBundle(), so they must
            // publish the same committed-state invalidation explicitly. Without this,
            // QBankLoadingEngine can legitimately serve its cached non-empty source list
            // after the import Activity finishes, making a newly imported QBank appear to
            // have vanished until a process/cache reset.
            AppState.changed("import_completed")
        }
    }
}

