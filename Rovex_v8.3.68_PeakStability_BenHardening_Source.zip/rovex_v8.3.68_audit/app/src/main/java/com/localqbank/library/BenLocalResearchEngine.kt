package com.localqbank.library

import android.content.Context

/**
 * Offline-only research gateway for Ben.
 *
 * This is deliberately an adapter boundary, not an AI runtime. It never opens a URL,
 * performs network I/O, or downloads a model. Until a validated LiteRT-LM backend is
 * installed, requests fall back to Rovex's existing local clinical/QBank intelligence.
 * This keeps the stability build deterministic while leaving a safe insertion point for
 * an on-device Hugging Face/LiteRT model later.
 */
class BenLocalResearchEngine(
    context: Context,
    private val inferenceBackend: BenInferenceBackend = UnavailableBenInferenceBackend
) {
    private val app = context.applicationContext

    data class Capability(
        val offlineOnly: Boolean = true,
        val modelBackendAvailable: Boolean = false,
        val groundedInLocalQBank: Boolean = true
    )

    data class Result(
        val answer: String,
        val source: String,
        val modelUsed: Boolean
    )

    fun capability(): Capability = Capability(modelBackendAvailable = inferenceBackend.isAvailable)

    fun research(query: String): Result {
        val clean = BenResearchInputPolicy.normalize(query)
        if (clean == null) {
            return Result("Give Ben a clinical term, topic, question, or study task.", "local-safety", false)
        }
        val modelAnswer = runCatching { inferenceBackend.answer(clean) }.getOrNull()
        if (!modelAnswer.isNullOrBlank()) {
            return Result(modelAnswer, "Ben local model backend", true)
        }
        val insight = runCatching {
            if (AppManagers.isReady()) AppManagers.renCognitive.answer(clean)
            else RenCognitiveEngine(app).answer(clean)
        }.getOrElse {
            runCatching { RenCognitiveEngine(app).answer(clean) }.getOrNull()
        }
        if (insight != null && insight.body.isNotBlank()) {
            return Result(insight.body, "Rovex local clinical/QBank engine", false)
        }
        // Ben must never turn a local-engine failure into an Activity crash.
        return Result(
            "Ben could not complete that local request right now. The study app remains available; try the request again.",
            "local-safety",
            false
        )
    }
}
