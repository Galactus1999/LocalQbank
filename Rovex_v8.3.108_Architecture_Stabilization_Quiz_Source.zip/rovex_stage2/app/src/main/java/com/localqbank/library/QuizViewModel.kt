package com.localqbank.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/**
 * Lifecycle owner for quiz-session data dependencies.
 *
 * The first migration deliberately keeps this ViewModel small. It owns the session persistence
 * seam and opening/routing logic while QuizActivity continues to own view construction. Later
 * stages can extract focused UI use-cases without creating a second business-logic authority.
 */
class QuizViewModel(application: Application) : AndroidViewModel(application) {
    val data = QuizSessionRepository(application)
    private val navigation = QuizNavigationUseCase(data)
    private val session = QuizSessionUseCase(application)
    private val notes = QuizNotesUseCase(data)
    private val bookmarks = QuizBookmarkUseCase(data.progress) {
        if (AppManagers.isReady()) AppManagers.adaptive.onEvent("bookmark_changed")
    }
    private val answerUseCase = QuizAnswerUseCase(data.progress, StudyStateRepository(application))

    fun answer(question: Question, label: String, practiceMode: Boolean, examMode: Boolean): QuizAnswerUseCase.Result =
        answerUseCase.answer(question, label, practiceMode, examMode)

    fun resolveSession(
        title: String, requestedTestId: String, requestedQuestionId: Long, requestedPosition: Int,
        sessionIdsRaw: String?, collectionMode: Boolean, filterType: String, filterValue: String, sessionLabel: String?
    ): Result<QuizNavigationUseCase.SessionResolution> =
        navigation.resolve(title, requestedTestId, requestedQuestionId, requestedPosition, sessionIdsRaw, collectionMode, filterType, filterValue, sessionLabel)

    fun note(questionId: Long): String? = notes.get(questionId)
    fun saveNote(questionId: Long, value: String) = notes.save(questionId, value)
    fun appendNote(questionId: Long, value: String) = notes.append(questionId, value)
    fun bookmark(stableKey: String): String? = bookmarks.current(stableKey)
    fun setBookmark(stableKey: String, value: String?) = bookmarks.set(stableKey, value)
    fun mistakeType(stableKey: String): String? = bookmarks.mistakeType(stableKey)
    fun setMistakeType(stableKey: String, value: String?) = bookmarks.setMistakeType(stableKey, value)

    fun existingQuestionIds(ids: LongArray): LongArray = data.existingQuestionIds(ids)
    fun questionById(id: Long): Question? = data.questionById(id)
    fun questionAt(testId: String, position: Int): Question? = data.questionAt(testId, position)
    fun testIdForQuestion(questionId: Long): String = data.testIdForQuestion(questionId).orEmpty()
    fun sourceIdForTest(testId: String): Long = data.sourceIdForTest(testId)
    fun sourceNameForTest(testId: String): String? = data.sourceNameForTest(testId)
    fun questionCount(testId: String): Int = data.questionCount(testId)
    fun rawQuestionPosition(testId: String, questionId: Long): Int? = data.rawQuestionPosition(testId, questionId)
    fun progressStatus(stableKey: String): String? = data.progress.status(stableKey)
    fun selectedAnswer(stableKey: String): String? = data.progress.selected(stableKey)
    fun addTime(stableKey: String, elapsedMs: Long) = data.progress.addTime(stableKey, elapsedMs)
    fun sessionKey(label: String?, title: String, testId: String, collectionMode: Boolean): String = session.sessionKey(label, title, testId, collectionMode)
    fun saveSessionCursor(key: String, testId: String, position: Int, stableKey: String?) = session.saveCursor(key, testId, position, stableKey)
    fun checkpoint(testId: String, position: Int, stableKey: String?, sessionLabel: String?) = session.checkpoint(testId, position, stableKey, sessionLabel)
    fun savePosition(testId: String, position: Int, sourceId: Long, bankName: String) {
        if (testId.isNotBlank()) data.progress.setPosition(testId, position, sourceId, bankName)
    }

    fun findTestIdForQuestion(questionId: Long): String = data.testIdForQuestion(questionId).orEmpty()

    override fun onCleared() {
        data.close()
        super.onCleared()
    }
}
