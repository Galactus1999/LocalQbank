package com.localqbank.library

import android.content.Context
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/**
 * Optional CPU-first EmbeddingGemma 300M accelerator.
 *
 * It is deliberately a short-lived inference adapter: load -> embed a bounded batch -> close.
 * It never owns retrieval policy, scheduling, study state, or the canonical QBank corpus.
 * If the model is unavailable or the resource governor denies execution, callers keep their
 * deterministic FTS/concept retrieval path.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)

    data class Result<T>(
        val hits: List<SemanticHit<T>>,
        val elapsedMs: Long,
        val usedModel: Boolean
    )

    suspend fun <T> rerank(
        query: String,
        candidates: List<T>,
        textOf: (T) -> String,
        limit: Int = 8
    ): Result<T> = withContext(Dispatchers.Default) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile)
            ?: run {
                BenNeuralTelemetry.blocked("EmbeddingGemma 300M model is not installed")
                return@withContext Result(candidates.take(limit).map { SemanticHit(it, 0.0) }, 0L, false)
            }
        if (!policy.mayStartModel(profile.estimatedModelMb) ||
            !governor.mayRun(policy, profile.estimatedRuntimeMb)
        ) {
            BenNeuralTelemetry.blocked("EmbeddingGemma blocked by policy/resource governor")
            return@withContext Result(candidates.take(limit).map { SemanticHit(it, 0.0) }, 0L, false)
        }

        val boundedQuery = query.trim().replace(Regex("\\s+"), " ").take(1200)
        if (boundedQuery.length < 2 || candidates.isEmpty()) {
            return@withContext Result(emptyList(), 0L, false)
        }

        val selected = candidates.take(8)
        return@withContext try {
            val embedder = TextEmbedder.createFromFile(app, installed.file)
            try {
                val queryContext = TextEmbedder.TextFormatContext.builder()
                    .setTaskType(TextEmbedder.EmbeddingType.RETRIEVAL_QUERY)
                    .setRole(TextEmbedder.TextRole.QUERY)
                    .build()
                val documentContext = TextEmbedder.TextFormatContext.builder()
                    .setTaskType(TextEmbedder.EmbeddingType.RETRIEVAL_DOCUMENT)
                    .setTitle("none")
                    .setRole(TextEmbedder.TextRole.DOCUMENT)
                    .build()
                val queryEmbedding = embedder.embed(boundedQuery, queryContext)
                    .embeddingResult().embeddings().first()
                val scored = selected.map { candidate ->
                    val text = textOf(candidate).replace(Regex("\\s+"), " ").trim().take(1200)
                    val embedding = embedder.embed(text, documentContext)
                        .embeddingResult().embeddings().first()
                    SemanticHit(candidate, TextEmbedder.cosineSimilarity(queryEmbedding, embedding))
                }.sortedByDescending { it.similarity }.take(limit.coerceIn(1, 8))
                policy.recordBackendSuccess()
                Result(scored, max(0L, System.currentTimeMillis() - started), true)
            } finally {
                embedder.close()
            }
        } catch (error: Exception) {
            BenNeuralTelemetry.error("EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}")
            policy.recordBackendFailure()
            Result(candidates.take(limit).map { SemanticHit(it, 0.0) }, max(0L, System.currentTimeMillis() - started), false)
        }
    }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.Default) {
        val installed = models.installed(profile) ?: run {
            BenNeuralTelemetry.blocked("EmbeddingGemma 300M model is not installed")
            return@withContext null
        }
        if (!policy.mayStartModel(profile.estimatedModelMb) || !governor.mayRun(policy, profile.estimatedRuntimeMb)) return@withContext null
        try {
            val embedder = TextEmbedder.createFromFile(app, installed.file)
            try {
                val context = TextEmbedder.TextFormatContext.builder()
                    .setTaskType(TextEmbedder.EmbeddingType.SEMANTIC_SIMILARITY)
                    .setRole(TextEmbedder.TextRole.QUERY)
                    .build()
                val a = embedder.embed(first.trim().take(1200), context).embeddingResult().embeddings().first()
                val b = embedder.embed(second.trim().take(1200), context).embeddingResult().embeddings().first()
                policy.recordBackendSuccess()
                TextEmbedder.cosineSimilarity(a, b)
            } finally { embedder.close() }
        } catch (error: Exception) {
            BenNeuralTelemetry.error("EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}")
            policy.recordBackendFailure()
            null
        }
    }


}
