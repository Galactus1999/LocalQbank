package com.localqbank.library

/**
 * Move-only owner for the existing question-state preparation performed by QuizActivity.show().
 * No Activity or View is retained; UI effects are supplied as short-lived callbacks.
 */
class QuizQuestionStateCoordinator(
    private val quizViewModel: QuizViewModel,
    private val recordCurrentTime: () -> Unit,
    private val startTiming: () -> Unit,
    private val persistPosition: () -> Unit,
    private val updateExamTimer: () -> Unit,
    private val updateGuidanceTimer: () -> Unit,
    private val setJumpText: (String) -> Unit,
    private val unlockScroll: (Boolean) -> Unit,
    private val updateSectionChip: (Question, String?) -> Unit,
    private val updateBookmarkButton: (Question) -> Unit,
    private val updateNextButton: () -> Unit
) {
    data class Prepared(
        val status: String?,
        val answered: Boolean
    )

    fun prepare(q: Question): Prepared {
        recordCurrentTime()
        quizViewModel.setCurrentQuestion(q)
        startTiming()
        persistPosition()

        val status = quizViewModel.progressStatus(q.stableKey)
        val answered = if (quizViewModel.state.examMode) {
            quizViewModel.state.examAnswers.containsKey(q.stableKey)
        } else {
            status != null
        }

        if (quizViewModel.state.examMode) updateExamTimer() else updateGuidanceTimer()
        setJumpText((quizViewModel.state.position + 1).toString())
        unlockScroll(answered)
        updateSectionChip(q, status)
        updateBookmarkButton(q)
        updateNextButton()
        return Prepared(status = status, answered = answered)
    }
}
