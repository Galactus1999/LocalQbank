package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

/**
 * Main imported-QBank library. The list is deliberately independent from TestListActivity:
 * this screen owns source-level edit/delete/reorder while TestListActivity owns test-level work.
 */
class MainQBankLibraryActivity : Activity() {
    private lateinit var list: LinearLayout
    private var appliedThemeKey: String? = null
    private var sourceLoadInFlight = false
    private var hasResumedOnce = false
    private var libraryOrderCache: List<Long>? = null
    private val importRequestCode = 5197
    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Float = 18f) = GradientDrawable().apply {
        setColor(c); cornerRadius = r * resources.displayMetrics.density
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        shell()
        RovexBottomNavigation.install(this, RovexBottomNavigation.Destination.QBANK.index, b)
        load()
        appliedThemeKey = ThemeManager.get(this)
    }

    override fun onResume() {
        super.onResume()
        if (isFinishing || isDestroyed) return
        val theme = ThemeManager.get(this)
        if (appliedThemeKey != null && appliedThemeKey != theme) {
            appliedThemeKey = theme
            recreate()
            return
        }
        appliedThemeKey = theme
        if (::list.isInitialized && hasResumedOnce && !sourceLoadInFlight) load(forceRefresh = false)
        hasResumedOnce = true
    }


    override fun onSaveInstanceState(outState: Bundle) {
        RovexBottomNavigation.saveInstanceState(outState, RovexBottomNavigation.Destination.QBANK.index)
        super.onSaveInstanceState(outState)
    }

    private fun openImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/html"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        runCatching { startActivityForResult(intent, importRequestCode) }.onFailure {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, importRequestCode)
        }
    }

    @Deprecated("Activity result API retained for compatibility with the existing Activity architecture")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != importRequestCode || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<android.net.Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) if (!uris.contains(clip.getItemAt(i).uri)) uris.add(clip.getItemAt(i).uri) }
        if (uris.isEmpty()) return
        uris.forEach { uri -> runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        startActivity(Intent(this, HtmlImportActivity::class.java).putParcelableArrayListExtra("uris", uris))
    }

    private fun shell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(14), d(12), d(14), d(12))
            background = ThemeManager.backgroundDrawable(this@MainQBankLibraryActivity)
        }
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        h.addView(TextView(this).apply {
            text = "Imported QBanks"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@MainQBankLibraryActivity))
        }, LinearLayout.LayoutParams(0, d(52), 1f))
        h.addView(TextView(this).apply {
            text = "＋ IMPORT"; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = bg(ThemeManager.accent(this@MainQBankLibraryActivity), 14f)
            setPadding(d(12), 0, d(12), 0)
            setOnClickListener { openImportPicker() }
        }, LinearLayout.LayoutParams(d(100), d(44)))
        root.addView(h)
        root.addView(TextView(this).apply {
            text = "Main QBank list • tap to open subject/test content • long-press to manage a QBank"
            textSize = 12.5f; setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity)); setPadding(0, 0, 0, d(12))
        })
        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER; isFillViewport = true }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "← BACK"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@MainQBankLibraryActivity)); background = bg(ThemeManager.elevated(this@MainQBankLibraryActivity), 14f)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(-1, d(46)).apply { topMargin = d(10) })
        setContentView(root)
    }

    private fun load(forceRefresh: Boolean = false) {
        if (!::list.isInitialized || sourceLoadInFlight) return
        sourceLoadInFlight = true
        list.removeAllViews()
        list.addView(TextView(this).apply {
            text = "Loading imported QBanks…"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity)); setPadding(0, d(24), 0, d(24))
        })
        AppManagers.qbankLoading.loadLibrarySources(forceRefresh = forceRefresh) { ordered ->
            // The dedicated source lane now returns the already-ordered catalog. Do not hand
            // this critical visibility path back to PerformanceManager's serialized worker: that
            // queue is allowed to remain busy with derived study work, while the QBank library
            // must become visible as soon as its source metadata is readable.
            runOnUiThread {
                sourceLoadInFlight = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                libraryOrderCache = ordered.map { it.id }
                renderSources(ordered)
            }
        }
    }

    private fun applyOrder(raw: List<Source>): List<Source> {
        val stored = libraryOrderCache ?: MainRepository(applicationContext).use { it.qbankLibraryOrder() }.also { libraryOrderCache = it }
        val rank = stored.withIndex().associate { x -> x.value to x.index }
        return raw.sortedWith(compareBy<Source> { rank[it.id] ?: Int.MAX_VALUE }.thenByDescending { it.id })
    }

    private fun persistOrder(sources: List<Source>) {
        val desired = sources.map { it.id }
        libraryOrderCache = desired
        MainRepository(applicationContext).use { repo ->
            if (repo.qbankLibraryOrder() != desired) repo.setQBankLibraryOrder(desired)
        }
    }

    private fun renderSources(sources: List<Source>) {
        list.removeAllViews()
        if (sources.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No imported QBank yet.\nUse IMPORT to add one."
                textSize = 16f; gravity = Gravity.CENTER; setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity))
                setPadding(d(20), d(50), d(20), d(50))
            })
            return
        }
        sources.forEachIndexed { i, source ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(d(16), d(14), d(16), d(14))
                background = bg(ThemeManager.panel(this@MainQBankLibraryActivity), 18f)
                isClickable = true; isFocusable = true
                setOnClickListener {
                    startActivity(Intent(this@MainQBankLibraryActivity, TestListActivity::class.java)
                        .putExtra("sourceId", source.id).putExtra("sourceName", source.fileName))
                }
                setOnLongClickListener { showManageDialog(sources, i); true }
            }
            card.addView(TextView(this).apply {
                text = "${i + 1}. ${source.fileName}"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.text(this@MainQBankLibraryActivity)); maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            val meta = if (source.seriesNumber.isBlank()) source.provider.ifBlank { "Imported QBank" }
            else source.provider.ifBlank { "Imported QBank" } + " • Series ${source.seriesNumber}"
            card.addView(TextView(this).apply {
                text = meta; textSize = 12f; setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity)); setPadding(0, d(5), 0, 0)
            })
            card.addView(TextView(this).apply {
                text = "OPEN QBANK  ›   •   LONG-PRESS TO MANAGE"; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.accent(this@MainQBankLibraryActivity)); setPadding(0, d(10), 0, 0)
            })
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(9) })
        }
    }

    private fun showManageDialog(current: List<Source>, index: Int) {
        val source = current[index]
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(18), d(8), d(18), d(10))
            background = bg(ThemeManager.panel(this@MainQBankLibraryActivity), 24f)
        }
        panel.addView(TextView(this).apply {
            text = source.fileName
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@MainQBankLibraryActivity))
            setPadding(d(4), d(4), d(4), d(2))
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        panel.addView(TextView(this).apply {
            text = "Manage this QBank"
            textSize = 12f
            setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity))
            setPadding(d(4), 0, d(4), d(10))
        })

        fun action(label: String, subtitle: String, glyph: String, destructive: Boolean = false, enabled: Boolean = true, click: () -> Unit): View {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = enabled
                isFocusable = enabled
                alpha = if (enabled) 1f else 0.42f
                background = bg(ThemeManager.elevated(this@MainQBankLibraryActivity), 16f)
                setPadding(d(12), d(10), d(12), d(10))
                if (enabled) setOnClickListener { click() }
                val icon = TextView(this@MainQBankLibraryActivity).apply {
                    text = glyph
                    textSize = 18f
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (destructive) Color.rgb(205, 70, 78) else ThemeManager.accent(this@MainQBankLibraryActivity))
                    background = bg(ThemeManager.background(this@MainQBankLibraryActivity), 12f)
                }
                addView(icon, LinearLayout.LayoutParams(d(42), d(42)))
                val copy = LinearLayout(this@MainQBankLibraryActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(d(12), 0, d(4), 0)
                    addView(TextView(this@MainQBankLibraryActivity).apply {
                        text = label
                        textSize = 14.5f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(if (destructive) Color.rgb(190, 62, 70) else ThemeManager.text(this@MainQBankLibraryActivity))
                    })
                    addView(TextView(this@MainQBankLibraryActivity).apply {
                        text = subtitle
                        textSize = 11.5f
                        setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity))
                        setPadding(0, d(2), 0, 0)
                    })
                }
                addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }

        fun addAction(view: View) {
            panel.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(8) })
        }

        var dialog: AlertDialog? = null
        addAction(action("Edit name / series", "Change how this QBank is displayed", "✎") {
            dialog?.dismiss(); editSource(source)
        })
        if (index > 0) addAction(action("Move QBank up", "Place it earlier in your library", "↑") { dialog?.dismiss(); move(current, index, -1) })
        if (index < current.lastIndex) addAction(action("Move QBank down", "Place it later in your library", "↓") { dialog?.dismiss(); move(current, index, 1) })
        addAction(action("Reset progress", "Keep questions; clear answers, SRS, bookmarks and resume state", "↺") {
            dialog?.dismiss(); confirmResetProgress(source)
        })
        addAction(action("Delete QBank", "Permanently remove this QBank and its questions", "⌫", destructive = true) {
            dialog?.dismiss(); deleteSource(source)
        })

        dialog = AlertDialog.Builder(this).setView(panel).setNegativeButton("CANCEL", null).create()
        dialog!!.setOnShowListener {
            dialog!!.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ThemeManager.muted(this))
        }
        dialog!!.show()
    }

    private fun confirmResetProgress(source: Source) {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(20), 0, d(20), 0)
            addView(TextView(this@MainQBankLibraryActivity).apply {
                text = "This will start this QBank from a clean study state."
                textSize = 15f
                setTextColor(ThemeManager.text(this@MainQBankLibraryActivity))
            })
            addView(TextView(this@MainQBankLibraryActivity).apply {
                text = "Answers, correct/wrong status, attempts, SRS scheduling, bookmarks and resume position will be cleared. The QBank itself and its questions will remain. Historical study attempts are retained for analytics."
                textSize = 12.5f
                setTextColor(ThemeManager.muted(this@MainQBankLibraryActivity))
                setPadding(0, d(8), 0, 0)
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Reset QBank progress?")
            .setView(body)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("RESET") { _, _ ->
                PerformanceManager.submit {
                    val ok = runCatching { MainRepository(applicationContext).use { it.resetSourceProgress(source.id) } }.getOrDefault(false)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (ok) {
                            AppManagers.qbankLoading.invalidate(source.id)
                            PerformanceManager.invalidate()
                            Toast.makeText(this, "${source.fileName}: progress reset.", Toast.LENGTH_SHORT).show()
                            load(forceRefresh = true)
                        } else {
                            Toast.makeText(this, "Could not reset this QBank safely.", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .show()
    }

    private fun editSource(source: Source) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(4), d(20), 0) }
        val name = EditText(this).apply { setText(source.fileName); setSingleLine(true); hint = "QBank display name" }
        val series = EditText(this).apply { setText(source.seriesNumber); setSingleLine(true); hint = "Series number (optional)" }
        box.addView(name, LinearLayout.LayoutParams(-1, d(56)))
        box.addView(series, LinearLayout.LayoutParams(-1, d(56)))
        val dialog = AlertDialog.Builder(this).setTitle("Edit QBank").setView(box).setNegativeButton("CANCEL", null).setPositiveButton("SAVE", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val newName = name.text.toString().trim()
                if (newName.isBlank()) { name.error = "Name cannot be empty"; return@setOnClickListener }
                val seriesValue = series.text.toString()
                PerformanceManager.submit {
                    val ok = MainRepository(applicationContext).use { it.updateSourceMetadata(source.id, newName, seriesValue) }
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (ok) {
                            AppManagers.qbankLoading.invalidate(source.id); PerformanceManager.invalidate()
                            dialog.dismiss(); load()
                        } else RovexUndoSnackbar.show(window.decorView,"Could not update this QBank.")
                    }
                }
            }
        }
        dialog.show()
    }

    private fun move(current: List<Source>, index: Int, delta: Int) {
        val target = index + delta
        if (target !in current.indices) return
        val reordered = current.toMutableList().apply { add(target, removeAt(index)) }
        libraryOrderCache = reordered.map { it.id }
        // Persist order off the UI thread, then render the already-computed order immediately.
        PerformanceManager.submit { persistOrder(reordered) }
        renderSources(reordered)
    }

    private fun deleteSource(source: Source) {
        AlertDialog.Builder(this)
            .setTitle("Delete QBank?")
            .setMessage("Remove this QBank from Rovex now. Its questions will be cleaned up safely in the background; Flashcard data is not deleted.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("DELETE") { _, _ ->
                // The interactive path performs only the durable tombstone. The catalog can then
                // disappear immediately while the resumable worker removes questions/tests later.
                PerformanceManager.submitQBankDeletion {
                    val accepted = runCatching { MainRepository(applicationContext).use { it.requestSourceDeletion(source.id) } }.getOrDefault(false)
                    if (accepted) {
                        runCatching { MainRepository(applicationContext).use { repo ->
                            val next = repo.qbankLibraryOrder().filter { id -> id != source.id }
                            libraryOrderCache = next
                            repo.setQBankLibraryOrder(next)
                        } }
                        QBankDeletionRecoveryWorker.enqueue(applicationContext)
                    }
                    AppManagers.qbankLoading.invalidate(source.id)
                    PerformanceManager.invalidate()
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (accepted) {
                            Toast.makeText(this, "QBank removed. Finishing cleanup in background.", Toast.LENGTH_SHORT).show()
                            load()
                        } else {
                            Toast.makeText(this, "Could not start QBank deletion safely.", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .show()
    }

}
