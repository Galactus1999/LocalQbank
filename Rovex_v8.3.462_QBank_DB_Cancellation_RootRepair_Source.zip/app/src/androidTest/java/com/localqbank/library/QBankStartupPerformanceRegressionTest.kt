package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Regression coverage for startup/QBank responsiveness repairs.
 * These tests exercise the actual SQLite paths used by the fast source lane and bounded deletion.
 */
@RunWith(AndroidJUnit4::class)
class QBankStartupPerformanceRegressionTest {
    private lateinit var context: Context
    private lateinit var db: QBankDb

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
        db.sources() // initialize authoritative schema before the raw fixture handle is opened
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun bookmarkCountsUsesBoundedAggregateWithoutMaterializingProgressSnapshot() {
        val raw = context.openOrCreateDatabase("qbank.db", 0, null)
        try {
            raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(1,'s','S','test',1)")
            raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('t',1,'T','p',3)")
            raw.execSQL("INSERT INTO progress_v2(stable_key,test_id,status,bookmark) VALUES('t:0:a','t','correct','important')")
            raw.execSQL("INSERT INTO progress_v2(stable_key,test_id,status,bookmark) VALUES('t:1:b','t','wrong','important')")
            raw.execSQL("INSERT INTO progress_v2(stable_key,test_id,status,bookmark) VALUES('t:2:c','t','correct','favorite')")
        } finally {
            raw.close()
        }

        assertEquals(mapOf("important" to 2, "favorite" to 1), db.bookmarkCounts())
    }

    @Test
    fun boundedDeletionPassLeavesTombstoneAndCanResumeWithoutFullWriterHold() {
        val raw = context.openOrCreateDatabase("qbank.db", 0, null)
        try {
            raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(1,'large','Large','test',1)")
            raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('t',1,'T','p',101)")
            raw.beginTransaction()
            try {
                repeat(101) { i ->
                    raw.execSQL(
                        "INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(?,?,?,?,?,?)",
                        arrayOf<Any?>(i + 1L, "t", i, "q$i", "q$i", "q$i")
                    )
                }
                raw.setTransactionSuccessful()
            } finally {
                raw.endTransaction()
            }
        } finally {
            raw.close()
        }

        assertFalse(db.deleteSource(1L, repairSearchIndex = false, maxQuestionBatches = 1))
        assertEquals(listOf(1L), db.pendingDeletingSourceIds())
        // questionCount() intentionally excludes tombstoned sources. Inspect the physical rows
        // directly here so this regression proves that exactly one 50-row batch was deleted,
        // rather than accidentally treating a hidden source as physically empty.
        val physicalRemaining = context.openOrCreateDatabase("qbank.db", 0, null).use { raw ->
            raw.rawQuery(
                "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?",
                arrayOf("1")
            ).use { cursor ->
                cursor.moveToFirst()
                cursor.getInt(0)
            }
        }
        assertEquals(51, physicalRemaining)
        assertTrue(db.deleteSource(1L, repairSearchIndex = false))
        assertTrue(db.pendingDeletingSourceIds().isEmpty())
        assertEquals(0, db.questionCount("t"))
        assertTrue(db.sources().isEmpty())
    }


    @Test
    fun localSearchCancellationBoundaryStopsAliasFanout() {
        db.importBundle(
            "rvx-uri-search-cancel", "search.html", "HTML",
            listOf(
                ImportedTest(
                    originalId = "search-test", title = "Search", path = "Subject", totalMarks = 1.0,
                    duration = 0, timePerQuestion = 0.0,
                    questions = listOf(
                        ImportedQuestion(
                            "search-q", "startup-token", null, "A", null, null, null, null,
                            listOf(ImportedOption("A", "answer", true)), emptyList(), emptyList()
                        )
                    )
                )
            )
        )
        val service = LocalQBankSearchService(context)
        var calls = 0
        // Use an explicit extra variant so this test deterministically enters the alias lane
        // without depending on the clinical synonym table. The callback is allowed for the
        // first alias admission, then denies continuation before the next alias can start.
        val result = service.search(
            "zzzz",
            limit = 20,
            extraVariants = listOf("startup-token"),
            shouldContinue = {
                calls += 1
                calls < 2
            }
        )
        assertTrue(result.hits.any { it.title.contains("startup-token", ignoreCase = true) })
        assertEquals("cancellation boundary should be checked before and between aliases", 2, calls)
    }

    @Test
    fun qbankSourceLaneReturnsCatalogWithoutNeedingDashboardCallback() {
        db.importBundle(
            "rvx-uri-startup", "startup.html", "HTML",
            listOf(
                ImportedTest(
                    originalId = "t", title = "Startup", path = "Subject", totalMarks = 1.0,
                    duration = 0, timePerQuestion = 0.0,
                    questions = listOf(
                        ImportedQuestion(
                            "q", "startup-token", null, "A", null, null, null, null,
                            listOf(ImportedOption("A", "answer", true)), emptyList(), emptyList()
                        )
                    )
                )
            )
        )

        val latch = CountDownLatch(1)
        var result: List<Source> = emptyList()
        AppManagers.initialize(context)
        AppManagers.qbankLoading.invalidate()
        AppManagers.qbankLoading.loadLibrarySources(forceRefresh = true) {
            result = it
            latch.countDown()
        }

        assertTrue("QBank source catalog callback timed out", latch.await(3, TimeUnit.SECONDS))
        assertEquals(1, result.size)
        assertEquals("startup.html", result.single().fileName)
    }
}
