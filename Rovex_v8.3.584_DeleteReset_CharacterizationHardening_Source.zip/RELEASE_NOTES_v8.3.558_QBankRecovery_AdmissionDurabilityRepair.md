# Rovex v8.3.558 — QBank Recovery Admission Durability Repair

## Baseline
- Previous source: v8.3.557 / versionCode 646
- Previous source SHA-256: `86d3d5524b4b620705aa6be3f96c635141353b8ef397d51b3a62cd03db6c63fc`
- Current source: v8.3.558 / versionCode 647
- Application ID: `com.localqbank.library`
- Scope: QBank deletion/recovery admission hardening plus verification/CI assertion repair
- Delete-manager extraction: **NOT performed**; characterization remains the gate before extraction.

## Confirmed issues repaired

### 1. Recovery marker was not fully durable
`QBankDeletionRecoveryWorker.markRecoveryNeeded()` used `SharedPreferences.apply()`. This marker is the crash/process-death hand-off for a tombstoned QBank, so asynchronous persistence was not an adequate durability contract.

Repair:
- recovery-needed marker now uses synchronous `commit()`;
- completion marker also uses synchronous `commit()`;
- failure is explicit rather than silently pretending the durable state was written.

### 2. DeviceIdle migration marker could suppress recovery after enqueue failure
The v8.3.557 migration wrote `recovery_admission_version=556` before the replacement WorkManager request was accepted. If enqueue failed after cancellation, a later startup could see the migration as complete and never repair/admit the stale request again.

Repair:
- migration admission is serialized in-process;
- stale unique work is cancelled before replacement admission;
- `ExistingWorkPolicy.KEEP` remains the normal post-migration policy;
- admission version `556` is persisted only after `enqueueUniqueWork()` returns successfully;
- if enqueue throws, the old marker remains and the next admission retries the migration.

### 3. Search Phase-0 audit was stale after extraction
The Phase-0 gate counted `ESCAPE CHAR(92)` only inside `QBankDb`, although authoritative LIKE SQL had already moved into `QBankSearchQueryBuilder`.

Repair:
- Phase-0 now audits the extracted authoritative SQL builder;
- search regression remains exercised through the actual `QBankDb.search()` production path.

### 4. Related architecture/defect gates were stale
Two verification scripts still asserted pre-extraction source locations/contracts.

Repair:
- search regression gate now checks `QBankSearchQueryBuilder`;
- Continue checkpoint gate now checks the authoritative `QBankDb` answer checkpoint path;
- Frankenstein empty-result cache guard is checked against the current `cacheSearchIds()` contract;
- newly identified quiz presentation coordinators are documented in `ManagerContractRegistry` without adding business-logic ownership.

### 5. CI version/signing assertions were stale
The checked-in workflow still asserted v8.3.535/versionCode 625 and did not contain the required persistent certificate fingerprint assertion.

Repair:
- workflow identity updated to v8.3.558/versionCode 647;
- current main branch is the push trigger;
- APK certificate SHA-256 is asserted against the established persistent Rovex certificate;
- APK SHA-256 remains recorded as CI proof.

## Delete characterization strengthening
`QBankDeletionIsolationTest` now explicitly verifies that deleting one QBank preserves unrelated:
- `last_resume_global`
- `last_solved_global`

Existing characterization remains in place for:
- immediate tombstone visibility;
- deletion isolation;
- source-owned global cursor clearing;
- legacy hidden-source recovery without destructive deletion;
- paused/bounded deletion;
- stale FTS safety;
- same-display-filename import identity isolation.

## Static verification
PASS:
- Phase-0 offline gate
- XML parsing
- duplicate IDs within each individual layout
- targeted `findViewById`/XML type audit
- broad `Throwable` catch audit
- coroutine cancellation audit
- architecture ownership audit
- search/QBank regression audit
- search regression repair audit
- root architecture audit
- performance/search architecture audit
- defect regression audit
- CI source structural gate
- recovery admission static assertions
- delete contract static assertions

Warnings only:
- large existing source files, including `QBankDb.kt` (~1,867 lines). This is the current planned refactor target and was not split in this release.

## Execution status
- Android Gradle build: **BLOCKED** — environment could not resolve `downloads.gradle.org` while bootstrapping Gradle 9.3.1.
- JVM unit tests: **PENDING** — Gradle execution was blocked before tests could run.
- Instrumented tests: **PENDING**.
- CI: **PENDING** — source is not pushed/CI-executed from this repair workspace.
- Device validation: **PENDING**.
- Release verification: **PENDING**.

No BUILD PASS, CI PASS, INSTRUMENTED TEST PASS, DEVICE PASS, or RELEASE VERIFIED claim is made.
