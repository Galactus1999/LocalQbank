# Rovex v8.3.531 — Rovex Online Social Access Repair

## Root cause

The v8.3.530 personal-progress projection was working, but the social layer still had two Firestore contract defects:

1. The recipient mailbox was queried without a query field tying each result to the authenticated recipient. The previous rule depended on a `get(friendCodes/{targetCode})` lookup inside an unconstrained collection query. Firestore Rules queries are evaluated against their potential result set; rules are not filters. The mailbox transport is now explicitly query-scoped with `targetUid`.
2. Accept/decline tried to query the sender's outgoing collection while authenticated as the recipient. The outgoing read rule correctly allowed only the sender, so the recipient could not find the outgoing request to update it. The recipient now uses the immutable `intentId` stored in its incoming request to update the exact sender-owned outgoing document. The rule permits that exact update without granting the recipient collection read access.

## Changes

- v8.3.531 / versionCode 621.
- Friend-code lookup occurs before creating a request.
- Mailbox records now contain `targetUid`.
- Mailbox materialization queries `whereEqualTo("targetUid", currentUid)`.
- Mailbox create/read/delete rules validate/authorize `targetUid`.
- Incoming request rules explicitly separate `get` and `list`.
- Outgoing request rules explicitly separate sender `get/list` access.
- Accept/decline no longer reads the sender's outgoing collection as the recipient.
- Accept/decline uses the incoming request's `intentId` to address the exact outgoing document.
- Accepted friendship is still materialized on the recipient immediately and finalized on the sender by its own outgoing view.
- No QBankDb production code changed.
- No Cloud Function dependency introduced.

## Verification status

- STATIC REVIEW: PASS
- Kotlin delimiter audit: PASS
- JavaScript syntax check (`functions/index.js`): PASS
- Firestore rules structural delimiter audit: PASS
- Android compile: BLOCKED until Gradle/network/CI execution
- Firebase Rules emulator: NOT AVAILABLE in current container (Firebase CLI/emulator not installed)
- CI: PENDING
- Device two-account test: PENDING

Do not label this release green until CI and the two-account Firebase/device flow succeed.
