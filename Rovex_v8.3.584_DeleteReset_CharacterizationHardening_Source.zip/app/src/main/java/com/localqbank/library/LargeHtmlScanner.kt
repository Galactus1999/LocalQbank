package com.localqbank.library

import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.EOFException
import java.io.InputStreamReader
import java.util.regex.Pattern
import android.util.Log

/**
 * Streaming parser for very large combined QBank HTML files. It owns no Activity/UI state.
 * One question object is materialized at a time and delivered through the callback.
 */
class LargeHtmlScanner(private val file: File, private val onQuestion: (String, ImportedQuestion) -> Unit) {
    private val seen = HashSet<String>()
    private val maxQuestionChars = 16 * 1024 * 1024
    private var rootQuestionMode = false

    fun scan() {
        BufferedReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8), 256 * 1024).use { r ->
            // seekToDataArray() consumes the opening '[' so the parser starts exactly
            // at the first element of the real data array.
            if (!seekToDataArray(r)) throw IllegalArgumentException("No supported QBank data array found")
            while (true) {
                skipWs(r)
                val c = peek(r)
                if (c == -1 || c == ']'.code) break
                if (c == ','.code) { r.read(); continue }
                if (c != '{'.code) { skipValue(r); continue }
                if (rootQuestionMode) parseRootQuestion(r) else parseTestObject(r)
                skipWs(r)
                if (peek(r) == ','.code) r.read()
            }
        }
    }

    private fun seekToDataArray(r: BufferedReader): Boolean {
        // Lexically scan JavaScript code only. Never use a regex to decide whether the
        // current '[' belongs to a supported assignment: this boundary is critical to
        // import correctness and previously failed because regex escaping/rolling windows
        // made the result fragile across revisions.
        val window = StringBuilder()
        var quote = 0
        var escape = false
        var lineComment = false
        var blockComment = false

        while (true) {
            val c = r.read()
            if (c < 0) return false
            val ch = c.toChar()

            if (lineComment) {
                if (ch == '\n' || ch == '\r') {
                    lineComment = false
                    window.setLength(0)
                }
                continue
            }
            if (blockComment) {
                if (ch == '*' && peek(r) == '/'.code) {
                    r.read()
                    blockComment = false
                    window.setLength(0)
                }
                continue
            }
            if (quote != 0) {
                if (escape) {
                    escape = false
                } else if (ch == '\\') {
                    escape = true
                } else if (ch.code == quote) {
                    quote = 0
                }
                continue
            }

            if (ch == '/' && peek(r) == '/'.code) {
                r.read()
                lineComment = true
                window.setLength(0)
                continue
            }
            if (ch == '/' && peek(r) == '*'.code) {
                r.read()
                blockComment = true
                window.setLength(0)
                continue
            }
            if (ch == '"' || ch == '\'' || ch == '`') {
                quote = ch.code
                window.setLength(0)
                continue
            }

            if (ch == '[') {
                assignmentName(window.toString())?.let { name ->
                    rootQuestionMode =
                        name.contains("question", true) || name.equals("items", true)
                    return true
                }
            }

            window.append(ch)
            if (window.length > 512) {
                window.delete(0, window.length - 512)
            }
        }
    }

    /**
     * Exact, regex-free recognition of the assignment immediately before '['.
     *
     * Accepted forms include:
     *   TESTS_LIST = [
     *   const TESTS_LIST = [
     *   let
     *       questionData
     *       = [
     *   window.QUESTIONS_DATA = [
     *
     * The lexical scanner has already discarded comments and quoted strings.
     */
    private fun assignmentName(candidate: String): String? {
        val left = candidate.substringBeforeLast('=').trimEnd()
        if (left == candidate) return null

        var i = left.length - 1
        while (i >= 0 && isIdentifierPart(left[i])) i--
        if (i == left.length - 1) return null

        val name = left.substring(i + 1)
        if (name !in SUPPORTED_DATA_ARRAY_NAMES) return null

        var prefix = left.substring(0, i + 1).trimEnd()
        if (prefix.endsWith("window.")) {
            prefix = prefix.removeSuffix("window.").trimEnd()
        }

        // HTML may precede inline JavaScript, e.g. "<script>const TESTS_LIST".
        // Keep only the syntactic tail after the nearest markup boundary.
        prefix = prefix.substringAfterLast('>').trim()

        if (prefix.isEmpty()) return name

        // Permit a declaration keyword with arbitrary whitespace/newlines.
        val declaration = prefix.substringAfterLast(';').trim()
        return declaration
            .takeIf { it == "const" || it == "let" || it == "var" }
            ?.let { name }
    }

    private fun isIdentifierPart(ch: Char): Boolean =
        ch.isLetterOrDigit() || ch == '_' || ch == '$'

    private companion object {
        val SUPPORTED_DATA_ARRAY_NAMES = setOf(
            "TESTS_LIST",
            "APP_DATA",
            "QUESTIONS_DATA",
            "questions_json",
            "questionData",
            "questions",
            "question_list",
            "items"
        )
    }

    private fun parseRootQuestion(r: BufferedReader) {
        try {
            val raw=readObject(r)
            if (raw.length > maxQuestionChars) return
            val o=org.json.JSONObject(raw)
            val q=normalize(o) ?: return
            val key="Imported Section|"+(q.sourceId ?: "")+"|"+q.text.take(180)
            if(seen.add(key)) onQuestion("Imported Section",q)
        } catch (e: Exception) {
            // Malformed card data is recoverable. Logging must not turn a recoverable parse
            // failure into a JVM-unit-test crash when Android framework stubs are present.
            runCatching {
                android.util.Log.w("LargeHtmlScanner", "Malformed streamed question skipped: ${e.message}")
            }
            runCatching { ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "LargeHtmlScanner.question_skipped") }
        }
    }

    private fun parseTestObject(r: BufferedReader) {
        expect(r, '{')
        var title = "DAMS PYQ"
        while (true) {
            skipWs(r)
            val c = peek(r)
            if (c == '}'.code) { r.read(); return }
            if (c == ','.code) { r.read(); continue }
            if (c != '"'.code) { skipValue(r); continue }
            val key = readString(r)
            skipWs(r); expect(r, ':'); skipWs(r)
            when (key.lowercase()) {
                "title", "name", "subject", "section" -> {
                    val v = readSimpleStringOrValue(r)
                    if (v.isNotBlank() && v.length < 150) title = v
                }
                "questions" -> parseQuestionsArray(r, title)
                else -> skipValue(r)
            }
        }
    }

    private fun parseQuestionsArray(r: BufferedReader, section: String) {
        skipWs(r)
        if (peek(r) != '['.code) { skipValue(r); return }
        r.read()
        while (true) {
            skipWs(r)
            val c = peek(r)
            if (c == -1 || c == ']'.code) { if (c == ']'.code) r.read(); return }
            if (c == ','.code) { r.read(); continue }
            if (c != '{'.code) { skipValue(r); continue }
            val raw = readObject(r)
            if (raw.length <= maxQuestionChars) parseCandidate(raw, section)
        }
    }

    private fun parseCandidate(src: String, section: String) {
        try {
            val o = org.json.JSONObject(src)
            val q = normalize(o) ?: return
            val key = section + "|" + (q.sourceId ?: "") + "|" + q.text.take(180)
            if (seen.add(key)) onQuestion(section, q)
        } catch (_: Exception) {
            // A malformed/non-JSON object is skipped without aborting the whole import.
        }
    }

    private fun normalize(q: org.json.JSONObject): ImportedQuestion? {
        // Keep explicit JSON null out of every alias chain. JSONObject.NULL is a sentinel,
        // not Kotlin null, so all candidates are inspected through one deterministic helper.
        val text = clean(firstNonNull(q, "raw_text", "text", "question", "stem", "question_text"))
        val options = firstNonNull(q, "options", "choices", "answers")
        val opts = mutableListOf<ImportedOption>()
        when (options) {
            is org.json.JSONArray -> {
                for (i in 0 until options.length()) {
                    val x = options.opt(i)
                    if (x is org.json.JSONObject) {
                        val optionText = clean(firstNonNull(x, "text", "value", "option"))
                        val label = clean(x.opt("label")).ifBlank { "${'A'.code + i}" }
                        opts.add(
                            ImportedOption(
                                label,
                                optionText,
                                x.optBoolean("correct", false) || x.optBoolean("is_correct", false)
                            )
                        )
                    } else if (x != null && x != org.json.JSONObject.NULL) {
                        opts.add(ImportedOption("${'A'.code + i}", clean(x), false))
                    }
                }
            }
            is org.json.JSONObject -> {
                val keys = options.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = options.opt(key)
                    if (value != null && value != org.json.JSONObject.NULL) {
                        opts.add(ImportedOption(key, clean(value), false))
                    }
                }
            }
        }

        val ans = clean(firstNonNull(q, "correct_answer", "correctAnswer", "answer", "ans"))
            .ifBlank { null }
        val ex = clean(firstNonNull(q, "explanation", "solution", "expl"))
        val imgs = (
            extractImages(text) +
                extractImagesFromValue(firstNonNull(q, "question_images", "questionImages", "images", "img", "image", "questionImage"))
            ).distinct()
        val exImgs = (
            extractImages(ex) +
                extractImagesFromValue(firstNonNull(q, "explanation_images", "explanationImages", "explanationImage"))
            ).distinct()
        if (text.isBlank() || opts.isEmpty()) return null

        return ImportedQuestion(
            clean(firstNonNull(q, "id", "question_id")).ifBlank { null },
            text,
            clean(firstNonNull(q, "raw_text")).ifBlank { null },
            ans,
            ex.ifBlank { null },
            clean(firstNonNull(q, "bot")).ifBlank { null },
            clean(firstNonNull(q, "video")).ifBlank { null },
            clean(firstNonNull(q, "audio")).ifBlank { null },
            opts,
            imgs,
            exImgs
        )
    }

    private fun firstNonNull(q: org.json.JSONObject, vararg keys: String): Any? {
        for (key in keys) {
            if (!q.has(key) || q.isNull(key)) continue
            val value = q.opt(key)
            if (value != null && value != org.json.JSONObject.NULL) return value
        }
        return null
    }

    private fun clean(v: Any?): String = when (v) {
        null, org.json.JSONObject.NULL -> ""
        is String -> v
        else -> v.toString()
    }

    private fun extractImages(s: String): List<String> {
        val out = LinkedHashMap<String, Boolean>()
        val p = Pattern.compile("<img[^>]+(?:src|data-src|data-original|data-lazy-src)=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
        val m = p.matcher(s)
        while (m.find()) m.group(1)?.let { out[it] = true }
        val srcset = Pattern.compile("""\bsrcset=["']([^"']+)["']""", Pattern.CASE_INSENSITIVE).matcher(s)
        while (srcset.find()) groupSrcset(srcset.group(1), out)
        if (s.trim().startsWith("data:image", true)) out[s.trim()] = true
        return out.keys.toList()
    }

    private fun extractImagesFromValue(value: Any?): List<String> {
        val out = LinkedHashMap<String, Boolean>()
        fun add(v: String) {
            val x = v.trim()
            if (x.isBlank() || x.equals("null", true)) return
            if (x.startsWith("data:image", true) || x.startsWith("http://", true) || x.startsWith("https://", true) || x.startsWith("content://", true) || x.startsWith("file://", true)) out[x] = true
            else extractImages(x).forEach { out[it] = true }
        }
        when (value) {
            is org.json.JSONArray -> for (i in 0 until value.length()) add(value.optString(i))
            is Collection<*> -> value.forEach { add(it?.toString().orEmpty()) }
            else -> add(value?.toString().orEmpty())
        }
        return out.keys.toList()
    }

    private fun groupSrcset(value: String?, out: MutableMap<String, Boolean>) {
        value.orEmpty().split(',').forEach { part ->
            part.trim().split(Regex("\\s+")).firstOrNull()?.takeIf { it.isNotBlank() }?.let { out[it] = true }
        }
    }

    private fun readObject(r: BufferedReader): String {
        val out = StringBuilder()
        var depth = 0
        var quote = false
        var escape = false
        while (true) {
            val c = r.read()
            if (c < 0) throw EOFException("Unexpected end of QBank JSON")
            out.append(c.toChar())
            if (out.length > maxQuestionChars) throw IllegalArgumentException("Question object is too large")
            if (quote) {
                if (escape) escape = false else if (c == '\\'.code) escape = true else if (c == '"'.code) quote = false
            } else {
                when (c) {
                    '"'.code -> quote = true
                    '{'.code -> depth++
                    '}'.code -> { depth--; if (depth == 0) return out.toString() }
                }
            }
        }
    }

    private fun readSimpleStringOrValue(r: BufferedReader): String {
        skipWs(r)
        return if (peek(r) == '"'.code) readString(r) else {
            val b = StringBuilder()
            while (true) {
                val c = peek(r)
                if (c < 0 || c == ','.code || c == '}'.code) break
                b.append(r.read().toChar())
            }
            b.toString().trim()
        }
    }

    private fun readString(r: BufferedReader): String {
        expect(r, '"')
        val out = StringBuilder()
        var escape = false
        while (true) {
            val c = r.read()
            if (c < 0) throw EOFException("Unterminated JSON string")
            if (escape) {
                out.append(when (c) { 'n'.code -> '\n'; 'r'.code -> '\r'; 't'.code -> '\t'; 'b'.code -> '\b'; 'f'.code -> '\u000C'; else -> c.toChar() })
                escape = false
            } else if (c == '\\'.code) escape = true
            else if (c == '"'.code) return out.toString()
            else out.append(c.toChar())
        }
    }

    private fun skipValue(r: BufferedReader) {
        skipWs(r)
        when (peek(r)) {
            '"'.code -> readString(r)
            '{'.code -> { readContainer(r, '{'.code, '}'.code) }
            '['.code -> { readContainer(r, '['.code, ']'.code) }
            else -> while (true) { val c = peek(r); if (c < 0 || c == ','.code || c == '}'.code || c == ']'.code) break; r.read() }
        }
    }

    private fun readContainer(r: BufferedReader, open: Int, close: Int) {
        var depth = 0; var quote = false; var escape = false
        while (true) {
            val c = r.read(); if (c < 0) throw EOFException("Unexpected end of JSON")
            if (quote) { if (escape) escape = false else if (c == '\\'.code) escape = true else if (c == '"'.code) quote = false; continue }
            if (c == '"'.code) quote = true else if (c == open) depth++ else if (c == close && --depth == 0) return
        }
    }

    private fun skipWs(r: BufferedReader) { while (true) { val c = peek(r); if (c < 0 || !c.toChar().isWhitespace()) return; r.read() } }
    private fun peek(r: BufferedReader): Int { r.mark(1); val c = r.read(); r.reset(); return c }
    private fun expect(r: BufferedReader, ch: Char) { val c = r.read(); if (c != ch.code) throw IllegalArgumentException("Expected '$ch' in QBank data") }
    }

