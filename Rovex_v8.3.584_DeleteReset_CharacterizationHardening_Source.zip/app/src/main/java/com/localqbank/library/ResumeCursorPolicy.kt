package com.localqbank.library

/** Pure selection policy for Home Continue. Durable cursor timestamps win; explicit last-solved ties win. */
data class ResumeCursorCandidate<T>(val value: T, val savedAt: Long, val priority: Int)

object ResumeCursorPolicy {
    fun <T> newest(candidates: List<ResumeCursorCandidate<T>>): T? =
        candidates.maxWithOrNull(compareBy<ResumeCursorCandidate<T>> { it.savedAt }.thenBy { it.priority })?.value

    /** Durable transactional cursors outrank the legacy/transient session fallback. */
    fun <T> durableOrFallback(
        durableCandidates: List<ResumeCursorCandidate<T>>,
        fallback: T?
    ): T? = newest(durableCandidates) ?: fallback
}
