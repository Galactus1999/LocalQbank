package com.localqbank.library

import android.content.Context
import android.graphics.*
import kotlin.math.sqrt
import java.util.Random
import android.graphics.drawable.Drawable
import android.os.SystemClock
import kotlin.math.sin
import kotlin.math.cos

/**
 * Lightweight procedural atmosphere. It deliberately uses Canvas primitives rather than
 * bitmap/video assets so themes remain offline, small and memory-safe. Animation is paused
 * when the drawable is not visible and runs at a modest ~8 FPS while visible.
 */
class ThemeAtmosphereDrawable(context: Context) : Drawable() {
    private val context = context.applicationContext
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stars = Array(96) { i -> Triple(((i * 47) % 101) / 100f, ((i * 71 + 11) % 101) / 100f, .5f + ((i * 17) % 10) / 10f) }
    private var phase = 0f
    private var visible = true
    private var planetBitmap: Bitmap? = null
    private val animationRunnable = Runnable { invalidateSelf() }

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        when (ThemeManager.get(context)) {
            ThemeManager.PANDORA -> pandora(c, w, h)
            ThemeManager.SPACE -> space(c, w, h)
            ThemeManager.AMOLED -> dark(c, w, h)
            ThemeManager.MINT -> light(c, w, h, Color.rgb(229,255,248), Color.rgb(233,245,255), Color.rgb(91,220,192))
            ThemeManager.SUNSET -> light(c, w, h, Color.rgb(255,242,225), Color.rgb(255,229,239), Color.rgb(255,151,90))
            ThemeManager.LAVENDER -> light(c, w, h, Color.rgb(241,235,255), Color.rgb(225,242,255), Color.rgb(170,125,255))
            ThemeManager.PASTEL -> light(c, w, h, Color.rgb(228,241,255), Color.rgb(249,234,255), Color.rgb(121,169,255))
            else -> light(c, w, h, Color.rgb(239,246,255), Color.rgb(250,244,255), Color.rgb(112,155,255))
        }
        if (visible && (ThemeManager.get(context) == ThemeManager.PANDORA || ThemeManager.get(context) == ThemeManager.SPACE || ThemeManager.get(context) == ThemeManager.AMOLED)) {
            phase = (phase + .035f) % 100f
            scheduleSelf(animationRunnable, SystemClock.uptimeMillis() + 125L)
        }
    }

    private fun light(c: Canvas, w: Float, h: Float, a: Int, b: Int, glow: Int) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, a, b, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        val pts = arrayOf(floatArrayOf(w*.08f,h*.10f),floatArrayOf(w*.92f,h*.16f),floatArrayOf(w*.18f,h*.88f),floatArrayOf(w*.78f,h*.82f))
        pts.forEachIndexed { i, q ->
            p.shader = RadialGradient(q[0], q[1], minOf(w,h)*.42f,
                intArrayOf(Color.argb(70-i*8,Color.red(glow),Color.green(glow),Color.blue(glow)),Color.TRANSPARENT),
                floatArrayOf(0f,1f), Shader.TileMode.CLAMP)
            c.drawCircle(q[0],q[1],minOf(w,h)*.42f,p)
        }
        p.shader = null
    }

    private fun pandora(c: Canvas, w: Float, h: Float) {
        val m = minOf(w, h)
        // Deep indigo/teal/violet base. The gradient is deliberately asymmetric so the
        // composition has a readable visual light source instead of a flat wallpaper tint.
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, w * .34f, h,
            intArrayOf(
                Color.rgb(2, 5, 20),
                Color.rgb(4, 16, 34),
                Color.rgb(7, 20, 43),
                Color.rgb(18, 10, 41)
            ),
            floatArrayOf(0f, .30f, .67f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // Soft large-scale light volumes. Keep the number of gradient allocations bounded:
        // this drawable is animated at ~8 FPS while visible.
        glow(c, w * .12f, h * .24f, m * .48f, Color.rgb(0, 205, 255), 45)
        glow(c, w * .78f, h * .18f, m * .44f, Color.rgb(120, 72, 255), 54)
        glow(c, w * .54f, h * .54f, m * .58f, Color.rgb(18, 112, 232), 26)
        glow(c, w * .88f, h * .70f, m * .38f, Color.rgb(255, 44, 194), 28)

        drawAuroraVeils(c, w, h)

        // Celestial anchors give the scene scale and prevent the lower forest from reading as
        // an ordinary fantasy landscape.
        moon(c, w * .82f, h * .115f, m * .082f)
        pandoraPlanet(c, w * .14f, h * .13f, m * .042f, Color.rgb(67, 225, 255), Color.rgb(81, 43, 201))
        pandoraPlanet(c, w * .93f, h * .34f, m * .023f, Color.rgb(255, 105, 214), Color.rgb(60, 66, 205))

        // Smooth depth ridges. They use curved valleys rather than the old saw-tooth line
        // construction, which is noticeably more polished at phone-sized bounds.
        mountainRange(c, w, h, .55f, Color.rgb(5, 15, 34), .16f, 0)
        mountainRange(c, w, h, .66f, Color.rgb(4, 13, 28), .20f, 1)
        mountainRange(c, w, h, .76f, Color.rgb(3, 11, 23), .15f, 2)

        val groundTop = h * .80f
        drawLuminousTerrain(c, w, h, groundTop)

        // Alien canopy: tapered path silhouettes with asymmetric branches and sparse inner
        // bioluminescent veins. No circle-stack tree geometry.
        val treeCount = 24
        for (i in 0 until treeCount) {
            val x = (i / (treeCount - 1f)) * w + sin(phase * .055f + i * .8f) * w * .0025f
            val depth = ((i * 17) % 23) / 22f
            val treeH = h * (.085f + depth * .095f)
            val trunk = if (i % 3 == 0) Color.rgb(7, 29, 43) else Color.rgb(5, 23, 37)
            val canopy = when (i % 5) {
                0 -> Color.rgb(11, 55, 78)
                1 -> Color.rgb(18, 40, 85)
                2 -> Color.rgb(35, 31, 76)
                3 -> Color.rgb(10, 57, 63)
                else -> Color.rgb(15, 46, 70)
            }
            elegantTree(c, x, h * .875f, treeH, trunk, canopy, i)
        }

        // Bioluminescent flowers are composited as sculpted petals + filaments + stalks.
        val flora = arrayOf(
            floatArrayOf(.08f, .72f, .030f, 0f),
            floatArrayOf(.20f, .64f, .041f, 1f),
            floatArrayOf(.34f, .76f, .027f, 2f),
            floatArrayOf(.50f, .65f, .047f, 3f),
            floatArrayOf(.65f, .74f, .034f, 4f),
            floatArrayOf(.79f, .59f, .043f, 5f),
            floatArrayOf(.91f, .73f, .031f, 6f)
        )
        flora.forEach { f ->
            val fx = w * f[0]
            val fy = h * f[1] + sin(phase * .14f + f[3]) * h * .006f
            val fr = m * f[2]
            val colour = when (f[3].toInt() % 6) {
                0 -> Color.rgb(52, 232, 255)
                1 -> Color.rgb(145, 88, 255)
                2 -> Color.rgb(255, 58, 199)
                3 -> Color.rgb(74, 255, 206)
                4 -> Color.rgb(255, 177, 82)
                else -> Color.rgb(198, 72, 255)
            }
            bioFlower(c, fx, fy, fr, colour, f[3])
        }

        // A few larger seed clusters establish foreground/midground separation.
        for (i in 0 until 24) {
            val x = ((i * 37 + 11) % 100) / 100f * w + sin(phase * .22f + i * .7f) * w * .009f
            val y = h * (.53f + ((i * 23 + 9) % 34) / 100f) + cos(phase * .16f + i) * h * .007f
            val col = when (i % 5) {
                0 -> Color.rgb(39, 232, 255)
                1 -> Color.rgb(141, 80, 255)
                2 -> Color.rgb(255, 66, 201)
                3 -> Color.rgb(90, 255, 193)
                else -> Color.rgb(255, 187, 92)
            }
            val pulse = .55f + .45f * ((sin(phase * .50f + i * .9f) + 1f) * .5f)
            p.color = Color.argb((85f + 110f * pulse).toInt().coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))
            c.drawCircle(x, y, m * .0027f, p)
            if (i % 3 == 0) glow(c, x, y, m * .010f, col, (26f + 30f * pulse).toInt())
        }

        // Quiet silhouettes keep the scale grounded without becoming cartoon characters.
        pandoraPerson(c, w * .38f, h * .874f, m * .040f, Color.rgb(76, 157, 255), .94f)
        pandoraPerson(c, w * .45f, h * .873f, m * .035f, Color.rgb(167, 94, 255), .84f)
        deer(c, w * .69f, h * .874f, m * .031f)
        deer(c, w * .83f, h * .878f, m * .024f)
        pandoraFlyingCreature(c, w * (.23f + .095f * sin(phase * .055f)), h * .285f, m * .040f)
        pandoraFlyingCreature(c, w * (.66f + .075f * cos(phase * .047f)), h * .205f, m * .030f)

        // Fireflies: smaller, pulsing, spatially distributed points rather than identical dots.
        for (i in 0 until 30) {
            val x = ((i * 41 + 5) % 100) / 100f * w + sin(phase * .27f + i * 1.13f) * w * .013f
            val y = ((i * 29 + 13) % 70) / 100f * h + cos(phase * .19f + i * .71f) * h * .011f
            val col = when (i % 4) {
                0 -> Color.rgb(55, 242, 255)
                1 -> Color.rgb(191, 93, 255)
                2 -> Color.rgb(255, 100, 216)
                else -> Color.rgb(108, 255, 194)
            }
            val pulse = .35f + .65f * ((sin(phase * .64f + i * 1.7f) + 1f) * .5f)
            val radius = m * (.0045f + .0025f * pulse)
            glow(c, x, y, radius * 2.2f, col, (36f + 52f * pulse).toInt())
            p.color = Color.argb((100f + 135f * pulse).toInt().coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))
            c.drawCircle(x, y, radius * .42f, p)
        }

        // Fine atmospheric reflection over the foreground plane.
        p.shader = LinearGradient(
            0f, h * .76f, 0f, h,
            Color.argb(42, 40, 224, 255),
            Color.argb(0, 20, 16, 48),
            Shader.TileMode.CLAMP
        )
        p.style = Paint.Style.FILL
        c.drawRect(0f, h * .76f, w, h, p)
        p.shader = null
    }

    private fun drawAuroraVeils(c: Canvas, w: Float, h: Float) {
        val layers = arrayOf(
            Triple(.17f, Color.rgb(18, 180, 255), .16f),
            Triple(.24f, Color.rgb(92, 92, 255), .12f),
            Triple(.31f, Color.rgb(207, 66, 232), .09f)
        )
        layers.forEachIndexed { index, layer ->
            val base = h * layer.first
            val sway = h * (.028f + index * .008f)
            val path = Path().apply {
                moveTo(-w * .08f, base)
                cubicTo(w * .16f, base - sway, w * .34f, base + sway, w * .52f, base - sway * .45f)
                cubicTo(w * .70f, base - sway * .95f, w * .88f, base + sway * .65f, w * 1.08f, base - sway * .20f)
                lineTo(w * 1.08f, base + h * .06f)
                cubicTo(w * .80f, base + h * .04f, w * .47f, base + h * .075f, -w * .08f, base + h * .045f)
                close()
            }
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(
                0f, base - sway, w, base + h * .05f,
                Color.argb((layer.third * 255f).toInt(), Color.red(layer.second), Color.green(layer.second), Color.blue(layer.second)),
                Color.argb(0, Color.red(layer.second), Color.green(layer.second), Color.blue(layer.second)),
                Shader.TileMode.CLAMP
            )
            c.drawPath(path, p)
        }
        p.shader = null
    }

    private fun drawLuminousTerrain(c: Canvas, w: Float, h: Float, top: Float) {
        val terrain = Path().apply {
            moveTo(0f, h)
            lineTo(0f, top)
            cubicTo(w * .12f, top - h * .028f, w * .20f, top + h * .020f, w * .33f, top - h * .010f)
            cubicTo(w * .46f, top - h * .040f, w * .57f, top + h * .015f, w * .70f, top - h * .018f)
            cubicTo(w * .83f, top - h * .050f, w * .92f, top + h * .012f, w, top - h * .020f)
            lineTo(w, h)
            close()
        }
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, top, w * .72f, h,
            Color.rgb(5, 21, 34),
            Color.rgb(7, 12, 25),
            Shader.TileMode.CLAMP
        )
        c.drawPath(terrain, p)
        p.shader = null

        // A narrow, winding reflective water/light channel breaks up the lower silhouette.
        val river = Path().apply {
            moveTo(w * .53f, top + h * .02f)
            cubicTo(w * .48f, top + h * .09f, w * .59f, top + h * .15f, w * .50f, h)
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = minOf(w, h) * .026f
        p.shader = LinearGradient(0f, top, w, h, Color.argb(18, 37, 185, 255), Color.argb(88, 60, 255, 215), Shader.TileMode.CLAMP)
        c.drawPath(river, p)
        p.strokeWidth = minOf(w, h) * .006f
        p.shader = null
        p.color = Color.argb(95, 118, 240, 255)
        c.drawPath(river, p)
        for (i in 0..5) {
            val y = top + h * (.10f + i * .115f)
            p.strokeWidth = minOf(w, h) * .0025f
            p.color = Color.argb(26 + i * 4, 73, 215, 255)
            c.drawLine(w * (.38f + i * .035f), y, w * (.62f - i * .025f), y + h * .004f, p)
        }
        p.style = Paint.Style.FILL
    }
    private fun space(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f,0f,w,h,Color.rgb(0,2,10),Color.rgb(6,8,30),Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p)
        // Broad procedural nebula bands.
        nebula(c,w*.62f,h*.30f,minOf(w,h)*.55f,Color.rgb(75,92,255),75)
        nebula(c,w*.18f,h*.73f,minOf(w,h)*.45f,Color.rgb(0,205,255),55)
        nebula(c,w*.48f,h*.55f,minOf(w,h)*.36f,Color.rgb(175,70,255),32)
        // Dense star field with subtle twinkle and a few brighter stars.
        stars.forEachIndexed { i,s ->
            val tw=.42f+.58f*((sin(phase*.50f+i*.71f)+1f)/2f)
            p.color=Color.argb((90+140*tw).toInt().coerceIn(0,255),190,220,255)
            c.drawCircle(s.first*w,s.second*h,s.third*(.35f+.28f*tw),p)
            if(i%17==0) starburst(c,s.first*w,s.second*h,minOf(w,h)*.008f,Color.WHITE,(80+100*tw).toInt())
        }
        // Original cached Earth-like planet texture: photo-like ocean/land/cloud detail
        // without shipping a large copyrighted bitmap or video. It is generated once and
        // reused for every animation frame.
        val r=minOf(w,h)*.19f; val px=w*.70f; val py=h*.66f
        planetBitmap()?.let { bmp ->
            val dst=RectF(px-r,py-r,px+r,py+r)
            c.drawBitmap(bmp,null,dst,p)
        }
        // Fine atmospheric rim and a subtle ring highlight.
        p.style=Paint.Style.STROKE;p.strokeWidth=r*.018f;p.color=Color.argb(145,155,215,255);c.drawCircle(px,py,r*1.01f,p);p.style=Paint.Style.FILL
        val mr=r*.045f; val mx=w*.31f; val my=h*.28f
        p.shader=RadialGradient(mx-mr*.3f,my-mr*.4f,mr,Color.WHITE,Color.rgb(80,100,170),Shader.TileMode.CLAMP);c.drawCircle(mx,my,mr,p);p.shader=null
        // Slow comet crossing the field.
        val t=(phase*.010f)%1f; val cx=(-.12f+t*1.30f)*w; val cy=(.12f+t*.30f)*h
        p.strokeWidth=minOf(w,h)*.007f;p.strokeCap=Paint.Cap.ROUND;p.color=Color.argb(125,170,225,255);c.drawLine(cx-w*.12f,cy-h*.055f,cx,cy,p);glow(c,cx,cy,minOf(w,h)*.016f,Color.WHITE,170)
    }

    private fun dark(c:Canvas,w:Float,h:Float){
        // AMOLED keeps the majority of the background at absolute black while retaining a
        // restrained cosmic layer so OLED power use remains materially lower than SPACE.
        p.style=Paint.Style.FILL;p.color=Color.BLACK;c.drawRect(0f,0f,w,h,p)
        nebula(c,w*.68f,h*.16f,minOf(w,h)*.50f,Color.rgb(28,72,255),28)
        nebula(c,w*.14f,h*.78f,minOf(w,h)*.34f,Color.rgb(0,175,255),22)
        stars.take(54).forEachIndexed{i,s->
            val tw=.45f+.55f*((sin(phase*.45f+i)+1f)/2f)
            p.color=Color.argb((70+120*tw).toInt(),180,215,255)
            c.drawCircle(s.first*w,s.second*h,s.third*.45f,p)
        }
        glow(c,w*.86f,h*.13f,minOf(w,h)*.055f,Color.rgb(55,196,255),80)
    }


    private fun planetBitmap(): Bitmap? {
        planetBitmap?.let { return it }
        val size=256
        val bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888)
        val px=IntArray(size*size)
        val rnd=Random(3181999L)
        val blobs=Array(18){floatArrayOf(rnd.nextFloat()*2f-1f,rnd.nextFloat()*2f-1f,.10f+rnd.nextFloat()*.32f)}
        for(y in 0 until size) for(x in 0 until size){
            val nx=(x/(size-1f))*2f-1f; val ny=(y/(size-1f))*2f-1f; val rr=nx*nx+ny*ny
            val idx=y*size+x
            if(rr>1f){px[idx]=Color.TRANSPARENT;continue}
            val z=sqrt((1f-rr).coerceAtLeast(0f));
            val light=(.32f + .68f*(.55f*nx+.35f*ny+.82f*z).coerceIn(0f,1f))
            var n=(sin(nx*8.7f+ny*3.1f)+sin(nx*17.3f-ny*9.4f)*.45f+sin(nx*31.1f+ny*18.7f)*.18f)
            var land=n>.55f
            blobs.forEach { b -> val dx=nx-b[0]; val dy=ny-b[1]; if(dx*dx+dy*dy < b[2]*b[2] && n>.05f) land=true }
            var r0=if(land) 84f else 22f; var g0=if(land) 86f else 104f; var b0=if(land) 68f else 150f
            val cloud=(sin(nx*21f+ny*13f)+sin(nx*39f-ny*17f)*.55f+sin(nx*67f+ny*29f)*.22f)/1.77f
            if(cloud>.58f){ r0=230f;g0=238f;b0=240f }
            val rim=(1f-z)*.55f
            val rrC=(r0*light + 105f*rim).toInt().coerceIn(0,255)
            val ggC=(g0*light + 185f*rim).toInt().coerceIn(0,255)
            val bbC=(b0*light + 255f*rim).toInt().coerceIn(0,255)
            val alpha=(255f*(.90f+.10f*z)).toInt().coerceIn(0,255)
            px[idx]=Color.argb(alpha,rrC,ggC,bbC)
        }
        bmp.setPixels(px,0,size,0,0,size,size)
        planetBitmap=bmp
        return bmp
    }

    private fun moon(c:Canvas,x:Float,y:Float,r:Float){
        p.style=Paint.Style.FILL
        p.shader=RadialGradient(x-r*.35f,y-r*.45f,r,Color.rgb(232,255,247),Color.rgb(70,132,125),Shader.TileMode.CLAMP)
        c.drawCircle(x,y,r,p);p.shader=null
        p.color=Color.argb(35,20,70,65)
        for(i in 0..5){ val cx=x+sin(i*2.1f)*r*.42f; val cy=y+cos(i*1.7f)*r*.42f; c.drawCircle(cx,cy,r*(.06f+.015f*i),p) }
    }
    private fun nebula(c:Canvas,x:Float,y:Float,r:Float,color:Int,alpha:Int){
        p.style=Paint.Style.FILL
        p.shader=RadialGradient(x-r*.18f,y-r*.12f,r,
            intArrayOf(Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color)),Color.argb(alpha/3,Color.red(color),Color.green(color),Color.blue(color)),Color.TRANSPARENT),
            floatArrayOf(0f,.42f,1f),Shader.TileMode.CLAMP)
        c.drawCircle(x,y,r,p);p.shader=null
    }
    private fun starburst(c:Canvas,x:Float,y:Float,r:Float,color:Int,alpha:Int){
        p.color=Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));p.strokeWidth=r*.55f; p.strokeCap=Paint.Cap.ROUND
        c.drawLine(x-r*2f,y,x+r*2f,y,p);c.drawLine(x,y-r*2f,x,y+r*2f,p)
    }
    private fun deer(c:Canvas,x:Float,y:Float,r:Float){
        p.color=Color.argb(220,4,18,20)
        c.drawOval(x-r*1.7f,y-r*.75f,x+r*1.0f,y+r*.75f,p)
        c.drawOval(x+r*.65f,y-r*1.0f,x+r*1.55f,y-r*.15f,p)
        c.drawRect(x-r*1.05f,y+r*.55f,x-r*.78f,y+r*1.8f,p);c.drawRect(x+r*.35f,y+r*.55f,x+r*.62f,y+r*1.8f,p)
        p.style=Paint.Style.STROKE;p.strokeWidth=r*.16f;p.strokeCap=Paint.Cap.ROUND
        c.drawLine(x+r*1.25f,y-r*.75f,x+r*1.55f,y-r*1.55f,p);c.drawLine(x+r*1.55f,y-r*1.55f,x+r*1.75f,y-r*1.35f,p);c.drawLine(x+r*1.55f,y-r*1.55f,x+r*1.38f,y-r*1.25f,p);p.style=Paint.Style.FILL
    }

    private fun pandoraPlanet(c: Canvas, x: Float, y: Float, r: Float, a: Int, b: Int) {
        glow(c, x, y, r * 2.2f, a, 58)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(x - r * .38f, y - r * .42f, r,
            Color.rgb(minOf(255, Color.red(a) + 40), minOf(255, Color.green(a) + 30), minOf(255, Color.blue(a) + 24)),
            b, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * .055f
        p.color = Color.argb(125, Color.red(a), Color.green(a), Color.blue(a))
        c.drawCircle(x, y, r * 1.04f, p)
        p.style = Paint.Style.FILL
    }

    private fun bioPetalPath(cx: Float, cy: Float, r: Float, angle: Float): Path {
        val ux = cos(angle).toFloat()
        val uy = sin(angle).toFloat()
        val vx = -uy
        val vy = ux
        val tip = r * 1.06f
        val neck = r * .16f
        val width = r * .33f
        return Path().apply {
            moveTo(cx + vx * neck, cy + vy * neck)
            cubicTo(
                cx + ux * tip * .42f + vx * width, cy + uy * tip * .42f + vy * width,
                cx + ux * tip * .82f + vx * width * .82f, cy + uy * tip * .82f + vy * width * .82f,
                cx + ux * tip, cy + uy * tip
            )
            cubicTo(
                cx + ux * tip * .82f - vx * width * .82f, cy + uy * tip * .82f - vy * width * .82f,
                cx + ux * tip * .42f - vx * width, cy + uy * tip * .42f - vy * width,
                cx - vx * neck, cy - vy * neck
            )
            close()
        }
    }

    private fun elegantTree(c: Canvas, x: Float, base: Float, height: Float, trunk: Int, canopy: Int, seed: Int) {
        // Tapered trunk and branch framework.
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = height * .065f
        p.color = trunk
        val trunkTop = base - height * .60f
        c.drawLine(x, base, x + sin(seed.toFloat()) * height * .035f, trunkTop, p)
        p.strokeWidth = height * .030f
        c.drawLine(x, base - height * .23f, x - height * (.23f + (seed % 3) * .03f), base - height * .43f, p)
        c.drawLine(x, base - height * .34f, x + height * (.19f + (seed % 4) * .025f), base - height * .57f, p)
        c.drawLine(x, base - height * .48f, x - height * .16f, base - height * .70f, p)

        // One continuous canopy silhouette made from Bezier lobes. This reads as organic
        // foliage at small sizes instead of a set of circles.
        p.style = Paint.Style.FILL
        val top = base - height
        val l = Path().apply {
            moveTo(x, top)
            cubicTo(x - height * .16f, top + height * .12f, x - height * .23f, base - height * .73f, x - height * .39f, base - height * .63f)
            cubicTo(x - height * .30f, base - height * .50f, x - height * .48f, base - height * .42f, x - height * .31f, base - height * .30f)
            cubicTo(x - height * .17f, base - height * .20f, x - height * .27f, base - height * .11f, x, base - height * .06f)
            cubicTo(x + height * .27f, base - height * .11f, x + height * .17f, base - height * .20f, x + height * .31f, base - height * .30f)
            cubicTo(x + height * .48f, base - height * .42f, x + height * .30f, base - height * .50f, x + height * .39f, base - height * .63f)
            cubicTo(x + height * .23f, base - height * .73f, x + height * .16f, top + height * .12f, x, top)
            close()
        }
        p.color = canopy
        c.drawPath(l, p)

        // Luminous veins on the inner canopy add detail without noisy decoration.
        p.style = Paint.Style.STROKE
        p.strokeWidth = height * .010f
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.argb(72, 90, 236, 230)
        c.drawLine(x, top + height * .17f, x - height * .11f, base - height * .18f, p)
        c.drawLine(x - height * .04f, base - height * .31f, x - height * .24f, base - height * .47f, p)
        c.drawLine(x + height * .02f, base - height * .35f, x + height * .22f, base - height * .50f, p)
        p.style = Paint.Style.FILL
        val shimmer = .5f + .5f * ((sin(phase * .42f + seed) + 1f) * .5f)
        p.color = Color.argb((18f + 28f * shimmer).toInt(), 70, 235, 228)
        c.drawCircle(x - height * .20f, base - height * .48f, height * .022f, p)
        c.drawCircle(x + height * .17f, base - height * .55f, height * .018f, p)
    }

    private fun bioFlower(c: Canvas, x: Float, y: Float, r: Float, colour: Int, seed: Float) {
        val pulse = .70f + .30f * ((sin(phase * .74f + seed * 1.7f) + 1f) * .5f)
        glow(c, x, y, r * 3.4f, colour, (42f + 42f * pulse).toInt())

        // Stem + paired alien leaves.
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * .085f
        p.color = Color.argb(175, 38, 113, 104)
        c.drawLine(x, y + r * .22f, x - r * .12f, y + r * 1.45f, p)
        p.style = Paint.Style.FILL
        val leaf = Path().apply {
            moveTo(x - r * .07f, y + r * .75f)
            cubicTo(x - r * .52f, y + r * .70f, x - r * .62f, y + r * .96f, x - r * .10f, y + r * .86f)
            close()
        }
        p.color = Color.argb(125, Color.red(colour), Color.green(colour), Color.blue(colour))
        c.drawPath(leaf, p)
        val leaf2 = Path().apply {
            moveTo(x + r * .01f, y + r * .58f)
            cubicTo(x + r * .48f, y + r * .45f, x + r * .62f, y + r * .70f, x + r * .08f, y + r * .72f)
            close()
        }
        c.drawPath(leaf2, p)

        val petals = if (seed.toInt() % 2 == 0) 6 else 5
        for (i in 0 until petals) {
            val a = i * (2.0 * Math.PI / petals) + seed * .31f
            val petal = bioPetalPath(x, y, r * .76f, a.toFloat())
            p.color = Color.argb((150f + 55f * pulse).toInt().coerceIn(0, 255), Color.red(colour), Color.green(colour), Color.blue(colour))
            c.drawPath(petal, p)
        }

        // Fine central filaments.
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * .035f
        p.color = Color.argb(175, Color.red(colour), Color.green(colour), Color.blue(colour))
        for (i in 0 until minOf(5, petals)) {
            val a = i * (2f * Math.PI.toFloat() / petals) + seed
            c.drawLine(x, y, x + cos(a) * r * 1.28f, y + sin(a) * r * 1.28f, p)
        }
        p.style = Paint.Style.FILL
        p.color = Color.argb(245, 255, 249, 220)
        c.drawCircle(x, y, r * .16f, p)
        p.color = Color.argb(210, Color.red(colour), Color.green(colour), Color.blue(colour))
        c.drawCircle(x, y, r * .075f, p)
    }

    private fun pandoraPerson(c: Canvas, x: Float, groundY: Float, r: Float, glowColour: Int, scale: Float) {
        val headY = groundY - r * 2.95f * scale
        glow(c, x, headY, r * 1.75f, glowColour, 34)
        val silhouette = Color.argb(225, 25, 36, 74)
        p.style = Paint.Style.FILL
        p.color = silhouette
        c.drawCircle(x, headY, r * .43f, p)
        val torso = Path().apply {
            moveTo(x - r * .48f, headY + r * .35f)
            cubicTo(x - r * .58f, headY + r * 1.05f, x - r * .42f, headY + r * 2.10f, x, headY + r * 2.45f)
            cubicTo(x + r * .42f, headY + r * 2.10f, x + r * .58f, headY + r * 1.05f, x + r * .48f, headY + r * .35f)
            close()
        }
        c.drawPath(torso, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * .18f
        p.color = Color.argb(205, Color.red(glowColour), Color.green(glowColour), Color.blue(glowColour))
        c.drawLine(x - r * .26f, headY + r * .92f, x - r * .82f, groundY - r * .55f, p)
        c.drawLine(x + r * .25f, headY + r * .94f, x + r * .92f, groundY - r * .70f, p)
        c.drawLine(x - r * .15f, groundY - r * .20f, x - r * .50f, groundY + r * .62f, p)
        c.drawLine(x + r * .15f, groundY - r * .20f, x + r * .53f, groundY + r * .62f, p)
        p.strokeWidth = r * .06f
        p.color = Color.argb(135, 104, 230, 255)
        c.drawLine(x - r * .18f, headY + r * .48f, x + r * .18f, headY + r * .48f, p)
        p.style = Paint.Style.FILL
    }

    private fun pandoraFlyingCreature(c: Canvas, x: Float, y: Float, r: Float) {
        val wingGlow = Color.rgb(92, 220, 255)
        val body = Color.argb(175, 31, 52, 91)
        glow(c, x, y, r * 2.2f, wingGlow, 34)
        p.style = Paint.Style.FILL
        p.color = body
        c.drawOval(x - r * .52f, y - r * .18f, x + r * .58f, y + r * .18f, p)
        c.drawCircle(x + r * .42f, y - r * .02f, r * .13f, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * .10f
        p.color = Color.argb(180, Color.red(wingGlow), Color.green(wingGlow), Color.blue(wingGlow))
        for (side in floatArrayOf(-1f, 1f)) {
            val upper = Path().apply {
                moveTo(x + side * r * .08f, y)
                cubicTo(x + side * r * .72f, y - r * .88f, x + side * r * 1.45f, y - r * .72f, x + side * r * 1.82f, y - r * .10f)
                cubicTo(x + side * r * 1.25f, y - r * .18f, x + side * r * .66f, y + r * .02f, x + side * r * .22f, y + r * .12f)
                close()
            }
            c.drawPath(upper, p)
            val lower = Path().apply {
                moveTo(x + side * r * .10f, y + r * .04f)
                cubicTo(x + side * r * .70f, y + r * .42f, x + side * r * 1.25f, y + r * .34f, x + side * r * 1.52f, y + r * .12f)
            }
            c.drawPath(lower, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun mountainRange(c: Canvas, w: Float, h: Float, base: Float, color: Int, heightFrac: Float, seed: Int) {
        val peaks = 9
        val pts = ArrayList<Pair<Float, Float>>(peaks + 1)
        for (i in 0..peaks) {
            val x = w * i / peaks.toFloat()
            val shape = when ((i + seed) % 4) {
                0 -> 1.18f
                1 -> .78f
                2 -> 1.00f
                else -> .62f
            }
            val y = h * (base - heightFrac * shape - ((i * 11 + seed * 7) % 5) * .012f)
            pts += x to y
        }
        val path = Path().apply {
            moveTo(0f, h)
            lineTo(0f, pts.first().second)
            for (i in 1 until pts.size) {
                val prev = pts[i - 1]
                val cur = pts[i]
                val midX = (prev.first + cur.first) * .5f
                quadTo(midX, prev.second, cur.first, cur.second)
            }
            lineTo(w, h)
            close()
        }
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = color
        c.drawPath(path, p)
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int, alpha: Int) {
        if (r <= 0f || alpha <= 0) return
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            x - r * .25f, y - r * .30f, r,
            Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color)),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, p)
        p.shader = null
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        this.visible = visible
        if (!visible) {
            unscheduleSelf(animationRunnable)
        } else if (changed || restart) {
            invalidateSelf()
        }
        return changed
    }

    override fun setAlpha(a:Int){p.alpha=a}
    override fun setColorFilter(f:ColorFilter?){p.colorFilter=f}
    override fun getOpacity()=PixelFormat.TRANSLUCENT
}
