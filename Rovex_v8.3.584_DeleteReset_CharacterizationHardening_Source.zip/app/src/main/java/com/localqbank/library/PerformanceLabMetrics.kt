package com.localqbank.library

/**
 * Pure current-state metrics used by Performance Lab's control panel.
 * The same ProgressSnapshot that drives Home/QBank status is the source of truth here.
 */
data class PerformanceLabCurrentMetrics(
    val attempted: Int,
    val correct: Int,
    val wrong: Int,
    val unsolved: Int,
    val due: Int
)

data class PerformanceLabPeriodMetrics(
    val attempted: Int,
    val correct: Int,
    val wrong: Int,
    val todaySolved: Int,
    val usedHistory: Boolean
)

object PerformanceLabMetrics {
    fun current(refs: List<QuestionRef>, progress: ProgressSnapshot, now: Long): PerformanceLabCurrentMetrics {
        var attempted = 0
        var correct = 0
        var wrong = 0
        var due = 0
        refs.forEach { ref ->
            val r = progress.record(ref.stableKey)
            if (r?.status != null) {
                attempted++
                if (r.status == "correct") correct++
                if (r.status == "wrong") wrong++
                if ((r.nextDue > 0L && now >= r.nextDue) ||
                    (r.nextDue == 0L && r.lastAttempted > 0L && now - r.lastAttempted >= when (r.attempts) {
                        1 -> 86_400_000L
                        2 -> 3 * 86_400_000L
                        3 -> 7 * 86_400_000L
                        4 -> 14 * 86_400_000L
                        else -> 30 * 86_400_000L
                    })) due++
            }
        }
        return PerformanceLabCurrentMetrics(
            attempted = attempted,
            correct = correct,
            wrong = wrong,
            unsolved = (refs.size - attempted).coerceAtLeast(0),
            due = due
        )
    }
    /**
     * Computes period accuracy from the durable attempt ledger when it is available, but never
     * allows an empty/broken ledger to mask answers that are already present in the authoritative
     * progress snapshot. Daily metrics intentionally use current progress because it is the same
     * state shown by the QBank control panel.
     */
    fun period(
        refs: List<QuestionRef>,
        progress: ProgressSnapshot,
        history: List<QBankDb.StudyAttemptHistoryRow>,
        since: Long,
        todaySince: Long,
        daily: Boolean
    ): PerformanceLabPeriodMetrics {
        val current = refs.mapNotNull { ref ->
            val record = progress.record(ref.stableKey) ?: return@mapNotNull null
            if (record.status.isNullOrBlank() || record.lastAttempted < since) null else record
        }
        if (daily || history.isEmpty()) {
            val attempted = current.size
            val correct = current.count { it.status == "correct" }
            val wrong = current.count { it.status == "wrong" }
            return PerformanceLabPeriodMetrics(
                attempted = attempted,
                correct = correct,
                wrong = wrong,
                todaySolved = current.count { it.lastAttempted >= todaySince },
                usedHistory = false
            )
        }
        return PerformanceLabPeriodMetrics(
            attempted = history.size,
            correct = history.count { it.correct },
            wrong = history.count { !it.correct },
            todaySolved = history.count { it.attemptedAt >= todaySince },
            usedHistory = true
        )
    }

}
