package com.localqbank.library

import android.content.Context

/**
 * Import persistence seam. HtmlImportActivity must not own QBankDb directly.
 * The importer coordinator owns scheduling; this class owns one operation's DB handle.
 */
class HtmlImportRepository(context: Context) : AutoCloseable {
    private val db = QBankDb(context.applicationContext)

    /**
     * Explicit five-argument progress overload. A trailing lambda on this overload is
     * unambiguously the question-import progress callback, not replacement-deletion progress.
     */
    fun importBundle(
        importKey: String,
        displayName: String,
        provider: String,
        tests: List<ImportedTest>,
        onProgress: (done: Int, total: Int) -> Unit
    ): Int = db.importBundle(
        importKey = importKey,
        displayName = displayName,
        provider = provider,
        tests = tests,
        onProgress = onProgress,
        onReplacementProgress = null
    )

    fun importBundle(
        importKey: String,
        displayName: String,
        provider: String,
        tests: List<ImportedTest>,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
        onReplacementProgress: ((deleted: Int, total: Int) -> Unit)? = null
    ): Int = db.importBundle(
        importKey = importKey,
        displayName = displayName,
        provider = provider,
        tests = tests,
        onProgress = onProgress,
        onReplacementProgress = onReplacementProgress
    )

    /** Legacy compatibility overload; production HTML imports use document identity. */
    fun importBundle(
        fileName: String,
        provider: String,
        tests: List<ImportedTest>,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): Int = db.importBundle(
        importKey = fileName,
        displayName = fileName,
        provider = provider,
        tests = tests,
        onProgress = onProgress
    )

    fun beginStreamingImport(
        importKey: String,
        displayName: String,
        provider: String,
        onReplacementProgress: ((deleted: Int, total: Int) -> Unit)? = null
    ) = db.beginStreamingImport(importKey, displayName, provider, onReplacementProgress)

    override fun close() = db.close()
}
