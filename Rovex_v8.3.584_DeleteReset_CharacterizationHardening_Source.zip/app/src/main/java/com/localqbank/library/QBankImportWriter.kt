package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import java.security.MessageDigest

/**
 * Transactional normalized-QBank import writer. It owns only row insertion and bounded
 * transaction mechanics; QBankDb remains the authoritative owner of source lifecycle,
 * search-index policy, and deletion/recovery.
 */
internal class QBankImportWriter(
    private val db: SQLiteDatabase,
    private val deleteSource: (Long) -> Boolean,
    private val markSearchIndexDirty: () -> Unit,
    private val finalizeSearchIndex: () -> Unit
) {
    fun import(importKey:String, displayName:String, provider:String, tests:List<ImportedTest>, onProgress:(done:Int,total:Int)->Unit):Int {
        val totalQuestions = tests.sumOf { it.questions.size }
        if (totalQuestions <= 0) return 0
        val batchLimit = if (totalQuestions <= 500) totalQuestions else 250
        var sourceId = 0L
        var transactionOpen = false
        var batchCount = 0
        val sourceStatement=db.compileStatement("INSERT INTO source(file_name,display_name,series_number,provider,imported_at) VALUES(?,?,?,?,?)")
        val testStatement=db.compileStatement("INSERT INTO test(id,source_id,title,path,num_questions,total_marks,duration_seconds,time_per_question,original_id,series_number) VALUES(?,?,?,?,?,?,?,?,?,?)")
        val questionStatement=db.compileStatement("INSERT INTO question(test_id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio) VALUES(?,?,?,?,?,?,?,?,?,?)")
        val optionStatement=db.compileStatement("INSERT INTO option_item(question_id,position,label,text,is_correct) VALUES(?,?,?,?,?)")
        val imageStatement=db.compileStatement("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)")
        val ftsStatement:android.database.sqlite.SQLiteStatement?=try {
            db.compileStatement("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)")
        } catch(e:Exception) {
            android.util.Log.w("QBankDb", "FTS statement unavailable during import: ${e.message}")
            ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.fts_statement_unavailable")
            null
        }
        fun beginBatch() { if(!transactionOpen){ db.beginTransactionNonExclusive(); transactionOpen=true; batchCount=0 } }
        fun finishBatch(success:Boolean) {
            if(!transactionOpen)return
            if(success)db.setTransactionSuccessful()
            db.endTransaction(); transactionOpen=false; batchCount=0
        }
        try {
            beginBatch()
            sourceStatement.bindString(1,importKey); sourceStatement.bindString(2,displayName); sourceStatement.bindString(3,"")
            sourceStatement.bindString(4,provider); sourceStatement.bindLong(5,System.currentTimeMillis())
            sourceId=sourceStatement.executeInsert(); check(sourceId>0L){"Unable to create import source"}; sourceStatement.clearBindings()
            var count=0
            for((ti,t) in tests.withIndex()) {
                val testId=makeId(importKey,t.originalId ?: t.title,ti)
                testStatement.bindString(1,testId); testStatement.bindLong(2,sourceId); testStatement.bindString(3,t.title)
                bindNullable(testStatement,4,t.path); testStatement.bindLong(5,t.questions.size.toLong()); testStatement.bindDouble(6,t.totalMarks)
                testStatement.bindLong(7,t.duration.toLong()); testStatement.bindDouble(8,t.timePerQuestion); bindNullable(testStatement,9,t.originalId)
                testStatement.bindString(10,t.seriesNumber ?: ""); testStatement.executeInsert(); testStatement.clearBindings()
                for((qi,q) in t.questions.withIndex()) {
                    questionStatement.bindString(1,testId); questionStatement.bindLong(2,qi.toLong()); bindNullable(questionStatement,3,q.sourceId)
                    bindNullable(questionStatement,4,q.text); bindNullable(questionStatement,5,q.rawText); bindNullable(questionStatement,6,q.correctAnswer)
                    bindNullable(questionStatement,7,q.explanation); bindNullable(questionStatement,8,q.bot); bindNullable(questionStatement,9,q.video); bindNullable(questionStatement,10,q.audio)
                    val qid=questionStatement.executeInsert(); questionStatement.clearBindings()
                    q.options.forEachIndexed{oi,o-> optionStatement.bindLong(1,qid); optionStatement.bindLong(2,oi.toLong()); bindNullable(optionStatement,3,o.label); bindNullable(optionStatement,4,o.text); optionStatement.bindLong(5,if(o.correct)1L else 0L); optionStatement.executeInsert(); optionStatement.clearBindings() }
                    q.questionImages.forEachIndexed{ii,u-> imageStatement.bindLong(1,qid); imageStatement.bindString(2,"question"); imageStatement.bindLong(3,ii.toLong()); imageStatement.bindString(4,u); imageStatement.executeInsert(); imageStatement.clearBindings() }
                    q.explanationImages.forEachIndexed{ii,u-> imageStatement.bindLong(1,qid); imageStatement.bindString(2,"explanation"); imageStatement.bindLong(3,ii.toLong()); imageStatement.bindString(4,u); imageStatement.executeInsert(); imageStatement.clearBindings() }
                    ftsStatement?.let { st ->
                        try { st.bindLong(1,qid); st.bindString(2,testId); st.bindLong(3,sourceId); st.bindString(4,q.text+" "+(q.rawText ?: "")+" "+(q.correctAnswer ?: "")+" "+(q.explanation ?: "")+" "+(q.bot ?: "")+" "+(q.video ?: "")+" "+(q.audio ?: "")+" "+t.title+" "+q.options.joinToString(" "){it.label+" "+it.text}); st.executeInsert() }
                        catch(e:Exception){ Log.w("QBankDb","FTS row skipped during import: ${e.message}"); ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context,"QBankDb.import_fts_row_skipped") }
                        finally { st.clearBindings() }
                    }
                    count++; batchCount++
                    // Progress is part of the import contract: emit the first row, each 25-row
                    // checkpoint, every bounded transaction/batch boundary, and the terminal row
                    // synchronously on the writer thread. Batch-boundary emission is intentional:
                    // it makes durable writer checkpoints externally observable without replacing
                    // the finer-grained progress cadence. Keep the call adjacent to the authoritative
                    // count increment so a successful import cannot return with an unreported
                    // completion boundary.
                    if (count == 1 || count % 25 == 0 || count % batchLimit == 0 || count == totalQuestions) {
                        onProgress(count, totalQuestions)
                    }
                    if(batchCount>=batchLimit && count<totalQuestions){ finishBatch(true); beginBatch() }
                }
            }
            finishBatch(true)
            // The normalized import is already durably committed at this point. Index finalization
            // is a repairable secondary step and must never turn a successful import into a
            // destructive rollback. If finalization fails, preserve the source and leave the
            // authoritative normalized tables available to the deterministic search fallback.
            runCatching { finalizeSearchIndex() }.onFailure { indexError ->
                Log.e("QBankDb", "Search-index finalization failed after committed import; preserving source", indexError)
                markSearchIndexDirty()
                ProductionCrashReporter.recordNonFatal(indexError, "QBANK_IMPORT_INDEX_FINALIZE")
            }
            return count
        } catch(t:Exception) {
            runCatching{finishBatch(false)}
            if(sourceId>0L) runCatching{deleteSource(sourceId)}.onFailure{cleanupError->Log.e("QBankDb","Failed to clean partial import source=$sourceId",cleanupError);ProductionCrashReporter.recordNonFatal(cleanupError,"QBANK_IMPORT_PARTIAL_CLEANUP")}
            markSearchIndexDirty()
            throw t
        } finally {
            runCatching{finishBatch(false)}
            sourceStatement.close(); testStatement.close(); questionStatement.close(); optionStatement.close(); imageStatement.close(); ftsStatement?.close()
        }
    }
    private fun bindNullable(st:android.database.sqlite.SQLiteStatement,i:Int,v:String?){if(v==null)st.bindNull(i) else st.bindString(i,v)}
    private fun makeId(file:String,original:String,index:Int):String{val raw="$file|$original|$index";return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).joinToString(""){String.format("%02x",it)}.take(24)}
}
