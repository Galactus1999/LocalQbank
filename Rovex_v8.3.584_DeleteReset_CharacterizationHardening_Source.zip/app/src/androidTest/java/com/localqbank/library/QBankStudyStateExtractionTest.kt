package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Exercises the extracted study-state component through the real QBankDb compatibility facade. */
@RunWith(AndroidJUnit4::class)
class QBankStudyStateExtractionTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()

    @After
    fun tearDown() {
        QBankDb.resetDatabaseForTest(context)
    }

    @Test
    fun extractedStoredProgressRoundTripsThroughProductionFacade() {
        val db = QBankDb(context)
        val expected = QBankDb.StoredProgress(
            selected = "B", status = "wrong", bookmark = "revise", review = true,
            attempts = 3, lastAttempted = 1234L, timeMs = 900L, mistake = "concept",
            easeFactor = 2.15f, repetitions = 2, intervalDays = 3.0f, nextDue = 9999L
        )
        db.writeStoredProgress("test-1:1:stable", expected)
        val actual = db.readStoredProgress("test-1:1:stable")
        assertNotNull(actual)
        assertEquals(expected, actual)
        assertEquals(1, db.allStoredProgress().size)
    }

    @Test
    fun extractedProgressMetaAndAttemptHistoryRemainDurable() {
        val db = QBankDb(context)
        db.putProgressMeta("test-1:position", "7")
        assertEquals("7", db.getProgressMeta("test-1:position"))

        db.recordStudyAttempt("test-1:7:stable", "test-1", 0L, 2000L, true)
        val rows = db.studyAttemptHistory(setOf("test-1:7:stable"), 0L)
        assertEquals(1, rows.size)
        assertEquals("test-1:7:stable", rows.single().stableKey)
        assertTrue(rows.single().correct)
    }
}
