package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Proves deleting one source cannot remove or hide another source's authoritative questions. */
@RunWith(AndroidJUnit4::class)
class QBankDeletionIsolationTest {

    @After fun closeRawDatabase() { runCatching { raw.close() } }
    private lateinit var db: QBankDb
    private lateinit var raw: android.database.sqlite.SQLiteDatabase

    @Before fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
        // Initialize the authoritative provider schema before opening the test-only raw handle.
        db.sources()
        raw = context.openOrCreateDatabase("qbank.db", 0, null)
        raw.execSQL("DELETE FROM question_fts")
        raw.execSQL("DELETE FROM question")
        raw.execSQL("DELETE FROM test")
        raw.execSQL("DELETE FROM source")
        raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(1,'delete.me','Delete Me','test',1)")
        raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(2,'keep.me','Keep Me','test',2)")
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('delete-test',1,'Delete Test','delete',1)")
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('keep-test',2,'Keep Test','keep',1)")
        raw.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(1,'delete-test',0,'d1','delete-only-token','delete-only-token')")
        raw.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(2,'keep-test',0,'k1','keep-only-token','keep-only-token')")
        raw.execSQL("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(1,'delete-test',1,'delete-only-token')")
        raw.execSQL("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(2,'keep-test',2,'keep-only-token')")
        raw.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")
        raw.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending','0')")
    }

    @Test
    fun tombstonedSourceCannotLeakThroughReadSideApisOrNotesUi() {
        raw.execSQL("INSERT INTO question_note(question_id,note,updated_at) VALUES(1,'deleted-note',123)")
        raw.execSQL("INSERT INTO question_note(question_id,note,updated_at) VALUES(2,'live-note',124)")

        assertTrue(db.requestSourceDeletion(1L))

        // The tombstone must be authoritative across read APIs, not only sources()/search().
        assertNull(db.testById("delete-test"))
        assertEquals("Unlinked" to "Question 1", db.questionContext(1L))
        assertEquals(0, db.sourceQuestionCount(1L))
        assertEquals(0, db.progressSummaryForSource(1L, ProgressStore(ApplicationProvider.getApplicationContext())).total)
        assertTrue(db.noteRecords().none { it.questionId == 1L })
        assertEquals(1, db.noteRecords().count { it.questionId == 2L })

        // The unrelated source remains fully readable.
        assertNotNull(db.testById("keep-test"))
        assertEquals(1, db.sourceQuestionCount(2L))
    }

    @Test
    fun deleteRequestHidesImmediatelyBeforePhysicalCleanup() {
        assertTrue(db.requestSourceDeletion(1L))

        // The user-visible catalog changes at the tombstone boundary, not after all questions
        // have been physically deleted. This is the critical responsiveness contract.
        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertEquals(listOf(1L), db.pendingDeletingSourceIds())

        // Physical data is still present at this point and is therefore available to the
        // resumable worker after process death. It must not be mistaken for a failed delete.
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM question WHERE test_id='delete-test'", null).use { it.moveToFirst(); it.getInt(0) })
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM question WHERE test_id='keep-test'", null).use { it.moveToFirst(); it.getInt(0) })

        assertTrue(db.deleteSource(1L, repairSearchIndex = false))
        assertTrue(db.pendingDeletingSourceIds().isEmpty())
        assertEquals(0, db.questionCount("delete-test"))
        assertEquals(1, db.questionCount("keep-test"))
    }

    @Test fun deletingOneQBankPreservesAnotherAndSearchRemainsLive() {
        assertTrue(db.deleteSource(1L, repairSearchIndex = false))

        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertEquals(0, db.questionCount("delete-test"))
        assertEquals(1, db.questionCount("keep-test"))
        assertEquals(1, db.questions("keep-test").size)

        // Physical FTS garbage is intentionally tolerated until idle maintenance. Logical search
        // must still return live questions and must never return the deleted source.
        val keep = db.search("keep-only-token")
        val deleted = db.search("delete-only-token")
        assertFalse(keep.isEmpty())
        assertEquals(2L, keep.single().id)
        assertTrue(deleted.isEmpty())

        val dirty = raw.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='dirty'", null).use { it.moveToFirst(); it.getString(0) }
        val garbage = raw.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='garbage_pending'", null).use { it.moveToFirst(); it.getString(0) }
        assertEquals("0", dirty)
        assertEquals("1", garbage)
    }

    @Test fun boundedQuestionReferenceLookupNeverRequiresWholeCorpus() {
        val refs = db.questionRefsForIdsBounded(longArrayOf(2L))
        assertEquals(1, refs.size)
        assertEquals(2L, refs.single().id)
        assertEquals("Keep Test", refs.single().testTitle)
    }

    @Test fun deletionTombstoneIsVisibleToRecoveryUntilSourceIsFullyRemoved() {
        raw.execSQL("UPDATE source SET deleting=1 WHERE id=1")
        val tombstoned = raw.rawQuery("SELECT id FROM source WHERE deleting=1 ORDER BY id", null).use { c ->
            buildList { while (c.moveToNext()) add(c.getLong(0)) }
        }
        assertEquals(listOf(1L), tombstoned)
        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
    }

    @Test fun crashRecoveryOnlyResumesExplicitDeletionAndRestoresLegacyHiddenData() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db.importBundle("legacy-hidden", "legacy.html", "HTML", listOf(
            ImportedTest(
                originalId = "legacy", title = "Legacy", path = null, totalMarks = 1.0, duration = 0, timePerQuestion = 0.0,
                questions = listOf(ImportedQuestion("legacy-q", "legacy-only-token", null, "A", null, null, null, null,
                    listOf(ImportedOption("A", "answer", true)), emptyList(), emptyList()))
            )
        ))
        val legacySource = db.sources().single { it.fileName == "legacy.html" }.id
        db.importBundle("explicit-delete", "same.html", "HTML", listOf(
            ImportedTest(
                originalId = "explicit", title = "Explicit", path = null, totalMarks = 1.0, duration = 0, timePerQuestion = 0.0,
                questions = listOf(ImportedQuestion("explicit-q", "explicit-only-token", null, "A", null, null, null, null,
                    listOf(ImportedOption("A", "answer", true)), emptyList(), emptyList()))
            )
        ))
        val explicitSource = db.sources().single { it.fileName == "same.html" }.id
        assertTrue(legacySource > 0)
        assertTrue(explicitSource > 0)
        assertTrue(legacySource != explicitSource)

        // Use the resolved source IDs rather than the stable import keys. importBundle() stores
        // those keys through safeImportKey(), so raw file_name equality would silently update zero rows.
        raw.execSQL(
            "UPDATE source SET deleting=1,delete_requested=0 WHERE id=?",
            arrayOf(legacySource.toString())
        )
        raw.execSQL(
            "UPDATE source SET deleting=1,delete_requested=1 WHERE id=?",
            arrayOf(explicitSource.toString())
        )
        assertEquals(
            2,
            raw.rawQuery("SELECT COUNT(*) FROM source WHERE deleting=1", null).use { c ->
                c.moveToFirst()
                c.getInt(0)
            }
        )

        db.restoreLegacyTombstonedSources()
        assertNotNull(db.sourceById(legacySource.toLong()))
        assertEquals(listOf(explicitSource.toLong()), db.pendingDeletingSourceIds())
        assertEquals(1, db.search("legacy-only-token").size)

        // Simulate the durable recovery boundary after process death: only the explicit delete
        // intent may be destructively resumed. The legacy hidden source must remain intact.
        db.pendingDeletingSourceIds().forEach { id -> db.deleteSource(id, repairSearchIndex = false) }

        // The fixture intentionally seeds two unrelated sources (IDs 1 and 2). They are not part
        // of either simulated deletion and therefore must survive the recovery/cleanup boundary.
        assertEquals(3, db.sources().size)
        assertNotNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertNotNull(db.sourceById(legacySource.toLong()))
        assertEquals(1, db.search("legacy-only-token").size)
        assertTrue(db.search("explicit-only-token").isEmpty())
    }

    @Test
    fun deleteClearsOnlyDeletedSourcesGlobalResumeAndSolvedCursors() {
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_resume_global','delete-test|0|1|3000')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_solved_global','delete-test|0|1|3000')")

        assertTrue(db.deleteSource(1L, repairSearchIndex = false))

        assertEquals("", db.getProgressMeta("last_resume_global"))
        assertEquals("", db.getProgressMeta("last_solved_global"))
    }


    @Test
    fun repeatedDeleteIsIdempotentAndCannotAffectAnotherSource() {
        assertTrue(db.deleteSource(1L, repairSearchIndex = false))
        assertTrue(db.deleteSource(1L, repairSearchIndex = false))

        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertEquals(0, db.questionCount("delete-test"))
        assertEquals(1, db.questionCount("keep-test"))
        assertEquals(1, db.search("keep-only-token").size)
    }

    @Test
    fun deleteThenReimportSameIdentityDoesNotResurrectOldContent() {
        assertTrue(db.deleteSource(1L, repairSearchIndex = false))

        val imported = db.importBundle(
            "delete-reimport",
            "delete.me",
            "TEST",
            listOf(
                ImportedTest(
                    originalId = "replacement",
                    title = "Replacement",
                    path = null,
                    totalMarks = 1.0,
                    duration = 0,
                    timePerQuestion = 0.0,
                    questions = listOf(
                        ImportedQuestion(
                            sourceId = "replacement-q",
                            text = "replacement-only-token",
                            rawText = null,
                            correctAnswer = "A",
                            explanation = null,
                            bot = null,
                            video = null,
                            audio = null,
                            options = listOf(ImportedOption("A", "answer", true)),
                            questionImages = emptyList(),
                            explanationImages = emptyList()
                        )
                    )
                )
            )
        )

        assertEquals(1, imported)
        assertEquals(0, db.search("delete-only-token").size)
        assertEquals(1, db.search("replacement-only-token").size)
        assertEquals(1, db.search("keep-only-token").size)
    }

    @Test
    fun deletePreservesUnrelatedGlobalResumeAndSolvedCursors() {
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('other-test',2,'Other Test','keep',1)")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_resume_global','other-test|0|1|4000')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_solved_global','other-test|0|1|4000')")

        assertTrue(db.deleteSource(1L, repairSearchIndex = false))

        assertEquals("other-test|0|1|4000", db.getProgressMeta("last_resume_global"))
        assertEquals("other-test|0|1|4000", db.getProgressMeta("last_solved_global"))
        assertNotNull(db.sourceById(2L))
    }

    @Test
    fun foregroundInterruptionBetweenQuestionBatchesLeavesDurableRecoveryBoundary() {
        // Seed more than one bounded batch so the interruption occurs after real destructive work.
        raw.execSQL("DELETE FROM question")
        raw.execSQL("DELETE FROM option_item")
        raw.execSQL("DELETE FROM question_image")
        raw.execSQL("DELETE FROM question_note")
        raw.execSQL("DELETE FROM question_note_image")
        raw.execSQL("DELETE FROM test")
        // Rebuild both source fixtures after clearing the question/test rows above. The keep-side
        // question is intentionally preserved so the assertion below proves unrelated data remains.
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('delete-test',1,'Delete Test','delete',101)")
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('keep-test',2,'Keep Test','keep',1)")
        for (i in 1..101) {
            raw.execSQL(
                "INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(?,?,?,?,?,?)",
                arrayOf(i.toString(), "delete-test", (i - 1).toString(), "d$i", "delete-$i", "delete-$i")
            )
        }
        raw.execSQL(
            "INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(?,?,?,?,?,?)",
            arrayOf("1000", "keep-test", "0", "keep-1", "keep-1", "keep-1")
        )
        var pauseCalls = 0
        val completed = db.deleteSource(
            1L,
            repairSearchIndex = false,
            maxQuestionBatches = 8,
            shouldPause = { ++pauseCalls >= 2 }
        )

        assertFalse(completed)
        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertEquals(51, raw.rawQuery("SELECT COUNT(*) FROM question WHERE test_id=?", arrayOf("delete-test")).use { it.moveToFirst(); it.getInt(0) })
        assertEquals(1, db.questionCount("keep-test"))
        assertEquals(listOf(1L), db.pendingDeletingSourceIds())

        // A later maintenance pass must resume the same tombstoned source and finish it safely.
        assertTrue(db.deleteSource(1L, repairSearchIndex = false))
        assertEquals(0, db.questionCount("delete-test"))
        assertNotNull(db.sourceById(2L))
        assertTrue(db.pendingDeletingSourceIds().isEmpty())
    }

    @Test
    fun requestDeletionPersistsRecoveryAdmissionMarker() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("qbank_recovery_state", Context.MODE_PRIVATE).edit().clear().commit()

        assertTrue(db.requestSourceDeletion(1L))
        assertTrue(QBankDeletionRecoveryWorker.isRecoveryNeeded(context))
    }

    @Test
    fun pausedDeleteLeavesSafeTombstoneUntilMaintenanceCanResume() {
        assertFalse(db.deleteSource(1L, repairSearchIndex = false, maxQuestionBatches = 1, shouldPause = { true }))

        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertEquals(listOf(1L), db.pendingDeletingSourceIds())
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM question WHERE test_id='delete-test'", null).use { it.moveToFirst(); it.getInt(0) })
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM question WHERE test_id='keep-test'", null).use { it.moveToFirst(); it.getInt(0) })
        assertTrue(db.search("delete-only-token").isEmpty())
        assertEquals(1, db.search("keep-only-token").size)
    }

}
