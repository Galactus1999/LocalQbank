package com.localqbank.library

import android.content.Context
import android.content.ContextWrapper
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.TimeUnit

/**
 * Locks the WorkManager admission boundary for resumable QBank deletion.
 * These tests verify the request shape and one-time migration behavior; actual DeviceIdle
 * execution remains a physical-device validation item.
 */
@RunWith(AndroidJUnit4::class)
class QBankDeletionRecoveryAdmissionTest {
    private lateinit var context: Context
    private lateinit var workManager: WorkManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        workManager = WorkManager.getInstance(context)
        workManager.cancelUniqueWork(UNIQUE)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()
    }

    @After
    fun tearDown() {
        workManager.cancelUniqueWork(UNIQUE)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()
    }

    @Test
    fun admissionAlwaysUsesDeviceIdleConstraint() {
        QBankDeletionRecoveryWorker.markRecoveryNeeded(context)
        QBankDeletionRecoveryWorker.enqueueIfNeeded(context)

        val info = workManager.getWorkInfosForUniqueWork(UNIQUE).get().single()
        assertTrue(info.state == WorkInfo.State.ENQUEUED || info.state == WorkInfo.State.RUNNING)
        assertTrue(info.constraints.requiresDeviceIdle())
    }

    @Test
    fun idleAdmissionDoesNotUseIncompatibleBackoffCriteria() {
        QBankDeletionRecoveryWorker.markRecoveryNeeded(context)
        QBankDeletionRecoveryWorker.enqueueIfNeeded(context)
        val info = workManager.getWorkInfosForUniqueWork(UNIQUE).get().single()
        assertTrue(info.constraints.requiresDeviceIdle())
        // The production admission call itself is the regression boundary: AndroidX throws
        // IllegalArgumentException while building an idle request if backoff is configured.
    }

    @Test
    fun oldUnconstrainedAdmissionIsMigratedExactlyOnce() {
        val oldRequest = OneTimeWorkRequestBuilder<QBankDeletionRecoveryWorker>()
            .setConstraints(Constraints.Builder().setRequiresCharging(true).build())
            .setInitialDelay(1, TimeUnit.DAYS)
            .build()
        workManager.enqueueUniqueWork(UNIQUE, ExistingWorkPolicy.REPLACE, oldRequest).result.get()

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_NEEDED, true)
            .putLong(KEY_ADMISSION_VERSION, 0L)
            .commit()

        QBankDeletionRecoveryWorker.enqueueIfNeeded(context)
        val migrated = workManager.getWorkInfosForUniqueWork(UNIQUE).get().single()
        assertTrue(migrated.id != oldRequest.id)
        assertTrue(migrated.constraints.requiresDeviceIdle())

        // A second admission at the current version must use KEEP rather than cancel/recreate.
        QBankDeletionRecoveryWorker.enqueueIfNeeded(context)
        val stable = workManager.getWorkInfosForUniqueWork(UNIQUE).get().single()
        assertEquals(migrated.id, stable.id)
        assertEquals(ADMISSION_VERSION, context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_ADMISSION_VERSION, 0L))
    }

    @Test
    fun recoveryMarkerIsDurableAcrossFreshContextHandle() {
        QBankDeletionRecoveryWorker.markRecoveryNeeded(context)
        val freshHandle = ContextWrapper(context.applicationContext)
        assertNotNull(freshHandle)
        assertTrue(QBankDeletionRecoveryWorker.isRecoveryNeeded(freshHandle))
    }

    companion object {
        private const val UNIQUE = "rovex_qbank_delete_recovery"
        private const val PREFS = "qbank_recovery_state"
        private const val KEY_NEEDED = "recovery_needed"
        private const val KEY_ADMISSION_VERSION = "recovery_admission_version"
        private const val ADMISSION_VERSION = 556L
    }
}
