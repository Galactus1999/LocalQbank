# v8.3.554 — QBankImportWriter CI Regression Repair

## Scope
Repair the two failing instrumented tests reported by the v8.3.553 CI run.

## Root cause
`QBankImportWriterRegressionTest` opened the raw `qbank.db` connection before forcing the authoritative `QBankDatabaseProvider` to initialize the schema. The two affected tests then failed with `SQLiteException: no such table: source`.

## Repair
Both tests now call `db.sources()` before opening their raw SQLite connection. This initializes the production/test database schema through the authoritative provider before the raw test connection is used. No production import/delete/reset logic was changed.

## Verification status
- CI log diagnosis: VERIFIED
- Source repair: STATIC PASS
- JVM test execution: PENDING
- Android-test execution: PENDING
- Device: PENDING

## Non-claims
This batch is not CI-green until the complete workflow executes successfully.
