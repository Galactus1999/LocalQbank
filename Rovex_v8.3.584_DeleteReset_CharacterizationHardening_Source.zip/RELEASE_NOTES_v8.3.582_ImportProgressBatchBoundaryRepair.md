# Rovex v8.3.582 — Import Progress Batch-Boundary Repair

- Root cause: `QBankImportWriter` emitted the first row, 25-row checkpoints, and terminal completion, but omitted the authoritative bounded writer-batch boundaries.
- The existing instrumented contract requires progress at `1`, `250`, `500`, and `501` for a 501-question import.
- Repair: preserve the 25-row cadence and additionally emit at every `batchLimit` boundary.
- No import transaction, database schema, deletion, search, or UI ownership was changed.
- v8.3.581's deletion-test fixture repair is retained unchanged.

- Restored the exact existing import-replacement progress guard contract expected by the offline Phase-0 audit; behavior is unchanged.
