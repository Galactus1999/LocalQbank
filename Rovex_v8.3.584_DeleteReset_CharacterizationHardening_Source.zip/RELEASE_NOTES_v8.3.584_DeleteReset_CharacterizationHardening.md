# Rovex v8.3.584 — Delete/Reset Characterization Hardening

## Purpose
Strengthen the next QBankDb stage without changing business-logic ownership.

## Changes
- Added idempotent repeated-delete regression coverage.
- Added delete-then-reimport identity coverage proving old content cannot resurrect and unrelated content remains searchable.
- Added idempotent progress-reset regression coverage.
- Preserved study attempt history as immutable history during reset.
- Preserved `QBankDb` as the authoritative facade and existing deletion/reset managers as owners.
- No workflow changes.

## Verification policy
Local Gradle execution is not claimed because the current environment cannot reliably resolve the Gradle distribution. CI/device execution is the authoritative gate.
