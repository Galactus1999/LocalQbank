# Rovex v8.3.563 — QBank / Performance Lab / Focus Map Regression Repair

## Version
- versionName: `8.3.563`
- versionCode: `652`
- package: `com.localqbank.library`
- Baseline: v8.3.562
- Reference comparison: v8.3.534

## User-observed regressions repaired

### 1. QBank deletion could leave a stale visible card
Root cause was a race between the QBank library Activity and the cache-epoch invalidation added to the QBank loading layer.

`QBankLoadingEngine` intentionally suppresses callbacks from source reads that began before `invalidate()`. `MainQBankLibraryActivity` kept `sourceLoadInFlight=true` while such a stale callback was discarded. A subsequent `load()` could therefore return immediately, leaving the old QBank card visible and blocking future catalog refreshes.

Repair:
- on accepted deletion, clear the Activity-side in-flight latch;
- remove the deleted source from the local order cache;
- force a fresh catalog read after invalidation;
- preserve the durable tombstone/background cleanup architecture.

The physical deletion manager was not rewritten and the explicit-delete/tombstone contract remains intact.

### 2. Performance Lab accuracy could remain 0%
The existing Performance Lab depended on `study_attempt_history` for weekly/monthly/all-time accuracy and silently fell back to an empty/previous snapshot when history reconciliation failed or was empty. The QBank control panel, however, already had authoritative `progress_v2` state showing answered questions.

Repair:
- added `PerformanceLabMetrics.period()` as a pure period-metric policy;
- Daily uses the current authoritative progress snapshot directly;
- weekly/monthly/all-time use the durable attempt ledger when populated;
- if the ledger is empty/unavailable, period metrics fall back to current progress rather than presenting false 0% accuracy;
- repeated-attempt history remains authoritative when available.

### 3. QBank Focus Map opened the generic QBank section instead of the selected QBank
The focus-map row passed `sourceId` to `RovexSectionDashboardActivity`, which is a generic section shell and did not provide the concrete source navigation expected from a row representing one imported QBank.

Repair:
- focus-map rows now open `TestListActivity` directly with the selected `sourceId` and `sourceName`.

## v8.3.534 comparison

The v8.3.534 reference was compared directly with the current v8.3.562 source.

Important findings:
- `MainActivity` Performance Lab and Focus Map implementation was substantially unchanged between v8.3.534 and v8.3.562; therefore these were not caused by a simple missing v8.3.534 function.
- The QBank library delete UI path was also structurally the same; the actual deletion regression was in the newer cache/in-flight interaction around the post-tombstone catalog refresh.
- QBankDb functions reported missing by a name-only comparison (`escapeLike`, `beginBatch`, `finishBatch`, `markSourceDeleting`, `sourceNameForId`) are intentional extractions into authoritative helper/manager classes, not accidental losses.
- No relevant MainActivity/MainRepository/MainQBankLibraryActivity/QBankLoadingEngine function was found missing relative to v8.3.534.

## Tests added
- `PerformanceLabMetricsTest.periodFallsBackToCurrentProgressWhenAttemptLedgerIsEmpty`
- `PerformanceLabMetricsTest.periodUsesRepeatedAttemptHistoryWhenAvailable`

## Verification status
- Source delimiter audit: PASS.
- TODO/FIXME/NotImplemented marker scan: PASS.
- v8.3.534 relevant-function comparison: PASS; no accidental relevant function loss found.
- CI source identity gates updated for v8.3.563 / versionCode 652.
- Local Android Gradle test/compile: **BLOCKED** because Gradle 9.3.1 is not cached and `downloads.gradle.org` DNS resolution fails in this environment.
- CI: PENDING.
- Instrumented/device validation: PENDING.

Do not treat this source package as BUILD PASS, CI PASS, or DEVICE PASS until those gates actually execute successfully.
