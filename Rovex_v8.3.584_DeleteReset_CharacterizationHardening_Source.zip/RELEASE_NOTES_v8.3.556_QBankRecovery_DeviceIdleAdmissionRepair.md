# Rovex v8.3.556 — QBank Recovery Device-Idle Admission Repair

## Version contract
- versionName: `8.3.556`
- versionCode: `645`
- package: `com.localqbank.library`
- Baseline: v8.3.555

## Scope
QBankDb Stage 3B — focused characterization and repair of `QBankDeletionRecoveryWorker` scheduling/admission.

## Root finding
The recovery worker documentation and architecture described physical deletion recovery as idle-only, but the WorkManager request in v8.3.555 had no `DeviceIdle` constraint. It could therefore be admitted while the device was active (subject to the worker's foreground check), causing repeated foreground `Result.retry()` attempts while an Activity remained visible.

WorkManager supports a `DeviceIdle` constraint, and this project has `minSdk = 26`, so the constraint is available without a compatibility shim.

## Repair
`QBankDeletionRecoveryWorker.enqueueIfNeeded()` now builds the WorkManager request with:

- `Constraints.Builder().setRequiresDeviceIdle(true)`
- existing foreground safety check retained;
- existing bounded deletion pass retained;
- existing generation fencing retained;
- existing durable recovery marker retained;
- existing unique-work `KEEP` semantics retained;
- existing linear retry/backoff retained only for actual worker failure/incomplete recovery.

No QBank deletion SQL was rewritten and no new scheduler/business-logic owner was introduced.

## Never-idle safety characterization
If the device never reaches idle:

1. the recovery worker is not admitted by WorkManager;
2. the explicitly deleted source remains durably tombstoned/hidden;
3. physical question/test/source cleanup may remain incomplete;
4. the recovery marker remains pending;
5. a later idle window can resume the same explicit deletion;
6. unrelated QBanks remain unaffected.

This is intentional: deletion visibility is decided at the tombstone boundary, while destructive physical cleanup is maintenance work.

## Regression scope
Existing v8.3.555 tests remain authoritative for:
- deleted-source global resume/solved cursor cleanup;
- paused deletion safe-half-state;
- unrelated-source preservation;
- deleted-source search invisibility;
- durable explicit-deletion recovery state.

Additional static checks for v8.3.556:
- `DeviceIdle` constraint present on the actual production WorkRequest;
- no second deletion scheduler/business owner;
- foreground admission check retained;
- no UI-thread deletion introduced;
- version incremented monotonically.

## Verification boundary
STATIC REVIEW: PASS
STATIC AUDIT: PENDING final whole-project scan after packaging
UNIT TEST: PENDING
INSTRUMENTED TEST: PENDING
BUILD: PENDING
CI: PENDING
DEVICE: PENDING

Do not represent v8.3.556 as build/CI/device verified until those gates actually execute.
