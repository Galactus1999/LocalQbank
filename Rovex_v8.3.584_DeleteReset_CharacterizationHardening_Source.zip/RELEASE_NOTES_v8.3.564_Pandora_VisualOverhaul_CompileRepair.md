# Rovex v8.3.564 — Pandora Visual Overhaul + v8.3.563 Compile Repair

## Version
- versionName: `8.3.564`
- versionCode: `653`
- package: `com.localqbank.library`

## Repairs

### Pandora
Reworked the Pandora theme into a bioluminescent night environment:
- deep indigo/teal multi-stop atmospheric background;
- cooler violet-toned panels/elevated surfaces;
- brighter cyan/mint accent treatment;
- updated Pandora semantic pastel fills;
- layered cyan/blue/violet/magenta volumetric glows;
- multi-peak mountain ranges;
- path-based tapered tree silhouettes;
- geometric bioluminescent flowers with halos and filaments;
- animated motes/fireflies;
- luminous ground/water reflection;
- retained lightweight procedural rendering and approximately 8 FPS visible animation budget.

Existing `glow`, `moon`, `pandoraPlanet`, `deer`, `pandoraPerson`, and `pandoraFlyingCreature` helpers remain in use.

### v8.3.563 CI compile blocker
The supplied CI log reached real Kotlin compilation and failed only on:
`QBankDb.kt:140:39 — Unresolved reference: sourceNameForId`.

The helper had existed in the v8.3.534 QBankDb implementation but was accidentally omitted while the progress-reset extraction was retained.

Restored the provider-safe `sourceNameForId(sourceId)` helper and kept the extracted `QBankProgressResetter` delegation intact.

## Verification boundary
Static/source verification is performed on the repaired source. Android CI/build/device status must be established by the next CI run and must not be inferred from source inspection.
