# Rovex v8.3.534 — Deep Source / Runtime-Risk Audit

## P0 finding
v8.3.533 claimed to preserve v8.3.532 friend transport but introduced a preflight read of the sender's outgoing document. That violated the write-first/offline-first contract and could prevent a request from being persisted while offline. v8.3.534 restores the exact write-first two-document batch pattern.

## P1 findings
- Presence listeners could read an unbounded connection subcollection as stale installation records accumulated. The listener is now limited to the newest 32 records ordered by `lastChanged`.
- The source artifact still contained a v8.3.532-only GitHub workflow, which asserted versionCode 622/versionName 8.3.532 and was therefore incomplete for the 8.3.533 source. It was replaced with a direct 8.3.534 workflow.
- Obsolete RTDB deployment configuration remained after the app/Functions RTDB implementation had been removed. It is now removed from `firebase.json`.

## Static checks
- PASS: versionCode 624 / versionName 8.3.534
- PASS: 37 XML layouts parsed; no duplicate `@+id` within an individual layout
- PASS: changed-source raw delimiter balance
- PASS: `RovexPresenceState.kt` standalone Kotlin compilation
- PASS: no application Kotlin `FirebaseDatabase`/`presenceAccess` references
- PASS: no friend-send preflight `outgoing.get()`
- PASS: no client-side `friendCodes` read in friend-send path
- PASS: no `targetUid` mailbox query
- PASS: mailbox + outgoing written in one batch
- PASS: presence query bounded to 32 newest connection records
- PASS: workflow version assertions aligned to 8.3.534 / 624

## Not yet verified
- Full Android compilation
- Full JVM test suite
- CI
- Firestore rules deployment
- Device presence behavior
- Two-device friend regression

Do not call v8.3.534 green until those external gates produce evidence.
