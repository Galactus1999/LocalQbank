# Rovex v8.3.574 — LargeHtmlScanner Compile Root Repair

## Root cause
CI run logs_101621252514.zip failed during `:app:compileDebugKotlin`.
The compiler reported `LargeHtmlScanner.kt:90:40 Syntax error: Expecting ')` and `Too many characters in a character literal`, followed by cascading unresolved references (`ch`, `maxQuestionChars`, `seen`) and a top-level declaration error.

The cause was an invalid Kotlin character literal introduced in the JavaScript lexical scanner:
`ch == '\\\\''` (four-character escaped representation in source) was invalid Kotlin.

## Fix
Replaced it with the valid Kotlin single-quote character literal:
`ch == '\''`

No parser logic was removed. The lexical scanner still recognizes double quotes, single quotes, and template literals.

## Additional checks
- No idle WorkManager request combines `setRequiresDeviceIdle(true)` with explicit `setBackoffCriteria(...)` in the audited worker paths.
- Package ID preserved: `com.localqbank.library`.
- Version advanced 8.3.573/660 -> 8.3.574/661.
- Only the current v8.3.574 workflow remains for this repair.

## Verification
- CI failure independently inspected: PASS.
- Root cause located at exact compiler line: PASS.
- Corrected source syntax by inspection: PASS.
- Gradle local compile attempt: BLOCKED because `downloads.gradle.org` DNS is unavailable in this environment.
- CI build/test status for v8.3.574: PENDING.
