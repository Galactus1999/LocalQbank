# Rovex v8.3.563 — Audit Report

## Scope
Compared current v8.3.562 source against the supplied/reference v8.3.534 source and repaired three user-observed regressions:
1. QBank delete leaves stale visible entry.
2. Performance Lab accuracy remains 0%.
3. QBank Focus Map row navigates to the wrong destination.

## Root-cause findings

### Delete
The durable tombstone itself is correct and was preserved. The regression was a UI/cache race:
- `QBankLoadingEngine` uses an epoch fence and intentionally suppresses callbacks from reads started before `invalidate()`.
- `MainQBankLibraryActivity` used `sourceLoadInFlight` as a gate.
- If invalidation happened while a catalog read was in flight, the stale callback could be suppressed without clearing the Activity latch.
- The screen could therefore retain the old list and future `load()` calls could return immediately.

Repair: clear the latch after accepted deletion, remove the ID from the local order cache, and force a fresh source catalog read.

### Performance Lab
The UI used `AnalyticsManager.computeSnapshot()` and depended on `study_attempt_history` for non-daily accuracy. The history reconciliation was wrapped by an all-or-nothing exception boundary, so an empty/unavailable ledger could produce a zero/previous snapshot even while `progress_v2` visibly contained answers.

Repair: pure `PerformanceLabMetrics.period()` policy:
- daily: authoritative current progress;
- weekly/monthly/all-time: attempt ledger when available;
- empty/unavailable ledger: current-progress fallback;
- repeated history remains authoritative when populated.

### Focus Map
The v8.3.534 and v8.3.562 focus-map row route was effectively unchanged and sent the selected source ID to `RovexSectionDashboardActivity`. That route is generic rather than source-specific. The repair sends the concrete source directly to `TestListActivity` with `sourceId` and `sourceName`.

## v8.3.534 function comparison

Name-based comparison found these QBankDb functions absent from the monolithic v8.3.562 facade:
- `escapeLike`
- `beginBatch`
- `finishBatch`
- `markSourceDeleting`
- `sourceNameForId`

These are intentional extractions:
- search escaping/query construction -> `QBankSearchSql` / `QBankSearchQueryBuilder`;
- import batch lifecycle -> `QBankImportWriter`;
- physical deletion helpers -> `QBankSourceDeletionManager`.

No relevant function was accidentally missing from:
- `MainActivity`
- `MainRepository`
- `MainQBankLibraryActivity`
- `QBankLoadingEngine`

## Static verification
- `phase0_offline_gate.py`: PASS
- coroutine cancellation audit: PASS (0 sensitive runCatching / 0 missing obvious boundary)
- architecture audit: PASS with informational large-file warnings
- search/QBank regression audit: PASS
- performance/search architecture audit: PASS
- defect regression audit: PASS
- ruthless static audit: PASS
- XML duplicate-ID audit: PASS
- targeted findViewById/XML type audit: PASS
- TODO/FIXME/NotImplemented marker scan: PASS (0 matches)
- changed-source delimiter balance: PASS
- pure Kotlin performance policy compile/execution smoke: PASS (`PURE_PERFORMANCE_POLICY_PASS`)

## Known pre-existing audit failure
`architecture_regression_audit.py` still reports the same four failures as untouched v8.3.562:
- MainQBankLibraryActivity size
- RovexOnlineActivity size
- TestListActivity direct persistence constructor count
- main source singleton/object declaration count

v8.3.562 independently reproduced the exact same four failures. Therefore these are not introduced by v8.3.563. The MainQBankLibraryActivity line count increased from 393 to 398 solely from the deletion race repair comments/code.

## Build / CI / device
- Local Gradle build/test: BLOCKED — Gradle 9.3.1 distribution unavailable and `downloads.gradle.org` DNS resolution fails.
- CI: PENDING.
- Instrumented tests: PENDING.
- Device validation: PENDING.
- APK/signing/SHA: PENDING until CI produces an APK.

Release decision: **STATIC AUDIT PASS / BUILD BLOCKED / CI PENDING / DEVICE PENDING**.
