package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class SettingsActivity: Activity(){
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private val section by lazy { intent.getStringExtra("section") ?: "all" }

    override fun onCreate(b:Bundle?){
        super.onCreate(b); AppManagers.initialize(applicationContext); SystemUi.immersive(this); val root=build(); setContentView(root); AdaptiveTypographyManager.apply(root)
    }

    private fun build():ScrollView{
        if(section=="all") return buildSettingsMenu()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(28));setBackgroundColor(ThemeManager.bg(this@SettingsActivity))}
        root.addView(TextView(this).apply{text=when(section){"adaptive"->"Adaptive Engine";"appearance"->"Appearance & Themes";"fonts"->"Quiz Typography";else->"Settings"};textSize=27f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity));setPadding(0,0,0,dp(6))})
        root.addView(TextView(this).apply{text="Dedicated ${section.replaceFirstChar{it.uppercase()}} controls";textSize=13f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,0,0,dp(18))})
        if(section=="appearance") addAppearance(root)
        if(section=="fonts") addFonts(root)
        if(section=="adaptive") addAdaptive(root)
        return ScrollView(this).apply{addView(root);isFillViewport=true}
    }

    private fun buildSettingsMenu():ScrollView{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(20),dp(20),dp(28));setBackgroundColor(ThemeManager.bg(this@SettingsActivity))}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val back=TextView(this).apply{text="←";textSize=25f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@SettingsActivity));background=rounded(ThemeManager.elevated(this@SettingsActivity),16);setOnClickListener{finish()}}
        header.addView(back,LinearLayout.LayoutParams(dp(52),dp(52)))
        header.addView(TextView(this).apply{text="Settings";textSize=28f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity));setPadding(dp(14),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        root.addView(header)
        root.addView(TextView(this).apply{text="Tune the study experience, intelligence and data safety.";textSize=14f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(14),0,dp(16))})
        val items=listOf(
            Triple("Theme","Light, Dark, Sepia, AMOLED and Midnight","theme"),
            Triple("Fonts","Quiz typography and reading density","fonts"),
            Triple("Colour flow","Two-colour flow, normal text and greeting panel","colour_flow"),
            Triple("Adaptive Engine","Learning, runtime policy and autonomy","adaptive"),
            Triple("Ben AI Safety","Local-model kill switch and conservative memory guard","ben_ai"),
            Triple("Backup & Restore","Protect progress and restore local backups","backup")
        )
        items.forEach{(title,sub,key)->
            val card=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(14),dp(12),dp(14));background=rounded(ThemeManager.elevated(this@SettingsActivity),18)}
            val copy=LinearLayout(this@SettingsActivity).apply{orientation=LinearLayout.VERTICAL}
            copy.addView(TextView(this@SettingsActivity).apply{text=title;textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
            copy.addView(TextView(this@SettingsActivity).apply{text=sub;textSize=12f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(4),0,0)})
            card.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            card.addView(TextView(this).apply{text="›";textSize=27f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@SettingsActivity))},LinearLayout.LayoutParams(dp(38),dp(42)))
            card.setOnClickListener{when(key){"theme"->showThemeDialog();"fonts"->showFontDialog();"colour_flow"->showColourFlowDialog();"adaptive"->startActivity(Intent(this,SettingsActivity::class.java).putExtra("section","adaptive"));"ben_ai"->showBenAiSafetyDialog();"backup"->startActivity(Intent(this,BackupActivity::class.java))}}
            root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        root.addView(TextView(this).apply{text="Changes are applied locally. Dr. Frankenstein and the adaptive engines cannot modify executable code or your source QBank at runtime.";textSize=11.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(dp(4),dp(18),dp(4),0)})
        return ScrollView(this).apply{addView(root);isFillViewport=true}
    }

    private fun showBenAiSafetyDialog(){
        val policy = BenAiRuntimePolicy(this)
        val dialog=Dialog(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(this@SettingsActivity),24)}
        root.addView(TextView(this).apply{text="Ben AI Safety";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
        root.addView(TextView(this).apply{text="Control any future on-device model before it can consume significant memory or native resources.";textSize=12.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(4),0,dp(14))})
        val enabled=android.widget.Switch(this).apply{text="Allow Ben local model";isChecked=policy.enabled;setTextColor(ThemeManager.text(this@SettingsActivity));setOnCheckedChangeListener{_,checked->policy.setEnabled(checked)}}
        root.addView(enabled)
        val conservative=android.widget.Switch(this).apply{text="Conservative memory guard";isChecked=policy.conservativeMode;setTextColor(ThemeManager.text(this@SettingsActivity));setOnCheckedChangeListener{_,checked->policy.setConservativeMode(checked)}}
        root.addView(conservative)
        root.addView(TextView(this).apply{text="When enabled, future model backends must pass the conservative 1.2 GB model-size gate before loading. Turning off the model switch is a persistent kill switch.";textSize=11.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(8),0,dp(12))})
        root.addView(TextView(this).apply{text="STOP BEN MODEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(10),0,dp(8));setOnClickListener{policy.forceStop();enabled.isChecked=false}})
        root.addView(TextView(this).apply{text="DONE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show()
    }

    private fun showThemeDialog(){
        val keys=arrayOf(ThemeManager.LIGHT,ThemeManager.DARK,ThemeManager.SEPIA,ThemeManager.AMOLED,ThemeManager.MIDNIGHT)
        val labels=arrayOf("Light","Dark","Sepia","AMOLED Black","Midnight Blue")
        val descriptions=arrayOf("Clean daylight reading","Low-glare night reading","Warm textbook paper","True black for OLED","Deep blue, high contrast")
        val dialog=Dialog(this)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(this@SettingsActivity),24)}
        root.addView(TextView(this).apply{text="Theme";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
        root.addView(TextView(this).apply{text="Choose the reading environment that feels right.";textSize=12.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(4),0,dp(12))})
        val current=ThemeManager.get(this)
        keys.forEachIndexed{index,key->
            val selected=current==key
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(10),dp(10));background=rounded(if(selected)ThemeManager.optionBg(this@SettingsActivity) else ThemeManager.elevated(this@SettingsActivity),16)}
            val swatch=TextView(this).apply{text="  ";background=rounded(themeSwatch(key),10);setPadding(dp(5),dp(5),dp(5),dp(5))}
            row.addView(swatch,LinearLayout.LayoutParams(dp(38),dp(38)))
            val copy=LinearLayout(this@SettingsActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(6),0)}
            copy.addView(TextView(this@SettingsActivity).apply{text=labels[index];textSize=15.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
            copy.addView(TextView(this@SettingsActivity).apply{text=descriptions[index];textSize=11.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(2),0,0)})
            row.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply{text=if(selected)"✓" else "";textSize=20f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity))},LinearLayout.LayoutParams(dp(28),dp(38)))
            row.setOnClickListener{ThemeManager.set(this,key);dialog.dismiss();recreate()}
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        root.addView(TextView(this).apply{text="CANCEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root)
        dialog.setOnShowListener{_ -> dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showFontDialog(){
        val keys=arrayOf("sans-serif","serif","sans-serif-condensed","monospace")
        val labels=arrayOf("Modern Sans","Textbook Serif","Compact Sans","Monospace")
        val samples=arrayOf("A  B  C  •  123","Question • Explanation","Rapid revision text","A = B + C")
        val current=getSharedPreferences("ui",MODE_PRIVATE).getString("quiz_font_family","sans-serif") ?: "sans-serif"
        val dialog=Dialog(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(this@SettingsActivity),24)}
        root.addView(TextView(this).apply{text="Fonts";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
        root.addView(TextView(this).apply{text="Preview how question text will feel before applying it.";textSize=12.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(4),0,dp(12))})
        keys.forEachIndexed{index,key->
            val selected=current==key
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(11),dp(12),dp(11));background=rounded(if(selected)ThemeManager.optionBg(this@SettingsActivity) else ThemeManager.elevated(this@SettingsActivity),16)}
            val top=LinearLayout(this@SettingsActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            top.addView(TextView(this@SettingsActivity).apply{text=labels[index];textSize=15.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity));typeface=Typeface.create(key,Typeface.BOLD)},LinearLayout.LayoutParams(0,-2,1f))
            top.addView(TextView(this@SettingsActivity).apply{text=if(selected)"✓" else "";textSize=20f;setTextColor(ThemeManager.accent(this@SettingsActivity));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(30)))
            row.addView(top)
            row.addView(TextView(this@SettingsActivity).apply{text=samples[index];textSize=15f;typeface=Typeface.create(key,Typeface.NORMAL);setTextColor(ThemeManager.text(this@SettingsActivity));setPadding(0,dp(5),0,0)})
            row.setOnClickListener{getSharedPreferences("ui",MODE_PRIVATE).edit().putString("quiz_font_family",key).apply();dialog.dismiss();recreate()}
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        root.addView(TextView(this).apply{text="CANCEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root)
        dialog.setOnShowListener{_ -> dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showColourFlowDialog(){
        val prefs=getSharedPreferences("ui",MODE_PRIVATE)
        var c1=RovexColorFlowTextView.colorOne(this)
        var c2=RovexColorFlowTextView.colorTwo(this)
        var panel=prefs.getInt("greeting_panel_color",0)
        var flow=prefs.getBoolean("flow_text_enabled",true)
        val dialog=Dialog(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));background=rounded(ThemeManager.dialogBg(this@SettingsActivity),24)}
        root.addView(TextView(this).apply{text="Colour flow";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
        root.addView(TextView(this).apply{text="Choose two colours. They blend and travel across the flow labels.";textSize=12.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(4),0,dp(12))})
        val preview=TextView(this).apply{text="Performance  •  Flashcards  •  Solved";textSize=16f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(dp(8),dp(10),dp(8),dp(10))}
        root.addView(preview,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(10))})
        fun refresh(){
            preview.background=GradientDrawable().apply{cornerRadius=dp(12).toFloat();setColor(if(ThemeManager.get(this@SettingsActivity)==ThemeManager.AMOLED)Color.BLACK else ThemeManager.elevated(this@SettingsActivity));setStroke(dp(1),RovexColorFlowTextView.mix(c1,c2,.5f))}
            preview.paint.shader=android.graphics.LinearGradient(0f,0f,preview.width.coerceAtLeast(dp(220)).toFloat(),0f,intArrayOf(c1,RovexColorFlowTextView.mix(c1,c2,.5f),c2),null,android.graphics.Shader.TileMode.CLAMP)
            preview.invalidate()
        }
        fun addSpectrum(label:String,initial:Int,onChange:(Int)->Unit){
            root.addView(TextView(this).apply{text=label;textSize=12f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(dp(2),dp(3),0,dp(1))})
            val bar=RovexColorSpectrumView(this).apply{color=initial;this.onColorChanged={onChange(it);refresh()}}
            root.addView(bar,LinearLayout.LayoutParams(-1,dp(88)).apply{setMargins(0,0,0,dp(4))})
        }
        addSpectrum("FLOW COLOUR 1",c1){c1=it;refresh()}
        addSpectrum("FLOW COLOUR 2",c2){c2=it;refresh()}
        val normal=CheckBox(this).apply{text="Keep colour-flow labels as normal text";textSize=13f;isChecked=!flow;setTextColor(ThemeManager.text(this@SettingsActivity));setOnCheckedChangeListener{_,checked->flow=!checked}}
        root.addView(normal)
        root.addView(TextView(this).apply{text="Greeting panel colour";textSize=13f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity));setPadding(dp(2),dp(12),0,dp(2))})
        val panelBar=RovexColorSpectrumView(this).apply{color=if(panel==0)Color.rgb(35,101,126) else panel;onColorChanged={panel=it}}
        root.addView(panelBar,LinearLayout.LayoutParams(-1,dp(88)).apply{setMargins(0,0,0,dp(4))})
        root.addView(TextView(this).apply{text="The panel behind Good morning / afternoon / evening uses this colour.";textSize=11f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(dp(2),0,0,dp(8))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        buttons.addView(TextView(this).apply{text="RESET";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));setOnClickListener{prefs.edit().remove("flow_text_color_1").remove("flow_text_color_2").remove("flow_text_enabled").remove("greeting_panel_color").apply();dialog.dismiss();recreate()}},LinearLayout.LayoutParams(0,dp(46),1f))
        buttons.addView(TextView(this).apply{text="SAVE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));setOnClickListener{prefs.edit().putInt("flow_text_color_1",c1).putInt("flow_text_color_2",c2).putBoolean("flow_text_enabled",flow).putInt("greeting_panel_color",panel).apply();dialog.dismiss();recreate()}},LinearLayout.LayoutParams(0,dp(46),1f))
        root.addView(buttons)
        refresh()
        dialog.setContentView(root);dialog.setOnShowListener{dialog.window?.setLayout((resources.displayMetrics.widthPixels*.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)};dialog.show();dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.window?.setLayout((resources.displayMetrics.widthPixels*.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun themeSwatch(key:String):Int=when(key){
        ThemeManager.LIGHT->Color.rgb(247,249,246)
        ThemeManager.DARK->Color.rgb(48,61,75)
        ThemeManager.SEPIA->Color.rgb(246,239,218)
        ThemeManager.AMOLED->Color.rgb(0,0,0)
        else->Color.rgb(24,54,92)
    }

    private fun addAppearance(root:LinearLayout){
        section(root,"APPEARANCE")
        val themes=linkedMapOf(ThemeManager.LIGHT to "Light",ThemeManager.DARK to "Dark",ThemeManager.SEPIA to "Sepia",ThemeManager.AMOLED to "AMOLED Black",ThemeManager.MIDNIGHT to "Midnight Blue")
        themes.forEach{(key,label)-> root.addView(button(if(ThemeManager.get(this)==key)"✓  $label" else label){ThemeManager.set(this,key);recreate()},lp())}
    }

    private fun addFonts(root:LinearLayout){
        section(root,"QUIZ TYPOGRAPHY")
        val fonts=linkedMapOf("sans-serif" to "Modern Sans","serif" to "Serif / textbook","monospace" to "Monospace / coding","sans-serif-condensed" to "Condensed Sans","sans-serif-light" to "Light Sans")
        val current=getSharedPreferences("ui",MODE_PRIVATE).getString("quiz_font_family","sans-serif")?:"sans-serif"
        fonts.forEach{(key,label)->root.addView(button(if(current==key)"✓  $label" else label){getSharedPreferences("ui",MODE_PRIVATE).edit().putString("quiz_font_family",key).apply();recreate()},lp())}
    }

    private fun addAdaptive(root:LinearLayout){
        section(root,"ADAPTIVE ENGINE")
        val state=AppManagers.adaptive.state()
        val dark=ThemeManager.isDark(this)
        val cardBg=ThemeManager.elevated(this)
        val border=if(dark) Color.rgb(48,61,75) else Color.rgb(220,226,230)

        fun card(pad:Int=16)=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(pad),dp(pad),dp(pad),dp(pad))
            background=GradientDrawable().apply{setColor(cardBg);cornerRadius=dp(16).toFloat();setStroke(dp(1),border)}
        }
        fun label(text:String,size:Float=12.5f)=TextView(this).apply{
            this.text=text;this.textSize=size;setTextColor(ThemeManager.muted(this@SettingsActivity))
        }
        fun title(text:String,size:Float=17f)=TextView(this).apply{
            this.text=text;this.textSize=size;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))
        }
        fun bar(value:Int, tint:Int):ProgressBar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{
            max=100;progress=value.coerceIn(0,100);progressTintList=android.content.res.ColorStateList.valueOf(tint);backgroundTintList=android.content.res.ColorStateList.valueOf(if(ThemeManager.get(this@SettingsActivity)==ThemeManager.AMOLED) Color.BLACK else if(dark)Color.rgb(42,52,64) else Color.rgb(231,235,238))
        }
        fun metric(value:String, caption:String)=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(11),dp(12),dp(11));background=GradientDrawable().apply{setColor(if(ThemeManager.get(this@SettingsActivity)==ThemeManager.AMOLED) Color.BLACK else if(dark)Color.rgb(20,28,37) else Color.rgb(248,249,249));cornerRadius=dp(12).toFloat()}
            addView(TextView(this@SettingsActivity).apply{text=value;textSize=21f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))},LinearLayout.LayoutParams(-1,dp(28)))
            addView(label(caption,11.5f),LinearLayout.LayoutParams(-1,-2))
        }

        val hero=card()
        val heroTop=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val heroCopy=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        heroCopy.addView(title("Adaptive Engine",19f))
        heroCopy.addView(label(if(state.safeMode)"Protective mode active" else "Learning from runtime behaviour",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,0)})
        heroTop.addView(heroCopy,LinearLayout.LayoutParams(0,-2,1f))
        val toggle=Switch(this).apply{
            isChecked=AppManagers.adaptive.isAutonomyEnabled();text="";contentDescription="Autonomous runtime optimisation"
            buttonTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(this@SettingsActivity))
            setOnCheckedChangeListener{_,checked->AppManagers.adaptive.setAutonomyEnabled(checked);Toast.makeText(this@SettingsActivity,if(checked)"Autonomous optimisation enabled" else "Autonomous optimisation paused",Toast.LENGTH_SHORT).show()}
        }
        heroTop.addView(toggle,LinearLayout.LayoutParams(dp(56),dp(48)))
        hero.addView(heroTop)
        val healthRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(16),0,0)}
        healthRow.addView(title("System health",15f),LinearLayout.LayoutParams(0,-2,1f))
        val healthColor=when { state.health>=80 -> Color.rgb(32,128,91); state.health>=55 -> Color.rgb(163,111,31); else -> Color.rgb(170,55,65) }
        healthRow.addView(TextView(this).apply{text="${state.health}%";textSize=22f;typeface=Typeface.DEFAULT_BOLD;setTextColor(healthColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(58),dp(30)))
        hero.addView(healthRow)
        hero.addView(bar(state.health,if(state.health>=80)Color.rgb(39,151,107)else if(state.health>=55)Color.rgb(190,139,52)else Color.rgb(185,65,77)),LinearLayout.LayoutParams(-1,dp(7)).apply{setMargins(0,dp(7),0,0)})
        hero.addView(label("${state.systemModel.replaceFirstChar{it.uppercase()}} device profile  •  ${if(state.safeMode)"safe mode"else"normal operation"}",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val metrics=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        metrics.addView(metric("${state.learningScore}%","learning"),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(0,0,dp(4),0)})
        metrics.addView(metric("${state.confidence}%","confidence"),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(dp(4),0,dp(4),0)})
        metrics.addView(metric("${state.autonomousChanges}","changes"),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(metrics,LinearLayout.LayoutParams(-1,dp(68)).apply{setMargins(0,0,0,dp(10))})

        val battery=card()
        val batteryTop=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val batteryCopy=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        batteryCopy.addView(title("Battery Engine",16f))
        batteryCopy.addView(label("Power governor • ${AppManagers.battery.statusLine()}",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,0)})
        batteryTop.addView(batteryCopy,LinearLayout.LayoutParams(0,-2,1f))
        val batteryLevel=AppManagers.battery.snapshot().level
        batteryTop.addView(TextView(this).apply{text=batteryLevel.name;textSize=11f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));background=GradientDrawable().apply{setColor(ThemeManager.bg(this@SettingsActivity));cornerRadius=dp(10).toFloat()};setPadding(dp(10),0,dp(10),0)},LinearLayout.LayoutParams(-2,dp(32)))
        battery.addView(batteryTop)
        val bp=AppManagers.battery.policy(RovexBatteryManager.WorkClass.INTERACTIVE)
        battery.addView(label("Interactive prefetch ${bp.prefetchDepth} • image concurrency ${bp.imageConcurrency} • import batch ${bp.importBatchSize}",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,0)})
        battery.addView(label("Foreground study remains allowed; the engine only reduces background/bulk pressure when power or thermal conditions require it.",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,0)})
        root.addView(battery,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val learning=card()
        learning.addView(title("Learning signal"))
        learning.addView(label("Confidence",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(4))})
        learning.addView(bar(state.confidence,ThemeManager.accent(this)),LinearLayout.LayoutParams(-1,dp(6)))
        learning.addView(label("Uncertainty ${state.uncertainty}%  •  exploration ${state.exploration}%",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,0)})
        learning.addView(label("User model: ${state.userModel}  •  System model: ${state.systemModel}",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,0)})
        root.addView(learning,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val strategy=card()
        strategy.addView(title("Current study strategy"))
        strategy.addView(label(AppManagers.adaptive.studyStrategy(),13.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,0)})
        root.addView(strategy,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val policy=card()
        policy.addView(title("Runtime policy"))
        policy.addView(label("Prefetch depth",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(4))})
        policy.addView(bar((state.preferredPrefetch/3f*100f).toInt(),ThemeManager.accent(this)),LinearLayout.LayoutParams(-1,dp(6)))
        policy.addView(label("${state.preferredPrefetch} question${if(state.preferredPrefetch==1)""else"s"}  •  cache ${PerformanceManager.adaptiveCacheTtlMs()/1000}s",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,0)})
        policy.addView(label("Next policy: ${AppManagers.adaptive.currentProposal().action.key}",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(2))})
        policy.addView(label(AppManagers.adaptive.currentProposal().reason,12.5f))
        policy.addView(label(AdaptiveExplainability.explain(state),11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,0)})
        root.addView(policy,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val activity=card()
        activity.addView(title("Engine activity"))
        activity.addView(label("${state.observations} observations  •  ${state.answers} answers  •  ${state.correct} correct  •  ${state.wrong} wrong",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(8))})
        activity.addView(label("Last action: ${state.lastAction}  •  outcome: ${state.lastOutcome}",12f))
        activity.addView(label("Rollbacks: ${state.rollbackCount}",12f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(8))})
        val history=state.recentActions
        if(history.isEmpty()) activity.addView(label("No autonomous changes yet.",12f))
        else history.take(8).forEachIndexed{idx,line->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(8),0,dp(8))}
            row.addView(TextView(this).apply{text="${idx+1}";textSize=11f;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));background=rounded(ThemeManager.explanationBg(this@SettingsActivity),10);},LinearLayout.LayoutParams(dp(28),dp(28)))
            row.addView(label(line,11.5f),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(10),0,0,0)})
            activity.addView(row)
        }
        root.addView(activity,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val safety=card()
        safety.addView(title("Safety boundaries"))
        safety.addView(label("The engine can tune only prefetch, cache lifetime and safe mode. It cannot alter question content, progress records, database schema, backups or executable code.",12.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(8))})
        safety.addView(label("Rollback count: ${state.rollbackCount}  •  Safe mode: ${if(state.safeMode)"active"else"ready"}",12f))
        root.addView(safety,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val resilience = card()
        val rh = AppManagers.resilienceHealth.snapshot()
        resilience.addView(title("Resilience & recovery"))
        resilience.addView(label("Health ${rh.overall}%  •  ${if(rh.safeMode) "protective safe mode" else "normal runtime"}", 12.5f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(4))})
        resilience.addView(label("Process interruptions: ${rh.crashCount}  •  suspected UI stalls: ${ResilienceManager.suspectedStalls(this)}", 12f))
        rh.recovery?.let { r -> resilience.addView(label("Protected session: question ${r.position + 1}${if(r.session.isBlank()) "" else "  •  ${r.session}"}", 12f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(0))}) }
        resilience.addView(label("Recovery is local and conservative. The app never attempts to force-kill a frozen Android process.", 11.5f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,dp(0))})
        root.addView(resilience,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        // Companion engines are surfaced separately. Flashcards are strictly user-controlled: a wrong answer never creates one automatically.
        val fs = AppManagers.flashcardIntelligence.stats()
        val ks = AppManagers.knowledge.stats()
        root.addView(sectionView("FLASHCARD INTELLIGENCE ENGINE", "Manual flashcard creation only. Wrong questions are never converted into flashcards automatically."))
        root.addView(engineCard("Flashcard Engine", "Manual creation: enabled", "Open Flashcards and choose what you want to add") {
            startActivity(Intent(this, FlashcardActivity::class.java))
        })
        root.addView(labelBlock("Engine status: ${if(fs.available) "ready" else "unavailable"} • flashcards are created only when you explicitly request them"), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,dp(10))})
        root.addView(sectionView("KNOWLEDGE / AUTO-NOTES ENGINE", "Builds local knowledge captures only when you explicitly request them; original QBank questions remain untouched."))
        root.addView(engineCard("Knowledge Engine", "Automatic capture: enabled", "Open Knowledge Vault") { startActivity(Intent(this,KnowledgeVaultActivity::class.java)) })
        root.addView(labelBlock("Stored now: ${ks.notes} notes • ${ks.tables} tables • ${ks.images} images"), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,dp(10))})
        root.addView(sectionView("DR. FRANKENSTEIN INTELLIGENCE ORCHESTRATOR", "Thin control plane for multi-engine requests. Simple actions bypass it for speed; complex requests are planned through registered capabilities. Dr. Frankenstein cannot rewrite executable code or source QBank data at runtime."))
        val bioCard = card()
        bioCard.addView(title("Capability registry", 16f))
        bioCard.addView(label("Guardian: ${AppManagers.guardian.snapshot()}", 11.5f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(8))})
        AppManagers.bio.capabilities().forEach { cap ->
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(6),0,dp(6)) }
            val copy = LinearLayout(this@SettingsActivity).apply { orientation=LinearLayout.VERTICAL }
            copy.addView(TextView(this@SettingsActivity).apply{text=cap.name;textSize=13.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
            copy.addView(TextView(this@SettingsActivity).apply{text="${cap.owner} • ${cap.mutates}";textSize=10.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(2),0,0)})
            row.addView(copy, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@SettingsActivity).apply{text="ACTIVE";textSize=9.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));background=rounded(ThemeManager.explanationBg(this@SettingsActivity),9);setPadding(dp(8),0,dp(8),0)},LinearLayout.LayoutParams(dp(62),dp(28)))
            bioCard.addView(row)
        }
        bioCard.addView(label("New functionality is added through versioned capability contracts and validation, not unrestricted runtime self-modification.",11.5f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(0))})
        root.addView(bioCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        // Ben is deliberately surfaced here: every AI subsystem is user-visible and independently controllable.
        val ben = card()
        ben.addView(title("BEN • Cognitive Architecture", 18f))
        ben.addView(label("Frankenstein control room • all local intelligence remains offline-first", 11.5f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,dp(10))})
        val bc = BenCognitiveControl(this)
        fun benSwitch(caption:String, checked:Boolean, change:(Boolean)->Unit) {
            ben.addView(Switch(this).apply {
                text=caption; isChecked=checked; setTextColor(ThemeManager.text(this@SettingsActivity));
                setOnCheckedChangeListener { _, v -> change(v) }
            }, LinearLayout.LayoutParams(-1,dp(48)))
        }
        benSwitch("Cognitive Core", bc.cognitiveCoreEnabled) { bc.setCognitiveCoreEnabled(it) }
        benSwitch("Medical Knowledge Graph", bc.knowledgeGraphEnabled) { bc.setKnowledgeGraphEnabled(it) }
        benSwitch("Planner / Reasoner", bc.plannerEnabled) { bc.setPlannerEnabled(it) }
        benSwitch("Local RAG / QBank Retrieval", bc.retrievalEnabled) { bc.setRetrievalEnabled(it) }
        benSwitch("Specialist Routing", bc.specialistRoutingEnabled) { bc.setSpecialistRoutingEnabled(it) }
        benSwitch("Learner Memory", bc.learnerMemoryEnabled) { bc.setLearnerMemoryEnabled(it) }
        benSwitch("Experience Memory", bc.experienceMemoryEnabled) { bc.setExperienceMemoryEnabled(it) }
        benSwitch("Answer Verifier", bc.verifierEnabled) { bc.setVerifierEnabled(it) }
        val frStats = AppManagers.benBrain.frankenstein().stats()
        ben.addView(label("Frankenstein telemetry: ${frStats.observations} routed requests • ${frStats.verificationRate}% verified • last specialist ${frStats.lastSpecialist}", 11.5f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(2))})
        if (frStats.lastConcepts.isNotBlank()) ben.addView(label("Recent concepts: ${frStats.lastConcepts}", 11f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(4))})
        ben.addView(label("Specialists: ${BenSpecialistRegistry.entries().size} deterministic clinical routes • neural model remains optional", 11.5f))
        val aiPolicy = BenAiRuntimePolicy(this)
        ben.addView(label("Neural accelerator: ${if(aiPolicy.circuitOpen) "BLOCKED (failure circuit open)" else if(aiPolicy.enabled) "ARMED (governor-controlled)" else "OFF"} • conservative gate ${BenAiRuntimePolicy.CONSERVATIVE_MODEL_MB_LIMIT} MB", 11.5f), LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(4))})
        val governor = BenAiResourceGovernor(this)
        val snapshot = governor.snapshot(foreground = true)
        ben.addView(label("Safety governor: ${snapshot.availableMemoryMb} MB available • thermal ${snapshot.thermalStatus} • power-save ${if(snapshot.powerSave) "ON" else "OFF"}", 11.5f))
        ben.addView(label("Hard gate: ${BenAiResourceGate.MIN_FREE_HEADROOM_MB} MB RAM headroom • thermal ceiling ${BenAiResourceGate.MAX_THERMAL_STATUS} • foreground-only model execution", 11.5f))
        ben.addView(label("Backend failures: ${aiPolicy.consecutiveFailures}/${BenAiRuntimePolicy.MAX_CONSECUTIVE_FAILURES} before automatic model circuit-breaker", 11.5f))
        ben.addView(button("Open Ben AI Safety") { showBenAiSafetyDialog() }, LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(10),0,dp(4))})
        ben.addView(button("Reset Ben to safe defaults") { bc.resetToSafeDefaults(); Toast.makeText(this,"Ben reset to safe defaults",Toast.LENGTH_SHORT).show(); recreate() }, LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,dp(0))})
        root.addView(ben,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        root.addView(button("Reset Adaptive Learning History"){AppManagers.adaptive.resetLearning();Toast.makeText(this,"Adaptive history reset",Toast.LENGTH_SHORT).show();recreate()},lp())
    }

    private fun sectionView(title:String, subtitle:String):View = LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL; setPadding(dp(2),dp(10),dp(2),dp(5))
        addView(TextView(this@SettingsActivity).apply{text=title;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(this@SettingsActivity))})
        addView(TextView(this@SettingsActivity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(3),0,dp(4))})
    }
    private fun labelBlock(t:String)=TextView(this).apply{text=t;textSize=11.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(dp(12),dp(4),dp(12),dp(6))}
    private fun engineCard(title:String, subtitle:String, action:String, click:()->Unit)=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(10),dp(12))
        background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@SettingsActivity));cornerRadius=dp(16).toFloat();setStroke(dp(1),if(ThemeManager.isDark(this@SettingsActivity))Color.rgb(48,61,75)else Color.rgb(220,226,230))}
        val copy=LinearLayout(this@SettingsActivity).apply{orientation=LinearLayout.VERTICAL}
        copy.addView(TextView(this@SettingsActivity).apply{text=title;textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity))})
        copy.addView(TextView(this@SettingsActivity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,dp(3),0,0)})
        addView(copy,LinearLayout.LayoutParams(0,-2,1f))
        addView(TextView(this@SettingsActivity).apply{text="OPEN";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@SettingsActivity));background=rounded(ThemeManager.explanationBg(this@SettingsActivity),11);setPadding(dp(10),0,dp(10),0);setOnClickListener{click()}},LinearLayout.LayoutParams(dp(78),dp(38)))
    }
    private fun section(root:LinearLayout,t:String){root.addView(TextView(this).apply{text=t;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(16),0,dp(8))})}
    private fun lp()=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}
    private fun button(t:String,click:()->Unit)=TextView(this).apply{text=t;textSize=14f;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),0,dp(16),0);setTextColor(ThemeManager.text(this@SettingsActivity));background=rounded(ThemeManager.elevated(this@SettingsActivity),14);setOnClickListener{click()}}
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
}
