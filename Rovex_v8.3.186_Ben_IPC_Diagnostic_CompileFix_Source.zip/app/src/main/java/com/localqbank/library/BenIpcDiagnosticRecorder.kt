package com.localqbank.library

import android.content.Context
import android.os.Build
import java.util.concurrent.atomic.AtomicLong

/** Durable, bounded, model-independent runtime trace for the Ben IPC diagnostic. */
object BenIpcDiagnosticRecorder {
    private const val PREFS = "ben_ipc_diagnostic"
    private const val EVENTS = "events"
    private const val ACTIVE = "active"
    private const val MAX_CHARS = 14000
    private const val MAX_EVENT_CHARS = 500
    private val sequence = AtomicLong(0)

    @Synchronized fun start(context: Context): String {
        val id = java.util.UUID.randomUUID().toString()
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ACTIVE, id).putString(EVENTS, "").apply()
        event(context, id, "TEST_START", "version=${Build.VERSION.RELEASE} sdk=${Build.VERSION.SDK_INT} device=${Build.MODEL}")
        return id
    }

    @Synchronized fun event(context: Context, testId: String?, stage: String, detail: String = "") {
        val prefs=context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id=testId ?: prefs.getString(ACTIVE,null) ?: "NO_TEST"
        val line="${System.currentTimeMillis()}|${sequence.incrementAndGet()}|$stage|${detail.replace("\n"," ").take(MAX_EVENT_CHARS)}"
        val old=prefs.getString(EVENTS,"").orEmpty()
        val combined=(old + line + "\n").takeLast(MAX_CHARS)
        prefs.edit().putString(EVENTS,combined).putString(ACTIVE,id).apply()
    }

    @Synchronized fun finish(context: Context, testId: String?, result: String, reason: String?=null): String {
        event(context,testId,"TEST_TERMINAL","result=$result reason=${reason?.take(400).orEmpty()}")
        val prefs=context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val report=buildString {
            appendLine("BEN IPC DIAGNOSTIC REPORT")
            appendLine("=========================")
            appendLine("testId=${testId ?: prefs.getString(ACTIVE,"unknown")}")
            appendLine("result=$result")
            if (!reason.isNullOrBlank()) appendLine("failure=$reason")
            appendLine("modelsRequired=false")
            appendLine("modelsLoaded=false (transport/lifecycle diagnostic)")
            appendLine()
            appendLine("EVENT TRACE (oldest → newest)")
            append(prefs.getString(EVENTS,"").orEmpty())
        }.take(MAX_CHARS)
        RovexDiagnosticsStore.publish(context, report)
        prefs.edit().remove(ACTIVE).apply()
        return report
    }

    fun current(context: Context): String? = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(EVENTS,null)
}
