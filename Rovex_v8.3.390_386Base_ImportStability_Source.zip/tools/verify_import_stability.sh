#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DB="$ROOT/app/src/main/java/com/localqbank/library/QBankDb.kt"
HTML="$ROOT/app/src/main/java/com/localqbank/library/HtmlImportActivity.kt"
COORD="$ROOT/app/src/main/java/com/localqbank/library/ImportPipelineCoordinator.kt"
fail(){ echo "FAIL: $*"; exit 1; }
grep -q 'private val dirtyTests=LinkedHashSet<String>()' "$DB" || fail "streaming importer lacks dirty-test tracking"
grep -q 'dirtyTests += title' "$DB" || fail "streaming importer does not mark changed tests"
grep -q 'dirtyTests.clear()' "$DB" || fail "dirty-test set is not cleared after commit"
# Both section commits and finalization must update only changed tests, never the full accumulated test map.
awk '/fun commitSection\(\)/,/fun addQuestion/' "$DB" | grep -q 'dirtyTests.forEach' || fail "commitSection still updates every accumulated test"
awk '/fun finish\(success:Boolean\)/,/^    }/{print}' "$DB" | grep -q 'dirtyTests.forEach' || fail "finish still updates every accumulated test"
grep -q 'LARGE_FILE_LIMIT = 8L \* 1024L \* 1024L' "$HTML" || fail "large-file streaming threshold was not lowered to 8 MiB"
grep -q 'Executors.newSingleThreadExecutor' "$COORD" || fail "imports are no longer serialized through the coordinator"
grep -q 'running.compareAndSet(false, true)' "$COORD" || fail "import concurrency gate missing"
# The large-file path must stage and stream rather than read the whole large document into a String.
awk '/private fun importLargeFile/,/private fun looksLikeSrcdocExport/' "$HTML" | grep -q 'LargeHtmlScanner' || fail "large-file path is not streaming"
awk '/private fun importLargeFile/,/private fun looksLikeSrcdocExport/' "$HTML" | grep -q 'copyToFile' || fail "large-file path lacks bounded staging"
echo 'PASS: streaming import updates only dirty tests at commit boundaries'
echo 'PASS: final streaming-import flush updates only dirty tests'
echo 'PASS: HTML importer switches to streaming mode at 8 MiB'
echo 'PASS: imports remain serialized and non-overlapping'
echo 'PASS: large-file path uses staged streaming scanner'
