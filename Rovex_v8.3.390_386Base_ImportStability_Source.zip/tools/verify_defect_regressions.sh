#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REN="$ROOT/app/src/main/java/com/localqbank/library/RenActivity.kt"
SEARCH="$ROOT/app/src/main/java/com/localqbank/library/SearchActivity.kt"
SERVICE="$ROOT/app/src/main/java/com/localqbank/library/LocalQBankSearchService.kt"
QUIZ="$ROOT/app/src/main/java/com/localqbank/library/QuizActivity.kt"
LIFE="$ROOT/app/src/main/java/com/localqbank/library/QuizSessionLifecycleController.kt"

fail(){ echo "FAIL: $*" >&2; exit 1; }

grep -Fq 'headerButton("CLEAR",58){clearChatHistory()}' "$REN" || fail "Frankenstein CLEAR control missing"
grep -Fq 'AppManagers.renMemory.clearChatContext()' "$REN" || fail "Frankenstein durable chat clear missing"
grep -Fq 'chatTurns.clear()' "$REN" || fail "Frankenstein UI chat clear missing"
! grep -Fq 'quizViewModel.persistSessionCursor()' "$QUIZ" || fail "QuizActivity still promotes QBank open to Continue cursor"
! grep -Fq 'viewModel.persistSessionCursor()' "$LIFE" || fail "QuizSessionLifecycleController still promotes onPause to Continue cursor"
grep -Fq 'quizViewModel.setResumeCursor(next, null)' "$QUIZ" || fail "Answer resume checkpoint missing"
grep -Fq 'fun searchSections(' "$SERVICE" || fail "Shared search service lacks hierarchy retrieval"
grep -Fq 'localSearch.searchSections(text, 60)' "$SEARCH" || fail "Main Search does not use shared hierarchy retrieval"
grep -Fq 'localSearch.search(text, 300)' "$SEARCH" || fail "Main Search does not use shared question retrieval"
grep -Fq 'if(::searchBox.isInitialized && ::db.isInitialized)runSearch' "$SEARCH" || fail "Search onResume can run before DB initialization"
grep -Fq 'if(::db.isInitialized)runCatching{db.close()}' "$SEARCH" || fail "Search DB is not closed on destroy"
grep -Fq 'private fun rawQBankIds' "$ROOT/app/src/main/java/com/localqbank/library/RenCognitiveEngine.kt" || fail "Frankenstein raw ID fallback missing"
grep -Fq 'if (ids.isNotEmpty()) recentSearchCache' "$ROOT/app/src/main/java/com/localqbank/library/RenCognitiveEngine.kt" || fail "Frankenstein empty-result cache poison guard missing"

echo 'PASS: DEFECT_1 chat-clear and local-search route invariants'
echo 'PASS: DEFECT_2 shared question + QBank/sub-QBank retrieval invariants'
echo 'PASS: DEFECT_3 Continue cursor is written only by explicit study interaction'
