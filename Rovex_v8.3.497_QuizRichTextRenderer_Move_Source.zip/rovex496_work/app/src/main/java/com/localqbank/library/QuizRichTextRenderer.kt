package com.localqbank.library

import android.text.Html
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.TextAppearanceSpan
import android.content.Context

/**
 * Dedicated imported-HTML renderer for question/option/explanation text.
 *
 * The renderer owns the theme-safety boundary so QuizActivity remains a session/controller
 * rather than accumulating HTML parsing and span-sanitization policy.
 */
internal class QuizRichTextRenderer(
    private val context: Context,
    private val appendNote: ((Long, String) -> Unit)? = null
) {

    fun themeSafeSpanned(html: String, forcedColor: Int? = null): Spanned {
        val sanitized = sanitizeImportedColors(html)
        val parsed = Html.fromHtml(sanitized, Html.FROM_HTML_MODE_LEGACY)
        if (parsed !is Spannable) return parsed

        val out = SpannableString(parsed)
        sanitizeColorSpans(out)
        // Theme colour is applied by TextView.setTextColor(), never as a span.
        // Spans have higher precedence and can otherwise preserve an old/imported colour across theme changes.
        @Suppress("UNUSED_VARIABLE") val ignoredForcedColor = forcedColor
        return out
    }

    /** Remove only imported foreground/background color declarations; preserve other markup. */
    private fun sanitizeImportedColors(raw: String): String {
        // Normalize provider/importer literal <br> markup before Android HTML parsing.
        var out = raw
            .replace(Regex("(?i)&lt;\\s*br\\s*/?\\s*&gt;"), "\n")
            .replace(Regex("(?i)<\\s*br\\s*/?\\s*>"), "\n")
        out = out.replace(Regex("(?is)(<font\\b[^>]*?)\\s+color\\s*=\\s*(?:\\\"[^\\\"]*\\\"|'[^']*'|[^\\s>]+)"), "$1")
        out = out.replace(Regex("(?is)(<[^>]+?)\\s+(?:color|bgcolor)\\s*=\\s*(?:\\\"[^\\\"]*\\\"|'[^']*'|[^\\s>]+)"), "$1")
        out = out.replace(Regex("(?is)(<[^>]+?\\s+style\\s*=\\s*['\\\"])(.*?)(['\\\"][^>]*>)")) { m ->
            var style = m.groupValues[2]
            style = style.replace(Regex("(?i)(?:^|;)\\s*(?:color|background-color|background|text-color)\\s*:[^;]+;?"), ";")
            val normalized = style.trim().trim(';').trim()
            if (normalized.isBlank()) "${m.groupValues[1]}${m.groupValues[3]}"
            else "${m.groupValues[1]}$normalized${m.groupValues[3]}"
        }
        return out
    }

    /**
     * Android Html.fromHtml() can represent HTML colours as ForegroundColorSpan or
     * TextAppearanceSpan. Both override a TextView's base textColor, so remove them
     * centrally while retaining bold/italic/underline/size/typeface spans.
     */
    internal fun sanitizeColorSpans(out: Spannable) {
        out.getSpans(0, out.length, ForegroundColorSpan::class.java).forEach(out::removeSpan)
        out.getSpans(0, out.length, BackgroundColorSpan::class.java).forEach(out::removeSpan)
        out.getSpans(0, out.length, TextAppearanceSpan::class.java).forEach { span ->
            val start = out.getSpanStart(span)
            val end = out.getSpanEnd(span)
            val flags = out.getSpanFlags(span)
            out.removeSpan(span)
            if (start >= 0 && end > start) {
                out.setSpan(TextAppearanceSpan(span.family, span.textStyle, span.textSize, null, null), start, end, flags)
            }
        }
        // Defensive postcondition: no parser-created foreground/background span may survive.
        out.getSpans(0, out.length, ForegroundColorSpan::class.java).forEach(out::removeSpan)
        out.getSpans(0, out.length, BackgroundColorSpan::class.java).forEach(out::removeSpan)
    }


    /**
     * Move-only extraction of QuizActivity's imported HTML rendering pipeline.
     * Rendering behavior is intentionally preserved; QuizActivity remains responsible for
     * image loading and owns the destination content container.
     */
    fun renderHtmlText(
        content: LinearLayout,
        html: String?,
        size: Float,
        bold: Boolean = false,
        color: Int? = null,
        noteQuestionId: Long? = null,
        role: String = "generic",
        fontFamily: String,
        addImage: (String) -> Unit
    ) {
        val raw = html ?: ""
        val imageSrcs = Regex("<img\\s+[^>]*(?:src|data-src|data-original|data-lazy-src)\\s*=\\s*[\"']([^\"']+)[^>]*>", RegexOption.IGNORE_CASE)
            .findAll(raw).map { it.groupValues[1] }.toList() +
            Regex("background-image\\s*:\\s*url\\s*\\(\\s*[\"']?([^\\)\"']+)[\"']?\\s*\\)", RegexOption.IGNORE_CASE)
                .findAll(raw).map { it.groupValues[1] }.toList()
        var cleaned = raw.replace(Regex("<img\\s+[^>]*>", RegexOption.IGNORE_CASE), "")
        cleaned = cleaned.replace(Regex("(?i)data:image/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=\\r\\n]+"), "")
        cleaned = cleaned.replace(Regex("\\s+face\\s*=\\s*['\"][^'\"]*['\"]", RegexOption.IGNORE_CASE), "")
        if (Regex("<table\\b", RegexOption.IGNORE_CASE).containsMatchIn(cleaned)) {
            addRichHtmlWithTables(content, cleaned, size, bold, color, noteQuestionId, role, fontFamily)
        } else {
            addSelectableHtmlText(content, cleaned, size, bold, color, noteQuestionId, role, fontFamily)
        }
        imageSrcs.forEach(addImage)
    }

    private fun addRichHtmlWithTables(content: LinearLayout, html: String, size: Float, bold: Boolean, color: Int?, noteQuestionId: Long?, role: String, fontFamily: String) {
        val tableRx = Regex("<table\\b[^>]*>(.*?)</table>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        var cursor = 0
        for (m in tableRx.findAll(html)) {
            val before = html.substring(cursor, m.range.first)
            if (before.replace(Regex("<[^>]+>"), "").trim().isNotBlank()) addSelectableHtmlText(content, before, size, bold, color, noteQuestionId, role, fontFamily)
            addNativeHtmlTable(content, m.value, size, color, role, fontFamily)
            cursor = m.range.last + 1
        }
        val after = html.substring(cursor)
        if (after.replace(Regex("<[^>]+>"), "").trim().isNotBlank()) addSelectableHtmlText(content, after, size, bold, color, noteQuestionId, role, fontFamily)
    }

    private fun addSelectableHtmlText(content: LinearLayout, html: String, size: Float, bold: Boolean, color: Int?, noteQuestionId: Long?, role: String, fontFamily: String) {
        val t = TextView(context).apply {
            tag = "quiz:" + role
            text = themeSafeSpanned(html, color ?: ThemeManager.text(context))
            textSize = size
            typeface = Typeface.create(fontFamily, if (bold) Typeface.BOLD else Typeface.NORMAL)
            setTextColor(color ?: ThemeManager.text(context))
            setLinkTextColor(if (color != null && ThemeManager.get(context) == ThemeManager.AMOLED) ThemeManager.accent(context) else ThemeManager.accent(context))
            setLineSpacing(0f, 1.25f)
            setPadding(0, 0, 0, dp(14))
            setTypeface(Typeface.create(fontFamily, if (bold) Typeface.BOLD else Typeface.NORMAL), if (bold) Typeface.BOLD else Typeface.NORMAL)
            if (noteQuestionId != null && role == "explanation") configureNoteSelection(this, noteQuestionId)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun configureNoteSelection(t: TextView, noteQuestionId: Long) {
        t.setTextIsSelectable(true)
        t.isLongClickable = true
        appendNote?.let { saver ->
            t.setCustomSelectionActionModeCallback(
                QuizNoteSelectionActionModeCallback(
                    textView = t,
                    noteQuestionId = noteQuestionId,
                    appendNote = saver,
                    context = context
                )
            )
        }
    }

    private fun addNativeHtmlTable(content: LinearLayout, tableHtml: String, size: Float, color: Int?, role: String, fontFamily: String) {
        val outer = RovexHorizontalScrollView(context).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            isHorizontalScrollBarEnabled = true
            isVerticalScrollBarEnabled = false
            setPadding(0, dp(4), 0, dp(16))
        }
        val table = TableLayout(context).apply {
            isStretchAllColumns = false
            isShrinkAllColumns = false
            setPadding(dp(1), dp(1), dp(1), dp(1))
        }
        val rows = Regex("<tr\\b[^>]*>(.*?)</tr>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(tableHtml)
        var rowIndex = 0
        for (rowMatch in rows) {
            val tr = TableRow(context).apply { gravity = Gravity.CENTER_VERTICAL }
            val cells = Regex("<(td|th)\\b([^>]*)>(.*?)</\\1>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(rowMatch.groupValues[1])
            var cellIndex = 0
            for (cell in cells) {
                val tag = cell.groupValues[1].lowercase()
                val attrs = cell.groupValues[2]
                val inner = cell.groupValues[3]
                val tv = TextView(context).apply {
                    this.tag = "quiz:" + role
                    text = themeSafeSpanned(inner, color ?: ThemeManager.questionText(context))
                    textSize = maxOf(13f, size - 1f)
                    setTextColor(color ?: ThemeManager.text(context))
                    setLinkTextColor(ThemeManager.accent(context))
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    gravity = Gravity.CENTER_VERTICAL
                    if (tag == "th") setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
                    background = GradientDrawable().apply {
                        setColor(if (tag == "th") {
                            if (ThemeManager.isDark(context)) Color.rgb(38,55,70) else Color.rgb(226,239,247)
                        } else {
                            if (ThemeManager.isDark(context)) Color.rgb(25,34,44) else if (rowIndex % 2 == 0) Color.WHITE else Color.rgb(247,250,252)
                        })
                        setStroke(dp(1), if (ThemeManager.isDark(context)) Color.rgb(76,92,108) else Color.rgb(190,201,211))
                    }
                    minWidth = dp(92)
                }
                val colspan = Regex("colspan\\s*=\\s*[\"'](\\d+)[\"']", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1
                val lp = TableRow.LayoutParams(dp(110), -2)
                lp.span = colspan.coerceAtLeast(1)
                tr.addView(tv, lp)
                cellIndex++
            }
            if (cellIndex > 0) { table.addView(tr); rowIndex++ }
        }
        if (table.childCount > 0) {
            outer.addView(table, ViewGroup.LayoutParams(-2, -2))
            content.addView(outer, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

    fun toSpanned(html: String): Spanned {
        return themeSafeSpanned(html)
    }

    fun optionSpanned(html: String, color: Int): Spanned {
        return themeSafeSpanned(html, color)
    }
}
