# Rovex v8.3.578 — LargeHtmlScanner CI/source-identity repair

## Authoritative failure reviewed
The uploaded CI log `logs_101773253696.zip` was independently inspected. It did **not** execute v8.3.577.
The log explicitly selected `Rovex_v8.3.576_LargeHtmlScanner_NullNormalization_CIRepair_Source.zip` (SHA-256 `e541ab1be6d0441af1fdcb07e9f1f248a603fd495504a93e1dded5d6c87c19ce`).
That run failed at `:app:testDebugUnitTest`: 147 tests completed, 5 failed, all in `LargeHtmlScannerRegressionTest`.

## Root cause
Two process/code issues were present:
1. The reported CI run was stale: it built v8.3.576 while the intended continuation was v8.3.577. Therefore previous repair claims could not be validated by that run.
2. The scanner's assignment detection remained a rolling regex over a mutable window. v8.3.578 replaces that with an explicit lexical state machine that tests the assignment prefix only when `[` is encountered, after comments/strings have been excluded.

## Changes
- LargeHtmlScanner seek-to-array logic hardened.
- JSON normalization retained from v8.3.577/576 deterministic `firstNonNull` + `clean` implementation.
- Version bumped to 8.3.578 / versionCode 664.
- Workflow renamed to `build-ben-qbank-578.yml`.
- Workflow source identity gates corrected to 8.3.578/664 and current `firstNonNull` contract.
- Added explicit stale-version rejection.
- Preserved idle/backoff audit gate.
- No QBankDb/business-logic ownership changes.

## Verification performed
- Source archive integrity: PASS.
- LargeHtmlScanner delimiter/brace balance: PASS.
- Workflow/version identity consistency: PASS.
- No `setRequiresDeviceIdle(true)` + `setBackoffCriteria(...)` combination in Kotlin worker source: PASS.
- CI/device/build: PENDING; this environment cannot establish GitHub Actions success.

## Important status
This ZIP is **not CI-green** until GitHub Actions runs the v8.3.578 source and the complete workflow passes.
