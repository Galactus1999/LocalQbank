# v8.3.515 — Home / Performance / PYQ / Motivation Repair

- Performance Lab: make study-attempt history reconciliation idempotent so existing progress cannot remain invisible after an earlier seed marker.
- Home Continue: select the newest valid durable resume cursor and pass the saved position as the authoritative launch target.
- PYQ dashboard: display each PYQ collection's own question total, not the whole source QBank total.
- Motivation: replace study/QBank-centric daily copy with 500 original life/work/discipline/failure/competition motivation lines and show two deterministic quotes per day on Home and in the daily notification.

Validation status: source/static audit pending; Android/CI/device validation must be run before release.
