# Rovex v8.3.527 — Friend Mailbox Repair

## Root cause
The previous no-Cloud-Function friend-request implementation stored a shared intent and then asked the recipient client to create both incoming and sender-owned outgoing documents. The recipient is not authorized to create the sender-owned outgoing document, so materialization could fail with `PERMISSION_DENIED`. The social loader also chained several 20–30 second `Tasks.await` calls, allowing one Firebase delay to surface as `Timed out waiting for Task` and hide usable social data.

## Repair
- Replace `friendRequestIntents` as the active transport with a recipient-scoped `friendRequestMailboxes/{targetCode}/requests/{requestId}` mailbox.
- Sender writes mailbox + sender-owned outgoing record in one batch; no target UID lookup and no Cloud Function.
- Recipient reads only its own mailbox, materializes incoming and updates the sender-owned outgoing record, then deletes the mailbox entry after successful materialization.
- Outgoing records use request IDs and carry `targetUid` once the recipient materializes them; accepted-outgoing finalization uses `targetUid` rather than assuming the document ID is a UID.
- Accept/decline locate the sender-owned outgoing record by requester UID + target Rovex ID.
- Social loading is best-effort and bounded; one Firebase failure no longer aborts the entire social section or blocks the screen for 20 seconds per operation.
- Partial social failures do not replace successfully loaded requests/friends with a generic error card.

## Scope
Friend-request transport/rules and social loading only. No QBank, study, AI, or unrelated feature changes.
