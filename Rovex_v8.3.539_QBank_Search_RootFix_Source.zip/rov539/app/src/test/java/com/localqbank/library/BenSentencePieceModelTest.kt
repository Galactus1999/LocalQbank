package com.localqbank.library

import com.sentencepiece.Model
import com.sentencepiece.Scoring
import com.sentencepiece.SentencePieceAlgorithm
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.file.Files

class BenSentencePieceModelTest {
    @Test fun parsesRequiredSentencePieceWireFieldsWithoutFullProtobufRuntime() {
        val modelBytes = protoMessage(
            fieldBytes(1, protoMessage(
                fieldString(1, "▁hello"),
                fieldFixed32(2, java.lang.Float.floatToIntBits(-0.5f)),
                fieldVarint(3, 1)
            )),
            fieldBytes(1, protoMessage(
                fieldString(1, "hello"),
                fieldFixed32(2, java.lang.Float.floatToIntBits(-1.0f)),
                fieldVarint(3, 1)
            )),
            fieldBytes(2, fieldVarint(40, 0))
        )
        val file = Files.createTempFile("rovex-spm", ".model")
        try {
            Files.write(file, modelBytes)
            val model = Model.parseFrom(file)
            assertEquals(0, model.getUnkId())
            assertEquals(0, model.getIdForToken("▁hello"))
            assertEquals(1, model.getIdForToken("hello"))
            val ids = model.encodeNormalized("hello", SentencePieceAlgorithm(true, Scoring.HIGHEST_SCORE))
            assertEquals(listOf(0), ids)
            assertTrue(model.decodeSmart(ids) == "hello")
        } finally {
            Files.deleteIfExists(file)
        }
    }

    private fun protoMessage(vararg fields: ByteArray): ByteArray = fields.flatMap { it.asList() }.toByteArray()
    private fun fieldString(field: Int, value: String): ByteArray = fieldBytes(field, value.toByteArray(Charsets.UTF_8))
    private fun fieldBytes(field: Int, value: ByteArray): ByteArray = tag(field, 2) + varint(value.size.toLong()) + value
    private fun fieldVarint(field: Int, value: Long): ByteArray = tag(field, 0) + varint(value)
    private fun fieldFixed32(field: Int, value: Int): ByteArray = tag(field, 5) + byteArrayOf(value.toByte(), (value ushr 8).toByte(), (value ushr 16).toByte(), (value ushr 24).toByte())
    private fun tag(field: Int, wire: Int): ByteArray = varint(((field shl 3) or wire).toLong())
    private fun varint(value: Long): ByteArray {
        var v = value
        val out = ArrayList<Byte>()
        while (true) {
            if ((v and 0x7f.inv().toLong()) == 0L) { out += v.toByte(); return out.toByteArray() }
            out += ((v and 0x7f) or 0x80).toByte()
            v = v ushr 7
        }
    }
}
