package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexFriendRequestFailureTest {
    @Test fun offlineMessageIsRetryable() {
        assertTrue(RovexFriendRequestFailure.shouldQueue(IllegalStateException("Failed to get document because the client is offline.")))
    }

    @Test fun permissionDeniedIsNotRetryable() {
        assertFalse(RovexFriendRequestFailure.shouldQueueFirestoreCode("PERMISSION_DENIED"))
    }

    @Test fun unknownIdMessageIsNotRetryable() {
        assertFalse(RovexFriendRequestFailure.shouldQueue(IllegalArgumentException("Rovex ID not found")))
    }

    @Test fun genericFirestoreFailureTextIsNotAutomaticallyQueued() {
        assertFalse(RovexFriendRequestFailure.shouldQueue(IllegalStateException("Failed to get document because the request was rejected.")))
    }
}
