package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexFriendRequestStateTest {
    @Test fun normalizesAndValidatesRovexIds() {
        assertTrue(RovexFriendRequestState.isValidCode(" rvx-abcd-1234 "))
        assertFalse(RovexFriendRequestState.isValidCode("RVX-ABC-1234"))
        assertFalse(RovexFriendRequestState.isValidCode("RVX-ABCD-12345"))
    }
}
