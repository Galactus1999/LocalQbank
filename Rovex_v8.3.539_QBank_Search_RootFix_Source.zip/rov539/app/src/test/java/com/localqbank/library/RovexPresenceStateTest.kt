package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexPresenceStateTest {
    @Test fun anyFreshOnlineConnectionMakesUserOnline() {
        val state = RovexPresenceState.derive(listOf(
            RovexPresenceState.Connection(false, 100L),
            RovexPresenceState.Connection(true, 200L)
        ), nowMillis = 250L, onlineTtlMillis = 90_000L)
        assertTrue(state.online)
        assertNull(state.lastSeenMillis)
    }

    @Test fun latestOfflineConnectionDeterminesLastSeen() {
        val state = RovexPresenceState.derive(listOf(
            RovexPresenceState.Connection(false, 100L),
            RovexPresenceState.Connection(false, 300L),
            RovexPresenceState.Connection(false, 200L)
        ), nowMillis = 400L, onlineTtlMillis = 90_000L)
        assertFalse(state.online)
        assertEquals(300L, state.lastSeenMillis)
    }

    @Test fun staleOnlineConnectionIsTreatedAsOffline() {
        val state = RovexPresenceState.derive(
            listOf(RovexPresenceState.Connection(true, 1_000L)),
            nowMillis = 100_001L,
            onlineTtlMillis = 90_000L
        )
        assertFalse(state.online)
        assertEquals(1_000L, state.lastSeenMillis)
    }

    @Test fun freshOnlineConnectionRemainsOnline() {
        val state = RovexPresenceState.derive(
            listOf(RovexPresenceState.Connection(true, 50_000L)),
            nowMillis = 100_000L,
            onlineTtlMillis = 90_000L
        )
        assertTrue(state.online)
        assertNull(state.lastSeenMillis)
    }

    @Test fun staleAndFreshMultiDeviceConnectionsKeepUserOnline() {
        val state = RovexPresenceState.derive(listOf(
            RovexPresenceState.Connection(true, 1_000L),
            RovexPresenceState.Connection(true, 95_000L),
            RovexPresenceState.Connection(false, 96_000L)
        ), nowMillis = 100_000L, onlineTtlMillis = 90_000L)
        assertTrue(state.online)
        assertNull(state.lastSeenMillis)
    }

    @Test fun emptyPresenceIsOfflineWithoutLastSeen() {
        val state = RovexPresenceState.derive(emptyList())
        assertFalse(state.online)
        assertNull(state.lastSeenMillis)
    }
}
