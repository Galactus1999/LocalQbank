package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class QBankSearchSqlTest {
    @Test
    fun escapeLikeEscapesBackslashPercentAndUnderscoreInOrder() {
        assertEquals("acid\\%base\\_literal\\\\literal", QBankSearchSql.escapeLike("acid%base_literal\\literal"))
    }

    @Test
    fun ordinaryTextRemainsUnchanged() {
        assertEquals("acid base", QBankSearchSql.escapeLike("acid base"))
    }

    @Test
    fun likePatternAddsOnlyOuterWildcards() {
        assertEquals("%acid\\%base%", QBankSearchSql.likePattern("acid%base"))
    }
}
