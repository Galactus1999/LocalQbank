package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class RovexDailyNotificationContentTest {
    @Test fun quoteIsDeterministicForSameDay() {
        val day = java.time.LocalDate.of(2026, 9, 25)
        assertEquals(RovexDailyNotificationContent.quoteFor(day), RovexDailyNotificationContent.quoteFor(day))
    }

    @Test fun adjacentDaysNormallyAdvanceQuote() {
        val a = java.time.LocalDate.of(2026, 9, 25)
        val b = a.plusDays(1)
        assertNotEquals(RovexDailyNotificationContent.quoteFor(a), RovexDailyNotificationContent.quoteFor(b))
    }

    @Test fun quoteLibraryIsLargeEnoughForARealDailyRotation() {
        assertTrue(RovexDailyNotificationContent.quoteCount() in 450..700)
    }

    @Test fun morningAndEveningProvideOneDeterministicQuoteEach() {
        val day = java.time.LocalDate.of(2026, 10, 2)
        val morning = RovexDailyNotificationContent.quoteForSlot(day, RovexDailyNotificationContent.MotivationSlot.MORNING)
        val evening = RovexDailyNotificationContent.quoteForSlot(day, RovexDailyNotificationContent.MotivationSlot.EVENING)
        assertTrue(morning.isNotBlank())
        assertTrue(evening.isNotBlank())
        assertNotEquals(morning, evening)
    }

    @Test fun homeQuoteSwitchesAtSevenAndSeventeenLocalTime() {
        val zone = ZoneId.of("Asia/Kolkata")
        val beforeSeven = ZonedDateTime.of(2026, 10, 2, 6, 59, 59, 0, zone)
        val atSeven = ZonedDateTime.of(2026, 10, 2, 7, 0, 0, 0, zone)
        val beforeFive = ZonedDateTime.of(2026, 10, 2, 16, 59, 59, 0, zone)
        val atFive = ZonedDateTime.of(2026, 10, 2, 17, 0, 0, 0, zone)
        assertEquals(RovexDailyNotificationContent.quoteForSlot(java.time.LocalDate.of(2026, 10, 1), RovexDailyNotificationContent.MotivationSlot.EVENING), RovexDailyNotificationContent.quoteForNow(beforeSeven))
        assertEquals(RovexDailyNotificationContent.quoteForSlot(java.time.LocalDate.of(2026, 10, 2), RovexDailyNotificationContent.MotivationSlot.MORNING), RovexDailyNotificationContent.quoteForNow(atSeven))
        assertEquals(RovexDailyNotificationContent.quoteForSlot(java.time.LocalDate.of(2026, 10, 2), RovexDailyNotificationContent.MotivationSlot.MORNING), RovexDailyNotificationContent.quoteForNow(beforeFive))
        assertEquals(RovexDailyNotificationContent.quoteForSlot(java.time.LocalDate.of(2026, 10, 2), RovexDailyNotificationContent.MotivationSlot.EVENING), RovexDailyNotificationContent.quoteForNow(atFive))
    }

    @Test fun nextTriggerMovesToTomorrowWhenTimeAlreadyPassed() {
        val now = ZonedDateTime.of(2026, 9, 25, 20, 30, 0, 0, ZoneId.of("Asia/Kolkata"))
        val delay = RovexDailyNotificationContent.nextTriggerMillis(now, 20, 0)
        assertTrue(delay > 23L * 60L * 60L * 1000L)
    }

    @Test fun nextTriggerStaysWithinOneDay() {
        val now = ZonedDateTime.of(2026, 9, 25, 7, 30, 0, 0, ZoneId.of("Asia/Kolkata"))
        val delay = RovexDailyNotificationContent.nextTriggerMillis(now, 17, 0)
        assertTrue(delay in 9L * 60L * 60L * 1000L..10L * 60L * 60L * 1000L)
    }
}
