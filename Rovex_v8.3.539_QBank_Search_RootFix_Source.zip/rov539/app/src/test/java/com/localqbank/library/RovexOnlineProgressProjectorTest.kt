package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class RovexOnlineProgressProjectorTest {
    @Test
    fun projectsAnsweredAccuracyTodayCardsAndXp() {
        val now = 1_760_000_000_000L
        val today = now - 60_000L
        val progress = ProgressSnapshot.from(
            mapOf(
                "a:status" to "correct", "a:lastAttempted" to today,
                "b:status" to "wrong", "b:lastAttempted" to today,
                "c:status" to "correct", "c:lastAttempted" to (now - 86_400_000L),
                "d:status" to "", "d:lastAttempted" to now
            )
        )
        val p = RovexOnlineProgressProjector.from(
            progress,
            flashcardsReviewed = 4,
            streak = StreakManager.Snapshot(currentStreak = 3, longestStreak = 7),
            nowMillis = now
        )
        assertEquals(3, p.questionsSolved)
        assertEquals(2, p.correct)
        assertEquals(66, p.accuracyPercent)
        assertEquals(2, p.todaySolved)
        assertEquals(4, p.flashcardsReviewed)
        assertEquals(3, p.currentStreak)
        assertEquals(7, p.longestStreak)
        assertEquals(80L, p.xp)
    }

    @Test
    fun emptyProjectionIsZeroAndNeverNegative() {
        val p = RovexOnlineProgressProjector.from(
            ProgressSnapshot.empty(),
            flashcardsReviewed = -5,
            streak = StreakManager.Snapshot(currentStreak = -1, longestStreak = -2),
            nowMillis = 1_760_000_000_000L
        )
        assertEquals(0, p.questionsSolved)
        assertEquals(0, p.correct)
        assertEquals(0, p.accuracyPercent)
        assertEquals(0, p.todaySolved)
        assertEquals(0, p.flashcardsReviewed)
        assertEquals(0, p.currentStreak)
        assertEquals(0, p.longestStreak)
        assertEquals(0L, p.xp)
    }
}
