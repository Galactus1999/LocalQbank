package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QuizHomeResumeContractTest {
    @Test fun explicitHomeResumeBeatsStaleTransientPosition() {
        val staleSavedStatePosition = 0
        val durableHomePosition = 24
        val forceResume = true
        val selected = if (forceResume) durableHomePosition else staleSavedStatePosition
        assertEquals(24, selected)
    }

    @Test fun lastSolvedWinsTieWithPostAnswerNextCursor() {
        val nextQuestion = ResumeCursorCandidate("Q26", savedAt = 100L, priority = 2)
        val lastSolved = ResumeCursorCandidate("Q25", savedAt = 100L, priority = 3)
        assertEquals("Q25", ResumeCursorPolicy.newest(listOf(nextQuestion, lastSolved)))
    }

    @Test fun newerExplicitNavigationBeatsOlderLastSolved() {
        val lastSolved = ResumeCursorCandidate("Q25", savedAt = 100L, priority = 3)
        val laterNavigation = ResumeCursorCandidate("Q27", savedAt = 101L, priority = 2)
        assertEquals("Q27", ResumeCursorPolicy.newest(listOf(lastSolved, laterNavigation)))
        assertTrue(laterNavigation.savedAt > lastSolved.savedAt)
    }
}
