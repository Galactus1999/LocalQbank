package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexFriendRequestIntentTest {
    @Test fun validCodeIsAccepted() {
        assertTrue(RovexFriendRequestState.isValidCode("RVX-ABCD-1234"))
    }

    @Test fun malformedCodeIsRejected() {
        assertFalse(RovexFriendRequestState.isValidCode("RVX-ABC-1234"))
        assertFalse(RovexFriendRequestState.isValidCode("RVX-ABCD-12345"))
    }
}
