package com.localqbank.library

import android.content.Context
import android.view.View
import android.view.ViewGroup

/**
 * Owns the UI-side completion of an already-persisted quiz answer.
 *
 * This is a move-only extraction: durable answer submission remains in
 * QuizAnswerInteractionController/QuizAnswerUseCase. This controller only coordinates
 * post-acceptance study events, resume cursor, haptic/audio feedback, milestone celebration,
 * and the existing answered-in-place rendering callbacks.
 */
class QuizAnswerFeedbackController(
    private val context: Context,
    private val quizViewModel: QuizViewModel,
    private val content: () -> ViewGroup,
    private val decorView: () -> View,
    private val requestStudyNotificationPermission: () -> Unit,
    private val triggerMilestone: (String) -> Boolean,
    private val showAnswered: (Question, String, Boolean) -> Unit,
    private val disableOptions: () -> Unit
) {
    fun handleAcceptedAnswer(q: Question, label: String, outcome: QuizAnswerUseCase.Result) {
        try {
            if (!quizViewModel.state.examMode) {
                StudyEventSpine.publishAsync(StudyEventSpine.Event(
                    "quiz_completed", outcome.stableKey, "quiz",
                    metadata = mapOf("correct" to outcome.correct.toString())
                ))
                resultOf { requestStudyNotificationPermission() }
            }
            if (quizViewModel.state.examMode) {
                quizViewModel.recordExamAnswer(q.stableKey, outcome.correct)
                quizViewModel.setPracticeAnsweredKey(q.stableKey)
            } else {
                quizViewModel.setPracticeAnsweredKey(
                    if (quizViewModel.state.practiceMode) q.stableKey else null
                )
            }
            val current = quizViewModel.state.position
            val next = QuizResumePolicy.afterAnswer(current, quizViewModel.state.questionCount)
            quizViewModel.setResumeCursor(next, null)
            content().performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)

            val milestoneTriggered = triggerMilestone(label)
            val plan = RovexCelebrationPreferences.load(context)
            if (milestoneTriggered && plan.sound) {
                RovexSoundFeedback.playMilestone(context)
            } else {
                RovexSoundFeedback.playClick(context)
            }
            showAnswered(q, label, outcome.correct)
        } catch (e: Exception) {
            ProductionCrashReporter.recordNonFatal(
                e,
                "QUIZ_ANSWER_UI",
                mapOf("question_key" to q.stableKey.take(120))
            )
            disableOptions()
            RovexUndoSnackbar.show(
                decorView(),
                "Answer saved, but feedback could not be rendered. Continue studying."
            )
        }
    }
}
