package com.localqbank.library

/**
 * Verbatim move of QuizActivity's fullscreen-image WebView render-process client.
 *
 * Move-only refactor: rendering/recovery behavior intentionally remains unchanged.
 */
class QuizFullscreenImageWebViewClient(
    private val onRenderProcessGoneAction: () -> Unit
) : RovexSafeWebViewClient() {
    override fun onRenderProcessGone(
        view: android.webkit.WebView?,
        detail: android.webkit.RenderProcessGoneDetail?
    ): Boolean {
        resultOf {
            view?.let {
                (it.parent as? android.view.ViewGroup)?.removeView(it)
                it.destroy()
            }
        }
        onRenderProcessGoneAction()
        return true
    }
}
