package com.localqbank.library

/**
 * Pure SQLite LIKE helpers used by QBank search paths.
 *
 * This class deliberately has no Android/Context/SQLite dependency so the escaping contract
 * can be tested on the JVM before changing QBankDb search implementation.
 */
internal object QBankSearchSql {
    const val LIKE_ESCAPE_SQL = "ESCAPE CHAR(92)"

    fun escapeLike(value: String): String =
        value.replace("\\", "\\\\")
            .replace("%", "\\%")
            .replace("_", "\\_")

    fun likePattern(value: String): String = "%${escapeLike(value)}%"
}
