package com.localqbank.library

import android.content.Context
import android.graphics.Color
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Owns the primary question-image rendering flow used by QuizActivity.
 * Move-only extraction from QuizActivity: image HTML, WebView configuration,
 * tap/long-press behavior, visible My Notes action, and relative-image URL
 * handling are intentionally preserved without introducing business ownership.
 */
class QuizImageController(
    private val context: Context,
    private val dp: (Int) -> Int,
    private val rounded: (Int, Float) -> android.graphics.drawable.GradientDrawable,
    private val readableForeground: (Int) -> Int,
    private val currentQuestion: () -> Question?,
    private val onFullscreenRequested: (String) -> Unit,
    private val onSaveImageRequested: (String, Question) -> Unit,
    private val onSaveImageWithNoteRequested: (String, Question) -> Unit
) {
    fun addImage(uri: String, host: ViewGroup) {
        val raw = uri.trim()
        if (raw.isBlank()) return
        val imageTag = "rovex-image:$raw"
        for (i in 0 until host.childCount) if (host.getChildAt(i).tag == imageTag) return
        val web = WebView(context).apply {
            tag = imageTag
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = false
            settings.domStorageEnabled = false
            settings.loadsImagesAutomatically = true
            settings.blockNetworkImage = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            // QBank exports commonly contain legacy HTTP image URLs.
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            webViewClient = QuizImageFitWebViewClient()
        }
        var imageDownAt = 0L
        web.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { imageDownAt = System.currentTimeMillis(); false }
                MotionEvent.ACTION_UP -> {
                    if (System.currentTimeMillis() - imageDownAt < 650L) onFullscreenRequested(raw)
                    false
                }
                else -> false
            }
        }
        web.setOnLongClickListener {
            currentQuestion()?.let { q -> onSaveImageRequested(raw, q) }
            true
        }
        host.addView(web, LinearLayout.LayoutParams(-1, dp(300)).apply { setMargins(0, dp(2), 0, dp(2)) })
        // Saving an image + personal cue belongs to My Notes, not the Knowledge Vault.
        // Keep this action visible so the user does not have to discover long-press behavior.
        val saveFill = if (ThemeManager.isDark(context)) Color.rgb(255, 219, 118) else Color.rgb(255, 240, 188)
        // Keep the foreground contrast-safe even if a custom/theme transition changes the
        // dialog palette underneath this view; never leave dark text on a dark action surface.
        val saveFg = readableForeground(saveFill)
        val saveToNotes = TextView(context).apply {
            text = "SAVE IMAGE + NOTE  →  MY NOTES"
            textSize = 11.5f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = android.view.Gravity.CENTER
            setTextColor(saveFg)
            background = rounded(saveFill, 12f)
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { currentQuestion()?.let { q -> onSaveImageWithNoteRequested(raw, q) } }
            contentDescription = "Save image and note to My Notes"
        }
        host.addView(saveToNotes, LinearLayout.LayoutParams(-1, dp(38)).apply { setMargins(dp(2), 0, dp(2), dp(8)) })
        val relation = QuizImageUriResolver.parseRelativeImage(raw)
        val imageSrc = relation?.second ?: raw
        val baseUrl = when {
            relation != null -> relation.first
            raw.startsWith("data:image", true) -> "https://rovex.local/"
            raw.startsWith("http://", true) || raw.startsWith("https://", true) -> raw
            else -> raw.substringBeforeLast('/', raw)
        }
        val safeSrc = android.text.TextUtils.htmlEncode(imageSrc)
        val html = """
            <!doctype html><html><head>
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <style>html,body{margin:0;padding:0;background:transparent;overflow:hidden}img{display:block;max-width:100%;width:auto;height:auto;margin:0 auto}</style>
            </head><body><img src="$safeSrc" alt="Question image"></body></html>
        """.trimIndent()
        web.loadDataWithBaseURL(baseUrl, html, "text/html", "UTF-8", null)
    }
}
