package com.localqbank.library

import android.util.Log

/** Lightweight render-path measurement; never owns chat state or rendering policy. */
object RovexChatRenderTelemetry {
    private const val TAG = "Rovex.ChatRender"
    private const val SLOW_RENDER_MS = 120L
    private const val LARGE_MESSAGE_CHARS = 12_000

    fun record(renderMs: Long, chars: Int, latest: Boolean) {
        if (renderMs >= SLOW_RENDER_MS || chars >= LARGE_MESSAGE_CHARS || !latest) {
            Log.i(TAG, "MARKDOWN_RENDER ms=$renderMs chars=$chars latest=$latest")
        }
    }
}
