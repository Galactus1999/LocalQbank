package com.localqbank.library

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.QuerySnapshot
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Firestore-backed realtime presence boundary.
 *
 * Firestore remains authoritative for identity/friendship/presence. Each installation owns one
 * connection document. Foreground heartbeats keep online state fresh; stale online records are
 * treated as offline by the pure reducer. This avoids a Cloud Function/RTDB ACL dependency while
 * preserving friend-only reads through Firestore security rules.
 */
object RovexPresenceManager : DefaultLifecycleObserver {
    private const val PREFS = "rovex_presence"
    private const val KEY_CONNECTION_ID = "connection_id"
    private const val HEARTBEAT_MS = 30_000L
    private const val ONLINE_TTL_MS = 90_000L

    data class PresenceState(val online: Boolean, val lastSeenMillis: Long?)
    data class Subscription(val registration: ListenerRegistration)

    private var appContext: Context? = null
    private var connectionRef: DocumentReference? = null
    private val installed = AtomicBoolean(false)
    private val handler = Handler(Looper.getMainLooper())
    private var foreground = false
    private val heartbeat = object : Runnable {
        override fun run() {
            if (!foreground) return
            writePresence("online")
            handler.postDelayed(this, HEARTBEAT_MS)
        }
    }

    fun install(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        appContext = context.applicationContext
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        FirebaseAuth.getInstance().addAuthStateListener { auth ->
            if (foreground) {
                stopPresence()
                if (auth.currentUser != null) startPresence()
            }
        }
        if (ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) {
            foreground = true
            startPresence()
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        foreground = true
        startPresence()
    }

    override fun onStop(owner: LifecycleOwner) {
        foreground = false
        stopPresence()
    }

    private fun connectionId(): String {
        val prefs = appContext!!.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_CONNECTION_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString().replace("-", "")
        prefs.edit().putString(KEY_CONNECTION_ID, created).apply()
        return created
    }

    @Synchronized
    private fun startPresence() {
        val user = FirebaseAuth.getInstance().currentUser ?: return
        if (connectionRef != null) return
        val ref = FirebaseFirestore.getInstance()
            .collection("users").document(user.uid)
            .collection("presence").document(connectionId())
        connectionRef = ref
        writePresence("online")
        handler.removeCallbacks(heartbeat)
        handler.postDelayed(heartbeat, HEARTBEAT_MS)
    }

    @Synchronized
    private fun stopPresence() {
        handler.removeCallbacks(heartbeat)
        val ref = connectionRef ?: return
        connectionRef = null
        if (FirebaseAuth.getInstance().currentUser?.uid != ref.parent.parent?.id) return
        ref.set(offlineData())
    }

    private fun writePresence(state: String) {
        val ref = connectionRef ?: return
        val user = FirebaseAuth.getInstance().currentUser ?: return
        if (ref.parent.parent?.id != user.uid) return
        ref.set(mapOf(
            "state" to state,
            "lastChanged" to FieldValue.serverTimestamp(),
            "platform" to "android"
        ))
    }

    private fun offlineData(): Map<String, Any> = mapOf(
        "state" to "offline",
        "lastChanged" to FieldValue.serverTimestamp(),
        "platform" to "android"
    )

    fun observeFriend(
        uid: String,
        onState: (PresenceState) -> Unit,
        onError: (Throwable) -> Unit = {}
    ): Subscription {
        val ref = FirebaseFirestore.getInstance()
            .collection("users").document(uid).collection("presence")
            .orderBy("lastChanged", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(32)
        val listener = EventListener<QuerySnapshot> { snapshot, error ->
            if (error != null) {
                onError(error)
                return@EventListener
            }
            val now = System.currentTimeMillis()
            val connections = snapshot?.documents.orEmpty().map { doc ->
                RovexPresenceState.Connection(
                    online = doc.getString("state") == "online",
                    lastChangedMillis = doc.getTimestamp("lastChanged")?.toDate()?.time
                )
            }
            val state = RovexPresenceState.derive(connections, now, ONLINE_TTL_MS)
            onState(PresenceState(state.online, state.lastSeenMillis))
        }
        val registration = ref.addSnapshotListener(listener)
        return Subscription(registration)
    }
}
