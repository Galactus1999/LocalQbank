package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Presentation-only controller for QuizActivity mistake/note/AI dialogs.
 *
 * This is a move-only extraction: dialog content, callbacks, and sequencing remain
 * behaviorally equivalent to the former QuizActivity implementations.
 */
internal class QuizDialogController(
    private val context: Context,
    private val quizViewModel: QuizViewModel,
    private val dp: (Int) -> Int,
    private val rounded: (Int, Float) -> GradientDrawable,
    private val showQuestion: () -> Unit,
    private val openAiQuestionContext: (Question) -> Unit,
    private val postToMain: ((() -> Unit) -> Unit),
    private val isHostFinishing: () -> Boolean
) {

    fun showMistakeTypeDialog(q: Question) {
        val choices = listOf(
            "Didn't know" to "The concept or fact was not in recall.",
            "Concept confusion" to "I knew related facts but mixed the underlying concept.",
            "Misread question" to "The stem, qualifier, image or wording was misread.",
            "Silly mistake" to "I knew it, but made an avoidable error.",
            "Changed correct answer" to "The first answer was right; I changed it incorrectly.",
            "Time pressure" to "Time pressure caused the wrong response."
        )
        val current=quizViewModel.mistakeType(q.stableKey)
        val dialog=Dialog(context)
        val root=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(16),dp(18),dp(16));background=GradientDrawable().apply{setColor(ThemeManager.dialogBg(context));cornerRadius=dp(24).toFloat()}}
        val head=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        head.addView(RovexWaveTextView(context).apply{text="Why did I miss this?";textSize=20f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(context))},LinearLayout.LayoutParams(0,dp(44),1f))
        head.addView(TextView(context).apply{text="×";textSize=25f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(context));background=rounded(ThemeManager.elevated(context),14f);setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(dp(44),dp(44)))
        root.addView(head)
        root.addView(TextView(context).apply{text="Tag the reason so Rovex can build a targeted collection for revision.";textSize=11.5f;setTextColor(ThemeManager.muted(context));setPadding(0,dp(2),0,dp(10))})
        choices.forEachIndexed{idx,pair->
            val selected=pair.first.equals(current,true)
            val card=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(10),dp(13),dp(10));background=GradientDrawable().apply{setColor(if(selected)ThemeManager.pastelAccentFill(context,idx) else ThemeManager.elevated(context));cornerRadius=dp(15).toFloat();setStroke(dp(1),if(selected)ThemeManager.pastelAccentText(context,idx) else Color.argb(45,100,120,140))};setOnClickListener{quizViewModel.setMistakeType(q.stableKey,pair.first);dialog.dismiss();showQuestion()}}
            card.addView(TextView(context).apply{text=pair.first;textSize=14.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(if(selected)ThemeManager.pastelAccentText(context,idx) else ThemeManager.text(context))})
            card.addView(TextView(context).apply{text=pair.second;textSize=11f;setTextColor(if(selected)ThemeManager.pastelAccentText(context,idx) else ThemeManager.muted(context));setPadding(0,dp(3),0,0)})
            root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        dialog.setContentView(root);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show();dialog.window?.setLayout((context.resources.displayMetrics.widthPixels*.92f).toInt(),-2);AdaptiveTypographyManager.apply(root)
    }

    fun showNoteEditor(q:Question){
        // Note reads are SQLite I/O; load the editor value off the UI thread so opening the
        // dialog cannot stall input during a busy QBank session.
        quizViewModel.noteAsync(q.id) { value ->
            postToMain {
                if (isHostFinishing()) return@postToMain
                val input=EditText(context).apply{setText(value.orEmpty());setSelection(text.length);setHint("Your memory cue, trap, or mnemonic");inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;minLines=4;setPadding(dp(12),dp(10),dp(12),dp(10))}
                val box=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(4),dp(8),0)};box.addView(input,LinearLayout.LayoutParams(-1,dp(150)))
                AlertDialog.Builder(context).setTitle("Note for this question").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->quizViewModel.saveNote(q.id,input.text.toString().trim());Toast.makeText(context,"Note saved",Toast.LENGTH_SHORT).show()}.show()
            }
        }
    }

    fun saveAiResponseToNotes(questionId: Long, content: String) {
        quizViewModel.saveNote(questionId, content.trim())
    }

    fun showAiQuestionContext(q: Question) {
        openAiQuestionContext(q)
    }
}
