package com.localqbank.library

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Behavior-preserving bitmap decode helpers extracted from the quiz screen. */
object QuizImageDecoder {
    fun decodeScaledImage(value: String, maxW: Int, maxH: Int, contentResolver: ContentResolver): Bitmap? {
        var uri = value.trim().replace("\\/", "/").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        if (uri.startsWith("rovex-rel://image?", true)) return null
        if (uri.startsWith("url(", true)) uri = uri.substringAfter('(').substringBeforeLast(')').trim().trim('"', '\'')
        if (uri.startsWith("//")) uri = "https:" + uri
        if (uri.startsWith("data:image", true)) {
            val comma = uri.indexOf(',')
            if (comma < 0) return null
            val payload = uri.substring(comma + 1)
            // Stream-decode the Base64 image twice: first for dimensions, then at the
            // calculated sample size. Never materialise the full decoded image byte[];
            // large QBank images are a common source of process-death/OOM on phones.
            fun stream() = android.util.Base64InputStream(payload.byteInputStream(Charsets.US_ASCII), android.util.Base64.DEFAULT)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            stream().use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val opts = BitmapFactory.Options().apply {
                inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, maxW, maxH)
                inPreferredConfig = Bitmap.Config.RGB_565
                inDither = true
            }
            return stream().use { BitmapFactory.decodeStream(it, null, opts) }
        }
        val parsed = Uri.parse(uri)
        fun open(): InputStream? = when (parsed.scheme?.lowercase()) {
            "https", "http" -> {
                val c = (URL(uri).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000
                    readTimeout = 20000
                    instanceFollowRedirects = true
                    useCaches = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android ${android.os.Build.VERSION.RELEASE}) AppleWebKit/537.36 Chrome/140.0 Mobile Safari/537.36")
                    setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
                    setRequestProperty("Accept-Encoding", "identity")
                    setRequestProperty("Connection", "close")
                }
                if (c.responseCode !in 200..299) { c.disconnect(); null } else c.inputStream
            }
            "content", "file" -> contentResolver.openInputStream(parsed)
            else -> null
        }
        // For file/content/network images, also avoid readBytes(): bounds are read first,
        // then the stream is reopened and decoded at the required sample size.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options().apply {
            inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, maxW, maxH)
            inPreferredConfig = Bitmap.Config.RGB_565
            inDither = true
        }
        return open()?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    fun calculateSample(w: Int, h: Int, maxW: Int, maxH: Int): Int {
        var sample = 1
        while (w / (sample * 2) >= maxW && h / (sample * 2) >= maxH) sample *= 2
        while (w / sample > maxW * 2 || h / sample > maxH * 2) sample *= 2
        return sample.coerceAtLeast(1)
    }

    fun decodeBytes(data: ByteArray, maxW: Int, maxH: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxW || bounds.outHeight / sample > maxH) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize=sample; inPreferredConfig=Bitmap.Config.RGB_565; inScaled=true }
        return BitmapFactory.decodeByteArray(data, 0, data.size, opts)
    }
}
