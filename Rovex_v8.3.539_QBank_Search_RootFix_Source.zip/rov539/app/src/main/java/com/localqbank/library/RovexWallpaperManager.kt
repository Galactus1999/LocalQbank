package com.localqbank.library

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** User-owned local wallpaper. The selected image is copied into app-private storage. */
object RovexWallpaperManager {
    private const val PREFS = "rovex_wallpaper"
    private const val KEY_ENABLED = "enabled"
    private const val FILE_NAME = "rovex_wallpaper.jpg"
    private const val MAX_EDGE = 1440
    @Volatile private var cached: Bitmap? = null
    private val loading = AtomicBoolean(false)

    fun isEnabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false) && file(context).exists()

    fun file(context: Context): File = File(context.applicationContext.filesDir, FILE_NAME)

    /** Returns a process-cached, bounded bitmap. The persisted image is deliberately downsampled. */
    fun bitmap(context: Context): Bitmap? {
        if (!isEnabled(context)) return null
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val b = runCatching { BitmapFactory.decodeFile(file(context).absolutePath) }.getOrNull()
            if (b != null) cached = b
            return b
        }
    }


    fun preload(context: Context) {
        val app = context.applicationContext
        if (!isEnabled(app) || cached != null || !loading.compareAndSet(false, true)) return
        PerformanceManager.submit {
            runCatching { BitmapFactory.decodeFile(file(app).absolutePath) }.getOrNull()?.let { synchronized(this) { cached = it } }
            loading.set(false)
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (cached != null && AppManagers.isReady()) AppState.changed("wallpaper_loaded")
            }
        }
    }

    fun setFromUri(context: Context, uri: Uri, onComplete: (Boolean) -> Unit) {
        val app = context.applicationContext
        if (!loading.compareAndSet(false, true)) { onComplete(false); return }
        PerformanceManager.submit {
            val ok = runCatching {
                val resolver = app.contentResolver
                val bounds = resolver.openInputStream(uri)?.use {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeStream(it, null, o); o
                } ?: error("Unable to inspect wallpaper")
                val sample = sampleSize(bounds.outWidth, bounds.outHeight)
                val decoded = resolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 })
                } ?: error("Unable to decode wallpaper")
                val scaled = scale(decoded)
                if (scaled !== decoded) decoded.recycle()
                val tmp = File(app.filesDir, "$FILE_NAME.tmp")
                FileOutputStream(tmp).use { out ->
                    check(scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)) { "Wallpaper compression failed" }
                }
                val destination = file(app)
                if (destination.exists()) destination.delete()
                check(tmp.renameTo(destination)) { "Wallpaper commit failed" }
                synchronized(this) { cached = scaled }
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, true).apply()
                true
            }.getOrDefault(false)
            loading.set(false)
            android.os.Handler(android.os.Looper.getMainLooper()).post { onComplete(ok) }
        }
    }

    fun clear(context: Context) {
        val app = context.applicationContext
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply()
        synchronized(this) { cached = null }
        file(app).delete()
    }

    private fun sampleSize(w: Int, h: Int): Int {
        var sample = 1
        while (w / sample > MAX_EDGE * 2 || h / sample > MAX_EDGE * 2) sample *= 2
        return sample.coerceAtLeast(1)
    }

    private fun scale(source: Bitmap): Bitmap {
        val max = maxOf(source.width, source.height)
        if (max <= MAX_EDGE) return source
        val scale = MAX_EDGE.toFloat() / max.toFloat()
        return Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true)
    }
}
