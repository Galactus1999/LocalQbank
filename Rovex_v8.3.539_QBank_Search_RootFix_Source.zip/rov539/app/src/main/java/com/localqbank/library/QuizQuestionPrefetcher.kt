package com.localqbank.library

/**
 * Move-only owner for the existing bounded next-question prefetch path.
 *
 * This class deliberately contains no UI or Activity reference. The Activity owns
 * the LifecycleExecutor and cache lifecycle; this controller only schedules the
 * same existing cache-fill work.
 */
class QuizQuestionPrefetcher(
    private val quizViewModel: QuizViewModel,
    private val executor: LifecycleExecutor,
    private val cache: MutableMap<String, Question>
) {
    fun prefetch() {
        // Adaptive controller may safely choose a rolling window of 1..3 questions.
        val depth = if (AppManagers.isReady()) PerformanceManager.effectivePrefetchDepth() else 2
        val targets = (1..depth)
            .map { quizViewModel.state.position + it }
            .filter { it < quizViewModel.state.questionCount }
        if (targets.isEmpty()) return
        executor.execute {
            targets.forEach { target ->
                resultOf {
                    val key = if (quizViewModel.state.collectionMode) {
                        "id:${quizViewModel.state.collectionQuestionIds.getOrNull(target) ?: return@forEach}"
                    } else {
                        "${quizViewModel.state.testId}:$target"
                    }
                    synchronized(cache) { if (cache.containsKey(key)) return@resultOf }
                    val q = if (quizViewModel.state.collectionMode) {
                        quizViewModel.state.collectionQuestionIds.getOrNull(target)?.let { quizViewModel.questionById(it) }
                    } else {
                        quizViewModel.questionAt(quizViewModel.state.testId, target)
                    }
                    if (q != null) synchronized(cache) { cache[key] = q }
                }
            }
        }
    }
}
