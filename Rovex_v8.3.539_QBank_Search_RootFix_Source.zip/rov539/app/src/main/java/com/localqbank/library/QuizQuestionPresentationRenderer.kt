package com.localqbank.library

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Move-only presentation extraction from QuizActivity.show(). */
class QuizQuestionPresentationRenderer(
    private val context: Context,
    private val content: ViewGroup,
    private val fontScale: Float,
    private val fontFamily: String,
    private val dp: (Int) -> Int,
    private val rounded: (Int, Float) -> android.graphics.drawable.Drawable,
    private val questionColor: Int,
    private val aiTextColor: Int,
    private val explanationBg: Int,
    private val explanationTitleColor: Int,
    private val explanationTextColor: Int,
    private val accentColor: Int,
    private val backgroundDrawable: android.graphics.drawable.Drawable,
    private val addHtmlText: (String?, Float, Boolean, Int?, Long?, String) -> Unit,
    private val addImage: (String) -> Unit,
    private val optionCard: (Question, Option, Boolean) -> Unit,
    private val mistakeType: (String) -> String?,
    private val showMistakeTypeDialog: (Question) -> Unit,
    private val showAiQuestionContext: (Question) -> Unit,
    private val hideResult: () -> Unit
) {
    fun render(q: Question, status: String?, answered: Boolean, examMode: Boolean) {
        addHtmlText(q.text, 20f * fontScale, true, questionColor, null, "question")
        q.questionImages.forEach(addImage)

        val aiContext = RovexColorFlowTextView(context).apply {
            tag = "quiz:ai"
            text = "✦  BEN + AI • EXAM CONTEXT"
            textSize = 11.5f * fontScale
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(aiTextColor)
            background = rounded(explanationBg, 14f)
            contentDescription = "Get Ben and AI context for this question"
            setPadding(dp(10), dp(9), dp(10), dp(9))
            setOnClickListener { showAiQuestionContext(q) }
        }
        content.addView(aiContext, LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, dp(10), 0, dp(8)) })
        q.options.forEach { optionCard(q, it, answered) }

        hideResult()
        if (answered && !examMode) {
            if (status == "wrong") {
                val why = TextView(context).apply {
                    text = mistakeType(q.stableKey)?.let { "Why I missed it: $it  •  Tap to change" } ?: "🧠 Why did I miss this?"
                    textSize = 12.5f * fontScale
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(accentColor)
                    setPadding(dp(4), dp(10), dp(4), dp(4))
                    setOnClickListener { showMistakeTypeDialog(q) }
                }
                content.addView(why, LinearLayout.LayoutParams(-1, -2))
            }
            val explanationPanel = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(4))
                background = rounded(explanationBg, 16f)
            }
            val explanationTitle = TextView(context).apply {
                text = "EXPLANATION"
                textSize = 12.5f * fontScale
                setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
                setTextColor(explanationTitleColor)
                setLetterSpacing(0.06f)
            }
            explanationPanel.addView(explanationTitle, LinearLayout.LayoutParams(-1, dp(28)))
            val answerAiContext = RovexColorFlowTextView(context).apply {
                tag = "quiz:ai"
                text = "✦  BEN + AI • ANSWER & DISTRACTOR CONTEXT"
                textSize = 10.8f * fontScale
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(aiTextColor)
                background = backgroundDrawable
                contentDescription = "Analyze this question, answer and distractors with Ben and AI"
                setPadding(dp(8), dp(7), dp(8), dp(7))
                setOnClickListener { showAiQuestionContext(q) }
            }
            explanationPanel.addView(answerAiContext, LinearLayout.LayoutParams(-1, dp(38)).apply {
                setMargins(0, dp(4), 0, dp(6))
            })
            content.addView(explanationPanel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(2)) })
            addHtmlText(rovexMarkdownBody(q.explanation ?: "<p>No explanation available.</p>", true), 17f * fontScale, false, explanationTextColor, q.id, "explanation")
            q.explanationImages.forEach(addImage)
        }
    }

}
