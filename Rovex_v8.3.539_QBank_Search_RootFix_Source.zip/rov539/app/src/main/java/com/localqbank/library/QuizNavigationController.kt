package com.localqbank.library

import android.view.View
import android.widget.TextView

/**
 * Owns the forward question transition state machine.
 *
 * The controller deliberately receives explicit callbacks instead of retaining the Activity host,
 * preserving the existing navigation behavior while keeping lifecycle-sensitive work at the host.
 */
class QuizNavigationController(
    private val quizViewModel: QuizViewModel,
    private val nextButton: () -> TextView,
    private val content: () -> View,
    private val isHostFinishing: () -> Boolean,
    private val recordCurrentTime: () -> Unit,
    private val show: ((() -> Unit)) -> Unit,
    private val startGuidanceTimer: () -> Unit,
    private val submitExam: (Boolean) -> Unit,
    private val finishStudySession: () -> Unit,
    private val onTransitionStateChanged: (Boolean) -> Unit
) {
    fun advanceQuestion() {
        if (quizViewModel.state.questionCount <= 0 || isHostFinishing()) return
        val current = quizViewModel.state.position
        val target = quizViewModel.targetPosition(current, 1)
        onTransitionStateChanged(true)
        nextButton().isEnabled = false
        nextButton().alpha = 0.72f
        recordCurrentTime()
        if (target != current) {
            quizViewModel.moveToPosition(target)
            // The question loader may be asynchronous. Always hand control back to the UI
            // queue so the button cannot race show()/prefetch state on the same frame.
            content().post {
                if (!isHostFinishing()) {
                    show {
                        startGuidanceTimer()
                        onTransitionStateChanged(false)
                        nextButton().isEnabled = true
                        nextButton().alpha = 1f
                    }
                }
            }
        } else if (quizViewModel.state.examMode) {
            onTransitionStateChanged(false)
            nextButton().isEnabled = true
            nextButton().alpha = 1f
            submitExam(false)
        } else {
            onTransitionStateChanged(false)
            nextButton().isEnabled = true
            nextButton().alpha = 1f
            finishStudySession()
        }
    }
}
