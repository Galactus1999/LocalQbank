package com.localqbank.library

import com.google.firebase.firestore.FirebaseFirestoreException

/**
 * Classifies only transport/backend-transient friend-request failures as retryable.
 * User/data failures such as an unknown Rovex ID or permission denial must surface immediately.
 */
object RovexFriendRequestFailure {
    fun shouldQueue(error: Throwable): Boolean {
        val firestore = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestore != null) return shouldQueueFirestoreCode(firestore.code.name)

        val message = generateSequence(error) { it.cause }
            .mapNotNull { it.message }
            .joinToString(" ")
        return message.contains("client is offline", ignoreCase = true) ||
            message.contains("network is unreachable", ignoreCase = true)
    }

    internal fun shouldQueueFirestoreCode(codeName: String): Boolean = when (codeName) {
        "UNAVAILABLE",
        "DEADLINE_EXCEEDED",
        "ABORTED" -> true
        else -> false
    }
}
