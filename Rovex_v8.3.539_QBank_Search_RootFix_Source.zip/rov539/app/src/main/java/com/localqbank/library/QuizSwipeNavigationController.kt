package com.localqbank.library

import android.view.MotionEvent
import kotlin.math.abs

/** Handles quiz horizontal swipe navigation without retaining the Activity. */
class QuizSwipeNavigationController(
    private val density: Float,
    private val position: () -> Int,
    private val questionCount: () -> Int,
    private val examMode: () -> Boolean,
    private val onRecordCurrentTime: () -> Unit,
    private val onMoveToPosition: (Int) -> Unit,
    private val onShow: () -> Unit,
    private val onStartGuidanceTimer: () -> Unit,
    private val onFinishStudySession: () -> Unit,
    private val onSubmitExam: () -> Unit
) {
    private var gestureDownX = 0f
    private var gestureDownY = 0f

    fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureDownX = ev.rawX
                gestureDownY = ev.rawY
            }
            MotionEvent.ACTION_UP -> {
                val dx = ev.rawX - gestureDownX
                val dy = ev.rawY - gestureDownY
                if (abs(dx) > 56f * density && abs(dx) > abs(dy) * 1.15f) {
                    if (dx < 0) {
                        if (position() < questionCount() - 1) {
                            onRecordCurrentTime()
                            onMoveToPosition(position() + 1)
                            onShow()
                            onStartGuidanceTimer()
                        } else if (!examMode()) {
                            onFinishStudySession()
                        } else {
                            onSubmitExam()
                        }
                        return true
                    }
                    if (dx > 0 && position() > 0) {
                        onRecordCurrentTime()
                        onMoveToPosition(position() - 1)
                        onShow()
                        onStartGuidanceTimer()
                        return true
                    }
                }
            }
        }
        return false
    }
}
