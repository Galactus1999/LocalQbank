package com.localqbank.library

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast

/**
 * Move-only extraction of QuizActivity's explanation-selection ActionMode callback.
 * Behavior intentionally preserved from the v8.3.488 inline implementation.
 */
class QuizNoteSelectionActionModeCallback(
    private val textView: TextView,
    private val noteQuestionId: Long,
    private val appendNote: (Long, String) -> Unit,
    private val context: Context
) : ActionMode.Callback {
    override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
        menu?.add(0, 0x4E4F5445, 0, "Save to Notes")?.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        return true
    }

    override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
        if (menu?.findItem(android.R.id.copy) == null) menu?.add(0, android.R.id.copy, 1, "Copy")
        return true
    }

    override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
        if (item?.itemId != 0x4E4F5445) return false
        val lo = minOf(textView.selectionStart.coerceAtLeast(0), textView.selectionEnd.coerceAtLeast(0))
        val hi = maxOf(textView.selectionStart.coerceAtLeast(0), textView.selectionEnd.coerceAtLeast(0))
        val selected = textView.text?.subSequence(lo, hi)?.toString()?.trim().orEmpty()
        if (selected.isNotBlank()) {
            appendNote(noteQuestionId, selected)
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Explanation", selected))
            Toast.makeText(context, "Selected text added to Notes", Toast.LENGTH_SHORT).show()
        }
        mode?.finish(); return true
    }

    override fun onDestroyActionMode(mode: ActionMode?) {}
}
