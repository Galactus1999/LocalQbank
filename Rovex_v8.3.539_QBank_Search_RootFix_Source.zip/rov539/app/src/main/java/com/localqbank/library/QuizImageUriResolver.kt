package com.localqbank.library

/**
 * Pure URI parsing/extraction for QBank image sources.
 * No Activity or Android UI dependency; behavior intentionally mirrors QuizActivity.
 */
object QuizImageUriResolver {
    fun extractImageUris(html: String?): List<String> {
        if (html.isNullOrBlank()) return emptyList()
        val out = LinkedHashSet<String>()
        Regex("<img\\s+[^>]*(?:src|data-src|data-original|data-lazy-src)\\s*=\\s*[\"']([^\"']+)[^>]*>", RegexOption.IGNORE_CASE)
            .findAll(html).forEach { out.add(it.groupValues[1]) }
        Regex("background-image\\s*:\\s*url\\s*\\(\\s*[\"']?([^\\)\"']+)[\"']?\\s*\\)", RegexOption.IGNORE_CASE)
            .findAll(html).forEach { out.add(it.groupValues[1]) }
        return out.toList()
    }

    fun parseRelativeImage(raw: String): Pair<String, String>? {
        if (!raw.startsWith("rovex-rel://image?", true)) return null
        return runCatching {
            val params = raw.substringAfter('?').split('&').mapNotNull { part ->
                val i = part.indexOf('=')
                if (i <= 0) null else part.substring(0, i) to
                    java.net.URLDecoder.decode(part.substring(i + 1), Charsets.UTF_8.name())
            }.toMap()
            val base = params["base"].orEmpty()
            val path = params["path"].orEmpty()
            if (base.isBlank() || path.isBlank()) null else base to path
        }.getOrNull()
    }
}
