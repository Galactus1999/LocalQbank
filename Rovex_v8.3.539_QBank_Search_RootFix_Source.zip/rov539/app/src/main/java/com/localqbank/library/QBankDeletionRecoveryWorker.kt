package com.localqbank.library

import android.content.Context
import android.os.Process
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.BackoffPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Resumes source-tombstoned QBank deletions after an app/process death. It is deliberately
 * low-priority and delayed so recovery never competes aggressively with foreground study.
 *
 * Startup must NOT enqueue this worker unconditionally: doing so forces WorkManager/SQLite
 * recovery work through every process launch, even when there is nothing to recover. A tiny
 * durable marker is used as the admission signal; the database is only opened by the recovery
 * worker when a delete/recovery operation actually needs it.
 */
class QBankDeletionRecoveryWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            if (ResilienceManager.isAppForeground()) return@withContext Result.retry()
            Process.setThreadPriority(Process.THREAD_PRIORITY_LOWEST)
            val startGeneration = applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_GENERATION, 0L)
            val db = QBankDb(applicationContext)
            var failed = false
            try {
                // Recover legacy hidden QBanks first. This operation only changes visibility and never deletes
                // legacy rows. Only explicit delete_requested=1 sources are eligible for destructive recovery.
                db.restoreLegacyTombstonedSources()
                // Re-query after each pass so a delete requested while this worker is already running
                // is picked up without waiting for another app restart.
                while (true) {
                    val ids = db.pendingDeletingSourceIds()
                    if (ids.isEmpty()) break
                    ids.forEach { id ->
                        if (ResilienceManager.isAppForeground()) { failed = true; return@forEach }
                        val ok = runCatching {
                            db.deleteSource(
                                id,
                                repairSearchIndex = false,
                                maxQuestionBatches = 8,
                                shouldPause = { ResilienceManager.isAppForeground() }
                            )
                        }.getOrDefault(false)
                        if (!ok) failed = true
                    }
                    if (failed) break
                }
            } finally {
                db.close()
            }
            val currentGeneration = applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_GENERATION, 0L)
            if (failed || currentGeneration != startGeneration) {
                // A new deletion request arrived while this run was finishing. Keep the marker
                // and ask WorkManager for another pass instead of clearing a newer request.
                Result.retry()
            } else {
                clearRecoveryNeeded(applicationContext, startGeneration)
                Result.success()
            }
        } catch (t: CancellationException) {
            // Cancellation is not proof of successful recovery. Keep the durable marker so a
            // later launch can re-admit the worker.
            markRecoveryNeeded(applicationContext)
            throw t
        } catch (t: Exception) {
            markRecoveryNeeded(applicationContext)
            ProductionCrashReporter.recordNonFatal(t, "QBANK_DELETE_RECOVERY")
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE = "rovex_qbank_delete_recovery"
        private const val PREFS = "qbank_recovery_state"
        private const val KEY_NEEDED = "recovery_needed"
        private const val KEY_GENERATION = "recovery_generation"
        private const val KEY_BOOTSTRAP_VERSION = "bootstrap_checked_version"
        private const val BOOTSTRAP_VERSION = 548L

        /** Durable admission signal; this is SharedPreferences-only and therefore cheap at startup. */
        fun markRecoveryNeeded(context: Context) {
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            prefs.edit()
                .putBoolean(KEY_NEEDED, true)
                .putLong(KEY_GENERATION, prefs.getLong(KEY_GENERATION, 0L) + 1L)
                .apply()
        }

        private fun clearRecoveryNeeded(context: Context, expectedGeneration: Long) {
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (prefs.getLong(KEY_GENERATION, 0L) == expectedGeneration) {
                prefs.edit().putBoolean(KEY_NEEDED, false).apply()
            }
        }

        fun isRecoveryNeeded(context: Context): Boolean =
            context.applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_NEEDED, false)

        /**
         * Admission is marker-based. ExistingWorkPolicy.KEEP prevents repeated launch/delete
         * events from building an unnecessary WorkManager chain.
         */
        fun enqueueIfNeeded(context: Context) {
            val app = context.applicationContext
            val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            // One-time compatibility bootstrap for legacy hidden tombstones created by older
            // releases. After this check, normal launches are marker-only and do not touch SQLite.
            if (prefs.getLong(KEY_BOOTSTRAP_VERSION, 0L) < BOOTSTRAP_VERSION) {
                runCatching {
                    val db = QBankDb(app)
                    val legacy = try {
                        db.hasLegacyTombstonedSources()
                    } finally { db.close() }
                    if (legacy) markRecoveryNeeded(app)
                }.onFailure {
                    // Do not claim the bootstrap succeeded if SQLite could not be opened. Keep
                    // the marker conservative so a later launch can retry the recovery admission.
                    markRecoveryNeeded(app)
                    return
                }
                prefs.edit().putLong(KEY_BOOTSTRAP_VERSION, BOOTSTRAP_VERSION).apply()
            }
            if (!isRecoveryNeeded(app)) return
            val request = OneTimeWorkRequestBuilder<QBankDeletionRecoveryWorker>()
                .setInitialDelay(0, TimeUnit.SECONDS)
                .setBackoffCriteria(BackoffPolicy.LINEAR, 10, TimeUnit.SECONDS)
                .addTag(UNIQUE)
                .build()
            WorkManager.getInstance(app).enqueueUniqueWork(
                UNIQUE, ExistingWorkPolicy.KEEP, request
            )
        }

        /** Explicit deletion/recovery admission path. */
        fun enqueue(context: Context) {
            val app = context.applicationContext
            markRecoveryNeeded(app)
            enqueueIfNeeded(app)
        }
    }

}
