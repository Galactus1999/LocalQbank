package com.sentencepiece;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * SentencePiece model wrapper used by Rovex.
 *
 * The upstream SentencePiece4J algorithm is retained, but its generated full
 * protobuf runtime is deliberately removed. EmbeddingGemma only needs the
 * SentencePiece ModelProto fields for pieces (token/score/type) and trainer
 * unk_id, so those fields are decoded directly from protobuf wire format.
 * This avoids the full protobuf-java vs Firebase protobuf-lite collision.
 */
public class Model {
    private final Map<String, Piece> vocabulary = new HashMap<>();
    private final TrieNode root = new TrieNode();
    private float maxScore = Float.NEGATIVE_INFINITY;
    private float minScore = Float.POSITIVE_INFINITY;
    private final List<Piece> piecesById = new ArrayList<>();
    private int unkId = -1;

    private Model() {}

    private static byte[] toByteArray(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[8192];
        int nRead;
        while ((nRead = in.read(data, 0, data.length)) != -1) buffer.write(data, 0, nRead);
        return buffer.toByteArray();
    }

    private static Model init(byte[] bytes) throws IOException {
        WireReader reader = new WireReader(bytes);
        Model model = new Model();
        int id = 0;
        int parsedPieces = 0;
        int parsedUnkId = -1;

        while (reader.hasRemaining()) {
            int tag = reader.readTag();
            int field = tag >>> 3;
            int wire = tag & 7;
            switch (field) {
                case 1: // repeated ModelProto.SentencePiece
                    if (wire != 2) throw reader.malformed("ModelProto.pieces has invalid wire type");
                    byte[] pieceBytes = reader.readLengthDelimited();
                    PieceData piece = parsePiece(pieceBytes);
                    model.addPiece(piece.token, id++, piece.score, piece.type);
                    parsedPieces++;
                    break;
                case 2: // TrainerSpec
                    if (wire != 2) throw reader.malformed("ModelProto.trainer_spec has invalid wire type");
                    byte[] trainerBytes = reader.readLengthDelimited();
                    parsedUnkId = parseTrainerUnkId(trainerBytes, parsedUnkId);
                    break;
                default:
                    reader.skipField(wire);
            }
        }

        if (parsedPieces == 0) throw new IOException("SentencePiece ModelProto contains no pieces");
        model.unkId = parsedUnkId >= 0 ? parsedUnkId : findUnkId(model.piecesById);
        return model;
    }

    private static int findUnkId(List<Piece> pieces) {
        for (Piece p : pieces) if (p != null && "<unk>".equals(p.getToken())) return p.getId();
        return -1;
    }

    private static PieceData parsePiece(byte[] bytes) throws IOException {
        WireReader reader = new WireReader(bytes);
        String token = "";
        float score = 0f;
        TokenType type = TokenType.TEXT;
        while (reader.hasRemaining()) {
            int tag = reader.readTag();
            int field = tag >>> 3;
            int wire = tag & 7;
            switch (field) {
                case 1:
                    if (wire != 2) throw reader.malformed("SentencePiece.piece has invalid wire type");
                    token = new String(reader.readLengthDelimited(), java.nio.charset.StandardCharsets.UTF_8);
                    break;
                case 2:
                    if (wire != 5) throw reader.malformed("SentencePiece.score has invalid wire type");
                    score = Float.intBitsToFloat(reader.readFixed32());
                    break;
                case 3:
                    if (wire != 0) throw reader.malformed("SentencePiece.type has invalid wire type");
                    type = mapType((int) reader.readVarint());
                    break;
                default:
                    reader.skipField(wire);
            }
        }
        return new PieceData(token, score, type);
    }

    private static int parseTrainerUnkId(byte[] bytes, int current) throws IOException {
        WireReader reader = new WireReader(bytes);
        int result = current;
        while (reader.hasRemaining()) {
            int tag = reader.readTag();
            int field = tag >>> 3;
            int wire = tag & 7;
            if (field == 40) {
                if (wire != 0) throw reader.malformed("TrainerSpec.unk_id has invalid wire type");
                result = (int) reader.readVarint();
            } else {
                reader.skipField(wire);
            }
        }
        return result;
    }

    private static TokenType mapType(int type) {
        switch (type) {
            case 2: return TokenType.UNKNOWN;
            case 3: return TokenType.CONTROL;
            case 4: return TokenType.USER_DEFINED;
            case 5: return TokenType.UNUSED;
            case 6: return TokenType.BYTE;
            case 1:
            default: return TokenType.TEXT;
        }
    }

    public static Model getInstance() throws IOException { return parseFromResource("models/sentencepiece.bpe.model"); }

    public static Model parseFromResource(String resourceName) throws IOException {
        try (InputStream in = Model.class.getClassLoader().getResourceAsStream(resourceName)) {
            if (in == null) throw new IOException("Resource not found: " + resourceName);
            return init(toByteArray(in));
        }
    }

    public static Model parseFrom(Path modelPath) throws IOException { return init(Files.readAllBytes(modelPath)); }

    public void addPiece(String token, int id, float score, TokenType type) {
        Piece piece = new Piece(token, id, score, type);
        vocabulary.put(token, piece);
        while (piecesById.size() <= id) piecesById.add(null);
        piecesById.set(id, piece);
        maxScore = Math.max(maxScore, score);
        minScore = Math.min(minScore, score);
        insertIntoTrie(token, piece);
    }

    private void insertIntoTrie(String token, Piece piece) {
        TrieNode node = root;
        for (int i = 0; i < token.length();) {
            int cp = token.codePointAt(i);
            i += Character.charCount(cp);
            node = node.getOrCreate(cp);
        }
        node.mark(piece.getId(), piece.getScore(), piece.getType());
    }

    public TrieNode getRoot() { return root; }
    public float getMaxScore() { return maxScore; }
    public float getMinScore() { return minScore; }
    public String getTokenById(int id) { return tokenById(id); }
    public String tokenById(int id) {
        if (id < 0 || id >= piecesById.size()) return "<unk>";
        Piece piece = piecesById.get(id);
        return piece != null ? piece.getToken() : "<unk>";
    }
    public int getUnkId() { return unkId; }
    public int getIdForToken(String token) {
        Piece piece = vocabulary.get(token);
        return piece != null ? piece.getId() : -1;
    }

    public List<Integer> encode(String input) {
        String trimmedInput = input.trim();
        String[] tokens = trimmedInput.split("\\s+");
        List<Integer> ids = new ArrayList<>();
        for (String t : tokens) {
            int id = getIdForToken(t);
            if (id != -1) ids.add(id);
        }
        return ids;
    }

    private static final Pattern pattern = Pattern.compile("\\s+");

    public List<Integer> encodeNormalized(String rawInput, SentencePieceAlgorithm algorithm) {
        String normalized = Normalizer.normalize(rawInput, Normalizer.Form.NFKC).toLowerCase();
        normalized = pattern.matcher(normalized.trim()).replaceAll(" ");
        StringBuilder sb = new StringBuilder();
        for (String word : normalized.split(" ")) sb.append('▁').append(word);
        ResultBuilderImpl builder = new ResultBuilderImpl();
        algorithm.segment(sb.toString(), builder, this);
        return builder.getTokenIds();
    }

    public String decodeSmart(List<Integer> ids) {
        StringBuilder sb = new StringBuilder();
        for (int id : ids) {
            String token = tokenById(id);
            if (token.equals("<unk>")) { sb.append('�'); continue; }
            if (token.startsWith("▁")) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(token.substring(1));
            } else sb.append(token);
        }
        return sb.toString().trim();
    }

    private static final Pattern ZS = Pattern.compile("\\p{Z}+");
    private static final Pattern HEBREW_DIACRITICS = Pattern.compile("[\\u0591-\\u05BD\\u05BF\\u05C1-\\u05C2\\u05C4-\\u05C5\\u05C7]");

    public String normalizeHebrew(String input, boolean stripDiacritics) {
        String s = Normalizer.normalize(input, Normalizer.Form.NFC);
        if (stripDiacritics) s = HEBREW_DIACRITICS.matcher(s).replaceAll("");
        return ZS.matcher(s.trim()).replaceAll(" ");
    }

    public String decode(List<Integer> ids) {
        return ids.stream().map(this::tokenById).collect(Collectors.joining(" "));
    }

    private static final class PieceData {
        final String token; final float score; final TokenType type;
        PieceData(String token, float score, TokenType type) { this.token = token; this.score = score; this.type = type; }
    }

    /** Minimal protobuf wire reader: only primitive wire types required by SentencePiece ModelProto. */
    private static final class WireReader {
        private final byte[] data; private int pos;
        WireReader(byte[] data) { this.data = data; }
        boolean hasRemaining() { return pos < data.length; }
        int readTag() throws IOException {
            long value = readVarint();
            if (value <= 0 || value > Integer.MAX_VALUE) throw malformed("Invalid protobuf tag");
            return (int) value;
        }
        long readVarint() throws IOException {
            long result = 0;
            for (int shift = 0; shift < 64; shift += 7) {
                if (pos >= data.length) throw malformed("Truncated protobuf varint");
                int b = data[pos++] & 0xff;
                result |= (long)(b & 0x7f) << shift;
                if ((b & 0x80) == 0) return result;
            }
            throw malformed("Overlong protobuf varint");
        }
        int readFixed32() throws IOException {
            if (data.length - pos < 4) throw malformed("Truncated protobuf fixed32");
            int value = (data[pos] & 0xff) | ((data[pos+1] & 0xff) << 8) | ((data[pos+2] & 0xff) << 16) | ((data[pos+3] & 0xff) << 24);
            pos += 4; return value;
        }
        byte[] readLengthDelimited() throws IOException {
            long length = readVarint();
            if (length < 0 || length > data.length - pos) throw malformed("Invalid protobuf length");
            int end = pos + (int) length;
            byte[] value = java.util.Arrays.copyOfRange(data, pos, end);
            pos = end; return value;
        }
        void skipField(int wire) throws IOException {
            switch (wire) {
                case 0: readVarint(); return;
                case 1:
                    if (data.length - pos < 8) throw malformed("Truncated protobuf fixed64");
                    pos += 8; return;
                case 2:
                    long length = readVarint();
                    if (length < 0 || length > data.length - pos) throw malformed("Invalid protobuf length");
                    pos += (int) length; return;
                case 5:
                    if (data.length - pos < 4) throw malformed("Truncated protobuf fixed32");
                    pos += 4; return;
                default: throw malformed("Unsupported protobuf wire type: " + wire);
            }
        }
        IOException malformed(String message) { return new IOException(message + " at offset " + pos); }
    }
}
