package com.sentencepiece;

import java.util.ArrayList;
import java.util.List;

public class ResultBuilderImpl implements SentencePieceAlgorithm.ResultBuilder {
    private final List<Integer> tokenIds = new ArrayList<>();

    @Override
    public void build(String input, SegmentEnd[] segmentEnds, boolean collapseUnknowns) {
        int i = segmentEnds.length - 1;
        while (i > 0) {
            SegmentEnd end = segmentEnds[i];
            if (end == null) throw new IllegalArgumentException("SentencePiece segmentation produced an incomplete path");
            tokenIds.add(0, end.getId());
            i = end.getSegmentStart();
        }
    }

    public List<Integer> getTokenIds() { return tokenIds; }
}
