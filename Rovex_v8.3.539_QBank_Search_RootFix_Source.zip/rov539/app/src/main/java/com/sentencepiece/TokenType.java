package com.sentencepiece;

public enum TokenType {
    UNKNOWN,
    TEXT,
    USER_DEFINED,
    CONTROL,
    BYTE,
    UNUSED
}
