package com.sentencepiece;

public class Piece {
    private final String token;
    private final int id;
    private final float score;
    private final TokenType type;

    public Piece(String token, int id, float score, TokenType type) {
        this.token = token;
        this.id = id;
        this.score = score;
        this.type = type;
    }
    public String getToken() { return token; }
    public int getId() { return id; }
    public float getScore() { return score; }
    public TokenType getType() { return type; }
}
