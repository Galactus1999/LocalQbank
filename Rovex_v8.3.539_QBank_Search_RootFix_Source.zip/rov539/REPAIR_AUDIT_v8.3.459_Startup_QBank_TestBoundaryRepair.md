# Rovex v8.3.459 — Verification Boundary Repair Audit

## Scope
Small follow-up to v8.3.458 only. No production business logic changed.

## Root cause proven by CI
The v8.3.458 instrumented test `boundedDeletionPassLeavesTombstoneAndCanResumeWithoutFullWriterHold` failed at line 78. The production deletion path tombstones the source before bounded physical question deletion. `QBankDb.questionCount(testId)` intentionally filters `source.deleting=0`, so using that API to measure physical rows after the tombstone necessarily returns zero. The failure was therefore in the regression assertion, not evidence that bounded deletion removed all rows.

## Repair
- Keep production bounded deletion implementation unchanged.
- Change the regression test to inspect physical question rows directly while the source is tombstoned.
- Assert exactly 51 rows remain after one 50-row batch from 101 seeded rows.
- Make the SQLite bind array explicitly typed (`Array<Any?>`) to remove the Kotlin compiler intersection-type warning introduced by the test fixture.
- Increment version from 8.3.458/versionCode 549 to 8.3.459/versionCode 550.

## Static verification executed
- `verify_search_regression_repair.sh` PASS
- `verify_search_qbank_regressions.sh` PASS
- `verify_performance_search_architecture.sh` PASS
- `verify_root_architecture.sh` PASS
- `verify_defect_regressions.sh` PASS
- `phase0_offline_gate.py` PASS
- Modified/affected Kotlin brace/paren/bracket balance PASS
- Diff against v8.3.458 contains only the version bump and the targeted regression-test correction.

## Runtime status
v8.3.458 CI evidence: debug build PASS, Android test APK build PASS, 39 instrumented tests executed, 38 completed successfully and 1 failed at the incorrect assertion described above. v8.3.459 has not yet been built or executed; therefore this version is NOT runtime verified yet.
