# Rovex v8.3.518 — CI compile repair

## Root cause
The v8.3.517 CI run reached `:app:compileDebugKotlin` and failed at:

`SettingsActivity.kt:43:18`

`'clearWallpaper' hides member of supertype 'ContextWrapper' and needs an 'override' modifier.`

The wallpaper feature introduced an app-specific `SettingsActivity.clearWallpaper()` method whose name collides with the Android `Context`/`ContextWrapper` API.

## Repair
Renamed the app-specific method:

- `SettingsActivity.clearWallpaper()` → `SettingsActivity.clearRovexWallpaper()`
- Updated the only caller in `SettingsScreen.kt`.
- Did not override the framework API.
- Did not change `RovexWallpaperManager` behavior.

## Version
- versionName: `8.3.518`
- versionCode: `608`

## Scope proof
Compared directly against the v8.3.517 source package. Only these source/build files changed:

1. `SettingsActivity.kt`
2. `SettingsScreen.kt`
3. `app/build.gradle.kts`

No `QBankDb.kt` changes. No search/ESCAPE changes.

## Validation
- CI log evidence: v8.3.517 reached real Kotlin compilation; failure was the single `clearWallpaper` collision above.
- Static collision scan: no `fun clearWallpaper()` remains in app source.
- New method reference scan: exactly the declaration and its one UI caller.
- Version check: 8.3.518 / 608.
- Local Gradle compile: BLOCKED because this environment cannot resolve `downloads.gradle.org` for Gradle 9.3.1.

## Required next gate
Run CI for v8.3.518. Do not call green until `:app:compileDebugKotlin` and the subsequent unit/instrumented/device gates pass.
