# v8.3.472 — Phase 2C Neural Policy Contract Repair

Baseline: v8.3.471 / versionCode 562
Release: v8.3.472 / versionCode 563

## Evidence
The v8.3.471 CI adaptive instrumented suite built successfully but failed one existing safety contract:
`BenInferenceProcessStressTest.quarantinedNeuralRuntime_doesNotStartNativeInference` asserted that neural execution is disabled by default. The v8.3.471 change inverted that invariant by making `BenAiRuntimePolicy.enabled` default to true.

The same CI run reported 40 tests with 1 failure. The failure is a production-policy regression, not an emulator transport failure. The JVM tests and debug builds completed successfully.

## Root cause
v8.3.470 correctly retained the existing explicit-user-enable model policy. v8.3.471 incorrectly attempted to solve normal-request neural admission by changing the policy default from OFF to ON. That violated the established safety/quarantine contract and would allow model execution without explicit user consent.

The actual Phase-2C root fixes remain valid:
- production Ben telemetry begins at the production entry point;
- duplicate deterministic QBank ranking work is cached rather than repeated;
- admission requires both EmbeddingGemma and Gemma 3 270M for the grounded neural pipeline;
- deterministic local QBank retrieval remains authoritative and bounded.

## Repair
- Restore `BenAiRuntimePolicy.enabled` default to `false` when no explicit user choice exists.
- Preserve explicit user enable/disable semantics and emergency STOP behavior.
- Do not weaken or rewrite the existing neural quarantine stress test.
- Keep the v8.3.471 telemetry, duplicate-search cache, two-model admission, and fast deterministic fallback changes.

## Verification
- Static source repair: PASS.
- Version monotonicity: 562 -> 563.
- CI v8.3.471: BUILD SUCCESSFUL; adaptive instrumentation FAILED only on the neural-default safety contract.
- v8.3.472 CI/device validation: PENDING.
- No claim of green until v8.3.472 CI passes.
