# v8.3.461 — CI Compile Root Repair

- Corrects the exact v8.3.460 CI compilation failure in `ExperiencePerformanceManager.kt`.
- Adds missing kotlinx.coroutines extension imports for `isActive` and `ensureActive`.
- No runtime/business-logic change.
- versionCode 552; versionName 8.3.461.
- Static regression and architecture gates pass.
- CI/build/device verification remains pending and must not be inferred from static checks.
