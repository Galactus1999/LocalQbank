# v8.3.538 — CI Compile Repair 2

## Root cause
CI for v8.3.537 reached Kotlin compilation and failed at `MainQBankLibraryActivity.kt:236:51` because the code referenced the nonexistent `ThemeManager.background(...)` API.

## Repair
Use the existing authoritative `ThemeManager.bg(...)` color API when constructing the icon background drawable.

## Preserved
- v8.3.536 QBankDb search SQL seam
- v8.3.537 QBankDb `getProgressMeta` receiver repair
- v8.3.535 QBank reset feature
- No QBank search semantics changed
