# Rovex v8.3.493 — QuizImageDecoder move-only extraction

## Scope
Extracted the existing bitmap decode helpers from `QuizActivity` into `QuizImageDecoder`.

Moved mechanics:
- `decodeScaledImage`
- `calculateSample`
- `decodeBytes`

The Activity retains only a thin private compatibility wrapper for `decodeScaledImage`, preserving its existing call contract. `ContentResolver` is explicitly supplied to the decoder; the decoder does not capture or reference `QuizActivity`.

## Discipline
- Move-only refactor; no behavior/algorithm cleanup.
- Existing decode/sample calculations and network/content/data-image handling preserved.
- No changes to QBank, Ben, chat, Frankenstein, answer feedback, or renderer behavior.
- Version: 8.3.493 / versionCode 584.

## Verification
- STATIC PASS: decoder implementation uniqueness.
- STATIC PASS: Activity wiring.
- STATIC PASS: decoder contains no `QuizActivity`/`AppCompatActivity` reference.
- STATIC PASS: brace balance and version assertion.
- Gradle/CI/device validation: NOT RUN in this preparation step.
