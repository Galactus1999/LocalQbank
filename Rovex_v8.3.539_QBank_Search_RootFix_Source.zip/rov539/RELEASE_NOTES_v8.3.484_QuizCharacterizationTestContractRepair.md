# v8.3.484 — Quiz characterization test contract repair

## Root causes found in v8.3.483 CI

1. `QuizViewModelCharacterizationTest.configureAndResolvePreserveCurrentQuizStateContract` asserted `bankName == "Medicine"`, but the existing production contract intentionally assigns `state.sessionLabel ?: resolution.bankName`. The fixture supplies `sessionLabel = "Stage test"`, so the observed value is `"Stage test"`; `sectionLabel` remains `"Medicine"`. The test was corrected to characterize the actual behavior rather than change production code.

2. Two Stage 7 UI assertions failed with Espresso `RootViewWithoutFocusException`. The complete emulator log contains no `FATAL EXCEPTION` for `com.localqbank.library`; the emulator instead logged a launcher ANR caused by an unfocused window. These assertions were test-harness focus dependent, so the test was hardened to inspect the activity hierarchy through `ActivityScenario.onActivity` instead of requiring Espresso root focus. No production Settings/MainActivity code was changed.

## Scope
- Test-only repair.
- No QuizActivity/QuizViewModel production behavior changes.
- No WebView/gesture/toolbar/onCreate extraction.
- Version 8.3.483 → 8.3.484, versionCode 574 → 575.

## Verification status
- Source/static review: PASS
- Test-only scope audit: PASS
- CI: PENDING
- Instrumented execution after repair: PENDING
- Device validation: PENDING

Do not label this release green until the complete CI workflow succeeds.
