# Repair Audit — v8.3.458 Startup / QBank Contention

## Scope
Starting from v8.3.457. Scope is limited to the reported cold-start/QBank loading/Continue/Ben contention/Celebration symptoms.

## Proven source-level causal paths
- Source catalog, dashboard aggregates, and section metadata previously shared `QBankLoadingEngine`'s executor.
- Home Continue previously submitted through `PerformanceManager.submit()`.
- Home bookmark rendering previously called `PerformanceManager.progress().all()`.
- Home `apply()` hydrated data and `MainActivity` subsequently queued another `refreshData()` on creation/first resume.
- QBank recovery worker could process all question batches in one WorkManager execution while the app returned foreground.
- Celebration requests could be discarded when the overlay or target had zero layout size; overlay stacking was not explicitly reasserted.

## Changes
- dedicated `qbank-source-loader` executor
- dedicated latest-resume lookup
- grouped SQL bookmark counts
- first-resume duplicate refresh suppression
- bounded foreground-aware deletion recovery
- robust celebration overlay layout/stacking
- new instrumented regression tests

## Static evidence
All required project audits returned RC 0 / PASS.

## Build evidence
BLOCKED. Gradle distribution download failed because `downloads.gradle.org` could not be resolved in the execution environment.

## Runtime evidence
NOT EXECUTED. No device/CI log proving v8.3.458 behavior has been supplied yet.

## Conclusion
The source-level root repairs are implemented and statically audited. Runtime causal confirmation remains pending and must be obtained from CI + real-device traces/timing. No runtime PASS is claimed.
