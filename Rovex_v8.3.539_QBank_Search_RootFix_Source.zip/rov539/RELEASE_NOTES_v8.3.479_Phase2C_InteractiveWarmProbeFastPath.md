# v8.3.479 — Phase 2C Interactive Warm-Probe Fast Path

## Evidence
Device telemetry from v8.3.478 showed deterministic fallback work of ~236 ms but `neuralAttempt=1221 ms`, with the warm-status trace reporting `EmbeddingGemma runtime cold/unavailable after 797 ms`. The QBank/search path was not the bottleneck.

## Root cause
The interactive Ben pipeline called `embeddingWarmSuspend()` on a client with no live inference-worker binding. The generic one-shot path acquired the main-process foreground lease and established Binder transport solely to answer a read-only warm-status question. This created avoidable pre-fallback latency.

## Repair
- Interactive Ben now calls `embeddingWarmSuspend(allowColdProbe=false)` so a client with no live worker binding immediately takes the deterministic fallback lane.
- A live worker binding can still report warm state.
- Warm state is cached for 5 seconds and marked warm after a successful rerank; it is invalidated on connection loss/trim/new service generation.
- Read-only `CMD_EMBED_WARM_STATUS` no longer acquires the foreground lease; it remains eligible for a live Binder control-plane query.
- Frankenstein retains the legacy probe behavior (`allowColdProbe=true`) so this repair does not silently alter its passive context contract.
- No native runtime, Binder transport architecture, SQLite/search owner, or fallback algorithm was changed.

## Verification status
Static/source audit and isolated Kotlin syntax/contract checks are required. Full Gradle/CI/device verification remains pending until the complete release workflow executes.
