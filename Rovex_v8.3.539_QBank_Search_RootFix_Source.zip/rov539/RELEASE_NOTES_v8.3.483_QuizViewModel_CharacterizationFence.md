# Rovex v8.3.483 — QuizViewModel characterization fence

## Purpose

This release is intentionally **test-only**. It creates the characterization fence required before the next QuizActivity extraction step.

## Scope

Added `QuizViewModelCharacterizationTest` as an Android instrumented test. It exercises the existing ViewModel without changing its production behavior:

- session configuration and resolution state
- exam-mode answer acceptance/correctness
- exam-answer recording/counting
- explicit navigation → resume target
- position and exam-remaining clamping

The test uses fake Quiz data sources so these characterization checks do not require QBank question data to exist.

## Refactor rule

No QuizActivity extraction is included in v8.3.483. The two WebView clients, gesture classes, toolbar/popup callbacks, and `onCreate` remain untouched.

The next extraction is allowed only after this characterization test is actually executed successfully in CI/emulator/device. The first extraction must then be a verbatim move of one WebView client with no behavior change.

## Verification status

- Source/static inspection: PASS
- Production behavior changes: NONE intended
- Android instrumented characterization test: PENDING CI/device execution
- Full Gradle build: PENDING CI
- Device runtime: PENDING

No claim of green/production verification is made until those gates execute.
