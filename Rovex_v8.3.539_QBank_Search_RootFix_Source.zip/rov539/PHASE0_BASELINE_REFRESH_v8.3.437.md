# Phase 0 baseline refresh — v8.3.437

The previous architecture regression baseline predates the completed modern-Home/search migration and therefore reported already-accepted architecture as regressions, including the removed legacy MainViewModel factory and accumulated activity persistence counts.

This refresh records the actual v8.3.437 source shape as the verification baseline. It does not suppress a defect: subsequent runs compare against this exact baseline and reject new growth or ownership violations.

The refresh is accompanied by an explicit ManagerContractRegistry entry for `RovexOnlineSyncCoordinator`, which was already a bounded event subscription and was previously missing only from the audit registry.
