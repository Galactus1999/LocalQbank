# v8.3.478 — Phase 2C Pre-Fallback Latency Repair

## Evidence
The device telemetry for v8.3.477 showed:
- request total: ~9292 ms
- preFallback: ~9034 ms
- deterministic fallback work: ~258 ms
- local search: 15 ms
- search index schema: 1 ms
- primary search: 13 ms
- alias search: 0 ms
- neural requests: 0
- fallback requests: 1

The latency therefore occurred before the authoritative deterministic fallback lane, not in SQLite/QBank retrieval.

## Root cause
The interactive grounded neural path could call EmbeddingGemma semantic reranking through IPC even when the isolated native runtime was cold. The rerank transport had an 8-second client deadline, so a cold/unavailable native path could consume roughly the observed 8 seconds plus foreground/Binder admission overhead before returning null and allowing deterministic fallback.

## Repair
1. `BenGroundedNeuralPipeline` now checks whether EmbeddingGemma is already warm before attempting interactive semantic reranking.
2. A cold/unavailable runtime is treated as an accelerator miss and immediately returns the existing deterministic-fallback signal; no native cold start is initiated by an interactive Ben request.
3. The warm semantic rerank deadline is reduced from 8 seconds to 2.5 seconds, preserving a bounded escape hatch for a stalled warm runtime while allowing normal bounded multi-vector work.
4. `ExperiencePerformanceManager` records the neural attempt duration/outcome in the deterministic fallback trace so future device evidence can distinguish warm-rerank latency from fallback latency.
5. No SQLite/QBank retrieval owner, ranking behavior, deterministic fallback algorithm, IPC lifecycle contract, model artifact, or native runtime implementation was rewritten.

## Expected behavior
Cold/unavailable EmbeddingGemma:
`request -> warm check -> immediate deterministic fallback`

Warm EmbeddingGemma:
`request -> warm check -> bounded semantic rerank -> neural pipeline`

Warm-rerank stall:
`request -> warm check -> <=2.5s rerank deadline -> deterministic fallback`

## Verification status
- Diff audit against v8.3.477: PASS; only the three intended production Kotlin files, `app/build.gradle.kts`, and this release note changed.
- Kotlin delimiter/syntax-structure audit on changed production files: PASS.
- XML parse audit: PASS (36 XML resources parsed); duplicate IDs checked per individual layout.
- Source contract audit: PASS; the interactive grounded pipeline now performs a warm-runtime gate before `rerankSuspend`, and the rerank deadline is 2.5 s with one attempt.
- `rerankSuspend` call-site audit: PASS; the two production call sites both use the warm-runtime policy (main grounded pipeline directly; passive context path explicitly).
- ZIP integrity: PASS.
- Full Gradle/Android compilation: BLOCKED locally because the wrapper could not resolve `downloads.gradle.org` (DNS).
- CI/device/runtime validation: pending.
- Do not claim green until CI and device validation pass.
