# v8.3.462 — QBank DB Lock + Cancellation Test Boundary Root Repair

- versionCode 553; versionName 8.3.462.
- CI input: v8.3.461.
- Root cause 1: v8.3.461's cancellation regression test did not deterministically enter the alias lane; the callback could remain uncalled when the query had no expansion variants.
- Root repair: test now supplies an explicit extra alias and asserts the continuation boundary is checked before and between alias admissions.
- Root cause 2: CI runtime evidence showed multiple StreakDatabaseConcurrencyTest workers waiting on QBankDatabaseProvider.get() while the provider monitor covered SQLiteOpenHelper.getWritableDatabase(). AOSP SQLiteOpenHelper independently synchronizes its open path, so holding the outer process-wide provider monitor across database open added an unnecessary serialization layer.
- Root repair: provider monitor now covers only helper identity/filesystem reconciliation; writableDatabase() executes after the provider monitor is released. Existing shared-helper architecture, WAL, schema, and QBankDatabaseProvider ownership remain unchanged.
- Added low-overhead qbank-db-open trace section so future device/CI traces can distinguish database-open latency from caller-side contention.
- No Ben IPC, Gemma runtime, schema, FTS policy, or business-logic owner changes.
