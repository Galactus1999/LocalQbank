# v8.3.497 — Quiz Rich Text Renderer Move

- Corrected versionCode from 586 to 587 after detecting the v8.3.495/v8.3.496 duplicate.
- Moved QuizActivity imported-HTML rendering helpers into the existing authoritative QuizRichTextRenderer.
- Preserved HTML cleanup, table rendering, note-selection callback wiring, theme colors, typography, spacing, and image callback behavior.
- No database, Ben/AI, or business-logic changes.
- CI/device validation pending.
