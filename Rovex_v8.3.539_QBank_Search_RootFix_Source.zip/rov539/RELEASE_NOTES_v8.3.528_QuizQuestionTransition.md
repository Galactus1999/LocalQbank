# v8.3.528 — Quiz Question Transition

## Scope
High-frequency question-navigation motion only. No theme, celebration, haptic, Ben, or QBankDb behavior changes.

## Change
- Added a directional question transition to `QuizActivity` for forward/backward question navigation.
- Existing `AnimationPolicy.enabled()` remains the single reduce-motion/accessibility gate.
- Forward navigation: outgoing content moves/fades left; incoming content enters from the right.
- Backward navigation: outgoing content moves/fades right; incoming content enters from the left.
- Duration: 190 ms exit + 200 ms enter, with a 72 dp travel distance.
- `QuizNavigationController` now keeps the Next button transition state locked until the visual transition completes.
- Existing direct `show()` paths used for initial loading, menus, dialogs, and asynchronous question loading remain unchanged.

## Stability intent
- No animation library added.
- No changes to question loading, answer state, database, search, or rendering logic.
- Reduce-motion / disabled-animation settings fall back to the existing immediate `show()` path.
- Transition is lifecycle guarded and cancellation-safe at the view-animation boundary.

## Verification
- Changed Kotlin delimiter balance: PASS.
- Android Gradle/CI/device verification: pending; must not be called green until actual build/CI/device execution succeeds.
