# v8.3.514 Offline Diff Scope

The supplied v8.3.513 source archive is not a Git working tree, so a literal `git diff --stat` cannot be produced offline. This is the equivalent file-scope diff against the exact v8.3.513 archive used by CI.

- app/src/main/java/com/localqbank/library/RovexCelebrationPlannerDialog.kt | 3 lines changed
- app/src/main/java/com/localqbank/library/RovexSectionDashboardActivity.kt | 1 line changed
- app/src/main/java/com/localqbank/library/StudyHealthActivity.kt | 2 lines changed
- app/build.gradle.kts | 2 lines changed

Total: 4 files changed, 4 insertions / 4 deletions relative to the relevant lines.

Scope matches the CI compile repair only.
