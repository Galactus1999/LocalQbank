# Rovex v8.3.457 — Startup/QBank Loading Root Repair Audit

## Scope

Repair the repeated post-process-start loading delay observed after QBank deletion. The target is the startup/data-hydration path, not the visual loading indicators.

## Root-cause evidence from v8.3.456 source

### 1. Unconditional deletion-recovery admission on every application process start

`LocalQBankApplication.onCreate()` called `QBankDeletionRecoveryWorker.enqueue(applicationContext)` for every normal process start.

The worker then opened `QBankDb`, ran `restoreLegacyTombstonedSources()`, queried pending deletion IDs, and could execute resumable deletion work. This meant a process launch could trigger SQLite recovery work even when no deletion/recovery was pending.

The worker also used `ExistingWorkPolicy.APPEND_OR_REPLACE`, so launch-time enqueueing was not an appropriate idempotent admission gate.

### 2. Full progress-corpus materialization was eagerly queued during AppManagers initialization

`AppManagers.initialize()` constructed `StudyStateRepository`.

The v8.3.456 `StudyStateRepository.init` immediately submitted `refreshProgressCache()` to the shared single-thread `PerformanceManager` `qbank-worker`.

`refreshProgressCache()` called `PerformanceManager.progress()`, which called `ProgressStore.allEntries()`, which materialized all `progress_v2` rows into a `ProgressSnapshot`.

This happened during every fresh process and occupied the same serialized background lane later used by Home/dashboard work. `RovexHomeRevolution.refreshDynamic()` also submits its Home statistics calculation to this same executor, so Home progress hydration could wait behind the full progress-corpus preload.

The Home progress UI explicitly starts as `Loading calibrated progress…`, matching the observed delayed hydration symptom.

## Repair

### Recovery admission

- Added durable SharedPreferences-only recovery admission state.
- Normal startup now calls `enqueueIfNeeded()` instead of unconditional `enqueue()`.
- If no recovery marker exists, normal startup does not open QBank SQLite for recovery.
- One-time compatibility bootstrap checks for legacy hidden tombstones after the repair version is first installed; subsequent launches are marker-only.
- Explicit deletion requests set the marker at the durable delete-intent boundary.
- Interrupted resumable deletions set the marker before returning failure.
- Worker reuses one `QBankDb` wrapper for its pass instead of constructing one wrapper per source ID.
- Worker uses `ExistingWorkPolicy.KEEP`.
- A monotonic recovery generation prevents a late worker completion from clearing a newer deletion request.

### Progress startup work

- Removed eager `StudyStateRepository` full-progress preload from application startup.
- Before the shared progress snapshot is warm, `StudyStateRepository.snapshot(stableKey)` performs one indexed stable-key lookup instead of loading every progress row.
- Full progress snapshots remain available to existing analytics/background callers.
- Mutation paths continue to invalidate/rebuild the shared snapshot as before.

### Measurement boundary

- Added a real `Rovex.MainActivity.firstUsable` trace section spanning Activity creation through installation of the production Home shell.
- Existing Macrobenchmark startup metrics can now measure this boundary alongside startup timing, frame timing, memory, and trace sections.

## Regression protections preserved

- `com.localqbank.library` package unchanged.
- versionCode remains monotonic: 548.
- QBank deletion remains tombstone-first and resumable.
- FTS deletion architecture unchanged: no synchronous whole-corpus FTS rebuild was introduced.
- Shared `QBankDatabaseProvider` remains authoritative.
- AppManagers remains the manager owner.
- Ben IPC/inference transport was not rewritten.
- Deterministic QBank/Frankenstein data remains authoritative.
- Existing v8.3.455 recovery identity test correction remains intact.

## Static verification actually executed on v8.3.457 source

- `phase0_offline_gate.py`: PASS
- `verify_search_regression_repair.sh`: PASS
- `verify_search_qbank_regressions.sh`: PASS
- `verify_performance_search_architecture.sh`: PASS
- `verify_root_architecture.sh`: PASS
- `verify_defect_regressions.sh`: PASS
- Changed Kotlin files have balanced delimiter counts.
- No unconditional startup call to `QBankDeletionRecoveryWorker.enqueue(...)` remains.
- No eager `StudyStateRepository` startup `PerformanceManager.submit { refreshProgressCache() }` remains.

## Runtime/build boundary

Gradle compilation was attempted with `:app:compileDebugKotlin :app:compileDebugAndroidTestKotlin --offline`.

It was BLOCKED because the Gradle wrapper attempted to download Gradle 9.3.1 and DNS resolution for `downloads.gradle.org` failed (`curl: (6) Could not resolve host`). Therefore this source audit does NOT claim compilation, CI, instrumented-test, or device PASS.

## Required proof before release

1. Build v8.3.457 in CI.
2. Run the complete instrumented suite and require all tests to pass.
3. Run Macrobenchmark startup tests on a physical device.
4. Reproduce: delete QBank -> close process -> reopen -> measure Home/QBank/Progress readiness.
5. Repeat a second cold process start without another deletion.
6. Compare startup traces before/after the repair.
7. Confirm no recovery worker is admitted when its marker is false.
8. Confirm interrupted deletion still resumes after process death.
9. Confirm unrelated QBanks and legacy hidden data survive recovery.
10. Only then classify the performance repair as runtime VERIFIED.
