# Rovex 8.3.522 — Friend Request Write-First Repair

## Root cause
The client previously performed a direct Firestore read of `friendCodes/{rovexId}` before creating a friend request. Firestore can fail an exact document read when the requested document is not cached and the SDK cannot reach its backend, even while Android reports validated Internet connectivity. This produced the misleading "server connection temporarily unavailable" path and made friend adding depend on a client-side lookup.

## Repair
- Friend add now creates an authenticated `friendRequestIntents/{intentId}` write containing the target Rovex ID.
- Firestore persistence owns delivery while offline.
- A trusted Cloud Function resolves the target Rovex ID server-side and creates the existing mirrored incoming/outgoing friend-request documents.
- Target-user presence is never consulted.
- Invalid/self/already-friends/already-pending cases are resolved server-side and recorded on the intent.
- Existing friend-request UI/outbox remains compatible; queued legacy codes now submit write-first intents.
- Version 8.3.522 / versionCode 612.
