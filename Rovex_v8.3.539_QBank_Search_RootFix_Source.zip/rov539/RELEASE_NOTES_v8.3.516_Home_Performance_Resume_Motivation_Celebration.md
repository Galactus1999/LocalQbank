# v8.3.516 — Performance / Continue / Motivation / Celebration Repair

- Performance Lab now reconciles all missing `progress_v2` rows into the attempt ledger without a stale timestamp cutoff; duplicate prevention remains the ledger key/time/correct predicate.
- Performance Lab daily accuracy/attempted/correct/wrong matches the current-progress data used by Home Today's Progress; control-panel wrong/unsolved counts use current durable status and due uses the same current progress snapshot.
- Home Continue now carries an explicit durable-resume launch contract that overrides stale SavedStateHandle position. Answers also persist a durable `last_solved_global` cursor; Home prefers that tie-break over the post-answer next-question cursor.
- Motivation is one quote at a time, switching deterministically at 07:00 and 17:00 local time. Morning and evening notifications are independently scheduled. The editable motivation-time control is removed.
- Celebration animation implementation confirmed present; Preview now renders through an overlay in the dialog content window so it is above the planner UI instead of relying on the Activity DecorView.
- Removed the “Discipline today, Doctor tomorrow.” Home banner.
