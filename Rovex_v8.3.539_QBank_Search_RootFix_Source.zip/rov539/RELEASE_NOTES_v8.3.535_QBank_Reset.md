# Rovex v8.3.535 — QBank Reset

## User feature
Long-press any imported QBank in the main QBank library to open a rounded management popup. The popup now includes **Reset progress**.

## Reset semantics
Reset clears learner state for the selected source only:
- selected answers and correct/wrong status
- attempts and timing state
- SRS scheduling state
- bookmarks/review flags
- source/test resume and completion cursors

The QBank content itself is preserved. Immutable `study_attempt_history` is preserved for historical analytics. Other QBanks are untouched.

## Safety
- Reset is a separate confirmed action; it cannot be triggered by a single long-press.
- Database work runs through the existing PerformanceManager background path.
- Current study session is cleared only when it belongs to the reset source.
- Backup/progress invalidation is triggered after a successful reset.
- Added `QBankResetIsolationTest` to prove source isolation and history preservation.

## Validation
- Changed-source delimiter audit: PASS
- XML per-layout duplicate-ID audit: PASS
- Version identity: 8.3.535 / versionCode 625
- Android Gradle compile/test: BLOCKED in the current environment if Android SDK/Gradle dependencies are unavailable; CI remains the build gate.
