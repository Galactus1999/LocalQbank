# Rovex v8.3.517

- Performance Lab now uses the full QBank population for period analytics and a single current-progress snapshot for WRONG/DUE NOW/UNSOLVED.
- Celebration rendering uses ViewGroupOverlay for transient visual-only effects and targets the selected option at milestone time.
- Removed small Daily Motivation and Rovex Online explanatory footer text from Home.
- Added optional local background wallpaper import from Gallery with app-private, bounded image storage.
- VersionCode 607.
