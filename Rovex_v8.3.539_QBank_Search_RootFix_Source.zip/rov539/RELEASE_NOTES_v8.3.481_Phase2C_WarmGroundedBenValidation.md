# Rovex v8.3.481 — Phase 2C Warm Grounded Ben Validation

## Purpose
Add a diagnostics-only warm-path validation harness. The normal interactive Ben path remains cold-start-free.

## Root contract
- The interactive pipeline must never cold-start EmbeddingGemma merely because a user asked a question.
- A warm neural request must still be executable when a live, policy-admitted EmbeddingGemma runtime is already warm.
- Validation must prime EmbeddingGemma and then execute the grounded pipeline using the same `BenGroundedNeuralPipeline`/`BenInferenceProcessClient` instance.

## Changes
- `BenGroundedNeuralPipeline.warmForDiagnostics()` performs a real policy-governed EmbeddingGemma semantic comparison and then confirms warm state through the same client.
- `RovexDiagnosticsDataCenter` adds `RUN WARM GROUNDED BEN TEST`.
- The test runs a fixed medical query, records prime time, warm state, cosine, grounded result, modelUsed, verification, evidence count, request latency, and telemetry.
- This is diagnostics-only. It is not called by production interactive requests.
- Version: 8.3.481 / versionCode 572.

## Verification status
- Static/source checks: pending final audit.
- Local Gradle build: blocked if Gradle distribution DNS remains unavailable.
- CI/device: pending.
