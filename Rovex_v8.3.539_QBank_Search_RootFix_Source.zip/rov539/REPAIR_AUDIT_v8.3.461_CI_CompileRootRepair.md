# Rovex v8.3.461 — CI Compile Root Repair

## Evidence reviewed
CI log: `logs_98607521680.zip`
Selected source:
`Rovex_v8.3.460_Phase1_QBank_Contention_RootRepair_Source.zip`
CI-reported SHA:
`cf192ed0af69ba5b3f3da392b2a616acdfdc4a79b7083442c7484d1969a691ad`

## Executed CI result
The CI selected the intended v8.3.460 archive and reached `:app:compileDebugKotlin`.
The build FAILED before instrumented/runtime execution.

Exact compiler diagnostics:
- `ExperiencePerformanceManager.kt:116:101 Unresolved reference 'isActive'.`
- `ExperiencePerformanceManager.kt:146:70 Unresolved reference 'ensureActive'.`

The failing expressions were:
- `currentCoroutineContext().isActive`
- `currentCoroutineContext().ensureActive()`

Root cause:
`ExperiencePerformanceManager.kt` used the kotlinx.coroutines extension APIs without importing their extension symbols. The project already contains valid uses/imports of `kotlinx.coroutines.ensureActive` elsewhere, confirming the dependency/API family is already present.

## Repair
Added explicit imports:
- `import kotlinx.coroutines.ensureActive`
- `import kotlinx.coroutines.isActive`

No behavior was changed in the cancellation logic.

Version bumped:
- versionName: `8.3.461`
- versionCode: `552`

## External API evidence
The official kotlinx.coroutines source documents `CoroutineContext.isActive` and `ensureActive()` as coroutine cancellation APIs and shows `currentCoroutineContext().ensureActive()` usage.
Source: https://github.com/Kotlin/kotlinx.coroutines/blob/master/kotlinx-coroutines-core/common/src/CoroutineScope.kt

The official cancellation documentation states that `isActive` returns false after cancellation and `ensureActive()` throws `CancellationException`, supporting their use at the cancellation boundaries added in v8.3.460.

## Static verification after repair
PASS:
- verify_search_regression_repair.sh
- verify_search_qbank_regressions.sh
- verify_performance_search_architecture.sh
- verify_root_architecture.sh
- verify_defect_regressions.sh
- verify_phase1_qbank_contention.sh
- audit_frankenstein_policy.py
- audit_coroutine_cancellation.py
- architecture_regression_audit.py
- phase0_offline_gate.py

Note: the audit runner emitted an unrelated spreadsheet-runtime warmup timeout during Python startup; each audit itself returned exit code 0 and its substantive audit output passed.

## Runtime/build status
v8.3.461 BUILD: BLOCKED / NOT YET EXECUTED.
This environment cannot claim compilation from source inspection. The prior CI failure was compile-time and is now repaired at the exact reported symbol boundary. A fresh CI run is required to prove compilation and to execute instrumented tests.

## Non-regression boundary
No changes to:
- Ben IPC transport
- Gemma/EmbeddingGemma runtime
- QBank schema
- AppManagers ownership
- QBank deletion production algorithm
- search semantics
- UI architecture
