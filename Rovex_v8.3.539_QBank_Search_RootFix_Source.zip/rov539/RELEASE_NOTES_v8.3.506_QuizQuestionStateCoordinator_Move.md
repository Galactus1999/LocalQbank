# Rovex v8.3.506 — QuizQuestionStateCoordinator Move

## Scope
Controlled QuizActivity decomposition following the user-reported GREEN v8.3.505 build.

## Change
Extracted the question-state preparation portion of `QuizActivity.show()` into `QuizQuestionStateCoordinator`.

The moved behavior is unchanged:
- record elapsed time for the previous question
- set the current question
- start the current-question timing window
- persist quiz position
- resolve progress status
- determine answered state, including exam-mode answers
- update exam/guidance timer UI
- update question jump label
- unlock the question scroll and preserve answered scrollbar behavior
- update section chip
- update bookmark button
- update next button

The coordinator receives explicit callbacks and does not retain an Activity/View reference directly.

## Important release-process correction
The supplied v8.3.505 source archive still contained `versionCode = 593` / `versionName = 8.3.503` despite being labeled 8.3.505. This batch corrects the release identity to:
- versionName: `8.3.506`
- versionCode: `596`

This preserves monotonic versioning relative to the intended 8.3.505 release sequence.

## Not changed
- question loading/cache semantics
- question presentation renderer
- rich-text renderer
- image subsystem
- answer evaluation
- audio/celebration
- Ben/AI/IPC
- QBank/database behavior
- navigation behavior
- prefetch behavior

## Validation
- STATIC: PASS — brace balance and owner/reference scan
- STATIC: PASS — version identity corrected and stale 8.3.503 identity absent from build file
- LOCAL GRADLE COMPILE: BLOCKED — Gradle 9.3.1 distribution could not be resolved because `downloads.gradle.org` DNS is unavailable in the current environment
- CI: PENDING
- DEVICE: PENDING
