# v8.3.463 — CI Test Compile Root Repair

## Root cause
CI for v8.3.462 reached Android-test compilation and failed at `QBankStartupPerformanceRegressionTest.kt:129` because `SearchHit` exposes `text`, not `title`.

## Repair
Changed the regression assertion from `result.hits.any { it.title... }` to `result.hits.any { it.text... }`.

No production behavior was changed. v8.3.462's QBank database provider lock-scope repair remains unchanged.

## Verification status
This source change is statically inspected only until a new CI build executes it. No build/device/runtime PASS is claimed here.
