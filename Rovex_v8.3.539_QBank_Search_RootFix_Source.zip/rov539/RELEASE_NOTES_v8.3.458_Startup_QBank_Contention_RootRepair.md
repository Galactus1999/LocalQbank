# Rovex v8.3.458 — Startup / QBank / Background-Contention Root Repair

## Version contract
- versionName: `8.3.458`
- versionCode: `549`
- package: `com.localqbank.library`
- Baseline: v8.3.457

## User-observed defects addressed
1. Imported QBank list can remain on `Loading imported QBanks…` after launch/navigation.
2. Home `CONTINUE MOST RECENT QBANK` can appear unresponsive.
3. Ben + AI / Frankenstein local retrieval can feel stressed while QBank deletion/recovery is still active.
4. Home startup can queue duplicate database refresh work.
5. Milestone Celebration/preview can produce no visible animation.

## Root-cause findings
### A. QBank catalog starvation
`QBankLoadingEngine` previously used one executor for source metadata, dashboard aggregates, and section work. Home's Continue-Learning path could start `dashboardTestRows()` on that executor; the QBank Library source request then waited behind the dashboard query.

### B. Home startup duplicate work
`RovexHomeRevolution.apply()` already performs the initial Home data hydration. `MainActivity.onCreate()` then called `refreshData()`, and the first `onResume()` called it again. This could queue multiple identical SQLite reads immediately during a cold launch.

### C. Full progress materialization from Home bookmark counts
Home's bookmark tile counted bookmarks by materializing `PerformanceManager.progress().all()`. That path reads the complete sparse progress corpus and constructs all progress records. The Home UI only needs four grouped bookmark counts.

### D. Continue action shared the general serialized QBank worker
The Continue button resolved the latest resume target through `PerformanceManager.submit()`, sharing the same serialized worker used for other QBank database work. A queued background calculation could therefore delay the button's result.

### E. Background deletion could remain CPU/SQLite-active while the user returned to the foreground
The resumable deletion worker used bounded question transactions, but a single WorkManager run could process an entire large QBank. Even with low OS thread priority, that remains unnecessary database/IO contention while the user is actively studying. The foreground state was not used as a cooperative yield signal.

### F. Celebration rendering had a brittle zero-size/stacking boundary
`RovexCelebrationView` silently returned when it was not yet laid out and did not explicitly bring the overlay to the front. This could drop a requested celebration if the host/target had not reached a non-zero layout size at the exact callback time.

## Repairs
### 1. Dedicated fast source lane
`QBankLoadingEngine` now has a dedicated `qbank-source-loader` executor for source catalog and latest-resume reads. Dashboard/section work remains on the background `qbank-loader` executor.

This prevents a dashboard aggregate from blocking the source catalog and Continue action.

### 2. Fast Continue path
Added `QBankLoadingEngine.loadLatestResumeTarget()` and routed Home Continue through it instead of the general `PerformanceManager` worker.

### 3. SQL bookmark aggregation
Added `QBankDb.bookmarkCounts()` using a grouped SQLite aggregate. Home no longer materializes the full progress snapshot merely to display bookmark counts.

### 4. Remove duplicate cold-launch Home refreshes
Initial hydration remains owned by `RovexHomeRevolution.apply()`. `MainActivity` no longer immediately calls a second `refreshData()` during `onCreate()`, and the first `onResume()` is explicitly skipped. Later resumes still refresh normally.

### 5. Foreground-aware bounded deletion
`QBankDeletionRecoveryWorker` now:
- refuses to start destructive recovery while an Activity is foregrounded;
- retries using WorkManager linear backoff (10 s minimum);
- limits each recovery pass to 8 question batches (50 questions/batch);
- checks foreground state between batches;
- passes a cooperative pause predicate into `QBankDb.deleteSource()`;
- leaves the source tombstoned and the recovery marker active when a pass is paused/incomplete.

The user-visible deletion contract is unchanged: the QBank disappears at the tombstone boundary, while physical cleanup remains resumable.

### 6. Celebration overlay hardening
Celebration now waits for attachment/layout instead of silently dropping a request, calls `bringToFront()`, uses explicit high elevation, and resets alpha/visibility before animation. The animation remains procedural and bounded.

## Regression tests added
`QBankStartupPerformanceRegressionTest` covers:
- grouped bookmark count correctness;
- bounded deletion pass + resumability;
- QBank source catalog callback through the dedicated source lane.

## Static verification
- Search regression audit: PASS
- QBank/search regression audit: PASS
- Performance/search architecture audit: PASS
- Root architecture audit: PASS
- Defect regression audit: PASS
- Phase-0 offline gate: PASS
- Kotlin source brace/parenthesis balance checks: PASS
- no compiled APK/class/jar/aab artifacts in source package: PASS

## Execution boundary
Android Gradle compilation was attempted but BLOCKED because the environment could not resolve `downloads.gradle.org` while attempting to obtain Gradle 9.3.1. Therefore this release is **not** being represented as BUILD PASS, CI PASS, instrumented-test PASS, or DEVICE PASS.

Required next evidence:
1. CI/build for v8.3.458.
2. Instrumented regression suite including the new startup/QBank tests.
3. Device trace/timing after deleting a QBank, force-closing, and reopening twice.
4. Device validation of QBank catalog, Continue, Ben+AI/Frankenstein search, and Celebration preview/milestone rendering.

## Research basis
The repair strategy was cross-checked against current Android performance guidance and open-source examples:
- Android Performance Samples: Macrobenchmark, Baseline Profile, JankStats and WorkManager performance examples.
- Android SQLite guidance: WAL for parallel read/write, short non-exclusive write transactions, indexed/aggregated queries.
- Android WorkManager guidance: explicit retry/backoff for deferred work.

No Gemma/EmbeddingGemma changes were made because the observed defect is a local QBank/SQLite/work-scheduling path and there is no evidence that neural inference is its root cause.
