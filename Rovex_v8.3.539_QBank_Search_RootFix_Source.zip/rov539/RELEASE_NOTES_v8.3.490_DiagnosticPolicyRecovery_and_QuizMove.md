# v8.3.490 — Diagnostic Policy Recovery Hardening + Quiz Move Continuation

## Scope
This batch contains two explicitly disclosed items:
1. A diagnostics-only policy recovery hardening for the **pre-existing** warm grounded Ben diagnostic.
2. Continuation of the move-only QuizActivity extraction from v8.3.489.

## Important scope audit finding
The warm grounded diagnostic UI and `BenGroundedNeuralPipeline.warmForDiagnostics()` were already present in v8.3.488. They are **not new changes in this batch** and are not part of the Quiz extraction. The v8.3.489 diff against v8.3.488 contains only the Quiz extraction, its new callback class, version metadata, and its release note.

## Diagnostic policy recovery
- Before the diagnostics screen temporarily enables a previously-OFF Ben accelerator, the prior OFF state is persisted synchronously with `commit()`.
- `LocalQBankApplication.onCreate()` restores and clears any pending temporary diagnostic state before normal managers/UI initialize.
- The normal coroutine `finally` path uses the same persisted restore contract.
- This closes the process-death gap where `finally` would not execute after an Android process kill.
- No normal interactive Ben path is changed.

## Quiz extraction
- Preserves the v8.3.489 `QuizNoteSelectionActionModeCallback` move unchanged.
- No QuizViewModel, rendering, WebView, or answer-feedback behavior changes.

## Verification
- Source/static diff audit: performed
- Diagnostic state-mutation path audit: performed
- ZIP integrity: verified after packaging
- Full Gradle build: not independently run in this environment
- CI/device: pending
