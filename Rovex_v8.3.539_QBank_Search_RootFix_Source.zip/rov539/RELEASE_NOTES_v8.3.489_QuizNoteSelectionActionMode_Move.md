# v8.3.489 — Quiz Note Selection ActionMode Move

## Scope
Move-only extraction from `QuizActivity.configureNoteSelection()`.

## Extracted component
`QuizNoteSelectionActionModeCallback`

The existing inline `ActionMode.Callback` was moved verbatim in behavior. Activity-specific dependencies are supplied through constructor parameters/callbacks rather than retaining an Activity reference.

## Preserved behavior
- `Save to Notes` action ID and label
- Copy menu insertion
- selection bounds handling
- note persistence callback
- clipboard copy
- toast text/duration
- action-mode finish behavior
- no-op destroy callback

## Deliberately not changed
- seekbar listener
- image WebView clients
- empty `RovexSafeWebViewClient` assignment
- QuizViewModel behavior
- rendering behavior
- unrelated QuizActivity logic

## Verification
- Source/static inspection: performed
- Full Gradle build in this environment: not claimed; Gradle distribution DNS may block local execution
- CI/device: pending
