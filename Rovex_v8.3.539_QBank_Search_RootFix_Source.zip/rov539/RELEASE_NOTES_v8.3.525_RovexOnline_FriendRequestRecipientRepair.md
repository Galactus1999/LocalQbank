# Rovex v8.3.525 — Friend Request Recipient Delivery Repair

## Root cause
The v8.3.524 no-Cloud-Function flow stored a friend-request intent correctly, but recipient-side Firestore security rules depended on `users/{uid}.rovexId`. The Online screen did not guarantee that the recipient's identity profile document existed before querying/materializing intents. A missing profile could therefore produce `PERMISSION_DENIED`, leaving the queued intent invisible and preventing the incoming request from being materialized.

## Repair
- Recipient-side Online load now calls `ensureIdentityProfile()` before friend-request materialization.
- Friend-request intent authorization no longer depends on the optional `users/{uid}` profile document.
- Recipient authorization uses the durable `friendCodes/{rovexId}` identity mapping instead.
- Incoming/outgoing materialization rules use the same durable friend-code mapping.
- No Cloud Function is required.
- Recipient may be offline at send time; delivery occurs when they next open Rovex Online with connectivity.
- Version bumped to 8.3.525 / versionCode 615.

## Verification status
- Changed-source inspection: PASS
- Kotlin delimiter audit: PENDING
- Firestore Rules compiler/deployment: PENDING
- Android compile/CI: PENDING
- Two-account device test: PENDING

Do not call this release runtime-green until the recipient-side two-account test succeeds.
