# Rovex v8.3.471 — Phase 2C Ben Admission + Fallback Repair

## Root causes addressed

1. Normal Ben neural admission depended on a persistent policy flag whose default was OFF.
   With installed models, ordinary clinical questions therefore entered deterministic fallback
   without attempting the already device-validated EmbeddingGemma/Gemma pipeline.
2. The production neural route treated either model artifact as sufficient even though the
   grounded pipeline requires both EmbeddingGemma and Gemma 3 270M.
3. Admission checked only the presence of artifacts, not the combined runtime footprint and
   thermal/RAM policy before selecting the neural route.
4. Deterministic fallback re-entered the heavier Ren clinical ranking path, which could repeat
   ontology/SQLite work while the QBank search/index layer was contended. A bounded local-search
   fallback is now preferred, with Ren retained only as a final recovery path.

## Repairs

- Local neural execution defaults ON until the user explicitly changes the persistent policy.
- Persistent STOP BEN MODEL / force-stop remains authoritative.
- Resource, thermal, foreground and conservative model gates remain mandatory.
- Neural production admission now requires both installed model artifacts.
- Combined runtime memory is considered for admission.
- Deterministic fallback uses LocalQBankSearchService first, preserving authoritative QBank data.
- Existing Ben IPC/isolated process, LiteRT, QNN, EmbeddingGemma and Gemma runtime code was not
  rewritten.
- Version: 8.3.471 / versionCode 562.

## Verification status

- Pure Kotlin BenAiRuntimeGate check: PASS.
- Source/static inspection: PASS for changed-path structure.
- QBankDb construction count: unchanged from v8.3.470.
- XML duplicate-ID audit: PASS.
- Gradle build: BLOCKED in this environment because downloads.gradle.org DNS is unavailable.
- Device/CI validation: PENDING.
