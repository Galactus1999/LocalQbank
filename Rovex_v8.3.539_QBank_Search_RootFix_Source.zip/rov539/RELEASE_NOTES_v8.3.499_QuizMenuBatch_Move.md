# v8.3.499 — Quiz Menu Extraction Batch

## Identity
- Candidate: v8.3.499 / versionCode 589
- Baseline: v8.3.498 / versionCode 588
- Change type: move-only presentation extraction batch

## Scope
Extracted three existing QuizActivity menu surfaces into `QuizMenuController`:
- Question Jump menu
- Question Settings menu
- Bookmark menu and its menu-local positioning helper

`QuizActivity` retains thin delegates and remains responsible for lifecycle/session orchestration.

## Behavior policy
- No intended behavior change.
- No QBank/database/Ben/answer/audio/celebration business logic changes.
- Existing `QuizFontScaleSeekBarController` remains authoritative for font-size interaction.
- Existing AppManagers/engine ownership is unchanged.
- Controller receives explicit dependencies/callbacks rather than retaining a QuizActivity reference.

## Verification
- Changed Kotlin brace balance: PASS.
- Menu methods reduced to delegates: PASS.
- Removed menu-local helper duplication: PASS.
- QuizMenuController source contains no QuizActivity reference except documentation text: PASS.
- Version monotonicity: PASS, 588 -> 589.
- Full Android Gradle build: NOT RUN / environment may require CI.
- CI/device validation: PENDING.


## CI compile-repair
The first CI run selected this archive and failed at `:app:compileDebugKotlin` because the
menu-batch move had removed the pre-existing `readableForeground(Int)` helper while leaving
its image-save call sites intact. The repair restores that presentation helper in `QuizActivity`
without changing menu or image-save behavior.
- CI failure evidence: `QuizActivity.kt:1063`, `1084`, `1096` unresolved `readableForeground`.
- Repair scope: one restored helper only.
- CI after repair: PENDING.
