# v8.3.498 — Quiz Image Controller Move

## Identity
- Baseline: v8.3.497 / versionCode 587
- Candidate: v8.3.498 / versionCode 588
- Package: `com.localqbank.library`
- Change type: move-only QuizActivity image-subsystem extraction

## Scope
Extracted the remaining primary question-image rendering body from `QuizActivity.addImage()` into `QuizImageController`.

Moved behavior is preserved verbatim in intent and sequencing:
- image URI trimming and duplicate-child suppression
- WebView construction/configuration
- `QuizImageFitWebViewClient` wiring
- tap-to-fullscreen timing behavior
- long-press image-save behavior
- visible `SAVE IMAGE + NOTE → MY NOTES` action
- theme-aware save-button colors/contrast
- relative-image resolution
- base URL selection
- HTML escaping and image HTML construction
- `loadDataWithBaseURL()` invocation

`QuizActivity` remains the UI/lifecycle host and delegates to the controller through explicit callbacks. No persistence/business-logic ownership moved into the new controller.

## Files changed
- `app/src/main/java/com/localqbank/library/QuizActivity.kt`
- `app/src/main/java/com/localqbank/library/QuizImageController.kt`
- `app/build.gradle.kts`
- `RELEASE_NOTES_v8.3.498_QuizImageController_Move.md`

## Safety constraints
- No workflow/CI source changed.
- No QBank/database logic changed.
- No answer/evaluation/audio/celebration logic changed.
- No Ben/AI/IPC logic changed.
- Existing `QuizImageDecoder`, `QuizImageUriResolver`, `QuizImageWebViewController`, `QuizImageSaveController`, and WebView client classes remain authoritative for their existing domains.
- The new controller has no `Activity`-typed dependency or Activity reference.

## Verification
- Static changed-source inspection: PASS.
- Brace-balance check for changed Kotlin files: PASS.
- Duplicate `QuizImageController` class check: PASS.
- Controller Activity-capture scan: PASS; source comment mention of `QuizActivity` is documentation only.
- Version monotonicity: PASS, 587 -> 588.
- Android Gradle/CI/device verification: PENDING; this source ZIP must not be called build-green until CI completes successfully.
