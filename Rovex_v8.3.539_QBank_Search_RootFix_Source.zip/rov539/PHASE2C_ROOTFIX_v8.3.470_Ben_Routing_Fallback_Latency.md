# Phase 2C — v8.3.470 Ben Routing / Fallback Latency Root Fix

Baseline: v8.3.469 / versionCode 560
Release: v8.3.470 / versionCode 561

## Root causes found by source audit

1. **Normal-request telemetry did not start at the production Ben entry point.**
   `BenNeuralTelemetry.begin()` lived inside `BenGroundedNeuralPipeline`, so policy-blocked/deterministic-only requests could be omitted or leave stale runtime counters in the diagnostics export. This made `neuralRequests`, `fallbackRequests`, and latency fields unreliable for some production requests.

2. **Deterministic QBank retrieval was executed twice for one normal Frankenstein request.**
   `RenCognitiveEngine.answer()` performed the clinical + SQLite ranking search to construct the response. `FrankensteinSupportEngine` then called `searchQuestionIds()` for the same command before publishing the result, which repeated the clinical understanding and QBank ranking pipeline. On a large local corpus this duplicated expensive work and is consistent with the observed ~64-second response latency.

3. **The production UI status could say that neural models were ready while the Ben neural safety policy was OFF.**
   This obscured the actual admission state. The existing persistent kill switch and governor remain authoritative; this repair only makes the state explicit.

## Repairs

- Request telemetry now begins at `FrankensteinSupportEngine`, covering deterministic, policy-blocked, cached and neural production requests consistently.
- `BenGroundedNeuralPipeline` no longer starts a second telemetry request.
- Deterministic completion has a dedicated telemetry terminal method that does not invent verifier confidence values.
- Ranked IDs produced by `RenCognitiveEngine.answer()` are cached for the existing short-lived ID lookup, eliminating the immediate duplicate search.
- Raw deterministic fallback IDs are cached as well.
- When a normal Ben request cannot enter the neural path, the telemetry now records the actual policy/model admission reason instead of silently falling through.
- Settings labels now explicitly identify the existing control as `AI Accelerator • Allow Ben local model`.
- Ben chat model status now reports `AI accelerator OFF` when models are installed but the persistent Ben neural policy is stopped.
- No changes to Ben IPC transport, isolated inference process, LiteRT/QNN runtime, model artifacts, database ownership, deterministic QBank authority, or resource-governor safety rules.

## Verification status

### Static
- Changed-file diff scoped to 6 files.
- XML parse: PASS.
- Per-layout duplicate-ID audit: PASS (36 XML files; 0 duplicate-ID files).
- QBankDb construction count: unchanged from v8.3.469 (63 project-wide occurrences; RenCognitiveEngine remains 4).
- Version monotonicity: 560 -> 561.

### Build / runtime
- Local Gradle build: **BLOCKED** because Gradle 9.3.1 distribution DNS is unavailable in the current environment (`downloads.gradle.org` resolution failure).
- CI build: **NOT YET RUN for v8.3.470**.
- Device runtime: **NOT YET RUN for v8.3.470**.

## Required Phase 2C device validation

1. Ensure `Settings -> Ben Safety -> AI Accelerator • Allow Ben local model` is ON for the neural-path test.
2. Run the same simple medical question used for the v8.3.469 baseline.
3. Export complete diagnostics.
4. Verify that the production request itself increments `totalRequests` and reports a current request latency, rather than relying on stale telemetry.
5. Verify neural admission/semantic reranking/generation when policy and resources permit.
6. Repeat the same question after the first response to test the warm path.
7. Test cancellation during generation, then issue a new request.
8. Compare deterministic fallback latency separately with the neural path.
