# Rovex v8.3.467 — Phase 2 Chat Rendering Hardening

Version: 8.3.467
VersionCode: 558
Package: com.localqbank.library
Base: v8.3.466

## Scope

Phase 2A/2B initial chat-rendering hardening. No renderer rewrite and no Ben IPC changes.

## Changes

- Added render-sequence fencing to streamed Free AI Markdown rendering.
  - Each render snapshot receives a monotonically increasing sequence.
  - A cancelled/obsolete background render can no longer enqueue a stale WebView replacement after a newer snapshot has been scheduled.
  - Existing request-generation/lifecycle fencing remains authoritative.
- Suppress duplicate streaming renders when the generated snapshot is unchanged.
- Added lightweight `RovexChatRenderTelemetry`.
  - Records Markdown render duration, rendered character count, and whether the render was still current.
  - Logs only slow renders (>=120 ms), large renders (>=12,000 chars), or obsolete render completion.
  - Telemetry is observational only and owns no chat state or scheduling.
- Chat CLEAR now clears the existing chat DOM directly instead of rebuilding and re-rendering the entire transcript.
- Version incremented monotonically from 8.3.466/versionCode 557 to 8.3.467/versionCode 558.

## Preserved

- `RovexChatDocument` incremental append/replace architecture.
- CommonMark/GFM rendering path.
- Mermaid/rich-content compatibility pipeline.
- Ben IPC/isolate architecture.
- AppManagers/authoritative-engine ownership.
- Existing lifecycle and cancellation guards.

## Verification status

- STATIC REVIEW: PASS
- Focused Kotlin syntax compilation of new telemetry class with Android Log stub: PASS
- Layout XML parsing: PASS
- Per-layout duplicate-ID audit: PASS
- QBankDb construction count versus v8.3.466 source: unchanged (61)
- Full Android Gradle build: NOT RUN HERE
- Instrumented/device runtime: NOT RUN HERE
- CI/device functional verification of v8.3.467: BLOCKED until this source is built and executed
