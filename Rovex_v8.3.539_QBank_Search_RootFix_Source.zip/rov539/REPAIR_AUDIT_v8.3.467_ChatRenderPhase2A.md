# Rovex v8.3.467 — Repair Audit

## Root cause addressed

During streamed Free AI output, Markdown rendering runs off the main thread and previous render jobs are cancelled when a newer snapshot arrives. Cancellation alone does not provide a strict freshness guarantee for work that has already reached a main-thread handoff. A stale render could therefore still enqueue a WebView replacement after a newer snapshot was scheduled.

## Repair

`RenActivity.runCombinedCore()` now assigns every streaming render a monotonically increasing local sequence. The sequence is checked again on the main thread immediately before `RovexChatDocument.replace()`. Only the current sequence and current request generation may update the WebView.

Identical snapshots are also skipped before scheduling a render.

`clearChatHistory()` now calls `RovexChatDocument.clear()` directly, avoiding an unnecessary full transcript Markdown parse and WebView document rebuild.

## Regression surface

- Free AI streaming display
- Markdown/CommonMark rendering
- WebView incremental DOM updates
- cancellation/latest-request behavior
- lifecycle destruction
- CLEAR chat action
- chat persistence remains unchanged

## Explicit non-goals

- No Ben inference transport changes.
- No QBank database architecture changes.
- No broad MVVM/QuizActivity rewrite.
- No speculative renderer replacement.
- No claim of device/runtime performance improvement until measured on device.

## Evidence

Static and focused checks were run in the offline workspace. Android build, instrumentation, and device performance measurement remain unexecuted for this source version.
