# v8.3.492 — Quiz Font-Scale SeekBar Move

## Scope
Move-only QuizActivity extraction.

## Changed files
- `app/src/main/java/com/localqbank/library/QuizActivity.kt`
- `app/src/main/java/com/localqbank/library/QuizFontScaleSeekBarController.kt`
- `app/build.gradle.kts`
- this release note

## Change
Extracted the question-settings font-scale `SeekBar` listener/configuration from `QuizActivity` into `QuizFontScaleSeekBarController`.

Behavior preserved:
- maximum progress remains 45
- initial progress calculation remains unchanged
- font scale remains clamped to 0.85–1.30
- persistence callback remains invoked only for user changes
- popup dismissal and settings refresh remain on tracking stop
- accent tint remains unchanged

No unrelated behavior or architecture changes are included.

## Verification
- Static source/diff audit: pending final package audit
- Gradle/CI: pending
- Device: pending
