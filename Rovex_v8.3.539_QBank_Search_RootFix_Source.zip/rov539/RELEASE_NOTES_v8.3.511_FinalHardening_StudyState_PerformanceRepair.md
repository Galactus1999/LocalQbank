# Rovex v8.3.511 — Final Hardening: Continue / Reattempt / Celebration / Performance Metrics

Version: 8.3.511  
VersionCode: 601  
Baseline: v8.3.510 / versionCode 600

## Repairs

1. **Continue cursor**
   - Continue now prefers the global durable resume cursor when it belongs to the selected QBank source.
   - Falls back to source-scoped cursors for compatibility.
   - Prevents an older source-name cursor from reopening Q1 after a later study position was saved.

2. **Reattempt sessions**
   - Wrong/bookmarked/revision collection sessions now explicitly enter reattempt mode.
   - Previously persisted `status` / `selected_answer` no longer makes options appear already answered in these sessions.
   - Unsolved sessions remain unanswered normally.
   - Durable historical progress is still retained and a new answer remains a new attempt.

3. **Celebration Preview**
   - Preview previously rendered into the Activity window while the Celebration Lab was a separate Dialog window, placing the effect behind the modal dialog.
   - Preview now installs its temporary celebration host in the dialog window and targets the Preview button.
   - Live quiz celebration path is unchanged.

4. **Performance Lab historical metrics**
   - Added durable `study_attempt_history` ledger because `progress_v2` only stores the latest state per question and cannot represent real repeated historical attempts.
   - Every accepted answer records timestamp/correctness; question time is attached to the latest attempt when elapsed time is committed.
   - Existing progress is seeded once as one best-known historical observation per question; this does not invent repeated historical attempts.
   - Daily / weekly / monthly are calendar windows; All Time uses the full ledger.
   - Performance Lab no longer prefilters questions by their latest `lastAttempted`, which previously discarded older attempts that belonged to the selected period.

## Verification

- Static changed-source inspection: PASS
- Brace balance on changed Kotlin files: PASS
- Version monotonicity: PASS (601 > 600)
- Gradle/Android compilation: BLOCKED until CI because local Gradle distribution download remains environment-blocked.
- Device runtime validation: PENDING CI/build/device execution.

## Important limitation

The historical ledger can exactly measure attempts recorded after this repair. Existing `progress_v2` contains only current state, so historical repeated attempts that occurred before the ledger existed cannot be reconstructed exactly. The one-time seed preserves the latest known attempt without fabricating prior attempts.
