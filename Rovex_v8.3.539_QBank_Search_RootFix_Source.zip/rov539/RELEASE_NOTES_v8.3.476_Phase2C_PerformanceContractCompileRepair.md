# Rovex v8.3.476 — Phase 2C Performance Contract Compile Repair

## Root cause

v8.3.475 added deterministic local-search telemetry in `ExperiencePerformanceManager`, consuming `indexSchemaMs`, `primarySearchMs`, and `aliasSearchMs` from `LocalQBankSearchService.Result`. The producer result contract was not updated, so Kotlin compilation failed with unresolved references in `ExperiencePerformanceManager.kt` at lines 165 and 311.

## Repair

`LocalQBankSearchService.Result` now owns and reports the three measurements:

- `indexSchemaMs`: elapsed time for `ensureSearchIndex()`.
- `primarySearchMs`: elapsed time for the primary literal/visual QBank search.
- `aliasSearchMs`: elapsed time for the bounded alias/variant search lane.

All three default to `0L` for compatibility with short/empty query results, and the existing authoritative retrieval behavior is unchanged. No Ben IPC, neural runtime, database ownership, ranking, or fallback behavior was changed.

Version increment: `8.3.475` / code `566` → `8.3.476` / code `567`.

## Verification status

- Source-level producer/consumer contract: repaired.
- Local source/static checks: pending execution after packaging.
- Android/Gradle CI: pending; must not be called green until CI executes successfully.
- Device/runtime Phase 2C validation: pending.
