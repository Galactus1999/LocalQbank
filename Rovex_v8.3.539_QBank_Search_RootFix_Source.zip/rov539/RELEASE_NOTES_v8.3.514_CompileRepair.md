# Rovex v8.3.514 — v8.3.513 CI Compile Repair

## Root causes found from CI

1. `RovexCelebrationPlannerDialog.kt:160` referenced `previewButton` from its own initializer. The callback now captures a local `lateinit` `TextView` assigned before the callback can execute.
2. `RovexSectionDashboardActivity.kt:408` constructed `Row` with one missing argument. The subject mastery row now supplies `sourceTotal=total` explicitly.
3. `StudyHealthActivity.kt:22-23` used `this` inside `GradientDrawable.apply`, where `this` referred to the drawable rather than the Activity. Theme lookups now explicitly use `this@StudyHealthActivity`.

## Scope

Compile-only repair of the v8.3.513 Home / Study Health / PYQ update. No QBankDb refactor, search behavior, Ben architecture, or unrelated feature work was changed.

## Version

- versionName: 8.3.514
- versionCode: 604

## Offline validation

- Changed Kotlin brace balance: PASS
- Local Kotlin language check for local `lateinit` capture: PASS
- Version monotonicity: PASS
- Source diff scope: 4 files changed
- Android Gradle compilation: BLOCKED because Gradle 9.3.1 could not be downloaded (`downloads.gradle.org` DNS failure)
- CI: PENDING
- Device/runtime: PENDING
