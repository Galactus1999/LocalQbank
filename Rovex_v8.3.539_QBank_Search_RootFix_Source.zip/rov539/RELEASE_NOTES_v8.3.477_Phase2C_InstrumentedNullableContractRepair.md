# v8.3.477 — Phase 2C Instrumentation Nullable-Result Contract Repair

## Root cause
CI reached `:app:compileDebugAndroidTestKotlin` but failed because
`RovexStage7InstrumentedTest.groundedBenPipelineReturnsSafeAnswerWhenNeuralAccelerationIsUnavailable`
dereferenced `BenGroundedNeuralPipeline.Result?` as non-null.

`BenGroundedNeuralPipeline.run()` intentionally returns `Result?`: `null` is the accelerator-failure/fallback signal, and `ExperiencePerformanceManager` owns deterministic recovery.

## Repair
Updated the Stage 7 test to handle the nullable pipeline contract:
- `null` is accepted as the intentional fallback signal.
- When a neural result exists, the existing answer/evidence/elapsed safety assertions remain.
- No production Ben pipeline, IPC, model, retrieval, or fallback implementation was changed.

## Verification
- Static source contract check: PASS.
- Version check: PASS (`8.3.477`, versionCode `568`).
- Full Gradle/Android-test compilation: not yet verified after this repair.
- CI/device/runtime: pending.
