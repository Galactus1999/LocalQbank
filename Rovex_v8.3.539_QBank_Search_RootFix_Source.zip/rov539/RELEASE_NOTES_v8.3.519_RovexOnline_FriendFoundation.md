# Rovex v8.3.519 — Online Friend Foundation

## Scope
- Redesigned Rovex Online into clearer account/progress/friends sections.
- Separated local internet state from friend presence; the target user is never required to be online for a friend request.
- Added Copy ID / Share ID actions.
- Added a durable local friend-request outbox keyed by Rovex ID.
- If the requesting device is offline, or Firestore cannot resolve a code because the client is offline, the request is preserved locally and retried through WorkManager when connectivity returns.
- Permanent data errors do not poison the whole outbox.
- Preserved Firestore as the server-authoritative social backend.

## Important behavior
A friend request is an account-to-account operation, not a presence operation. The other user can be completely offline when the request is created. True presence is a separate realtime subsystem and is not faked by Firestore account lookup.

## Validation status
- Source/diff audit: PENDING
- JVM tests: PENDING
- Android Gradle compile/CI: PENDING
- Device/runtime validation: PENDING
