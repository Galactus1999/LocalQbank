# Rovex v8.3.465 — Answer Audio Exclusivity + Celebration Visibility Repair

## Scope
Targeted Phase-2 engagement/feedback repair. No Ben IPC, neural runtime, QBank database, search, or business-logic ownership changes.

## Root repairs
- Removed answer-option click audio from the pre-commit UI path.
- Emit exactly one sound after an answer is accepted:
  - ordinary answer: click cue;
  - configured milestone with milestone sound enabled: milestone cue replaces click cue.
- Prevented ordinary + milestone sounds from overlapping at milestone answers.
- Pre-install the celebration overlay when QuizActivity content is attached instead of first creating it only at the milestone.
- Hardened celebration z-order with `bringToFront()` and high translationZ/elevation.
- Clamp target coordinates into the visible overlay bounds.
- Explicitly enable custom drawing and invalidate/request layout when starting the animation.
- Added a larger deterministic core pulse so the celebration remains visually obvious even when procedural particles are subtle.

## Verification status
STATIC ONLY until CI executes. Do not claim build/device/runtime PASS from this source package alone.
