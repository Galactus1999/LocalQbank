# v8.3.529 — Rovex Online Friend Mailbox Materialization Repair

## Root cause
The recipient mailbox materialization batch attempted to write both the recipient-owned incoming request and the sender-owned outgoing request. Firestore rules correctly allow the recipient to create the incoming document but do not allow the recipient to create a document under the sender UID. The batch therefore failed atomically with PERMISSION_DENIED, leaving the mailbox request undelivered.

## Repair
- Recipient materialization now creates only its own incoming request.
- The sender-owned outgoing record remains the sender's existing document created at send time.
- Mailbox entries are deleted only after incoming materialization commits successfully.
- Existing accept/decline flow remains responsible for updating the sender-owned outgoing record.
- No Cloud Function and no Blaze plan are required.

## Verification status
- Source delimiter audit: pending/perform before release.
- Firebase Rules deployment: existing 8.3.528 rules deployment confirmed separately.
- Android CI/device: pending.
