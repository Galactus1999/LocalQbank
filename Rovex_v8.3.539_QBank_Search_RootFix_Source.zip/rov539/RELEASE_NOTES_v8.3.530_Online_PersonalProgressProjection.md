# v8.3.530 — Rovex Online Personal Progress Projection

## Root cause
The Online screen previously displayed aggregate counters from `users/{uid}`. Those counters were maintained by the `acceptStudyEvent` Cloud Function, which is not deployed because the Firebase project is not on Blaze. Consequently study events could be stored while the displayed aggregate remained zero.

## Repair
- Added deterministic `RovexOnlineProgressProjector` based on existing local QBank progress, flashcard review log, and streak state.
- `MY PROGRESS` now renders from local study state and does not wait for a Cloud Function or remote aggregate.
- Best-effort projection sync writes the same personal counters back to the authenticated user's Firestore profile.
- Firestore Rules allow only the authenticated owner to update these projection fields.
- Marked `progressSource=client_projection` to distinguish this from server-authoritative aggregation.
- No Cloud Function or Blaze plan is required for the personal progress path.
- Existing immutable `studyEvents` submission is preserved for future server-authoritative processing.

## Verification
- Added JVM tests for answered/correct/today/card/XP projection and zero/negative bounds.
- Android compile/CI/device verification remains required before calling the release green.

## Current verification status
- Source delimiter audit: PASS.
- Firebase rules file: syntactically inspected; deployment required.
- Local Gradle JVM test execution: BLOCKED because `downloads.gradle.org` DNS resolution is unavailable in the current environment.
- CI/device/runtime verification: PENDING.
