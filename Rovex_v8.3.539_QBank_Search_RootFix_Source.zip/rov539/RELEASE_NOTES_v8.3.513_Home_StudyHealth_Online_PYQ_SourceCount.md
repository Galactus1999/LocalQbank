# Rovex v8.3.513 — Home / Study Health / PYQ information update

- Added a dedicated Rovex Online visual info card to Home.
- Replaced the static Home greeting with a deterministic daily study quote. Expanded the quote library.
- PYQ-focused QBank rows now show the whole imported source/QBank question count alongside the PYQ attempt information.
- Added Study Health screen using existing local flashcard due state, QBank progress/weak areas, and authoritative study streak data.
- Added Home Study Health entry point.
- No new study-data owner; all surfaces are read-only over existing managers/repositories.

Validation status: source/static validation required; Android build/CI/device validation pending.
