# v8.3.491 — Quiz Swipe Navigation Move

## Scope
Move-only extraction from `QuizActivity.kt`.

### Changed files
- `QuizActivity.kt`
- `QuizSwipeNavigationController.kt` (new)
- `app/build.gradle.kts` (version bump)
- this release note

## Change
Moved quiz horizontal swipe gesture state and navigation handling out of `QuizActivity` into `QuizSwipeNavigationController`.

The controller receives explicit state/action callbacks and does not retain an `Activity` reference.

## Behavior
No intended behavior change. Existing thresholds, direction handling, question navigation, session completion, exam submission, timing, rendering, and guidance-timer calls are preserved.

## Verification
Static/source audit only at preparation time. CI/device validation pending.
