# v8.3.539 — QBank Search Root Fix

## Root cause
The FTS health contract could publish `dirty=0` when the FTS table was only partially populated. Interactive search trusted that state and returned the partial FTS result set without proving normalized SQLite coverage, so valid QBank questions could be invisible to search.

## Repair
- FTS schema recreation now marks the index dirty.
- FTS health requires live-question coverage to equal live rows represented in FTS.
- Incremental import finalization only publishes `dirty=0` after the same coverage check.
- Existing authoritative LIKE fallback remains available.
- Added an Android regression test for a falsely-clean partial FTS index.

## Scope
No QBank ownership, import identity, delete semantics, or search escaping contract was changed.
