# Rovex v8.3.521 — Realtime Friend Presence

## Scope
- Repair the v8.3.520 JVM regression reported by CI: `RovexFriendRequestFailureTest.permissionDeniedIsNotRetryable` failed with `ExceptionInInitializerError` because the test directly instantiated a Firebase Firestore exception in a JVM test. The classifier now exposes a pure code-name helper and the JVM test no longer initializes the Firebase Android exception class.
- Add Firebase Realtime Database for presence only. Firestore remains authoritative for identity, friendships, requests and progress.
- Add multi-device-safe per-installation connection nodes using `onDisconnect()`.
- Track online/offline and last-seen state without requiring the friend to be online for friendship/request operations.
- Restrict presence reads to the owner or accepted friends through an RTDB `presenceAccess` ACL mirrored by server-side Cloud Functions from Firestore friendship documents.
- Show presence status in Friends Arena without adding chat in this batch.

## Firebase configuration
- RTDB URL: `https://rovex-81c4e-default-rtdb.asia-southeast1.firebasedatabase.app`
- `database.rules.json` added and wired into `firebase.json`.
- Cloud Functions mirror Firestore friendship create/delete events into `presenceAccess`.

## Verification
- Static/source audit required.
- JVM tests must pass before release/CI is considered green.
- CI/device presence verification remains pending until actual execution.
