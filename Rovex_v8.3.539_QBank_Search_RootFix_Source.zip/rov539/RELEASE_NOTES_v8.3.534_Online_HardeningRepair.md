# Rovex v8.3.534 — Online Presence + Social Hardening Repair

## Deep-scan repairs
- Restored the v8.3.532 friend-request transport to a true write-first/offline-first batch. Removed the 533 preflight `outgoing.get()` regression.
- Bounded friend presence listener reads to the newest 32 connection records to prevent unbounded stale-installation reads.
- Removed obsolete RTDB deployment configuration because no application or Cloud Function code uses RTDB/presenceAccess.
- Added mixed stale/fresh multi-device presence regression coverage.
- Replaced the stale v8.3.532-only CI workflow with a direct v8.3.534 workflow that uses the runner's installed Android SDK tools without the obsolete `android-actions/setup-android` `tools` package path.

## Release identity
- versionName: `8.3.534`
- versionCode: `624`

## Verification
- PASS: standalone compilation of `RovexPresenceState.kt`
- PASS: XML parse / per-layout duplicate-ID scan (37 layouts)
- PASS: changed-source delimiter audit
- PASS: friend transport source contract audit
- PASS: RTDB application-reference audit
- BLOCKED: full Gradle tests locally because `downloads.gradle.org` DNS is unavailable
- PENDING: GitHub CI
- PENDING: Firebase rules deployment
- PENDING: device presence regression
