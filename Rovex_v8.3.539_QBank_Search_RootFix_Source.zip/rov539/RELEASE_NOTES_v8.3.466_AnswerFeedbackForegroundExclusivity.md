# Rovex v8.3.466 — Answer Feedback Exclusivity / Foreground Milestone Repair

## Baseline
- Starting source: v8.3.465 / versionCode 556
- Starting source SHA-256: ce480e2a3c70a13c477a446cd612ebc5aa33ebc877345d3792290fad3bab7b82
- Package: com.localqbank.library
- Candidate: v8.3.466 / versionCode 557

## Root cause
`QuizActivity` emits in-session milestone feedback after an accepted answer. The global
`StudyEventSpine` also emits `milestone_reached`, and `MainActivity` remained subscribed
while stopped underneath QuizActivity. Its listener did not check `isVisible`, so the
same milestone could produce a second milestone sound from the background Home Activity.

The sound engine also allowed two SoundPool streams and could overlap fallback MediaPlayer
instances during the asynchronous sample-loading window.

## Repair
1. MainActivity milestone presentation is now foreground-gated with `isVisible`.
   QuizActivity remains the owner of in-session milestone feedback.
2. RovexSoundFeedback now uses a single SoundPool stream.
3. Direct MediaPlayer fallback is explicitly stopped/released before another fallback
   or SoundPool cue begins.
4. Fallback player lifecycle is cleaned during release.
5. No Ben IPC, QBank database, search, importer, or business-logic ownership changes.
6. versionCode incremented monotonically 556 -> 557.

## Celebration visibility
The existing v8.3.465 celebration implementation was re-audited:
- host is pre-installed after QuizActivity content attachment;
- overlay uses full-size content-root LayoutParams;
- milestone trigger posts after attachment;
- zero-size views retry on the next animation frame;
- target coordinates are clamped;
- overlay is brought to front with high Z;
- drawing is explicitly enabled/invalidation-driven;
- celebration failures remain non-fatal.

No additional speculative celebration rewrite was made because source inspection alone
cannot establish device visibility.

## Verification matrix

| Area | Result | Evidence |
|---|---|---|
| Source SHA/version/package | VERIFIED | archive SHA and Gradle/source inspection |
| Diff audit | STATIC PASS | exactly 3 changed files; no DB/Ben IPC changes |
| Per-layout duplicate IDs | STATIC PASS | 0 duplicate IDs within individual XML layouts |
| Defect regression audit | VERIFIED | tools/verify_defect_regressions.sh |
| Online architecture audit | VERIFIED | tools/verify_online_architecture.sh |
| Performance/search architecture audit | VERIFIED | tools/verify_performance_search_architecture.sh |
| Coroutine cancellation audit | VERIFIED | tools/audit_coroutine_cancellation.py |
| Frankenstein policy audit | VERIFIED | tools/audit_frankenstein_policy.py |
| Phase-2 stability gate | FAILED/BLOCKED | existing AI-display normalization condition; not caused by this repair |
| Architecture regression audit | FAILED | pre-existing QuizActivity >1800-line threshold |
| JVM unit tests | BLOCKED | Gradle 9.3.1 download blocked by DNS |
| Android build | BLOCKED | Gradle 9.3.1 download blocked by DNS |
| CI | BLOCKED | no CI execution in this environment |
| Instrumented tests | BLOCKED | no build/device |
| Device validation | BLOCKED | no APK/device execution |
| Runtime audio validation | BLOCKED | no device execution |
| Runtime celebration visibility | BLOCKED | no device execution |
| Performance benchmark | BLOCKED | no runtime/device execution |

The source package must therefore NOT be described as runtime/device verified or release-green.
