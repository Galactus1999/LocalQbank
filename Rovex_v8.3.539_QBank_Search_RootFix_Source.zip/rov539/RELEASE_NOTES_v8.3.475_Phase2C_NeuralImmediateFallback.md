# Rovex v8.3.475 — Phase 2C Neural Failure Immediate Fallback

## Evidence
v8.3.474 device testing showed that reducing EmbeddingGemma rerank timeout from the historical generic 30 s/retry path to a single 8 s attempt removed the ~64 s pathological wait, but the request still took ~12.6 s.

The v8.3.474 source shows why: when `rerankSuspend()` returned null, `BenGroundedNeuralPipeline` continued through the neural pipeline and could reach generation/fallback logic. Its internal deterministic recovery used `BenCognitiveArchitecture.answer()`, which is slower than the authoritative fast deterministic QBank fallback. This created an additional multi-second tail after the 8 s rerank timeout.

## Repair
- `BenGroundedNeuralPipeline.run()` now returns `null` immediately when semantic reranking is unavailable.
- Generation failure and verification failure also return `null` to the outer owner instead of invoking the slower internal deterministic answer path.
- `ExperiencePerformanceManager` remains the authoritative owner of deterministic fallback and therefore executes the bounded `fastDeterministicFallback()` path.
- Restored the v8.3.473 deterministic fallback trace and stale verification/citation cleanup so diagnostics distinguish neural-attempt time from deterministic fallback time.
- Neural remains explicitly OFF by default and no IPC transport architecture was rewritten.

## Expected behavior
A failed EmbeddingGemma rerank should now incur only the dedicated bounded rerank attempt plus the fast deterministic fallback, rather than adding a second slow deterministic recovery/generation path.

## Verification status
- Static/source repair: prepared.
- XML/compile/CI/device: pending.
