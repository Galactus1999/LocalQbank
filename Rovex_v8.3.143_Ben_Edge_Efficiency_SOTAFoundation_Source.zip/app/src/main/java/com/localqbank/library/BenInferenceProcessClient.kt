package com.localqbank.library

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Main-process IPC facade. The connection is retained for the life of this client so Gemma's
 * short-lived conversation can stay warm, while Binder death/timeout remains a normal fallback.
 */
class BenInferenceProcessClient(context: Context) : AutoCloseable {
    private val app = context.applicationContext
    private val callbackThread = HandlerThread("ben-inference-callback").also { it.start() }
    private val callbackHandler = Handler(callbackThread.looper)
    private val lock = Any()
    @Volatile private var remote: Messenger? = null
    @Volatile private var closed = false
    @Volatile private var warm = false
    private var connection: ServiceConnection? = null

    fun generate(prompt: String, maxTokens: Int = 160): String? = request(
        what = BenInferenceProcessService.CMD_GENERATE,
        data = Bundle().apply {
            putString(BenInferenceProcessService.KEY_PROMPT, prompt.take(6_000))
            putInt(BenInferenceProcessService.KEY_MAX_TOKENS, maxTokens.coerceIn(32, 192))
        }
    ) { message ->
        if (message.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false)) null
        else message.data.getString(BenInferenceProcessService.KEY_TEXT)
    }

    data class RerankResult(val indices: IntArray, val scores: DoubleArray, val elapsedMs: Long, val usedModel: Boolean)

    fun rerank(query: String, candidates: List<String>, limit: Int = 8): RerankResult? = request(
        what = BenInferenceProcessService.CMD_RERANK,
        data = Bundle().apply {
            putString(BenInferenceProcessService.KEY_QUERY, query.take(1_800))
            putStringArrayList(BenInferenceProcessService.KEY_CANDIDATES, ArrayList(candidates.take(8).map { it.take(1_800) }))
            putInt(BenInferenceProcessService.KEY_LIMIT, limit.coerceIn(1, 8))
        }
    ) { message ->
        if (message.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false)) null
        else RerankResult(
            message.data.getIntArray(BenInferenceProcessService.KEY_INDICES) ?: IntArray(0),
            message.data.getDoubleArray(BenInferenceProcessService.KEY_SCORES) ?: DoubleArray(0),
            message.data.getLong(BenInferenceProcessService.KEY_ELAPSED, 0L),
            message.data.getBoolean(BenInferenceProcessService.KEY_USED_MODEL, false)
        )
    }

    fun diagnostic(): String? = request(
        what = BenInferenceProcessService.CMD_DIAGNOSTIC,
        data = Bundle()
    ) { message ->
        if (message.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false)) null
        else message.data.getString(BenInferenceProcessService.KEY_REPORT)
    }

    fun compare(first: String, second: String): Double? = request(
        what = BenInferenceProcessService.CMD_COMPARE,
        data = Bundle().apply {
            putString(BenInferenceProcessService.KEY_FIRST, first.take(1_800))
            putString(BenInferenceProcessService.KEY_SECOND, second.take(1_800))
        }
    ) { message ->
        if (message.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false)) null
        else message.data.getDouble(BenInferenceProcessService.KEY_SCORE, Double.NaN).takeUnless { it.isNaN() }
    }

    private fun ensureBound(): Messenger? {
        remote?.let { return it }
        synchronized(lock) {
            remote?.let { return it }
            if (closed) return null
            val latch = CountDownLatch(1)
            val conn = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                    remote = service?.let { Messenger(it) }
                    latch.countDown()
                }
                override fun onServiceDisconnected(name: ComponentName?) { remote = null; warm = false }
                override fun onBindingDied(name: ComponentName?) { remote = null; warm = false }
                override fun onNullBinding(name: ComponentName?) { remote = null; warm = false; latch.countDown() }
            }
            connection = conn
            if (!app.bindService(Intent(app, BenInferenceProcessService::class.java), conn, (Context.BIND_AUTO_CREATE or Context.BIND_NOT_FOREGROUND))) {
                connection = null
                return null
            }
            latch.await(2_000L, TimeUnit.MILLISECONDS)
            return remote
        }
    }

    private fun <T> request(what: Int, data: Bundle, decode: (Message) -> T?): T? {
        val target = ensureBound() ?: return null
        val latch = CountDownLatch(1)
        var output: T? = null
        val replyHandler = Handler(callbackHandler.looper) { message ->
            output = runCatching { decode(message) }.getOrElse { null }
            latch.countDown()
            true
        }
        return try {
            target.send(Message.obtain(null, what).apply {
                replyTo = Messenger(replyHandler)
                this.data = data
            })
            val timeout = if (warm) 5_000L else 35_000L
            if (!latch.await(timeout, TimeUnit.MILLISECONDS)) {
                trim()
                null
            } else {
                if (output != null) warm = true
                output
            }
        } catch (_: RemoteException) {
            remote = null
            warm = false
            null
        } catch (_: Exception) {
            remote = null
            warm = false
            null
        }
    }

    fun trim() {
        synchronized(lock) {
            connection?.let { runCatching { app.unbindService(it) } }
            connection = null
            remote = null
            warm = false
        }
    }

    override fun close() {
        synchronized(lock) {
            closed = true
            connection?.let { runCatching { app.unbindService(it) } }
            connection = null
            remote = null
            warm = false
        }
        callbackThread.quitSafely()
    }
}
