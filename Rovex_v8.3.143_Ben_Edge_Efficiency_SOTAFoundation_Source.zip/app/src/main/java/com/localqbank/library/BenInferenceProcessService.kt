package com.localqbank.library

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import android.os.Process
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.ExecutionException

/**
 * Native-inference crash boundary for Ben.
 *
 * This service deliberately lives in :inference_process. It owns no study state, QBank DB,
 * learner memory or UI. Only the optional neural runtimes are allowed through this boundary.
 */
class BenInferenceProcessService : Service() {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "ben-inference-process") }
    private val runtimeLock = Any()
    private val handlerThread by lazy { HandlerThread("ben-inference-binder").also { it.start() } }
    private var generator: BenLiteRtLmGenerator? = null
    private var embedding: BenEmbeddingGemmaEngine? = null
    private var generatorWarm = false
    private var embeddingWarm = false
    private lateinit var messenger: Messenger

    override fun onCreate() {
        super.onCreate()
        messenger = Messenger(Handler(handlerThread.looper) { message -> handle(message) })
    }

    private fun handle(message: Message): Boolean {
        val reply = message.replyTo
        when (message.what) {
            CMD_GENERATE -> {
                val prompt = message.data.getString(KEY_PROMPT).orEmpty()
                val maxTokens = message.data.getInt(KEY_MAX_TOKENS, 160)
                val result = runBounded("generation", if (generatorWarm) 3_000L else 30_000L) {
                        if (generator == null) generator = BenLiteRtLmGenerator(applicationContext)
                        runBlocking { generator!!.generate(prompt, maxTokens)?.text }
                    }
                if (result != null) generatorWarm = true
                sendReply(reply, REPLY_GENERATE, Bundle().apply {
                    putString(KEY_TEXT, result)
                    putBoolean(KEY_FAILED, result == null)
                })
            }
            CMD_RERANK -> {
                val query = message.data.getString(KEY_QUERY).orEmpty()
                val candidates = message.data.getStringArrayList(KEY_CANDIDATES) ?: arrayListOf()
                val limit = message.data.getInt(KEY_LIMIT, 8)
                val result = runBounded("embedding", if (embeddingWarm) 3_000L else 30_000L) {
                        if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                        val wrapped = candidates.mapIndexed { index, text -> Candidate(index, text) }
                        runBlocking {
                            embedding!!.rerank(query, wrapped, { it.text }, limit.coerceIn(1, 8))
                        }
                    }
                if (result != null) embeddingWarm = true
                sendReply(reply, REPLY_RERANK, Bundle().apply {
                    if (result == null) {
                        putBoolean(KEY_FAILED, true)
                    } else {
                        putIntArray(KEY_INDICES, result.hits.map { it.item.index }.toIntArray())
                        putDoubleArray(KEY_SCORES, result.hits.map { it.similarity }.toDoubleArray())
                        putLong(KEY_ELAPSED, result.elapsedMs)
                        putBoolean(KEY_USED_MODEL, result.usedModel)
                    }
                })
            }
            CMD_DIAGNOSTIC -> {
                val result = runBounded("diagnostic", 30_000L) {
                    if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                    runBlocking { embedding!!.diagnostic() }
                }
                sendReply(reply, REPLY_DIAGNOSTIC, Bundle().apply {
                    putString(KEY_REPORT, result)
                    putBoolean(KEY_FAILED, result == null)
                })
            }
            CMD_COMPARE -> {
                val first = message.data.getString(KEY_FIRST).orEmpty()
                val second = message.data.getString(KEY_SECOND).orEmpty()
                val result = runBounded("comparison", if (embeddingWarm) 3_000L else 30_000L) {
                    if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                    runBlocking { embedding!!.compare(first, second) }
                }
                if (result != null) embeddingWarm = true
                sendReply(reply, REPLY_COMPARE, Bundle().apply {
                    putDouble(KEY_SCORE, result ?: Double.NaN)
                    putBoolean(KEY_FAILED, result == null)
                })
            }
            CMD_PING -> sendReply(reply, REPLY_PING, Bundle().apply { putBoolean(KEY_OK, true) })
            else -> return false
        }
        return true
    }

    private data class Candidate(val index: Int, val text: String)

    private fun <T> runBounded(kind: String, timeoutMs: Long, block: () -> T): T? {
        val future = executor.submit<T> { synchronized(runtimeLock) { block() } }
        return try {
            future.get(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (timeout: java.util.concurrent.TimeoutException) {
            future.cancel(true)
            BenNeuralTelemetry.error("Isolated $kind inference exceeded ${timeoutMs} ms; terminating inference process")
            Thread {
                Thread.sleep(100L)
                Process.killProcess(Process.myPid())
            }.start()
            null
        } catch (error: ExecutionException) {
            future.cancel(true)
            val cause = error.cause
            if (cause is Error) throw cause
            BenNeuralTelemetry.error("Isolated $kind inference failed: ${cause?.javaClass?.simpleName ?: error.javaClass.simpleName}")
            null
        } catch (error: Exception) {
            future.cancel(true)
            BenNeuralTelemetry.error("Isolated $kind inference failed: ${error.javaClass.simpleName}")
            null
        }
    }

    private fun sendReply(target: Messenger?, what: Int, data: Bundle) {
        if (target == null) return
        runCatching { target.send(Message.obtain(null, what).apply { this.data = data }) }
    }

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    override fun onUnbind(intent: Intent?): Boolean {
        closeRuntimes()
        return false
    }

    override fun onDestroy() {
        closeRuntimes()
        executor.shutdownNow()
        handlerThread.quitSafely()
        super.onDestroy()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) closeRuntimes()
    }

    private fun closeRuntimes() {
        synchronized(runtimeLock) {
            runCatching { generator?.close() }
            generator = null
            runCatching { embedding?.close() }
            embedding = null
            generatorWarm = false
            embeddingWarm = false
        }
    }

    companion object {
        const val CMD_GENERATE = 1
        const val CMD_RERANK = 2
        const val CMD_PING = 3
        const val CMD_DIAGNOSTIC = 4
        const val CMD_COMPARE = 5
        const val REPLY_GENERATE = 101
        const val REPLY_RERANK = 102
        const val REPLY_DIAGNOSTIC = 104
        const val REPLY_COMPARE = 105
        const val REPLY_PING = 103
        const val KEY_PROMPT = "prompt"
        const val KEY_MAX_TOKENS = "maxTokens"
        const val KEY_QUERY = "query"
        const val KEY_CANDIDATES = "candidates"
        const val KEY_LIMIT = "limit"
        const val KEY_TEXT = "text"
        const val KEY_INDICES = "indices"
        const val KEY_SCORES = "scores"
        const val KEY_ELAPSED = "elapsedMs"
        const val KEY_USED_MODEL = "usedModel"
        const val KEY_FAILED = "failed"
        const val KEY_OK = "ok"
        const val KEY_REPORT = "report"
        const val KEY_FIRST = "first"
        const val KEY_SECOND = "second"
        const val KEY_SCORE = "score"
    }
}
