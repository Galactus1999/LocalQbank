package com.localqbank.library

/** Deterministic bounds and hygiene for text returned by optional Ben backends.
 *
 * AI responses are presentation data, never executable HTML/CSS. The renderer receives
 * Markdown only; CSS, scripts, event handlers and layout-bearing HTML are removed here so
 * a malformed response cannot alter the Android text renderer or theme.
 */
object BenResponsePolicy {
    const val MAX_RESPONSE_CHARS = 16_384
    private val styleBlock = Regex("(?is)<style\\b[^>]*>.*?</style\\s*>")
    private val scriptBlock = Regex("(?is)<script\\b[^>]*>.*?</script\\s*>")
    private val eventAttribute = Regex("(?is)\\bon[a-z][a-z0-9_-]*\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)")
    private val styleAttribute = Regex("(?is)\\bstyle\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)")
    private val cssRule = Regex("(?s)(?:^|(?<=}))\\s*[^{}]{1,240}\\{[^{}]{1,5000}\\}")
    private val htmlTag = Regex("(?is)</?(?:!doctype|html|head|body|main|section|article|div|span|table|thead|tbody|tr|th|td|p|br|hr|ul|ol|li|h[1-6]|strong|b|em|i|u|code|pre|blockquote|a|img|mark|small|sup|sub)(?:\\s+[^>]*)?>")

    fun normalize(raw:String?):String? {
        var x=raw?.replace("\r\n","\n")?.replace("\r","\n") ?: return null
        x=x.replace("\\u0000"," ")
            .replace(styleBlock," ")
            .replace(scriptBlock," ")
            .replace(eventAttribute," ")
            .replace(styleAttribute," ")
        repeat(4){ x=cssRule.replace(x," ") }
        // AI presentation must not leak arbitrary HTML into the Markdown renderer.
        x=htmlTag.replace(x," ")
        return BoundedTextPolicy.normalize(x,MAX_RESPONSE_CHARS)
    }
}
