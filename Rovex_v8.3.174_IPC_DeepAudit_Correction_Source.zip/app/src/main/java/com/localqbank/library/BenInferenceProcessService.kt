package com.localqbank.library

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import android.os.Process
import android.os.Parcel
import android.os.PowerManager
import android.os.Build
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Isolated neural-runtime service.
 *
 * v8.3.145: single-flight/latest-request-wins generation, explicit remote cancellation, native
 * LiteRT-LM async streaming, and a release barrier before a replacement request may run.
 */
class BenInferenceProcessService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val singleFlight = Mutex()
    private val requests = ConcurrentHashMap<String, GenerationControl>()
    private val oneShotRequests = ConcurrentHashMap<String, OneShotControl>()
    private val serviceGenerationId = AtomicLong(System.nanoTime())
    private val latestGenerationSequence = AtomicLong(0L)
    private val handlerThread by lazy { HandlerThread("ben-inference-binder").also { it.start() } }
    private var generator: BenLiteRtLmGenerator? = null
    private var embedding: BenEmbeddingGemmaEngine? = null
    private var generatorWarm = false
    private var embeddingWarm = false
    private lateinit var messenger: Messenger
    private val powerManager by lazy { getSystemService(PowerManager::class.java) }
    private val lifecycleHandler by lazy { Handler(mainLooper) }
    private val warmTrimRunnable = Runnable {
        if (requests.isEmpty() && oneShotRequests.isEmpty()) {
            scope.launch {
                singleFlight.withLock { closeRuntimes() }
                runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
                stopSelf()
            }
        }
    }

    // v8.3.166: nothing in this service previously kept the OS from treating
    // :inference_process as an ordinary background process. On aggressive OEM battery
    // managers (OnePlus/OxygenOS in particular) a background process doing sustained
    // NPU/CPU work for tens of seconds is a well-known freeze/throttle target -- the
    // process stays alive (no Binder death, so the client never sees
    // INFERENCE_PROCESS_DIED) but simply stops making progress, which looks exactly like
    // the "Stage: IDLE" / IPC timeout symptom reported from a device diagnostic run.
    // beginForegroundWork()/endForegroundWork() promote this process to foreground
    // priority (notification + wake lock) only while a generation or diagnostic request
    // is actually in flight, and demote it again as soon as none are, so it isn't a
    // silently always-on foreground service.
    private var wakeLock: PowerManager.WakeLock? = null
    private val activeForegroundOps = AtomicInteger(0)
    private val foregroundPromoted = AtomicBoolean(false)

    private fun beginForegroundWork(): Boolean {
        if (activeForegroundOps.getAndIncrement() != 0) return foregroundPromoted.get()
        promoteForegroundIfNeeded()
        if (!foregroundPromoted.get()) {
            activeForegroundOps.decrementAndGet()
            return false
        }
        runCatching {
            val lock = wakeLock ?: powerManager
                ?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Rovex:BenInference")
                ?.apply { setReferenceCounted(false) }
                ?.also { wakeLock = it }
            lock?.acquire(WAKE_LOCK_TIMEOUT_MS)
        }.onFailure { BenNeuralTelemetry.error("Wake lock acquire failed: ${it.javaClass.simpleName}: ${it.message}") }
        return true
    }

    private fun promoteForegroundIfNeeded() {
        if (foregroundPromoted.get()) return
        runCatching {
            ensureNotificationChannel()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(
                    FOREGROUND_NOTIFICATION_ID,
                    buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
                )
            } else {
                startForeground(FOREGROUND_NOTIFICATION_ID, buildNotification())
            }
            foregroundPromoted.set(true)
        }.onFailure {
            foregroundPromoted.set(false)
            BenNeuralTelemetry.error("Foreground promotion failed: ${it.javaClass.simpleName}: ${it.message}")
        }
    }

    private fun endForegroundWork() {
        if (activeForegroundOps.updateAndGet { (it - 1).coerceAtLeast(0) } != 0) return
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(FOREGROUND_CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(FOREGROUND_CHANNEL_ID, "Ben on-device AI", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Shown only while Ben is running an on-device model test or answer"
                setShowBadge(false)
            }
        )
    }

    private fun buildNotification(): Notification {
        // minSdk is 26, so the channel-based constructor is always available here.
        return Notification.Builder(this, FOREGROUND_CHANNEL_ID)
            .setContentTitle("Ben is running an on-device test")
            .setContentText("EmbeddingGemma / Ben neural runtime")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
                        .build()
    }
    private val thermalListener = if (Build.VERSION.SDK_INT >= 29) object : PowerManager.OnThermalStatusChangedListener {
        override fun onThermalStatusChanged(status: Int) {
            if (status >= PowerManager.THERMAL_STATUS_SEVERE) activeGeneration?.cancel()
        }
    } else null
    @Volatile private var activeGeneration: GenerationControl? = null

    private class GenerationControl(
        val requestId: String,
        val clientGeneration: Long,
        val reply: Messenger,
        val sequence: Long,
    ) {
        val cancelled = AtomicBoolean(false)
        val terminalSent = AtomicBoolean(false)
        val nativeReleased = AtomicBoolean(false)
        val nativeStarted = AtomicBoolean(false)
        val lifecycle = BenIpcLifecycleState()
        @Volatile var job: Job? = null
        @Volatile var nativeCancel: (() -> Unit)? = null

        fun cancel() {
            if (cancelled.compareAndSet(false, true)) runCatching { nativeCancel?.invoke() }
        }
    }

    private class OneShotControl(
        val requestId: String,
        val clientGeneration: Long,
        val reply: Messenger?,
    ) {
        val cancelled = AtomicBoolean(false)
        val terminalSent = AtomicBoolean(false)
        val phase = AtomicReference("queued")
        @Volatile var job: Job? = null
    }

    override fun onCreate() {
        super.onCreate()
        messenger = Messenger(Handler(handlerThread.looper) { message -> handle(message) })
        if (Build.VERSION.SDK_INT >= 29) runCatching { thermalListener?.let { powerManager?.addThermalStatusListener(it) } }
    }

    private fun handle(message: Message): Boolean {
        if (bundleSizeBytes(message.data) > MAX_IPC_PAYLOAD_BYTES) {
            val replyCode = when (message.what) {
                CMD_PING -> REPLY_PING
                CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
                else -> REPLY_GENERATE
            }
            sendReply(message.replyTo, replyCode, Bundle().apply {
                putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
                putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
                putBoolean(KEY_FAILED, true)
                putString(KEY_ERROR, "IPC_PAYLOAD_TOO_LARGE")
            })
            return true
        }
        when (message.what) {
            CMD_GENERATE -> startGeneration(message)
            CMD_CANCEL -> cancelGeneration(message.data.getString(KEY_REQUEST_ID).orEmpty())
            CMD_RERANK, CMD_DIAGNOSTIC, CMD_COMPARE -> startOneShot(message)
            CMD_PING -> sendReply(message.replyTo, REPLY_PING, Bundle().apply {
                putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
                putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
                putBoolean(KEY_OK, true)
            })
            else -> return false
        }
        return true
    }

    private fun startGeneration(message: Message) {
        val requestId = message.data.getString(KEY_REQUEST_ID).orEmpty()
        val reply = message.replyTo ?: return
        if (requestId.isBlank()) return
        activeGeneration?.cancel()
        requests.values.forEach { if (it !== activeGeneration) it.cancel() }
        val control = GenerationControl(
            requestId = requestId,
            clientGeneration = message.data.getLong(KEY_CLIENT_GENERATION),
            reply = reply,
            sequence = latestGenerationSequence.incrementAndGet(),
        )
        requests[requestId] = control
        control.job = scope.launch {
            if (!beginForegroundWork()) {
                sendTerminal(control, failed = true, error = "IPC_FGS_PROMOTION_FAILED")
                requests.remove(requestId, control)
                return@launch
            }
            val watchdog = launch {
                delay(GENERATION_HARD_TIMEOUT_MS)
                if (!control.terminalSent.get() && requests[control.requestId] === control) {
                    BenNeuralTelemetry.error("Generation hard deadline exceeded; terminating isolated inference process")
                    Process.killProcess(Process.myPid())
                }
            }
            try {
                singleFlight.withLock {
                    if (control.cancelled.get() || control.sequence != latestGenerationSequence.get()) return@withLock
                    activeGeneration = control
                    control.nativeStarted.set(true)
                    try {
                        runGeneration(control, message.data.getString(KEY_PROMPT).orEmpty(), message.data.getInt(KEY_MAX_TOKENS, 160))
                    } finally {
                        watchdog.cancel()
                        control.lifecycle.released()
                        control.nativeReleased.set(true)
                        activeGeneration = null
                    }
                }
            } finally {
                watchdog.cancel()
                requests.remove(requestId, control)
                endForegroundWork()
            }
        }
    }

    private suspend fun runGeneration(control: GenerationControl, prompt: String, maxTokens: Int) {
        val governor = BenAiResourceGovernor(applicationContext)
        val policy = BenAiRuntimePolicy(applicationContext)
        val profile = BenNeuralModelRegistry.gemma3_270m
        val installed = BenNeuralModelManager(applicationContext).installed(profile)
        if (installed == null || !governor.mayRun(policy, profile.estimatedRuntimeMb, foreground = true)) {
            sendTerminal(control, failed = true, error = "Generation blocked by model/resource policy")
            return
        }
        val promptBudget = BenAiResourceGate.promptBudgetChars(governor.snapshot(foreground = true).thermalStatus)
        if (promptBudget <= 0) {
            sendTerminal(control, failed = true, error = "Thermal safety gate denied neural generation")
            return
        }
        try {
            if (generator == null) generator = BenLiteRtLmGenerator(applicationContext)
            val stream = generator!!.generateStream(
                prompt = prompt.take(promptBudget),
                maxOutputTokens = maxTokens,
                onCancel = { control.cancelled.get() },
                onNativeCancelReady = { cancel -> control.nativeCancel = cancel },
            )
            stream
                .catch { error ->
                    if (error is CancellationException || control.cancelled.get()) {
                        sendTerminal(control, cancelled = true)
                    } else {
                        policy.recordBackendFailure()
                        sendTerminal(control, failed = true, error = error.message ?: error.javaClass.simpleName)
                    }
                }
                .collect { chunk ->
                    if (!control.cancelled.get()) sendToken(control, chunk)
                }
            if (control.cancelled.get()) {
                sendTerminal(control, cancelled = true)
            } else {
                policy.recordBackendSuccess()
                sendTerminal(control, text = controlReplyText.remove(control.requestId)?.toString().orEmpty())
            }
        } catch (error: Exception) {
            if (error is Error) throw error
            if (control.cancelled.get() || error is CancellationException) sendTerminal(control, cancelled = true)
            else {
                policy.recordBackendFailure()
                sendTerminal(control, failed = true, error = error.message ?: error.javaClass.simpleName)
            }
        }
    }

    private val controlReplyText = ConcurrentHashMap<String, StringBuilder>()

    private fun sendToken(control: GenerationControl, token: String) {
        if (control.cancelled.get()) return
        controlReplyText.getOrPut(control.requestId) { StringBuilder() }.append(token)
        sendReply(control.reply, REPLY_TOKEN, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_TOKEN, token)
        })
    }

    private fun sendTerminal(
        control: GenerationControl,
        text: String? = null,
        failed: Boolean = false,
        cancelled: Boolean = false,
        error: String? = null,
    ) {
        if (!control.lifecycle.terminal()) return
        control.terminalSent.set(true)
        val finalText = text ?: controlReplyText.remove(control.requestId)?.toString().orEmpty()
        sendReply(control.reply, REPLY_GENERATE, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_TEXT, finalText)
            putBoolean(KEY_FAILED, failed)
            putBoolean(KEY_CANCELLED, cancelled)
            if (error != null) putString(KEY_ERROR, error)
        })
    }

    private fun sendOneShotFailure(control: OneShotControl, command: Int, error: String) {
        if (!control.terminalSent.compareAndSet(false, true)) return
        val reply = control.reply ?: return
        val data = Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putBoolean(KEY_FAILED, true)
            putString(KEY_ERROR, error)
            if (command == CMD_COMPARE) putDouble(KEY_SCORE, Double.NaN)
        }
        sendReply(reply, when (command) {
            CMD_RERANK -> REPLY_RERANK
            CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
            else -> REPLY_COMPARE
        }, data)
    }

    private fun cancelGeneration(requestId: String) {
        if (requestId.isBlank()) return
        val control = requests[requestId]
        if (control != null) {
            control.cancel()
        } else {
            oneShotRequests[requestId]?.cancelled?.set(true)
        }
        if (control == null) return
        // LiteRT-LM documents that CancelProcess() can leave a native session unusable, and
        // current upstream reports show that a pathological cancellation can delay session
        // release. Never let that wedge the single-flight barrier indefinitely: the isolated
        // process is disposable, so kill it after a short cancellation grace period.
        scope.launch {
            delay(CANCEL_GRACE_MS)
            if (!control.nativeReleased.get() && requests[requestId] === control) {
                BenNeuralTelemetry.error("Cancellation grace exceeded; terminating isolated inference process")
                Process.killProcess(Process.myPid())
            }
        }
    }

    private fun startOneShot(message: Message) {
        val requestId = message.data.getString(KEY_REQUEST_ID).orEmpty()
        val reply = message.replyTo
        if (requestId.isBlank()) return
        val control = OneShotControl(requestId, message.data.getLong(KEY_CLIENT_GENERATION), reply)
        oneShotRequests[requestId] = control
        control.job = scope.launch {
            if (!beginForegroundWork()) {
                sendOneShotFailure(control, message.what, "IPC_FGS_PROMOTION_FAILED")
                oneShotRequests.remove(requestId, control)
                return@launch
            }
            val hardTimeout = if (message.what == CMD_DIAGNOSTIC) DIAGNOSTIC_HARD_TIMEOUT_MS else ONE_SHOT_HARD_TIMEOUT_MS
            val watchdog = launch {
                if (message.what == CMD_DIAGNOSTIC) {
                    // Give the diagnostic a little longer than the expected cold start, but
                    // surface the exact phase before the disposable isolated process is killed.
                    delay(DIAGNOSTIC_PREKILL_MS)
                    if (oneShotRequests[requestId] === control && control.phase.get() != "complete") {
                        val phase = control.phase.get()
                        sendOneShotFailure(control, message.what, "SERVER_DIAGNOSTIC_TIMEOUT_STAGE=$phase")
                        BenNeuralTelemetry.error("Diagnostic hard deadline approaching; stage=$phase")
                    }
                }
                delay(if (message.what == CMD_DIAGNOSTIC) DIAGNOSTIC_KILL_GRACE_MS else hardTimeout)
                if (oneShotRequests[requestId] === control) {
                    val phase = control.phase.get()
                    if (message.what == CMD_DIAGNOSTIC) {
                        sendOneShotFailure(control, message.what, "SERVER_DIAGNOSTIC_HARD_TIMEOUT_STAGE=$phase")
                    }
                    BenNeuralTelemetry.error("One-shot hard deadline exceeded; terminating isolated inference process; stage=$phase")
                    Process.killProcess(Process.myPid())
                }
            }
            try {
                singleFlight.withLock {
                    if (control.cancelled.get()) return@withLock
                    if (Build.VERSION.SDK_INT >= 29 && (powerManager?.currentThermalStatus ?: PowerManager.THERMAL_STATUS_NONE) >= PowerManager.THERMAL_STATUS_SEVERE) {
                        sendOneShotFailure(control, message.what, "Thermal safety gate denied neural operation")
                        return@withLock
                    }
                    if (message.what == CMD_DIAGNOSTIC) {
                        control.phase.set("accepted")
                        sendOneShotProgress(control, "Remote diagnostic accepted by isolated Ben process")
                        control.phase.set("admission")
                        sendOneShotProgress(control, "Starting full EmbeddingGemma contract + NPU test")
                    }
                    handleOneShot(message, control)
                }
            } finally {
                watchdog.cancel()
                oneShotRequests.remove(requestId, control)
                endForegroundWork()
            }
        }
    }

    private suspend fun handleOneShot(message: Message, control: OneShotControl) {
        val reply = control.reply
        if (control.cancelled.get()) return
        val result = when (message.what) {
            CMD_RERANK -> runCatching {
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                val query = message.data.getString(KEY_QUERY).orEmpty()
                val candidates = message.data.getStringArrayList(KEY_CANDIDATES) ?: arrayListOf()
                val limit = message.data.getInt(KEY_LIMIT, 8)
                embedding!!.rerank(query, candidates.mapIndexed { index, text -> Candidate(index, text) }, { it.text }, limit.coerceIn(1, 8))
            }.getOrNull()?.let { r -> Bundle().apply {
                putIntArray(KEY_INDICES, r.hits.map { it.item.index }.toIntArray())
                putDoubleArray(KEY_SCORES, r.hits.map { it.similarity }.toDoubleArray())
                putLong(KEY_ELAPSED, r.elapsedMs)
                putBoolean(KEY_USED_MODEL, r.usedModel)
                putBoolean(KEY_FAILED, false)
            }} ?: Bundle().apply { putBoolean(KEY_FAILED, true) }
            CMD_DIAGNOSTIC -> runCatching {
                control.phase.set("engine_start")
                sendOneShotProgress(control, "Initializing EmbeddingGemma runtime • first run may take around 20 seconds")
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                control.phase.set("diagnostic")
                embedding!!.diagnostic { progress ->
                    control.phase.set(progress.take(80))
                    sendOneShotProgress(control, progress)
                }
            }.getOrNull()?.let { Bundle().apply { putString(KEY_REPORT, it); putBoolean(KEY_FAILED, false) } }
                ?: Bundle().apply { putBoolean(KEY_FAILED, true) }
            CMD_COMPARE -> runCatching {
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                embedding!!.compare(message.data.getString(KEY_FIRST).orEmpty(), message.data.getString(KEY_SECOND).orEmpty())
            }.getOrNull()?.let { Bundle().apply { putDouble(KEY_SCORE, it); putBoolean(KEY_FAILED, false) } }
                ?: Bundle().apply { putDouble(KEY_SCORE, Double.NaN); putBoolean(KEY_FAILED, true) }
            else -> Bundle().apply { putBoolean(KEY_FAILED, true) }
        }
        if (control.cancelled.get()) return
        if (message.what == CMD_DIAGNOSTIC) {
            control.phase.set("complete")
            sendOneShotProgress(control, "Diagnostic complete • publishing report")
        }
        if (!control.terminalSent.compareAndSet(false, true)) return
        result.putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
        result.putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
        sendReply(reply, when (message.what) {
            CMD_RERANK -> REPLY_RERANK
            CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
            else -> REPLY_COMPARE
        }, result)
    }

    private data class Candidate(val index: Int, val text: String)

    private fun sendOneShotProgress(control: OneShotControl, progress: String) {
        val reply = control.reply ?: return
        sendReply(reply, REPLY_DIAGNOSTIC_PROGRESS, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_PROGRESS, progress.take(220))
        })
    }

    private fun sendReply(target: Messenger?, what: Int, data: Bundle) {
        if (target == null) return
        runCatching { target.send(Message.obtain(null, what).apply { this.data = data }) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService() requires prompt promotion. Promote immediately in
        // onStartCommand(), before Binder/native work, so a cold NPU initialization cannot
        // outrun Android's foreground-service deadline.
        promoteForegroundIfNeeded()
        // The service is deliberately START_NOT_STICKY: Ben's neural runtime is disposable.
        // A process restart must go through the normal client binding/resource admission path,
        // never silently resurrect a heavyweight native runtime in the background.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder {
        lifecycleHandler.removeCallbacks(warmTrimRunnable)
        return messenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        requests.values.forEach { it.cancel() }
        oneShotRequests.values.forEach { it.cancelled.set(true) }
        // Keep a successfully initialized runtime warm for a short bounded window. This avoids
        // paying EmbeddingGemma's ~20 s cold initialization for every isolated request, while
        // still trimming deterministically when the process becomes idle.
        lifecycleHandler.removeCallbacks(warmTrimRunnable)
        lifecycleHandler.postDelayed(warmTrimRunnable, WARM_RUNTIME_TTL_MS)
        return false
    }

    override fun onDestroy() {
        lifecycleHandler.removeCallbacks(warmTrimRunnable)
        if (Build.VERSION.SDK_INT >= 29) runCatching { thermalListener?.let { powerManager?.removeThermalStatusListener(it) } }
        requests.values.forEach { it.cancel() }
        oneShotRequests.values.forEach { it.cancelled.set(true) }
        // Do not synchronously close native runtimes from Service.onDestroy(). onDestroy() can
        // run while the service coroutine is still returning from native inference; direct close
        // here would reintroduce the exact concurrent-close race this barrier prevents. The
        // isolated process is disposable, so OS process teardown is the final cleanup boundary.
        scope.coroutineContext[Job]?.cancel()
        handlerThread.quitSafely()
        // Defensive: the coroutine finally blocks normally pair every beginForegroundWork()
        // with endForegroundWork(), but if the service is torn down mid-request, make sure
        // the wake lock does not outlive the process.
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        super.onDestroy()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) {
            scope.launch { singleFlight.withLock { closeRuntimes() } }
        }
    }

    private fun bundleSizeBytes(bundle: Bundle): Int {
        return runCatching {
            val parcel = Parcel.obtain()
            return try {
                bundle.writeToParcel(parcel, 0)
                parcel.dataSize()
            } finally {
                parcel.recycle()
            }
        }.getOrDefault(Int.MAX_VALUE)
    }

    private fun closeRuntimes() {
        runCatching { generator?.close() }
        generator = null
        generatorWarm = false
        runCatching { embedding?.close() }
        embedding = null
        embeddingWarm = false
    }

    companion object {
        const val CMD_GENERATE = 1
        const val CMD_RERANK = 2
        const val CMD_PING = 3
        const val CMD_DIAGNOSTIC = 4
        const val CMD_COMPARE = 5
        const val CMD_CANCEL = 6
        const val REPLY_GENERATE = 101
        const val REPLY_RERANK = 102
        const val REPLY_DIAGNOSTIC = 104
        const val REPLY_COMPARE = 105
        const val REPLY_PING = 103
        const val REPLY_TOKEN = 106
        const val REPLY_DIAGNOSTIC_PROGRESS = 107
        const val KEY_REQUEST_ID = "requestId"
        const val KEY_CLIENT_GENERATION = "clientGeneration"
        const val KEY_PROMPT = "prompt"
        const val KEY_MAX_TOKENS = "maxTokens"
        const val KEY_QUERY = "query"
        const val KEY_CANDIDATES = "candidates"
        const val KEY_LIMIT = "limit"
        const val KEY_TEXT = "text"
        const val KEY_TOKEN = "token"
        const val KEY_INDICES = "indices"
        const val KEY_SCORES = "scores"
        const val KEY_ELAPSED = "elapsedMs"
        const val KEY_USED_MODEL = "usedModel"
        const val KEY_FAILED = "failed"
        const val KEY_CANCELLED = "cancelled"
        const val KEY_ERROR = "error"
        const val KEY_OK = "ok"
        const val KEY_REPORT = "report"
        const val KEY_PROGRESS = "progress"
        const val KEY_FIRST = "first"
        const val KEY_SECOND = "second"
        const val KEY_SCORE = "score"
        private const val CANCEL_GRACE_MS = 2_500L
        private const val GENERATION_HARD_TIMEOUT_MS = 45_000L
        private const val ONE_SHOT_HARD_TIMEOUT_MS = 30_000L
        private const val DIAGNOSTIC_PREKILL_MS = 100_000L
        private const val DIAGNOSTIC_HARD_TIMEOUT_MS = 120_000L
        private const val DIAGNOSTIC_KILL_GRACE_MS = 2_500L
        private const val FOREGROUND_CHANNEL_ID = "ben_inference_foreground"
        private const val FOREGROUND_NOTIFICATION_ID = 4171
        // Slightly longer than the longest hard deadline in this file (DIAGNOSTIC_HARD_TIMEOUT_MS)
        // so the lock cannot expire out from under a legitimately still-running diagnostic; every
        // acquire() is still paired with a release() in endForegroundWork()/onDestroy(), this is
        // only a backstop against a leaked wake lock outliving its request.
        private const val WAKE_LOCK_TIMEOUT_MS = 130_000L
        // Evidence-driven warm retention: the verified SM8650 cold init is ~20 s while warm
        // inference is ~100 ms. Keep the native runtime for 120 s after unbind, then trim.
        private const val WARM_RUNTIME_TTL_MS = 120_000L
        private const val MAX_IPC_PAYLOAD_BYTES = 128 * 1024
    }
}
