package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

class BenActivity : AppCompatActivity() {
    private lateinit var store: BenAgentStore
    private lateinit var mesh: BenMeshView
    private lateinit var status: TextView
    private lateinit var face: BenFaceView
    private lateinit var prompt: TextView
    private val executor=Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store=BenAgentStore(this)
        setContentView(build())
        refreshMesh()
    }

    override fun onDestroy(){
        executor.shutdownNow()
        if(::store.isInitialized)store.shutdown()
        super.onDestroy()
    }

    private fun panel(color:Int, radius:Float=18f)=android.graphics.drawable.GradientDrawable().apply{
        setColor(color); cornerRadius=radius*resources.displayMetrics.density
        setStroke((1*resources.displayMetrics.density).toInt(),Color.rgb(39,61,80))
    }

    private fun build(): LinearLayout {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(10),dp(16),dp(16));setBackgroundColor(Color.rgb(4,9,15))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(ImageView(this).apply{setImageResource(R.drawable.ic_ben_cosmic);contentDescription="Ben cosmic logo"},LinearLayout.LayoutParams(dp(44),dp(44)))
        val name=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        name.addView(TextView(this).apply{text="BEN";textSize=25f;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD);letterSpacing=.08f})
        status=TextView(this).apply{text="ONLINE • LOCAL BRAIN • RESOURCE AWARE";textSize=11f;setTextColor(Color.rgb(72,181,255));setPadding(0,dp(1),0,0)}
        name.addView(status);top.addView(name,LinearLayout.LayoutParams(0,-2,1f))
        top.addView(TextView(this).apply{text="⋮";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setOnClickListener{showInfo()}},LinearLayout.LayoutParams(dp(42),dp(48)))
        root.addView(top)

        face=BenFaceView(this).apply{setMode(BenFaceView.Mode.IDLE);contentDescription="Ben robotic avatar"}
        val faceWrap=FrameLayout(this).apply{addView(face,FrameLayout.LayoutParams(-1,dp(170)));background=panel(Color.rgb(7,15,24),22f)}
        root.addView(faceWrap,LinearLayout.LayoutParams(-1,dp(180)).apply{setMargins(0,dp(10),0,dp(10))})

        val greeting=TextView(this).apply{
            text="I’m Ben. I can reason across your QBank, learn from your performance and help you decide what to do next.\n\nAsk me anything—or tap a command below."
            textSize=15f;setTextColor(Color.rgb(224,236,245));setLineSpacing(0f,1.15f);setPadding(dp(14),dp(12),dp(14),dp(12));background=panel(Color.rgb(10,22,34),16f)
        }
        root.addView(greeting)

        val quick=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f}
        fun qButton(text:String, action:()->Unit){quick.addView(Button(this).apply{this.text=text;isAllCaps=false;textSize=11f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(15,69,104));setOnClickListener{action()}},LinearLayout.LayoutParams(0,dp(52),1f).apply{setMargins(dp(2),dp(8),dp(2),dp(2))})}
        qButton("Explain",::showAsk);qButton("Quiz me",::showAsk);qButton("My weak areas",::showAsk)
        root.addView(quick)

        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=panel(Color.rgb(7,16,26),18f)}
        card.addView(TextView(this).apply{text="LIVE KNOWLEDGE MESH";textSize=12f;typeface=android.graphics.Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(91,190,255));letterSpacing=.08f})
        prompt=TextView(this).apply{text="Building Ben’s map…";textSize=12f;setTextColor(Color.rgb(150,174,191));setPadding(0,dp(5),0,dp(7))};card.addView(prompt)
        mesh=BenMeshView(this); card.addView(mesh,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(card,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,dp(10),0,dp(10))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val ask=Button(this).apply{text="Talk to Ben";isAllCaps=false;textSize=14f;setOnClickListener{showAsk()}}
        val study=Button(this).apply{text="Study with Ben";isAllCaps=false;textSize=14f;setOnClickListener{startActivity(Intent(this@BenActivity,StudyToolsActivity::class.java))}}
        actions.addView(ask,LinearLayout.LayoutParams(0,dp(54),1f).apply{setMargins(0,0,dp(4),0)});actions.addView(study,LinearLayout.LayoutParams(0,dp(54),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        return root
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    private fun refreshMesh(){
        executor.execute {
            runCatching {
                runOnUiThread{if(!isFinishing&&!isDestroyed){face.setMode(BenFaceView.Mode.THINKING);prompt.text="Ben is analysing your local study state…"}}
                BenAgentEngine.run(applicationContext)
                val nodes=store.nodes(); val edges=store.edges(); val weak=store.weakCount(); val events=store.eventCount()
                runOnUiThread{if(!isFinishing&&!isDestroyed){mesh.submit(nodes,edges);face.setMode(BenFaceView.Mode.FOCUSED);prompt.text="${nodes.size} active nodes • $weak weak areas • $events learned events";status.text="ONLINE • LEARNING STATE UPDATED"}}
            }.onFailure{runOnUiThread{if(!isFinishing&&!isDestroyed){face.setMode(BenFaceView.Mode.ALERT);status.text="SAFE PAUSE";prompt.text="Ben paused to protect the device: ${it.message ?: "temporary error"}"}}}
        }
    }

    private fun showAsk(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(4),dp(8),0)}
        val f=BenFaceView(this).apply{setMode(BenFaceView.Mode.FOCUSED)};box.addView(f,LinearLayout.LayoutParams(-1,dp(120)))
        val input=EditText(this).apply{hint="Talk to Ben…";minLines=2;maxLines=4}
        box.addView(input)
        val hints=TextView(this).apply{text="Try: explain this • why is this wrong? • quiz me • my weak areas • what should I study next?";textSize=11.5f;setTextColor(Color.rgb(90,110,125));setPadding(0,dp(8),0,0)};box.addView(hints)
        AlertDialog.Builder(this).setTitle("Talk to Ben").setView(box).setPositiveButton("Think"){_,_->
            val q=input.text.toString().trim();if(q.isBlank())return@setPositiveButton
            face.setMode(BenFaceView.Mode.THINKING)
            executor.execute{val answer=runCatching{BenBrain.reply(this@BenActivity,q)}.getOrElse{"I couldn't access the local study data right now."};runOnUiThread{if(!isFinishing&&!isDestroyed){face.setMode(BenFaceView.Mode.FOCUSED);AlertDialog.Builder(this).setTitle("BEN").setMessage(answer).setPositiveButton("Continue",null).show()}}}
        }.setNegativeButton("Cancel",null).show()
    }

    private fun showInfo(){
        AlertDialog.Builder(this).setTitle("BEN • operating model").setMessage("Ben is a local-first adaptive agent. He can use your QBank, learning history and knowledge mesh. His background work is deliberately bounded by Android resource and power safeguards.\n\nHe is designed to learn strategies and relationships over time without rewriting his executable code.").setPositiveButton("Understood",null).show()
    }
}
