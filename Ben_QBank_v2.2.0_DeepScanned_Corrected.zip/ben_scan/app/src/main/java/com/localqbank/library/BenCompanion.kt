package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.concurrent.Executors

/** Lightweight Ben companion available across QBank screens. */
object BenCompanion {
    private val executor=Executors.newFixedThreadPool(2)
    fun attach(activity:Activity,label:String="") {
        if(activity is BenActivity) return
        val content=activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        if(content.findViewWithTag<View>("ben-companion")!=null) return
        val d=activity.resources.displayMetrics.density
        val b=TextView(activity).apply{
            tag="ben-companion";text="BEN";textSize=12f;typeface=Typeface.create("sans-serif",Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.WHITE)
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_ben_face,0,0,0);compoundDrawablePadding=(5*d).toInt()
            background=GradientDrawable().apply{setColor(Color.rgb(7,25,39));cornerRadius=28f*d;setStroke((1*d).toInt(),Color.rgb(52,178,255))};elevation=7f*d;setPadding((10*d).toInt(),0,(14*d).toInt(),0)
            contentDescription="Talk to Ben";setOnClickListener{showChat(activity,label)}
        }
        content.addView(b,FrameLayout.LayoutParams(-2,(54*d).toInt(),Gravity.BOTTOM or Gravity.END).apply{setMargins((8*d).toInt(),(8*d).toInt(),(14*d).toInt(),(14*d).toInt())})
    }
    fun setQuestionContext(title:String,section:String,question:String,explanation:String){BenBrain.setContext(BenBrain.ContextInfo(title,section,question,explanation))}
    private fun showChat(activity:Activity,label:String){
        val box=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(12,6,12,4)}
        val top=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(BenFaceView(activity).apply{setMode(BenFaceView.Mode.FOCUSED)},LinearLayout.LayoutParams(96,96))
        top.addView(TextView(activity).apply{text="I’m Ben. Context: ${label.ifBlank{"current screen"}}\nI can use the question you’re viewing and your local learning history.";textSize=14f;setTextColor(Color.rgb(35,48,60));setPadding(10,0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        box.addView(top)
        val history=TextView(activity).apply{text="\nBen: Ready. Ask directly, or use one of the commands below.";textSize=14.5f;setTextColor(Color.rgb(30,45,55));setPadding(0,4,0,8)}
        box.addView(history)
        val inputRef=EditText(activity).apply{hint="Talk to Ben…";minLines=2;maxLines=4}
        val quick=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        listOf("Explain this","Quiz me","My weak areas","Study next").forEach{t->quick.addView(Button(activity).apply{this.text=t;isAllCaps=false;textSize=10.5f;setOnClickListener{send(activity,history,inputRef,t)}},LinearLayout.LayoutParams(0,54,1f).apply{setMargins(2,2,2,2)})}
        box.addView(quick)
        box.addView(inputRef)
        val sendButton=Button(activity).apply{text="Send to Ben";isAllCaps=false;setOnClickListener{send(activity,history,inputRef,inputRef.text.toString())}}
        box.addView(sendButton,LinearLayout.LayoutParams(-1,54))
        AlertDialog.Builder(activity).setTitle("BEN").setView(box).setNegativeButton("Close",null).show()
    }
    private fun send(activity:Activity,history:TextView,input:EditText,raw:String){
        val q=raw.trim();if(q.isBlank())return
        input.setText("");history.append("\n\nYou: $q\nBen: Thinking…")
        executor.execute{val answer=runCatching{BenBrain.reply(activity,q)}.getOrElse{"I hit a temporary local-data problem. Try again."};activity.runOnUiThread{if(!activity.isFinishing&&!activity.isDestroyed){history.text=history.text.toString().replace("Ben: Thinking…","Ben: $answer")}}}
    }
}
