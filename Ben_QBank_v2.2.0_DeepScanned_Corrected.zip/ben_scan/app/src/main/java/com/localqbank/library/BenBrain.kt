package com.localqbank.library

import android.content.Context

/** Lightweight local-first reasoning layer. No continuous LLM or network work. */
object BenBrain {
    data class ContextInfo(val title:String="", val section:String="", val question:String="", val explanation:String="")
    @Volatile private var current=ContextInfo()
    fun setContext(info:ContextInfo){ current=info }
    fun clearContext(){ current=ContextInfo() }

    fun reply(context:Context, input:String):String {
        val q=input.trim()
        if(q.isBlank()) return "I'm here. Ask me about this question, a topic, your weak areas, revision, or what to study next."
        val db=QBankDb(context.applicationContext); val store=ProgressStore(context.applicationContext); val agent=BenAgentStore(context.applicationContext)
        return try {
            agent.observe("ben_chat",q.take(240),1.0)
            val l=q.lowercase(); val nodes=agent.nodes(16)
            when {
                l.contains("hello") || l=="hi" || l.startsWith("hi ") || l.contains("hey") -> "Hey! I'm Ben. I can work across your local QBank, learn from your answers, and help you decide what to do next."
                l.contains("explain this") || l.contains("this question") || l.contains("why") -> explainCurrent()
                l.contains("what should i study") || l.contains("what do i study") || l.contains("next") || l.contains("weak") || l.contains("revise") -> recommend(nodes)
                l.contains("quiz me") || l.contains("test me") || l.contains("ask me") -> "Let's do it. Tell me a topic, or say 'start' to use the current QBank context. I can keep the questions focused on your weak areas."
                l.contains("progress") || l.contains("performance") || l.contains("accuracy") -> performance(store,db)
                else -> searchAnswer(q,db)
            }
        } finally { db.close(); agent.shutdown() }
    }
    private fun explainCurrent():String {
        val c=current
        if(c.question.isBlank() && c.explanation.isBlank()) return "Open a question first and ask me 'explain this'. Then I can use that question's local explanation."
        if(c.explanation.isNotBlank()) {
            val clean=c.explanation.replace(Regex("<[^>]*>")," ").replace(Regex("\\s+")," ").trim()
            return "Here is the explanation from your local QBank:\n\n${clean.take(1800)}\n\nYou can ask me to simplify it, compare it, or quiz you on it."
        }
        return "I have the current question but no stored explanation. Ask me about a specific part of the stem and I'll search your local QBank for related material."
    }
    private fun recommend(nodes:List<BenAgentStore.Node>):String {
        val weak=nodes.filter{it.kind=="weak" || it.confidence<0.55}.take(5)
        return if(weak.isNotEmpty()) "I'd prioritise ${weak.joinToString(", "){it.label.removePrefix("Weak: ")}}. I'm using your recent learning signals rather than choosing randomly. Say 'quiz me' and I'll keep the session targeted." else "I need a little more answer history before I can confidently rank weak areas. Keep solving questions; I'll learn from each result."
    }
    private fun performance(store:ProgressStore,db:QBankDb):String {
        // Do not materialise the entire QBank just to calculate progress. Progress keys
        // are already persisted locally and can be counted directly.
        val entries=store.allProgressKeys()
        var c=0; var w=0
        entries.forEach { key ->
            if (!key.endsWith(":status")) return@forEach
            when (store.status(key.removeSuffix(":status"))) {
                "correct" -> c++
                "wrong" -> w++
            }
        }
        val totalQuestions = runCatching { db.questionCountAll() }.getOrDefault(c + w)
        val a=c+w; val acc=if(a==0)0 else c*100/a
        return "Your local record is $a attempted: $c correct, $w wrong ($acc% accuracy). $totalQuestions questions are currently in your local QBank. Ben uses these outcomes to update his weak-area model."
    }
    private fun searchAnswer(query:String,db:QBankDb):String {
        val hits=runCatching{db.search(query)}.getOrDefault(emptyList())
        if(hits.isNotEmpty()) {
            val text=hits.take(3).mapIndexed{i,h->"${i+1}. ${h.testTitle}: ${h.text.replace(Regex("<[^>]*>")," ").replace(Regex("\\s+")," ").trim().take(420)}"}.joinToString("\n")
            return "I found this in your local QBank:\n\n$text\n\nAsk 'explain this' on a question for a deeper local explanation."
        }
        val sections=runCatching{db.searchSections(query)}.getOrDefault(emptyList())
        if(sections.isNotEmpty()) return "I found relevant sections: ${sections.take(5).joinToString(", "){it.title}}. Open one and I'll stay available while you study."
        return "I don't have a strong local match yet. Try a disease, drug, topic, or exact phrase. I learn from your interactions over time."
    }
}
