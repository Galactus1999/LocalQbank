package com.localqbank.library

import android.text.Html
import android.text.Spanned

/** Dependency-free presentation helpers. WebView is used only for rich, local chat layout. */
fun rovexMarkdownToSpanned(raw: String, showTables: Boolean = true): Spanned {
    // IMPORTANT: Html.fromHtml() backs a plain TextView, not a browser engine. Android's
    // legacy parser has no real notion of <head>/<style> — it has no handler for <style>
    // the way it does for <script>, so a full document wrapper gets its raw CSS text
    // dumped straight into the visible Spanned output. Only ever hand it the body
    // fragment. The full document (rovexMarkdownToHtml) is for WebView consumers only.
    return Html.fromHtml(rovexMarkdownBody(raw, showTables), Html.FROM_HTML_MODE_LEGACY)
}

/** Full standalone HTML document — for WebView.loadDataWithBaseURL() only. Never pass this to Html.fromHtml(). */
fun rovexMarkdownToHtml(raw: String, showTables: Boolean = true): String = wrapMarkdownDocument(rovexMarkdownBody(raw, showTables))

/** The rendered body fragment (a `<p>…</p>` tree), with no doctype/html/head/style wrapper. Safe for both Html.fromHtml() and WebView body injection. */
fun rovexMarkdownBody(raw: String, showTables: Boolean = true): String {
    var s = raw.replace("\r\n", "\n").replace("\r", "\n")
        .replace(Regex("(?i)&lt;\\s*br\\s*/?\\s*&gt;"), "\n")
        .replace(Regex("(?i)<\\s*br\\s*/?\\s*>"), "\n")
        .replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        .replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
        .replace(Regex("(?is)<iframe[^>]*>.*?</iframe>"), "")
        .replace(Regex("(?is)<object[^>]*>.*?</object>"), "")
        .replace(Regex("(?is)<embed[^>]*>.*?</embed>"), "")
        .replace(Regex("(?i)on[a-z]+\\s*=\\s*(['\"]).*?\\1"), "")

    // Preserve explicit AI rich-content blocks. Ordinary prose/search output is never
    // promoted into a table/chart merely because the renderer supports those formats.
    val codeTokens = ArrayList<String>()
    val richTokens = ArrayList<String>()
    s = s.replace(
        Regex("(?s)`{2,}\\s*(mermaid|chart|tree|slides|presentation|diagram|flowchart|sequence|state|class|er|gantt|mindmap|timeline|journey|quadrant|xychart|gitgraph|requirement|architecture|sankey|block|kanban|packet|c4)\\s*\\n(.*?)`{2,}", RegexOption.IGNORE_CASE)
    ) { m ->
        val token = "@@ROVEX_RICH_${richTokens.size}@@"
        richTokens += renderExplicitRichBlock(m.groupValues[1].lowercase(), m.groupValues[2])
        token
    }
    s = s.replace(Regex("(?s)```(?:[a-zA-Z0-9_+.-]+)?\\n(.*?)```")) { m ->
        val token = "@@ROVEX_CODE_${codeTokens.size}@@"
        codeTokens += "<pre>${escHtml(m.groupValues[1])}</pre>"
        token
    }
    // Some AI providers occasionally strip the opening/closing Markdown fence while preserving
    // the Mermaid payload. Recover the common unfenced Mermaid fragment after fenced blocks have
    // already been protected, otherwise Chromium would display the Mermaid source as prose.
    s = recoverUnfencedMermaid(s, richTokens)

    val imageTokens = ArrayList<String>()
    s = s.replace(Regex("!\\[([^\\]]{0,240})\\]\\((https://[^\\s)]+|data:image/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=]+)\\)")) { m ->
        val token = "@@ROVEX_IMAGE_${imageTokens.size}@@"
        val alt = escHtml(m.groupValues[1]).replace("\"", "")
        val src = m.groupValues[2].replace("\"", "&quot;")
        imageTokens += "<img src=\"$src\" alt=\"$alt\">"
        token
    }

    val tableTokens = ArrayList<String>()
    val htmlTableTokens = ArrayList<String>()

    // Providers sometimes return a genuine HTML table instead of Markdown. Preserve the table
    // as a native scrollable table rather than escaping <table>/<tr>/<td> into visible source.
    s = s.replace(Regex("(?is)<table\\b[^>]*>.*?</table>")) { m ->
        val token = "@@ROVEX_HTML_TABLE_${htmlTableTokens.size}@@"
        htmlTableTokens += renderHtmlTable(m.value, showTables)
        token
    }

    // Some cloud providers/routers collapse Markdown newlines into spaces while preserving
    // the pipe characters. A strict line-only parser then sees one giant paragraph (the exact
    // failure mode that produced literal `|---|---|` in chat). Recover only when a real GFM
    // delimiter row is present and the surrounding pipe structure is internally consistent.
    s = normalizeCollapsedGfmTables(s)
    val lines = s.split('\n')
    val pre = StringBuilder()
    var i = 0

    fun inlineCell(cell: String): String {
        var x = escHtml(cell)
        x = x.replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("~~(.+?)~~", RegexOption.DOT_MATCHES_ALL), "<del>$1</del>")
            .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
            .replace(Regex("`([^`\\n]+?)`"), "<code>$1</code>")
            .replace(Regex("\\[([^\\]]+)]\\((https://[^\\s)]+)\\)"), "<a href=\"$2\">$1</a>")
        return x
    }

    while (i < lines.size) {
        val table = RovexMarkdownTableParser.parse(lines, i)
        if (table != null) {
            val token = "@@ROVEX_TABLE_${tableTokens.size}@@"
            val html = if (showTables) {
                StringBuilder("<div class=\"table-wrap\"><table><thead><tr>").apply {
                    table.header.forEach { append("<th>").append(inlineCell(it)).append("</th>") }
                    append("</tr></thead><tbody>")
                    table.rows.forEach { cells ->
                        append("<tr>")
                        cells.forEach { cell -> append("<td>").append(inlineCell(cell)).append("</td>") }
                        append("</tr>")
                    }
                    append("</tbody></table></div>")
                }.toString()
            } else {
                // Chat-default presentation: preserve all table information but explain it as
                // compact, readable sections instead of a dense grid. Explicit table requests
                // and the user setting still use the real table renderer.
                buildString {
                    append("<div class=\"table-as-sections\">")
                    table.rows.forEachIndexed { rowIndex, cells ->
                        val title = cells.firstOrNull().orEmpty().ifBlank { "Item ${rowIndex + 1}" }
                        append("<section><h4>").append(inlineCell(title)).append("</h4>")
                        cells.drop(1).forEachIndexed { cellIndex, cell ->
                            val label = table.header.getOrNull(cellIndex + 1).orEmpty()
                            if (label.isNotBlank()) append("<b>").append(inlineCell(label)).append(":</b> ")
                            append(inlineCell(cell)).append("<br>")
                        }
                        if (cells.size <= 1 && table.header.size > 1) {
                            table.header.drop(1).forEach { label ->
                                if (label.isNotBlank()) append("<b>").append(inlineCell(label)).append(":</b> —<br>")
                            }
                        }
                        append("</section>")
                    }
                    append("</div>")
                }
            }
            tableTokens += html
            pre.append(token).append('\n')
            i = table.nextIndex
        } else {
            pre.append(lines[i]).append('\n'); i++
        }
    }
    // The table pass builds the transformed Markdown in `pre`. Continue the rendering
    // pipeline with that transformed buffer; otherwise table tokens are never consumed
    // and every table parser regression test (and runtime table rendering) is bypassed.
    s = pre.toString()

    // Preserve supported HTML already present in imported QBank explanations. The previous
    // pipeline escaped the entire prose buffer here, turning real markup such as <p>,
    // <strong>, <sup> and <img> into visible source code (e.g. "<p><strong>...").
    // Tokenize only the small presentation-safe HTML vocabulary that Android Html.fromHtml()
    // can render, escape the surrounding prose, then restore the tags. This keeps arbitrary
    // unsupported markup inert while retaining the rich formatting supplied by the QBank.
    val htmlTokens = ArrayList<String>()
    s = s.replace(Regex("(?is)</?(?:p|strong|b|em|i|u|s|del|sup|sub|br|ul|ol|li|blockquote|h[1-6]|div|span|a|hr)(?:\\s+[^<>]*?)?/?>")) { m ->
        val token = "@@ROVEX_HTML_${htmlTokens.size}@@"
        htmlTokens += m.value
        token
    }
    s = escHtml(s)
    htmlTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_HTML_$index@@", html) }
    codeTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_CODE_$index@@", html) }
    richTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_RICH_$index@@", html) }
    imageTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_IMAGE_$index@@", html) }
    tableTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_TABLE_$index@@", html) }
    htmlTableTokens.forEachIndexed { index, html -> s = s.replace("@@ROVEX_HTML_TABLE_$index@@", html) }

    s = s.replace(Regex("(?m)^######\\s+(.+)$"), "<h6>$1</h6>")
        .replace(Regex("(?m)^#####\\s+(.+)$"), "<h5>$1</h5>")
        .replace(Regex("(?m)^####\\s+(.+)$"), "<h4>$1</h4>")
        .replace(Regex("(?m)^###\\s+(.+)$"), "<h3>$1</h3>")
        .replace(Regex("(?m)^##\\s+(.+)$"), "<h2>$1</h2>")
        .replace(Regex("(?m)^#\\s+(.+)$"), "<h1>$1</h1>")
        .replace(Regex("(?m)^>\\s?(.+)$"), "<blockquote>$1</blockquote>")
        .replace(Regex("(?m)^[-*+]\\s+"), "• ")
        .replace(Regex("(?m)^(\\d+)[.)]\\s+"), "$1. ")
        .replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("~~(.+?)~~", RegexOption.DOT_MATCHES_ALL), "<del>$1</del>")
        .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
        .replace(Regex("`([^`\\n]+?)`"), "<code>$1</code>")
        .replace(Regex("\\[([^\\]]+)]\\((https://[^\\s)]+)\\)"), "<a href=\"$2\">$1</a>")

    val blocks = Regex("(@@ROVEX_TABLE_\\d+@@|@@ROVEX_HTML_TABLE_\\d+@@|@@ROVEX_RICH_\\d+@@|<div class=\"table-wrap\">.*?</div>|<div class=\"table-as-sections\">.*?</div>|<img\\s[^>]*>|<pre>.*?</pre>)", setOf(RegexOption.DOT_MATCHES_ALL))
    val protectedBlocks = ArrayList<String>()
    s = s.replace(blocks) { m ->
        val token = "@@ROVEX_BLOCK_${protectedBlocks.size}@@"; protectedBlocks += m.value; token
    }

    // Keep block-level tables/images/code OUTSIDE paragraph elements. A previous implementation
    // replaced the protected token after wrapping the whole document in <p>, producing invalid
    // <p><div>… HTML that Chromium could relocate or drop.
    val blockPattern = Regex("@@ROVEX_BLOCK_(\\d+)@@")
    val bodyOut = StringBuilder()
    var cursor = 0
    blockPattern.findAll(s).forEach { match ->
        val textPart = s.substring(cursor, match.range.first)
        if (textPart.isNotBlank()) {
            bodyOut.append("<p>")
                .append(textPart.trim().replace(Regex("\\n{2,}"), "</p><p>").replace("\n", "<br>"))
                .append("</p>")
        }
        bodyOut.append(protectedBlocks[match.groupValues[1].toInt()])
        cursor = match.range.last + 1
    }
    val tail = s.substring(cursor)
    if (tail.isNotBlank()) {
        bodyOut.append("<p>")
            .append(tail.trim().replace(Regex("\\n{2,}"), "</p><p>").replace("\n", "<br>"))
            .append("</p>")
    }
    return bodyOut.toString()
}


/**
 * Repairs provider output that collapsed a GFM table into one physical line. This is deliberately
 * conservative: a delimiter row with >=2 columns is mandatory, and only the contiguous pipe
 * region around that delimiter is expanded. Ordinary prose containing pipes is untouched.
 */
private fun normalizeCollapsedGfmTables(input: String): String {
    val delimiter = Regex("\\|?\\s*:?-{3,}:?\\s*(?:\\|\\s*:?-{3,}:?\\s*)+\\|?")
    var text = input
    repeat(4) {
        val match = delimiter.find(text) ?: return@repeat
        val rawDelimiter = match.value
        val columns = rawDelimiter.trim().trim('|').split('|')
            .count { it.trim().matches(Regex(":?-{3,}:?")) }
        if (columns < 2 || columns > 12) return@repeat

        val lineStart = text.lastIndexOf('\n', match.range.first).let { if (it >= 0) it + 1 else 0 }
        val lineEnd = text.indexOf('\n', match.range.last + 1).let { if (it >= 0) it else text.length }
        val physicalLine = text.substring(lineStart, lineEnd)
        val before = physicalLine.substring(0, match.range.first - lineStart)
        val after = physicalLine.substring(match.range.last + 1 - lineStart)

        // The header is the final N pipe-delimited cells immediately before the delimiter.
        // Everything before that remains ordinary prose/heading text.
        val headerParts = before.trim().trim('|').split('|')
        if (headerParts.size < columns) return@repeat
        val headerCells = headerParts.takeLast(columns).map { it.trim() }
        if (headerCells.any { it.isBlank() }) return@repeat
        val prefixParts = headerParts.dropLast(columns)
        val prefix = prefixParts.joinToString(" | ").trim().trimEnd('|').trim()

        // Collapsed providers commonly encode rows as: A | B | C | D | | A2 | B2...
        // The blank pipe is a row boundary, not a table cell. Require the first cell of every
        // recovered row to be non-empty so we never turn arbitrary pipe-heavy prose into a table.
        val pieces = after.trim().trim('|').split('|').map { it.trim() }.toMutableList()
        val rows = ArrayList<String>()
        var cursor = 0
        while (cursor < pieces.size && rows.size < 80) {
            while (cursor < pieces.size && pieces[cursor].isBlank()) cursor++
            if (cursor + columns > pieces.size) break
            val group = pieces.subList(cursor, cursor + columns)
            if (group.first().isBlank() || group.drop(1).any { it.isBlank() }) break
            rows += "| ${group.joinToString(" | ")} |"
            cursor += columns
            while (cursor < pieces.size && pieces[cursor].isBlank()) cursor++
        }
        if (rows.isEmpty()) return@repeat

        val suffix = pieces.drop(cursor).filter { it.isNotBlank() }.joinToString(" | ").trim()
        val reconstructed = buildString {
            if (prefix.isNotBlank()) append(prefix).append('\n')
            append(headerCells.joinToString(" | ", prefix = "| ", postfix = " |")).append('\n')
            append((0 until columns).joinToString(" | ", prefix = "| ", postfix = " |") { "---" }).append('\n')
            rows.forEachIndexed { index, row -> append(row); if (index != rows.lastIndex) append('\n') }
            if (suffix.isNotBlank()) append(' ').append(suffix)
        }
        text = text.substring(0, lineStart) + reconstructed + text.substring(lineEnd)
    }
    return text
}

private fun escHtml(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .replace("'", "&#39;")

/**
 * Renders only explicit AI rich blocks. This is deliberately deterministic and dependency-free:
 * JavaScript/chart libraries are not loaded into the chat WebView. This keeps the chat offline,
 * fast and safer while still allowing the AI to author visual content.
 */
private fun renderExplicitRichBlock(kind: String, source: String): String = when (kind) {
    "chart" -> renderChartBlock(source)
    "tree" -> renderTreeBlock(source)
    "slides", "presentation" -> renderSlidesBlock(source)
    else -> renderMermaidBlock(source)
}

private fun recoverUnfencedMermaid(input: String, richTokens: MutableList<String>): String {
    val lines = input.split('\n')
    if (lines.size < 2) return input

    fun isHeader(line: String): Boolean {
        val x = line.trim().lowercase()
        return x.startsWith("flowchart ") || x.startsWith("graph ") ||
            x == "sequencediagram" || x.startsWith("sequencediagram ") ||
            x == "statediagram" || x.startsWith("statediagram-") ||
            x.startsWith("classdiagram") || x.startsWith("erdiagram") ||
            x == "gantt" || x.startsWith("pie ") || x == "pie" ||
            x == "mindmap" || x == "timeline" || x == "journey" ||
            x.startsWith("quadrantchart") || x.startsWith("xychart") ||
            x.startsWith("gitgraph") || x.startsWith("requirementdiagram") ||
            x.startsWith("architecture-beta") || x.startsWith("sankey") ||
            x.startsWith("block-beta") || x.startsWith("kanban") ||
            x.startsWith("packet-beta") || x.startsWith("c4")
    }

    fun mermaidLine(line: String): Boolean {
        val x = line.trim()
        if (x.isBlank()) return false
        if (isHeader(x)) return true
        return x.equals("end", true) ||
            x.startsWith("subgraph ", true) ||
            x.startsWith("classDef ", true) ||
            x.startsWith("class ", true) ||
            x.startsWith("style ", true) ||
            x.startsWith("linkStyle ", true) ||
            x.startsWith("participant ", true) ||
            x.startsWith("actor ", true) ||
            x.startsWith("section ", true) ||
            x.startsWith("title ", true) ||
            x.startsWith("dateFormat ", true) ||
            x.startsWith("axisFormat ", true) ||
            x.startsWith("state ", true) ||
            x.contains("-->") || x.contains("-->>") || x.contains("->>") ||
            x.contains("---") || x.contains("||--") || x.contains("o--") ||
            x.contains("<|--") || x.contains("*--") ||
            x.matches(Regex("^[A-Za-z0-9_:-]+(?:\\[[^]]+]|\\([^)]*\\)|\\{[^}]+\\}).*"))
    }

    val out = StringBuilder()
    var i = 0
    while (i < lines.size) {
        if (!mermaidLine(lines[i])) {
            out.append(lines[i]).append('\n')
            i++
            continue
        }
        val startIndex = i
        val block = ArrayList<String>()
        var sawStructural = isHeader(lines[i])
        while (i < lines.size) {
            val line = lines[i]
            if (line.isBlank()) break
            if (mermaidLine(line)) {
                block += line
                if (isHeader(line) || line.contains("-->") || line.contains("->>") ||
                    line.contains("-->>") || line.contains("||--") || line.contains("<|--") ||
                    line.startsWith("subgraph ", true) || line.startsWith("participant ", true) ||
                    line.startsWith("actor ", true)) sawStructural = true
                i++
            } else {
                break
            }
        }
        if (sawStructural && block.size >= 2) {
            val token = "@@ROVEX_RICH_${richTokens.size}@@"
            richTokens += renderMermaidBlock(block.joinToString("\n"))
            out.append(token).append('\n')
        } else {
            for (j in startIndex until i) out.append(lines[j]).append('\n')
        }
        if (i < lines.size && lines[i].isBlank()) {
            out.append('\n')
            i++
        }
    }
    return out.toString().trimEnd()
}

private fun renderMermaidFragment(source: String): String {
    // Providers can omit the outer flowchart/graph header and emit a subgraph directly.
    // Render it as a rich fragment and discard Mermaid-only styling directives.
    val fragment = source.lines()
        .filterNot {
            val x = it.trimStart()
            x.startsWith("classDef ", true) ||
                x.startsWith("class ", true) ||
                x.startsWith("style ", true) ||
                x.startsWith("linkStyle ", true)
        }
        .joinToString("\n")
    return renderFlowSvg(fragment.lines())
        .replaceFirst("class=\"rich-diagram\"", "class=\"rich-mermaid-fragment rich-diagram\"")
}

private fun renderMermaidBlock(source: String): String {
    val clean = source.lines()
        .map { it.trimEnd() }
        .filter { it.isNotBlank() && !it.trimStart().startsWith("%%") }
    if (clean.isEmpty()) return ""

    val first = clean.first().trim()
    val lower = first.lowercase()
    return try {
        when {
            lower.startsWith("flowchart") || lower.startsWith("graph") ->
                renderFlowSvg(clean)
            lower == "sequencediagram" || lower.startsWith("sequencediagram ") ->
                renderSequenceSvg(clean.drop(1))
            lower == "statediagram" || lower.startsWith("statediagram-") ->
                renderStateSvg(clean.drop(1))
            lower.startsWith("classdiagram") ->
                renderClassSvg(clean.drop(1))
            lower.startsWith("erdiagram") ->
                renderErSvg(clean.drop(1))
            lower == "gantt" ->
                renderGanttSvg(clean.drop(1))
            lower.startsWith("pie") -> {
                val rows = clean.drop(1).mapNotNull { line ->
                    val m = Regex("^\\\"?(.+?)\\\"?\\s*:\\s*([0-9]+(?:\\.[0-9]+)?)$").find(line)
                        ?: return@mapNotNull null
                    m.groupValues[1].trim(' ', '"') to m.groupValues[2].toDoubleOrNull()
                }.filter { it.second != null }.take(20)
                if (rows.isEmpty()) renderUnsupportedDiagram("pie", source)
                else renderPieSvg(rows.map { it.first to it.second!! })
            }
            lower == "mindmap" -> renderMindmapSvg(clean.drop(1))
            lower == "timeline" -> renderTimelineSvg(clean.drop(1))
            lower == "journey" || lower.startsWith("journey ") -> renderJourneySvg(clean.drop(1))
            lower.startsWith("quadrantchart") || lower.startsWith("xychart") ->
                renderChartLikeMermaidSvg(clean)
            lower.startsWith("gitgraph") || lower.startsWith("requirementdiagram") ||
                lower.startsWith("architecture-beta") || lower.startsWith("sankey") ||
                lower.startsWith("block-beta") || lower.startsWith("kanban") ||
                lower.startsWith("packet-beta") || lower.startsWith("c4") ->
                renderStructuredDiagramFallback(first, clean.drop(1))
            else -> {
                if (lower.startsWith("subgraph ")) {
                    renderMermaidFragment(source)
                } else {
                    val looksLikeMermaidFragment = clean.any {
                        it.startsWith("subgraph ", true) ||
                            it.matches(Regex("(?i)^(classDef|class|style|linkStyle)\\s+.*")) ||
                            it.contains("-->") || it.contains("->>") || it.contains("||--") ||
                            it.contains("<|--") || it.contains("*--")
                    }
                    if (looksLikeMermaidFragment) renderFlowSvg(clean)
                    else renderUnsupportedDiagram("diagram", source)
                }
            }
        }
    } catch (t: StackOverflowError) {
        android.util.Log.e("Rovex.RichRenderer", "Mermaid renderer stack overflow", t)
        renderUnsupportedDiagram(first.take(48), source)
    } catch (t: Exception) {
        // Rendering is presentation-only. A malformed diagram must never kill the chat.
        android.util.Log.w("Rovex.RichRenderer", "Mermaid renderer fallback: ${t.javaClass.simpleName}")
        renderUnsupportedDiagram(first.take(48), source)
    }
}

private data class MermaidNode(val id: String, val label: String, val shape: String = "rect")
private data class MermaidEdge(val from: String, val to: String, val label: String = "", val dashed: Boolean = false)

private fun parseMermaidNode(token: String): MermaidNode? {
    val t = token.trim()
    val id = Regex("^([A-Za-z0-9_][A-Za-z0-9_:-]*)").find(t)?.groupValues?.get(1) ?: return null
    val rest = t.substring(id.length)
    val patterns = listOf(
        "circle" to Regex("^\\(\\((.*?)\\)\\)"),
        "stadium" to Regex("^\\(\\[(.*?)\\]\\)"),
        "rounded" to Regex("^\\((.*?)\\)"),
        "diamond" to Regex("^\\{(.*?)\\}"),
        "hex" to Regex("^\\{\\{(.*?)\\}\\}"),
        "asym" to Regex("^>(.*?)\\]"),
        "rect" to Regex("^\\[(.*?)\\]")
    )
    patterns.forEach { (shape, regex) ->
        regex.find(rest)?.let { return MermaidNode(id, it.groupValues[1].trim(), shape) }
    }
    return null
}

private fun parseFlowGraph(lines: List<String>): Pair<List<MermaidNode>, List<MermaidEdge>> {
    val nodes = LinkedHashMap<String, MermaidNode>()
    val edges = ArrayList<MermaidEdge>()
    val nodePattern = Regex("""([A-Za-z0-9_][A-Za-z0-9_:-]*)(\[\[[^]]+\]\]|\(\([^)]*\)\)|\(\[[^]]*\]\)|\([^)]*\)|\{\{[^}]*\}\}|\{[^}]*\}|\[[^]]*\]|>[^]]+\])""")
    val operatorPattern = Regex("""(-\.->|==>|-->|---|--o|--x|---o|---x)""")

    fun addNodeIfUseful(node: MermaidNode) {
        val previous = nodes[node.id]
        if (previous == null || previous.label == previous.id || node.label != node.id) {
            nodes[node.id] = node
        }
    }

    lines.forEach { raw ->
        val line = raw.trim().removeSuffix(";")
        if (line.isBlank() || line.startsWith("classDef ", true) || line.startsWith("class ", true) ||
            line.startsWith("style ", true) || line.startsWith("linkStyle ", true) ||
            line.startsWith("subgraph ", true) || line.equals("end", true) ||
            line.matches(Regex("(?i)^(flowchart|graph)\\s+(TD|TB|BT|LR|RL)\\b"))) return@forEach

        nodePattern.findAll(line).forEach { m ->
            parseMermaidNode(m.value)?.let(::addNodeIfUseful)
        }

        val op = operatorPattern.find(line) ?: return@forEach
        var left = line.substring(0, op.range.first).trim()
        var right = line.substring(op.range.last + 1).trim()
        var edgeLabel = ""

        Regex("""^\|([^|]*)\|\s*""").find(right)?.let {
            edgeLabel = it.groupValues[1].trim()
            right = right.substring(it.range.last + 1).trim()
        }
        Regex("""\|([^|]*)\|\s*$""").find(left)?.let {
            if (edgeLabel.isBlank()) edgeLabel = it.groupValues[1].trim()
            left = left.substring(0, it.range.first).trim()
        }

        val from = parseMermaidNode(left) ?: Regex("""^[A-Za-z0-9_][A-Za-z0-9_:-]*""").find(left)?.value?.let {
            MermaidNode(it, it)
        } ?: return@forEach
        val to = parseMermaidNode(right) ?: Regex("""^[A-Za-z0-9_][A-Za-z0-9_:-]*""").find(right)?.value?.let {
            MermaidNode(it, it)
        } ?: return@forEach

        addNodeIfUseful(from)
        addNodeIfUseful(to)
        edges += MermaidEdge(from.id, to.id, edgeLabel, op.value == "-.->" || op.value == "---")
    }

    if (nodes.isEmpty()) {
        Regex("""([A-Za-z0-9_][A-Za-z0-9_:-]*)\s*(-->|---|-.->|==>)\s*(?:\|([^|]+)\|\s*)?([A-Za-z0-9_:-]+)""")
            .findAll(lines.joinToString("\n")).forEach { m ->
                val a = m.groupValues[1]
                val b = m.groupValues[4]
                addNodeIfUseful(MermaidNode(a, a))
                addNodeIfUseful(MermaidNode(b, b))
                edges += MermaidEdge(a, b, m.groupValues[3])
            }
    }
    return nodes.values.take(48) to edges.distinct().take(64)
}

private fun renderFlowSvg(lines: List<String>): String {
    val (nodes, edges) = parseFlowGraph(lines)
    if (nodes.isEmpty()) return renderUnsupportedDiagram("flowchart", lines.joinToString("\n"))

    val headerDirection = Regex("(?i)^(?:flowchart|graph)\\s+(TD|TB|BT|LR|RL)\\b").find(lines.firstOrNull().orEmpty())?.groupValues?.getOrNull(1)
    val direction = headerDirection?.uppercase() ?: "TD"
    val cols = if (direction == "LR" || direction == "RL") 1 else 3
    val cellH = 92
    val width = if (cols == 1) 780 else cols * 250 + 30
    val rows = ((nodes.size + cols - 1) / cols).coerceAtLeast(1)
    val height = (rows * cellH + 30).coerceAtMost(2400)
    fun pos(index: Int): Pair<Double,Double> {
        val row=index/cols; val col=index%cols
        return if (direction == "LR") 45.0 + row*250.0 to 55.0 + col*120.0
        else if (direction == "RL") 45.0 + row*250.0 to 55.0 + col*120.0
        else 35.0 + col*250.0 to 35.0 + row*cellH
    }
    val positions = nodes.withIndex().associate { it.value.id to pos(it.index) }
    fun nodeShape(n: MermaidNode, x:Double, y:Double): String {
        val w=205.0; val h=50.0
        val label=escHtml(n.label.replace(Regex("<[^>]+>"), " ").trim().take(140))
        return when(n.shape) {
            "circle" -> "<circle cx=\"${x+w/2}\" cy=\"${y+h/2}\" r=\"26\" class=\"node\"/><text x=\"${x+w/2}\" y=\"${y+h/2+5}\" text-anchor=\"middle\" class=\"label\">$label</text>"
            "diamond" -> "<polygon points=\"${x+w/2},$y ${x+w},${y+h/2} ${x+w/2},${y+h} $x,${y+h/2}\" class=\"node\"/><text x=\"${x+w/2}\" y=\"${y+h/2+5}\" text-anchor=\"middle\" class=\"label\">$label</text>"
            "rounded", "stadium" -> "<rect x=\"$x\" y=\"$y\" width=\"$w\" height=\"$h\" rx=\"25\" class=\"node\"/><text x=\"${x+w/2}\" y=\"${y+h/2+5}\" text-anchor=\"middle\" class=\"label\">$label</text>"
            else -> "<rect x=\"$x\" y=\"$y\" width=\"$w\" height=\"$h\" rx=\"10\" class=\"node\"/><text x=\"${x+w/2}\" y=\"${y+h/2+5}\" text-anchor=\"middle\" class=\"label\">$label</text>"
        }
    }
    val nodeHtml = nodes.map { n ->
        val (x,y)=positions[n.id] ?: (35.0 to 35.0)
        nodeShape(n,x,y)
    }.joinToString("")
    val arrows = edges.mapNotNull { e ->
        val a=positions[e.from] ?: return@mapNotNull null
        val b=positions[e.to] ?: return@mapNotNull null
        val x1=a.first+102.5; val y1=a.second+25
        val x2=b.first+102.5; val y2=b.second+25
        val label=if(e.label.isBlank()) "" else "<text x=\"${(x1+x2)/2}\" y=\"${(y1+y2)/2-5}\" text-anchor=\"middle\" class=\"edge-label\">${escHtml(e.label.take(80))}</text>"
        "<line x1=\"$x1\" y1=\"$y1\" x2=\"$x2\" y2=\"$y2\" class=\"edge ${if(e.dashed)"dashed" else ""}\" marker-end=\"url(#rovexArrow)\"/>$label"
    }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $width $height\" role=\"img\" aria-label=\"AI flowchart\"><defs><marker id=\"rovexArrow\" markerWidth=\"8\" markerHeight=\"8\" refX=\"7\" refY=\"4\" orient=\"auto\"><path d=\"M0,0 L8,4 L0,8 z\"/></marker></defs>$arrows$nodeHtml</svg></div>"
}

private fun renderSequenceSvg(lines: List<String>): String {
    val participants = LinkedHashSet<String>()
    val displayNames = LinkedHashMap<String, String>()
    val messages = ArrayList<Triple<String,String,String>>()
    lines.forEach { raw ->
        val line=raw.trim()
        Regex("(?i)^(participant|actor)\\s+([^\\s]+)(?:\\s+as\\s+(.+))?$").find(line)?.let {
            val id = it.groupValues[2]
            participants += id
            displayNames[id] = it.groupValues[3].trim().ifBlank { id }
            return@forEach
        }
        Regex("^([^\\s:]+)\\s*(?:-->>|->>|-->|->|-->>|--)\\s*([^:]+):\\s*(.+)$").find(line)?.let {
            participants += it.groupValues[1]; participants += it.groupValues[2].trim()
            messages += Triple(it.groupValues[1],it.groupValues[2].trim(),it.groupValues[3])
        }
    }
    if (participants.isEmpty()) return renderUnsupportedDiagram("sequenceDiagram", lines.joinToString("\n"))
    val names=participants.toList().take(16); val w=names.size*150+40; val h=(messages.size*62+110).coerceAtMost(2200)
    val xMap=names.mapIndexed { i,n -> n to 70.0+i*150 }.toMap()
    val headers=names.map { n ->
        val display=displayNames[n].orEmpty().ifBlank { n }
        "<rect x=\"${xMap[n]!!-48}\" y=\"12\" width=\"96\" height=\"34\" rx=\"8\" class=\"node\"/><text x=\"${xMap[n]}\" y=\"34\" text-anchor=\"middle\" class=\"label\">${escHtml(display.take(30))}</text><line x1=\"${xMap[n]}\" y1=\"46\" x2=\"${xMap[n]}\" y2=\"$h\" class=\"lifeline\"/>"
    }.joinToString("")
    val msgs=messages.mapIndexed { i,m ->
        val y=82+i*58; val x1=xMap[m.first]?:70.0; val x2=xMap[m.second]?:70.0
        "<line x1=\"$x1\" y1=\"$y\" x2=\"$x2\" y2=\"$y\" class=\"edge\" marker-end=\"url(#rovexArrow)\"/><text x=\"${(x1+x2)/2}\" y=\"${y-7}\" text-anchor=\"middle\" class=\"edge-label\">${escHtml(m.third.take(90))}</text>"
    }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $w $h\" role=\"img\" aria-label=\"AI sequence diagram\"><defs><marker id=\"rovexArrow\" markerWidth=\"8\" markerHeight=\"8\" refX=\"7\" refY=\"4\" orient=\"auto\"><path d=\"M0,0 L8,4 L0,8 z\"/></marker></defs>$headers$msgs</svg></div>"
}

private fun renderStateSvg(lines: List<String>): String {
    val edges=ArrayList<MermaidEdge>(); val states=LinkedHashSet<String>()
    lines.forEach { line ->
        val m=Regex("^\\s*([^\\s]+)\\s*(?:-->|---)\\s*([^:]+?)(?:\\s*:\\s*(.+))?$").find(line) ?: return@forEach
        val a=m.groupValues[1].trim(); val b=m.groupValues[2].trim(); states += a; states += b
        edges += MermaidEdge(a,b,m.groupValues[3].trim())
    }
    if(states.isEmpty()) return renderUnsupportedDiagram("stateDiagram",lines.joinToString("\n"))
    val list=states.toList().take(40); val w=760; val h=(list.size*68+50).coerceAtMost(2200)
    val pos=list.mapIndexed { i,n -> n to (45.0 to 25.0+i*62) }.toMap()
    val nodes=list.map { n -> val p=pos[n]!!; "<rect x=\"${p.first}\" y=\"${p.second}\" width=\"210\" height=\"38\" rx=\"10\" class=\"node\"/><text x=\"150\" y=\"${p.second+24}\" text-anchor=\"middle\" class=\"label\">${escHtml(n.take(34))}</text>" }.joinToString("")
    val arrows=edges.map { e -> val a=pos[e.from]!!; val b=pos[e.to]!!; "<line x1=\"255\" y1=\"${a.second+19}\" x2=\"255\" y2=\"${b.second+19}\" class=\"edge\" marker-end=\"url(#rovexArrow)\"/><text x=\"270\" y=\"${(a.second+b.second)/2}\" class=\"edge-label\">${escHtml(e.label.take(70))}</text>" }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $w $h\" role=\"img\" aria-label=\"AI state diagram\"><defs><marker id=\"rovexArrow\" markerWidth=\"8\" markerHeight=\"8\" refX=\"7\" refY=\"4\" orient=\"auto\"><path d=\"M0,0 L8,4 L0,8 z\"/></marker></defs>$nodes$arrows</svg></div>"
}

private fun renderClassSvg(lines: List<String>): String {
    val classes=LinkedHashMap<String,MutableList<String>>(); val relations=ArrayList<MermaidEdge>(); var current:String?=null
    lines.forEach { raw ->
        val line=raw.trim()
        Regex("^class\\s+([A-Za-z0-9_]+)").find(line)?.let { current=it.groupValues[1]; classes.putIfAbsent(it.groupValues[1], mutableListOf()); return@forEach }
        if(line=="{"||line=="}") { if(line=="}") current=null; return@forEach }
        if(current!=null && line.isNotBlank() && !line.startsWith("class ")) classes[current!!]!!.add(line.trim())
        Regex("^([A-Za-z0-9_]+)\\s+(<\\|--|\\*--|o--|--|\\.\\.>)\\s+([A-Za-z0-9_]+)(?:\\s*:\\s*(.+))?$").find(line)?.let { relations += MermaidEdge(it.groupValues[1],it.groupValues[3],it.groupValues[4]) }
    }
    if(classes.isEmpty()) return renderUnsupportedDiagram("classDiagram",lines.joinToString("\n"))
    val list=classes.entries.take(20); val w=760; val boxW=250; val boxH=80
    val boxes=list.mapIndexed { i,e -> val x=30+(i%2)*360; val y=20+(i/2)*150; val rows=e.value.take(4); "<rect x=\"$x\" y=\"$y\" width=\"$boxW\" height=\"${boxH+rows.size*22}\" rx=\"10\" class=\"node\"/><text x=\"${x+boxW/2}\" y=\"${y+24}\" text-anchor=\"middle\" class=\"label\">${escHtml(e.key)}</text>${rows.mapIndexed{j,r->"<text x=\"${x+10}\" y=\"${y+48+j*20}\" class=\"edge-label\">${escHtml(r.take(42))}</text>"}.joinToString("")}" }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $w ${((list.size+1)/2)*150+30}\" role=\"img\" aria-label=\"AI class diagram\">$boxes</svg></div>"
}

private fun renderErSvg(lines: List<String>): String {
    val entities=LinkedHashMap<String,MutableList<String>>(); val rels=ArrayList<MermaidEdge>(); var current:String?=null
    lines.forEach { raw ->
        val line=raw.trim()
        Regex("^([A-Za-z0-9_-]+)\\s*\\{").find(line)?.let { current=it.groupValues[1]; entities.putIfAbsent(it.groupValues[1], mutableListOf()); return@forEach }
        if(line=="}"){current=null;return@forEach}
        if(current!=null && !line.contains("--")) entities[current!!]!!.add(line)
        Regex("^([A-Za-z0-9_-]+)\\s+[^:]+\\s+([A-Za-z0-9_-]+)\\s*:\\s*(.+)$").find(line)?.let { rels += MermaidEdge(it.groupValues[1],it.groupValues[2],it.groupValues[3]) }
        Regex("^([A-Za-z0-9_-]+)\\s+([|o}{]+)--([|o}{]+)\\s+([A-Za-z0-9_-]+)(?:\\s*:\\s*(.+))?$").find(line)?.let { rels += MermaidEdge(it.groupValues[1],it.groupValues[4],it.groupValues[5]) }
    }
    if(entities.isEmpty()) return renderUnsupportedDiagram("erDiagram",lines.joinToString("\n"))
    val list=entities.entries.take(16); val w=760; val h=((list.size+1)/2)*150+30
    val boxes=list.mapIndexed { i,e -> val x=30+(i%2)*360; val y=20+(i/2)*150; "<rect x=\"$x\" y=\"$y\" width=\"300\" height=\"${65+e.value.take(3).size*20}\" rx=\"10\" class=\"node\"/><text x=\"${x+150}\" y=\"${y+23}\" text-anchor=\"middle\" class=\"label\">${escHtml(e.key)}</text>${e.value.take(3).mapIndexed{j,r->"<text x=\"${x+10}\" y=\"${y+45+j*19}\" class=\"edge-label\">${escHtml(r.take(48))}</text>"}.joinToString("")}" }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $w $h\" role=\"img\" aria-label=\"AI entity relationship diagram\">$boxes</svg></div>"
}

private fun renderGanttSvg(lines: List<String>): String {
    val tasks=ArrayList<Pair<String,String>>(); var section=""
    lines.forEach { line ->
        val x=line.trim()
        if(x.startsWith("section ",true)) section=x.substringAfter("section ").trim()
        else if(x.contains(":") && !x.startsWith("dateFormat") && !x.startsWith("axisFormat") && !x.startsWith("title")) {
            tasks += (if(section.isBlank()) "" else "$section • ") + x.substringBefore(":").trim() to x.substringAfter(":").trim()
        }
    }
    if(tasks.isEmpty()) return renderUnsupportedDiagram("gantt",lines.joinToString("\n"))
    val h=(tasks.size*48+50).coerceAtMost(2200); val rows=tasks.mapIndexed { i,t -> val y=30+i*45; "<text x=\"10\" y=\"${y+18}\" class=\"edge-label\">${escHtml(t.first.take(55))}</text><rect x=\"330\" y=\"$y\" width=\"${120+(t.second.length.coerceIn(1,80)*3)}\" height=\"26\" rx=\"7\" class=\"bar\"/><text x=\"340\" y=\"${y+18}\" class=\"edge-label\">${escHtml(t.second.take(55))}</text>" }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 760 $h\" role=\"img\" aria-label=\"AI gantt chart\">$rows</svg></div>"
}

private fun renderMindmapSvg(lines: List<String>): String {
    val items=lines.map { it.trim() }.filter { it.isNotBlank() && !it.equals("root",true) }.take(50)
    if(items.isEmpty()) return renderUnsupportedDiagram("mindmap",lines.joinToString("\n"))
    val h=(items.size*42+60).coerceAtMost(2200)
    val nodes=items.mapIndexed { i,x -> val indent=lines.getOrNull(i)?.takeWhile { it.isWhitespace() }?.length ?: 0; val depth=(indent/2).coerceIn(0,4); val xPos=30+depth*130; val y=30+i*40; "<rect x=\"$xPos\" y=\"$y\" width=\"${260-depth*20}\" height=\"28\" rx=\"8\" class=\"node\"/><text x=\"${xPos+8}\" y=\"${y+19}\" class=\"label\">${escHtml(x.take(80))}</text>" }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 760 $h\" role=\"img\" aria-label=\"AI mind map\">$nodes</svg></div>"
}

private fun renderTimelineSvg(lines: List<String>): String {
    val items=lines.filter { it.trim().isNotBlank() && !it.trim().startsWith("title ",true) }.take(40)
    if(items.isEmpty()) return renderUnsupportedDiagram("timeline",lines.joinToString("\n"))
    val h=items.size*55+30
    val html=items.mapIndexed { i,l -> val y=30+i*55; "<circle cx=\"40\" cy=\"$y\" r=\"7\" class=\"point\"/><line x1=\"40\" y1=\"$y\" x2=\"40\" y2=\"${y+55}\" class=\"edge\"/><text x=\"65\" y=\"${y+5}\" class=\"label\">${escHtml(l.trim().take(110))}</text>" }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 760 $h\" role=\"img\" aria-label=\"AI timeline\">$html</svg></div>"
}

private fun renderJourneySvg(lines: List<String>): String {
    val rows=lines.filter { it.contains(":") && !it.trim().startsWith("section",true) }.take(24)
    if(rows.isEmpty()) return renderUnsupportedDiagram("journey",lines.joinToString("\n"))
    val h=rows.size*48+40
    val html=rows.mapIndexed { i,l -> val p=l.split(":",limit=2); val y=25+i*45; "<rect x=\"15\" y=\"$y\" width=\"170\" height=\"30\" rx=\"8\" class=\"node\"/><text x=\"100\" y=\"${y+20}\" text-anchor=\"middle\" class=\"label\">${escHtml(p[0].trim().take(24))}</text><text x=\"205\" y=\"${y+20}\" class=\"edge-label\">${escHtml(p.getOrElse(1){""}.trim().take(100))}</text>" }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 760 $h\" role=\"img\" aria-label=\"AI journey diagram\">$html</svg></div>"
}

private fun renderChartLikeMermaidSvg(lines: List<String>): String {
    val points=Regex("(?:^|\\s)(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?)").findAll(lines.joinToString(" ")).map { it.groupValues[1].toDoubleOrNull() to it.groupValues[2].toDoubleOrNull() }.mapNotNull { (x,y)->if(x!=null&&y!=null)x to y else null }.take(32).toList()
    if(points.isEmpty()) return renderStructuredDiagramFallback(lines.firstOrNull().orEmpty(),lines.drop(1))
    val poly=points.joinToString(" ") { "${55+it.first*4},${260-it.second*3}" }
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 760 300\" role=\"img\" aria-label=\"AI chart\"><polyline points=\"$poly\" class=\"line\" fill=\"none\"/>${points.map{ "<circle cx=\"${55+it.first*4}\" cy=\"${260-it.second*3}\" r=\"4\" class=\"point\"/>"}.joinToString("")}</svg></div>"
}

private fun renderStructuredDiagramFallback(kind: String, lines: List<String>): String {
    val items=lines.filter { it.isNotBlank() && !it.trim().startsWith("%%") }.take(80)
    val content=items.joinToString("\n") { it.trim() }
    return "<div class=\"rich-mermaid-fragment\"><h4>${escHtml(kind.take(64))} • structured preview</h4><div class=\"mermaid-node\"><pre>${escHtml(content)}</pre></div><div class=\"diagram-fallback-note\">This diagram type is preserved safely; the chat remains functional if the device renderer does not implement this Mermaid family yet.</div></div>"
}

private fun renderUnsupportedDiagram(kind: String, source: String): String =
    "<div class=\"rich-mermaid-fragment\"><h4>Mermaid • ${escHtml(kind.take(48))}</h4><div class=\"mermaid-node\"><pre>${escHtml(source.take(12000))}</pre></div><div class=\"diagram-fallback-note\">Diagram preview unavailable; source preserved safely.</div></div>"

private fun htmlCellText(fragment: String): String {
    // Keep this parser framework-independent: rovexMarkdownBody() is covered by JVM unit tests,
    // where android.text.Html.fromHtml() is not available. We only need table-cell text here,
    // so strip markup and decode the common entities emitted by model/providers.
    var text = fragment
        .replace(Regex("(?is)<script\\b[^>]*>.*?</script>"), " ")
        .replace(Regex("(?is)<style\\b[^>]*>.*?</style>"), " ")
        .replace(Regex("(?i)<br\\s*/?>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
    text = Regex("&#x([0-9a-fA-F]+);").replace(text) { m ->
        m.groupValues[1].toIntOrNull(16)?.let { String(Character.toChars(it)) } ?: m.value
    }
    text = Regex("&#([0-9]+);").replace(text) { m ->
        m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: m.value
    }
    return text.replace(Regex("\\s+"), " ").trim()
}

private fun renderHtmlTable(tableHtml: String, showTables: Boolean): String {
    val rows = Regex("(?is)<tr\\b[^>]*>(.*?)</tr>").findAll(tableHtml).map { row ->
        Regex("(?is)<t[dh]\\b[^>]*>(.*?)</t[dh]>").findAll(row.groupValues[1]).map {
            htmlCellText(it.groupValues[1])
        }.toList()
    }.filter { it.isNotEmpty() }.toList()
    if (rows.size < 2) return "<pre>${escHtml(tableHtml)}</pre>"
    val header = rows.first()
    val bodyRows = rows.drop(1)
    if (!showTables) {
        return buildString {
            append("<div class=\"table-as-sections\">")
            bodyRows.forEachIndexed { i, row ->
                append("<section><h4>").append(escHtml(row.firstOrNull().orEmpty().ifBlank { "Item ${i + 1}" })).append("</h4>")
                row.drop(1).forEachIndexed { j, cell ->
                    val label = header.getOrNull(j + 1).orEmpty()
                    if (label.isNotBlank()) append("<b>").append(escHtml(label)).append(":</b> ")
                    append(escHtml(cell)).append("<br>")
                }
                append("</section>")
            }
            append("</div>")
        }
    }
    return buildString {
        append("<div class=\"table-wrap\"><table><thead><tr>")
        header.forEach { append("<th>").append(escHtml(it)).append("</th>") }
        append("</tr></thead><tbody>")
        bodyRows.forEach { row ->
            append("<tr>")
            header.indices.forEach { i -> append("<td>").append(escHtml(row.getOrNull(i).orEmpty())).append("</td>") }
            append("</tr>")
        }
        append("</tbody></table></div>")
    }
}

private fun renderPieSvg(rows: List<Pair<String, Double>>): String {
    val total = rows.sumOf { it.second }.takeIf { it > 0.0 } ?: return ""
    val cx = 140.0; val cy = 140.0; val r = 105.0
    var angle = -Math.PI / 2
    val paths = rows.mapIndexed { i, (label, value) ->
        val sweep = value / total * Math.PI * 2
        val end = angle + sweep
        val x1 = cx + r * kotlin.math.cos(angle); val y1 = cy + r * kotlin.math.sin(angle)
        val x2 = cx + r * kotlin.math.cos(end); val y2 = cy + r * kotlin.math.sin(end)
        val large = if (sweep > Math.PI) 1 else 0
        val d = "M $cx $cy L $x1 $y1 A $r $r 0 $large 1 $x2 $y2 Z"
        angle = end
        "<path d=\"$d\" class=\"slice s$i\"/><text x=\"310\" y=\"${35+i*28}\" class=\"legend\">${escHtml(label)} (${("%.1f".format(value))})</text>"
    }.joinToString("")
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 560 300\" role=\"img\" aria-label=\"AI pie chart\"><circle cx=\"$cx\" cy=\"$cy\" r=\"$r\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1\" opacity=\".15\"/>$paths</svg></div>"
}

private fun renderChartBlock(source: String): String {
    return try {
        val o = org.json.JSONObject(source.trim())
        val type = o.optString("type", "bar").lowercase()
        val labels = o.optJSONArray("labels") ?: return "<pre>${escHtml(source)}</pre>"
        val values = o.optJSONArray("values") ?: return "<pre>${escHtml(source)}</pre>"
        val pairs = (0 until minOf(labels.length(), values.length(), 24)).mapNotNull { i ->
            val v = values.optDouble(i, Double.NaN); if (v.isFinite()) labels.optString(i) to v else null
        }
        when (type) {
            "pie", "doughnut" -> renderPieSvg(pairs)
            "bar", "line" -> renderBarLineSvg(type, pairs)
            else -> "<pre>${escHtml(source)}</pre>"
        }
    } catch (_: Exception) { "<pre>${escHtml(source)}</pre>" }
}

private fun renderBarLineSvg(type: String, pairs: List<Pair<String, Double>>): String {
    if (pairs.isEmpty()) return ""
    val max = pairs.maxOf { kotlin.math.abs(it.second) }.coerceAtLeast(1.0)
    val width = 720; val height = 340; val base = 270; val left = 55; val usable = 620.0
    val step = usable / pairs.size
    val marks = pairs.mapIndexed { i, (label, value) ->
        val x = left + step * i + step * .18; val h = kotlin.math.abs(value) / max * 210.0; val y = base - h
        if (type == "line") "<circle cx=\"${x+step*.32}\" cy=\"$y\" r=\"5\" class=\"point\"/><text x=\"${x+step*.32}\" y=\"${base+25}\" text-anchor=\"middle\" class=\"legend\">${escHtml(label.take(14))}</text>"
        else "<rect x=\"$x\" y=\"$y\" width=\"${step*.64}\" height=\"$h\" rx=\"7\" class=\"bar\"/><text x=\"${x+step*.32}\" y=\"${base+25}\" text-anchor=\"middle\" class=\"legend\">${escHtml(label.take(14))}</text>"
    }.joinToString("")
    val line = if (type == "line") {
        val pts = pairs.mapIndexed { i, (_, v) -> val x=left+step*i+step*.32; val y=base-kotlin.math.abs(v)/max*210.0; "$x,$y" }.joinToString(" ")
        "<polyline points=\"$pts\" class=\"line\" fill=\"none\"/>"
    } else ""
    return "<div class=\"rich-diagram\"><svg viewBox=\"0 0 $width $height\" role=\"img\" aria-label=\"AI $type chart\"><line x1=\"$left\" y1=\"$base\" x2=\"680\" y2=\"$base\" class=\"axis\"/>$line$marks</svg></div>"
}

private fun renderTreeBlock(source: String): String {
    val lines = source.lines().map { it.trimEnd() }.filter { it.trim().isNotBlank() }.take(80)
    if (lines.isEmpty()) return ""
    return "<div class=\"rich-tree\"><pre>${escHtml(lines.joinToString("\\n"))}</pre></div>"
}

private fun renderSlidesBlock(source: String): String {
    val slides = source.split(Regex("(?m)^\\s*---+\\s*$")).map { it.trim() }.filter { it.isNotBlank() }.take(20)
    return if (slides.size <= 1) "<div class=\"slide\">${rovexMarkdownBody(slides.firstOrNull().orEmpty(), true)}</div>"
    else "<div class=\"presentation\">" + slides.mapIndexed { i, slide -> "<article class=\"slide\"><div class=\"slide-number\">${i+1}</div>${rovexMarkdownBody(slide, true)}</article>" }.joinToString("") + "</div>"
}

private fun wrapMarkdownDocument(body: String): String = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>body{font-family:sans-serif;font-size:16px;line-height:1.52;margin:0;padding:2px;color:#EAF1F7}h1{font-size:25px;margin:8px 0}h2{font-size:21px;margin:16px 0 7px}h3{font-size:18px;margin:14px 0 6px}h4{font-size:16px;margin:12px 0 5px}p{margin:8px 0}blockquote{margin:10px 0;padding:9px 12px;border-left:4px solid #61B7FF;background:#182936;border-radius:8px}code,pre{background:#17232D;border-radius:8px;padding:2px 5px}pre{padding:10px;overflow:auto}.table-wrap{touch-action:pan-x pan-y;width:100%;max-width:100%;max-height:70vh;overflow:auto;margin:12px 0;padding-bottom:2px;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;scrollbar-gutter:stable} .table-as-sections{display:block;margin:12px 0}.table-as-sections section{margin:8px 0;padding:10px 11px;border-left:3px solid #61B7FF;background:#182936;border-radius:8px}.table-as-sections h4{margin:0 0 5px}table{border-collapse:collapse;margin:0;background:#13212B;width:max-content;min-width:680px;max-width:none;table-layout:auto}th,td{box-sizing:border-box;border:1px solid #334A5A;padding:8px 9px;text-align:left;vertical-align:top;min-width:0;max-width:none;overflow-wrap:anywhere;word-break:break-word}th{background:#1C3445;color:#B9F4EF;white-space:normal}mark{background:#6B5520;color:#FFF2B0;padding:1px 4px;border-radius:4px}.card{background:#13212B;border:1px solid #2C4352;border-radius:14px;padding:12px;margin:10px 0}.label{font-size:12px;color:#8FCBFF;text-transform:uppercase;letter-spacing:.08em;font-weight:700}.answer{font-size:19px;font-weight:700;color:#62D7A1}img{display:block;max-width:100%;height:auto;max-height:520px;object-fit:contain;border-radius:10px;margin:10px auto;background:#0D151B}a{color:#7FCBFF}table{overflow-wrap:anywhere}.table-as-sections section{margin:10px 0;padding:10px 12px;border-left:3px solid #61B7FF;background:#13212B;border-radius:9px}.table-as-sections h4{margin:0 0 6px;color:#B9F4EF}.table-as-sections b{color:#8FCBFF}.rich-diagram{width:100%;overflow:auto;max-height:70vh;margin:12px 0;padding:4px 0}.rich-diagram svg{display:block;width:100%;min-width:420px;height:auto;max-height:720px}.rich-diagram .node{fill:#1A2A35;stroke:#6FB6D8;stroke-width:1.5}.rich-diagram .label{fill:currentColor;font:14px sans-serif}.rich-diagram .edge{stroke:currentColor;stroke-width:2;opacity:.7}.rich-diagram .edge.dashed{stroke-dasharray:6 5}.rich-diagram .edge-label{fill:currentColor;font:12px sans-serif}.rich-diagram .lifeline{stroke:currentColor;stroke-width:1;stroke-dasharray:4 5;opacity:.35}.diagram-fallback-note{font-size:11px;opacity:.72;margin-top:7px;line-height:1.45}.rich-diagram .node{fill:#1A2A35;stroke:#6FB6D8;stroke-width:1.5}.rich-diagram .label,.rich-diagram .legend{fill:currentColor;font:14px sans-serif}.rich-diagram .edge,.rich-diagram .axis{stroke:currentColor;stroke-width:2;opacity:.65}.rich-diagram .bar{fill:#62B6E8}.rich-diagram .line{stroke:#62D7A1;stroke-width:4}.rich-diagram .point{fill:#62D7A1}.rich-diagram .slice{stroke:#0D151B;stroke-width:2}.rich-diagram .s0{fill:#62B6E8}.rich-diagram .s1{fill:#62D7A1}.rich-diagram .s2{fill:#D8A85C}.rich-diagram .s3{fill:#B68DEB}.rich-diagram .s4{fill:#E7839A}.rich-tree{margin:12px 0}.rich-tree pre{white-space:pre;overflow:auto}.rich-mermaid-fragment{margin:12px 0;padding:10px 12px;border:1px solid #334A5A;border-radius:10px;background:#13212B}.rich-mermaid-fragment h4{margin:0 0 7px}.mermaid-node{padding:8px 10px;margin:5px 0;border-radius:8px;border:1px solid #476276;background:#1A2A35}.presentation{display:flex;gap:12px;overflow-x:auto;padding:4px 0 12px;scroll-snap-type:x mandatory}.slide{box-sizing:border-box;min-width:92%;max-width:92%;padding:18px;border-radius:16px;border:1px solid #2C4352;background:#13212B;scroll-snap-align:start}.slide-number{font-size:11px;font-weight:800;opacity:.7;margin-bottom:6px}</style></head><body>$body</body></html>"""
