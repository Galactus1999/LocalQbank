#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
QDB="$ROOT/app/src/main/java/com/localqbank/library/QBankDb.kt"
FRANK="$ROOT/app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt"
LOAD="$ROOT/app/src/main/java/com/localqbank/library/QBankLoadingEngine.kt"
TESTLIST="$ROOT/app/src/main/java/com/localqbank/library/TestListActivity.kt"
MAIN="$ROOT/app/src/main/java/com/localqbank/library/MainActivity.kt"
fail(){ echo "FAIL: $1"; exit 1; }
# Generic search must not inherit the visual/image hard-filter.
generic="$(awk '/fun search\(query:String/{on=1} /fun searchImageQuestions/{on=0} on{print}' "$QDB")"
grep -q 'WHERE question_fts MATCH ? ORDER BY' <<<"$generic" || fail "generic FTS search missing"
! grep -q 'EXISTS(SELECT 1 FROM question_image' <<<"$generic" || fail "generic search still image-only"
grep -q 'EXISTS(SELECT 1 FROM question_image' "$QDB" || fail "image search hard-filter missing"
# Dashboard must use metadata, not a full question join.
dash="$(awk '/fun dashboardTestRows\(/{on=1} /^    }$/{if(on){print;exit}} on{print}' "$QDB")"
grep -q 'COALESCE(t.num_questions, 0)' <<<"$dash" || fail "dashboard still not metadata-first"
! grep -q 'LEFT JOIN question q' <<<"$dash" || fail "dashboard still scans question corpus"
# Import must not unconditionally rebuild the entire FTS corpus after a successful incremental import.
grep -q 'finalizeIncrementalSearchIndex()' "$QDB" || fail "incremental FTS finalizer missing"
! grep -q 'markSearchIndexCleanIfCountsMatch()' <(sed -n '/fun importBundle/,/private fun bindNullable/p' "$QDB") || fail "import still schedules unconditional full FTS rebuild"
# Frankenstein duplicate-request gate must reserve before launch.
grep -q 'if (!inFlight.add(key)) return' "$FRANK" || fail "Frankenstein atomic in-flight reservation missing"
! grep -q 'if (inFlight.containsKey(key)) return' "$FRANK" || fail "Frankenstein stale containsKey gate remains"
# Sub-QBank metadata must be staged before progress scanning.
grep -q 'fun loadSectionMetadata' "$LOAD" || fail "staged QBank metadata loader missing"
grep -q 'loadSectionMetadata(sourceId)' "$TESTLIST" || fail "sub-QBank screen still waits for bundled progress load"
# Restore/protect methods that v8.3.384 accidentally dropped.
grep -q 'fun allQuestionRefs' "$QDB" || fail "allQuestionRefs regression"
grep -q 'fun updateTestMetadata' "$QDB" || fail "updateTestMetadata regression"
# Production Home must not inflate the retired XML dashboard alongside the modern shell.
[ "$(grep -c 'setContentView(modernRoot)' "$MAIN")" -eq 1 ] || fail "MainActivity modern root contract changed"
! grep -q 'setContentView(R.layout.dashboard)' "$MAIN" || fail "legacy dashboard still inflated"
echo 'PASS: generic search returns text questions, not only image questions'
echo 'PASS: dashboard navigation is metadata-first'
echo 'PASS: imports avoid unconditional whole-corpus FTS rebuild when incremental index is consistent'
echo 'PASS: Frankenstein duplicate-request gate cannot leave a stale completed Job key'
echo 'PASS: sub-QBank navigation is staged metadata-first'
echo 'PASS: v8.3.384 accidental QBankDb API deletion is restored'
echo 'PASS: modern Home is the sole production dashboard UI'
