#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SEARCH="$ROOT/app/src/main/java/com/localqbank/library/SearchActivity.kt"
FRANK="$ROOT/app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt"
COG="$ROOT/app/src/main/java/com/localqbank/library/RenCognitiveEngine.kt"

grep -Fq 'private lateinit var db: QBankDb' "$SEARCH"
grep -Fq 'db=QBankDb(this)' "$SEARCH"
grep -Fq 'db.searchSections(variant)' "$SEARCH"
grep -Fq 'val primaryHits = db.search(text, 250)' "$SEARCH"
grep -Fq 'db.search(variant, 250)' "$SEARCH"
! grep -Fq 'LocalQBankSearchService(applicationContext)' "$SEARCH"

! grep -Fq 'localSearch.search(command, 100).hits' "$FRANK"
grep -Fq 'val useNeural = !actionCommand && !localSearchCommand' "$FRANK"

! grep -Fq 'LocalQBankSearchService(app)' "$COG"
grep -Fq 'val primaryHits = db.search(query, 80)' "$COG"
grep -Fq 'ClinicalQueryExpansion.expand(normalized)' "$COG"
grep -Fq 'db.search(variant, safeLimit)' "$COG"

echo 'PASS: Main Search uses the proven direct QBankDb retrieval path with bounded alias rescue'
echo 'PASS: Frankenstein no longer routes deterministic search through LocalQBankSearchService'
echo 'PASS: RenCognitiveEngine primary and fallback retrieval use QBankDb directly'
