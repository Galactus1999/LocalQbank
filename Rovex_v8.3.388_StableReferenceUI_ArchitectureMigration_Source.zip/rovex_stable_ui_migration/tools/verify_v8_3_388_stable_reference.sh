#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $*"; exit 1; }
pass(){ echo "PASS: $*"; }
BUILD="$ROOT/app/build.gradle.kts"
MAIN="$ROOT/app/src/main/java/com/localqbank/library/MainActivity.kt"
XML="$ROOT/app/src/main/res/layout/activity_main.xml"
MODERN="$ROOT/app/src/main/java/com/localqbank/library/RovexModernUi.kt"
SEARCH="$ROOT/app/src/main/java/com/localqbank/library/SearchActivity.kt"
LOCAL="$ROOT/app/src/main/java/com/localqbank/library/LocalQBankSearchService.kt"
FRANK="$ROOT/app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt"
VM="$ROOT/app/src/main/java/com/localqbank/library/MainViewModel.kt"

 grep -q 'versionCode = 480' "$BUILD" || fail "versionCode 480 missing"
 grep -q 'versionName = "8.3.388"' "$BUILD" || fail "versionName 8.3.388 missing"
pass "release version 8.3.388 / 480"

grep -q 'setContentView(R.layout.activity_main)' "$MAIN" || fail "stable XML Home structure not restored"
grep -q 'RovexModernUi.applyMain(this)' "$MAIN" || fail "v8.3.299 modern UI system not applied"
grep -q 'R.id.rovexBottomNav' "$MAIN" || fail "stable static bottom navigation not restored"
! grep -q 'RovexHomeRevolution.apply(this)' "$MAIN" || fail "dual Home UI path reintroduced"
! grep -q 'RovexBottomNavigation.install(this, RovexBottomNavigation.Destination.HOME' "$MAIN" || fail "dynamic Home navigation shell still active"
grep -q 'RovexHeaderCosmicView' "$XML" || fail "stable cosmic header missing"
grep -q 'R.id.homeSearchCard' "$MODERN" || fail "stable Home card styling contract missing"
pass "v8.3.299 stable Home UI structure restored as the single runtime Home"

grep -q 'private val localSearch by lazy' "$SEARCH" || fail "Search does not use shared local retrieval"
grep -q 'localSearch.searchSections' "$SEARCH" || fail "Search hierarchy retrieval missing"
grep -q 'localSearch.search(text, 300)' "$SEARCH" || fail "Search question retrieval missing"
grep -q 'localSearch.close()' "$SEARCH" || fail "Search service lifecycle cleanup missing"
grep -q 'if (primary.size >= minOf(8, safeLimit)' "$LOCAL" || fail "section-search primary-first bound missing"
grep -q 'override fun close()' "$LOCAL" || fail "shared search DB cleanup missing"
pass "Search keeps the tested deterministic lane with bounded hierarchy fan-out and DB cleanup"

grep -q 'Shared local search failed; using direct QBank fallback' "$FRANK" || fail "Frankenstein v8.3.299-style deterministic fallback missing"
grep -q 'localSearch.search(command, 100)' "$FRANK" || fail "Frankenstein shared local search lane missing"
grep -q 'localSearch.close()' "$FRANK" || fail "Frankenstein shared search cleanup missing"
pass "Frankenstein keeps the tested local-search fallback while preserving current grounded AI"

grep -q 'refreshRunning' "$VM" || fail "Home refresh coalescing missing"
grep -q 'refreshAgain' "$VM" || fail "Home refresh pending-pass coalescing missing"
pass "Home refresh requests are coalesced instead of stacking repeated dashboard loads"

bash "$ROOT/tools/verify_search_qbank_regressions.sh"
bash "$ROOT/tools/verify_performance_search_architecture.sh"
bash "$ROOT/tools/verify_v8_3_387_deep_architecture.sh" 2>/dev/null || true
pass "stable-reference release checks complete"
