#!/usr/bin/env python3
"""Find potentially cancellation-unsafe runCatching usage in coroutine-sensitive Kotlin code.

This is intentionally a conservative static audit: it reports files containing both
coroutine entry points and runCatching, then marks explicit CancellationException handling
as the safe pattern. It does not attempt to be a Kotlin parser.
"""
from pathlib import Path
import re

ROOT = Path("app/src/main/java")
files = sorted(ROOT.rglob("*.kt"))
issues = []
for p in files:
    s = p.read_text(encoding="utf-8", errors="ignore")
    if "runCatching" not in s:
        continue
    coroutine = bool(re.search(r"\bsuspend\s+fun\b|\b(?:launch|async|withContext|coroutineScope|supervisorScope)\s*(?:<[^>]+>)?\s*\{", s))
    if not coroutine:
        continue
    explicit_cancel = "CancellationException" in s and bool(re.search(r"catch\s*\([^)]*CancellationException", s))
    # A project helper that explicitly preserves cancellation is also accepted.
    helper_used = "resultOf {" in s
    if not explicit_cancel and not helper_used:
        issues.append(str(p))

print(f"Coroutine-sensitive files using runCatching: {sum(1 for p in files if 'runCatching' in p.read_text(encoding='utf-8', errors='ignore') and re.search(r'\\bsuspend\\s+fun\\b|\\b(?:launch|async|withContext|coroutineScope|supervisorScope)\\s*(?:<[^>]+>)?\\s*\\{', p.read_text(encoding='utf-8', errors='ignore')))}")
print(f"Files without an obvious CancellationException/resultOf boundary: {len(issues)}")
for item in issues:
    print(f"  {item}")
