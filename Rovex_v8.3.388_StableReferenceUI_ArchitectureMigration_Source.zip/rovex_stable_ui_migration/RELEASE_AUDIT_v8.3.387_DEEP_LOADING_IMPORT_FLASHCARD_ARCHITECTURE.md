# Rovex v8.3.387 — Deep Loading / Import / Flashcard Architecture Repair

## Scope

This release targets recurrent loading, cross-screen duplication, import pressure, progress resets, and QBank/flashcard reloading. It is based on v8.3.386 source.

## Root defects found

1. **Progress invalidation was too broad.** `AppState.changed()` invalidated `PerformanceManager`'s immutable QBank reference caches for ordinary progress mutations. An answer/bookmark/SRS mutation could therefore cause the next Home refresh to rebuild the entire lightweight QBank reference list.
2. **Home progress widgets required the full QBank reference index.** The modern Home used `PerformanceManager.lightRefs()` solely to calculate today's/week's progress. Those metrics are derivable from sparse progress records and do not require one object per imported question.
3. **Sub-QBank progress summaries scanned the question table.** `testProgressSummaries()` reconstructed totals/resume by iterating every question in a source. This made opening a subsection proportional to question count.
4. **QBank metadata/bundle requests could duplicate reads.** Source, section metadata, and section bundle loading had independent paths. The new waiter/coalescing layer makes concurrent callers share one physical SQLite read.
5. **Opening a QBank reset completion.** `QuizNavigationUseCase` called `clearCompletion()` during navigation. Merely visiting a section could therefore mutate durable study state.
6. **Flashcard dashboard used N+1 statistics queries.** `FlashcardViewModel.readState()` performed per-deck due-stat queries plus several global `modeCount()` queries. A large collection could cause repeated full card-table work.
7. **Hidden FlashcardActivity could refresh from unrelated state changes.** Its global AppState listener had no visibility gate.
8. **Large HTML imports entered whole-document parsing too late.** The previous 40 MB threshold allowed sizeable multi-section HTML exports to be held/parsed as one in-memory object graph.
9. **Streaming QBank import repeatedly updated every accumulated test at each batch.** `commitSection()` walked all tests accumulated so far rather than only tests changed since the previous commit.
10. **Cross-domain invalidation was still possible.** Flashcard-only mutations should not invalidate QBank progress/reference caches.

## Implemented architecture

```text
                        AppState / event reason
                                |
             +------------------+------------------+
             |                                     |
      QBank structural                         progress-only
       import/delete                              change
             |                                     |
   invalidate catalog + refs              invalidate progress only
             |                                     |
             v                                     v
     QBankLoadingEngine                    immutable QBank refs stay
             |
     +-------+--------+
     |                |
 source waiters   section metadata waiters
                      |
                 bundle waiters
                      |
                 sparse progress
                      |
                   UI state
```

Home no longer requires the question-reference index for its ordinary progress widgets.

Sub-QBank navigation now uses:

```text
test.num_questions
+ progress_v2 grouped by test_id
+ progress_meta resume cursor
```

rather than iterating the question corpus.

Flashcards now use a single aggregate library-statistics read plus deck metadata, rather than a global query plus one due-stat query per deck plus seven mode queries.

## Import strategy

HTML files >= 8 MiB now enter the bounded streaming path earlier. The importer still stages large files on disk rather than holding the whole document in RAM. The streaming session commits bounded transactions and now updates only dirty test rows at each section/batch boundary.

Flashcard/APKG import remains batch-transactional and resumable. The release does not introduce a second parser or duplicate collection representation.

## Progress semantics

Opening a QBank is now explicitly read-only with respect to completion state. The durable cursor remains authoritative. Answer handling continues to write the next-question resume target.

## Gemma / EmbeddingGemma architecture

The release deliberately keeps the neural models behind Ben's resource boundary:

```text
lexical QBank recall
        |
 bounded candidate set
        |
 EmbeddingGemma (only when permitted/warm)
        |
 deterministic verifier
        |
 Gemma 3 270M generation accelerator
```

No QBank screen or import path cold-starts a neural runtime. This is intentional: current Google guidance positions Gemma 3 270M for mobile/edge deployment, while LiteRT-LM is the current Google path for efficient on-device Gemma inference. EmbeddingGemma is explicitly designed for semantic retrieval and mobile RAG, with 768-dimensional output and MRL truncation options for cheaper retrieval storage/compute.

## Verification

### Existing static audits

```text
Rovex ruthless static audit
FIREBASE_OAUTH_CONFIG=PASS (Android + Web clients present)
XML_AND_LAYOUT_CHECK=PASS
MAIN_ACTIVITY_LAYOUT_ID_AUDIT=PASS
STATIC_AUDIT=PASS

Coroutine-sensitive files using runCatching: 0
Files without an obvious CancellationException/resultOf boundary: 0

PASS: single intent-routing owner + thin compatibility facade
PASS: orchestration/control contracts registered
PASS: no undocumented orchestrator/coordinator classes
```

### Search/performance regression verifier

```text
PASS: progress_v2 has indexed test ownership
PASS: dashboard progress aggregation is set-based, not per-test correlated
PASS: Home and QBank dashboard share cached catalog loading
PASS: QBank dashboard has immediate loading state
PASS: import/delete invalidates shared QBank catalog cache
PASS: generic search remains non-visual and visual search remains isolated
```

### Deep architecture verifier

```text
PASS: release version advanced to 8.3.387 / 479
PASS: QBank structural invalidation is separated from progress/flashcard invalidation
PASS: Home no longer scans full QBank refs for progress widgets
PASS: opening a QBank does not reset durable completion
PASS: sub-QBank progress uses test metadata + sparse progress aggregation
PASS: QBank source/metadata/bundle loads are request-coalesced
PASS: Flashcard catalog/stat reads are aggregated and lifecycle-gated
PASS: large/multi-section HTML import uses earlier streaming and dirty-test commits
PASS: deep architecture regression checks complete
```

### ZIP integrity

```text
No errors detected in compressed data
```

### Android build

Attempted:

```text
./gradlew test --offline
```

Result:

```text
Downloading Gradle 9.3.1...
curl: (6) Could not resolve host: downloads.gradle.org
EXIT:6
```

Therefore Android compilation, APK packaging, CI, and device runtime are **not claimed as verified** in this environment.

## Remaining deliberate architecture debt

The following large files remain and should be extracted by bounded responsibility rather than by arbitrary line-count splitting:

- `QBankDb.kt`
- `QuizActivity.kt`
- `BenEmbeddingGemmaEngine.kt`
- `BenInferenceProcessClient.kt`
- `BenInferenceProcessService.kt`

The next safe extraction target is QBank persistence into catalog/search/progress/import/question repositories while keeping the existing process-scoped database provider authoritative. A blind rewrite would increase regression risk.

## Research basis

- Android Paging/repository architecture: local database/cache as a source of truth and `PagingSource` as the repository-side pagination primitive.
- SQLite query planning: indexes, covering indexes, and set-based plans reduce repeated scans and temporary sorting work; `EXPLAIN QUERY PLAN` is the appropriate measurement tool.
- Android Macrobenchmark/Baseline Profiles: performance claims should be measured on a physical device using repeated cold/warm/hot journeys and TTID/TTFD/frame metrics.
- Google Gemma documentation: Gemma 3 270M is a mobile/edge-sized model; LiteRT-LM is the current on-device inference path.
- Hugging Face EmbeddingGemma documentation: embeddings are intended for semantic search/RAG; MRL can reduce retrieval storage/compute by truncating dimensions.
