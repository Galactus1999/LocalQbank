package com.localqbank.library

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView

/** Lightweight app-wide visual system. No bitmap assets, no WebView, no main-thread I/O. */
object RovexModernUi {
    private fun dp(v: Int, view: View): Int = (v * view.resources.displayMetrics.density).toInt()

    private fun surface(view: View, fill: Int, stroke: Int, radius: Int = 20): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            setStroke(dp(1, view), stroke)
            cornerRadius = dp(radius, view).toFloat()
        }

    fun applyMain(activity: MainActivity) {
        val root = activity.findViewById<View>(R.id.dashboardRoot) ?: return
        root.setBackgroundColor(ThemeManager.bg(activity))
        val elevated = ThemeManager.elevated(activity)
        val stroke = Color.argb(if (ThemeManager.isDark(activity)) 72 else 42,
            Color.red(ThemeManager.accent(activity)), Color.green(ThemeManager.accent(activity)), Color.blue(ThemeManager.accent(activity)))

        listOf(R.id.renCard, R.id.todaySolvedCard, R.id.studyMenuCard,
            R.id.flashcardCard, R.id.performanceLabCard, R.id.homeSearchCard).forEach { id ->
            activity.findViewById<View>(id)?.apply {
                background = surface(this, elevated, stroke, if (id == R.id.homeSearchCard) 18 else 22)
                elevation = dp(if (id == R.id.renCard) 5 else 2, this).toFloat()
            }
        }
        listOf(R.id.importantButton, R.id.reviseButton, R.id.doubtButton, R.id.favoriteButton, R.id.addButton,
            R.id.continueStudyButton).forEach { id ->
            activity.findViewById<Button>(id)?.let { styleButton(it) }
        }
        val nav = activity.findViewById<ViewGroup>(R.id.rovexBottomNav)
        nav?.apply {
            background = surface(this, ThemeManager.elevated(activity), stroke, 24)
            elevation = dp(10, this).toFloat()
        }
        listOf(R.id.navQBank, R.id.navCards, R.id.navMastery).forEach { id ->
            activity.findViewById<TextView>(id)?.apply {
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                letterSpacing = .03f
            }
        }
        tintText(root, activity)
    }

    fun applySection(root: View, activity: RovexSectionDashboardActivity) {
        root.setBackgroundColor(ThemeManager.bg(activity))
        tintText(root, activity)
        val nav = root.findViewById<ViewGroup>(R.id.rovexBottomNav)
        nav?.background = surface(nav, ThemeManager.elevated(activity), Color.argb(72, Color.red(ThemeManager.accent(activity)), Color.green(ThemeManager.accent(activity)), Color.blue(ThemeManager.accent(activity))), 24)
    }

    fun applyRen(root: View, activity: RenActivity) {
        root.setBackgroundColor(ThemeManager.bg(activity))
        val stroke = Color.argb(78, Color.red(ThemeManager.accent(activity)), Color.green(ThemeManager.accent(activity)), Color.blue(ThemeManager.accent(activity)))
        tintText(root, activity)
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                val child = root.getChildAt(i)
                if (child is android.webkit.WebView) {
                    child.setBackgroundColor(Color.TRANSPARENT)
                } else if (child is android.widget.EditText) {
                    child.background = surface(child, ThemeManager.elevated(activity), stroke, 18)
                    child.setTextColor(ThemeManager.text(activity))
                    child.setHintTextColor(ThemeManager.muted(activity))
                } else if (child is TextView) {
                    child.setTextColor(if (child.text.toString().contains("OPEN MATCH", true)) ThemeManager.bg(activity) else ThemeManager.text(activity))
                }
            }
        }
    }

    private fun tintText(view: View, activity: android.app.Activity) {
        if (view is TextView) {
            val id = view.resources.getResourceEntryName(view.id).lowercase()
            val color = when {
                id.contains("ai") || id.contains("ben") -> ThemeManager.aiText(activity)
                id.contains("hint") || id.contains("sub") || id.contains("stats") -> ThemeManager.muted(activity)
                else -> ThemeManager.text(activity)
            }
            view.setTextColor(color)
        }
        if (view is ViewGroup) for (i in 0 until view.childCount) tintText(view.getChildAt(i), activity)
    }

    private fun styleButton(button: Button) {
        val c = button.context
        button.background = surface(button, ThemeManager.peacockFill(c), Color.argb(80, Color.red(ThemeManager.accent(c)), Color.green(ThemeManager.accent(c)), Color.blue(ThemeManager.accent(c))), 16)
        button.setTextColor(ThemeManager.peacockText(c))
        button.stateListAnimator = null
        button.minHeight = dp(42, button)
        button.setPadding(dp(12, button), dp(7, button), dp(12, button), dp(7, button))
        button.isAllCaps = false
        button.letterSpacing = .01f
    }
}
