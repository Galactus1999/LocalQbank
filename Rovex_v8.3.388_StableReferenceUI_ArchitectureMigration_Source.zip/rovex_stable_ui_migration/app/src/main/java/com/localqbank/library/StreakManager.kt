package com.localqbank.library

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.TimeUnit

/**
 * Durable study-streak owner. It listens to the existing event spine rather than creating a
 * second event pipeline. Streak state lives in qbank.db so backup/restore carries it with study
 * progress. This manager owns streak policy only; it does not schedule study/business work.
 */
class StreakManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("streak_settings", Context.MODE_PRIVATE)
    private val listener: (StudyEventSpine.Event) -> Unit = { event ->
        when (event.name) {
            "quiz_completed", "flashcard_reviewed" -> PerformanceManager.submit {
                recordStudyDay(event.timestamp)
            }
        }
    }

    init {
        StudyEventSpine.subscribe(listener)
        // Reminder scheduling is maintenance work, not startup-critical UI work.
        PerformanceManager.submitMaintenance { scheduleReminder() }
    }

    fun recordStudyDay(timestamp: Long = System.currentTimeMillis()): Snapshot =
        resultOf {
            val db = QBankDb(app)
            try {
                // Keep milestone detection paired with the same serialized mutation boundary as
                // the database update. Direct QBankDb callers are protected by the provider lock.
                synchronized(streakMutationLock) {
                    val before = db.readStudyStreak()
                    val snapshot = db.recordStudyStreakDay(timestamp)
                    val day = snapshot.currentStreak
                    if (day > before.currentStreak && day in MILESTONE_DAYS) {
                        StudyEventSpine.publishAsync(
                            StudyEventSpine.Event(
                                "streak_milestone",
                                source = "streak",
                                metadata = mapOf("days" to day.toString())
                            )
                        )
                    }
                    snapshot
                }
            } finally {
                db.close()
            }
        }.getOrElse { Snapshot() }

    fun snapshot(): Snapshot = QBankDb(app).let { db ->
        try { db.readStudyStreak() } finally { db.close() }
    }

    fun notificationsEnabled(): Boolean = prefs.getBoolean("enabled", true)

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("enabled", enabled).apply()
        if (enabled) scheduleReminder() else WorkManager.getInstance(app).cancelUniqueWork(STREAK_WORK_NAME)
    }

    fun shouldPromptNotificationPermission(): Boolean = notificationsEnabled() && QBankDb(app).let { db ->
        try { !db.notificationPermissionPrompted() } finally { db.close() }
    }

    fun markNotificationPermissionPrompted() {
        QBankDb(app).let { db -> try { db.markNotificationPermissionPrompted() } finally { db.close() } }
    }

    private fun scheduleReminder() {
        if (!notificationsEnabled()) return
        val request = PeriodicWorkRequestBuilder<StreakReminderWorker>(24, TimeUnit.HOURS, 6, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(app).enqueueUniquePeriodicWork(
            STREAK_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    data class Snapshot(
        val currentStreak: Int = 0,
        val longestStreak: Int = 0,
        val totalStudyDays: Int = 0,
        val lastStudyDay: String? = null
    )

    private companion object {
        val streakMutationLock = Any()
        val MILESTONE_DAYS = setOf(3, 7, 14, 30, 60, 100)
    }
}

private const val STREAK_WORK_NAME = "rovex_daily_streak_reminder"
private const val STREAK_CHANNEL_ID = "rovex_study_reminders"
private const val STREAK_NOTIFICATION_ID = 8401

fun maybeRequestStudyNotificationPermission(activity: android.app.Activity) {
    if (!AppManagers.isReady() || !AppManagers.streak.notificationsEnabled()) return
    if (android.os.Build.VERSION.SDK_INT < 33) return
    if (activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
    // shouldPromptNotificationPermission()/markNotificationPermissionPrompted() read and write
    // qbank.db. Never perform that persistence work from a settings/quiz click callback.
    PerformanceManager.submit {
        if (!AppManagers.streak.shouldPromptNotificationPermission()) return@submit
        AppManagers.streak.markNotificationPermissionPrompted()
        activity.runOnUiThread {
            if (!activity.isFinishing && !activity.isDestroyed &&
                activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8402)
            }
        }
    }
}

internal fun postStreakNotification(context: Context, snapshot: StreakManager.Snapshot): Boolean {
    if (snapshot.currentStreak <= 0) return false
    if (!AppManagers.streak.notificationsEnabled()) return false
    if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false
    if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false
    val manager = context.getSystemService(NotificationManager::class.java)
    if (manager.getNotificationChannel(STREAK_CHANNEL_ID) == null) manager.createNotificationChannel(NotificationChannel(STREAK_CHANNEL_ID, "Study reminders", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "Daily Rovex study and streak reminders" })
    val content = if (snapshot.currentStreak == 1) "Start today's session to build your streak." else "Your ${snapshot.currentStreak}-day streak is waiting for today's study."
    val notification = NotificationCompat.Builder(context, STREAK_CHANNEL_ID).setSmallIcon(R.drawable.ic_study).setContentTitle("Keep your Rovex streak alive").setContentText(content).setStyle(NotificationCompat.BigTextStyle().bigText(content)).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
    NotificationManagerCompat.from(context).notify(STREAK_NOTIFICATION_ID, notification)
    return true
}

class StreakPolicy {
    fun apply(current: StreakManager.Snapshot, today: LocalDate): StreakManager.Snapshot {
        val last = current.lastStudyDay?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val next = when {
            last == today -> current.currentStreak.coerceAtLeast(1)
            last == today.minusDays(1) -> current.currentStreak.coerceAtLeast(1) + 1
            else -> 1
        }
        val total = if (last == today) current.totalStudyDays else current.totalStudyDays + 1
        val longest = maxOf(current.longestStreak, next)
        return StreakManager.Snapshot(next, longest, total, today.toString())
    }
}

class StreakReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result = runCatching {
        val app = applicationContext
        val db = QBankDb(app)
        val snapshot = try { db.readStudyStreak() } finally { db.close() }
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        if (snapshot.lastStudyDay == today.toString()) return Result.success()
        val effectiveStreak = snapshot.lastStudyDay?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?.takeIf { it == today.minusDays(1) }
            ?.let { snapshot.currentStreak } ?: 0
        if (effectiveStreak <= 0) return Result.success()
        val reminderSnapshot = snapshot.copy(currentStreak = effectiveStreak)
        val reminderDb = QBankDb(app)
        try {
            if (reminderDb.studyReminderAlreadySent(today.toString())) return Result.success()
            if (postStreakNotification(app, reminderSnapshot)) reminderDb.markStudyReminderSent(today.toString())
        } finally {
            reminderDb.close()
        }
        Result.success()
    }.getOrElse { Result.retry() }
}
