package com.localqbank.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import android.os.Handler
import android.os.Looper

/**
 * Home screen state holder. It coordinates existing authoritative managers but does not replace
 * DashboardManager, QBankLoadingEngine, or any other application-level owner.
 */
class MainViewModel(private val repository: MainRepository) : ViewModel() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val refreshLock = Any()
    private var refreshRunning = false
    private var refreshAgain = false
    @Volatile private var lastPreparedAt = 0L
    private val study = MainStudyUseCase(repository)
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    fun refresh() {
        if (!AppManagers.isReady()) return
        synchronized(refreshLock) {
            if (refreshRunning) {
                // Home can receive several lifecycle/state notifications during one frame. Do not
                // queue another complete dashboard/SQLite build for every notification; remember
                // only that one fresh pass is needed after the current pass completes.
                refreshAgain = true
                return
            }
            refreshRunning = true
            refreshAgain = false
        }
        _uiState.update { it.copy(loading = true, error = null) }
        val generation = PerformanceManager.currentGeneration()
        val experienceGeneration = AppManagers.experience.newGeneration()
        AppManagers.experience.submitHome {
            try {
                val modelResult = runCatching { AppManagers.dashboard.build() }
                val model = modelResult.getOrElse { error ->
                    _uiState.update { it.copy(loading = false, error = error.message ?: "Dashboard refresh failed") }
                    return@submitHome
                }
                if (generation != PerformanceManager.currentGeneration() || experienceGeneration != AppManagers.experience.currentGeneration()) return@submitHome
                val resumes = runCatching { repository.resumeTargets(model.sources) }.getOrDefault(emptyMap())
                _uiState.update {
                    it.copy(
                        dashboard = model,
                        sources = model.sources,
                        sourceProgress = model.sourceProgress,
                        resumeBySource = resumes,
                        loading = false,
                        error = null
                    )
                }
            } finally {
                val rerun = synchronized(refreshLock) {
                    refreshRunning = false
                    val again = refreshAgain
                    refreshAgain = false
                    again
                }
                if (rerun && AppManagers.isReady()) mainHandler.post { refresh() }
            }
        }
    }

    fun prepareForDisplay() {
        if (!AppManagers.isReady()) return
        val now = System.currentTimeMillis()
        if (now - lastPreparedAt < 1_500L) return
        lastPreparedAt = now
        AppManagers.dashboard.prepareForDisplay()
    }

    fun flushBackup() {
        repository.flushBackup()
    }

    fun refreshSourcesFast() {
        if (!AppManagers.isReady()) return
        AppManagers.qbankLoading.loadSources { sources ->
            // QBankLoadingEngine may deliver on the main thread. Resume-target lookup is SQLite
            // work, so never perform it in that callback.
            PerformanceManager.submit {
                val resumes = runCatching { repository.resumeTargets(sources) }.getOrDefault(emptyMap())
                mainHandler.post {
                    if (!AppManagers.isReady()) return@post
                    _uiState.update { it.copy(sources = sources, resumeBySource = resumes) }
                }
            }
        }
    }

    /**
     * QBank deletion is a potentially large SQLite write. Never execute it from a Home click
     * callback: keep the UI responsive and surface the actual result to the caller.
     */
    fun deleteSource(sourceId: Long, onResult: (Boolean) -> Unit = {}) {
        PerformanceManager.submitQBankDeletion {
            val ok = runCatching { repository.deleteSource(sourceId) }.getOrDefault(false)
            mainHandler.post {
                if (ok) {
                    AppManagers.qbankLoading.invalidate(sourceId)
                    PerformanceManager.invalidate()
                    refreshSourcesFast()
                    refresh()
                }
                onResult(ok)
            }
        }
    }

    fun updateSourceMetadata(sourceId: Long, name: String, series: String, onResult: (Boolean) -> Unit = {}) {
        PerformanceManager.submit {
            val ok = runCatching { repository.updateSourceMetadata(sourceId, name, series) }.getOrDefault(false)
            mainHandler.post {
                if (ok) {
                    AppManagers.qbankLoading.invalidate(sourceId)
                    refreshSourcesFast()
                    refresh()
                }
                onResult(ok)
            }
        }
    }


    fun currentQBankRefs(refs: List<QuestionRef>): List<QuestionRef> = study.currentQBankRefs(refs)
    fun wrongIds(refs: List<QuestionRef>): LongArray = study.wrongIds(refs)
    fun todaySolvedIds(refs: List<QuestionRef>): LongArray = study.todaySolvedIds(refs)
    fun todayRevisionIds(refs: List<QuestionRef>): LongArray = study.todayRevisionIds(refs)
    fun todayRevisionCount(refs: List<QuestionRef>): Int = study.todayRevisionCount(refs)

    override fun onCleared() {
        repository.close()
        super.onCleared()
    }
}

class MainViewModelFactory(private val repository: MainRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) return MainViewModel(repository) as T
        throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
