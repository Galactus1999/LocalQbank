package com.localqbank.library

import android.content.Context
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import android.os.Process

/**
 * Dedicated QBank loading layer. It keeps navigation metadata off the UI thread,
 * coalesces repeated section loads, and retains a small TTL cache so reopening a
 * heavy QBank feels immediate without retaining question HTML in memory.
 */
class QBankLoadingEngine(context: Context) {
    private val app = context.applicationContext
    private val executor = ThreadPoolExecutor(
        1, 2, 15L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>()
    ).apply {
        threadFactory = java.util.concurrent.ThreadFactory { r ->
            Thread(r, "qbank-loader").apply { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
        }
    }
    /** Fast Home-library source path. This must remain independent from question indexing so a
     * committed import becomes visible even if a heavier dashboard calculation is delayed. */
    private val sourceWaiters = java.util.concurrent.CopyOnWriteArrayList<(List<Source>) -> Unit>()
    @Volatile private var sourceLoadInFlight = false

    fun loadSources(onLoaded: (List<Source>) -> Unit) {
        val now = System.currentTimeMillis()
        val cached = sourceCache.values.mapNotNull { it.first }.sortedByDescending { it.id }
        if (cached.isNotEmpty()) {
            executor.execute { onLoaded(cached) }
            return
        }
        sourceWaiters.add(onLoaded)
        synchronized(sourceWaiters) {
            if (sourceLoadInFlight) return
            sourceLoadInFlight = true
        }
        executor.execute {
            Process.setThreadPriority(
                if (AppManagers.isReady() && AppManagers.runtime.framePressure() >= 2)
                    Process.THREAD_PRIORITY_BACKGROUND + 1
                else Process.THREAD_PRIORITY_BACKGROUND
            )
            val sources = runCatching {
                QBankDb(app).let { db -> try { db.sources() } finally { db.close() } }
            }.getOrDefault(emptyList())
            val at = System.currentTimeMillis()
            sourceCache.clear(); sources.forEach { sourceCache[it.id] = it to at }
            val callbacks=synchronized(sourceWaiters){ val copy=sourceWaiters.toList(); sourceWaiters.clear(); sourceLoadInFlight=false; copy }
            callbacks.forEach { callback -> runCatching { callback(sources) } }
        }
    }

    /** Shared lightweight dashboard catalog. Home and the QBank tab must not independently scan the database. */
    fun loadDashboardRows(onLoaded: (List<DashboardTestRow>) -> Unit) {
        val now = System.currentTimeMillis()
        dashboardCache?.let { cached ->
            if (now - cached.at < ttlMs) { executor.execute { onLoaded(cached.rows) }; return }
        }
        val key = Long.MIN_VALUE
        if (inFlight.putIfAbsent(key, true) != null) return
        adaptRuntimeBudget()
        executor.execute {
            try {
                val rows = runCatching { QBankDb(app).let { db -> try { db.dashboardTestRows() } finally { db.close() } } }.getOrDefault(emptyList())
                dashboardCache = DashboardCache(rows, System.currentTimeMillis())
                onLoaded(rows)
            } finally { inFlight.remove(key) }
        }
    }

    private fun adaptRuntimeBudget() {
        val workers = if (AppManagers.isReady()) AppManagers.runtime.recommendedBackgroundWorkers() else 1
        // Lowering the core size never interrupts active SQLite work; the extra worker simply
        // becomes eligible for retirement once it finishes. This is the runtime equivalent of
        // a game engine reducing its worker-job budget under frame pressure.
        executor.corePoolSize = workers.coerceIn(1, 2)
    }
    data class SectionMetadata(val tests: List<Test>, val source: Source?)
    data class SectionBundle(val tests: List<Test>, val summaries: Map<String, ProgressSummary>, val source: Source?)
    private data class TestCache(val tests: List<Test>, val at: Long)
    private data class BundleCache(val bundle: SectionBundle, val at: Long)
    private val testCache = ConcurrentHashMap<Long, TestCache>()
    private val bundleCache = ConcurrentHashMap<Long, BundleCache>()
    private val sourceCache = ConcurrentHashMap<Long, Pair<Source?, Long>>()
    private data class DashboardCache(val rows: List<DashboardTestRow>, val at: Long)
    private var dashboardCache: DashboardCache? = null
    private val inFlight = ConcurrentHashMap<Long, Boolean>()
    private val metadataWaiters = ConcurrentHashMap<Long, java.util.concurrent.CopyOnWriteArrayList<(SectionMetadata) -> Unit>>()
    private val bundleWaiters = ConcurrentHashMap<Long, java.util.concurrent.CopyOnWriteArrayList<(SectionBundle) -> Unit>>()
    // Cache epoch prevents a slow read that started before an import/delete from
    // repopulating the cache with stale metadata after invalidation.
    private val cacheEpoch = AtomicLong(0L)
    private val ttlMs = 30_000L

    fun loadSections(sourceId: Long, onLoaded: (List<Test>) -> Unit) {
        // Keep one in-flight path per source so a warm-up and the section screen never
        // open duplicate SQLite readers for the same heavy QBank.
        loadSectionMetadata(sourceId) { onLoaded(it.tests) }
    }

    /**
     * Fast navigation path: read only test/source metadata. Progress is deliberately staged
     * because computing per-question progress for a huge QBank can otherwise make a simple
     * subsection tap look like an application hang.
     */
    fun loadSectionMetadata(sourceId: Long, onLoaded: (SectionMetadata) -> Unit) {
        if (sourceId <= 0L) { onLoaded(SectionMetadata(emptyList(), null)); return }
        val now = System.currentTimeMillis()
        testCache[sourceId]?.let { cached ->
            if (now - cached.at < ttlMs) {
                val cachedSource = sourceCache[sourceId]?.first
                executor.execute { onLoaded(SectionMetadata(cached.tests, cachedSource)) }
                return
            }
        }
        val waiters = metadataWaiters.computeIfAbsent(sourceId) { java.util.concurrent.CopyOnWriteArrayList() }
        waiters.add(onLoaded)
        // The first caller owns the physical SQLite read; later callers attach to the same
        // result. This removes the metadata-vs-bundle race that previously allowed two readers
        // to load the same test list simultaneously.
        if (waiters.size > 1) return
        val epoch = cacheEpoch.get()
        adaptRuntimeBudget()
        try {
            executor.execute {
                try {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
                    val metadata = runCatching {
                        val db = QBankDb(app)
                        try {
                            val tests = db.tests(sourceId)
                            val source = db.sourceById(sourceId)
                            val at = System.currentTimeMillis()
                            if (cacheEpoch.get() == epoch) {
                                testCache[sourceId] = TestCache(tests, at)
                                sourceCache[sourceId] = source to at
                            }
                            SectionMetadata(tests, source)
                        } finally { db.close() }
                    }.getOrDefault(SectionMetadata(emptyList(), null))
                    if (cacheEpoch.get() == epoch) {
                        waiters.forEach { callback -> runCatching { callback(metadata) } }
                    } else {
                        metadataWaiters.remove(sourceId)
                        waiters.forEach { callback -> loadSectionMetadata(sourceId, callback) }
                        return@execute
                    }
                } finally {
                    metadataWaiters.remove(sourceId)
                }
            }
        } catch (t: Throwable) {
            metadataWaiters.remove(sourceId)
            throw t
        }
    }

    fun loadSectionBundle(sourceId: Long, onLoaded: (SectionBundle) -> Unit) {
        if (sourceId <= 0L) { onLoaded(SectionBundle(emptyList(), emptyMap(), null)); return }
        val now = System.currentTimeMillis()
        bundleCache[sourceId]?.let { cached ->
            if (now - cached.at < ttlMs) {
                executor.execute { onLoaded(cached.bundle) }
                return
            }
        }
        val waiters = bundleWaiters.computeIfAbsent(sourceId) { java.util.concurrent.CopyOnWriteArrayList() }
        waiters.add(onLoaded)
        if (waiters.size > 1) return
        val epoch = cacheEpoch.get()
        // Reuse the exact same metadata read used by TestListActivity/warmSource. Only the
        // progress aggregation remains after metadata is available.
        loadSectionMetadata(sourceId) { metadata ->
            adaptRuntimeBudget()
            executor.execute {
                try {
                    Process.setThreadPriority(
                        if (AppManagers.isReady() && AppManagers.runtime.framePressure() >= 2) Process.THREAD_PRIORITY_BACKGROUND + 1
                        else Process.THREAD_PRIORITY_BACKGROUND
                    )
                    val db = QBankDb(app)
                    try {
                        val progress = PerformanceManager.progress(app)
                        val summaries = db.testProgressSummaries(sourceId, progress)
                        val bundle = SectionBundle(metadata.tests, summaries, metadata.source)
                        if (cacheEpoch.get() == epoch) {
                            val at = System.currentTimeMillis()
                            bundleCache[sourceId] = BundleCache(bundle, at)
                        }
                        if (cacheEpoch.get() == epoch) {
                            waiters.forEach { callback -> runCatching { callback(bundle) } }
                        } else {
                            bundleWaiters.remove(sourceId)
                            waiters.forEach { callback -> loadSectionBundle(sourceId, callback) }
                            return@execute
                        }
                    } finally { db.close() }
                } finally {
                    bundleWaiters.remove(sourceId)
                }
            }
        }
    }

    fun warmSource(sourceId: Long) {
        if (sourceId <= 0L) return
        loadSections(sourceId) { }
    }

    fun invalidate(sourceId: Long? = null) {
        cacheEpoch.incrementAndGet()
        if (sourceId == null) { testCache.clear(); bundleCache.clear(); sourceCache.clear(); dashboardCache = null }
        else { testCache.remove(sourceId); bundleCache.remove(sourceId); sourceCache.remove(sourceId); dashboardCache = null }
    }

    fun shutdown() { executor.shutdownNow() }
}
