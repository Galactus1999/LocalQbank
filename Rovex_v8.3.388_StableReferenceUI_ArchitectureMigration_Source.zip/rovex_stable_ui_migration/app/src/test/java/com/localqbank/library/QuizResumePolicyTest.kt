package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class QuizResumePolicyTest {
    @Test fun answeredQuestion37ResumesAt38() =
        assertEquals(37, QuizResumePolicy.afterAnswer(36, 100))

    @Test fun answerAtLastQuestionStaysAtLast() =
        assertEquals(99, QuizResumePolicy.afterAnswer(98, 100))

    @Test fun navigationResumesExactlyAtViewedQuestion() =
        assertEquals(36, QuizResumePolicy.afterExplicitNavigation(36, 100))

    @Test fun emptySessionIsSafe() =
        assertEquals(0, QuizResumePolicy.afterAnswer(0, 0))
}
