package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpacedRepetitionSchedulerTest {
    @Test fun first_correct_answer_is_due_tomorrow() {
        val now = 1_000_000L
        val r = SpacedRepetitionScheduler.schedule(
            SpacedRepetitionScheduler.ScheduleInput(correct = true), now
        )
        assertEquals(1, r.repetitions)
        assertEquals(1f, r.intervalDays, 0f)
        assertEquals(now + SpacedRepetitionScheduler.DAY_MS, r.nextDueAt)
        assertEquals(2.6f, r.easeFactor, 0.0001f)
    }

    @Test fun second_correct_answer_uses_six_day_interval() {
        val r = SpacedRepetitionScheduler.schedule(
            SpacedRepetitionScheduler.ScheduleInput(correct = true, easeFactor = 2.6f, repetitions = 1, previousIntervalDays = 1f),
            2_000L
        )
        assertEquals(2, r.repetitions)
        assertEquals(6f, r.intervalDays, 0f)
        assertEquals(2_000L + 6L * SpacedRepetitionScheduler.DAY_MS, r.nextDueAt)
    }

    @Test fun miss_resets_repetitions_and_returns_tomorrow() {
        val r = SpacedRepetitionScheduler.schedule(
            SpacedRepetitionScheduler.ScheduleInput(correct = false, easeFactor = 1.3f, repetitions = 9, previousIntervalDays = 120f),
            3_000L
        )
        assertEquals(0, r.repetitions)
        assertEquals(1f, r.intervalDays, 0f)
        assertEquals(3_000L + SpacedRepetitionScheduler.DAY_MS, r.nextDueAt)
        assertEquals(1.3f, r.easeFactor, 0.0001f)
    }

    @Test fun long_term_interval_uses_previous_interval_and_ease() {
        val r = SpacedRepetitionScheduler.schedule(
            SpacedRepetitionScheduler.ScheduleInput(correct = true, easeFactor = 2f, repetitions = 2, previousIntervalDays = 6f),
            0L
        )
        assertEquals(3, r.repetitions)
        assertEquals(12f, r.intervalDays, 0f)
        assertTrue(r.nextDueAt > 0L)
    }
}
