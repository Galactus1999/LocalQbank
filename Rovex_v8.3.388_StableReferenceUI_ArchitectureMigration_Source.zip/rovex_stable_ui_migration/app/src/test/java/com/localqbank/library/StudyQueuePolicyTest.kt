package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class StudyQueuePolicyTest {
    private fun ref(id: Long, testId: String, sourceId: Long, sourceName: String) =
        QuestionRef(id, "k$id", testId, id.toInt(), "Q$id", testId, sourceId, sourceName, "subject")

    @Test
    fun currentQBankRefsUsesActiveSessionSourceWithoutViewModel() {
        val refs = listOf(
            ref(1, "test-a", 10, "A"),
            ref(2, "test-a", 10, "A"),
            ref(3, "test-b", 20, "B")
        )
        val session = StudySession("s", "test-b", 0, "k3", 1L)

        assertEquals(listOf(3L), StudyQueuePolicy.currentQBankRefs(refs, session).map { it.id })
    }

    @Test
    fun currentQBankRefsFallsBackToFirstSourceWhenNoActiveSessionMatches() {
        val refs = listOf(
            ref(1, "test-a", 10, "A"),
            ref(2, "test-a", 10, "A"),
            ref(3, "test-b", 20, "B")
        )

        assertEquals(listOf(1L, 2L), StudyQueuePolicy.currentQBankRefs(refs, null).map { it.id })
    }
}
