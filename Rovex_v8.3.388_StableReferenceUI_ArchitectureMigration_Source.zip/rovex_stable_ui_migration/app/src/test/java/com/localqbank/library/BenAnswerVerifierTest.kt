package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BenAnswerVerifierTest {
    private fun plan(visual: Boolean = false) = BenCognitiveArchitecture.Plan(
        query = "hypertension",
        intent = "diagnosis",
        concepts = listOf("hypertension"),
        domains = setOf("cardiology"),
        tools = emptyList(),
        confidence = 70,
        visualIntent = visual
    )

    @Test fun blank_answer_is_rejected() {
        val r = BenAnswerVerifier().verify("hypertension", "", plan())
        assertFalse(r.acceptable)
        assertTrue(r.score == 0)
    }

    @Test fun ordinary_answer_can_pass_without_grounded_evidence() {
        val r = BenAnswerVerifier().verify("hypertension", "Hypertension is elevated blood pressure.", plan())
        assertTrue(r.acceptable)
    }

    @Test fun invalid_citation_is_rejected() {
        val evidence = listOf(BenAnswerVerifier.EvidenceItem(1, 101L, "Hypertension is elevated blood pressure."))
        val r = BenAnswerVerifier().verify("hypertension", "Hypertension is elevated blood pressure [2].", plan(), evidence)
        assertFalse(r.acceptable)
        assertFalse(r.citationValid)
    }

    @Test fun grounded_critical_number_with_valid_citation_is_accepted() {
        val evidence = listOf(BenAnswerVerifier.EvidenceItem(1, 101L, "Screening is recommended at age 40 years."))
        val answer = "Screening is recommended at age 40 years [1]."
        val r = BenAnswerVerifier().verify("hypertension", answer, plan(), evidence)
        assertTrue(r.citationValid)
        assertTrue(r.criticalClaims.all { it.status == BenAnswerVerifier.ClaimStatus.SUPPORTED })
        assertTrue(r.acceptable)
    }

    @Test fun unsupported_visual_finding_is_rejected() {
        val evidence = listOf(BenAnswerVerifier.EvidenceItem(1, 101L, "The image is provided."))
        val answer = "The image shows pulmonary edema [1]."
        val r = BenAnswerVerifier().verify("chest x-ray", answer, plan(visual = true), evidence)
        assertFalse(r.acceptable)
    }
}
