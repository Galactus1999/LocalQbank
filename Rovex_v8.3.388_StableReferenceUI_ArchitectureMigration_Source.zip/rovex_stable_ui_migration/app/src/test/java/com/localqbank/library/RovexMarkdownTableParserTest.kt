package com.localqbank.library

import org.junit.Assert.*
import org.junit.Test

class RovexMarkdownTableParserTest {
    @Test fun numberedListIsNotATable() {
        val lines = listOf("1. Step one | important", "2. Step two | more detail")
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }

    @Test fun pseudoColumnsAreNotATableWithoutDelimiterRow() {
        val lines = listOf("Step | 1 | 2 | 3 | 4", "Integrated reasoning | Notes | Persistence")
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }

    @Test fun proseWithPipesIsNotATable() {
        val lines = listOf("HPV | smoking | persistence", "Risk rises | but this is prose")
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }

    @Test fun genuineTableIsRecognized() {
        val lines = listOf(
            "| Feature | Finding |",
            "| --- | --- |",
            "| HPV | Persistent infection |",
            "| Smoking | Synergistic risk |",
            "",
            "Next paragraph"
        )
        val table = RovexMarkdownTableParser.parse(lines, 0)
        assertNotNull(table)
        assertEquals(listOf("Feature", "Finding"), table!!.header)
        assertEquals(2, table.rows.size)
        assertEquals(4, table.nextIndex)
    }

    @Test fun mixedProseAndTableStopsAtProse() {
        val lines = listOf(
            "Intro paragraph",
            "| A | B |",
            "| --- | --- |",
            "| 1 | 2 |",
            "| 3 | 4 |",
            "After table"
        )
        val table = RovexMarkdownTableParser.parse(lines, 1)
        assertNotNull(table)
        assertEquals(5, table!!.nextIndex)
        assertEquals("After table", lines[table.nextIndex])
    }

    @Test fun chatTableOffRendersReadableSectionsInsteadOfGrid() {
        val markdown = """| Feature | Finding |
| --- | --- |
| HPV | Persistent infection |
| Smoking | Synergistic risk |"""
        val html = rovexMarkdownBody(markdown, showTables = false)
        assertFalse(html.contains("<table>"))
        assertTrue(html.contains("<h4>HPV</h4>"))
        assertTrue(html.contains("<b>Finding:</b> Persistent infection"))
    }

    @Test fun tablesRemainTablesWhenEnabled() {
        val markdown = """| Feature | Finding |
| --- | --- |
| HPV | Persistent infection |"""
        val html = rovexMarkdownBody(markdown, showTables = true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<th>Feature</th>"))
    }

    @Test fun collapsedProviderTableIsRecovered() {
        val markdown = "Intro | text | ### Re-framed | Distractor | New stem | Correct answer | Fact | | --- | --- | --- | --- | | A | Stem A | TTG-1 | intestinal isoform |"
        val html = rovexMarkdownBody(markdown, showTables = true)
        assertTrue("collapsed GFM table should become a real table", html.contains("<table>"))
        assertTrue(html.contains("<th>Distractor</th>"))
        assertTrue(html.contains("TTG-1"))
    }

    @Test fun mismatchedRowDoesNotBecomeMalformedTable() {
        val lines = listOf(
            "| A | B |",
            "| --- | --- |",
            "| 1 | 2 | 3 |"
        )
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }
    @Test fun htmlTableIsRenderedAsRealTable() {
        val html = rovexMarkdownBody("<table><tr><th>Stage</th><th>Treatment</th></tr><tr><td>I</td><td>Surgery</td></tr></table>", true)
        assertTrue(html.contains("<th>Stage</th>"))
        assertTrue(html.contains("<td>Surgery</td>"))
        assertTrue(html.contains("table-wrap"))
    }

    @Test fun unfencedMermaidSubgraphFragmentIsRecovered() {
        val markdown = """subgraph Stage IV
IVA[IVA]:::stage
IVB[IVB]:::stage
end
classDef stage fill:#f9f9f9,stroke:#333,stroke-width:2px;

- Stage I: Confined to cervix."""
        val html = rovexMarkdownBody(markdown, true)
        assertTrue(html.contains("rich-mermaid-fragment"))
        assertTrue(html.contains("IVA"))
        assertTrue(html.contains("Stage I"))
        assertFalse(html.contains("classDef stage fill:"))
    }

    @Test fun mermaidSubgraphFragmentIsNotShownAsRawSource() {
        val markdown = """```mermaid
subgraph Stage IV
IVA[IVA]:::stage
IVB[IVB]:::stage
end
classDef stage fill:#f9f9f9,stroke:#333,stroke-width:2px;
```"""
        val html = rovexMarkdownBody(markdown, true)
        assertTrue(html.contains("rich-mermaid-fragment"))
        assertTrue(html.contains("IVA"))
        assertFalse(html.contains("classDef stage fill:"))
    }

    @Test fun unfencedMermaidStyleFragmentIsRecovered() {
        val html = rovexMarkdownToHtml("""Clinical pathway:
style A fill:#fff,stroke:#333
style B fill:#eee,stroke:#333
A --> B
""")
        assertTrue(!html.contains("style A fill:#fff"))
        assertTrue(!html.contains("style B fill:#eee"))
        assertTrue(html.contains("rich-diagram"))
    }

}
