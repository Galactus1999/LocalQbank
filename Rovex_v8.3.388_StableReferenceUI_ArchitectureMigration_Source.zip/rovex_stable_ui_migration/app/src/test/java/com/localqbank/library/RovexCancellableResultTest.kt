package com.localqbank.library

import kotlinx.coroutines.CancellationException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class RovexCancellableResultTest {
    @Test
    fun cancellationIsNeverConvertedToFailureResult() {
        val thrown = assertThrows(CancellationException::class.java) {
            resultOf<String> { throw CancellationException("test cancellation") }
        }
        assertEquals("test cancellation", thrown.message)
    }

    @Test
    fun ordinaryFailureRemainsARecoverableResult() {
        val result = resultOf<String> { error("ordinary failure") }
        assert(result.isFailure)
        assertEquals("ordinary failure", result.exceptionOrNull()?.message)
    }
}
