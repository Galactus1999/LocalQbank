package com.localqbank.library

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class StreakPolicyTest {
    @Test fun first_study_day_starts_one_day_streak() {
        val r = StreakPolicy().apply(StreakManager.Snapshot(), LocalDate.of(2026, 9, 22))
        assertEquals(1, r.currentStreak)
        assertEquals(1, r.longestStreak)
        assertEquals(1, r.totalStudyDays)
    }

    @Test fun consecutive_day_extends_streak() {
        val previous = StreakManager.Snapshot(3, 5, 8, "2026-09-22")
        val r = StreakPolicy().apply(previous, LocalDate.of(2026, 9, 23))
        assertEquals(4, r.currentStreak)
        assertEquals(5, r.longestStreak)
        assertEquals(9, r.totalStudyDays)
    }

    @Test fun same_day_does_not_double_count() {
        val previous = StreakManager.Snapshot(4, 4, 9, "2026-09-23")
        val r = StreakPolicy().apply(previous, LocalDate.of(2026, 9, 23))
        assertEquals(4, r.currentStreak)
        assertEquals(4, r.longestStreak)
        assertEquals(9, r.totalStudyDays)
    }

    @Test fun gap_resets_current_but_preserves_longest() {
        val previous = StreakManager.Snapshot(7, 7, 12, "2026-09-20")
        val r = StreakPolicy().apply(previous, LocalDate.of(2026, 9, 22))
        assertEquals(1, r.currentStreak)
        assertEquals(7, r.longestStreak)
        assertEquals(13, r.totalStudyDays)
    }
}
