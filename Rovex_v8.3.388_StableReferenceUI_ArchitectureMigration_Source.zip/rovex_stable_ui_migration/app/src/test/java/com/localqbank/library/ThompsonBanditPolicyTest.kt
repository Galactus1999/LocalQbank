package com.localqbank.library

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ThompsonBanditPolicyTest {
    private class FixedRandom(private val value: Double) : Random() {
        override fun nextBits(bitCount: Int): Int = (value * (1L shl bitCount)).toInt()
    }

    @Test fun sample_beta_stays_within_probability_bounds() {
        val policy = ThompsonBanditPolicy(FixedRandom(0.5))
        val sample = policy.sampleBeta(4.0, 2.0)
        assertTrue(sample in 0.0..1.0)
    }

    @Test fun select_action_returns_a_candidate() {
        val policy = ThompsonBanditPolicy(FixedRandom(0.5))
        val selected = policy.selectAction(mapOf("a" to (2.0 to 2.0), "b" to (8.0 to 1.0)))
        assertNotNull(selected)
    }

    @Test fun empty_candidates_returns_null() {
        val policy = ThompsonBanditPolicy(FixedRandom(0.5))
        assertEquals(null, policy.selectAction(emptyMap<String, Pair<Double, Double>>()))
    }

    @Test fun reward_is_clamped_and_decay_is_applied() {
        val policy = ThompsonBanditPolicy(FixedRandom(0.5))
        val (alpha, beta) = policy.updateBelief(10.0, 4.0, 2.0)
        assertEquals(10.95, alpha, 0.000001)
        assertEquals(3.98, beta, 0.000001)
    }
}
