package com.localqbank.library

import android.content.Context

/**
 * Durable milestone policy driven by the existing StudyEventSpine.
 * It emits milestone_reached events; UI layers decide how to render them.
 */
class MilestoneManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("study_milestones", Context.MODE_PRIVATE)
    private val listener: (StudyEventSpine.Event) -> Unit = { event ->
        when (event.name) {
            "quiz_completed" -> {
                val count = synchronized(questionMilestoneLock) {
                    val next = prefs.getInt(KEY_QUESTIONS, 0) + 1
                    // commit() keeps the read-modify-write as one serialized persistence boundary
                    // for the milestone counter; the surrounding event spine is also single-threaded.
                    prefs.edit().putInt(KEY_QUESTIONS, next).commit()
                    next
                }
                if (count in QUESTION_MILESTONES) publish("questions", count.toString())
            }
            "deck_completed" -> publish("deck", "completed")
            "streak_milestone" -> {
                val days = event.metadata["days"]?.toIntOrNull()
                if (days != null && days in STREAK_MILESTONES) publish("streak", days.toString())
            }
        }
    }

    init { StudyEventSpine.subscribe(listener) }

    private fun publish(kind: String, value: String) {
        StudyEventSpine.publishAsync(
            StudyEventSpine.Event(
                "milestone_reached",
                source = "milestones",
                metadata = mapOf("kind" to kind, "value" to value)
            )
        )
    }

    companion object {
        private val questionMilestoneLock = Any()
        private const val KEY_QUESTIONS = "questions_answered"
        private val QUESTION_MILESTONES = setOf(10, 25, 50, 100, 250, 500, 1000)
        private val STREAK_MILESTONES = setOf(3, 7, 14, 30, 60, 100)
    }
}
