package com.localqbank.library

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.util.Log

/** Reliable low-latency UI sound feedback. Loads asynchronously and plays only after the sample is ready. */
object RovexSoundFeedback {
    private const val PREFS = "ui"
    private const val KEY_ENABLED = "sound_feedback_enabled"
    private const val TAG = "RovexSound"
    private var pool: SoundPool? = null
    private var correctId = 0
    private var milestoneId = 0
    private var correctReady = false
    private var milestoneReady = false
    private var pending: Cue? = null
    private enum class Cue { CORRECT, MILESTONE }
    fun isEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (!enabled) release() else ensurePool(context)
    }
    fun playCorrect(context: Context) = play(context, Cue.CORRECT)
    fun playMilestone(context: Context) = play(context, Cue.MILESTONE)
    fun playTest(context: Context) = play(context, Cue.CORRECT)
    private fun play(context: Context, cue: Cue) {
        if (!isEnabled(context)) return
        val audio = context.getSystemService(AudioManager::class.java) ?: return
        if (audio.ringerMode == AudioManager.RINGER_MODE_SILENT || audio.ringerMode == AudioManager.RINGER_MODE_VIBRATE) return
        if (audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION) <= 0 && audio.getStreamVolume(AudioManager.STREAM_SYSTEM) <= 0) return
        synchronized(this) {
            ensurePool(context)
            val ready = if (cue == Cue.CORRECT) correctReady else milestoneReady
            val id = if (cue == Cue.CORRECT) correctId else milestoneId
            if (!ready || id == 0) { pending = cue; return }
            pool?.play(id, 0.75f, 0.75f, 2, 0, 1f)
        }
    }
    private fun ensurePool(context: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        val p = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { soundPool, sampleId, status ->
            synchronized(this) {
                if (status != 0) { Log.w(TAG, "Sound sample failed to load: $sampleId status=$status"); return@synchronized }
                if (sampleId == correctId) correctReady = true
                if (sampleId == milestoneId) milestoneReady = true
                val next = pending; pending = null
                if (next != null) {
                    val nextId = if (next == Cue.CORRECT) correctId else milestoneId
                    val nextReady = if (next == Cue.CORRECT) correctReady else milestoneReady
                    if (nextReady && nextId != 0) soundPool.play(nextId, 0.75f, 0.75f, 2, 0, 1f)
                }
            }
        }
        pool = p; correctReady = false; milestoneReady = false
        correctId = p.load(context.applicationContext, R.raw.rover_correct, 1)
        milestoneId = p.load(context.applicationContext, R.raw.rover_milestone, 1)
    }
    private fun release() { synchronized(this) { runCatching { pool?.release() }; pool = null; correctId = 0; milestoneId = 0; correctReady = false; milestoneReady = false; pending = null } }
}
