package com.localqbank.library

import android.content.Context

/** User-facing AI chat presentation preference. Tables remain structurally supported. */
object RovexTableDisplayPrefs {
    private const val PREFS = "chat_ui"
    private const val KEY_SHOW_TABLES = "show_tables_in_chat"

    private val explicitTableRequestPatterns = listOf(
        Regex("""(?i)\b(show|make|give|present|display|format|convert|put|use)\b.{0,36}\b(table|tables|tabular)\b"""),
        Regex("""(?i)\b(table|tables|tabular)\b.{0,28}\b(format|view|version)\b""")
    )

    fun showTables(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_SHOW_TABLES, false)

    /**
     * Explicit user requests are a per-response override of the default presentation preference.
     * Negative requests are deliberately excluded so "don't show a table" cannot enable tables.
     */
    fun showTables(context: Context, explicitUserPrompt: String?): Boolean {
        if (showTables(context)) return true
        val prompt = explicitUserPrompt?.trim().orEmpty()
        if (prompt.isBlank()) return false
        if (Regex("""(?i)\b(don't|do not|dont|without|no)\b.{0,24}\b(table|tables|tabular)\b""").containsMatchIn(prompt)) {
            return false
        }
        return explicitTableRequest(prompt)
    }

    fun explicitTableRequest(prompt: String): Boolean =
        explicitTableRequestPatterns.any { it.containsMatchIn(prompt) }

    fun setShowTables(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SHOW_TABLES, enabled).apply()
    }
}
