# Rovex v8.3.380 — Deep Frankenstein/Ben Local Search Root Audit

## Build identity
- versionName: `8.3.380`
- versionCode: `472`
- applicationId: `com.localqbank.library`
- baseline: v8.3.379 source archive

## Root-cause findings
The local-search failure was not a single missing synonym. The architecture had multiple retrieval compositions:

1. Frankenstein/Ren had its own clinical-expansion and raw-search rescue logic.
2. The grounded neural pipeline had a separate literal/alias retrieval implementation.
3. SearchActivity directly called QBankDb.search() and therefore could behave differently from Frankenstein.
4. Short topic routing treated terminal punctuation as a reason to leave the deterministic local-QBank lane. `cervical cancer?` could therefore enter the neural path instead of authoritative retrieval.
5. Raw recovery could let a sparse set of generic literal hits suppress clinically equivalent alias retrieval.

These were corrected by introducing `LocalQBankSearchService` as the single retrieval-composition contract while retaining `QBankDb` as the authoritative corpus/database owner.

## Implemented root fixes
- Added `LocalQBankSearchService`.
- Frankenstein/Ren now use the shared local retrieval contract for raw ID recovery.
- Grounded neural evidence retrieval now uses the same shared contract and bounded clinical aliases.
- SearchActivity question retrieval now uses the same shared contract.
- Sparse literal results no longer suppress bounded clinical terminology rescue.
- Topic intent routing is centralized in `LocalQBankSearchService.isLikelyTopicQuery()`.
- Terminal punctuation no longer forces a short clinical topic into the generative lane.
- Existing clinical expansions remain bounded and original-query preserving.
- Existing Mermaid fixes remain intact.

## Verification
- `tools/ruthless_audit.sh`: PASS
- Frankenstein policy audit: PASS
- coroutine cancellation audit: PASS
- phase-2 stability assertions: PASS
- architecture ownership audit: PASS
- XML parsing: PASS (0 malformed XML files)
- focused Kotlin compilation of `ClinicalQueryExpansion`, `LocalQBankSearchService`, and focused tests with Android/JUnit stubs: PASS
- applicationId/version identity: PASS
- Full Android Gradle/CI build: NOT VERIFIED in this environment; Gradle distribution DNS is unavailable.

## Known independent audit debt
`tools/architecture_regression_audit.py` still reports legacy baseline drift in pre-existing screens (Activity-size/persistence counts, stale AppContainer expectations, and singleton/object baseline). This gate is intentionally not falsified or marked green. Those findings are separate from the local-QBank retrieval root fix and require a dedicated architecture-baseline reconciliation rather than silently weakening the audit.

## Release rule
Do not call v8.3.380 CI-green until GitHub Actions builds this exact archive and the resulting APK is inspected for versionCode 472 and installed/tested on the target device.
