# Rovex v8.3.386 — QBank performance/search/import root-fix audit

## Scope
Baseline: v8.3.385 source. This release targets the reported regression cluster:
- QBank dashboard appears blank/loading and is expensive to open.
- Home repeatedly reloads QBank catalog data.
- imported QBanks can remain absent from cached UI after import.
- search must cover all local QBank questions and hierarchy.
- Frankenstein must use the local corpus as authoritative retrieval context.
- import must not trigger redundant whole-corpus search-index work.

## Root causes found
1. `dashboardTestRows()` used correlated `progress_v2` scans per test (`stable_key LIKE test_id || ':%'`). This scaled with number of tests *and* progress rows and was repeatedly called by Home and the QBank dashboard.
2. `progress_v2` did not store its owning `test_id`, forcing dashboard SQL to recover ownership by prefix matching the stable key.
3. `RovexHomeRevolution.refreshContinue()` and `RovexSectionDashboardActivity.loadLiveData()` independently queried the dashboard catalog instead of sharing a single loader/cache.
4. `QBankLoadingEngine` had a test/bundle cache but no shared source/dashboard catalog cache, so repeated navigation could reopen SQLite work unnecessarily.
5. The QBank dashboard initially rendered only its shell/nav before the asynchronous catalog query completed; this produced the reported blank screen appearance.
6. Import completion did not centrally invalidate the QBank catalog cache. A committed import could therefore exist in SQLite while an already-cached source/dashboard snapshot still hid it.
7. Generic question search and visual-only search had previously been conflated; v8.3.385 corrected that root regression. v8.3.386 preserves that separation.
8. Frankenstein's deterministic local search lane and stale in-flight race were corrected in v8.3.385; v8.3.386 preserves the shared retrieval architecture rather than adding a second search engine.

## Architectural changes
- Added indexed `progress_v2.test_id` with one-time migration/backfill.
- Added `idx_progress_v2_test_status`.
- Replaced per-test correlated progress subqueries with one set-based aggregate joined by `test_id`.
- Added `QBankDb.sourceById()` to avoid loading the complete source catalog when opening one QBank.
- Added `QBankLoadingEngine.loadDashboardRows()` as the shared catalog owner with TTL caching/coalescing.
- Added source and subsection metadata caching.
- Home and QBank dashboard now consume the shared catalog loader instead of directly opening their own dashboard queries.
- Import/delete state changes invalidate the shared QBank catalog cache.
- QBank dashboard now renders an explicit loading state before data arrives.

## Search architecture retained
`SearchActivity` and Frankenstein use `LocalQBankSearchService`.
The intended pipeline remains:
lexical FTS/LIKE + clinical expansion -> candidate set -> optional EmbeddingGemma semantic reranking -> deterministic verification/composition.
Neural models are not authoritative for QBank existence or provenance.

## Research basis
- Android UI architecture recommends unidirectional data flow and a state holder separating UI from data/business logic.
- Android performance guidance recommends keeping long I/O off the main thread and measuring TTID/TTFD.
- SQLite query-planner guidance emphasizes appropriate indexes and warns that complex joins/subqueries can produce expensive plans.
- SQLite FTS5 supports external/contentless index designs; this supports keeping searchable content separate from full question payloads.
- Hugging Face Sentence Transformers documentation describes embeddings/rerankers for semantic retrieval; this is appropriate as a second-stage accelerator, not as the QBank source of truth.
- Android background-task guidance supports WorkManager/long-running workers for durable user-visible background work. A future import hardening stage can migrate very long imports from the process-local executor to a lifecycle-resilient job without changing the parser/database contract.

## Verification performed
### Static regression/search audit
PASS:
- Frankenstein deterministic local search lane
- Main Search shared question + hierarchy retrieval
- QBank/sub-QBank OR recall
- subsection launch validation
- rich Markdown/table rendering path

### Performance architecture audit
PASS:
- indexed progress ownership
- set-based dashboard aggregation
- shared Home/QBank dashboard loader
- immediate QBank loading state
- import/delete cache invalidation
- generic search not image-only

### Project audits
PASS:
- ruthless static audit
- coroutine cancellation audit
- architecture ownership audit

### SQLite query verification
An isolated SQLite reproduction of the new dashboard query returned correct per-test totals, solved counts, correct counts, and resume positions without correlated subqueries.

### Build status
NOT VERIFIED.
Local Gradle execution remains blocked because the environment cannot resolve `downloads.gradle.org` while downloading Gradle 9.3.1. No Android compile/APK/device-runtime claim is made.

## Release identity
versionName: 8.3.386
versionCode: 478

## Remaining runtime verification required
1. CI release workflow must compile/package/sign the APK.
2. Install on OnePlus CPH2691 / Android 16.
3. Measure: cold Home, QBank tab open, existing QBank open, imported QBank visibility immediately after import, Search query, Frankenstein topic and interrogative query, subsection launch.
4. Capture logcat if any loading/blank/crash remains.
5. Use Macrobenchmark/Perfetto for TTID/TTFD and database spans before claiming performance improvement quantitatively.
