# Rovex v8.3.325 — Exact Logo + Pulse→Synapse Splash

## Changes
- Replaced the launcher application/round icon resource with the user-supplied Rovex logo image.
- The supplied logo bytes are preserved exactly; no crop, resize, recolor, compression rewrite, or drawing modification was applied.
- Replaced `RovexSplashView` with the supplied Pulse → Synapse splash implementation.
- Preserved the existing `RovexSplashActivity` public integration surface (`setOnFinished`, `start`, `skipToEnd`, attach/detach lifecycle).
- Android 12+ system splash remains OLED-black before the custom splash activity, avoiding a second competing animation.

## Validation
- XML parsing: PASS (0 errors)
- Duplicate IDs within each individual XML layout: PASS (0)
- Logo byte identity: PASS
- Source ZIP integrity: PASS
- Android/Gradle compilation: NOT CLAIMED; GitHub Actions remains the build gate.
