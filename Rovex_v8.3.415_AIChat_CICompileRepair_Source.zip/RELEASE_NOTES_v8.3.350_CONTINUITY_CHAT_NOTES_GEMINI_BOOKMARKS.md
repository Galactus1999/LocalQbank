# Rovex v8.3.350 — Chat/Resume/Notes/Cloud AI/Bookmark Stability

VersionCode: 443

## Fixes
- Hardened GFM table rendering against provider/router newline collapse. A real delimiter row plus consistent pipe structure is reconstructed into a genuine table instead of a single pipe-heavy paragraph.
- Preserved the user-facing table preference: tables remain off by default and explicit table requests/settings still render genuine tables.
- Continue cursor is now durable across answer, pause, stop and Activity/ViewModel teardown. Lifecycle checkpointing no longer overwrites the post-answer Continue target with the currently visible question.
- Home now exposes all four bookmark collections directly below the aggregate bookmarks card: Important, Revise, Doubt and Favourite.
- Previous-question control uses a direct click path and remains available at the first-question boundary with explicit feedback.
- Notes rich/AI cards now have an explicit OPEN NOTE action outside the WebView, preventing WebView child touch handling from swallowing the card tap. WebViews are destroyed on NotesActivity teardown.
- Google Gemini provider default model changed from a pinned Gemini 3.8 Flash model to Google's `gemini-flash-latest` alias. The alias is not a promise of a particular future model version; Google documents latest aliases as moving targets. API free-tier eligibility remains provider/account dependent.
- Cloud AI key UI now uses explicit in-dialog OPEN OFFICIAL KEY PAGE / GET KEY actions instead of relying on an AlertDialog neutral-button path; provider controls are clearer and directly actionable.

## Verification
- Pure Kotlin Markdown renderer/parser smoke test passed locally with Android/JSON stubs.
- Existing Gradle/JVM test execution could not be rerun locally because `downloads.gradle.org` DNS is unavailable in this environment.
- CI remains the authoritative Android build gate.
