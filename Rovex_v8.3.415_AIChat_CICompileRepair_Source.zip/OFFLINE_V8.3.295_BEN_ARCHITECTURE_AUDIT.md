# Rovex v8.3.295 — Ben / Frankenstein architecture and durability repair

## User-visible defect repaired
Frankenstein's Markdown tables could appear as raw `| ... |` text. The renderer already contained table CSS and a table extraction attempt, but malformed/concatenated AI separator rows were not recognized and the previous block protection could still produce invalid `<p><div>...</div></p>` HTML. v8.3.295 adds bounded table recovery, embedded-separator repair, Markdown formatting inside cells, HTML escaping of cell content, and block-level HTML that keeps tables outside paragraph tags.

## Ben / Frankenstein performance repairs
- `FrankensteinContextEngine` no longer opens/searches the QBank once per token (up to eight sequential searches). It performs one bounded search over the actual question first and only uses up to three lexical fallback terms when that result is sparse.
- `RenCognitiveEngine.searchQuestionIds()` now has a small in-memory 10-second/40-entry cache for repeated session retrievals. It is non-persistent and bounded, so QBank truth is never permanently cached.
- Frankenstein UI chat history is bounded to 20 displayed turns and 20,000 display characters per message. Full Ben responses remain available to the current SAVE path, while the WebView DOM is prevented from growing without bound.

## Stability / memory repairs
- `RenActivity.onDestroy()` now stops, detaches, clears and destroys its WebView. Android documents explicit WebView teardown as necessary to prevent native-memory leaks/OOM.
- Renderer and policy error handling no longer catches arbitrary `Throwable`/OOM. Input is bounded before parsing; `StackOverflowError` and ordinary exceptions are isolated, while catastrophic memory errors are not swallowed.
- `BenResponsePolicy` now correctly normalizes actual CRLF/CR and NUL characters (the previous source used escaped backslash sequences, so those controls were not actually normalized).

## File durability / corruption repairs
- Added `RovexAtomicFile` for same-filesystem atomic replacement after a temp file has been flushed/synced.
- Automatic/full backup replacement and diagnostic journal replacement no longer fall back to deleting the live file and copying a replacement. A process kill during a copy could otherwise leave a missing/truncated backup/database/diagnostic artifact.
- Full database restore no longer deletes the live DB before the staged replacement is renamed.

## Research basis
Android's current guidance recommends main-safe suspend/data operations, lifecycle-scoped cancellable work, explicit WebView destruction, and Macrobenchmark/Baseline Profile measurement for real device performance. SQLite's current documentation recommends WAL for concurrency while preserving appropriate synchronization/durability and warns against unsafe file copying of live WAL databases. Google AI Edge documents on-device Gemma/LiteRT as an inference layer rather than requiring the model to own application state. See the accompanying research notes in the development record.

## Verification performed offline
- Dependency-free Kotlin compilation of the modified `RovexMarkdown.kt` against Android text stubs: PASS.
- Standard Markdown table rendering: PASS.
- Malformed/concatenated separator rendering modeled on the supplied screenshot: PASS.
- Ordinary prose containing pipes is not converted to a table: PASS.
- Tables are emitted as block-level HTML outside `<p>`: PASS.
- Source ZIP contains no build/cache/APK/class/dex/so output.
- Android Gradle compilation still requires GitHub Actions because the local environment cannot resolve/download the configured Gradle distribution.
