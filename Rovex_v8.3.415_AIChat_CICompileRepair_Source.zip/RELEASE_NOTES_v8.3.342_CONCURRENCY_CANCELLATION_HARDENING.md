# Rovex v8.3.342 — Concurrency + Cancellation Hardening

- Atomically serialize the QBank streak read-modify-write across all `QBankDb` instances.
- Pair `StreakManager` milestone detection with the mutation lock.
- Make milestone question-count persistence explicitly serialized.
- Add `resultOf {}` which rethrows `CancellationException` instead of converting coroutine cancellation into a fallback result.
- Apply the cancellation-safe boundary to `StreakManager.recordStudyDay()` and `QuizViewModel.onCleared()`.
- Add JVM tests for cancellation semantics and an Android integration stress test for concurrent same-day streak writes.
- Keep the existing SQLiteOpenHelper/WorkManager/Crashlytics architecture unchanged.
- Do not introduce Hilt or a wholesale QuizActivity rewrite in this batch; both are staged after a green CI gate to avoid adding build/code-generation risk while the current stability baseline is being verified.
