# Rovex v8.3.320 — AI Chat / Search / UI Stability

- Version: 8.3.320 / versionCode 413.
- Both Frankenstein and Ben+AI use the shared deterministic Markdown/rich-content renderer.
- Hardened Markdown table parsing for AI providers that collapse table line breaks; genuine tables remain tables and wide tables scroll horizontally.
- Preserved authored mermaid/chart/tree/slides/image blocks instead of converting them to tables.
- Ben+AI remains full-screen with a smaller header/footer and now supports follow-up questions in the same AI chat, carrying recent conversation context.
- Frankenstein header made responsive so Free AI, text-size, and Model Lab controls remain visible on narrow displays.
- Replaced the oversized/ugly Free AI popup with a compact theme-adaptive provider panel.
- Frankenstein web search now carries recent chat context, has an editable search bar, and keeps HTTPS result navigation inside the controlled WebView.
- Google WebView search has Safe Browsing enabled, file/content access disabled, no JavaScript bridge, and explicit WebView cleanup on destroy.
- Settings secondary controls now use theme-adaptive elevated/outlined styling instead of hard blue-looking buttons.
- No heavyweight neural runtime or new model dependency added in this UI/stability batch.
