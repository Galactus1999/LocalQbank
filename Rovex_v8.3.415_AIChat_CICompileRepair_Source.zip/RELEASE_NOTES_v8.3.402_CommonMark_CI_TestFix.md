# Rovex v8.3.402 — CommonMark CI Test Fix

## Defect
GitHub Actions for v8.3.401 failed one JVM regression test:
`RovexRichRendererTest.inlineClinicalBulletsBecomeSeparateBlocks`.

## Root cause
The test input contained only two inline bullet items, but the assertion expected a third `Age range` item that was not present in the input. The CommonMark renderer was not the cause of the failure.

## Fix
Corrected the assertion to match the actual test fixture. No production renderer behavior was changed.

## Verification
- v8.3.401 CI log inspected.
- Kotlin/JVM compilation reached and completed the test execution stage.
- 1 regression assertion mismatch was the build-stopping failure.
- Production CommonMark/GFM implementation remains unchanged.
- Full v8.3.402 CI/build/device verification is still required.
