# Rovex v8.3.330 — Portrait reference splash

- Reworked RovexSplashView around the supplied reference video choreography.
- Portrait-first 9:16 composition: ECG wake-up → bright peak → particle burst → dense amber neural network → script Rovex wordmark → tagline.
- Procedural particles/network; no video asset added to the APK.
- Adaptive to other aspect ratios while preserving portrait composition.
- 6.5 s choreography: deliberately shorter than the ~10 s reference clip to avoid adding unnecessary cold-launch delay.
- Existing splash-to-Home fade remains in place.
- Existing exact launcher logo from v8.3.329 remains byte-identical and unchanged.
