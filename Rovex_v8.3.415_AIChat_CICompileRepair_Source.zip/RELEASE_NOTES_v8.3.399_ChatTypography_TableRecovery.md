# Rovex v8.3.399 — Chat Typography & Collapsed-Table Recovery

## Scope
- Prevent accidental whole-message bold appearance by enforcing normal base weight and bounded inline emphasis.
- Recover inline ` - Label:` and `> Clinical tip:` boundaries emitted without Markdown newlines.
- Recover collapsed 3+ column GFM tables from single-line provider output.
- Preserve existing safe HTML, Mermaid, image, table, paragraph, list and WebView architecture.
- No changes to Ben IPC, EmbeddingGemma, APKG import, flashcards, QBank database, SRS, or deterministic retrieval.

## Verification
- Standalone Kotlin renderer compilation: PASS.
- Collapsed 3-column table regression harness: PASS.
- Inline clinical-list boundary regression harness: PASS.
- Bold/normal-weight regression harness: PASS.
- XML/layout/ruthless static audit: PASS.
- Coroutine cancellation audit: PASS.
- Architecture audit: PASS (large-file warnings only).
- Search/QBank regression audit: PASS.
- Root architecture audit: PASS.
- Full Android Gradle build/CI: NOT CLAIMED; requires actual CI execution.
