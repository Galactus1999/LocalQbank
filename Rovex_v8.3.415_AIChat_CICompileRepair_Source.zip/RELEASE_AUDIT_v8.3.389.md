# Rovex v8.3.389 — Flashcard Import Recovery / Hierarchy Hardening

## Scope
- Stop stale interrupted APKG work from hijacking newly selected imports.
- Make APKG staging atomic before a recoverable session is created.
- Add a session token to the durable checkpoint so cancelled/replaced workers cannot overwrite a newer import state.
- Make checkpoint writes strict instead of silently swallowing checkpoint I/O failures.
- Treat WorkManager cancellation as cancellation, not a generic import failure.
- Normalize modern Anki deck hierarchy delimiter U+001F/U+001E to Rovex `::` hierarchy.
- Preserve explicit resume/discard flow and make discard cancel the unique import work before deleting checkpoint/source files.
- Preserve imported deck/subdeck tree deletion and explicitly delete dependent cards/review logs when removing a source.

## Verification performed
- Source inspection of APKG importer, worker, FlashcardActivity, FlashcardDb.
- CoreBTR.apkg structural inspection: 7065 cards, 258 decks, modern `collection.anki21b`, modern deck names use U+001F hierarchy delimiter.
- Exact checkpoint position 1591 corresponds to the first card of `CoreBTR` U+001F `General Physiology` U+001F `Pyqs`, making stale/recovery/session handling a high-value forensic boundary.
- ZIP/source integrity checks after packaging.
- Android Gradle build remains unverified because the environment cannot resolve `downloads.gradle.org`.
