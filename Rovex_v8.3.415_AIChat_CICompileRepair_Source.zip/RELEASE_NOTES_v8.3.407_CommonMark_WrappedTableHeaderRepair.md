# Rovex v8.3.407 — CommonMark Wrapped Table Header Repair

- Repairs provider output where the final GFM table header cell is wrapped onto the delimiter row.
- Keeps CommonMark as the authoritative parser; adds only a narrow compatibility normalizer.
- Adds a regression test reproducing the Drug Interactions table shape seen in the UI.
- No Ben IPC, EmbeddingGemma, APKG, QBank, flashcard, or database ownership changes.
- CI/device verification remains required before release.
