# Rovex v8.3.365 — Deep Forensic Architecture Repair Audit

## Baseline
- Input: `Rovex_v8.3.364_Deep_Forensic_Architecture_Repair_Source.zip`
- Package/applicationId: `com.localqbank.library`
- Version: `8.3.365`
- versionCode: `458`
- Target/compile SDK: 36/37 as inherited from v8.3.364
- Source baseline was re-read from the supplied ZIP; v8.3.364 was not assumed correct.

## New root causes found and repaired

### F1 — Quiz progress snapshot still had a hidden SQLite escape hatch
v8.3.364 moved many quiz mutations to the background lane, but `QuizViewModel.bookmark()`, `mistakeType()`, `progressStatus()` and `selectedAnswer()` still called `PerformanceManager.progress()` synchronously. A cache miss in `PerformanceManager.progress()` can enumerate the SQLite-backed progress store.

**Repair**
- `QuizViewModel` now owns a foreground immutable `ProgressSnapshot` cache.
- The cache is primed on the QBank worker.
- UI reads use the snapshot only.
- Mutation completion refreshes the snapshot off-main.
- Existing optimistic bookmark/mistake overlays remain.

### F2 — StudyStateRepository still performed synchronous progress reads
`StudyStateRepository.snapshot()` called `PerformanceManager.progress()` directly. `QuizAnswerUseCase.status()` reaches this method before accepting an answer, so this was a real foreground interaction path.

**Repair**
- Added a background-primed immutable progress snapshot.
- `snapshot()`, `status()`, and `isDue()` consume cached/optimistic state.
- Durable writes remain serialized on the QBank worker and refresh the snapshot afterward.

### F3 — Performance Lab had a second UI-thread database scan
`MainActivity.showInteractiveAnalyticsPrepared()` received a background progress snapshot but then called `AppManagers.analytics.snapshot(refs)`, which reacquired the progress store.

**Repair**
- Added `AnalyticsManager.snapshot(refs, progress, periodDays)`.
- UI rendering now computes analytics entirely from the already-loaded immutable snapshot.
- Removed the redundant database read.

### F4 — Legacy Home Today-Solved/Revision actions retained synchronous DB-capable use-case calls
Although the modern Home no longer inflates the legacy dashboard, the compatibility methods could still invoke progress/database work from a click callback.

**Repair**
- Today-Solved and Today-Revision collection generation now execute through `PerformanceManager`.
- Modern Performance Lab computes its due count directly from its existing snapshot.

### F5 — Application/ViewModel construction still opened SQLite handles eagerly
Several screen repositories and the study-state repository could construct `QBankDb`, `ProgressStore`, or `FlashcardDb` while ViewModel factories ran on the main thread.

**Repair**
- `MainRepository` database/progress handles are lazy.
- `QuizSessionRepository` progress store is lazy.
- `QBankQuizDataSource` database handle is lazy.
- `SqliteFlashcardReviewRepository` database handle is lazy.
- `StudyStateRepository` progress store is lazy.
- `DataHealthManager` progress store is lazy.
- `FlashcardStudyActivity` no longer opens `FlashcardDb` during `onCreate`; it is created on its study executor.

This follows Android startup guidance to avoid I/O-bound work during startup and critical UI construction.

### F6 — Flashcard lifecycle durability path could synchronously commit SharedPreferences
`FlashcardStudyActivity` used `commit()` at lifecycle boundaries for the compact recovery cursor.

**Repair**
- All cursor persistence uses `apply()`.
- The cursor remains in-memory immediately and is also captured in `onSaveInstanceState`.
- Lifecycle callbacks no longer synchronously wait for a disk commit.

### F7 — Flashcard WebView trusted-bridge surface accepted active imported HTML
The card renderer enables JavaScript because it uses a small Rovex JS bridge for image/reveal interaction. Imported card HTML could otherwise contain active scripts/event handlers alongside that bridge.

**Repair**
- Strip `<script>` and `<iframe>` blocks from imported card HTML before embedding.
- Strip inline `on*` event attributes and `javascript:` URLs.
- Keep the Rovex-owned script outside the sanitized user HTML.
- Disable content access and universal file-URL access.
- Retain compatibility mixed-content mode only for legacy remote card media.

The renderer remains protected by `RovexSafeWebViewClient`.

### F8 — Knowledge Vault search could queue an expensive artifact scan on every keystroke
The previous background repair prevented UI blocking but every TextWatcher event could enqueue a complete artifact scan/N+1 question-context lookup.

**Repair**
- Added 180 ms main-thread debounce.
- Obsolete scheduled renders are cancelled.
- Generation suppression remains in place.
- Only the latest query proceeds to the maintenance worker.

## Existing fixes reverified
- Modern Home is the only production dashboard tree.
- No legacy `performClick()` navigation bridges.
- FTS mutations cannot declare the index clean; authoritative rebuild remains responsible for clean state.
- QBank deletion remains isolated to its lowest-priority worker.
- Search result opening is background validated.
- Notes/Knowledge Vault database work remains worker-side.
- WebView renderer termination handling remains present.
- `MIXED_CONTENT_ALWAYS_ALLOW` remains absent.
- XML parsing and per-layout duplicate-ID checks remain clean.

## Static verification
- XML parse errors: 0
- Duplicate IDs within individual XML files: 0
- `performClick()` calls: 1; only the legitimate touch accessibility forwarding in `FlashcardStudyActivity`
- `MIXED_CONTENT_ALWAYS_ALLOW`: 0
- `GlobalScope`: 0
- `AsyncTask`: 0
- Main-source `runBlocking`: 0 (remaining test-only occurrences are instrumentation tests)
- Modified Kotlin delimiter balance: passed
- Package/applicationId preserved
- versionName/versionCode: 8.3.365 / 458

## Web research applied
Official Android guidance used during the audit:
- SQLite: reduce rows/columns, use SQL-side filtering, indexes, WAL, batch/serialized writes and query-plan analysis:
  https://developer.android.com/topic/performance/sqlite-performance-best-practices
- WebView memory/lifecycle: WebView has substantial native memory usage; explicitly detach/stop/destroy instances and handle renderer termination:
  https://developer.android.com/develop/ui/views/layout/webapps/manage-webview-memory
  https://developer.android.com/develop/ui/views/layout/webapps/managing-webview
- App performance: use Perfetto, memory profiling, Simpleperf and Android vitals to validate critical user journeys:
  https://developer.android.com/topic/performance/overview
  https://developer.android.com/topic/performance/measuring-performance
- Baseline Profiles: optimize startup and critical navigation/scrolling paths with ART AOT compilation; cover the actual critical user journeys:
  https://developer.android.com/topic/performance/baselineprofiles/overview
  https://developer.android.com/topic/performance/baselineprofiles/create-baselineprofile

## Architectural advantage created
Rovex now has a clearer separation:
1. UI = immutable/cached state consumption and rendering.
2. QBank worker = serialized SQLite/progress computation.
3. Delete worker = destructive database mutations.
4. Maintenance worker = filesystem/PDF/knowledge work.
5. WebView = contained rich renderer with explicit lifecycle recovery.
6. Baseline/Macrobenchmark = optimization of the actual modern Home/QBank/Ben journeys.

This converts the previous ANR pattern from a one-off bug into a guarded architecture: foreground interaction no longer needs to wait for a cold progress-store scan.

## Build verification
Local Gradle compilation was attempted with:
`bash ./gradlew --offline :app:compileDebugKotlin --no-daemon`

The wrapper attempted to download Gradle 9.3.1 and DNS resolution for `downloads.gradle.org` failed. Therefore Android compilation, lint, tests, APK packaging and runtime behavior are **not claimed as verified**.

## Required CI/device gate
Run the complete GitHub Actions release workflow, then on the OnePlus Android 16 device test:
- cold Home launch
- Home -> QBank -> all 19 subjects
- QBank search and rapid filter changes
- quiz rapid answering/bookmark/mistake/position transitions
- flashcard open/rating/undo/bury/suspend
- Frankenstein rich tables/images
- Notes and Knowledge Vault typing stress
- large QBank deletion while navigating
- low-memory/thermal pressure
- inspect Logcat + ANR traces + Perfetto/performance markers

Do not call v8.3.365 release-ready until CI and device validation pass.
