# Rovex v8.3.409 — CI defect repair audit

## Defect
GitHub Actions run 36220160754 for the v8.3.408 source completed compilation and reached `:app:testDebugUnitTest`, where 85 tests ran and exactly one failed:
`RovexRichRendererTest.wrappedTableHeaderCellIsRecoveredIntoCommonMarkTable` at `RovexRichRendererTest.kt:195`.

## Root cause
The wrapped delimiter fixture was:
`| Clinical Implication | ------------- | -------- ||`

The recovery scanner treated the doubled trailing pipe as an extra logical cell and then incorrectly attempted to consume the first real body row as a missing delimiter row. The resulting recovery returned no table, so the renderer test did not find `<table>`.

## Repair
1. Trim trailing empty logical cells before delimiter-suffix detection.
2. Once the complete header has been reconstructed and the remaining delimiter suffix is valid, synthesize missing delimiter cells rather than consuming the first body row.
3. Add an explicit regression test for the exact failing fixture.
4. Preserve valid GFM, ordinary pipe-heavy prose, escaped pipes, inline-code pipes, and following blockquotes.

## Scope
Changed only:
- `app/build.gradle.kts` versionCode/versionName
- `RovexMarkdownTableRecovery.kt`
- `RovexMarkdownTableRecoveryTest.kt`
- this audit note

No Ben/IPC/DB/APKG/import/UI business-owner code was changed.

## Verification
- Standalone Kotlin recovery compilation with `-Werror`: PASS.
- Standalone recovery regression harness: PASS.
- Exact failing wrapped-header fixture: PASS.
- Valid GFM preservation: PASS.
- Ordinary pipe-heavy prose preservation: PASS.
- Escaped/inline-code pipe tokenization: PASS.
- Following blockquote preservation: PASS.
- `tools/ruthless_audit.sh`: PASS.
- Architecture regression audit: same pre-existing failures as v8.3.408; no new findings.
- Defect regression audit: same pre-existing Main Search finding as v8.3.408; no new finding.
- Source ZIP integrity: PASS.
- Full Android Gradle/CI acceptance for v8.3.409: OPEN until CI runs against this exact source ZIP.
