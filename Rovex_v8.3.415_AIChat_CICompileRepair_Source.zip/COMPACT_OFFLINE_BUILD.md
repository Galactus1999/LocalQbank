# Rovex 8.3.271 compact offline source

Base: green v8.3.269 source.

Changes in this package: theme-safe question/option HTML rendering, generic Ben CSS/HTML wrapper sanitization, five-section dashboard race protection, subject-level QBank/Stats/Mastery aggregation, and removal of optional Qualcomm QNN/HTP native accelerator payloads. Deterministic/local Ben retrieval and required Zstandard Android support remain intact.

The APK size is intentionally not constrained. The distribution source ZIP is the size target: <25 MiB.
