# Rovex v8.3.294 — Offline Radical UI/Search Repair Audit

Date: 2026-09-21

## 1. AMOLED question/options visibility
- Centralized imported HTML colour sanitization in `QuizRichTextRenderer`.
- Removes imported foreground/background colour spans while retaining semantic formatting such as bold/italic/underline/size/typeface.
- Theme colours are never injected as `ForegroundColorSpan`; TextView base colour is the sole semantic colour authority.
- Added semantic roles for question, explanation, option, option-label and Ben/AI TextViews.
- On QuizActivity resume, all imported colour spans are stripped again and semantic roles are assigned current ThemeManager colours.
- This breaks the previous failure mode where an imported/cached colour span or stale theme colour could override the AMOLED palette.

## 2. Frankenstein / Ben search latency
- Explicit local-search commands now bypass neural model initialization/inference.
- Deterministic local QBank retrieval remains authoritative for question discovery.
- Retrieval now executes a fast primary-query path first (80 candidates).
- Expansion variants are only queried when the primary result set is sparse; expansion fan-out is capped at seven additional variants and 80 candidates each.
- This removes the previous unconditional expansion fan-out and avoids waiting for a neural accelerator for a search request.

## 3. Footer theme switching
- Main Home footer is now explicitly painted on every resume with a theme-owned background and 1dp accent border.
- Section footer is repainted on every resume/theme change with the same semantic palette.
- Selected section uses accent text + theme background + accent border instead of an inverted white capsule, avoiding the screenshot's white/invisible-text failure.

## 4. Home footer state
- Home never marks QBank/Cards/Mastery as selected.
- Home footer only displays the accent border glow.
- Section screens own the selected state.

## Static verification
- XML parsing: PASS.
- Duplicate IDs per layout: PASS.
- Source assertions for radical AMOLED span invariant: PASS.
- Source assertions for semantic quiz roles: PASS.
- Search neural bypass + fast-path assertions: PASS.
- Footer border/state assertions: PASS.
- Version: 8.3.294 / versionCode 388.
- Source directory size before ZIP: approximately 3.8 MB.

## Build verification limitation
A local Gradle compilation was attempted but the environment could not resolve `downloads.gradle.org`, so Gradle 9.3.1 could not be downloaded. Therefore this offline ZIP is source-verified, not claimed as locally compiled.

Official Android references consulted during the repair:
- https://developer.android.com/reference/kotlin/android/widget/TextView
- https://developer.android.com/develop/ui/views/theming/themes
- https://developer.android.com/develop/ui/views/theming/darktheme
