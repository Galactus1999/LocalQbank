# Rovex v8.3.366 — Deep Dual-UI Crash / Architecture Repair Audit

## Baseline
- Input: `Rovex_v8.3.365_Deep_Forensic_Architecture_Repair2_Source.zip`
- Working copy: `/mnt/data/app-fix`
- Branch: `fix/dual-ui-crashes`
- Package/applicationId: `com.localqbank.library`
- Previous version: 8.3.365 / versionCode 458
- New source version: 8.3.366 / versionCode 459

## Executive summary
The supplied source no longer inflated `activity_main.xml` in `MainActivity`, but it still contained a partially migrated dual-controller architecture. The modern Home was the visible runtime UI while large portions of `MainActivity` retained the old XML-dashboard controller, ViewModel, RecyclerView, styling, source-edit/delete, collection and navigation code. Several modern Performance Lab paths still called that legacy ViewModel indirectly.

The repair removes those runtime/controller escape hatches without deleting `activity_main.xml` from the source tree. The legacy layout remains available as a compatibility/reference artifact, but it is no longer instantiated or consulted by the modern Home.

## Confirmed root causes

### DUAL-UI-01 — Legacy MainViewModel remained reachable from modern Home
**Severity:** P1

**Evidence:**
- `app/src/main/java/com/localqbank/library/MainActivity.kt` previously declared `MainViewModel` and used it from modern Home-dependent methods.
- `showInteractiveAnalyticsPrepared()` previously read `mainViewModel.uiState.value.sources`.
- `currentQBankRefs()` previously delegated to `mainViewModel.currentQBankRefs()`.
- `stateListener` previously had a legacy fallback to `mainViewModel.refresh()`.

**Root cause:** The UI migration removed the old layout inflation but did not fully remove the old controller dependency. The visible new UI therefore retained an old UI-state owner and could observe stale/empty legacy state.

**Repair:**
- Removed `MainViewModel` ownership from `MainActivity`.
- Removed legacy UI collector/refresh pipeline.
- Moved the shared current-QBank selection policy into `StudyQueuePolicy`, a UI-free pure policy object.
- Modern Performance Lab now derives its QBank focus map directly from its immutable `QuestionRef` snapshot instead of the legacy ViewModel state.
- AppState refresh now refreshes only the modern Home.

### DUAL-UI-02 — Hidden legacy container was still part of `RovexHomeRevolution`
**Severity:** P1

**Evidence:**
- `RovexHomeRevolution.apply()` previously allocated a `legacy` `FrameLayout`, attempted to detach/reparent any root children, hid the container, and added it back as a 1x1 child.
- The current `MainActivity` already creates an empty `dashboardRoot`, so there was no reason for a legacy runtime container to exist.

**Root cause:** Migration code from the older layered implementation survived after the production Home stopped inflating the legacy layout.

**Repair:**
- Removed the hidden legacy container and reparenting logic.
- `RovexHomeRevolution` now creates exactly one Home shell under `dashboardRoot`.
- `activity_main.xml` is retained in source; it is not deleted.

### DUAL-UI-03 — Modern analytics depended on legacy source state
**Severity:** P1

**Evidence:**
- Performance Lab's QBank focus map used `mainViewModel.uiState.value.sources`.

**Root cause:** The new dialog was rendering from a mixture of modern `PerformanceManager` snapshots and legacy Home ViewModel state.

**Repair:**
- Source grouping now comes directly from the already-loaded `QuestionRef` objects and immutable progress snapshot.
- No second UI state store is required.

### DUAL-UI-04 — Modern study queue path indirectly crossed the old controller boundary
**Severity:** P1

**Evidence:**
- `MainActivity.currentQBankRefs()` previously called `MainViewModel.currentQBankRefs()`.
- Modern Performance Lab uses this method for the active-source focus and due queue.

**Repair:**
- Added `StudyQueuePolicy.currentQBankRefs(allRefs, session)`.
- Both the compatibility `MainStudyUseCase` and modern Home use the same UI-free policy.
- Added unit coverage for active-session and fallback-source behavior.

## Structural invariants after repair
1. `MainActivity` contains no `MainViewModel` reference.
2. `MainActivity` contains no `activity_main.xml` runtime inflation.
3. `MainActivity` contains no references to legacy dashboard IDs such as `libraryList`, `homeSearchCard`, `renCard`, `todaySolvedCard`, or legacy collection buttons.
4. `RovexHomeRevolution` contains no hidden legacy runtime container.
5. Production Home has one programmatic dashboard root and one Home shell.
6. Persistent bottom navigation remains owned by `RovexBottomNavigation`.
7. `activity_main.xml` remains in the source tree for compatibility/reference and was not deleted.

## Validation performed
- Git diff whitespace validation: PASS (`git diff --check`).
- Kotlin brace-balance scan of modified Kotlin files: PASS.
- XML duplicate-ID audit within each layout: PASS in baseline; no layout XML was changed by this repair.
- Search for MainActivity legacy controller references: PASS — no `MainViewModel` or legacy dashboard IDs remain.
- Search for hidden legacy container implementation: PASS — removed.
- Unit test added: `StudyQueuePolicyTest`.

## Build limitation
`./gradlew --offline :app:compileDebugKotlin --no-daemon` could not execute because the wrapper requires Gradle 9.3.1 and that distribution is not cached. The environment attempted to resolve `downloads.gradle.org` and DNS failed.

Therefore Android compilation, lint, JVM tests, APK packaging, instrumentation tests, and runtime behavior are **not claimed as verified** in this environment.

## Required CI/device validation
Run the complete CI workflow and then verify on the target Android 16 device:
- cold Home launch
- Home -> QBank -> subject navigation
- rapid Home refresh/state events
- Performance Lab open/close and period switching
- DUE NOW action from Performance Lab
- theme change and Activity recreation
- Home -> Search -> Quiz -> Back -> Home
- Home -> Flashcards / Ben / Tools
- memory/ANR traces during rapid navigation

## Rollback
Revert commit `fix(architecture): eliminate legacy Home controller from modern UI` or restore the supplied v8.3.365 ZIP. The original `activity_main.xml` remains intact, so source-level rollback does not require reconstructing the legacy layout.
