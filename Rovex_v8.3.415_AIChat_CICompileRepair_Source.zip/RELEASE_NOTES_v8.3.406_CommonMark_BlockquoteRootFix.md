# Rovex v8.3.406 — CommonMark Blockquote Root Fix

## CI defect addressed
The v8.3.405 CI run compiled successfully but failed one JVM test:
`RovexRichRendererTest.commonMarkRendersNestedListsAndBlockquotes`.

### Root cause
`rovexMarkdownBody()` escaped the entire Markdown buffer before invoking CommonMark. In particular, `>` became `&gt;`, so a Markdown blockquote was no longer visible to the CommonMark parser. This was a renderer defect, not a stale test expectation.

### Repair
- Preserve Markdown syntax characters for CommonMark.
- Neutralize only residual unsupported/raw HTML tags after supported HTML has been tokenized.
- Keep the existing safe rich-block, image, table, and CommonMark pipeline intact.
- No Ben/IPC/EmbeddingGemma/APKG/QBank ownership changes.

## Verification status
Local Gradle verification remains unavailable if the Gradle distribution cannot be downloaded in the current environment. Fresh GitHub Actions CI is required for compile + JVM-test confirmation.
