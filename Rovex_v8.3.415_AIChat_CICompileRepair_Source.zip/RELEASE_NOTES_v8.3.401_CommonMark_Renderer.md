# Rovex v8.3.401 — CommonMark/GFM Chat Renderer

## Purpose
Replace the regex-based Markdown paragraph/emphasis/list renderer with standards-based commonmark-java parsing while preserving Rovex rich-content preprocessing, safe local HTML, Mermaid/diagram rendering, images, and configurable table presentation.

## Implementation
- Added `org.commonmark:commonmark:0.30.0`.
- Added `org.commonmark:commonmark-ext-gfm-tables:0.30.0`.
- Added `org.commonmark:commonmark-ext-gfm-strikethrough:0.30.0`.
- `rovexMarkdownBody()` now parses normalized chat content through CommonMark AST + GFM extensions.
- Existing provider-collapsed-table recovery remains only as an input compatibility preprocessor; normal Markdown tables are now parsed by CommonMark's GFM table extension.
- Existing rich blocks/images/imported safe HTML remain protected around the standards parser.
- CommonMark HTML rendering enables URL sanitization.
- Numbered medical section headings are normalized before parsing.
- The former regex-based final paragraph/list/emphasis renderer was removed from the active pipeline.
- Existing table display preference is applied after CommonMark table rendering.

## Regression coverage
Added tests for paragraph boundaries, emphasis, nested lists, blockquotes, GFM tables, and safe inline HTML.

## Verification
- XML parse/duplicate-ID checks: PASS.
- Coroutine cancellation audit: PASS.
- Architecture audit: PASS with existing large-file warnings only.
- Search/QBank regression audit: PASS.
- Root architecture audit: PASS.
- Ruthless static audit: PASS.
- Direct Gradle verification: BLOCKED because this environment cannot resolve `downloads.gradle.org` while downloading Gradle 9.3.1. No CI/APK/runtime-green claim is made by this source package.
