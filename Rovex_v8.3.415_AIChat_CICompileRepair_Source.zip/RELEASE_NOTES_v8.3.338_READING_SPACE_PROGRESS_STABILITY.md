# Rovex v8.3.338 — Reading Space, Progress Continuity, Tools Navigation, Notes and Stability

- Compact Frankenstein and Ben+AI chrome; controls collapse on chat scroll and remain accessible through SHOW CONTROLS.
- Frankenstein keeps its dedicated full-screen workspace without the persistent bottom navigation.
- Bottom navigation fifth destination is now Tools and opens Study Tools; Notes remains a secondary surface.
- Saved notes open in a full-screen reading surface.
- Sound Feedback uses a strictly bounded 44x26dp custom toggle instead of a theme-sized switch.
- Home progress refreshes after committed study-state changes instead of remaining on the previous snapshot.
- Home 28-day progress visual is now a dotted accuracy trend.
- Continue Study prefers the durable live study-session cursor and answer-time resume checkpoint, so it returns to the exact last question rather than merely the last QBank.
- Answer persistence now checkpoints the answered test/position together with the progress write.
- Performance settings expose authoritative saved-answer counts, accuracy, and progress-index matching.
- Markdown tables ignore empty rows and render surviving single-cell rows as full-width rows instead of misleading blank columns.
- No new database writer or parallel business-logic owner introduced.
