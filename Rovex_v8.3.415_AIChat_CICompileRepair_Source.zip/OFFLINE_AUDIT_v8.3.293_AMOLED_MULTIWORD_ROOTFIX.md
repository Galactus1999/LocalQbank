# Rovex v8.3.293 — Offline AMOLED + Multi-word Ben/Frankenstein Root-Cause Repair

## Baseline
- Source: v8.3.292 / versionCode 386
- New source: v8.3.293 / versionCode 387
- Repository: Galactus1999/LocalQbank
- No GitHub Actions build was triggered during this repair batch.

## Root causes found

### 1. AMOLED Dark question text
The quiz renderer had already removed `ForegroundColorSpan`/`BackgroundColorSpan` and some `TextAppearanceSpan` color state, but the policy was duplicated between the parser and a later tree walk. The imported HTML boundary did not have one authoritative color-sanitization routine, and WebView AI surfaces did not consistently force inherited readable foreground colors for descendant elements.

Repair:
- Centralized imported HTML color sanitization in `QuizRichTextRenderer`.
- Removes foreground/background color declarations while preserving unrelated formatting attributes.
- Removes Android `ForegroundColorSpan` and `BackgroundColorSpan`.
- Rebuilds `TextAppearanceSpan` without foreground/background color while preserving typeface/style/size.
- Installs the authoritative AMOLED foreground span only after sanitization.
- `QuizActivity.enforceAmoledTextVisibility()` now calls the same central span policy and always resets the base `TextView` color/invalidation for the whole quiz tree.
- AMOLED question/options/explanation colors remain LightGoldenrodYellow `#FAFAD2`; Ben + AI uses `#7FE7E2`.
- WebView-based Frankenstein/Ben question context CSS now forces readable inherited/paragraph/list/table/link colors with `!important` where required.

### 2. Ben/Frankenstein multi-word request failure
The request itself was preserved through `EditText -> respond(cmd) -> FrankensteinSupportEngine -> BenResearchInputPolicy`, but the local QBank recall layer used an FTS `AND` query over every surface word. Normal grammatical words such as `what`, `is`, `of`, `the`, `how`, etc. therefore made ordinary clinical sentences return zero candidates. The previous Ren ranking fix did not fully solve this because the failure occurred earlier in `QBankDb.search()`.

Repair:
- `QBankDb.search()` now removes common grammatical stop words for retrieval while preserving the original query for exact-ranking checks.
- Strict meaningful-token FTS recall is attempted first.
- If strict recall returns no result, meaningful-token OR recall is used.
- SQL LIKE fallback mirrors the same strict-then-broad strategy.
- `searchImageQuestions()` receives the same natural-language retrieval treatment so visual questions do not regress.
- Downstream Ren/Ben ranking remains authoritative; this change restores recall rather than replacing semantic ranking.
- The original user sentence is not reduced to the first token or first list element.
- Ben input normalization remains bounded at 4096 characters and preserves normal spaces, punctuation and multiline content.

### 3. Ben + AI persistent context
The current Frankenstein/Ben UI was still appending chat turns to durable `renMemory`, despite being described as stateless by default. The repair removes those durable chat/study writes from the Ben + AI response path. In-session chat remains available in `chatTurns` for the visible UI and optional same-session prompt context, but it is not persisted as hidden durable chat context.

## Static verification performed
- `tools/ruthless_audit.sh`: PASS
- `tools/architecture_regression_audit.py`: PASS
- `tools/amoled_ui_audit.py`: PASS (one background-only Color.BLACK candidate in MainActivity adaptive insight; no hard-coded foreground defect)
- Changed Kotlin brace/parenthesis checks performed.
- Full project scans performed for color spans, WebView paths, input truncation and first-token patterns.

## Build status
Local Gradle compilation was attempted with `./gradlew :app:compileDebugKotlin --offline`, but the wrapper required Gradle 9.3.1 and the environment could not resolve `downloads.gradle.org`. Therefore Android compilation is **not claimed green**.

GitHub Actions was deliberately not consumed during exploratory correction. Release APK, signing, Firebase SHA-1, zstd, device runtime and complete workflow remain pending the explicit CI verification stage.
