# Rovex v8.3.344 — CI Compile Fix

VersionCode: 439

## Fixes
- Fixed unresolved `LayoutParams` references in `BenQuestionAiContextDialog` by using `ViewGroup.LayoutParams` for the two horizontal-scroll containers.
- Fixed the Sound Feedback TEST button compile error caused by passing `activity` to the local `rounded()` helper, whose signature accepts only color and radius.

## Validation
- Based directly on v8.3.343 source.
- CI log `logs_97025318019.zip` showed four Kotlin compiler errors in `compileDebugKotlin`; all four reported source defects are addressed here.
- Full Android/Gradle compilation remains a CI gate.
