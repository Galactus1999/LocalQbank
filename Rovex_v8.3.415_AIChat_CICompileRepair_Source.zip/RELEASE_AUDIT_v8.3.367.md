# Rovex v8.3.367 — Deep Defect Repair / Stability Audit

## Baseline
- Input: Rovex v8.3.366_Dual_UI_CrashRepair_Source.zip
- Input SHA-256: f5210886d540eb2db805020e8ce1f9d0f52ac16b702b22cd9f690396ab9f13ee
- Output version: 8.3.367
- Output versionCode: 460
- Package/applicationId: com.localqbank.library

## Confirmed defects fixed
1. **Flashcard first-load dead path** — `FlashcardStudyActivity.refreshCardData()` returned immediately whenever `db == null`, while DB initialization existed only inside the unreachable worker body. The first flashcard session could therefore render zero cards indefinitely. The guard was removed and DB acquisition is now worker-only and lifecycle-safe.
2. **Flashcard stale-load race** — navigation or study-set changes during an in-flight serial DB load could discard the old result without scheduling a new load. Added request generation plus mode/deck/session-limit/position validation and automatic rescheduling of stale loads.
3. **Flashcard teardown resource race** — `onDestroy()` could shut down the executor before a queued DB-close task ran, and a worker could race Activity teardown while creating the DB. Added explicit destroyed state, worker-side acquisition checks, and `LifecycleExecutor.closeWhenIdle()` so resource cleanup happens on the worker after active work.
4. **Study answer snapshot ordering bug** — successful answer persistence invalidated the progress cache but removed the optimistic overlay before refreshing it. The next foreground read could therefore briefly expose stale persisted state. The repair now persists → invalidates → refreshes immutable snapshot → removes only the matching optimistic overlay.
5. **Failed answer optimistic overlay leak** — persistence failure could leave an optimistic answer in `pendingAnswers` indefinitely. The latest failed ticket is now reconciled back to the durable snapshot and removed. Newer answer generations are preserved.
6. **Study Tools Smart Mix main-thread database path** — the Smart Mix button directly called `smartMix()`, which synchronously reads the question/progress indexes. It now uses the existing background collection lane.
7. **Quiz note main-thread SQLite path** — note editor loading called the repository synchronously from the UI, and note save/append also wrote synchronously. Note reads are now asynchronous/cache-backed and writes/append operations run on the QBank worker.
8. **Unused QuizBookmarkUseCase synchronous DB escape hatch** — `current()`/`mistakeType()` previously opened the global progress snapshot directly. They now consume the QuizViewModel's immutable foreground snapshot.
9. **Synchronous resume/milestone preference writes on study UI path** — `StudySessionStore.save()` and milestone counting used `commit()`. These were changed to `apply()`; crash recovery remains separately handled by the dedicated resilience checkpoint path.

## Static validation
- Kotlin files: 217
- Java files: 0
- XML files: 36
- XML parse errors: 0
- Duplicate IDs within individual XML files: 0
- package/applicationId preserved: YES
- Zstandard Android AAR: com.github.luben:zstd-jni:1.5.7-16@aar
- Ben inference service remains isolated in `:inference_process`.
- `LifecycleExecutor.kt` standalone Kotlin compilation: PASS.
- Full Android/Kotlin Gradle compilation: NOT VERIFIED because the wrapper attempted to download Gradle 9.3.1 and DNS resolution for downloads.gradle.org failed in this environment.

## Runtime-risk audit conclusion
The known v8.3.366 flashcard dead path and several additional foreground I/O/concurrency defects have been repaired at source level. The changes preserve the existing worker ownership model and do not move database work onto the UI thread.

**CI/device verification is still required. This source must not be called build-green until the complete GitHub Actions workflow passes.**
