# Rovex v8.3.373 Release Audit

Baseline: v8.3.372 / versionCode 465.

## CI failure repaired
GitHub Actions run log `logs_97232232787.zip` reached `:app:compileDebugKotlin` and failed with two root compile defects plus cascaded diagnostics:

1. `QBankDb.kt:372` referenced nonexistent `Question.sourceQuestionId`. The actual `Question` model exposes the database `source_question_id` as `sourceId`; `questionByStableKey()` now compares `it.sourceId` to the stable-key source-question component.
2. `RenActivity.kt:242` called `takeLast()` directly on Kotlin `Sequence<MatchResult>`. `findAll()` is a Sequence, so the bounded hydration now materializes the small transcript (`toList()`) before `takeLast(MAX_UI_CHAT_TURNS)`.

## Preserved v8.3.372 scope
- Search failure isolation/root-cause instrumentation.
- Supplied `rovex_button_click.mp3` for Quiz option taps and Flashcard interactions.
- Persistent Frankenstein chat hydration/write-through.
- Stable-key based Continue/resume identity propagation.
- Rich Markdown/HTML table and Mermaid-fragment rendering.

## Structural checks
- XML parsing: 0 errors.
- Duplicate IDs within individual XML layouts: 0.
- Kotlin source files: audited.
- `runBlocking`: 0.
- `GlobalScope`: 0.
- `Thread.sleep`: 0.
- `catch(Throwable)`: 0.
- Supplied sound SHA-256: `8d81cbfe9a05b30da6730f03c1976e59143cb425f8fa4d9e4129df6f65643b7a`.
- Version: 8.3.373 / versionCode 466.

## Compilation status
A local Gradle compile was attempted but the environment cannot resolve `downloads.gradle.org`, so local Android compilation is not verified. GitHub Actions CI must be treated as authoritative.

## Important
This source is **not CI-green until the complete GitHub Actions workflow succeeds**.
