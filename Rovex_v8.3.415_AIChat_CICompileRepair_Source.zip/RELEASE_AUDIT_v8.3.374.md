# Rovex v8.3.374 Release Audit

## Baseline
- Previous source: v8.3.373 / versionCode 466
- New source: v8.3.374 / versionCode 467
- Purpose: repair the JVM unit-test regression reported by GitHub Actions.

## CI failure analyzed
Uploaded workflow log: `logs_97235487994.zip`.

The build successfully reached Kotlin compilation and proceeded through:
- `:app:compileDebugUnitTestJavaWithJavac`
- `:app:processDebugUnitTestJavaRes`
- `:app:testDebugUnitTest`

The sole reported failing test was:
`RovexMarkdownTableParserTest > htmlTableIsRenderedAsRealTable`

CI reported:
`java.lang.RuntimeException at RovexMarkdownTableParserTest.kt:90`

37 tests completed, 1 failed. Therefore this was a **unit-test/runtime compatibility failure**, not a Kotlin compilation failure.

## Root cause
`rovexMarkdownBody()` called `renderHtmlTable()`, which used Android framework
`android.text.Html.fromHtml()` to extract text from HTML table cells.

`RovexMarkdownTableParserTest` is a JVM unit test. Android framework methods such as
`Html.fromHtml()` are not available in the plain JVM test environment and therefore
throw the standard "method ... not mocked" runtime failure.

This was a real implementation/test-boundary defect: the Markdown body renderer did
not need Android framework HTML parsing for the limited operation of extracting plain
text from table cells.

## Fix
`RovexMarkdown.kt` now uses a framework-independent `htmlCellText()` parser for
HTML-table cell extraction:
- removes script/style blocks
- converts `<br>` to whitespace
- strips remaining HTML tags
- decodes common HTML entities
- decodes numeric decimal/hex entities
- normalizes whitespace

The Android `Html.fromHtml()` call remains only in the separate full `renderHtml()`
path where Android Spanned output is intentionally required.

## Validation
- XML files: 37
- XML parse errors: 0
- duplicate IDs within individual XML layouts: 0
- Kotlin main-source files: 217
- `runBlocking` in main source: 0
- `GlobalScope` in main source: 0
- `Thread.sleep` in main source: 0
- `catch(Throwable)` in main source: 0

Local Gradle test execution was attempted but could not start because this environment
cannot resolve `downloads.gradle.org` while the wrapper attempts to obtain Gradle 9.3.1.
Therefore local tests are **not verified**.

GitHub Actions validation of v8.3.374 is still required. Do not call this release
CI-green until the complete workflow passes.
