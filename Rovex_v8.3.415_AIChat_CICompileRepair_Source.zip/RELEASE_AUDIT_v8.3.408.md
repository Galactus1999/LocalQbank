# v8.3.408 — Verification / Forensic Audit

## Baseline
- Starting source: v8.3.407 / versionCode 499.
- Starting source ZIP: `Rovex_v8.3.407_CommonMark_WrappedTableHeaderRepair_Source.zip`.
- Repair candidate: v8.3.408 / versionCode 500.

## Defect repaired
Provider-generated Markdown can lose physical line boundaries. The observed case split a table header,
separator cells and body rows across lines, then placed a Markdown blockquote after the final row on the
same physical line. The previous renderer used three independent regex normalizers, so each new provider
shape required another patch.

## Source changes
1. Added `RovexMarkdownTableRecovery.kt`.
   - Single state-machine recovery stage.
   - Handles wrapped header/delimiter/body rows.
   - Handles fully collapsed provider tables.
   - Preserves escaped pipes and inline-code pipes as cell content.
   - Requires delimiter evidence and bounded column counts.
   - Stops at Markdown structural boundaries.
   - Preserves a following blockquote instead of swallowing it into a table.
2. `RovexMarkdown.kt` now calls the single recovery stage before CommonMark/GFM parsing.
3. Removed the three previous table regex normalizers from the active pipeline.
4. Added focused recovery tests and an end-to-end renderer regression test for the observed screenshot shape.
5. Bumped version to 8.3.408 / versionCode 500.

## Dependency / architecture decision
No new parser dependency was added. Current CommonMark/GFM remains authoritative for valid Markdown.
Current online flexmark-java documentation was reviewed; its table extension has useful options such as
`APPEND_MISSING_COLUMNS`, `DISCARD_EXTRA_COLUMNS`, and `HEADER_SEPARATOR_COLUMN_MATCH`, but changing the
production parser in the same repair would increase regression surface without being necessary for this
root cause. A future parser benchmark can be performed as a separate controlled change.

## Proof executed
### A. Kotlin source compilation of new recovery engine
Command:
`kotlinc app/src/main/java/com/localqbank/library/RovexMarkdownTableRecovery.kt -Werror -d /tmp/rovex-recovery-compile.jar`

Result: `KOTLIN_RECOVERY_COMPILE=PASS`

### B. Recovery behavior proof harness
Command:
`kotlinc app/src/main/java/com/localqbank/library/RovexMarkdownTableRecovery.kt /tmp/RovexRecoveryProof.kt -Werror -include-runtime -d /tmp/rovex-recovery-proof.jar && java -jar /tmp/rovex-recovery-proof.jar`

Result: `RECOVERY_BEHAVIOR_PROOF=PASS`

Covered:
- exact screenshot-shaped malformed table;
- all five recovered rows;
- following blockquote separation;
- valid GFM byte-for-byte preservation;
- collapsed provider table recovery;
- pipe-heavy prose preservation;
- escaped/code-span pipe handling;
- tokenizer behavior.

### C. Whole-project static audit
Command:
`bash tools/ruthless_audit.sh`

Result:
`FIREBASE_OAUTH_CONFIG=PASS (Android + Web clients present)`
`XML_AND_LAYOUT_CHECK=PASS`
`MAIN_ACTIVITY_LAYOUT_ID_AUDIT=PASS`
`STATIC_AUDIT=PASS`

### D. Source diff isolation
Compared the v8.3.407 source tree against the repaired tree. Only these files changed:
- `app/build.gradle.kts`
- `app/src/main/java/com/localqbank/library/RovexMarkdown.kt`
- `app/src/main/java/com/localqbank/library/RovexMarkdownTableRecovery.kt` (new)
- `app/src/test/java/com/localqbank/library/RovexMarkdownTableParserTest.kt`
- `app/src/test/java/com/localqbank/library/RovexMarkdownTableRecoveryTest.kt` (new)
- `RELEASE_NOTES_v8.3.408_CommonMark_TableStateMachine.md`
- this audit file

No Ben/IPC/database/import/WebView security/business-owner source files were changed.

### E. ZIP integrity
Source ZIP:
`Rovex_v8.3.408_CommonMark_TableStateMachine_Source.zip`

SHA-256 before adding this audit file:
`6be0be40520af4573b1965134733edc0fcfb398f6c6446e57ba6cda80484be06`

Initial ZIP size: 2,052,356 bytes.

## Verification blocked / not claimed green
Full Android/Gradle verification could not run in this environment because the Gradle wrapper attempted
to download Gradle 9.3.1 and DNS resolution for `downloads.gradle.org` failed:
`curl: (6) Could not resolve host: downloads.gradle.org`.

Therefore this repair is **not marked CI-green, APK-verified, device-verified, or release-verified**.
No build/test/device result has been fabricated.

The GitHub `Rovex Build` workflow is configured to select the highest-version valid source ZIP from the
repository, run `:app:testDebugUnitTest`, build the release APK, verify the persistent signing certificate,
verify Qualcomm native libraries, and package the source ZIP. The candidate must be uploaded to the repository
before that external verification can occur.

## Known pre-existing audit failures observed after the repair
`tools/architecture_regression_audit.py` still reports pre-existing baseline drift in several large
Activities/source ownership metrics and `MainActivity.kt`'s historical AppContainer boundary check.
These files were not modified by this repair.

`tools/verify_defect_regressions.sh` currently fails its pre-existing Main Search hierarchy retrieval
invariant. Search/DB files were not modified by this repair.

These failures are recorded rather than silently treated as passing.
