# Rovex v8.3.349 — QBank Delete + Settings Search + Table Test Fix

VersionCode: 442
Baseline: v8.3.348

## Repairs
- Fixed the v8.3.348 CI JVM-test failure in `RovexMarkdownTableParserTest` by removing the Android-framework `TextUtils.htmlEncode()` dependency from the pure Markdown body renderer. Added a dependency-free HTML escaping helper.
- Preserved table-off/table-on behavior and genuine Markdown table detection.
- Hardened main imported-QBank deletion:
  - deletion is moved off the UI thread;
  - failures are contained instead of crashing the Activity;
  - FTS rows are explicitly removed because FTS does not participate in relational cascades;
  - durable `progress_v2` entries belonging to the deleted tests are removed;
  - normalized source/test/question descendants remain transactionally deleted;
  - library ordering is repaired after successful deletion.
- Reworked Settings Search into a real semantic settings index with aliases/keywords for natural queries such as `dark mode`, `tables`, `Gemma`, `RAM`, `backup`, `API key`, `streak`, `font`, etc.
- Removed the useless self-result where Settings Search could only return the Settings Search option itself.
- Search results route directly to the relevant settings subsection/control.

## Verification
- Source version increment verified: 8.3.349 / 442.
- XML parsing and duplicate-ID audit: PASS (duplicates checked only within each individual XML file).
- Markdown table parser JVM smoke test: PASS.
- Compact source size: ~3.11 MB before ZIP compression; no APK/JAR/SO/build artifacts included.
- Full Android/Gradle compilation: NOT VERIFIED locally because the environment cannot resolve `downloads.gradle.org`; GitHub Actions remains the definitive build gate.
