# Rovex v8.3.414 — AI Chat Rendering + Streaming Repair

## Scope
This release continues the v8.3.411 verified baseline and completes the source-side repair of the two affected chat surfaces:

- Dr. Frankenstein chat (`RenActivity`)
- BEN + AI chat (`BenQuestionAiContextDialog`)

The package/applicationId remains `com.localqbank.library`.
Version: **8.3.413** / versionCode **506**.

## Root cause
The primary production defect was in `BenResponsePolicy`.

AI responses were passed through the query-oriented `BoundedTextPolicy.normalize()`. That routine intentionally collapses whitespace, including Markdown newlines. As a result:

- GFM table rows were collapsed into prose.
- fenced Mermaid blocks lost their line structure.
- CommonMark/GFM received already-corrupted input and therefore could not reliably recover the authored structure.

A second renderer-boundary defect was also identified: the CSS sanitiser used a broad brace regex that could mistake legitimate Mermaid node syntax such as `B{Stage?}` or `A{Diagnosis: cervical}` for CSS. That sanitizer has now been narrowed and fenced code/rich blocks are protected before presentation sanitisation.

## Implemented repairs

### Forensic second-pass corrections

- Fixed the CSS-rule sanitiser replacement bug.
- Protected incomplete streaming fences and added CommonMark tilde-fence support.
- Moved streaming Markdown rendering off the Android main thread with latest-snapshot cancellation.
- Added smart-scroll retention and bounded chat DOM pruning.
- Added stale-generation guards for mode changes/cancellation/follow-ups.
- Hardened multi-provider streaming fallback so a failed provider's partial output cannot be concatenated with the next provider's response.


### 1. Rich Markdown response policy
`BenResponsePolicy` now:

- preserves `\n` and `\t` required by Markdown/GFM;
- continues bounding responses to `MAX_RESPONSE_CHARS`;
- preserves UTF-16 surrogate pairs and drops isolated surrogates;
- protects fenced code/rich blocks from CSS/HTML sanitisation;
- removes unsafe presentation constructs without collapsing authored Markdown structure;
- uses a Mermaid-safe CSS rule recogniser;
- has regression coverage for tables, Mermaid decision nodes, Mermaid labels containing colons, and fenced CSS-looking code.

### 2. Shared persistent chat document controller
New `RovexChatDocument` provides a fixed, local DOM controller for both chat surfaces.

It supports:

- append message;
- replace only the active/streaming message;
- remove message;
- clear document;
- scroll to bottom.

The WebView executes only the fixed application-owned document script. No JavaScript interface is exposed to the WebView.

AI output is rendered through the existing Markdown/rich-block renderer before DOM insertion.

### 3. Frankenstein chat
`RenActivity` now:

- uses the shared WebView hardening configuration;
- appends new turns instead of rebuilding the whole transcript;
- uses streaming for the Free-AI combined lane;
- coalesces stream updates instead of rendering every token;
- replaces only the active response node while streaming;
- keeps generation identity/cancellation protection;
- retains bounded persistent chat memory;
- preserves the existing local Frankenstein lane and its matching-question action.

### 4. BEN + AI chat
`BenQuestionAiContextDialog` now:

- uses the same shared WebView hardening configuration;
- keeps the Ben context summary and AI response in one persistent document on initial load;
- streams the Free-AI response into one replaceable message node;
- streams follow-up answers into their own message node;
- appends follow-up user messages without rebuilding the entire transcript;
- supports stopping an active Free-AI generation through the existing action control;
- safely handles cancellation, provider failure, empty responses and Activity destruction;
- no longer contains the legacy full-transcript `renderChatTranscript()` path.

## Regression tests added

- Markdown whitespace preservation.
- Control-character handling without destroying Markdown structure.
- Mermaid decision-node braces survive response policy.
- CSS-looking content inside fenced code survives response policy.
- Mermaid decision flow survives response policy + rich renderer.
- Screenshot-shaped collapsed table + Mermaid response is recovered end-to-end.
- Unsafe HTML/script/event-handler content does not reach final chat HTML.

## Verification performed locally

PASS:

- `bash tools/ruthless_audit.sh`
- `python3 tools/audit_coroutine_cancellation.py`
- `python3 tools/audit_frankenstein_policy.py`
- `bash tools/audit_chat_architecture.sh`
- `bash tools/verify_performance_search_architecture.sh`
- `bash tools/verify_root_architecture.sh`
- `bash tools/verify_search_qbank_regressions.sh`
- pure Kotlin response-policy harness, including Mermaid brace and fenced-code cases

BLOCKED:

- Android Gradle compilation/unit-test execution in this environment. The Gradle distribution download is blocked by DNS resolution of `downloads.gradle.org` (`curl: (6) Could not resolve host`).
- Therefore this source is **not claimed CI-green or device-verified**.

Known pre-existing architecture-regression audit findings remain outside this chat repair and are not being represented as fixed by this release.

## Online architecture research applied

The design follows current Android/AI guidance emphasizing:

- incremental streaming events rather than waiting for one complete response;
- defensive structured rendering for malformed AI output;
- fixed application-owned rendering surfaces rather than arbitrary AI-executed code;
- minimal WebView capabilities and explicit file/content restrictions;
- eventual structured message/block models for richer AI UI.

The current repair deliberately uses the smallest auditable step: a persistent document + incremental message nodes. A full native Compose/A2UI migration is a separate architectural project and is not falsely represented as completed by this source repair.
