# Rovex v8.3.321 — Resilient Large-Import Lifecycle

- Version: 8.3.321 / versionCode 414.
- Moved long-running APKG import lifecycle from the Activity-owned executor to WorkManager CoroutineWorker.
- Imports run as user-visible foreground work with cancellation and exponential retry; committed APKG checkpoints remain authoritative across process death.
- Added foreground `dataSync` declaration required for Android 14+ long-running import/export/local-file processing.
- APKG free-space planning now accounts for ZIP central-directory uncompressed media sizes before media extraction, while retaining lazy media extraction.
- QBank and Flashcard SQLite providers remain process-scoped `SQLiteOpenHelper` singletons; no Room migration was introduced because the existing database layer already provides shared WAL connections and the migration would add unnecessary risk.
- Debug StrictMode was already enabled and remains intact.
- No speculative multi-writer import pipeline was introduced: SQLite still has a single-writer bottleneck, and media extraction remains lazy. Parallelization will be benchmark-driven rather than adding contention to the database path.
