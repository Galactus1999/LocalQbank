# Rovex v8.3.378 Release Audit

## Baseline
- Baseline: Rovex v8.3.377 / versionCode 469
- Fix is applied in-place; no older Frankenstein/Ben UI was restored.

## CI root cause fixed
GitHub CI run using `Rovex_v8.3.377_Frankenstein_Ben_Search_RootFix_Source.zip` failed at `:app:compileDebugKotlin` in `FrankensteinContextEngine.kt`.

Compiler errors:
- `Unresolved reference 'mapIndexedNotNull'` on `reranked.indices`
- type inference failures for the lambda parameters
- downstream `exam` / `source` unresolved references caused by the failed inference

Root cause: `BenInferenceProcessClient.RerankResult.indices` is an `IntArray`; the previous code applied an indexed nullable transform directly to that primitive array, which did not resolve with the project's Kotlin compiler/toolchain.

Fix:
- convert `IntArray` to `List<Int>` using `toList()` before `mapIndexedNotNull`;
- explicitly distinguish the score rank from the candidate index;
- preserve the existing bounded rerank behavior and isolated-process architecture.

## Validation
- XML parsing: PASS (0 errors)
- Per-layout duplicate-ID audit: PASS (0 duplicates)
- Kotlin source inventory: 219 files
- `mapIndexedNotNull` on primitive `.indices` audit: no remaining unsafe pattern
- `runBlocking` audit: PASS
- `GlobalScope` audit: PASS
- `Thread.sleep` audit: PASS
- Version: 8.3.378 / versionCode 470
- Local Gradle compile: NOT VERIFIED because downloads.gradle.org DNS is unavailable in this environment.

## Architecture checks
- `RenActivity` remains the visible Frankenstein/Ben UI.
- No duplicate hidden Frankenstein search UI was restored.
- `AppManagers.renCognitive` remains the authoritative search engine path.
- Ben planner/search routes reuse the authoritative cognitive/search infrastructure.
- Deterministic QBank retrieval remains authoritative.
- Isolated neural inference architecture is unchanged.

## Remaining required validation
1. GitHub Actions `:app:testDebugUnitTest` / compile.
2. Install on OnePlus CPH2691 / SM8650.
3. Test: cervical cancer; cervical carcinoma; cervix cancer; natural-language clinical question.
4. Verify raw Mermaid source never appears in AI search output.
