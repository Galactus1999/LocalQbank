# v8.3.408 — CommonMark Table Recovery State Machine

## Scope

Replaced the previous chain of provider-specific table regex patches with one isolated,
high-confidence table recovery stage before CommonMark/GFM parsing.

## Defect addressed

AI/provider output can lose physical Markdown line boundaries. The observed failure split the
header, delimiter cells and body rows across multiple lines, then merged the following blockquote
into the table prose. CommonMark correctly rejects malformed structure; the renderer therefore
needs a recovery stage rather than additional regex substitutions.

## Safety contract

- Valid GFM is not rewritten by the recovery stage.
- Recovery requires delimiter evidence and exact column-cardinality evidence.
- Escaped pipes and inline-code pipes are not treated as column separators.
- Headings, lists, fenced code and blockquotes terminate recovery.
- Recovered tables are emitted as ordinary GFM for the existing CommonMark renderer.
- No Ben/IPC/AI inference architecture, database, import pipeline, WebView security boundary,
  or other unrelated business owner was changed.
