# Rovex v8.3.383 — Full Regression Root Audit

## Baselines used
- Uploaded known-working source: Rovex_Source.zip, v8.3.335 / versionCode 428.
- Current submitted source: v8.3.382 / versionCode 474.
- Repository historical resources inspected from Galactus1999/LocalQbank: v8.3.278 architecture/stability sources, v8.3.295 Ben durability, v8.3.299 UI, v8.3.304 corrected/UI stability sources, v8.3.319 Ben verifier source, v8.3.357 resource-forensic source, and historical release/audit notes through v8.3.382.
- Historical release notes were treated as behavioral contracts; source was not reconstructed from prose alone.

## Audit scope
- 274 main-source files in current source.
- 31,810 Kotlin source lines in current source.
- Compared all same-path Kotlin/XML/manifest/resource files against v8.3.335.
- Ran project-provided static architecture, cancellation, Frankenstein-policy, Phase-2, AMOLED and ruthless audits.
- Inspected search, Frankenstein/Ren, QBank DB/indexing, Continue/resume, import, backup, AI/IPC, notes, flashcards, UI/theme and resource-boundary changes for regression indicators.

## Confirmed regressions repaired

### R1 — SearchActivity lifecycle regression
Root cause: v8.3.382 changed onResume from the known-safe `::searchBox.isInitialized && ::db.isInitialized` guard to only `::searchBox.isInitialized`, allowing runSearch() to execute after database initialization failed. v8.3.382 also removed db.close() from onDestroy(), creating a database-handle lifecycle leak.

Repair:
- Restored both initialization guards in onResume().
- Restored guarded QBankDb.close() in onDestroy().

### R2 — Frankenstein search-ID fallback was not symmetric with answer() fallback
Root cause: searchQuestionIds() fell back to a single literal `QBankDb.search(q, limit)` call, while the authoritative answer() fallback used normalized clinical variants. This could return no IDs for an alias/clinical-equivalent query even when rawQBankSearch() could recover it.

Repair:
- Added rawQBankIds() using the same normalized + ClinicalQueryExpansion variant set.
- Closes the temporary QBankDb deterministically.

### R3 — Frankenstein empty-result cache poisoning
Root cause: searchQuestionIds() cached empty fallback results. A transient ranking/index failure could therefore suppress a later successful recovery for the entire cache TTL.

Repair:
- Empty ID results are no longer cached.
- Non-empty deterministic results remain cached.

## Historical architecture findings not silently classified as regressions
- The current source is materially larger than v8.3.335 because later features were added (Ben/IPC, Markdown/table handling, UI, search/index hardening, etc.). Size growth alone is not proof of a regression.
- Current architecture audit still reports baseline debt: large Activities/classes, direct persistence access in some Activities, singleton/object growth, and missing MainActivity AppContainer boundary. These remain explicit audit findings and were not weakened.
- Search/Frankenstein retrieval architecture changed substantially in v8.3.380. The current repair preserves authoritative QBankDb corpus ownership while retaining bounded clinical alias rescue.

## Verification
- tools/verify_defect_regressions.sh: PASS.
- tools/ruthless_audit.sh: PASS.
- tools/assert_phase2_stability.py: PASS.
- tools/audit_architecture.py: PASS (with existing large-file WARNs).
- tools/audit_coroutine_cancellation.py: PASS.
- tools/audit_frankenstein_policy.py: PASS.
- AMOLED foreground audit: PASS.
- XML parse and per-layout duplicate-ID audit: PASS.
- Android Gradle build: NOT VERIFIED in this environment because Gradle distribution DNS access is unavailable.

## Verification boundary
SOURCE REGRESSION REPAIR VERIFIED.
ANDROID COMPILE/APK/DEVICE RUNTIME: UNVERIFIED until CI executes the v8.3.383 source.
