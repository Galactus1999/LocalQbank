# Rovex v8.3.394 — Rich Chat + Notifications compile fix

## DEFECT #1 — StreakManager generic WorkManager builder
- STATUS: SOURCE FIX APPLIED; CI/build verification pending
- ROOT CAUSE: `OneTimeWorkRequestBuilder<T>()` is an inline/reified Kotlin API and cannot be called from the generic `enqueueAtLocalTime<T>()` function with a non-reified type parameter.
- FIX: Replaced the reified builder call with `OneTimeWorkRequest.Builder(workerClass)`, which accepts the runtime `Class<T>` already passed by the caller.
- Scope: `StreakManager.kt` only, plus version bump.
- No changes to Ben/IPC, APKG importer, QBank deletion, database schema, or renderer behavior.

## Verification
- Source-level assertion: the invalid reified call is absent and the class-based builder is present.
- Full Gradle/JVM/Android verification: pending CI.
