# Rovex v8.3.341 — Chat Fullscreen + Daily Progress Repair

- Fixed Settings Sound feedback row measuring to an enormous empty card; bounded to 68dp.
- Hardened chat chrome scrolling: deterministic WebView scroll callbacks, bottom-only collapse for Frankenstein, full top/bottom collapse for Ben+AI, corner reveal affordance, and automatic restoration at the top/reverse scroll.
- Ben+AI surface now uses a true edge-to-edge full-screen window treatment with no dimmed popup appearance.
- Notes reader now uses the same edge-to-edge full-screen window treatment and receives key points plus note body.
- Replaced the broken Daily Progress GridLayout/vertical-bar heatmap with the authoritative saved-answer 28-day accuracy chart, including today/28-day solved and accuracy summaries and an actual streak derived from saved answers.
