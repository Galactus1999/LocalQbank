# Rovex v8.3.361 — Deep UI-Coexistence / QBank / Search Forensic Audit

## Scope
This audit re-opened v8.3.360 with the explicit architectural fact that the legacy Home UI was retained while a new programmatic Home UI was layered over it. The audit therefore treats old UI, modern UI, shared infrastructure, navigation, lifecycle, SQLite/FTS and search as one system.

## External Android guidance applied
Android's current architecture guidance emphasizes a single source of truth and unidirectional data flow because multiple owners of the same UI/data state create inconsistencies and subtle bugs. It also recommends lifecycle-aware collection (`repeatOnLifecycle`) and main-safe repositories that move blocking work away from the UI thread. Navigation guidance recommends a predictable navigation graph and iterative migration rather than parallel, competing navigation paths.

## Findings from v8.3.360
1. **Legacy Home was still inflated at runtime.** `activity_main.xml` was inflated, then every child was detached into a hidden 1x1 legacy container. This preserved the old UI but still paid inflation, object allocation, view hierarchy and measurement/setup costs and left the legacy IDs discoverable through `findViewById`.
2. **Modern Home still contained a legacy `performClick()` bridge for Flashcards.** This was inconsistent with the previous direct-navigation repair and meant the modern navigation layer still depended on an old widget.
3. **RovexDailyStudyHub retained another legacy Flashcard `performClick()` fallback.**
4. **Modern Home could re-apply itself without a proper `UI305` guard.** The old guard checked only `UI304`, while `isApplied()` reported `UI305`.
5. **MainQBankLibraryActivity performed QBank-order database reads/writes on the main thread after asynchronous source loading.** This was a direct foreground-jank risk during the exact screen reported as crashing/stalling.
6. **QBank-library reload policy could reload immediately during the first `onResume()` after `onCreate()`, depending on timing.** The initial load is now distinguished from subsequent resumes.
7. **QBank deletion still performed library-order persistence from the UI callback.** The destructive operation itself was already off-main, but its follow-up DB mutation was not.
8. **QBank source/test metadata edits did not invalidate FTS content.** FTS content includes source/test labels, so a renamed QBank could have a stale FTS index while row counts remained identical. Count-only health detection was insufficient.
9. **FTS health based only on row counts could report a stale index as healthy.** A same-count replacement or metadata edit can leave semantically stale FTS content.
10. **Modern Home bookmark counts scanned the entire progress snapshot four times during UI construction.** This work is now deferred to the background worker and the visible controls render immediately.
11. **Milestone animation targets referenced legacy Home IDs after the legacy tree became non-authoritative.** Modern Home now exposes explicit tags for visible targets.

## Repairs in v8.3.361
- Production Home now installs a minimal `dashboardRoot` container and constructs only the modern Home tree. The legacy `activity_main.xml` remains in source for compatibility/reference and is not deleted.
- Removed all modern/legacy navigation `performClick()` bridges except legitimate touch forwarding in `FlashcardStudyActivity`.
- Modern Home Flashcards, Search, Frankenstein and other destinations use explicit intents/actions.
- `RovexHomeRevolution.apply()` now correctly guards against repeated application of the UI305 shell.
- Main QBank library ordering is computed and persisted on `PerformanceManager`'s serialized background worker rather than the UI thread.
- Initial-vs-subsequent QBank library reload is explicitly separated.
- QBank deletion order cleanup is performed inside the serialized deletion worker.
- QBank metadata edits are performed off-main.
- Added persistent `search_index_meta` dirty state.
- Source/test metadata mutation marks FTS dirty.
- Import paths mark FTS dirty while changing the corpus and clear the flag only when the resulting FTS/question counts agree.
- FTS rebuild now rebuilds when the dirty flag is set even if row counts happen to match.
- Interactive search continues to avoid synchronous full-corpus rebuilds; when FTS is unavailable/dirty it uses bounded normalized-table fallback.
- Modern Home bookmark counting is deferred to the serialized background worker.
- Milestone feedback targets visible modern Home views instead of legacy IDs.

## Why this architecture is advantageous
The retained legacy UI can remain as a compatibility/reference artifact without remaining an active runtime controller. This gives Rovex a migration path without paying the runtime cost of two UI trees. A single modern navigation owner also reduces duplicate Activity instances and back-stack ambiguity. SQLite/FTS remains an accelerator, while normalized QBank tables remain authoritative; this is compatible with Android's single-source-of-truth/offline-first guidance.

## Static verification
- XML parse errors: 0
- Duplicate `@+id` definitions within individual XML files: 0
- Modern Home legacy ID references: 0 inside `RovexHomeRevolution`
- Production UI navigation `performClick()` bridges: 0; remaining occurrence is legitimate touch-event accessibility forwarding in `FlashcardStudyActivity`
- Package/applicationId preserved: `com.localqbank.library`
- Version: 8.3.361 / versionCode 454
- Local Android Gradle compile: NOT VERIFIED because `downloads.gradle.org` DNS resolution is unavailable in this environment.
- CI-green: NOT CLAIMED; GitHub Actions must remain authoritative.

## Required device regression sequence
1. Cold launch Home.
2. Open QBank from bottom navigation.
3. Verify 19-subject QBank dashboard appears without crash/stall.
4. Open Browse QBanks and verify imported source list.
5. Open a QBank and return.
6. Search a common term, then a multi-word term such as `cervical cancer`.
7. Rename a QBank, search its new name, and verify it appears immediately through normalized fallback while FTS repairs asynchronously.
8. Open Frankenstein/Ren and repeat the same query.
9. Rapidly switch Home → QBank → Home → Search → Frankenstein.
10. Repeat with a large imported QBank and while background work is active.
11. Stress delete/reopen a large QBank and verify no input-dispatch ANR.

## Conclusion
v8.3.360 was not the final fix. The deep scan found remaining old/new UI coupling, main-thread QBank-library DB work, and a real semantic FTS-staleness hole that the count-only repair could not detect. v8.3.361 addresses those defects without deleting the retained legacy UI or replacing authoritative database/navigation ownership.
