# Rovex v8.3.393 — Rich AI Chat + Daily Study Notifications

## Scope
This repair batch is limited to Frankenstein/Ren rich rendering and the existing Study & Notifications owner. Import, flashcard database deletion, Ben IPC, EmbeddingGemma, QBank deletion, SRS, and search business logic are intentionally untouched.

## Rich AI chat
- Keeps the existing sanitized WebView architecture and deterministic Markdown fallback.
- Accepts normal fenced Mermaid plus providers that emit shortened two-backtick rich fences.
- Adds native, dependency-free Mermaid rendering for common AI-produced diagram families:
  - flowchart/graph with node shapes and labeled edges
  - sequence diagrams
  - state diagrams
  - class diagrams
  - ER diagrams
  - Gantt
  - pie
  - mindmap
  - timeline
  - journey
  - chart-like Mermaid sources
- Recognizes additional Mermaid families and preserves them in a safe structured preview rather than leaking raw malformed source into the chat layout.
- Malformed/unsupported diagrams fall back to readable source inside a bounded card; rendering failure does not terminate chat.
- Existing Markdown tables, HTML tables, images, code blocks, headings, lists, links, and rich HTML preservation remain on the same renderer path.
- Labeled Mermaid edges such as `B -->|Yes| C[...]` are parsed correctly.
- The parser does not catch `Throwable`; only stack overflow and ordinary exceptions receive presentation fallback.

## Notifications
- Extends the existing StreakManager rather than creating a competing notification owner.
- Daily motivational quote notification with a 60-quote deterministic offline rotation.
- Daily target reminder based on the existing saved `rovex:goal:daily` goal and the same today-progress semantics used by Home.
- Independent switches for motivation and target reminders.
- Configurable local times; defaults are 08:00 motivation and 20:00 target.
- Uses one-shot WorkManager scheduling for the next local clock time and reschedules after delivery, avoiding fixed 24-hour drift.
- Reuses the existing Android 13+ `POST_NOTIFICATIONS` permission flow.
- Notifications are presentation-only and do not mutate study data.

## Verification
- Static audit: PASS.
- Coroutine cancellation audit: PASS.
- Architecture audit: PASS with existing large-file warnings.
- Search/QBank regression audit: PASS.
- Root architecture audit: PASS.
- Performance/search architecture audit: PASS after replacing the stale hard-coded versionCode check with a monotonic versionCode check.
- Dependency-free Kotlin syntax/render smoke checks for the modified Markdown renderer: PASS.
- Full Gradle unit-test execution: BLOCKED in this environment because `downloads.gradle.org` DNS is unavailable.
- Android/device runtime verification: NOT YET VERIFIED.
- GitHub Actions verification: NOT YET VERIFIED.
