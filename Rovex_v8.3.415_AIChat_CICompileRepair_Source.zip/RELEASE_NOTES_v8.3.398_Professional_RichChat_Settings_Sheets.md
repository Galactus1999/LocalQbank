# v8.3.398 — Professional Rich Chat + Settings Surfaces

## Root causes repaired
- AI Markdown inline emphasis was regex-based with DOT_MATCHES_ALL, allowing `**` pairs to span unrelated blocks and make large portions of a response bold. Inline emphasis is now line-bounded.
- Provider output can collapse GFM table rows into one physical line. A second conservative recovery pass reconstructs a table only when a valid multi-column delimiter is present.
- The cloud-AI answer contract now explicitly requires blank-line paragraph boundaries, one physical line per GFM table row, semantic lists/headings, and restrained bold usage.

## UI polish
- Study & Notifications moved from the stock AlertDialog to a rounded Material bottom-sheet surface with grouped option cards and schedule controls.
- Cloud AI & Gemini moved to the same surface with provider cards, status, enable switch, connect/key-page/test actions, and a clear fallback-order note.
- Settings Search moved to the same surface with a dedicated search field, clear control, result cards, and chevrons.

## Safety
- No Ben IPC, EmbeddingGemma, APKG importer, QBank database, flashcard engine, or study-authority changes.
- Existing WebView/rich-content architecture remains in place.
- Build/runtime/CI verification is required before release; this source patch is not claimed CI-green until the workflow passes.
