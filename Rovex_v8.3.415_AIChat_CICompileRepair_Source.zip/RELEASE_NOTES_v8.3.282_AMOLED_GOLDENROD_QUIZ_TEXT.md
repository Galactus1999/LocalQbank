# Rovex v8.3.282 — AMOLED Dark Question Reading Palette

- Base: v8.3.281 Frankenstein static-init crash-fix source.
- AMOLED Dark core question/option/explanation text: LightGoldenrodYellow `#FAFAD2` (RGB 250,250,210).
- Ben + AI solving surfaces: luminous cyan `#7FE7E2` for AI identity/accent, with LightGoldenrodYellow for readable answer/body text.
- Explicit HTML renderer colour parameters are now honoured instead of being silently replaced by the generic theme text colour.
- Non-AMOLED themes retain their existing colours.
- versionName: 8.3.282; versionCode: 376.
