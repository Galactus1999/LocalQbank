# Rovex v8.3.410 Release Audit

## Scope
Repair candidate derived from v8.3.409 for the CommonMark/GFM malformed-provider table recovery defect found by Android CI.

## Defect #1 — Screenshot-shaped wrapped table recovery
- **STATUS:** Repaired; standalone verification PASS. Android CI verification PENDING for v8.3.410.
- **ROOT CAUSE:** The wrapped-table state machine correctly reconstructed the header/delimiter boundary, but the first physical body line could contain a repeated delimiter-shaped cell. That structural residue was interpreted as a real body cell, shifting all subsequent cells by one column. The malformed provider output also used empty-pipe sentinels between logical rows; treating those sentinels as semantic empty cells caused row cardinality drift and prevented completion of the table.
- **REPAIR:** In `RovexMarkdownTableRecovery.kt`, only inside the high-confidence wrapped-table recovery path: (1) discard a delimiter-shaped leading body token when it is the first cell of the first recovered body row; (2) treat empty pipe cells in this malformed collapsed-row state as row-boundary sentinels rather than semantic cells. Valid GFM is not globally rewritten.
- **FILES CHANGED:** `app/src/main/java/com/localqbank/library/RovexMarkdownTableRecovery.kt`, `app/build.gradle.kts` (versionCode 502 / versionName 8.3.410).
- **TESTS:** Existing regression tests `screenshotShapedWrappedHeaderDelimiterAndBodyAreRecovered` and `inlineBlockquoteAfterRecoveredRowsIsSeparatedFromTable` directly exercise the CI failures. A standalone Kotlin `-Werror` harness also exercises both fixtures plus valid GFM preservation, escaped/code pipes, ordinary pipe prose, and the double-trailing-pipe regression.
- **VERIFICATION:** `V8.3.410_RECOVERY_HARNESS=PASS`.

## CI evidence supplied for v8.3.409
- `:app:compileDebugKotlin` and downstream test compilation completed.
- `:app:testDebugUnitTest` ran 86 tests.
- 84 passed; 2 failed:
  - `RovexMarkdownTableRecoveryTest > screenshotShapedWrappedHeaderDelimiterAndBodyAreRecovered`
  - `RovexMarkdownTableRecoveryTest > inlineBlockquoteAfterRecoveredRowsIsSeparatedFromTable`
- Therefore v8.3.409 was correctly **not** considered green.

## v8.3.410 local/source verification
- Kotlin recovery harness with `-Werror`: PASS.
- Harness coverage: both previously failing fixtures, valid GFM unchanged, escaped/code pipes, ordinary pipe prose unchanged, double-trailing-pipe wrapped header.
- Ruthless static audit: PASS.
- Architecture regression audit: FAILED on pre-existing baseline findings; no source evidence indicates this renderer repair introduced those findings.
- Defect regression audit: FAILED on pre-existing finding `Main Search does not use authoritative hierarchy retrieval`; unrelated to this renderer repair.
- Full Android Gradle suite: **BLOCKED** in this environment because the wrapper requires Gradle 9.3.1 and DNS cannot resolve `downloads.gradle.org`.
- Device/runtime verification: **PENDING**.
- Release APK/signing/native-library/Firebase SHA verification: **PENDING**.

## Important acceptance state
v8.3.410 is a **repair candidate, not a verified release** until the exact source is run through GitHub Actions and the resulting logs show all required tests/build gates passing.
