# Rovex v8.3.348 — Energy Logo + CI Compile Fix

## Changes
- Fixed the v8.3.347 CI Kotlin compilation defect in `RenActivity.kt` by using the Activity receiver explicitly inside `buildString`.
- Replaced the Home header's Earth/living-world animation with the supplied Rovex cyan/violet energy emblem.
- Added `RovexEnergyLogoView`, a lightweight lifecycle-aware animation that adds:
  - breathing cyan/violet/magenta glow;
  - continuously moving colour arcs;
  - procedural outward electrical discharges and energy pulses.
- Updated `rovex_app_logo.jpg` with the supplied emblem artwork for the application launcher and in-app header.
- Kept the existing table-display preference: AI + Search and Frankenstein default to section/list presentation, with optional table rendering controlled by Settings.
- Preserved the 4-second splash duration from v8.3.347.

## Stability
- No parallel chat renderer or business-logic owner introduced.
- Energy animation stops when detached/invisible and uses only bounded Canvas work.
- VersionCode increased monotonically from 440 to 441.

\n## v8.3.348 follow-up correction
- Fixed the CI compile error in `RenActivity`.
- Corrected the table-off renderer so section-formatted tables are protected as block elements and receive dedicated chat styling.
- Explicit user table requests override the default OFF preference for the following Frankenstein response.
- Negative requests such as "don't show a table" do not trigger the override.
