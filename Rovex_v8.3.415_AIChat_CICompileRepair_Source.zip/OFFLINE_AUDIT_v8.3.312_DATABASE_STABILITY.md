# Rovex v8.3.312 — Database Concurrency / Ben Stability Audit

## Root-cause repair

The QBank and flashcard stores previously opened `SQLiteDatabase` directly from each wrapper instance. This allowed many independent SQLite handles and made `synchronized(db)` local to each wrapper ineffective across Activities/managers.

### Changes
- `QBankDb` now borrows a process-scoped `SQLiteOpenHelper` provider for `qbank.db`.
- `FlashcardDb` now borrows a process-scoped `SQLiteOpenHelper` provider for `flashcards.db`.
- WAL and foreign-key enforcement are configured centrally in `SQLiteOpenHelper.onConfigure()`.
- Schema creation/repair is centralized inside `onCreate()` / `onUpgrade()` and therefore serialized by SQLiteOpenHelper.
- Existing wrapper `close()` methods are intentionally no-ops so an Activity cannot invalidate the process-scoped database used by another manager.
- BenGroundedNeuralPipeline reuses the shared QBank facade rather than opening/closing a database for every query.
- Backup database snapshots now use the same shared helper-backed connection rather than opening a second raw SQLite connection.
- The critical Frankenstein/Ben suspend path rethrows `CancellationException` rather than swallowing coroutine cancellation.

## Static verification
- No `SQLiteDatabase.openOrCreateDatabase()` remains in `QBankDb.kt` or `FlashcardDb.kt`.
- QBank/flashcard wrapper close calls no longer close the underlying shared database.
- Modified Kotlin files have balanced braces.
- Ruthless static audit: PASS.
- XML/layout audit: PASS.
- MainActivity layout-ID audit: PASS.
- AMOLED foreground audit: PASS.
- Frankenstein policy audit: PASS.
- Phase-2 stability assertions: PASS.

## Known pre-existing audit warnings
The architecture regression script already failed on v8.3.311 before this batch because of the existing MainActivity/RenActivity/baseline singleton metrics. This batch did not increase the singleton/object count (70 before and after). Large-file warnings remain intentionally deferred to avoid a risky architectural decomposition during a crash/data-integrity repair.

## Build status
Local Android compilation remains unverified because `downloads.gradle.org` DNS/network access is unavailable in the current environment. GitHub Actions remains the authoritative Android build gate.
