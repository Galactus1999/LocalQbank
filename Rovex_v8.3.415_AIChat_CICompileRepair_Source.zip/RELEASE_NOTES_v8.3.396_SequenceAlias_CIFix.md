# Rovex v8.3.396 — Sequence Mermaid Alias CI Fix

## Root cause
The v8.3.395 CI suite had 63 tests with one failure: `RovexRichRendererTest.sequenceDiagramDoesNotBecomeRawSource` at line 58. `renderSequenceSvg()` correctly parsed `participant A as Doctor` and stored `displayNames[A] = Doctor`, but the SVG header rendered the participant ID (`A`) instead of the alias.

## Fix
The sequence renderer now uses the parsed display alias for visible participant headers while retaining the Mermaid participant ID internally for message routing. Unknown participants continue to display their ID.

## Scope
Only the sequence-diagram presentation path and version metadata were changed. No Ben/IPC, APKG, flashcard, QBank, SRS, importer, notification, or unrelated business logic changes.

## Verification
The CI log for v8.3.395 proves compilation succeeded and 62/63 JVM tests passed; the only failure was the sequence alias assertion. v8.3.396 requires a fresh CI run for authoritative verification.
