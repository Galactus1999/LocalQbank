# Rovex v8.3.388 — Sound / Search-Set / APKG Crash Hardening Audit

## Baseline
- Starting source: v8.3.387 / versionCode 479
- Output: v8.3.388 / versionCode 480
- Package: `com.localqbank.library`
- APK build: NOT VERIFIED locally because Gradle 9.3.1 cannot be downloaded in the current environment (`downloads.gradle.org` DNS failure).

## Defect 1 — UI sound feedback silent
### Root cause
The previous sound path explicitly gated playback on notification/system stream volume and used sonification usage. On devices where those streams were muted while media output was available, the app returned before calling `SoundPool.play()`. The first interaction also raced asynchronous sample loading.
### Changes
- `RovexSoundFeedback`: remove notification/system volume gate; use explicit media audio usage; preload SoundPool at application startup; provide a one-shot MediaPlayer fallback if the click sample is not ready or SoundPool returns stream 0.
- `SettingsScreen`: TEST reports if the sample is still loading.
- `ResilienceManager`: preloads the centralized sound pool once per normal app process.
### Asset verification
- `rovex_button_click.mp3`: SHA-256 `8d81cbfe9a05b30da6730f03c1976e59143cb425f8fa4d9e4129df6f65643b7a`
- 1536 bytes, 48 kHz, approximately 48 ms.

## Defect 2 — Search result navigation must form a set
### Root cause
SearchActivity previously launched QuizActivity with only `testId + questionId`, so QuizActivity loaded the containing QBank section instead of the visible search-result sequence.
### Changes
- Search question launch now passes the visible question IDs as `sessionIds` in retrieval order and sets `collectionMode=true`; the result counter reports the actual question count rather than counting section rows.
- QuizNavigationUseCase already supports `sessionIds`; no new navigation owner was introduced.
- Maximum set size is 500 IDs, matching the existing navigation resolver bound and remaining small enough for an Intent.
- Duplicate IDs are removed while preserving first occurrence order.

## Defect 3 — CoreBTR.apkg crash / black screen / persistent post-failure import
### Artifact inspection
`CoreBTR.apkg` SHA-256: `1fe73aa2b5d2c73a952f527cddf22f73c4808b4b952e05d79485ab6c1a5aa297`

ZIP members:
- `meta`
- `collection.anki21b` (2,026,917 compressed bytes)
- `collection.anki2` (51,200 bytes)
- `media`

The modern collection decompresses with Zstandard to SQLite and contains:
- 7,065 cards
- 7,065 notes
- 1 notetype
- 28 fields
- 9 templates
- 258 decks

The modern schema declares custom `unicase` collations on text columns. A host SQLite connection without that custom collation reproduces `no such collation sequence: unicase` for broad table scans. The importer is therefore hardened to use explicit `CAST(name AS TEXT)` for modern normalized deck/notetype/field/template reads rather than relying on the schema's custom collation.

### Changes
- `ApkgImporter`: modern-schema reads use explicit binary/text casts; modern-model parsing is contained so a schema-specific model read cannot crash the entire worker; generic field/template fallback prevents blank-card generation when metadata is incomplete.
- `ApkgImportWorker`: deterministic `Exception` failures now finish as `Result.failure` instead of infinite retry; durable checkpoint remains available for explicit resume/discard. `IOException` remains retryable.
- `FlashcardActivity`: failed imports never auto-resume a repeatedly failing package; the checkpoint is left for explicit user action.

## Duplicate-process / previous-UI audit
- One `ApkgImporter` implementation found.
- One `ApkgImportWorker` implementation found.
- APKG work is submitted through one WorkManager unique-work name: `rovex_flashcard_import` with `ExistingWorkPolicy.KEEP`.
- No second APKG import pathway was found in the current Java/Kotlin source.
- `FlashcardActivity` is the sole flashcard library Activity; `FlashcardStudyActivity` is the study screen, not a duplicate library UI.
- `HtmlImportActivity` is a separate HTML-QBank importer, not an APKG importer.
- MainActivity contains one primary `setContentView` call; no second legacy root is overlaid there.

## Static checks
- XML parse errors: 0
- Duplicate IDs within individual layout files: 0
- Tap sound asset SHA verified: PASS
- APKG ZIP structure: PASS
- Modern APKG Zstandard decompression: PASS
- Modern APKG SQLite opened on host: PASS
- Search session unit tests added: `SearchSessionSetTest.kt`

## Build
NOT VERIFIED / BLOCKED locally.
Exact attempted command:
`./gradlew :app:testDebugUnitTest --no-daemon --stacktrace`

Raw environment failure:
`curl: (6) Could not resolve host: downloads.gradle.org`

No claim of Android compilation green is made.
