# Rovex v8.3.381 — Specific Defect Repair Audit

## Build identity
- versionName: 8.3.381
- versionCode: 473
- applicationId: com.localqbank.library
- baseline: uploaded v8.3.380 source archive

## DEFECT_1 — Frankenstein search + stale chat transcript
STATUS: FIXED (source-level; Android build/runtime not yet verified)

Root cause: Frankenstein's local-search command path still delegated to the cognitive router before a direct authoritative retrieval result was accepted, so a downstream ranking/ontology failure could replace an existing local hit with the generic no-result response; persisted chat history also had no visible clear action.

Changed files:
- app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt
- app/src/main/java/com/localqbank/library/RenActivity.kt

Verification:
- tools/verify_defect_regressions.sh
- temporary Kotlin harness for LocalQBankSearchService
- tools/ruthless_audit.sh

## DEFECT_2 — Main Search cannot find questions/QBank/sub-QBank
STATUS: FIXED (source-level; Android build/runtime not yet verified)

Root cause: question and hierarchy retrieval were separate direct QBankDb paths; hierarchy search had no clinical-variant rescue and question search used a separately-instantiated shared-search service.

Changed files:
- app/src/main/java/com/localqbank/library/LocalQBankSearchService.kt
- app/src/main/java/com/localqbank/library/SearchActivity.kt

Verification:
- temporary Kotlin harness proves literal/clinical-alias question retrieval and alias hierarchy retrieval
- tools/verify_defect_regressions.sh
- XML parse + per-layout duplicate-ID audit
- tools/ruthless_audit.sh

## DEFECT_3 — Continue opens the recent QBank instead of last active question
STATUS: FIXED (source-level; Android build/runtime not yet verified)

Root cause: QuizActivity wrote the current QBank cursor to the global StudySessionStore on Activity open and again during onPause, so merely opening/browsing another QBank overwrote the last explicit study cursor.

Changed files:
- app/src/main/java/com/localqbank/library/QuizActivity.kt
- app/src/main/java/com/localqbank/library/QuizSessionLifecycleController.kt

Verification:
- tools/verify_defect_regressions.sh confirms open/onPause no longer write the global session cursor and accepted-answer/navigation paths retain explicit cursor writes.

## Static verification
- tools/ruthless_audit.sh: PASS
- XML parse: 0 errors
- duplicate IDs within individual layouts: 0
- runBlocking: 0
- GlobalScope: 0
- Thread.sleep: 0

## Architecture regression gate
- tools/architecture_regression_audit.py: FAILED on pre-existing baseline debt unrelated to these repairs.
- Reported items: FlashcardStudyActivity size, NotesActivity size/direct persistence, RenActivity size/direct shared prefs, SearchActivity direct QBankDb construction baseline count, increased singleton/object count, and missing MainActivity AppContainer boundary.
- These were not changed in this defect repair and the audit was not weakened.

## Build verification
Command:
./gradlew clean test assembleRelease --offline

Result: BLOCKED by environment before Gradle execution. Gradle 9.3.1 could not be downloaded because downloads.gradle.org DNS resolution failed.

Raw failure:
curl: (6) Could not resolve host: downloads.gradle.org

Therefore Android compilation, APK packaging, CI signing, and device runtime are NOT claimed verified.
