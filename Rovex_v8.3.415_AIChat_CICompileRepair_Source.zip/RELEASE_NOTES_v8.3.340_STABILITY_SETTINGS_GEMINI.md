# Rovex v8.3.340 — Stability, Settings, Permissions & Gemini

- Audited and removed empty `catch (_: Exception) {}` blocks in the targeted production paths; recoverable UI failures now use the shared `RovexUndoSnackbar` action surface and non-user-recoverable failures emit production breadcrumbs/non-fatal telemetry.
- Added explicit manifest permission documentation for INTERNET, WAKE_LOCK, foreground-service permissions, notifications, and calendar access. READ_CALENDAR remains because Daily Study Hub actively reads today's calendar events when the user requests it.
- Added an explicit global **Allow cloud AI fallback** control. It defaults OFF; deterministic/local Ben remains authoritative.
- Added **Google Gemini** as an optional user-owned cloud provider. API keys are stored encrypted with Android Keystore and are never bundled or logged. Default model is `gemini-3.8-flash`; the REST integration uses Google's `x-goog-api-key` header and `generateContent` contract.
- Added a Settings hub entry for Cloud AI & Gemini and Study & Notifications.
- Added a persistent Study & Notifications toggle and cancellation/rescheduling of the existing streak reminder WorkManager job.
- Extended the existing StartupHealthStore to record cold-launch → interactive time. Debug builds warn when real initialization exceeds 1200 ms after subtracting the intentional splash duration; release behavior is unchanged.
- Preserved offline-first behavior: no cloud call is possible unless the user explicitly enables cloud fallback and a provider is enabled with a key.

Build note: Android/Gradle compilation remains a CI gate in this environment; do not interpret local source audits as a green Android build.
