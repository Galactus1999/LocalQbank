# Rovex v8.3.318 — Native Rich Chat Preservation

- Chat rendering no longer treats ordinary prose/search output as a table.
- Markdown tables are rendered only when the AI actually emits a valid Markdown table.
- Explicit AI rich blocks are preserved through the shared renderer: `mermaid`, `chart`, `tree`, and `slides`/`presentation`.
- Markdown images remain supported.
- Added dependency-free native SVG rendering for explicit flowcharts, pie charts, bar/line charts.
- Presentation blocks render as horizontally scrollable slide cards; tables retain their own horizontal scrolling.
- Cloud AI prompts now explicitly tell the model to use native Markdown by default and emit rich blocks only when they are part of the answer.
- JavaScript remains disabled in the chat WebView; no external chart/diagram runtime was added. Android guidance recommends keeping JavaScript disabled when it is not required.
- Version: 8.3.318 / versionCode 411.
