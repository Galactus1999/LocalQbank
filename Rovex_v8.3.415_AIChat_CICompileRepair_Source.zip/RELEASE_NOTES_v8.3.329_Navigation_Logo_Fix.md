# Rovex v8.3.329 — Navigation shell positioning + exact launcher logo

- Fixed the persistent five-destination bottom navigation being vertically displaced by the existing edge-to-edge inset owner.
- Navigation now observes insets on itself instead of replacing the central content inset listener.
- The bar sits at the physical bottom, above the actual system navigation area, using live WindowInsets rather than hardcoded system-bar dimensions.
- The underlying screen root receives only the required bottom protection so the bar no longer overlaps scrollable content.
- Fixed `RovexAdaptiveUi` incorrectly resizing `rovexPersistentBottomNavigation` through the legacy 42dp footer rule.
- Replaced `drawable-nodpi/rovex_app_logo.jpg` byte-for-byte with the newly supplied launcher logo. No crop, recolor, resize, vectorization, or recompression was performed.
- Manifest continues to use `@drawable/rovex_app_logo` for both `android:icon` and `android:roundIcon`.
