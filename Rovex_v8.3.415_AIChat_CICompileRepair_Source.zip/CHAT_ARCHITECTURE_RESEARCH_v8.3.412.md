# Rovex AI Chat Architecture Research — v8.3.412

## Evidence from current Rovex source

The screenshot defect has a direct root cause before CommonMark ever sees the response:
`BenResponsePolicy.normalize()` passed AI Markdown through `BoundedTextPolicy.normalize()`. That policy intentionally collapses whitespace/newlines for short query-like text. For a Markdown document this destroys blank lines, GFM table row boundaries, fenced Mermaid boundaries, list indentation, blockquotes and code fences.

This explains both Frankenstein and BEN + AI showing the same corruption: both surfaces call `BenResponsePolicy.normalize()` before `rovexMarkdownBody()`.

## External research

- Google AI's current Interactions API documents streaming as named incremental events (`step.start`, `step.delta`, `step.stop`) and recommends the Interactions primitive for multi-turn/agentic applications. See https://ai.google.dev/gemini-api/docs/interactions-overview and https://ai.google.dev/gemini-api/docs/streaming.
- Android's current A2UI renderer uses schema validation, incremental state updates, defensive error boundaries, and native Compose components rather than executing arbitrary agent-generated code. This is a useful architectural direction for future structured AI surfaces, not a reason to immediately migrate the whole Rovex app.
- Android UI architecture recommends unidirectional data flow and a single source of truth for UI state. RecyclerView remains the native virtualization primitive for dynamic message lists.
- FluidMarkdown is specifically designed for mobile LLM streaming Markdown and exposes structured/progressive rendering. It is a useful benchmark for Rovex, but a dependency should not be introduced until its Android version/license/performance are verified against the app's offline and stability constraints.
- Markwon renders CommonMark directly to Android-native Spannables without WebView and supports tables, images, HTML and syntax highlighting. It is a viable future native-rendering benchmark, but the current Rovex custom rich renderer has more specialized deterministic diagram behavior and should not be replaced blindly.
- Current open-source AI chat clients commonly use a message-list architecture, DiffUtil/Compose state, streaming updates, retry/stop controls, smart scrolling, session persistence and per-message actions.

## Target architecture for Rovex

1. **Response contract** — preserve Markdown whitespace at the trust boundary; never use query normalization for model output.
2. **Safety layer** — remove scripts/style/event handlers and dangerous HTML before rendering.
3. **Block recovery** — recover provider-corrupted tables/Mermaid only when structural evidence is high confidence.
4. **Standards parser** — CommonMark/GFM owns normal Markdown parsing.
5. **Structured rich blocks** — tables, Mermaid/diagrams, code, images and future UI surfaces are explicit typed blocks.
6. **Message state** — each chat turn is independently persisted and rendered; avoid reconstructing the entire transcript for every new token/turn.
7. **Incremental streaming** — stable blocks are not re-parsed when only the tail of a streamed response changes.
8. **Smart scrolling** — auto-scroll only when the user is already at/near the bottom; never steal the reader's position.
9. **Error boundaries** — a malformed rich block becomes a readable fallback block; it never causes the Activity to finish or discard a valid answer.
10. **Future A2UI-style structured surfaces** — only after schema validation, capability negotiation and a safe local component catalog are proven.

## v8.3.412 implementation scope

- Fixed the proven whitespace-destruction root cause.
- Added a regression test that locks Markdown tables and fenced Mermaid across the response-policy boundary.
- Added high-confidence recovery for an inline/unfenced Mermaid marker when a provider has collapsed the block boundary.
- Began the chat rendering transition by changing Frankenstein's transcript to a persistent WebView document with append-only message insertion instead of reloading the entire transcript for every turn.
- Kept JavaScript limited to a fixed local renderer shell; AI content is inserted only as sanitized HTML, with file/content access disabled and HTTPS-only external navigation.
- No arbitrary AI JavaScript or remote renderer libraries are executed.

## Deferred deliberately

A full Compose/A2UI migration, third-party streaming Markdown dependency, or multi-WebView/RecyclerView rewrite is not being mixed into the same repair until the v8.3.412 root fix is CI/device verified. This preserves causal isolation and prevents a renderer rewrite from masking the actual defect.
