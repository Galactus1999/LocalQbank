# Rovex v8.3.324 — Rich Markdown Table Rendering + Study Streak Foundation

## Fixes
- Hardened `RovexMarkdown` table-boundary recovery for AI output where Markdown table separators are collapsed into the preceding prose/header line.
- Preserved strict structural detection so ordinary prose/search results are not promoted into tables.
- Kept genuine tables as horizontally scrollable HTML tables while preserving authored mermaid/chart/tree/slides/image blocks.

## Study engagement foundation
- Added durable `StreakManager` registered through `AppManagers`.
- Added `quiz_completed` study events for normal practice/study answers.
- Added streak state to `qbank.db` with current streak, longest streak, total study days, last study day and reminder state.
- Added timezone-aware streak policy with same-day de-duplication and gap reset.
- Added WorkManager-based daily streak reminder using notification permission only after a contextual first study interaction on Android 13+.
- Added unit-test coverage for first day, consecutive day, same-day duplicate, and gap reset policy.

## Deliberately not included in this batch
- Home-screen widget
- Weak-topic analytics dashboard
- APKG/Anki export
- Exam countdown/revision planner/calendar write integration
- On-device voice Q&A

Those are kept as separate auditable batches so database, widget, scheduling, calendar and audio changes do not get mixed into the rich-rendering repair.
