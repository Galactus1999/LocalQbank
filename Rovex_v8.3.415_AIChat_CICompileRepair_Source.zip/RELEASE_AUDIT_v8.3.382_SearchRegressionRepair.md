# v8.3.382 Search Regression Repair

## Source baseline
- Previous submitted baseline: v8.3.381a / versionCode 473
- Working comparison source: Rovex_Source.zip / versionName 8.3.335, versionCode 428
- Repair baseline SHA-256: d3e2d6d41f49cfadb5d6f55521d648ad58d29e935ab9c525b45a6e3da128296a

## Root cause
The newer search architecture routed both Main Search and Frankenstein's primary deterministic retrieval through LocalQBankSearchService, whereas the older working source used QBankDb directly. The repair restores the proven direct QBankDb retrieval path and retains bounded clinical alias rescue.

## Changed files
- app/src/main/java/com/localqbank/library/SearchActivity.kt
- app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt
- app/src/main/java/com/localqbank/library/RenCognitiveEngine.kt
- app/build.gradle.kts
- tools/verify_search_regression_repair.sh

## Verification
Focused source regression script: PASS.
Ruthless static audit: PASS.
XML parse/duplicate-ID audit: PASS.
Architecture regression audit: FAIL due pre-existing/baseline architectural debt plus SearchActivity/other size and boundary counts; not hidden or weakened.
Android Gradle build: BLOCKED before compilation because downloads.gradle.org DNS resolution fails in this environment.

## Important boundary
Search behavior is source-level repaired against the known working v8.3.335 retrieval path. Android compile/APK/device runtime remain unverified until CI can execute.
