# Rovex v8.3.379 — Frankenstein/Ben Search Root Fix 2 + Shared Clinical Retrieval

## Scope
This release is based directly on the verified v8.3.378 source and addresses the remaining search-path gap found during source/CI/APK forensic review. It does **not** claim Android/CI green until GitHub builds this exact archive.

- applicationId: `com.localqbank.library`
- versionName: `8.3.379`
- versionCode: `471`
- archive SHA-256 is recorded with the handoff file and must be verified after download.

## Root causes / incomplete paths found

### 1. Bare topic queries were entering the neural-answer path
`FrankensteinSupportEngine.isLocalSearchCommand()` previously recognized explicit search phrases (`find`, `search`, `show questions`, etc.) but not a bare topic such as `cervical cancer`. Such a prompt could therefore enter the optional neural pipeline instead of first using the authoritative local-QBank retrieval path.

**Fix:** short, non-interrogative topic-only prompts are now classified as local retrieval commands. Explicit search phrases remain supported. This prevents a topic query from being answered as a generic neural question before local QBank recall has been attempted.

### 2. Neural lexical retrieval was a second, weaker search implementation
`BenGroundedNeuralPipeline` previously called `QBankDb.search(clean, 12)` for the literal query. Even after deterministic Ren received clinical alias expansion, the neural evidence lane could still have zero candidates for terminology-equivalent wording.

**Fix:** the neural lexical lane now uses the same bounded `ClinicalQueryExpansion` aliases plus shared clinical understanding expansions, unions/deduplicates the QBank hits, and then allows EmbeddingGemma to rerank only those locally retrieved candidates.

### 3. Clinical aliases were not propagated through the shared understanding contract
`ClinicalKnowledgeLayer.understand()` did not expose `ClinicalQueryExpansion` aliases. `RenCognitiveEngine` had its own alias rescue, but other Ben/Frankenstein consumers could still receive only the literal phrase.

**Fix:** bounded clinical aliases are now inserted into `Understanding.expansions`. This makes the same terminology vocabulary available to deterministic retrieval, Ben retrieval/planning, and the neural evidence lane without creating another search owner.

### 4. Unfenced Mermaid recovery was incomplete for style/control fragments
The renderer already recovered many unfenced Mermaid blocks, but `style`/`linkStyle`-heavy fragments could fail the structural test and remain visible as raw source.

**Fix:** `style`, `linkStyle`, `class`, arrows, and related Mermaid control syntax now count as structural during recovery. A regression test covers a style/control fragment and asserts that raw `style ...` lines are not emitted.

## Preserved architecture
- `AppManagers.renCognitive` remains the authoritative deterministic Frankenstein/Ren retrieval owner.
- `QBankDb` remains the authoritative local corpus/index.
- EmbeddingGemma remains a reranker/evidence accelerator, not the source of truth.
- Gemma 3 270M remains optional and is never required for local QBank search.
- Neural inference remains behind the isolated inference process/resource-governor boundary.
- No parallel visible Frankenstein Activity or replacement search owner was introduced.

## Static verification performed
- XML/layout static audit: PASS
- `tools/ruthless_audit.sh`: PASS
- `tools/audit_frankenstein_policy.py`: PASS
- `tools/assert_phase2_stability.py`: PASS
- `tools/audit_coroutine_cancellation.py`: PASS
- `runBlocking` in main source: 0
- `GlobalScope` in main source: 0
- `Thread.sleep` in main source: 0
- duplicate IDs within individual XML layouts: 0
- applicationId preserved: PASS
- versionCode monotonic: 470 -> 471
- zstd Android AAR invariant preserved
- isolated inference-process invariant preserved

## Architecture regression audit
`tools/architecture_regression_audit.py` reports the same pre-existing baseline failures seen on v8.3.378, plus the expected +1 singleton/object count caused by the new `ClinicalQueryExpansion` object; this count is architectural tooling noise rather than a duplicate search owner. These failures are not introduced by the search changes themselves and are not being misreported as a green architecture audit.

## Android/CI verification status
Local Gradle execution remains blocked because the environment cannot resolve `downloads.gradle.org` for the configured Gradle distribution. Therefore this release is **not** claimed Android-compiled or CI-green.

Required next verification:
1. Put this exact ZIP in the GitHub repository root where the existing source-acquisition workflow can select it.
2. Confirm the workflow log selects `Rovex_v8.3.379_Frankenstein_Ben_Search_RootFix2_Source.zip`.
3. Confirm the internal version is `8.3.379` / `471`.
4. Build the APK and inspect its DEX/resources to confirm the new topic-routing, shared clinical expansion, neural alias retrieval, and Mermaid changes are actually present.
5. Install that exact APK on the target device and reproduce `cervical cancer` in Frankenstein.
6. Confirm matching local questions open through `Open matching questions` and the generic no-result text is not emitted when authoritative/alias retrieval has hits.
