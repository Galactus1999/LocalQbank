# Rovex v8.3.352 — Smoothness / Q&A / Delete Repair

Version code: 445

Repairs:
- QBank deletion moved off the Home UI thread and hardened with explicit child cleanup, FTS tolerance, transaction rollback, and safe user feedback.
- Continue/resume final teardown no longer overwrites the durable answer→next-question cursor.
- Live Q&A explanations no longer enable TextView selection, preventing touch/scroll gesture competition.
- Frankenstein and Ben + AI chat chrome no longer auto-hides during WebView scrolling.
- Supplied short click sound is triggered when opening/using the Ben + AI Q&A surface and its action controls, subject to the existing sound-feedback setting.
- Collapsed provider Markdown tables are recovered row-by-row, including repeated pipe-separated rows, while ordinary pipe prose remains untouched.
- Test-list question totals use actual question-row counts from the progress summary instead of stale test metadata when available.
- Test-list now has an explicit empty/error state instead of a completely blank screen when a QBank has no readable test records.

Build gate: GitHub Actions remains authoritative. Local full Gradle compilation is not claimed if the environment cannot resolve Gradle.
