# Rovex v8.3.353 — CI compile fix
VersionCode: 446

## CI defect fixed
The v8.3.352 CI run selected the correct v8.3.352 source but failed during `:app:compileDebugKotlin` in `QBankDb.kt`:
- `db.sourceNameForId` unresolved
- `db.getProgressMeta` unresolved
- `db.putProgressMeta` unresolved

These calls were made from inside `QBankDb` but were incorrectly qualified with the SQLite `db` object. They now call the owning `QBankDb` methods directly.

No feature behavior was changed in this repair.
