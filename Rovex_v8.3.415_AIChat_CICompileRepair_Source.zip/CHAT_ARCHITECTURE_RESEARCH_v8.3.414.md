# Rovex AI Chat Architecture Research — v8.3.414

## Findings
Current AI chat systems are converging on a few important primitives:

1. **Streaming deltas**: the UI receives incremental response data instead of waiting for one complete response.
2. **Stable message identity**: the active assistant message is updated in place while completed messages remain stable.
3. **Block-aware rendering**: Markdown, tables, diagrams, images and other rich blocks are represented independently rather than being treated as one opaque HTML string.
4. **Defensive structured rendering**: malformed or unknown AI payloads must fail locally without taking down the surrounding UI.
5. **Single source of truth**: conversation state and UI state should be separate from the transport/provider implementation.
6. **Security boundaries**: AI content must not become an application JavaScript bridge or unrestricted WebView document.

Google's current Gemini streaming documentation describes a step/delta event model and explicit completion/error events. Android's current A2UI guidance similarly emphasizes incremental state updates, schema validation, unknown-component handling and defensive error boundaries.

## Rovex implementation chosen for this release

The immediate problem was not that Rovex lacked a sophisticated AI model. The renderer was being handed structurally damaged Markdown before the renderer ran.

Therefore v8.3.414 first repairs the data contract:

`provider -> response policy -> Markdown/rich-block parser -> persistent chat document -> incremental message node`

Both affected surfaces now use the same fixed document controller for incremental DOM updates. This avoids a full transcript `loadDataWithBaseURL()` on every streamed update.

## Why not perform a giant Compose rewrite here?

A complete Compose/A2UI-style chat renderer can eventually provide stronger block identity, virtualization, message actions and state handling. It is intentionally not mixed into this repair because it would change too many variables at once and could hide the actual root cause.

The correct migration path is:

1. prove v8.3.414 rendering and streaming on CI/device;
2. keep the current deterministic Markdown/rich-block parser as the compatibility renderer;
3. introduce an explicit message/block model;
4. migrate stable blocks to a native RecyclerView/LazyColumn surface with DiffUtil/state-driven updates;
5. retain the same security and parser boundaries;
6. add structured AI response schemas only after the current renderer is proven stable.

## Security posture

The chat WebViews do not expose `addJavascriptInterface()`. File access and content access are disabled, universal/file URL access is explicitly disabled, mixed content is disallowed, and navigation is controlled. The fixed script exists only to mutate the application-owned local document; AI text is not treated as executable script.

## Sources consulted

- Android WebView security guidance.
- Android in-app WebView content guidance.
- Android A2UI render-surface guidance.
- Google Gemini Interactions API documentation.
- Google Gemini streaming documentation.

See the project release notes for the exact verification state.


## v8.3.414 forensic completion

The second source pass found and corrected a sanitizer replacement defect in the previous candidate: the narrowed CSS regex had no capture group, while its replacement attempted to read `groupValues[1]`. The replacement now removes only the matched CSS rule. Regression coverage includes CSS-like text, unsafe attributes, and incomplete streaming Mermaid fences.

Streaming Markdown normalization/rendering is now performed on a cancellable background render lane. Only the newest pending snapshot is applied to the WebView. The shared chat document also uses smart-scroll retention and bounded DOM pruning.


The streaming gateway was also audited for provider fallback. A provider can emit partial chunks and then fail; without a boundary, the next provider's stream would be visually concatenated with the failed provider's partial answer. v8.3.414 adds an internal fallback control marker and resets the active stream buffer before the next provider begins.
