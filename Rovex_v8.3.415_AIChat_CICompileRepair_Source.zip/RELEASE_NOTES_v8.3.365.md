# Rovex v8.3.365 — Deep Forensic Architecture Repair

VersionCode 458.

This release is a source-level stability/performance repair based on a fresh forensic scan of v8.3.364. It removes remaining foreground progress-store escape hatches, makes screen database handles lazy, hardens flashcard WebView content, removes synchronous SharedPreferences commits from lifecycle callbacks, fixes redundant Performance Lab reads, moves legacy collection generation off the UI thread, and debounces Knowledge Vault artifact scans.

Build status: NOT CI-VERIFIED. Local Gradle 9.3.1 download is blocked by DNS in the current environment.

See `DEEP_FORENSIC_AUDIT_v8.3.365.md`.
