# v8.3.403 — CommonMark forensic compile repair

- Fixed the v8.3.402 CI compile blocker: an undefined `htmlTableTokens` reference in `RovexMarkdown.kt`.
- Added the missing opaque HTML-table tokenization/restoration path so supported imported HTML tables are not escaped before CommonMark parsing.
- Activated the existing high-confidence inline/block-boundary normalizers before CommonMark parsing.
- Bumped versionCode to 495 / versionName 8.3.403.
- No Ben, IPC, EmbeddingGemma, APKG, flashcard, QBank, SRS, or StudyCore changes.

Verification status: source/static verification performed; full Gradle/CI verification remains required.
