# Rovex v8.3.360 — Deep New/Legacy UI Coexistence + QBank/Search Stability Audit

## Baseline
- Starting source: v8.3.359 / versionCode 452.
- Target: v8.3.360 / versionCode 453.
- Package/applicationId preserved: `com.localqbank.library`.
- The legacy UI is intentionally retained. It is not deleted; the new UI is layered over it.

## Root architectural finding
`MainActivity` still inflates the legacy `activity_main.xml`, then `RovexHomeRevolution.apply()` detaches the legacy children into a hidden `legacy` container and creates the visible modern dashboard.

This is a valid compatibility strategy only if the hidden legacy tree is treated as inert. Prior code still allowed the visible modern UI to route user actions through hidden legacy views via `findViewById(...).performClick()`, while `MainActivity` continued to run the legacy ViewModel/data-refresh pipeline.

That created three classes of risk:
1. duplicated UI/controller ownership;
2. hidden legacy database/background work competing with the modern UI;
3. old/new event-routing dependencies that can break when the legacy tree is hidden/reparented.

## Concrete duplication/coupling findings and repairs

### 1. Modern Home Search -> hidden legacy `homeSearchCard`
Old behavior:
- modern search card called `findViewById(R.id.homeSearchCard)?.performClick()`;
- the hidden legacy view then opened `SearchActivity`.

Repair:
- modern search now launches `SearchActivity` directly.
- legacy `homeSearchCard` remains in the hidden compatibility tree but is no longer a controller for the modern search UI.

### 2. Modern Home Frankenstein -> hidden legacy `renCard`
Old behavior:
- modern Frankenstein card called `findViewById(R.id.renCard)?.performClick()`.

Repair:
- modern Frankenstein card now launches `RenActivity` directly with safe single-top/reorder flags.

### 3. Modern Performance Lab -> hidden legacy `performanceLabCard`
Old behavior:
- modern card delegated through the hidden legacy card click listener.

Repair:
- modern card now calls a dedicated `MainActivity.openPerformanceLabFromModernHome()` bridge that obtains the authoritative PerformanceManager data and opens the existing analytics dialog directly.
- No hidden legacy view is used as an event bus.

### 4. Daily Study Hub -> hidden legacy Flashcard card
Old behavior:
- modern Home passed the hidden legacy `flashcardCard` to `RovexDailyStudyHub`; the Mix Revision action could call `flashcards.performClick()`.

Repair:
- `RovexDailyStudyHub` now supports an explicit `flashcardsAction` callback.
- Modern Home supplies a direct FlashcardActivity action.
- The legacy View reference remains supported for compatibility callers, but modern Home no longer depends on it.

### 5. MainActivity legacy ViewModel/data pipeline
Old behavior:
- modern Home was still starting/collecting `MainViewModel.uiState` and calling `refreshSourcesFast()` and `refresh()` on startup/resume.
- `publishQBankSources()` could therefore continue operating on the hidden legacy QBank RecyclerView.

Repair:
- when `RovexHomeRevolution` is active, MainActivity no longer starts the legacy MainViewModel UI collector or legacy QBank source-refresh pipeline.
- AppState refresh events update the modern Home directly through `RovexHomeRevolution.refreshData()`.
- Legacy MainActivity data/UI methods remain in source for compatibility but are no longer the active modern-home controller path.

### 6. QBank navigation ownership
Previous state had multiple QBank destinations:
- modern Home QBank card -> `RovexSectionDashboardActivity`;
- bottom navigation QBank -> `MainQBankLibraryActivity`;
- legacy MainActivity QBank -> `MainQBankLibraryActivity`.

Repair:
- primary five-tab QBank navigation now targets `RovexSectionDashboardActivity` with `section=qbank`, matching the modern subject-wise QBank architecture.
- `MainQBankLibraryActivity` remains available as the explicit imported-QBank library/browse surface from Home and legacy-compatible paths.

### 7. Swipe destination mapping
The modern Home swipe helper previously mapped index 3 to Study Tools even though the persistent five-tab shell defines index 3 as Ben and index 4 as Tools.

Repair:
- navigation helper now maps all five destinations consistently: Home, QBank, Flashcards, Ben, Tools.

## Search/Frankenstein resource containment
v8.3.359 already moved FTS rebuild work out of the interactive search path. v8.3.360 adds a second containment layer.

### Generic search
- Added cached `QBankDb.isSearchIndexReady()` health signal.
- If FTS is incomplete/rebuilding, generic search still uses the normalized-table fallback but does not pretend the FTS path is healthy.

### Frankenstein search
Previously, when FTS was incomplete, one Frankenstein request could execute the primary fallback scan plus multiple semantic expansion scans. With a large QBank this could multiply full-corpus SQLite work.

Repair:
- when FTS is ready, semantic expansion remains available;
- when FTS is not ready, only the primary fallback retrieval is performed;
- semantic expansion is deferred until the index becomes healthy.

### Visual/image search
- When FTS is unavailable, visual search fallback term fan-out is capped to three terms instead of issuing the complete concept-term expansion set.

This preserves deterministic offline behavior while bounding CPU/I/O during index repair.

## Static audits performed
- XML parsing: 0 errors.
- Duplicate `@+id` definitions within individual layout files: 0.
- Explicit generic `findViewById<T>()` occurrences scanned: 71.
- No remaining modern-Home `homeSearchCard.performClick()` bridge.
- No remaining modern-Home `renCard.performClick()` bridge.
- Modern Daily Study Hub no longer uses the hidden Flashcard card as its active Mix Revision route.
- Kotlin delimiter sanity checks on all modified Kotlin files: balanced braces/parentheses.

## Verification limitation
Full Android compilation could not be executed locally because the Gradle wrapper attempted to download Gradle 9.3.1 and this environment cannot resolve `downloads.gradle.org` (`curl: Could not resolve host`).

Therefore v8.3.360 is **not CI-green until GitHub Actions completes successfully**.

## Device regression matrix required after CI
1. Launch Home.
2. Tap Home Search directly; verify SearchActivity opens and returns results.
3. Type multiple queries rapidly; verify stale results do not replace the newest query.
4. Open Frankenstein directly from modern Home; run a local search such as `cervical cancer`.
5. Verify matching-question action appears and opens the correct Quiz collection.
6. Tap bottom-nav QBank; verify the subject-wise QBank dashboard opens.
7. Open Browse QBanks from Home; verify MainQBankLibraryActivity renders the imported list.
8. Open a QBank/test and return.
9. Repeat Search and Frankenstein after QBank navigation.
10. Repeat with an incomplete/stale FTS index if available to confirm bounded fallback behavior.
11. Exercise theme change and return to Home; verify modern UI remains the only active visible controller.
12. Inspect logcat for `FATAL EXCEPTION`, `ANR`, `ClassCastException`, SQLite errors, and unexpected repeated QBank/search worker activity.
