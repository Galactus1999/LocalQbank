# Rovex v8.3.384 — Search / Frankenstein / Sub-QBank Root-Fix Audit

## Root defects fixed

1. Frankenstein explicit search was still routed through the cognitive/ranking stack. It now has a deterministic first-class local retrieval lane using LocalQBankSearchService before ontology/ranking/neural processing.
2. Main SearchActivity bypassed LocalQBankSearchService and therefore did not receive the shared clinical alias/retrieval contract. It now consumes the shared question + hierarchy retrieval service.
3. QBank/sub-QBank hierarchy search used AND semantics across every query token. This is incorrect for discovery and caused legitimate sections to disappear. Hierarchy search now uses OR recall with parameterized relevance scoring.
4. Quiz subsection launch mutated progress before validating that the target test actually contained questions. Stale/empty subsection rows could therefore enter the quiz launch path. Validation now occurs first and empty targets fail as a controlled Result error.
5. Search launch now validates both test existence and question count before starting QuizActivity.
6. Frankenstein already has a WebView rich Markdown renderer with table support. The repaired search route deliberately does not bypass this renderer; generated rich answers continue through rovexMarkdownBody. Research confirms Markwon 4.6.2 as a mature alternative with explicit table support, but no new dependency was introduced because Rovex already has a functioning WebView/table pipeline and adding a renderer during a crash/search repair would increase regression surface.

## Research

- SQLite FTS4 supports prefix and phrase queries; Android exposes configurable FTS tokenizers and prefix indexes.
- SQLite/Android documentation requires cursors to be closed after iteration; QBankDb already uses `use` for cursors.
- Markwon 4.6.2 provides CommonMark/GFM table rendering and a table-aware movement extension. It was evaluated but not imported into this repair.
- Hugging Face Sentence Transformers documents dense embeddings for semantic search/retrieval. EmbeddingGemma can be used later as a bounded semantic recall lane, but deterministic SQLite recall remains authoritative for stability.

## Verification

- tools/verify_search_qbank_regressions.sh: PASS
- tools/ruthless_audit.sh: PASS
- tools/audit_coroutine_cancellation.py: PASS
- tools/audit_architecture.py: PASS with existing large-file warnings
- Android Gradle build: environment-blocked if Gradle distribution is not cached; do not claim APK green without CI.
