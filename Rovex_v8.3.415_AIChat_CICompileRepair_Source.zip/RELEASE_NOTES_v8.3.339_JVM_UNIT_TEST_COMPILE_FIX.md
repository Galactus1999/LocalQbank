# Rovex v8.3.339 — JVM Unit-Test Task Compile Fix

## Build-log driven corrections
- Fixed `ProgressStore.setAnswer()` resume metadata writes to call `QBankDb.putProgressMeta()` through the existing `db` receiver.
- Fixed Home refresh lookup to search the dashboard root for the tagged Home shell instead of calling `findViewWithTag()` on `MainActivity`.
- Fixed malformed Kotlin string escaping in the Markdown table `colspan` HTML builder.

## Validation intent
The failing GitHub Actions step named **Run JVM unit tests** was not failing because a JVM test assertion failed. `:app:testDebugUnitTest` first compiled the Debug main source set, and `:app:compileDebugKotlin` failed before test execution.

This release therefore treats the reported compiler errors as source defects and does not weaken or skip JVM unit-test execution.
