# v8.3.297 repair

Retired AMOLED Dark; added Obsidian Night, touch-safe Frankenstein table scrolling, adaptive table sizing and responsive Markdown presentation.
