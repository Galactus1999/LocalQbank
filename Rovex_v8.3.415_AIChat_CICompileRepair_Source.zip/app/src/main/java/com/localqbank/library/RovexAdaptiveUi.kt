package com.localqbank.library
import android.app.Activity
import android.content.res.Configuration
import android.view.View
import android.view.ViewGroup
object RovexAdaptiveUi{
 fun apply(a:Activity){
  if(a is RenActivity||a.resources.configuration.orientation!=Configuration.ORIENTATION_LANDSCAPE)return
  val r=a.window.decorView.findViewById<ViewGroup>(android.R.id.content)?:return
  val d=a.resources.displayMetrics.density
  fun walk(v:View){
   val n=if(v.id!=View.NO_ID)runCatching{a.resources.getResourceEntryName(v.id)}.getOrDefault("") else ""
   // The persistent five-tab shell owns its compact 50dp height. Never let the generic
   // compact-footer rule resize it or it will become vertically misaligned and overlap content.
   if(n.equals("rovexPersistentBottomNavigation",true)) return@walk
   if(n.contains("rovexBottomNav",true)||n.contains("bottomNav",true)||n.contains("footer",true))v.layoutParams=v.layoutParams.apply{height=(42*d).toInt()}
   if(v is ViewGroup)for(i in 0 until v.childCount)walk(v.getChildAt(i))
  };walk(r)
 }
}