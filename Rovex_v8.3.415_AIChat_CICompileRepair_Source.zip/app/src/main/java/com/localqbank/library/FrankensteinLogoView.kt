package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.min

/** Lightweight original Frankenstein box-logo drawing; no external image dependency. */
class FrankensteinLogoView(context: Context) : View(context) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas){
        val w=width.toFloat(); val h=height.toFloat(); val r=min(w,h)*.36f; val cx=w*.5f; val cy=h*.53f
        p.style=Paint.Style.FILL; p.color=Color.rgb(18,25,18); c.drawRoundRect(cx-r*1.05f,cy-r*1.18f,cx+r*1.05f,cy+r*1.22f,r*.30f,r*.30f,p)
        p.color=Color.rgb(108,180,72); c.drawRoundRect(cx-r*.90f,cy-r*1.02f,cx+r*.90f,cy+r*1.05f,r*.34f,r*.34f,p)
        // Hair and brow.
        p.color=Color.rgb(10,13,11); val hair=Path();hair.moveTo(cx-r*.94f,cy-r*.55f);for(i in 0..10){val x=cx-r*.88f+i*(r*1.76f/10f);val y=cy-r*(.95f+if(i%2==0).08f else 0f);hair.lineTo(x,y)};hair.lineTo(cx+r*.94f,cy-r*.35f);hair.close();c.drawPath(hair,p)
        // Eyes.
        p.color=Color.rgb(5,12,6);c.drawOval(cx-r*.58f,cy-r*.23f,cx-r*.10f,cy-r*.03f,p);c.drawOval(cx+r*.10f,cy-r*.23f,cx+r*.58f,cy-r*.03f,p)
        p.color=Color.rgb(185,245,126);c.drawCircle(cx-r*.35f,cy-r*.13f,r*.07f,p);c.drawCircle(cx+r*.35f,cy-r*.13f,r*.07f,p)
        // Nose, mouth and chin shading.
        p.color=Color.rgb(67,122,49);c.drawOval(cx-r*.16f,cy-r*.05f,cx+r*.16f,cy+r*.37f,p)
        p.style=Paint.Style.STROKE;p.strokeWidth=r*.055f;p.strokeCap=Paint.Cap.ROUND;p.color=Color.rgb(12,23,12);c.drawLine(cx-r*.42f,cy+r*.48f,cx+r*.42f,cy+r*.48f,p)
        // Forehead stitches.
        p.strokeWidth=r*.035f;p.color=Color.rgb(205,230,180);c.drawLine(cx-r*.55f,cy-r*.70f,cx+r*.55f,cy-r*.70f,p);for(i in -2..2)c.drawLine(cx+i*r*.24f,cy-r*.76f,cx+i*r*.24f,cy-r*.64f,p)
        // Neck bolts.
        p.style=Paint.Style.FILL;p.color=Color.rgb(160,169,160);c.drawRect(cx-r*1.08f,cy+r*.38f,cx-r*.82f,cy+r*.63f,p);c.drawRect(cx+r*.82f,cy+r*.38f,cx+r*1.08f,cy+r*.63f,p)
    }
}
