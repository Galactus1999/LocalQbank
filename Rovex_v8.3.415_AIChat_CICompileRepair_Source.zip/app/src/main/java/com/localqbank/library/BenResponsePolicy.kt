package com.localqbank.library

/**
 * Deterministic bounds and hygiene for text returned by optional Ben backends.
 *
 * AI responses are presentation data, never executable HTML/CSS. The renderer receives
 * Markdown only; CSS, scripts, event handlers and layout-bearing HTML are removed here so
 * a malformed response cannot alter the Android text renderer or theme.
 *
 * IMPORTANT: sanitiser construction is deliberately lazy and failure-tolerant. Android's
 * ICU regex implementation has rejected patterns that compile on desktop/JDKs before.
 * A regex failure must therefore degrade to plain bounded text, never to
 * ExceptionInInitializerError / process death.
 */
object BenResponsePolicy {
    const val MAX_RESPONSE_CHARS = 64_000
    const val POLICY_REVISION = "v7-markdown-whitespace-and-mermaid-brace-preservation"

    private fun safeRegex(pattern: String, flags: Set<RegexOption> = emptySet()): Regex? =
        runCatching { Regex(pattern, flags) }
            .onFailure { t ->
                android.util.Log.e("Rovex.Frankenstein", "BenResponsePolicy regex disabled", t)
            }
            .getOrNull()

    // Never compile presentation-sanitisation regexes during object/class initialisation.
    // This prevents an Android ICU PatternSyntaxException from becoming
    // ExceptionInInitializerError and killing RenActivity on the main thread.
    private val styleBlock by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("<style\\b[^>]*>.*?</style\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val scriptBlock by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("<script\\b[^>]*>.*?</script\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val eventAttribute by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("\\bon[a-z][a-z0-9_-]*\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val styleAttribute by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("\\bstyle\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val cssRule by lazy(LazyThreadSafetyMode.PUBLICATION) {
        // Restrict CSS removal to explicit selector/property syntax on a single line.
        // Markdown/Mermaid uses braces legitimately (e.g. B{Stage?}, A{Diagnosis: ...});
        // a broad brace regex corrupts those authored blocks before the Markdown parser sees them.
        safeRegex("(?m)^[ \t]*(?:[.#][A-Za-z0-9_-]+|[a-z][A-Za-z0-9_-]*(?:[.#][A-Za-z0-9_-]+)?)\\s*\\{[^{}\\n]{0,5000}:[^{}\\n]{1,5000}\\}", setOf(RegexOption.IGNORE_CASE))
    }
    // Preserve harmless presentation tags so tables/images can reach the renderer.
    // Dangerous containers are removed; style and event attributes are removed separately.
    private val unsafeHtmlTag by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("</?(?:!doctype|html|head|body|base|link|meta|script|style|iframe|object|embed|form|input|textarea|button|select|option|canvas|svg|math)(?:\\s+[^>]*)?>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }

    /**
     * AI responses are presentation documents, not search queries. Preserve Markdown
     * newlines, blank lines, indentation and fenced-block boundaries; collapsing all
     * whitespace here destroys the structure needed by CommonMark/GFM and rich blocks.
     */
    private fun normalizeRichMarkdownWhitespace(raw: String): String? {
        if (raw.isEmpty()) return null
        val bounded = BoundedTextPolicy.truncateSafely(raw, MAX_RESPONSE_CHARS)
        val out = StringBuilder(bounded.length)
        var i = 0
        while (i < bounded.length) {
            val ch = bounded[i]
            when {
                Character.isHighSurrogate(ch) -> {
                    if (i + 1 < bounded.length && Character.isLowSurrogate(bounded[i + 1])) {
                        out.append(ch).append(bounded[i + 1]); i += 2; continue
                    }
                }
                Character.isLowSurrogate(ch) -> Unit
                ch == '\n' || ch == '\t' -> out.append(ch)
                ch.isISOControl() -> out.append(' ')
                else -> out.append(ch)
            }
            i++
        }
        return out.toString().trim().takeIf { it.isNotEmpty() }
    }

    /**
     * Never throws for malformed/untrusted AI text. If any sanitiser stage fails, the
     * response is still returned as bounded plain text after control-character cleanup.
     */
    fun normalize(raw: String?): String? {
        if (raw.isNullOrEmpty()) return null
        return try {
            var x = raw.replace("\r\n", "\n").replace("\r", "\n")
                .replace("\u0000", " ")
            // Protect fenced code/rich blocks from presentation sanitisation. Their contents are
            // rendered as inert code/rich data later; removing CSS-looking braces here would
            // corrupt legitimate code and Mermaid syntax before the renderer can parse it.
            val protectedBlocks = ArrayList<String>()
            x = x.replace(Regex("(?s)(```|~~~).*?(?:\\1|\\z)")) { m ->
                val token = "@@ROVEX_POLICY_BLOCK_${protectedBlocks.size}@@"
                protectedBlocks += m.value
                token
            }
            styleBlock?.let { x = it.replace(x, " ") }
            scriptBlock?.let { x = it.replace(x, " ") }
            eventAttribute?.let { x = it.replace(x, " ") }
            styleAttribute?.let { x = it.replace(x, " ") }
            repeat(4) { cssRule?.let { x = it.replace(x, " ") } }
            unsafeHtmlTag?.let { x = it.replace(x, " ") }
            protectedBlocks.forEachIndexed { index, block -> x = x.replace("@@ROVEX_POLICY_BLOCK_$index@@", block) }
            normalizeRichMarkdownWhitespace(x)
        } catch (t: StackOverflowError) {
            android.util.Log.e("Rovex.Frankenstein", "BenResponsePolicy stack overflow", t)
            runCatching { normalizeRichMarkdownWhitespace(raw) }.getOrNull()
                ?: raw.take(MAX_RESPONSE_CHARS)
        } catch (t: Exception) {
            android.util.Log.e("Rovex.Frankenstein", "BenResponsePolicy fallback", t)
            runCatching { normalizeRichMarkdownWhitespace(raw) }.getOrNull()
                ?: raw.take(MAX_RESPONSE_CHARS)
        }
    }
}
