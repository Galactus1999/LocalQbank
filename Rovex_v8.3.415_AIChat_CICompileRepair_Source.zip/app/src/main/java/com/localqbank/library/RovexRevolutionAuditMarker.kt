package com.localqbank.library
object RovexRevolutionAuditMarker {
 const val VERSION="ROVEX_UI_REVOLUTION_303"
 const val HOME="FULL_RUNTIME_LAYOUT_REPLACEMENT"
 const val EFFECTS="GLASS,GRADIENT,GLOW,DEPTH,REFLECTION,3D_STYLE"
}