package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Compact graphical Performance Lab panel; all metrics remain driven by real study data. */
class RovexPerformanceLabView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var accuracy = 0
    private var solved = 0
    private var wrong = 0

    fun setUserStats(a: Int, s: Int, w: Int) {
        RovexValueAnimations.animateInt(this, "accuracy", a.coerceIn(0, 100), 500L) { accuracy = it; invalidate() }
        RovexValueAnimations.animateInt(this, "solved", s.coerceAtLeast(0), 500L) { solved = it; invalidate() }
        RovexValueAnimations.animateInt(this, "wrong", w.coerceAtLeast(0), 500L) { wrong = it; invalidate() }
    }

    fun setScores(a: Int, s: Int, w: Int) = setUserStats(a, s, w)

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val dark = ThemeManager.isDark(context)
        val panel = if (ThemeManager.get(context) == ThemeManager.AMOLED) ThemeManager.panel(context) else ThemeManager.panel(context)
        paint.style = Paint.Style.FILL; paint.color = panel; c.drawRoundRect(0f,0f,w,h,20f*d,20f*d,paint)
        paint.textAlign = Paint.Align.LEFT; paint.color = ThemeManager.muted(context); paint.textSize=9.5f*d; paint.isFakeBoldText=true; c.drawText("PERFORMANCE LAB",16f*d,22f*d,paint)
        paint.isFakeBoldText=false; paint.color=ThemeManager.text(context); paint.textSize=12f*d; c.drawText("Study performance snapshot",16f*d,40f*d,paint)
        paint.color=if(ThemeManager.get(context)==ThemeManager.AMOLED) Color.rgb(127,231,226) else ThemeManager.accent(context); paint.textSize=24f*d; paint.isFakeBoldText=true; c.drawText("${accuracy}%",16f*d,70f*d,paint)
        paint.isFakeBoldText=false; paint.color=ThemeManager.muted(context); paint.textSize=8.5f*d; c.drawText("ACCURACY",78f*d,68f*d,paint)
        val left=16f*d; val right=w-16f*d; val total=maxOf(1,solved)
        fun bar(y:Float,label:String,value:Int,fraction:Float,fill:Int){
            paint.color=ThemeManager.muted(context);paint.textSize=8.5f*d;paint.isFakeBoldText=false;c.drawText(label,left,y-5f*d,paint)
            paint.color=Color.argb(35,255,255,255);c.drawRoundRect(left,y,right,y+8f*d,4f*d,4f*d,paint)
            paint.color=fill;val end=left+(right-left)*fraction.coerceIn(0f,1f);c.drawRoundRect(left,y,end,y+8f*d,4f*d,4f*d,paint)
            paint.textAlign=Paint.Align.RIGHT;paint.color=fill;paint.isFakeBoldText=true;c.drawText(value.toString(),right,y-5f*d,paint);paint.textAlign=Paint.Align.LEFT;paint.isFakeBoldText=false
        }
        bar(92f*d,"Solved",solved,solved/total.toFloat(),Color.rgb(255,183,77)); bar(128f*d,"Wrong",wrong,wrong/total.toFloat(),Color.rgb(79,195,247))
        paint.color=ThemeManager.muted(context);paint.textSize=8.5f*d;c.drawText("Continue last study position",16f*d,h-18f*d,paint);paint.color=if(dark)ThemeManager.aiText(context) else ThemeManager.accent(context);paint.isFakeBoldText=true;paint.textAlign=Paint.Align.RIGHT;c.drawText("OPEN  ›",right,h-18f*d,paint);paint.textAlign=Paint.Align.LEFT;paint.isFakeBoldText=false
    }
}