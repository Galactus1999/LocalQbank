package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * Compact Rovex identity mark for the home header.
 *
 * The old moving Earth graphic has deliberately been removed. This view uses the actual
 * Rovex application logo and adds a lightweight cyan/violet emission + animated lightning
 * arcs that originate from the logo. The bitmap itself remains visually stable.
 */
class RovexHeaderCosmicView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val logo = BitmapFactory.decodeResource(resources, R.drawable.rovex_app_logo)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var phase = 0f

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w * .5f
        val cy = h * .5f
        val r = minOf(w, h) * .39f

        // Emission behind the logo follows the logo's own cyan/violet identity colors.
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx - r * .18f, cy - r * .15f, r * 1.45f,
            intArrayOf(
                Color.argb(120, 0, 225, 255),
                Color.argb(72, 117, 50, 255),
                Color.argb(0, 0, 0, 0)
            ),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 1.45f, paint)
        paint.shader = null

        drawLightning(c, cx - r * .20f, cy - r * .12f, -2.55f, r * 1.00f, Color.rgb(45, 225, 255), 0)
        drawLightning(c, cx + r * .15f, cy + r * .02f, -.58f, r * .94f, Color.rgb(174, 82, 255), 1)
        drawLightning(c, cx - r * .02f, cy + r * .14f, 2.55f, r * .92f, Color.rgb(30, 205, 255), 2)
        drawLightning(c, cx + r * .10f, cy - r * .05f, .55f, r * 1.04f, Color.rgb(154, 60, 255), 3)

        val dst = RectF(cx - r, cy - r, cx + r, cy + r)
        paint.style = Paint.Style.FILL
        paint.alpha = 255
        c.drawBitmap(logo, null, dst, paint)

        phase += .18f
        if (isShown) postInvalidateOnAnimation()
    }

    private fun drawLightning(
        c: Canvas,
        sx: Float,
        sy: Float,
        angle: Float,
        length: Float,
        color: Int,
        seed: Int
    ) {
        val pulse = .72f + .28f * ((sin(phase * 1.7f + seed) + 1f) * .5f)
        val ex = sx + cos(angle) * length
        val ey = sy + sin(angle) * length
        val path = Path()
        path.moveTo(sx, sy)
        val segments = 6
        for (i in 1..segments) {
            val f = i / segments.toFloat()
            val bx = sx + (ex - sx) * f
            val by = sy + (ey - sy) * f
            val nx = -(ey - sy) / length
            val ny = (ex - sx) / length
            val jitter = if (i == segments) 0f else sin(seed * 3.1f + i * 4.7f) * length * .085f
            path.lineTo(bx + nx * jitter, by + ny * jitter)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = 1.1f + pulse * .9f
        paint.color = Color.argb((105 + pulse * 120).toInt(), Color.red(color), Color.green(color), Color.blue(color))
        c.drawPath(path, paint)
    }
}
