package com.localqbank.library
import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.webkit.WebView
import kotlin.math.abs
class BenChatWebView @JvmOverloads constructor(context: Context,attrs: AttributeSet?=null,defStyleAttr:Int=0):WebView(context,attrs,defStyleAttr){
 private var downX=0f; private var downY=0f; private var horizontalGesture=false
 override fun onTouchEvent(e:MotionEvent):Boolean{ when(e.actionMasked){ MotionEvent.ACTION_DOWN->{downX=e.x;downY=e.y;horizontalGesture=false;parent?.requestDisallowInterceptTouchEvent(false)}; MotionEvent.ACTION_MOVE->{val dx=e.x-downX;val dy=e.y-downY;if(!horizontalGesture&&abs(dx)>12f&&abs(dx)>abs(dy)*1.15f)horizontalGesture=true;if(horizontalGesture) parent?.requestDisallowInterceptTouchEvent(true)}; MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{if(horizontalGesture)parent?.requestDisallowInterceptTouchEvent(false);horizontalGesture=false} }; return super.onTouchEvent(e)}
 init { isHorizontalScrollBarEnabled=true; overScrollMode=android.view.View.OVER_SCROLL_IF_CONTENT_SCROLLS }
 override fun onDetachedFromWindow(){parent?.requestDisallowInterceptTouchEvent(false);super.onDetachedFromWindow()}
}
