package com.localqbank.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.createSavedStateHandle

/**
 * Screen-level quiz state holder. Android lifecycle/context objects stay outside the ViewModel;
 * storage and application dependencies are supplied by the factory.
 */
class QuizViewModel(
    private val appContext: android.content.Context,
    private val data: QuizSessionRepository,
    private val navigation: QuizNavigationUseCase,
    private val session: QuizSessionUseCase,
    private val answerUseCase: QuizAnswerUseCase,
    private val savedState: SavedStateHandle? = null
) : ViewModel() {
    private object SavedKeys {
        const val TEST_ID = "quiz.testId"
        const val POSITION = "quiz.position"
        const val PRACTICE_KEY = "quiz.practiceAnsweredKey"
        const val EXAM_REMAINING = "quiz.examRemainingMs"
        const val SESSION_LABEL = "quiz.sessionLabel"
        const val RESUME_POSITION = "quiz.resumePosition"
        const val RESUME_KEY = "quiz.resumeStableKey"
        const val EXAM_KEYS = "quiz.examAnswerKeys"
        const val EXAM_VALUES = "quiz.examAnswerValues"
    }

    val state = QuizUiState()
    private val pendingBookmarks = java.util.concurrent.ConcurrentHashMap<String, String?>()
    private val pendingMistakes = java.util.concurrent.ConcurrentHashMap<String, String?>()
    @Volatile private var foregroundProgress: ProgressSnapshot = ProgressSnapshot.empty()
    private val noteCache = java.util.concurrent.ConcurrentHashMap<Long, String>()

    init {
        restoreSavedTransientState()
        PerformanceManager.submit { foregroundProgress = PerformanceManager.progress(appContext) }
    }

    private fun persistTransientState() {
        val h=savedState ?: return
        h[SavedKeys.TEST_ID]=state.testId
        h[SavedKeys.POSITION]=state.position
        h[SavedKeys.PRACTICE_KEY]=state.practiceAnsweredKey
        h[SavedKeys.EXAM_REMAINING]=state.examRemainingMs
        h[SavedKeys.SESSION_LABEL]=state.sessionLabel
        h[SavedKeys.RESUME_POSITION]=state.resumePosition
        h[SavedKeys.RESUME_KEY]=state.resumeStableKey
        h[SavedKeys.EXAM_KEYS]=ArrayList(state.examAnswers.keys)
        h[SavedKeys.EXAM_VALUES]=ArrayList(state.examAnswers.values)
    }

    private fun restoreSavedTransientState() {
        val h=savedState ?: return
        state.testId=h[SavedKeys.TEST_ID] ?: state.testId
        state.position=(h[SavedKeys.POSITION] ?: 0).coerceAtLeast(0)
        state.practiceAnsweredKey=h[SavedKeys.PRACTICE_KEY]
        state.examRemainingMs=(h[SavedKeys.EXAM_REMAINING] ?: 0L).coerceAtLeast(0L)
        state.sessionLabel=h[SavedKeys.SESSION_LABEL]
        state.resumePosition=(h[SavedKeys.RESUME_POSITION] ?: state.position).coerceAtLeast(0)
        state.resumeStableKey=h[SavedKeys.RESUME_KEY]
        val keys=h.get<ArrayList<String>>(SavedKeys.EXAM_KEYS).orEmpty()
        val values=h.get<ArrayList<Boolean>>(SavedKeys.EXAM_VALUES).orEmpty()
        state.examAnswers.clear()
        keys.indices.filter { it < values.size && keys[it].isNotBlank() }.forEach { state.examAnswers[keys[it]]=values[it] }
    }
    private val notes = QuizNotesUseCase(data)
    private val bookmarks = QuizBookmarkUseCase(data.progress, readSnapshot = { foregroundProgress }) {
        if (AppManagers.isReady()) AppManagers.adaptive.onEvent("bookmark_changed")
    }
    private val flashcards = QuizFlashcardUseCase()
    private val knowledge = QuizKnowledgeUseCase()

    fun answer(question: Question, label: String, practiceMode: Boolean, examMode: Boolean): QuizAnswerUseCase.Result =
        answerUseCase.answer(question, label, practiceMode, examMode)

    fun resolveSession(
        title: String, requestedTestId: String, requestedQuestionId: Long, requestedPosition: Int,
        sessionIdsRaw: String?, collectionMode: Boolean, filterType: String, filterValue: String, sessionLabel: String?
    ): Result<QuizNavigationUseCase.SessionResolution> =
        navigation.resolve(title, requestedTestId, requestedQuestionId, requestedPosition, sessionIdsRaw, collectionMode, filterType, filterValue, sessionLabel)

    /** Cached-only read for callers that must remain synchronous on the UI thread. */
    fun note(questionId: Long): String? = noteCache[questionId]

    /** Loads note content off the UI thread; the callback is delivered on that same worker. */
    fun noteAsync(questionId: Long, onResult: (String?) -> Unit) {
        PerformanceManager.submit {
            val value = runCatching { noteCache[questionId] ?: notes.get(questionId) }
                .getOrNull()
            if (value != null) noteCache[questionId] = value
            onResult(value)
        }
    }

    fun saveNote(questionId: Long, value: String) {
        val cleaned = value.trim()
        PerformanceManager.submit {
            runCatching {
                notes.save(questionId, cleaned)
                noteCache[questionId] = cleaned
            }.onFailure { ProductionCrashReporter.recordNonFatal(it, "QUIZ_NOTE_SAVE") }
        }
    }

    fun appendNote(questionId: Long, value: String) {
        val selected = value.trim()
        if (selected.isBlank()) return
        PerformanceManager.submit {
            runCatching {
                val existing = noteCache[questionId] ?: notes.get(questionId).orEmpty()
                val merged = if (existing.isBlank()) selected else "$existing\n\n$selected"
                notes.save(questionId, merged)
                noteCache[questionId] = merged
            }.onFailure { ProductionCrashReporter.recordNonFatal(it, "QUIZ_NOTE_APPEND") }
        }
    }
    fun bookmark(stableKey: String): String? = pendingBookmarks[stableKey] ?: foregroundProgress.record(stableKey)?.bookmark
    fun setBookmark(stableKey: String, value: String?) {
        pendingBookmarks[stableKey] = value
        bookmarks.set(stableKey, value)
        PerformanceManager.submit {
            // Keep the optimistic overlay until the durable write is reflected in the snapshot.
            foregroundProgress = PerformanceManager.progress(appContext)
            pendingBookmarks.remove(stableKey, value)
        }
    }
    fun mistakeType(stableKey: String): String? = pendingMistakes[stableKey] ?: foregroundProgress.record(stableKey)?.mistake
    fun setMistakeType(stableKey: String, value: String?) {
        pendingMistakes[stableKey] = value
        PerformanceManager.submit {
            data.progress.setMistakeType(stableKey, value)
            PerformanceManager.invalidateProgress()
            foregroundProgress = PerformanceManager.progress(appContext)
            pendingMistakes.remove(stableKey, value)
        }
    }
    fun createFlashcard(questionId: Long, contextLabel: String, onResult: (FlashcardIntelligenceManager.Result) -> Unit) =
        flashcards.createFromQuestion(questionId, contextLabel, onResult)

    fun captureQuestionToKnowledge(question: Question, reason: String, onDone: (KnowledgeEngineManager.Result) -> Unit) =
        knowledge.captureQuestion(question, reason, onDone)

    fun saveKnowledgeImage(raw: String, questionId: Long, onDone: (Boolean) -> Unit) =
        knowledge.saveImage(raw, questionId, onDone)

    fun saveKnowledgeImageWithNote(raw: String, questionId: Long, note: String, onDone: (Boolean) -> Unit) =
        knowledge.saveImageWithNote(raw, questionId, note, onDone)

    fun existingQuestionIds(ids: LongArray): LongArray = data.existingQuestionIds(ids)
    fun questionById(id: Long): Question? = data.questionById(id)
    fun questionAt(testId: String, position: Int): Question? = data.questionAt(testId, position)
    fun testIdForQuestion(questionId: Long): String = data.testIdForQuestion(questionId).orEmpty()
    fun sourceIdForTest(testId: String): Long = data.sourceIdForTest(testId)
    fun sourceNameForTest(testId: String): String? = data.sourceNameForTest(testId)
    fun questionCount(testId: String): Int = data.questionCount(testId)
    fun rawQuestionPosition(testId: String, questionId: Long): Int? = data.rawQuestionPosition(testId, questionId)
    // Foreground quiz rendering must read from the immutable progress snapshot, not directly
    // from SQLite. The snapshot is invalidated by every progress mutation and is bounded by the
    // PerformanceManager TTL, so question transitions never synchronously wait on SQLite.
    fun progressStatus(stableKey: String): String? = foregroundProgress.record(stableKey)?.status
    fun selectedAnswer(stableKey: String): String? = foregroundProgress.record(stableKey)?.selected
    fun addTime(stableKey: String, elapsedMs: Long) {
        if (elapsedMs <= 0L) return
        PerformanceManager.submit {
            data.progress.addTime(stableKey, elapsedMs)
            PerformanceManager.invalidateProgress()
            foregroundProgress = PerformanceManager.progress(appContext)
        }
    }
    fun sessionKey(label: String?, title: String, testId: String, collectionMode: Boolean): String = session.sessionKey(label, title, testId, collectionMode)
    fun saveSessionCursor(key: String, testId: String, position: Int, stableKey: String?) = session.saveCursor(key, testId, position, stableKey)
    fun checkpoint(testId: String, position: Int, stableKey: String?, sessionLabel: String?) = session.checkpoint(testId, position, stableKey, sessionLabel)
    fun savePosition(testId: String, position: Int, sourceId: Long, bankName: String) {
        if (testId.isNotBlank()) PerformanceManager.submit {
            data.progress.setPosition(testId, position, sourceId, bankName)
            PerformanceManager.invalidateProgress()
        }
    }

    fun findTestIdForQuestion(questionId: Long): String = data.testIdForQuestion(questionId).orEmpty()
    fun targetPosition(current: Int, delta: Int): Int = navigation.targetPosition(current, delta, state.questionCount)
    fun isNavigationBoundary(current: Int, delta: Int): Boolean = navigation.isBoundary(current, delta, state.questionCount)
    fun moveToPosition(position: Int) {
        setPosition(position)
        // Explicit navigation means the visible question becomes the resume target.
        state.resumePosition = state.position
        state.resumeStableKey = state.currentQuestion?.let { if (it.position == state.position) it.stableKey else null }
        persistTransientState()
        persistPosition()
        persistSessionCursor()
    }
    fun persistPosition() {
        if (state.collectionMode || state.testId.isBlank()) return
        PerformanceManager.submit {
            data.progress.setPosition(state.testId, state.position, state.sourceId, state.bankName)
            PerformanceManager.invalidateProgress()
            foregroundProgress = PerformanceManager.progress(appContext)
        }
    }
    fun setResumeCursor(position: Int, stableKey: String?) {
        state.resumePosition = position.coerceIn(0, (state.questionCount - 1).coerceAtLeast(0))
        state.resumeStableKey = stableKey
        persistTransientState()
        persistResumePosition()
        persistSessionCursor()
    }

    /** Persist the durable Continue target, not merely the question currently visible. */
    fun persistResumePosition() {
        if (state.collectionMode || state.testId.isBlank()) return
        PerformanceManager.submit {
            data.progress.setPosition(state.testId, state.resumePosition, state.sourceId, state.bankName)
            PerformanceManager.invalidateProgress()
        }
    }
    fun persistSessionCursor() {
        if (state.collectionMode || state.testId.isBlank()) return
        saveSessionCursor(
            sessionKey(state.sessionLabel, state.title, state.testId, state.collectionMode),
            state.testId,
            state.resumePosition.coerceIn(0, (state.questionCount - 1).coerceAtLeast(0)),
            state.resumeStableKey
        )
    }
    fun checkpointSession() = checkpoint(state.testId, state.resumePosition, state.resumeStableKey, state.sessionLabel)
    fun recordElapsedTime(stableKey: String, elapsedMs: Long) {
        if (stableKey.isBlank() || elapsedMs <= 0L) return
        PerformanceManager.submit {
            data.progress.addTime(stableKey, elapsedMs)
            PerformanceManager.invalidateProgress()
            foregroundProgress = PerformanceManager.progress(appContext)
        }
    }

    fun configureSession(title: String, requestedTestId: String, collectionMode: Boolean, examMode: Boolean, examDurationMinutes: Int, practiceMode: Boolean, sessionLabel: String?, sectionLabel: String?) {
        val restoredSameSession = savedState?.get<String>(SavedKeys.TEST_ID)?.let { it.isNotBlank() && it == requestedTestId } == true
        state.title = title
        state.testId = requestedTestId
        state.collectionMode = collectionMode
        state.examMode = examMode
        state.examDurationMinutes = examDurationMinutes
        state.practiceMode = practiceMode
        state.sessionLabel = sessionLabel
        state.sectionLabel = sectionLabel
        if (!restoredSameSession) state.resetForNewSession()
        if (restoredSameSession) {
            state.resumePosition = savedState?.get<Int>(SavedKeys.RESUME_POSITION) ?: state.position
            state.resumeStableKey = savedState?.get<String>(SavedKeys.RESUME_KEY)
        }
        persistTransientState()
    }

    fun applyResolution(resolution: QuizNavigationUseCase.SessionResolution, preferResolutionPosition: Boolean = false) {
        state.testId = resolution.testId
        state.sourceId = resolution.sourceId
        state.questionCount = resolution.questionCount
        val restoredPosition = savedState?.get<Int>(SavedKeys.POSITION)
        state.position = if (!preferResolutionPosition && restoredPosition != null && savedState?.get<String>(SavedKeys.TEST_ID) == resolution.testId) {
            restoredPosition.coerceIn(0, (resolution.questionCount - 1).coerceAtLeast(0))
        } else resolution.position.coerceIn(0, (resolution.questionCount - 1).coerceAtLeast(0))
        state.collectionQuestionIds = resolution.collectionIds
        state.bankName = state.sessionLabel ?: resolution.bankName
        val restoredResume = savedState?.get<Int>(SavedKeys.RESUME_POSITION)
        val restoredResumeTest = savedState?.get<String>(SavedKeys.TEST_ID)
        if (restoredResume != null && restoredResumeTest == resolution.testId && !preferResolutionPosition) {
            state.resumePosition = restoredResume.coerceIn(0, (resolution.questionCount - 1).coerceAtLeast(0))
            state.resumeStableKey = savedState?.get<String>(SavedKeys.RESUME_KEY)
        } else {
            state.resumePosition = state.position
            state.resumeStableKey = null
        }
        persistTransientState()
    }
    fun setCurrentQuestion(question: Question?) { state.currentQuestion = question }
    fun setPosition(position: Int) { state.position = position.coerceIn(0, (state.questionCount - 1).coerceAtLeast(0)); persistTransientState() }
    fun setPracticeAnsweredKey(key: String?) { state.practiceAnsweredKey = key; persistTransientState() }
    fun setExamRemainingMs(value: Long) { state.examRemainingMs = value.coerceAtLeast(0L); persistTransientState() }
    fun recordExamAnswer(key: String, correct: Boolean) {
        if (key.isBlank()) return
        state.examAnswers[key] = correct
        persistTransientState()
    }
    fun examAttemptedCount(): Int = state.examAnswers.size
    fun examCorrectCount(): Int = state.examAnswers.values.count { it }

    override fun onCleared() {
        // Last-chance transient checkpoint before the repository is released. The durable
        // answer itself is already committed synchronously by StudyStateRepository.
        resultOf {
            persistTransientState()
            if (state.testId.isNotBlank()) {
                // checkpointSession() already uses the durable resume cursor. Do not call
                // persistPosition() here: that would overwrite an answer->next-question
                // resume target with the question that happened to be visible at teardown.
                checkpointSession()
            }
        }
        data.close()
        super.onCleared()
    }
}

class QuizViewModelFactory(
    private val newRepository: () -> QuizSessionRepository,
    private val newSessionUseCase: () -> QuizSessionUseCase,
    private val newStudyStateRepository: () -> StudyStateRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = createInternal(modelClass, null)

    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T = createInternal(modelClass, extras.createSavedStateHandle())

    private fun <T : ViewModel> createInternal(modelClass: Class<T>, savedState: SavedStateHandle?): T {
        if (!modelClass.isAssignableFrom(QuizViewModel::class.java)) throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
        val repository = newRepository()
        return QuizViewModel(
            appContext = repository.progressContext(),
            data = repository,
            navigation = QuizNavigationUseCase(repository),
            session = newSessionUseCase(),
            answerUseCase = QuizAnswerUseCase(newStudyStateRepository()),
            savedState = savedState
        ) as T
    }
}
