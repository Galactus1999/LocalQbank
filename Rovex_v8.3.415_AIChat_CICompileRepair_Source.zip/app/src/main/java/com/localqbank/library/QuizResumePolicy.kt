package com.localqbank.library

/** Pure resume semantics: answer -> next question, navigation -> viewed question. */
object QuizResumePolicy {
    fun afterAnswer(position: Int, questionCount: Int): Int =
        position.coerceAtLeast(0).let { current -> (current + 1).coerceAtMost((questionCount - 1).coerceAtLeast(0)) }

    fun afterExplicitNavigation(position: Int, questionCount: Int): Int =
        position.coerceIn(0, (questionCount - 1).coerceAtLeast(0))
}
