package com.localqbank.library

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log

/** Reliable low-latency UI sound feedback. Loads asynchronously and plays only after the sample is ready. */
object RovexSoundFeedback {
    private const val PREFS = "ui"
    private const val KEY_ENABLED = "sound_feedback_enabled"
    private const val TAG = "RovexSound"
    private var pool: SoundPool? = null
    private var correctId = 0
    private var milestoneId = 0
    private var clickId = 0
    private var correctReady = false
    private var milestoneReady = false
    private var clickReady = false
    private var pending: Cue? = null
    private enum class Cue { CORRECT, MILESTONE, CLICK }
    fun isEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (!enabled) release() else ensurePool(context)
    }
    fun playCorrect(context: Context) = play(context, Cue.CORRECT)
    fun playMilestone(context: Context) = play(context, Cue.MILESTONE)
    fun preload(context: Context) {
        if (isEnabled(context)) synchronized(this) { ensurePool(context) }
    }
    fun playTest(context: Context): Boolean = play(context, Cue.CLICK)
    fun playClick(context: Context) { play(context, Cue.CLICK) }
    private fun play(context: Context, cue: Cue): Boolean {
        if (!isEnabled(context)) return false
        synchronized(this) {
            ensurePool(context)
            val ready = when(cue) {
                Cue.CORRECT -> correctReady
                Cue.MILESTONE -> milestoneReady
                Cue.CLICK -> clickReady
            }
            val id = when(cue) {
                Cue.CORRECT -> correctId
                Cue.MILESTONE -> milestoneId
                Cue.CLICK -> clickId
            }
            if (!ready || id == 0) {
                if (cue == Cue.CLICK) {
                    // SoundPool loads asynchronously. A short UI cue must still work on the
                    // very first tap, so use the same PCM asset through MediaPlayer while the
                    // pool finishes loading. Do not queue a second click or the user can hear
                    // two sounds when onLoadComplete fires.
                    return playDirectFallback(context)
                }
                pending = cue
                return false
            }
            val gain = if (cue == Cue.CLICK) 0.72f else 0.85f
            val stream = pool?.play(id, gain, gain, 2, 0, 1f) ?: 0
            if (stream == 0 && cue == Cue.CLICK) return playDirectFallback(context)
            return stream != 0
        }
    }
    private fun ensurePool(context: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        val p = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { soundPool, sampleId, status ->
            synchronized(this) {
                if (status != 0) { Log.w(TAG, "Sound sample failed to load: $sampleId status=$status"); return@synchronized }
                if (sampleId == correctId) correctReady = true
                if (sampleId == milestoneId) milestoneReady = true
                if (sampleId == clickId) clickReady = true
                val next = pending; pending = null
                if (next != null) {
                    val nextId = when(next) {
                        Cue.CORRECT -> correctId
                        Cue.MILESTONE -> milestoneId
                        Cue.CLICK -> clickId
                    }
                    val nextReady = when(next) {
                        Cue.CORRECT -> correctReady
                        Cue.MILESTONE -> milestoneReady
                        Cue.CLICK -> clickReady
                    }
                    if (nextReady && nextId != 0) {
                        val gain = if (next == Cue.CLICK) 0.72f else 0.85f
                        soundPool.play(nextId, gain, gain, 2, 0, 1f)
                    }
                }
            }
        }
        pool = p; correctReady = false; milestoneReady = false; clickReady = false
        correctId = p.load(context.applicationContext, R.raw.rover_correct, 1)
        milestoneId = p.load(context.applicationContext, R.raw.rover_milestone, 1)
        clickId = p.load(context.applicationContext, R.raw.rovex_button_click, 1)
    }

    private fun playDirectFallback(context: Context): Boolean {
        return runCatching {
            val player = android.media.MediaPlayer.create(context.applicationContext, R.raw.rovex_button_click)
                ?: return@runCatching false
            player.setOnCompletionListener { it.release() }
            player.setOnErrorListener { mp, _, _ -> mp.release(); true }
            player.setVolume(0.9f, 0.9f)
            player.start()
            true
        }.onFailure { Log.w(TAG, "Direct click fallback failed", it) }.getOrDefault(false)
    }
    private fun release() { synchronized(this) { runCatching { pool?.release() }; pool = null; correctId = 0; milestoneId = 0; clickId = 0; correctReady = false; milestoneReady = false; clickReady = false; pending = null } }
}
