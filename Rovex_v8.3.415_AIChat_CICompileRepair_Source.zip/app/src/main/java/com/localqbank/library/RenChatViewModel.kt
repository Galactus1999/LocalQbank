package com.localqbank.library
import androidx.lifecycle.ViewModel
class RenChatViewModel:ViewModel(){
 val turns=mutableListOf<Pair<String,String>>()
 var prompt:String=""
 var lastBenReply:String=""
 var webScrollY:Int=0
}