package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max

/**
 * 28-day accuracy trend. The primary visual is deliberately a dotted line rather than bars:
 * each day is a dot, its vertical position is that day's accuracy, and the dotted path connects
 * observed days. Solved volume is retained in the accessibility/content description and is not
 * allowed to visually dominate the accuracy signal.
 */
class Last28StudyDaysGraphView(context: Context) : View(context) {
    data class Day(val dayStart: Long, val solved: Int, val correct: Int)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
        strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(2f, 7f), 0f)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private var days: List<Day> = emptyList()

    fun setDays(value: List<Day>) {
        days = value.takeLast(28)
        contentDescription = days.joinToString("; ") { day ->
            val accuracy = if (day.solved == 0) "no attempts" else "${day.correct * 100 / day.solved}% accuracy"
            "${day.dayStart}: $accuracy, ${day.solved} solved"
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val left = 20f * d
        val right = (width - 12f * d).coerceAtLeast(left + 1f)
        val top = 18f * d
        val bottom = (height - 25f * d).coerceAtLeast(top + 1f)
        val accent = ThemeManager.accent(context)
        val dark = ThemeManager.isDark(context)

        line.color = android.graphics.Color.argb(if (dark) 75 else 60,
            android.graphics.Color.red(accent), android.graphics.Color.green(accent), android.graphics.Color.blue(accent))
        val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f }
        grid.color = android.graphics.Color.argb(if (dark) 45 else 35,
            android.graphics.Color.red(accent), android.graphics.Color.green(accent), android.graphics.Color.blue(accent))
        for (i in 0..4) {
            val y = bottom - (bottom - top) * i / 4f
            c.drawLine(left, y, right, y, grid)
        }

        text.color = ThemeManager.muted(context)
        text.textSize = 8f * d
        text.textAlign = Paint.Align.RIGHT
        c.drawText("100%", left - 4f * d, top + 3f * d, text)
        c.drawText("50%", left - 4f * d, (top + bottom) / 2f + 3f * d, text)
        c.drawText("0%", left - 4f * d, bottom + 3f * d, text)

        if (days.isEmpty()) {
            text.textAlign = Paint.Align.LEFT
            c.drawText("Answer questions to build today's accuracy trend", left, (top + bottom) / 2f + 4f * d, text)
            return
        }

        val path = Path()
        days.forEachIndexed { i, day ->
            val x = if (days.size == 1) (left + right) / 2f else left + (right - left) * i / (days.lastIndex.toFloat())
            val hasData = day.solved > 0
            val accuracy = if (hasData) (day.correct * 100f / day.solved).coerceIn(0f, 100f) else Float.NaN
            val y = if (hasData) bottom - (bottom - top) * accuracy / 100f else bottom
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            dot.color = if (!hasData) android.graphics.Color.argb(45,
                android.graphics.Color.red(accent), android.graphics.Color.green(accent), android.graphics.Color.blue(accent))
            else if (accuracy >= 75f) android.graphics.Color.rgb(62, 210, 165)
            else if (accuracy >= 50f) android.graphics.Color.rgb(255, 193, 73)
            else android.graphics.Color.rgb(255, 102, 137)
            c.drawCircle(x, y, if (hasData) 4.3f * d else 2.4f * d, dot)
        }
        if (days.size > 1) c.drawPath(path, line)

        text.textAlign = Paint.Align.CENTER
        val labels = listOf(0, 6, 13, 20, 27)
        labels.forEach { i ->
            if (i < days.size) {
                val cal = java.util.Calendar.getInstance().apply { timeInMillis = days[i].dayStart }
                val x = if (days.size == 1) (left + right) / 2f else left + (right - left) * i / (days.lastIndex.toFloat())
                c.drawText(cal.get(java.util.Calendar.DAY_OF_MONTH).toString(), x, height - 7f * d, text)
            }
        }
        text.textAlign = Paint.Align.LEFT
        c.drawText("ACCURACY TREND", left, 10f * d, text)
        text.textAlign = Paint.Align.RIGHT
        c.drawText("DOT = DAILY ACCURACY", right, 10f * d, text)
    }
}
