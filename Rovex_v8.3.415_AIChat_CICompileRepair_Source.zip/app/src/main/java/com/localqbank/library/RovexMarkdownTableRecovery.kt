package com.localqbank.library

/**
 * High-confidence recovery for provider-generated GFM tables whose physical line boundaries were
 * lost. CommonMark remains authoritative for valid Markdown; this class only reconstructs a table
 * when delimiter evidence and column cardinality make the intended 2-D structure unambiguous.
 */
object RovexMarkdownTableRecovery {
    private val delimiterCell = Regex(":?-{3,}:?")
    private val headingBoundary = Regex("^ {0,3}(?:#{1,6}\\s|[-*+]\\s+|\\d+[.)]\\s+|>\\s?)")

    fun recover(input: String, maxColumns: Int = 12, maxRows: Int = 80): String {
        if (input.isBlank()) return input
        val lines = input.replace("\r\n", "\n").replace('\r', '\n').split('\n').toMutableList()
        var changed = false
        var i = 0
        while (i < lines.size) {
            val result = recoverCandidate(lines, i, maxColumns, maxRows)
                ?: recoverCollapsedCandidate(lines, i, maxColumns, maxRows)
            if (result == null) {
                i++
                continue
            }
            lines.subList(result.start, result.endExclusive).clear()
            lines.add(result.start, result.markdown)
            changed = true
            i = result.start + result.markdown.lineSequence().count() + 1
        }
        return if (changed) lines.joinToString("\n") else input
    }

    private data class Candidate(
        val start: Int,
        val endExclusive: Int,
        val markdown: String
    )

    private fun recoverCandidate(
        lines: List<String>,
        delimiterLineIndex: Int,
        maxColumns: Int,
        maxRows: Int
    ): Candidate? {
        if (delimiterLineIndex <= 0) return null
        val previous = lines[delimiterLineIndex - 1].trim()
        if (!previous.endsWith("|")) return null
        val previousCells = splitCells(previous)
        if (previousCells.size !in 2..maxColumns || previousCells.any { it.isBlank() }) return null

        val current = lines[delimiterLineIndex].trim()
        // A common provider shape ends the wrapped delimiter line with an extra sentinel pipe:
        // "| Clinical Implication | ------------- | -------- ||". splitCells() correctly removes
        // only the outer table pipes, but the doubled trailing pipe leaves an empty logical cell.
        // Trim trailing empty cells before delimiter analysis so the sentinel cannot invalidate an
        // otherwise unambiguous delimiter suffix.
        val currentCells = splitCells(current).dropLastWhile { it.isBlank() }
        if (currentCells.size < 2) return null
        val delimiterStart = suffixDelimiterStart(currentCells) ?: return null
        val prefixCount = delimiterStart
        val delimiterCells = currentCells.drop(delimiterStart)
        if (prefixCount !in 1..maxColumns || delimiterCells.isEmpty()) return null
        if (delimiterCells.any { !isDelimiter(it) }) return null

        val totalColumns = previousCells.size
        if (totalColumns !in 2..maxColumns || prefixCount + delimiterCells.size != totalColumns) return null

        val headerCells = previousCells.takeLast(delimiterCells.size) + currentCells.take(prefixCount)
        if (headerCells.size != totalColumns || headerCells.any { it.isBlank() }) return null
        val prefixCells = previousCells.dropLast(delimiterCells.size)
        val prefix = prefixCells.joinToString(" | ").trim()

        // The wrapped delimiter line may contain fewer delimiter cells than the recovered
        // header because one or more delimiter tokens were lost along with the line break. Once
        // the complete header has been reconstructed and the remaining delimiter suffix is valid,
        // synthesize the missing delimiter cells instead of consuming the first body row as if it
        // were delimiter syntax. This is the exact failure mode produced by the CI fixture:
        // "| Clinical Implication | ------------- | -------- ||".
        val bodyLineIndex = delimiterLineIndex + 1
        val bodyCells = emptyList<String>()

        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        var trailingBoundary: String? = null
        var trailingOnInitialBodyLine = false

        fun consumeLineCells(cells: List<String>): Boolean {
            for (cell in cells) {
                val value = cell.trim()
                // A provider can put the next Markdown block after a final pipe. A leading
                // blockquote marker is a structural boundary, not a table cell.
                if (value.startsWith(">")) {
                    if (row.isEmpty() && rows.isNotEmpty()) {
                        trailingBoundary = value
                        return false
                    }
                    return false
                }
                if (value.isBlank()) {
                    // In collapsed provider output an empty pipe is commonly a row-boundary
                    // sentinel ("... | cell | | next-cell ..."), not a semantic empty cell.
                    // Ignore it when a row is already complete, or while a malformed physical
                    // line is being packed into the next complete logical row. Never treat the
                    // sentinel as content because doing so shifts every subsequent cell.
                    if (row.size == totalColumns) {
                        rows += row.toList()
                        row.clear()
                    }
                    continue
                }
                row += value
                if (row.size == totalColumns) {
                    rows += row.toList()
                    row.clear()
                } else if (row.size > totalColumns) {
                    return false
                }
            }
            return true
        }

        if (bodyCells.isNotEmpty() && !consumeLineCells(bodyCells)) {
            trailingOnInitialBodyLine = trailingBoundary != null
        }

        var cursor = bodyLineIndex
        while (cursor < lines.size && rows.size < maxRows) {
            val raw = lines[cursor]
            val trimmed = raw.trim()
            if (trimmed.isBlank()) break
            if (isHardBoundary(trimmed)) break
            if (!trimmed.contains('|')) break

            var cells = splitCellsPreserveEmpty(trimmed)
            if (cells.isEmpty()) break

            // Some providers repeat the final delimiter token at the start of the first
            // physical body line after wrapping the header/delimiter pair, e.g.
            // "| ----------------- | Persistent cough | Mass on chest X-ray | | CXR | ...".
            // That token is structural residue, not a body cell. Discard it only at the
            // beginning of a fresh row and only when it is a delimiter-shaped cell; doing
            // this inside the wrapped-table state machine avoids globally rewriting valid
            // Markdown tables or ordinary prose containing dashes.
            if (row.isEmpty() && rows.isEmpty() && cells.size > 1 && isDelimiter(cells.first())) {
                cells = cells.drop(1)
                if (cells.isEmpty()) break
            }

            val accepted = consumeLineCells(cells)
            if (!accepted) break
            cursor++
        }
        if (row.isNotEmpty()) {
            // A final short row is ambiguous: do not guess. Valid rows must have the recovered
            // column cardinality.
            return null
        }
        if (rows.isEmpty()) return null


        val consumedEnd = when {
            trailingOnInitialBodyLine -> bodyLineIndex
            trailingBoundary != null -> cursor + 1
            else -> cursor
        }
        val nextBoundary = lines.getOrNull(consumedEnd)?.trim().orEmpty()
        // Never absorb a blockquote/heading/list into the table. A final cell may contain a prose
        // fragment only when it was already part of the pipe-delimited row.
        if (nextBoundary.startsWith(">") || headingBoundary.matches(nextBoundary)) {
            // expected boundary; leave it outside the reconstructed block
        }

        val out = buildString {
            if (prefix.isNotBlank()) append(prefix).append("\n\n")
            append("| ").append(headerCells.joinToString(" | ")).append(" |\n")
            append("| ").append((0 until totalColumns).joinToString(" | ") { "---" }).append(" |\n")
            rows.forEachIndexed { _, cells ->
                append("| ").append(cells.joinToString(" | ")).append(" |")
                append("\n")
            }
            trailingBoundary?.let { append(it) }
        }
        return Candidate(delimiterLineIndex - 1, consumedEnd, out)
    }

    /**
     * Recovers a provider that emitted an entire GFM table as one physical line. This path is
     * intentionally separate from the wrapped-header state machine because there is no physical
     * newline to use as a structural hint. A delimiter run plus an exact N-cell header/body shape
     * is required before rewriting anything.
     */
    private fun recoverCollapsedCandidate(
        lines: List<String>,
        lineIndex: Int,
        maxColumns: Int,
        maxRows: Int
    ): Candidate? {
        val line = lines[lineIndex].trim()
        if (!line.contains('|')) return null
        val cells = splitCellsPreserveEmpty(line)
        if (cells.size < 5) return null

        val delimiterStart = cells.indexOfFirst { isDelimiter(it) }
        if (delimiterStart < 0) return null
        var delimiterEnd = delimiterStart
        while (delimiterEnd < cells.size && isDelimiter(cells[delimiterEnd])) delimiterEnd++
        val columns = delimiterEnd - delimiterStart
        if (columns !in 2..maxColumns) return null
        if (delimiterStart < columns) return null
        if (delimiterEnd >= cells.size) return null

        // A collapsed row boundary is commonly represented by an empty pipe immediately after the
        // delimiter/header area. Require that sentinel when the body is also collapsed, otherwise
        // ordinary prose with a few dashes is too easy to misclassify.
        val headerSource = cells.subList(0, delimiterStart).toMutableList()
        while (headerSource.lastOrNull()?.isBlank() == true) headerSource.removeAt(headerSource.lastIndex)
        val header = headerSource.takeLast(columns)
        if (header.size != columns || header.any { it.isBlank() }) return null
        val prefix = headerSource.dropLast(columns).joinToString(" | ").trim()
        val bodySource = cells.subList(delimiterEnd, cells.size).toMutableList()
        if (bodySource.firstOrNull()?.isBlank() == true) bodySource.removeAt(0)
        if (bodySource.isEmpty()) return null

        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        var trailing: String? = null
        for (cell in bodySource) {
            val value = cell.trim()
            if (value.startsWith(">")) {
                if (row.isEmpty() && rows.isNotEmpty()) trailing = value
                else return null
                break
            }
            if (value.isBlank()) {
                if (row.size == columns) {
                    rows += row.toList()
                    row.clear()
                }
                continue
            }
            row += value
            if (row.size == columns) {
                rows += row.toList()
                row.clear()
                if (rows.size >= maxRows) break
            } else if (row.size > columns) {
                return null
            }
        }
        if (row.isNotEmpty() || rows.isEmpty()) return null

        val out = buildString {
            if (prefix.isNotBlank()) append(prefix).append("\n\n")
            append("| ").append(header.joinToString(" | ")).append(" |\n")
            append("| ").append((0 until columns).joinToString(" | ") { "---" }).append(" |\n")
            rows.forEach { append("| ").append(it.joinToString(" | ")).append(" |\n") }
            trailing?.let { append(it) }
        }.trimEnd()
        return Candidate(lineIndex, lineIndex + 1, out)
    }

    private fun suffixDelimiterStart(cells: List<String>): Int? {
        var index = cells.lastIndex
        while (index >= 0 && cells[index].isBlank()) index--
        if (index < 1) return null
        var start = index
        while (start >= 0 && isDelimiter(cells[start])) start--
        val delimiterStart = start + 1
        return if (delimiterStart in 1..index) delimiterStart else null
    }

    private fun isDelimiter(cell: String): Boolean = delimiterCell.matches(cell.trim())

    private fun isHardBoundary(line: String): Boolean {
        if (line.startsWith(">")) return true
        if (line.startsWith("```") || line.startsWith("~~~")) return true
        return headingBoundary.matches(line)
    }

    /** Split pipe-delimited cells while respecting escaped pipes and inline-code spans. */
    fun splitCells(line: String): List<String> = splitCellsPreserveEmpty(line).filterNot { it.isEmpty() }

    private fun splitCellsPreserveEmpty(line: String): List<String> {
        val source = line.trim()
        if (source.isEmpty()) return emptyList()
        val cells = ArrayList<String>()
        val current = StringBuilder()
        var escaped = false
        var codeTicks = 0
        var i = 0
        while (i < source.length) {
            val c = source[i]
            if (escaped) {
                current.append(c)
                escaped = false
                i++
                continue
            }
            if (c == '\\') {
                current.append(c)
                escaped = true
                i++
                continue
            }
            if (c == '`') {
                var j = i
                while (j < source.length && source[j] == '`') j++
                val count = j - i
                if (codeTicks == 0) codeTicks = count
                else if (count == codeTicks) codeTicks = 0
                current.append(source, i, j)
                i = j
                continue
            }
            if (c == '|' && codeTicks == 0) {
                cells += current.toString().trim()
                current.setLength(0)
            } else {
                current.append(c)
            }
            i++
        }
        cells += current.toString().trim()
        if (cells.firstOrNull().orEmpty().isEmpty()) cells.removeAt(0)
        if (cells.lastOrNull().orEmpty().isEmpty()) cells.removeAt(cells.lastIndex)
        return cells
    }
}
