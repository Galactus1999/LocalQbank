package com.localqbank.library

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/**
 * Pure, deterministic content/scheduling helpers for Rovex's daily motivation and target
 * notifications. No network, AI inference, database mutation, or study scheduling lives here.
 */
object RovexDailyNotificationContent {
    private val quotes = listOf(
        "Small, consistent effort compounds into extraordinary results.",
        "You do not need a perfect day. You need the next focused session.",
        "Study the concept, then test the concept. Retrieval turns knowledge into recall.",
        "Progress is built one question, one correction, and one revision at a time.",
        "When a topic feels difficult, slow down enough to understand it—not enough to quit.",
        "A difficult question is feedback, not a verdict.",
        "Your future self benefits from the work you finish today.",
        "Consistency beats intensity when the goal is long-term mastery.",
        "Learn the why, remember the pattern, and practise the application.",
        "One focused hour is more valuable than a day spent worrying about studying.",
        "Mistakes are useful when you convert them into a rule you can recall next time.",
        "Keep the session simple: learn, retrieve, correct, repeat.",
        "The fastest route to mastery is honest feedback followed by deliberate practice.",
        "Do today's work before tomorrow's anxiety arrives.",
        "A strong revision system makes difficult knowledge easier to retrieve.",
        "You are allowed to find a topic hard. You are not required to leave it misunderstood.",
        "Every solved question is also a diagnostic of what your brain knows and misses.",
        "Make the next question count.",
        "Focus on the process you can control: attention, recall, correction, repetition.",
        "Knowledge becomes reliable when you can retrieve it without the page in front of you.",
        "Do not measure the session only by the questions you got right. Measure what you learned from the wrong ones.",
        "A calm, repeated routine can outperform occasional bursts of effort.",
        "Finish one small block before deciding whether you can do another.",
        "Your study history is built from ordinary days. Make today's one useful.",
        "Understand first. Memorize strategically. Retrieve repeatedly.",
        "The goal is not to know everything at once. The goal is to keep reducing what you do not know.",
        "Protect your attention; it is one of your most valuable study resources.",
        "A question you correct today is a question you are less likely to miss tomorrow.",
        "Keep moving: one concept, one question, one review.",
        "Good preparation is rarely dramatic. It is usually consistent.",
        "Use difficulty as a signal for where your next revision should go.",
        "You can restart a study session at any moment. The next five minutes still count.",
        "Strong recall is built, not wished for.",
        "Do the high-value work while your attention is available.",
        "A useful revision session leaves you with fewer uncertainties than you started with.",
        "Do not wait to feel motivated before beginning. Beginning often creates the momentum.",
        "Your mistakes can become your highest-yield revision list.",
        "Learn actively enough that the answer can come back when the question is unfamiliar.",
        "A focused attempt is progress even when the score is not.",
        "Keep the standard high and the next step small.",
        "Study for understanding; revise for retrieval; test for transfer.",
        "The best study plan is one you can execute repeatedly.",
        "Today is another opportunity to make tomorrow's recall easier.",
        "You do not need to finish everything. Finish the next important thing.",
        "When recall fails, identify the missing cue and build it deliberately.",
        "Small wins are still wins when they accumulate.",
        "A disciplined routine reduces the amount of willpower studying requires.",
        "Turn every explanation into something you can retrieve later.",
        "The question bank is not only an exam tool; it is a map of your knowledge gaps.",
        "Review the errors you keep repeating. That is where the highest-value learning often lives.",
        "One good correction can be worth more than ten passive rereads.",
        "Keep your attention on the question in front of you.",
        "Mastery grows quietly through repeated exposure and retrieval.",
        "If today's session is imperfect, make the next one better rather than abandoning the plan.",
        "A target gives direction; a routine turns it into progress.",
        "Study with curiosity: ask why the correct answer is correct and why the alternatives are wrong.",
        "The work you repeat becomes the skill you keep.",
        "Your next revision can begin with the last mistake you understood.",
        "Keep showing up. The cumulative effect is the point."
    )

    fun quoteFor(date: LocalDate): String {
        val index = Math.floorMod(date.toEpochDay().toInt(), quotes.size)
        return quotes[index]
    }

    fun quoteCount(): Int = quotes.size

    fun nextTriggerMillis(now: ZonedDateTime, hour: Int, minute: Int): Long {
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)
        var next = now.withHour(safeHour).withMinute(safeMinute).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return ChronoUnit.MILLIS.between(now, next).coerceAtLeast(60_000L)
    }

    fun todayStartMillis(zone: ZoneId = ZoneId.systemDefault()): Long =
        LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()
}
