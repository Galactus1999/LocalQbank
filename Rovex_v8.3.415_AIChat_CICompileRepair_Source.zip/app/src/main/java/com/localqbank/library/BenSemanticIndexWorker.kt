package com.localqbank.library

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/**
 * Builds EmbeddingGemma's persistent document-vector cache without competing with foreground
 * study. This is deliberately separate from BenKnowledgeBuildWorker: concept indexing may run
 * immediately, while native embedding is deferred to charging + device-idle time.
 *
 * The vector cache lives inside :inference_process and is keyed by model/tokenizer/content hash.
 * It is therefore a cache, not a second authoritative QBank or retrieval database.
 */
class BenSemanticIndexWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext
        val db = QBankDb(app)
        val inference = BenInferenceProcessClient(app)
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        try {
            val policy = BenAiRuntimePolicy(app)
            if (!policy.enabled || policy.circuitOpen) {
                prefs.edit().putString("state", "AI_DISABLED").apply()
                return@withContext Result.success()
            }
            val models = BenNeuralModelManager(app)
            if (models.installed(BenNeuralModelRegistry.embeddingGemma300m) == null ||
                models.installedEmbeddingGemmaTokenizer() == null) {
                prefs.edit().putString("state", "WAITING_FOR_MODEL").apply()
                return@withContext Result.success()
            }
            val total = runCatching { db.aiIndexQuestionCount() }.getOrDefault(0)
            if (total <= 0) {
                prefs.edit().putString("state", "EMPTY").putInt("progress", 0).apply()
                return@withContext Result.success()
            }
            var cursor = prefs.getLong("last_question_id", 0L)
            var processed = prefs.getInt("processed", 0).coerceAtLeast(0)
            prefs.edit().putString("state", "RUNNING").apply()

            while (true) {
                coroutineContext.ensureActive()
                val rows = db.aiIndexBatch(cursor, BATCH_SIZE)
                if (rows.isEmpty()) break
                var batchSucceeded = true
                rows.chunked(8).forEach { chunk ->
                    coroutineContext.ensureActive()
                    if (!batchSucceeded) return@forEach
                    val texts = chunk.map { row ->
                        "title: ${row.testTitle.ifBlank { "none" }} | text: ${row.text.take(MAX_TEXT)}"
                    }
                    // The isolated service persists the vectors. The worker only controls pacing.
                    batchSucceeded = runCatching {
                        val result = inference.embedDocumentsSuspend(texts)
                        result?.usedModel == true && result.vectors.size == texts.size
                    }.getOrDefault(false)
                }
                if (!batchSucceeded) {
                    prefs.edit().putString("state", "PAUSED_NEURAL_UNAVAILABLE").apply()
                    return@withContext Result.retry()
                }
                cursor = rows.last().id
                processed += rows.size
                val percent = ((processed.toLong() * 100L) / total.coerceAtLeast(1)).toInt().coerceIn(0, 100)
                prefs.edit().putLong("last_question_id", cursor).putInt("processed", processed).putInt("progress", percent).apply()
                setProgress(workDataOf("processed" to processed, "total" to total, "progress" to percent))
            }
            prefs.edit().putString("state", "COMPLETE").putInt("progress", 100).apply()
            Result.success()
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            prefs.edit().putString("state", "PAUSED").apply()
            throw cancelled
        } catch (_: Exception) {
            prefs.edit().putString("state", "FAILED").apply()
            Result.retry()
        } finally {
            inference.close()
            db.close()
        }
    }

    data class Status(val state: String, val progress: Int, val processed: Int)

    companion object {
        fun status(context: Context): Status {
            val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return Status(
                p.getString("state", "IDLE") ?: "IDLE",
                p.getInt("progress", 0).coerceIn(0, 100),
                p.getInt("processed", 0).coerceAtLeast(0)
            )
        }

        const val UNIQUE_WORK = "ben_semantic_vector_index"
        private const val PREFS = "ben_semantic_index"
        private const val BATCH_SIZE = 32
        private const val MAX_TEXT = 5_000

        fun enqueue(context: Context, rebuild: Boolean = false) {
            val app = context.applicationContext
            val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (rebuild) prefs.edit().clear().apply()
            val constraints = Constraints.Builder()
                .setRequiresCharging(true)
                .setRequiresBatteryNotLow(true)
                .setRequiresDeviceIdle(true)
                .build()
            val request = OneTimeWorkRequest.Builder(BenSemanticIndexWorker::class.java)
                .setConstraints(constraints)
                .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag(UNIQUE_WORK)
                .build()
            WorkManager.getInstance(app).enqueueUniqueWork(
                UNIQUE_WORK,
                if (rebuild) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
                request
            )
        }
    }
}
