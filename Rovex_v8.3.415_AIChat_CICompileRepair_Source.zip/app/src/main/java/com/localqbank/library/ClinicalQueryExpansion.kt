package com.localqbank.library

/**
 * Bounded, deterministic clinical query expansion used only when ordinary local retrieval
 * has insufficient recall. It is intentionally small and symmetric: it never replaces the
 * user's query and never owns ranking or QBank data.
 */
object ClinicalQueryExpansion {
    private val aliases = mapOf(
        "cervical cancer" to listOf("cervix cancer", "cervical carcinoma", "cervix carcinoma", "carcinoma cervix", "cancer cervix", "cervical malignancy"),
        "cervix cancer" to listOf("cervical cancer", "cervical carcinoma", "carcinoma cervix"),
        "cervical carcinoma" to listOf("cervical cancer", "cervix carcinoma", "carcinoma cervix"),
        "breast cancer" to listOf("breast carcinoma", "mammary carcinoma"),
        "lung cancer" to listOf("lung carcinoma", "bronchogenic carcinoma"),
        "prostate cancer" to listOf("prostate carcinoma", "prostatic carcinoma"),
        "ovarian cancer" to listOf("ovarian carcinoma", "ovary carcinoma"),
        "endometrial cancer" to listOf("endometrial carcinoma", "endometrium carcinoma"),
        "thyroid cancer" to listOf("thyroid carcinoma"),
        "liver cancer" to listOf("hepatocellular carcinoma", "hepatoma"),
        "kidney cancer" to listOf("renal cell carcinoma", "renal carcinoma"),
        "skin cancer" to listOf("cutaneous carcinoma", "skin carcinoma"),
        "stomach cancer" to listOf("gastric cancer", "gastric carcinoma"),
        "colon cancer" to listOf("colorectal cancer", "colonic carcinoma", "colon carcinoma"),
        "rectal cancer" to listOf("rectal carcinoma", "rectal cancer"),
        "blood cancer" to listOf("hematological malignancy", "hematologic malignancy"),
        "heart attack" to listOf("myocardial infarction", "acute myocardial infarction"),
        "stroke" to listOf("cerebrovascular accident", "cva", "cerebral infarction"),
        "high blood pressure" to listOf("hypertension"),
        "low blood pressure" to listOf("hypotension"),
        "high blood sugar" to listOf("hyperglycemia"),
        "low blood sugar" to listOf("hypoglycemia"),
        "heart failure" to listOf("cardiac failure", "congestive heart failure"),
        "kidney failure" to listOf("renal failure", "renal insufficiency"),
        "liver failure" to listOf("hepatic failure"),
        "urinary infection" to listOf("urinary tract infection", "uti"),
        "chest pain" to listOf("angina", "angina pectoris"),
        "shortness of breath" to listOf("dyspnea", "breathlessness"),
        "blood clot" to listOf("thrombus", "thrombosis"),
        "blood poisoning" to listOf("sepsis", "septicemia")
    )

    fun expand(query: String): List<String> {
        val q = ClinicalKnowledgeLayer.normalize(query)
        if (q.length < 2) return emptyList()
        val out = linkedSetOf<String>()
        aliases[q].orEmpty().forEach { out += ClinicalKnowledgeLayer.normalize(it) }
        // Also expand an exact clinical phrase embedded in a longer query, e.g.
        // "cervical cancer screening" -> "cervix cancer screening". This remains bounded and
        // never replaces the original query, so natural-language questions retain their literal
        // retrieval lane while gaining deterministic terminology recall.
        aliases.entries.forEach { (phrase, replacements) ->
            if (q.contains(Regex("\\b${Regex.escape(phrase)}\\b"))) {
                replacements.take(4).forEach { replacement ->
                    val normalizedReplacement = ClinicalKnowledgeLayer.normalize(replacement)
                    val expanded = q.replace(Regex("\\b${Regex.escape(phrase)}\\b"), normalizedReplacement).trim()
                    if (expanded.isNotBlank() && expanded != q) out += expanded
                }
            }
        }
        // Safe singular/plural normalization for simple topic queries.
        if (q.endsWith("ies") && q.length > 5) out += q.dropLast(3) + "y"
        if (q.endsWith("s") && !q.endsWith("ss") && q.length > 4) out += q.dropLast(1)
        return out.filter { it.isNotBlank() && it != q }.take(8)
    }
}
