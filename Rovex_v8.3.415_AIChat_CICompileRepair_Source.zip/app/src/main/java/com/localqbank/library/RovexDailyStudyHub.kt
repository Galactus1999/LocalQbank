package com.localqbank.library

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.CalendarContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Daily Study Hub: local-first planner, study heatmap, streak, and revision-bag shell.
 *
 * Calendar read access is requested only when the user opens the Calendar view. Calendar export
 * uses Android's ACTION_INSERT contract so the installed calendar handler owns account selection
 * and saving; export itself does not require READ_CALENDAR.
 */
object RovexDailyStudyHub {
    private const val PREF = "rovex_daily_study_hub_v304"
    private const val MAX_HEAT = 7
    private const val SLOT_COUNT = 4
    const val CALENDAR_PERMISSION_REQUEST = 3401
    private val slots = arrayOf("QBank Sprint", "PYQ + Error Review", "Flashcard Mix", "Rapid Revision")

    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun key(cal: Calendar = Calendar.getInstance()): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.time)

    fun markStudy(c: Context, amount: Int = 1) {
        val p = prefs(c)
        val k = "heat_" + key()
        val old = p.getInt(k, 0)
        p.edit().putInt(k, (old + max(1, amount)).coerceAtMost(9))
            .putBoolean("day_" + key(), true).apply()
    }

    private fun isStudyDay(c: Context, cal: Calendar): Boolean {
        return prefs(c).getBoolean("day_" + key(cal), false) ||
            prefs(c).getInt("heat_" + key(cal), 0) > 0
    }

    private fun streak(c: Context): Int {
        val cal = Calendar.getInstance()
        var n = 0
        while (n < 365 && isStudyDay(c, cal)) {
            n++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return n
    }

    private fun card(c: Context, index: Int = 0): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ThemeManager.pastelAccentFill(c,index), ThemeManager.elevated(c))).apply {
        cornerRadius = dp(c, 22).toFloat()
        setStroke(dp(c,1), ThemeManager.accent(c))
    }

    private fun text(c: Context, s: String, size: Float, color: Int = ThemeManager.text(c), bold: Boolean = true) = TextView(c).apply {
        text=s;textSize=size;setTextColor(color);if(bold)setTypeface(typeface,1);includeFontPadding=false
    }

    private fun styleDialog(dialog: AlertDialog, c: Context) {
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply{setColor(ThemeManager.dialogBg(c));cornerRadius=dp(c,22).toFloat();setStroke(dp(c,1),ThemeManager.accent(c))})
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(ThemeManager.accent(c))
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ThemeManager.muted(c))
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(ThemeManager.accent(c))
        }
    }

    private fun heatmap(c: Context): View {
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
            background = card(c, 0)
            elevation = dp(c, 7).toFloat()
        }
        val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(text(c, "✦  Daily Progress", 18f), LinearLayout.LayoutParams(0, dp(c, 30), 1f))
        val streakView = text(c, "🔥 — day streak", 13f, ThemeManager.accent(c), true)
        head.addView(streakView)
        box.addView(head)
        box.addView(text(c, "Last 28 days • dot position = accuracy • dot = a day with saved answers", 11.5f, ThemeManager.muted(c), false),
            LinearLayout.LayoutParams(-1, dp(c, 34)).apply { topMargin = dp(c, 2) })

        val summary = text(c, "Loading saved answer history…", 12.5f, ThemeManager.text(c), true)
        box.addView(summary, LinearLayout.LayoutParams(-1, dp(c, 28)).apply { topMargin = dp(c, 3) })

        // Reuse the authoritative 28-day accuracy renderer. The previous GridLayout used weighted
        // zero-width cells, which could measure into seven giant vertical bars on some devices.
        val graph = Last28StudyDaysGraphView(c)
        box.addView(graph, LinearLayout.LayoutParams(-1, dp(c, 190)).apply { topMargin = dp(c, 2) })

        val legend = text(c, "Accuracy: higher dot = better accuracy   •   Solved count is shown in the summary", 10f, ThemeManager.muted(c), false)
        box.addView(legend, LinearLayout.LayoutParams(-1, dp(c, 22)).apply { topMargin = dp(c, 2) })

        if (c is MainActivity) {
            PerformanceManager.submit {
                val snapshot = runCatching { PerformanceManager.progress(c.applicationContext).all().values.filter { it.lastAttempted > 0L && it.status != null } }.getOrNull().orEmpty()
                val now = Calendar.getInstance()
                val days = (27 downTo 0).map { offset ->
                    val day = Calendar.getInstance().apply {
                        timeInMillis = now.timeInMillis
                        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                        add(Calendar.DAY_OF_YEAR, -offset)
                    }
                    val start = day.timeInMillis
                    val end = start + 86_400_000L
                    val rows = snapshot.filter { it.lastAttempted in start until end }
                    Last28StudyDaysGraphView.Day(start, rows.size, rows.count { it.status == "correct" })
                }
                val today = days.last()
                val todayAccuracy = if (today.solved > 0) today.correct * 100 / today.solved else 0
                var streak = 0
                for (day in days.asReversed()) {
                    if (day.solved > 0) streak++ else break
                }
                val attempted28 = days.sumOf { it.solved }
                val correct28 = days.sumOf { it.correct }
                c.runOnUiThread {
                    if (c.isFinishing || c.isDestroyed) return@runOnUiThread
                    graph.setDays(days)
                    streakView.text = "🔥 $streak day streak"
                    summary.text = if (today.solved > 0) {
                        "Today: ${today.solved} solved • ${todayAccuracy}% accuracy   |   28 days: $attempted28 solved • ${if (attempted28 > 0) correct28 * 100 / attempted28 else 0}% accuracy"
                    } else {
                        "Today: no saved answers yet   |   28 days: $attempted28 solved • ${if (attempted28 > 0) correct28 * 100 / attempted28 else 0}% accuracy"
                    }
                }
            }
        }
        return box
    }

    private fun planner(c: MainActivity, flashcards: View?, flashcardsAction: (() -> Unit)? = null): View {
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
            background = card(c, 1)
            elevation = dp(c, 7).toFloat()
        }
        box.addView(text(c, "◈  Today’s Mission", 18f))
        box.addView(text(c, "Plan → revise → log → build the streak", 12f, ThemeManager.muted(c), false),
            LinearLayout.LayoutParams(-1, dp(c, 26)).apply { topMargin = dp(c, 2) })

        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val plan = text(c, "PLAN MY DAY", 12f).apply {
            gravity = Gravity.CENTER
            background = card(c, 0)
            setPadding(dp(c, 8), 0, dp(c, 8), 0)
            setOnClickListener { openPlanner(c) }
        }
        val calendar = text(c, "VIEW CALENDAR", 12f).apply {
            gravity = Gravity.CENTER
            background = card(c, 2)
            setPadding(dp(c, 8), 0, dp(c, 8), 0)
            setOnClickListener { openCalendar(c) }
        }
        val mix = text(c, "MIX REVISION", 12f).apply {
            gravity = Gravity.CENTER
            background = card(c, 3)
            setPadding(dp(c, 8), 0, dp(c, 8), 0)
            setOnClickListener {
                markStudy(c, 1)
                if (flashcardsAction != null) flashcardsAction.invoke() else c.startActivity(Intent(c, FlashcardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }
        }
        row.addView(plan, LinearLayout.LayoutParams(0, dp(c, 48), 1f).apply { rightMargin = dp(c, 4) })
        row.addView(calendar, LinearLayout.LayoutParams(0, dp(c, 48), 1f).apply { leftMargin = dp(c, 4); rightMargin = dp(c, 4) })
        row.addView(mix, LinearLayout.LayoutParams(0, dp(c, 48), 1f).apply { leftMargin = dp(c, 4) })
        box.addView(row, LinearLayout.LayoutParams(-1, dp(c, 54)).apply { topMargin = dp(c, 8) })

        val log = text(c, "✓  LOG TODAY'S STUDY", 12f).apply {
            gravity = Gravity.CENTER
            background = card(c, 3)
            setOnClickListener { markStudy(c, 1); Toast.makeText(c, "Study day logged • streak updated", Toast.LENGTH_SHORT).show() }
        }
        box.addView(log, LinearLayout.LayoutParams(-1, dp(c, 44)).apply { topMargin = dp(c, 7) })
        return box
    }

    private fun openCalendar(c: MainActivity) {
        if (android.os.Build.VERSION.SDK_INT >= 23 && c.checkSelfPermission(android.Manifest.permission.READ_CALENDAR) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            c.requestPermissions(arrayOf(android.Manifest.permission.READ_CALENDAR), CALENDAR_PERMISSION_REQUEST)
            return
        }
        showCalendarEvents(c)
    }

    fun onCalendarPermissionResult(c: MainActivity, grantResults: IntArray) {
        if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) showCalendarEvents(c)
        else Toast.makeText(c, "Calendar access was not granted. Rovex can still export plans to your calendar app.", Toast.LENGTH_LONG).show()
    }

    private fun showCalendarEvents(ctx: MainActivity) {
        val now = Calendar.getInstance()
        val start = (now.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val end = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val events = mutableListOf<Triple<Long,Long,String>>()
        val resolver = ctx.contentResolver
        val projection = arrayOf(CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.TITLE, CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.CALENDAR_ID)
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(builder, start)
        android.content.ContentUris.appendId(builder, end)
        runCatching {
            resolver.query(builder.build(), projection, null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { cur ->
                val beginIx=cur.getColumnIndex(CalendarContract.Instances.BEGIN)
                val endIx=cur.getColumnIndex(CalendarContract.Instances.END)
                val titleIx=cur.getColumnIndex(CalendarContract.Instances.TITLE)
                val locIx=cur.getColumnIndex(CalendarContract.Instances.EVENT_LOCATION)
                while(cur.moveToNext()) {
                    val title=cur.getString(titleIx).orEmpty().ifBlank { "Untitled event" }
                    val loc=if(locIx>=0) cur.getString(locIx).orEmpty() else ""
                    events.add(Triple(cur.getLong(beginIx),cur.getLong(endIx),if(loc.isBlank()) title else "$title  •  $loc"))
                }
            }
        }.onFailure {
            RovexUndoSnackbar.show((ctx as MainActivity).window.decorView,"Could not read calendar: " + (it.message ?: "unknown error"))
            return
        }
        val body=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(ctx, 18),0,dp(ctx, 18),dp(ctx, 4))}
        if(events.isEmpty()) body.addView(text(ctx,"No calendar events found for today. If your Google Calendar is synced on this device, its events will appear here after calendar access is granted.",13f,ThemeManager.text(ctx),false).apply{setPadding(0,dp(ctx, 8),0,dp(ctx, 8))})
        else {
            val fmt=SimpleDateFormat("HH:mm",Locale.getDefault())
            events.take(30).forEach { (b,e,title) ->
                val line=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(ctx, 12),dp(ctx, 9),dp(ctx, 12),dp(ctx, 9));background=card(ctx,0)}
                line.addView(text(ctx,fmt.format(java.util.Date(b))+"–"+fmt.format(java.util.Date(e)),11f,ThemeManager.accent(ctx),true))
                line.addView(text(ctx,title,13f,ThemeManager.text(ctx),true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(ctx, 3)})
                body.addView(line,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(ctx, 6)})
            }
        }
        val dialog=AlertDialog.Builder(ctx).setTitle("Today's Calendar").setView(body).setNegativeButton("Close",null).setPositiveButton("Refresh",null).create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply{setColor(ThemeManager.dialogBg(ctx));cornerRadius=dp(ctx,22).toFloat();setStroke(dp(ctx,1),ThemeManager.accent(ctx))})
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(ThemeManager.accent(ctx));setOnClickListener{dialog.dismiss();showCalendarEvents(ctx)}}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ThemeManager.muted(ctx))
        }
        dialog.show()
    }

    private fun openPlanner(c: MainActivity) {
        val holder = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 18), dp(c, 4), dp(c, 18), 0)
        }
        val fields = ArrayList<EditText>()
        val defaults = arrayOf("07:00  •  QBank Sprint", "10:30  •  PYQ + Error Review", "15:00  •  Flashcard Mix", "20:00  •  Rapid Revision")
        for (i in 0 until SLOT_COUNT) {
            val e = EditText(c).apply {
                setSingleLine(true)
                textSize = 14f
                setText(prefs(c).getString("slot_$i", defaults[i]))
                hint = "Time  •  Study block"
                setTextColor(ThemeManager.text(c))
            }
            fields.add(e)
            holder.addView(e, LinearLayout.LayoutParams(-1, dp(c, 48)).apply { topMargin = dp(c, 2) })
        }
        val dialog = AlertDialog.Builder(c)
            .setTitle("Daily Schedule Planner")
            .setMessage("Create your study plan, then view today’s synced calendar schedule inside Rovex or export a plan block to your calendar app. Google Calendar events appear when Google Calendar is synced on this device and calendar access is granted.")
            .setView(holder)
            .setNegativeButton("Close", null)
            .setPositiveButton("Save Plan") { _, _ ->
                val ed = prefs(c).edit()
                fields.forEachIndexed { i, e -> ed.putString("slot_$i", e.text.toString().trim()) }
                ed.apply()
                Toast.makeText(c, "Today's plan saved", Toast.LENGTH_SHORT).show()
            }
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply{setColor(ThemeManager.dialogBg(c));cornerRadius=dp(c,22).toFloat();setStroke(dp(c,1),ThemeManager.accent(c))})
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ThemeManager.muted(c))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(ThemeManager.accent(c))
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(ThemeManager.accent(c))
            val sync = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
            if (sync != null) sync.setText("Calendar")
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val ed = prefs(c).edit()
                fields.forEachIndexed { i, e -> ed.putString("slot_$i", e.text.toString().trim()) }
                ed.apply()
                dialog.dismiss()
                exportFirstCalendarBlock(c)
            }
        }
        dialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Calendar") { _, _ -> exportFirstCalendarBlock(c) }
        dialog.show()
    }

    private fun exportFirstCalendarBlock(c: MainActivity) {
        val raw = prefs(c).getString("slot_0", "07:00  •  QBank Sprint") ?: "07:00  •  QBank Sprint"
        val parts = raw.split("•", limit = 2)
        val time = parts.first().trim()
        val title = if (parts.size > 1) parts[1].trim() else raw
        val hm = time.split(":", limit = 2)
        val cal = Calendar.getInstance()
        if (hm.size == 2) {
            cal.set(Calendar.HOUR_OF_DAY, hm[0].toIntOrNull()?.coerceIn(0,23) ?: 7)
            cal.set(Calendar.MINUTE, hm[1].toIntOrNull()?.coerceIn(0,59) ?: 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
        }
        val begin = cal.timeInMillis
        val end = begin + 60L * 60L * 1000L
        val insert = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, "Rovex • $title")
            putExtra(CalendarContract.Events.DESCRIPTION, "Rovex daily study plan")
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
        }
        val resolver = c.packageManager
        if (insert.resolveActivity(resolver) != null) {
            c.startActivity(Intent.createChooser(insert, "Add Rovex study block to calendar"))
            return
        }
        val calendarApp = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
        if (calendarApp.resolveActivity(resolver) != null) {
            c.startActivity(calendarApp)
        } else {
            RovexUndoSnackbar.show(c.window.decorView, "No calendar app can handle calendar actions on this device")
        }
    }

    fun install(c: MainActivity, content: LinearLayout, flashcards: View?, flashcardsAction: (() -> Unit)? = null) {
        if (content.findViewWithTag<View>("ROVEX_DAILY_HUB_304") != null) return
        val wrap = LinearLayout(c).apply {
            tag = "ROVEX_DAILY_HUB_304"
            orientation = LinearLayout.VERTICAL
        }
        wrap.addView(heatmap(c), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, 12) })
        wrap.addView(planner(c, flashcards, flashcardsAction), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, 15) })
        content.addView(wrap, content.indexOfChild(content.findViewWithTag<View>("ROVEX_DAILY_HUB_ANCHOR")).takeIf { it >= 0 }
            ?.let { LinearLayout.LayoutParams(-1, -2) } ?: LinearLayout.LayoutParams(-1, -2))
    }
}
