package com.localqbank.library

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small Notes-domain store for AI answers that are not tied to a specific QBank question. */
class AiNoteRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("ai_notes", Context.MODE_PRIVATE)
    data class Item(val id: Long, val title: String, val body: String, val updatedAt: Long)
    fun items(): List<Item> = runCatching {
        val a=JSONArray(prefs.getString("items", "[]"))
        buildList { for(i in 0 until a.length()){ val o=a.getJSONObject(i); add(Item(o.optLong("id"),o.optString("title"),o.optString("body"),o.optLong("updatedAt"))) } }.sortedByDescending{it.updatedAt}
    }.getOrDefault(emptyList())
    fun save(title:String, body:String){
        val now=System.currentTimeMillis(); val list=items().filterNot{it.title==title}.toMutableList(); list.add(0,Item(now,title,body.take(64_000),now));
        val a=JSONArray(); list.take(100).forEach{a.put(JSONObject().apply{put("id",it.id);put("title",it.title);put("body",it.body);put("updatedAt",it.updatedAt)})}; prefs.edit().putString("items",a.toString()).apply()
    }
}
