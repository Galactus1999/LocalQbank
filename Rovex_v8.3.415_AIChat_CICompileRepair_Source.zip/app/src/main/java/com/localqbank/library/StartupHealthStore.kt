package com.localqbank.library

import android.content.Context

class StartupHealthStore(context:Context){
    private val prefs=context.applicationContext.getSharedPreferences("startup_health",Context.MODE_PRIVATE)
    data class Snapshot(val healthy:Boolean,val failed:Int,val durationMs:Long,val launchToInteractiveMs:Long=0L)
    fun save(report:StartupHealthReport){prefs.edit().putLong("last_ms",report.durationMs).putBoolean("healthy",report.healthy).putInt("failed",report.failed).apply()}
    fun markColdLaunchStart(nowMs:Long=android.os.SystemClock.elapsedRealtime()){prefs.edit().putLong("cold_start_ms",nowMs).apply()}
    fun markInteractive(context:Context,nowMs:Long=android.os.SystemClock.elapsedRealtime()){
        val start=prefs.getLong("cold_start_ms",0L)
        if(start<=0L)return
        val elapsed=(nowMs-start).coerceAtLeast(0L)
        prefs.edit().putLong("last_interactive_ms",elapsed).remove("cold_start_ms").apply()
        if(BuildConfig.DEBUG){
            val splashBudget=RovexSplashView.DURATION_MS.toLong()
            val initMs=(elapsed-splashBudget).coerceAtLeast(0L)
            if(initMs>1200L){
                val message="STARTUP_BUDGET_WARN init=${initMs}ms (interactive=${elapsed}ms, splash=${splashBudget}ms, budget=1200ms)"
                android.util.Log.w("RovexStartup",message)
                ProductionCrashReporter.breadcrumb(context,message)
            } else {
                android.util.Log.d("RovexStartup","STARTUP_BUDGET_OK init=${initMs}ms")
            }
        }
    }
    fun snapshot()=Snapshot(prefs.getBoolean("healthy",true),prefs.getInt("failed",0),prefs.getLong("last_ms",0L),prefs.getLong("last_interactive_ms",0L))
}
