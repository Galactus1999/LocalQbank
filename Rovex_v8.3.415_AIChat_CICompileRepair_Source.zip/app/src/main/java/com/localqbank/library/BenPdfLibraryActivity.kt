package com.localqbank.library

import android.app.Activity
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

/**
 * Small PDF library surface. Disk enumeration, PDF page rendering and deletion are deliberately
 * kept off the UI thread because PdfRenderer/Bitmap work can be surprisingly expensive for large
 * reference PDFs. The UI only receives immutable filenames/bitmaps.
 */
class BenPdfLibraryActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 16) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(TextView(this).apply { text = "‹"; textSize = 30f; setOnClickListener { finish() } }, LinearLayout.LayoutParams(42, 48))
        bar.addView(TextView(this).apply { text = "Imported PDFs"; textSize = 20f; setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(bar)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh(list)
    }

    private fun refresh(list: LinearLayout) {
        val generation = System.nanoTime()
        PerformanceManager.submitMaintenance {
            val dir = File(filesDir, "ben_pdf_corpus")
            val fs = dir.listFiles { f -> f.extension.equals("pdf", true) }
                ?.sortedByDescending { it.lastModified() }.orEmpty()
            val names = fs.map { it.absolutePath to it.name.substringAfter("_").removeSuffix(".pdf").replace("_", " ") }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                list.removeAllViews()
                if (names.isEmpty()) {
                    list.addView(TextView(this).apply { text = "No PDFs imported yet."; textSize = 15f; setPadding(8, 24, 8, 24) })
                    return@runOnUiThread
                }
                names.forEach { (path, label) ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    row.addView(TextView(this@BenPdfLibraryActivity).apply { text = label; textSize = 14f }, LinearLayout.LayoutParams(0, 58, 1f))
                    row.addView(TextView(this@BenPdfLibraryActivity).apply {
                        text = "OPEN"; gravity = Gravity.CENTER
                        setOnClickListener { open(File(path)) }
                    }, LinearLayout.LayoutParams(68, 44))
                    row.addView(TextView(this@BenPdfLibraryActivity).apply {
                        text = "DELETE"; gravity = Gravity.CENTER
                        setOnClickListener {
                            val target = File(path)
                            PerformanceManager.submitMaintenance {
                                val deleted = runCatching {
                                    val ok = !target.exists() || target.delete()
                                    if (ok) File(target.parentFile, target.nameWithoutExtension + ".txt").delete()
                                    ok
                                }.getOrDefault(false)
                                runOnUiThread {
                                    if (!isFinishing && !isDestroyed && deleted) refresh(list)
                                }
                            }
                        }
                    }, LinearLayout.LayoutParams(72, 44))
                    list.addView(row)
                }
            }
        }
    }

    private fun open(file: File) {
        if (!file.isFile) return
        val d = Dialog(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8) }
        val image = ImageView(this).apply { adjustViewBounds = true }
        var page = 0
        val generation = java.util.concurrent.atomic.AtomicLong(0)

        fun render() {
            val serial = generation.incrementAndGet()
            val requestedPage = page
            PerformanceManager.submitMaintenance {
                val bitmap = runCatching {
                    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                        PdfRenderer(pfd).use { renderer ->
                            if (requestedPage !in 0 until renderer.pageCount) return@runCatching null
                            renderer.openPage(requestedPage).use { pg ->
                                // Bound the bitmap so a large medical PDF page cannot allocate an
                                // enormous ARGB buffer merely because the source page is huge.
                                val maxDim = 2048
                                val scale = minOf(1f, maxDim.toFloat() / maxOf(pg.width, pg.height).toFloat())
                                val w = (pg.width * scale).toInt().coerceAtLeast(1)
                                val h = (pg.height * scale).toInt().coerceAtLeast(1)
                                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bm ->
                                    pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                }
                            }
                        }
                    }
                }.getOrNull()
                runOnUiThread {
                    if (isFinishing || isDestroyed || serial != generation.get()) {
                        bitmap?.recycle()
                        return@runOnUiThread
                    }
                    if (bitmap != null) image.setImageBitmap(bitmap)
                }
            }
        }

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        controls.addView(TextView(this).apply {
            text = "‹"; textSize = 26f; setPadding(24, 4, 24, 4)
            setOnClickListener { if (page > 0) { page--; render() } }
        })
        controls.addView(TextView(this).apply {
            text = "›"; textSize = 26f; setPadding(24, 4, 24, 4)
            setOnClickListener {
                PerformanceManager.submitMaintenance {
                    val n = runCatching { ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { PdfRenderer(it).pageCount } }.getOrDefault(page + 1)
                    runOnUiThread { if (!isFinishing && !isDestroyed && page + 1 < n) { page++; render() } }
                }
            }
        })
        box.addView(image, LinearLayout.LayoutParams(-1, 0, 1f)); box.addView(controls)
        d.setContentView(box); d.show(); d.window?.setLayout(-1, -1)
        d.setOnDismissListener { generation.incrementAndGet(); image.setImageDrawable(null) }
        render()
    }
}
