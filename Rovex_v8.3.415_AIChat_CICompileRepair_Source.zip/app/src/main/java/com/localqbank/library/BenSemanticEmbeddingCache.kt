package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/**
 * Persistent EmbeddingGemma document-vector cache owned by the isolated inference process.
 *
 * The cache is keyed by model/tokenizer identity + document content hash, so imported/edited
 * text can never accidentally reuse a vector from an older model or stale document. It stores
 * only vectors, never authoritative QBank content. The canonical corpus remains QBankDb.
 *
 * This is intentionally a cache, not a second retrieval database: query recall remains
 * deterministic FTS/knowledge-index recall, while repeated semantic reranks avoid re-running
 * EmbeddingGemma for unchanged candidates.
 */
class BenSemanticEmbeddingCache(context: Context) {
    private val helper = Helper(context.applicationContext)

    data class Vector(val values: FloatArray)

    fun get(key: String): FloatArray? = runCatching {
        helper.writableDatabase.rawQuery(
            "SELECT vector FROM embedding_cache WHERE cache_key=? LIMIT 1",
            arrayOf(key)
        ).use { c ->
            if (!c.moveToFirst()) return@use null
            decode(c.getBlob(0))
        }
    }.getOrNull()

    fun put(key: String, vector: FloatArray) {
        if (vector.isEmpty() || vector.any { !it.isFinite() }) return
        runCatching {
            val db = helper.writableDatabase
            db.execSQL(
                "INSERT OR REPLACE INTO embedding_cache(cache_key,vector,dimension,updated_at) VALUES(?,?,?,?)",
                arrayOf(key, encode(vector), vector.size, System.currentTimeMillis())
            )
            // Bounded cache: old vectors are useful less often and must not consume unbounded app storage.
            val excess = db.rawQuery("SELECT COUNT(*) FROM embedding_cache", null).use { c ->
                if (c.moveToFirst()) (c.getLong(0) - MAX_ENTRIES).coerceAtLeast(0L) else 0L
            }
            if (excess > 0) {
                db.execSQL(
                    "DELETE FROM embedding_cache WHERE cache_key IN (SELECT cache_key FROM embedding_cache ORDER BY updated_at ASC LIMIT ?)",
                    arrayOf(excess)
                )
            }
        }
    }

    fun clear() = runCatching { helper.writableDatabase.delete("embedding_cache", null, null) }.isSuccess

    fun stats(): Pair<Long, Long> = runCatching {
        helper.writableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(LENGTH(vector)),0) FROM embedding_cache", null
        ).use { c ->
            if (c.moveToFirst()) c.getLong(0) to c.getLong(1) else 0L to 0L
        }
    }.getOrDefault(0L to 0L)

    companion object {
        private const val DB_NAME = "ben_semantic_cache.db"
        private const val DB_VERSION = 1
        private const val MAX_ENTRIES = 5_000

        fun key(modelSha: String, tokenizerSha: String, text: String): String {
            val canonical = modelSha + "\u0000" + tokenizerSha + "\u0000" + text.trim()
            val digest = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
            return digest.joinToString("") { "%02x".format(it) }
        }

        private fun encode(vector: FloatArray): ByteArray {
            val out = ByteBuffer.allocate(4 + vector.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            out.putInt(vector.size)
            vector.forEach(out::putFloat)
            return out.array()
        }

        private fun decode(blob: ByteArray): FloatArray? {
            if (blob.size < 4) return null
            val b = ByteBuffer.wrap(blob).order(ByteOrder.LITTLE_ENDIAN)
            val n = b.int
            if (n <= 0 || n > 4096 || blob.size != 4 + n * 4) return null
            return FloatArray(n) { b.float }.takeIf { it.all(Float::isFinite) }
        }
    }

    private class Helper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onConfigure(db: SQLiteDatabase) {
            super.onConfigure(db)
            db.enableWriteAheadLogging()
        }
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS embedding_cache(cache_key TEXT PRIMARY KEY NOT NULL, vector BLOB NOT NULL, dimension INTEGER NOT NULL, updated_at INTEGER NOT NULL)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_embedding_cache_updated ON embedding_cache(updated_at)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { onCreate(db) }
    }
}
