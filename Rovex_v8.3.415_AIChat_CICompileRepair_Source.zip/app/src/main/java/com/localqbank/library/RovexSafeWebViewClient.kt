package com.localqbank.library

import android.util.Log
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Common renderer-process containment for every Rovex WebView.
 *
 * Chromium runs outside the app process. Android explicitly requires handling renderer
 * termination; otherwise a renderer crash/LMK event can take down the foreground app.
 * The dead WebView is never reused: it is detached, stopped and destroyed, and the app
 * remains alive. The host screen can render its normal fallback/empty state.
 */
open class RovexSafeWebViewClient : WebViewClient() {
    override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
        val crashed = runCatching { detail?.didCrash() ?: false }.getOrDefault(false)
        Log.w("Rovex.WebView", "renderer terminated crashed=$crashed")
        if (view != null) {
            runCatching { (view.parent as? ViewGroup)?.removeView(view) }
            runCatching { view.stopLoading() }
            runCatching { view.destroy() }
        }
        ProductionCrashReporter.breadcrumb(
            RovexApplicationContextHolder.context,
            "webview_renderer_terminated:${if (crashed) "crash" else "reclaimed"}"
        )
        return true
    }
}
