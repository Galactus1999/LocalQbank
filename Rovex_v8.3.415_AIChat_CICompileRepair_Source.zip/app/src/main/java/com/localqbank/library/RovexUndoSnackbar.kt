package com.localqbank.library

import android.view.View
import com.google.android.material.snackbar.Snackbar

/** Single Material error/action surface used by user-facing recoverable failures. */
object RovexUndoSnackbar {
    fun show(
        anchor: View,
        message: String,
        actionLabel: String? = null,
        duration: Int = if (actionLabel == null) Snackbar.LENGTH_LONG else Snackbar.LENGTH_INDEFINITE,
        action: (() -> Unit)? = null
    ) {
        val bar = Snackbar.make(anchor, message.take(220), duration)
        if (!actionLabel.isNullOrBlank() && action != null) {
            bar.setAction(actionLabel) { action() }
        }
        bar.setTextMaxLines(3).show()
    }
}
