package com.localqbank.library

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.recyclerview.widget.RecyclerView
import android.widget.ScrollView
import android.widget.HorizontalScrollView
import android.view.animation.OvershootInterpolator
import android.animation.ValueAnimator
import kotlin.math.min

/** Shared, bounded motion primitives. They never own navigation/business state. */
object AliveMotion {
    private const val PRESS_SCALE = 0.96f
    private const val PRESS_MS = 85L
    private const val RELEASE_MS = 180L

    fun install(view: View) {
        if (!view.isClickable || !view.isEnabled) return
        // Never replace a bespoke touch/scroll handler on complex interactive surfaces.
        // Press feedback belongs on actual click targets, not WebViews/scroll containers.
        if (view is WebView || view is RecyclerView || view is ScrollView || view is HorizontalScrollView) return
        if (view.id == com.localqbank.library.R.id.rovexPersistentBottomNavigation ||
            view.getTag()?.toString()?.startsWith("rovex_bottom_navigation") == true) return
        if (view.getTag(com.localqbank.library.R.id.rovexMotionInstalled) == true) return
        view.setTag(com.localqbank.library.R.id.rovexMotionInstalled, true)
        view.isHapticFeedbackEnabled = true
        view.setOnTouchListener { v, event ->
            if (!v.isEnabled || !v.isClickable) return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().cancel()
                    v.animate().scaleX(PRESS_SCALE).scaleY(PRESS_SCALE)
                        .setDuration(PRESS_MS).setInterpolator(OvershootInterpolator(1.15f)).start()
                    runCatching { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().cancel()
                    v.animate().scaleX(1f).scaleY(1f)
                        .setDuration(RELEASE_MS).setInterpolator(OvershootInterpolator(1.15f)).start()
                }
            }
            false
        }
    }

    fun installTree(root: View) {
        if (root.isClickable && root.isEnabled) install(root)
        if (root is ViewGroup) for (i in 0 until root.childCount) installTree(root.getChildAt(i))
    }
}

/** Reusable amber radial feedback extracted from the splash visual language. */
object RovexPulseEffect {
    private const val DURATION_MS = 260L
    private const val MAX_ALPHA = 190

    fun drawRadialFlash(canvas: Canvas, cx: Float, cy: Float, radius: Float, alpha: Int) {
        if (alpha <= 0 || radius <= 0f) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = min(3.5f, radius * 0.12f).coerceAtLeast(1f)
            color = Color.argb(alpha.coerceIn(0, 255), 255, 178, 56)
            setShadowLayer(radius * 0.35f, 0f, 0f, Color.argb((alpha * 0.7f).toInt().coerceIn(0, 255), 255, 178, 56))
        }
        canvas.drawCircle(cx, cy, radius, paint)
        paint.clearShadowLayer()
    }

    fun play(view: View) {
        if (!view.isAttachedToWindow || view.width <= 0 || view.height <= 0) return
        runCatching { view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
        val drawable = PulseDrawable(view)
        view.overlay.add(drawable)
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = DURATION_MS
            interpolator = android.view.animation.DecelerateInterpolator()
            addUpdateListener { animator ->
                drawable.progress = animator.animatedValue as Float
                view.invalidate()
            }
            doOnEndCompat { view.overlay.remove(drawable); view.invalidate() }
            start()
        }
    }

    fun shake(view: View) {
        runCatching { view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
        val d = view.resources.displayMetrics.density
        val x = 3.5f * d
        view.animate().cancel()
        view.animate().translationX(x).setDuration(35L).withEndAction {
            view.animate().translationX(-x).setDuration(35L).withEndAction {
                view.animate().translationX(x * 0.55f).setDuration(30L).withEndAction {
                    view.animate().translationX(0f).setDuration(50L).start()
                }.start()
            }.start()
        }.start()
    }

    private class PulseDrawable(private val target: View) : android.graphics.drawable.Drawable() {
        var progress = 0f
        init { setBounds(0, 0, target.width, target.height) }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(canvas: Canvas) {
            val inset = min(target.width, target.height) * 0.08f
            val cx = target.width * 0.5f
            val cy = target.height * 0.5f
            val maxR = min(target.width, target.height) * 0.62f
            val r = inset + maxR * progress
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = (3.2f * target.resources.displayMetrics.density * (1f - progress * 0.45f)).coerceAtLeast(1f)
            paint.color = Color.argb((MAX_ALPHA * (1f - progress)).toInt(), 255, 178, 56)
            paint.setShadowLayer(10f * (1f - progress), 0f, 0f, Color.argb((110 * (1f - progress)).toInt(), 255, 178, 56))
            canvas.drawCircle(cx, cy, r, paint)
            paint.clearShadowLayer()
        }
        override fun setAlpha(alpha: Int) { }
        override fun setColorFilter(filter: android.graphics.ColorFilter?) { }
        override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun ValueAnimator.doOnEndCompat(action: () -> Unit) {
        addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) = action()
            override fun onAnimationCancel(animation: android.animation.Animator) = action()
        })
    }
}
