package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * Compact living Rovex energy emblem for the Home header.
 *
 * The supplied launcher artwork is used as the authoritative logo. This view adds
 * a lightweight procedural energy layer: flowing colour pulses, breathing glow and
 * continuous outward electrical discharges. It never blocks the UI thread and
 * stops its animation when detached/invisible.
 */
class RovexEnergyLogoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val logo = BitmapFactory.decodeResource(resources, R.drawable.rovex_app_logo)
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var started = 0L
    private var running = false

    private val boltAngles = floatArrayOf(
        -2.82f, -2.38f, -1.92f, -1.48f, -1.05f,
        -0.63f, -0.18f, 0.25f, 0.68f, 1.10f,
        1.54f, 1.94f, 2.38f, 2.78f
    )

    private val cyan = Color.rgb(55, 226, 255)
    private val violet = Color.rgb(153, 72, 255)
    private val magenta = Color.rgb(244, 67, 255)

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        started = SystemClock.uptimeMillis()
        running = true
        postInvalidateOnAnimation()
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        running = visibility == View.VISIBLE
        if (running) postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val now = SystemClock.uptimeMillis()
        val t = ((now - started).coerceAtLeast(0L) % 7200L) / 7200f
        val pulse = 0.5f + 0.5f * sin(t * Math.PI * 2.0).toFloat()

        val size = minOf(w, h) * 0.78f
        val left = (w - size) * 0.5f
        val top = (h - size) * 0.5f
        val dst = RectF(left, top, left + size, top + size)

        // Outer breathing aura.
        val cx = w * 0.5f
        val cy = h * 0.5f
        val radius = size * (0.47f + 0.025f * pulse)
        glowPaint.shader = RadialGradient(
            cx, cy, radius * 1.55f,
            intArrayOf(
                Color.argb((58 + 28 * pulse).toInt(), 60, 210, 255),
                Color.argb((34 + 28 * pulse).toInt(), 155, 70, 255),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.62f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 1.55f, glowPaint)
        glowPaint.shader = null

        // Flowing colour sweep around the emblem.
        boltPaint.strokeWidth = maxOf(1.2f, size * 0.018f)
        boltPaint.color = Color.argb(155, 90, 220, 255)
        canvas.drawArc(
            RectF(left - size * 0.055f, top - size * 0.055f, left + size * 1.055f, top + size * 1.055f),
            -80f + t * 360f, 92f, false, boltPaint
        )
        boltPaint.color = Color.argb(145, 185, 75, 255)
        canvas.drawArc(
            RectF(left - size * 0.075f, top - size * 0.075f, left + size * 1.075f, top + size * 1.075f),
            105f + t * 360f, 82f, false, boltPaint
        )

        // Authoritative supplied artwork plus a moving colour-energy sweep.
        canvas.saveLayer(dst, null)
        imagePaint.alpha = 255
        imagePaint.shader = null
        imagePaint.xfermode = null
        canvas.drawBitmap(logo, null, dst, imagePaint)
        val sweepX = left - size + ((t * 2.4f) % 2.4f) * size
        imagePaint.shader = LinearGradient(
            sweepX, top, sweepX + size * 0.48f, top + size,
            intArrayOf(Color.TRANSPARENT, Color.argb(58, 80, 235, 255), Color.argb(52, 185, 75, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 0.38f, 0.68f, 1f),
            Shader.TileMode.CLAMP
        )
        imagePaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        canvas.drawRect(dst, imagePaint)
        imagePaint.shader = null
        imagePaint.xfermode = null
        canvas.restore()

        // Continuous electrical expulsion.
        for (i in boltAngles.indices) {
            val angle = boltAngles[i] + sin(t * Math.PI * 2.0 + i * 0.71).toFloat() * 0.055f
            val baseR = size * (0.42f + 0.02f * sin(i * 1.7 + t * 6.0).toFloat())
            val length = size * (0.07f + 0.045f * (0.5f + 0.5f * sin(t * Math.PI * 4.0 + i)).toFloat())
            val x0 = cx + cos(angle) * baseR
            val y0 = cy + sin(angle) * baseR
            val x1 = cx + cos(angle) * (baseR + length)
            val y1 = cy + sin(angle) * (baseR + length)

            val path = Path()
            path.moveTo(x0, y0)
            val segments = 4
            for (s in 1..segments) {
                val f = s / segments.toFloat()
                val px = x0 + (x1 - x0) * f
                val py = y0 + (y1 - y0) * f
                val normalX = -sin(angle)
                val normalY = cos(angle)
                val jitter = sin(i * 2.1 + s * 3.7 + t * Math.PI * 12.0).toFloat() * size * 0.012f
                path.lineTo(px + normalX * jitter, py + normalY * jitter)
            }

            val c = if (i % 2 == 0) cyan else violet
            boltPaint.color = Color.argb((125 + 90 * pulse).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
            boltPaint.strokeWidth = maxOf(1f, size * 0.014f)
            boltPaint.setShadowLayer(size * 0.045f, 0f, 0f, Color.argb(170, Color.red(c), Color.green(c), Color.blue(c)))
            canvas.drawPath(path, boltPaint)
            boltPaint.clearShadowLayer()

            if ((i + (t * 14f).toInt()) % 4 == 0) {
                pulsePaint.color = Color.argb(225, Color.red(magenta), Color.green(magenta), Color.blue(magenta))
                canvas.drawCircle(x1, y1, maxOf(1.2f, size * 0.018f), pulsePaint)
            }
        }

        if (running) postInvalidateOnAnimation()
    }
}
