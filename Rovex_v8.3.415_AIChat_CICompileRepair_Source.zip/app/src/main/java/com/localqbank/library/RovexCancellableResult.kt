package com.localqbank.library

import kotlinx.coroutines.CancellationException

/**
 * Result helper for coroutine-aware failure boundaries.
 * Cancellation is control flow, not an application failure, so it must never be
 * converted into a fallback Result/empty state.
 */
inline fun <T> resultOf(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (cancel: CancellationException) {
    throw cancel
} catch (error: Throwable) {
    Result.failure(error)
}
