package com.localqbank.library

import androidx.activity.ComponentActivity
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Owns only the asynchronous answer interaction seam. QuizActivity remains the presentation owner;
 * this controller prevents synchronous SQLite work from running on the tap frame and converts
 * persistence failures into a retryable UI state instead of an Activity crash.
 */
class QuizAnswerInteractionController(
    private val activity: ComponentActivity,
    private val viewModel: QuizViewModel,
    private val recordCurrentTime: () -> Unit,
    private val contentProvider: () -> ViewGroup,
    private val onAccepted: (Question, String, QuizAnswerUseCase.Result) -> Unit
) {
    private var inProgress = false

    fun submit(question: Question, label: String) {
        if (inProgress) return
        inProgress = true
        setOptionsEnabled(false)
        val practiceMode = viewModel.state.practiceMode
        val examMode = viewModel.state.examMode
        activity.lifecycleScope.launch(Dispatchers.IO) {
            val outcome = runCatching {
                recordCurrentTime()
                viewModel.answer(question, label, practiceMode, examMode)
            }
            activity.runOnUiThread {
                inProgress = false
                if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                val result = outcome.getOrNull()
                if (result == null) {
                    android.util.Log.e("Rovex.Quiz", "Answer commit failed", outcome.exceptionOrNull())
                    setOptionsEnabled(true)
                    RovexUndoSnackbar.show(contentProvider(), "Answer could not be saved.", "RETRY") { submit(question, label) }
                    return@runOnUiThread
                }
                if (result.accepted) onAccepted(question, label, result)
            }
        }
    }

    private fun setOptionsEnabled(enabled: Boolean) {
        val content = contentProvider()
        for (i in 0 until content.childCount) {
            val row = content.getChildAt(i)
            if (row.tag?.toString()?.startsWith("option:") == true) {
                row.isClickable = enabled
                row.isFocusable = enabled
            }
        }
    }
}
