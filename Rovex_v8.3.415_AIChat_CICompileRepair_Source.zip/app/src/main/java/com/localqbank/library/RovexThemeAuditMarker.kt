package com.localqbank.library
object RovexThemeAuditMarker { const val SYSTEM="ROVEX_UI_302"; const val USER_THEMES="LIGHT,PASTEL,MINT,SUNSET,LAVENDER,AMOLED" }