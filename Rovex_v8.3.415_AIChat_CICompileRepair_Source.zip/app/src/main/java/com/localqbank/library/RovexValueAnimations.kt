package com.localqbank.library

import android.animation.ValueAnimator
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.TextView

/** Shared bounded count/fill animation with per-view last-value suppression. */
object RovexValueAnimations {
    private const val TAG_LAST = "rovex_value_animation_last"

    fun TextView.animateCountTo(target: Int, suffix: String = "", duration: Long = 500L) {
        animateInt(this, "default", target, duration) { value -> text = "$value$suffix" }
    }

    fun animateInt(view: View, key: String, target: Int, duration: Long = 500L, render: (Int) -> Unit) {
        @Suppress("UNCHECKED_CAST")
        val state = (view.getTag(R.id.rovex_animation_value) as? MutableMap<String, Int>) ?: mutableMapOf<String, Int>().also { view.setTag(R.id.rovex_animation_value, it) }
        val last = state["target:$key"]
        if (last == target) { render(target); return }
        state["target:$key"] = target
        val from = state["display:$key"] ?: 0
        ValueAnimator.ofInt(from, target).apply {
            this.duration = duration.coerceIn(250L, 650L)
            interpolator = DecelerateInterpolator()
            addUpdateListener { value -> val v=value.animatedValue as Int; state["display:$key"] = v; render(v) }
            start()
        }
    }
}
