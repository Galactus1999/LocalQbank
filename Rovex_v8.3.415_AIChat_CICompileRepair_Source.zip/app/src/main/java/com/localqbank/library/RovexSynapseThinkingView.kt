package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Compact procedural neural-pulse indicator for Ben inference. */
class RovexSynapseThinkingView(context: Context) : View(context) {
    private data class Node(val angle: Float, val radius: Float, val phase: Float)
    private val nodes = List(12) { i ->
        val r = Random(0xBEEF + i)
        Node(r.nextFloat() * (Math.PI.toFloat() * 2f), 0.22f + r.nextFloat() * 0.72f, r.nextFloat())
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var running = false
    private var phase = 0f
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            phase += 0.075f
            invalidate()
            postOnAnimation(this)
        }
    }

    init { visibility = GONE; importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO; contentDescription = null }
    fun start() { if (running) return; running = true; visibility = VISIBLE; removeCallbacks(tick); postOnAnimation(tick) }
    fun stop() { running = false; removeCallbacks(tick); visibility = GONE; invalidate() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        if (!running) return
        val cx = width * .5f; val cy = height * .5f; val maxR = minOf(width, height) * .43f
        val pts = ArrayList<Pair<Float, Float>>(nodes.size)
        nodes.forEach { n -> pts += (cx + cos(n.angle + phase * .22f) * maxR * n.radius) to (cy + sin(n.angle + phase * .22f) * maxR * n.radius) }
        paint.style = Paint.Style.STROKE; paint.strokeWidth = resources.displayMetrics.density; paint.color = android.graphics.Color.argb(75,255,178,56)
        for (i in 0 until pts.lastIndex) canvas.drawLine(pts[i].first, pts[i].second, pts[i+1].first, pts[i+1].second, paint)
        paint.style = Paint.Style.FILL
        pts.forEachIndexed { i, p ->
            val glow = (0.45f + 0.55f * ((sin(phase * 2f + nodes[i].phase * 6.28f) + 1f) * .5f))
            paint.color = android.graphics.Color.argb((220 * glow).toInt(),255,178,56)
            canvas.drawCircle(p.first, p.second, resources.displayMetrics.density * (1.7f + 1.4f * glow), paint)
        }
    }
}
