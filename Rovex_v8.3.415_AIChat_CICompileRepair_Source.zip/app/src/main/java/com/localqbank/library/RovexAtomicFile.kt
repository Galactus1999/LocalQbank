package com.localqbank.library

import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Small process-local durability primitive for files that must never be replaced by a partial
 * copy. Writers finish and fsync the temporary file first, then replace the target in one rename.
 * There is deliberately no delete-target-then-copy fallback: that pattern can leave a missing or
 * truncated database/backup after a process kill or power loss.
 */
object RovexAtomicFile {
    fun replace(temp: File, target: File) {
        require(temp.isFile) { "Atomic source does not exist: ${temp.path}" }
        target.parentFile?.mkdirs()
        try {
            Files.move(
                temp.toPath(), target.toPath(),
                StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.ATOMIC_MOVE
            )
            return
        } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
            // Same-directory File.renameTo is the safest available fallback on older/vendor filesystems.
        } catch (_: UnsupportedOperationException) {
            // Some Android/libcore combinations do not expose ATOMIC_MOVE for every provider.
        }
        if (!temp.renameTo(target)) {
            throw IllegalStateException("Could not atomically replace ${target.path}")
        }
    }
}
