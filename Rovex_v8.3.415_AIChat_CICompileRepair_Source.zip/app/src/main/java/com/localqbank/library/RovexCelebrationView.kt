package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Short, non-blocking particle celebration using the same procedural language as the splash. */
class RovexCelebrationView(context: Context) : View(context) {
    private data class Particle(val angle: Float, val distance: Float, val size: Float, val delay: Float)
    private val particles = List(28) { i ->
        val r = Random(0x524F5645 + i)
        Particle(r.nextFloat() * (Math.PI.toFloat() * 2f), 0.45f + r.nextFloat() * 0.55f, 1.4f + r.nextFloat() * 2.2f, r.nextFloat() * 0.25f)
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var progress = 1f
    private var running = false
    private var startMs = 0L
    private var centerX = Float.NaN
    private var centerY = Float.NaN
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            progress = ((android.os.SystemClock.uptimeMillis() - startMs) / DURATION_MS.toFloat()).coerceIn(0f, 1f)
            invalidate()
            if (progress < 1f) postOnAnimation(this) else { running = false; visibility = GONE }
        }
    }

    init { isClickable = false; isFocusable = false; visibility = GONE }

    fun celebrate() {
        if (!isAttachedToWindow || width <= 0 || height <= 0) return
        centerX = Float.NaN; centerY = Float.NaN
        running = true; visibility = VISIBLE; progress = 0f; startMs = android.os.SystemClock.uptimeMillis(); removeCallbacks(tick); postOnAnimation(tick)
    }

    fun celebrateAt(target: View) {
        if (!isAttachedToWindow || width <= 0 || height <= 0) return
        val targetLocation = IntArray(2); val rootLocation = IntArray(2)
        target.getLocationOnScreen(targetLocation); getLocationOnScreen(rootLocation)
        centerX = targetLocation[0] - rootLocation[0] + target.width * 0.5f
        centerY = targetLocation[1] - rootLocation[1] + target.height * 0.5f
        running = true; visibility = VISIBLE; progress = 0f; startMs = android.os.SystemClock.uptimeMillis(); removeCallbacks(tick); postOnAnimation(tick)
    }

    override fun onDetachedFromWindow() { running = false; removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!running) return
        val d = resources.displayMetrics.density
        val cx = if (centerX.isNaN()) width * 0.5f else centerX
        val cy = if (centerY.isNaN()) height * 0.5f else centerY
        val maxR = minOf(width, height) * 0.44f
        val eased = 1f - (1f - progress) * (1f - progress)
        particles.forEach { p ->
            val local = ((progress - p.delay) / (1f - p.delay)).coerceIn(0f, 1f)
            val r = maxR * p.distance * (1f - (1f - local) * (1f - local))
            val x = cx + cos(p.angle) * r
            val y = cy + sin(p.angle) * r * 0.78f
            paint.color = android.graphics.Color.argb((210 * (1f - local)).toInt().coerceIn(0, 210), 255, 178, 56)
            paint.setShadowLayer(7f * d * (1f - local), 0f, 0f, paint.color)
            canvas.drawCircle(x, y, p.size * d * (0.6f + 0.7f * eased), paint)
            paint.clearShadowLayer()
        }
    }

    companion object { private const val DURATION_MS = 1050L }
}

/** Installs a reusable celebration overlay over any Activity content root. */
object RovexCelebrationHost {
    private const val TAG = "rovex_celebration_host"
    fun install(root: ViewGroup): RovexCelebrationView {
        (root.findViewWithTag<RovexCelebrationView>(TAG))?.let { return it }
        val v = RovexCelebrationView(root.context).apply { tag = TAG }
        root.addView(v, ViewGroup.LayoutParams(-1, -1))
        return v
    }
}
