package com.localqbank.library

import kotlin.math.sin

/** Shared breathing-glow curve used by splash and in-app attention surfaces. */
object RovexBreathing {
    fun factor(phase: Float): Float = 0.72f + 0.28f * sin(phase * 6.2f)
    fun alpha(base: Int, phase: Float, variance: Float = 0.12f): Int {
        val normalized = (factor(phase) - 0.72f) / 0.28f
        return (base * (1f + normalized * variance)).toInt().coerceIn(0, 255)
    }
}
