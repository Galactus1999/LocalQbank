package com.localqbank.library

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.abs

/** Home dashboard: adaptive, data-backed and deliberately light on runtime work. */
object RovexHomeRevolution {
    private const val TAG = "ROVEX_HOME_SHELL"
    private data class DynamicResult(val today:Int,val attempted:Int,val correct:Int,val wrong:Int,val week:Int,val daily:Int,val weekly:Int,val bookmarks:Int,val todayRecords:List<Pair<Long,Boolean>>,val days:List<Last28StudyDaysGraphView.Day>)
    private fun d(v:Int,c:Context)=(v*c.resources.displayMetrics.density).toInt()

    private fun tv(c:Context,s:String,z:Float,col:Int=ThemeManager.text(c),bold:Boolean=true)=TextView(c).apply{
        text=s;textSize=z;setTextColor(col);if(bold)setTypeface(typeface,Typeface.BOLD);includeFontPadding=false
    }

    private fun card(c:Context,index:Int=0):GradientDrawable {
        val base=if(ThemeManager.isDark(c)) {
            when(index%4){0->ThemeManager.elevated(c);1->ThemeManager.panel(c);2->ThemeManager.elevated(c);else->ThemeManager.panel(c)}
        } else ThemeManager.pastelAccentFill(c,index)
        val end=if(ThemeManager.isDark(c)) ThemeManager.panel(c) else when(index%4){0->ThemeManager.panel(c);1->ThemeManager.elevated(c);2->ThemeManager.panel(c);else->ThemeManager.elevated(c)}
        return GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(base,end)).apply{
            cornerRadius=d(22,c).toFloat()
            val ac=ThemeManager.accent(c)
            setStroke(d(1,c),Color.argb(if(ThemeManager.isDark(c))95 else 70,Color.red(ac),Color.green(ac),Color.blue(ac)))
        }
    }

    private fun feature(a:MainActivity,title:String,sub:String,icon:String,index:Int,target:()->Unit):View{
        val box=FrameLayout(a).apply{background=card(a,index);setPadding(d(14,a),d(13,a),d(10,a),d(10,a));isClickable=true;isFocusable=true;elevation=d(4,a).toFloat();setOnClickListener{target()}}
        val col=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL}
        val iconColor=ThemeManager.accent(a)
        if(title=="Frankenstein") {
            col.addView(FrankensteinLogoView(a),LinearLayout.LayoutParams(d(54,a),d(54,a)).apply{bottomMargin=d(6,a)})
        } else {
            col.addView(tv(a,icon,29f,iconColor,true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Color.argb(if(ThemeManager.isDark(a))55 else 95,Color.red(iconColor),Color.green(iconColor),Color.blue(iconColor)));setStroke(d(1,a),Color.argb(90,Color.red(iconColor),Color.green(iconColor),Color.blue(iconColor)))}},LinearLayout.LayoutParams(d(50,a),d(50,a)).apply{bottomMargin=d(8,a)})
        }
        col.addView(tv(a,title,18f,ThemeManager.text(a),true))
        col.addView(tv(a,sub,11.5f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(4,a)})
        box.addView(col,FrameLayout.LayoutParams(-1,-1))
        box.addView(tv(a,"›",28f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER},FrameLayout.LayoutParams(d(30,a),d(30,a),Gravity.END or Gravity.BOTTOM))
        return box
    }

    private fun openSection(a:MainActivity,id:String,focusKind:String?=null){
        a.startActivity(Intent(a,RovexSectionDashboardActivity::class.java).apply{
            putExtra("section",id);focusKind?.let{putExtra("focusKind",it)}
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        })
    }

    private fun navigateNav(a:MainActivity,index:Int,flashcards:View?){
        when(index.coerceIn(0,4)){
            0->a.startActivity(Intent(a,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            1->openSection(a,"qbank")
            2->a.startActivity(Intent(a,FlashcardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            3->a.startActivity(Intent(a,RenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            4->a.startActivity(Intent(a,StudyToolsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }

    fun refreshTheme(a:MainActivity){
        val root=a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        root.findViewWithTag<FrameLayout>(TAG)?.let{it.background=ThemeManager.backgroundDrawable(a);it.invalidate()}
    }

    fun apply(a:MainActivity){
        val root=a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        if(root.findViewWithTag<FrameLayout>(TAG)!=null)return
        val shell=FrameLayout(a).apply{tag=TAG;contentDescription="rovexHomeShell";background=ThemeManager.backgroundDrawable(a)}
        val scroll=ScrollView(a).apply{tag="ROVEX_HOME_SCROLL";overScrollMode=View.OVER_SCROLL_NEVER;clipToPadding=false;isFillViewport=true}
        // The persistent five-tab shell is owned exclusively by RovexBottomNavigation.
        // Keep enough trailing space for that shell, but do not create a second in-content footer.
        val content=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(14,a),d(14,a),d(14,a),d(92,a))}
        scroll.addView(content);shell.addView(scroll,FrameLayout.LayoutParams(-1,-1))

        val top=LinearLayout(a).apply{gravity=Gravity.CENTER_VERTICAL}
        top.addView(RovexHeaderCosmicView(a),LinearLayout.LayoutParams(d(48,a),d(44,a)).apply{rightMargin=d(4,a)})
        top.addView(RovexWaveTextView(a).apply{text="Rovex";textSize=29f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(a));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,d(48,a),1f))
        top.addView(tv(a,"⚙",23f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;contentDescription="Settings";background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(ThemeManager.peacockFill(a));setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{a.startActivity(Intent(a,SettingsActivity::class.java))}},LinearLayout.LayoutParams(d(48,a),d(48,a)))
        content.addView(top,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(9,a)})

        val search=tv(a,"⌕   Search questions, topics, anything…   ✦",14f,ThemeManager.text(a),false).apply{gravity=Gravity.CENTER_VERTICAL;contentDescription="rovexHomeSearch";setPadding(d(16,a),0,d(16,a),0);background=card(a,0);setOnClickListener{a.startActivity(Intent(a,SearchActivity::class.java).putExtra("focusSearch",true))}}
        content.addView(search,LinearLayout.LayoutParams(-1,d(52,a)).apply{bottomMargin=d(13,a)})

        val greet=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL}
        greet.addView(tv(a,"Good Evening,",15f,ThemeManager.muted(a),false))
        greet.addView(tv(a,"Future Doctor 👋",29f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)})
        greet.addView(tv(a,"Small steps. Big Doctor.",13f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)})
        content.addView(greet,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(12,a)})

        val progress=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16,a),d(14,a),d(16,a),d(14,a));background=card(a,2);elevation=d(4,a).toFloat()}
        val progressTitle=tv(a,"Today's Progress",18f,ThemeManager.text(a),true)
        val progressValue=tv(a,"Loading calibrated progress…",29f,ThemeManager.text(a),true).apply{tag="rovex_home_progress_value"}
        val progressMeta=tv(a,"Using saved answers only",11.5f,ThemeManager.muted(a),false).apply{tag="rovex_home_progress_meta"}
        val progressGraph=TodayProgressGraphView(a).apply{tag="rovex_home_progress_graph";contentDescription="Today-only accuracy timeline"}
        val continueButton=tv(a,"▶  CONTINUE MOST RECENT QBANK",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{
            PerformanceManager.submit{
                val target=runCatching{val db=QBankDb(a.applicationContext);try{MainRepository(a.applicationContext).use{it.latestResumeTarget(db.sources())}}finally{db.close()}}.getOrNull()
                a.runOnUiThread{if(!a.isFinishing&&!a.isDestroyed){if(target!=null)a.startActivity(Intent(a,QuizActivity::class.java).putExtra("testId",target.testId).putExtra("title",target.title).putExtra("position",target.position).putExtra("questionId",target.questionId).putExtra("practiceMode",true))else a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))}}
            }
        }}
        progress.addView(progressTitle);progress.addView(progressValue,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)});progress.addView(progressGraph,LinearLayout.LayoutParams(-1,d(168,a)).apply{topMargin=d(7,a)});progress.addView(progressMeta,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)});progress.addView(continueButton,LinearLayout.LayoutParams(-1,d(38,a)).apply{topMargin=d(8,a)})
        content.addView(progress,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        val grid=GridLayout(a).apply{columnCount=2}
        fun add(v:View,i:Int){val lp=GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED,1f),GridLayout.spec(GridLayout.UNDEFINED,1f));lp.width=0;lp.height=d(160,a);lp.setMargins(d(4,a),d(4,a),d(4,a),d(4,a));grid.addView(v,lp)}
        add(feature(a,"QBank","19 subjects • imported content","📚",0){openSection(a,"qbank")}.apply{tag="modern_feature_qbank";contentDescription="qbankHomeCard"},0)
        add(feature(a,"Flashcards","Spaced repetition • review","🧠",1){a.startActivity(Intent(a,FlashcardActivity::class.java))}.apply{tag="modern_feature_flashcards"},1)
        add(feature(a,"Performance Lab","Measured study telemetry","📊",2){a.openPerformanceLabFromModernHome()},2)
        add(feature(a,"Frankenstein","Ben / AI study partner","🤖",3){a.startActivity(Intent(a,RenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))},3)
        content.addView(grid,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(9,a)})

        val qbox=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,1)}
        qbox.addView(tv(a,"QBank Library",17f,ThemeManager.text(a),true))
        qbox.addView(tv(a,"Browse the main imported QBank list, then open any bank for its subject/test content.",11.5f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(3,a)})
        val qb=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun action(label:String,click:()->Unit)=tv(a,label,10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.peacockFill(a));cornerRadius=d(18,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{click()}}
        qb.addView(action("BROWSE QBANKS"){a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))},LinearLayout.LayoutParams(0,d(44,a),1f).apply{rightMargin=d(4,a)})
        qb.addView(action("IMPORT QBANK"){a.openQBankImporterFromHome()},LinearLayout.LayoutParams(0,d(44,a),1f).apply{leftMargin=d(4,a)})
        qbox.addView(qb,LinearLayout.LayoutParams(-1,d(44,a)).apply{topMargin=d(8,a)})
        content.addView(qbox,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        val bookmarksBox=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,0)}
        bookmarksBox.addView(tv(a,"🔖  Bookmarked MCQs",17f,ThemeManager.text(a),true))
        bookmarksBox.addView(tv(a,"Saved questions remain independent of solved / wrong / marked status.",11.5f,ThemeManager.muted(a),false).apply{tag="rovex_home_bookmarks_meta"},LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(3,a)})
        bookmarksBox.addView(tv(a,"OPEN BOOKMARKS  →",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{a.startActivity(Intent(a,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue","all"))}},LinearLayout.LayoutParams(-1,d(40,a)).apply{topMargin=d(8,a)})
        content.addView(bookmarksBox,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(10,a)})
        val bookmarkCollections = listOf(
            Triple("★  Important", "important", ThemeManager.bookmarkFill(a,"important")),
            Triple("↻  Revise", "revise", ThemeManager.bookmarkFill(a,"revise")),
            Triple("❔  Doubt", "doubt", ThemeManager.bookmarkFill(a,"doubt")),
            Triple("♥  Favourite", "favorite", ThemeManager.bookmarkFill(a,"favorite"))
        )
        val bookmarkGrid=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL}
        val bookmarkViews=linkedMapOf<String,TextView>()
        bookmarkCollections.chunked(2).forEachIndexed{rowIndex,rowItems->
            val rr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL;weightSum=2f}
            rowItems.forEachIndexed{cellIndex,item->
                val key=item.second
                val b=tv(a,"${item.first}\n…",12.5f,ThemeManager.bookmarkText(a,key),true).apply{
                    gravity=Gravity.CENTER; textAlignment=View.TEXT_ALIGNMENT_CENTER; background=GradientDrawable().apply{setColor(item.third);cornerRadius=d(16,a).toFloat();setStroke(d(1,a),Color.argb(55,100,120,140))}
                    setPadding(d(6,a),d(4,a),d(6,a),d(4,a))
                    setOnClickListener{a.startActivity(Intent(a,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue",key))}
                    contentDescription="${item.first} bookmark collection"
                }
                bookmarkViews[key]=b
                rr.addView(b,LinearLayout.LayoutParams(0,d(66,a),1f).apply{if(cellIndex>0)setMargins(d(6,a),0,0,0)})
            }
            bookmarkGrid.addView(rr,LinearLayout.LayoutParams(-1,d(66,a)).apply{if(rowIndex>0)setMargins(0,d(6,a),0,0)})
        }
        content.addView(bookmarkGrid,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})
        PerformanceManager.submit {
            val counts=runCatching{
                val counts=linkedMapOf<String,Int>()
                PerformanceManager.progress(a.applicationContext).all().values.forEach { p ->
                    val key=p.bookmark.orEmpty().lowercase()
                    if(key.isNotBlank()) counts[key]=(counts[key] ?: 0)+1
                }
                counts
            }.getOrDefault(emptyMap())
            a.runOnUiThread {
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                bookmarkViews.forEach { (key,view) ->
                    val label=bookmarkCollections.firstOrNull{it.second==key}?.first ?: key
                    val count=counts[key] ?: 0
                    view.text="$label\n$count"
                    view.contentDescription="$label bookmark collection, $count saved"
                }
            }
        }

        RovexDailyStudyHub.install(a,content,null){a.startActivity(Intent(a,FlashcardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))}

        content.addView(tv(a,"Quick Tools",18f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{leftMargin=d(3,a);bottomMargin=d(7,a)})
        val qr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL}
        val qscroll=HorizontalScrollView(a).apply{isHorizontalScrollBarEnabled=false}
        val tools=listOf(
            "▣\nPYQ" to {openSection(a,"qbank","PYQ")},
            "✓\nTests" to {openSection(a,"tests","Subject Test")},
            "✎\nNotes" to {a.startActivity(Intent(a,NotesActivity::class.java))},
            "🔖\nBookmarks" to {a.startActivity(Intent(a,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue","all"))},
            "▤\nLibrary" to {a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))},
            "⌘\nTools" to {a.startActivity(Intent(a,StudyToolsActivity::class.java))},
            "⚙\nSettings" to {a.startActivity(Intent(a,SettingsActivity::class.java))}
        )
        tools.forEachIndexed{index,p->qr.addView(tv(a,p.first,13f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER;background=card(a,index);setOnClickListener{p.second()}},LinearLayout.LayoutParams(d(98,a),d(70,a)).apply{rightMargin=d(7,a)})}
        qscroll.addView(qr);content.addView(qscroll,LinearLayout.LayoutParams(-1,d(78,a)).apply{bottomMargin=d(13,a)})

        val goal=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,2)}
        val goalTitle=tv(a,"🏆  Weekly Goal",17f,ThemeManager.text(a),true)
        val goalText=tv(a,"Goals not set",12.5f,ThemeManager.muted(a),false).apply{tag="rovex_home_goal_text"}
        val goalBar=ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal).apply{tag="rovex_home_goal_bar";max=100;this.progress=0;progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(a));progressBackgroundTintList=android.content.res.ColorStateList.valueOf(ThemeManager.peacockFill(a))}
        val setGoals=tv(a,"SET DAILY / WEEKLY GOAL",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{showGoalDialog(a){refreshDynamic(a,progressValue,progressMeta,progressGraph,goalText,goalBar)}}}
        goal.addView(goalTitle);goal.addView(goalText,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(6,a)});goal.addView(goalBar,LinearLayout.LayoutParams(-1,d(7,a)).apply{topMargin=d(7,a)});goal.addView(setGoals,LinearLayout.LayoutParams(-1,d(38,a)).apply{topMargin=d(8,a)})
        content.addView(goal,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        content.addView(tv(a,"Continue Learning",18f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{leftMargin=d(3,a);bottomMargin=d(7,a)})
        val hs=HorizontalScrollView(a).apply{isHorizontalScrollBarEnabled=false};val hr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL;id=R.id.rovexHomeContinueRow};hs.addView(hr)
        content.addView(hs,LinearLayout.LayoutParams(-1,d(128,a)).apply{bottomMargin=d(13,a)})
        refreshContinue(a,hr)

        content.addView(tv(a,"✦   Discipline today, Doctor tomorrow.   ›",16f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(d(16,a),0,d(16,a),0);background=card(a,3)},LinearLayout.LayoutParams(-1,d(62,a)))

        // No legacy footer here. RovexBottomNavigation installs the single persistent
        // five-destination shell as a sibling of the dashboard root.

        var downX=0f;var downY=0f
        shell.setOnTouchListener{_,e->when(e.actionMasked){MotionEvent.ACTION_DOWN->{downX=e.x;downY=e.y;true};MotionEvent.ACTION_UP->{val dx=e.x-downX;val dy=e.y-downY;if(abs(dx)>d(72,a)&&abs(dx)>abs(dy)*1.3f){if(dx<0)navigateNav(a,1,null) else navigateNav(a,3,null);true}else false};else -> false}}
        root.addView(shell,ViewGroup.LayoutParams(-1,-1))

        refreshDynamic(a,progressValue,progressMeta,progressGraph,goalText,goalBar)
    }

    fun refreshData(a: MainActivity) {
        val root = a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        val shell = root.findViewWithTag<FrameLayout>(TAG) ?: return
        val value = shell.findViewWithTag<TextView>("rovex_home_progress_value") ?: return
        val meta = shell.findViewWithTag<TextView>("rovex_home_progress_meta") ?: return
        val graph = shell.findViewWithTag<TodayProgressGraphView>("rovex_home_progress_graph") ?: return
        val goalText = shell.findViewWithTag<TextView>("rovex_home_goal_text") ?: return
        val goalBar = shell.findViewWithTag<ProgressBar>("rovex_home_goal_bar") ?: return
        refreshDynamic(a, value, meta, graph, goalText, goalBar)
        val continueRow = shell.findViewById<LinearLayout>(R.id.rovexHomeContinueRow)
        if (continueRow != null) refreshContinue(a, continueRow)
    }

    private fun refreshContinue(a:MainActivity,row:LinearLayout){
        AppManagers.qbankLoading.loadSources { sources ->
            AppManagers.qbankLoading.loadDashboardRows { rows ->
            val cards=sources.map{src->
                val relevant=rows.filter{it.source==src.fileName};val total=relevant.sumOf{it.total};val solved=relevant.sumOf{it.solved};Triple(src,total,solved)
            }.sortedByDescending{it.third}.take(6)
            a.runOnUiThread{
                val hr=row
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                hr.removeAllViews()
                if(cards.isEmpty()){
                    hr.addView(tv(a,"No imported QBank yet\nImport a QBank to start learning",13f,ThemeManager.muted(a),false).apply{gravity=Gravity.CENTER;background=card(a,0)},LinearLayout.LayoutParams(d(210,a),d(116,a)))
                } else cards.forEachIndexed{index,item->
                    val src=item.first;val total=item.second;val solved=item.third
                    val label=if(total>0)"$solved / $total solved" else "No question data yet"
                    val box=tv(a,"📘\n${src.fileName}\n$label",13f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER;background=card(a,index);setPadding(d(8,a),d(7,a),d(8,a),d(7,a))
                        setOnClickListener{
                            PerformanceManager.submit {
                                val target=runCatching { MainRepository(a.applicationContext).use { it.resumeTarget(src) } }.getOrNull()
                                a.runOnUiThread {
                                    if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                                    if(target!=null) a.startActivity(Intent(a,QuizActivity::class.java).putExtra("testId",target.testId).putExtra("title",target.title).putExtra("position",target.position).putExtra("practiceMode",true))
                                    else a.startActivity(Intent(a,TestListActivity::class.java).putExtra("sourceId",src.id).putExtra("sourceName",src.fileName))
                                }
                            }
                        }}
                    hr.addView(box,LinearLayout.LayoutParams(d(170,a),d(116,a)).apply{rightMargin=d(8,a)})
                }
            }
            }
        }
    }
    private fun refreshDynamic(a:MainActivity,value:TextView,meta:TextView,graph:TodayProgressGraphView,goalText:TextView,goalBar:ProgressBar){
        PerformanceManager.submit{
            val result=runCatching{
                val refs=PerformanceManager.lightRefs(a.applicationContext)
                val day=AppManagers.analytics.snapshot(refs,1)
                val week=AppManagers.analytics.snapshot(refs,7)
                val goals=MainRepository(a.applicationContext)
                val daily=goals.dailyGoal();val weekly=goals.weeklyGoal();goals.close()
                val progress = PerformanceManager.progress(a.applicationContext).all().values
                    .filter { it.lastAttempted > 0L && it.status != null }
                val now = java.util.Calendar.getInstance()
                val todayStart = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0)
                }.timeInMillis
                val todayRecords = progress.filter { it.lastAttempted >= todayStart }.sortedBy { it.lastAttempted }
                    .map { it.lastAttempted to (it.status == "correct") }
                val days = (27 downTo 0).map { offset ->
                    val cal = java.util.Calendar.getInstance().apply {
                        timeInMillis = now.timeInMillis
                        set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0)
                        add(java.util.Calendar.DAY_OF_YEAR,-offset)
                    }
                    val start = cal.timeInMillis
                    val end = start + 86_400_000L
                    val rows = progress.filter { it.lastAttempted in start until end }
                    Last28StudyDaysGraphView.Day(start,rows.size,rows.count { it.status == "correct" })
                }
                DynamicResult(todayRecords.size,day.attempted,day.correct,day.wrong,week.attempted,daily,weekly,day.bookmarks,todayRecords,days)
            }.getOrNull() ?: return@submit
            a.runOnUiThread{
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                val today=result.today;val attempted=result.attempted;val correct=result.correct;val wrong=result.wrong;val week=result.week;val daily=result.daily;val weekly=result.weekly
                a.findViewById<View>(android.R.id.content)?.findViewWithTag<TextView>("rovex_home_bookmarks_meta")?.text = "${result.bookmarks} saved MCQs • independent of solved / wrong status"
                value.text="$today solved today"
                graph.setTodayProgress(result.todayRecords)
                val todayCorrect=result.todayRecords.count { it.second }
                val accuracy=if(today>0) todayCorrect*100/today else 0
                meta.text="$accuracy% accuracy • $todayCorrect correct • ${today-todayCorrect} wrong"
                goalText.text=if(weekly>0)"$week / $weekly questions this week" else "$week questions attempted this week • weekly goal not set"
                goalBar.progress=if(weekly>0)(week*100/weekly).coerceIn(0,100) else 0
            }
        }
    }

    private fun startOfToday(): Long = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0) }.timeInMillis

    private fun showGoalDialog(a:MainActivity,onSaved:()->Unit){
        val box=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(20,a),d(5,a),d(20,a),0)}
        val daily=EditText(a).apply{hint="Daily questions (0 = not set)";inputType=android.text.InputType.TYPE_CLASS_NUMBER}
        val weekly=EditText(a).apply{hint="Weekly questions (0 = not set)";inputType=android.text.InputType.TYPE_CLASS_NUMBER}
        box.addView(daily,LinearLayout.LayoutParams(-1,d(56,a)));box.addView(weekly,LinearLayout.LayoutParams(-1,d(56,a)))
        val loading=TextView(a).apply{
            text="Loading saved goals…";textSize=11.5f;setTextColor(ThemeManager.muted(a));setPadding(0,d(4,a),0,d(4,a))
        }
        box.addView(loading,LinearLayout.LayoutParams(-1,-2))
        val dialog=AlertDialog.Builder(a)
            .setTitle("Study goals")
            .setMessage("Only your saved answer history is used for progress. No target is invented automatically.")
            .setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",null).create()
        dialog.setOnShowListener {
            val save=dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            save.isEnabled=false
            PerformanceManager.submit {
                val goals=runCatching { MainRepository(a.applicationContext).use { it.dailyGoal() to it.weeklyGoal() } }.getOrNull()
                a.runOnUiThread {
                    if(a.isFinishing || a.isDestroyed || !dialog.isShowing) return@runOnUiThread
                    if(goals!=null){
                        goals.first.takeIf{it>0}?.toString()?.let{daily.setText(it)}
                        goals.second.takeIf{it>0}?.toString()?.let{weekly.setText(it)}
                        loading.text="Saved goals loaded"
                        save.isEnabled=true
                    } else {
                        loading.text="Saved goals could not be loaded; you can still enter new values."
                        save.isEnabled=true
                    }
                }
            }
            save.setOnClickListener {
                val dailyValue=daily.text.toString().toIntOrNull()?.coerceIn(0,10000) ?: 0
                val weeklyValue=weekly.text.toString().toIntOrNull()?.coerceIn(0,50000) ?: 0
                save.isEnabled=false
                PerformanceManager.submit {
                    val ok=runCatching { MainRepository(a.applicationContext).use { it.setDailyGoal(dailyValue);it.setWeeklyGoal(weeklyValue) };true }.getOrDefault(false)
                    a.runOnUiThread {
                        if(a.isFinishing || a.isDestroyed) return@runOnUiThread
                        if(ok){ dialog.dismiss(); onSaved() } else { save.isEnabled=true;loading.text="Could not save goals. Try again." }
                    }
                }
            }
        }
        dialog.show()
    }
}
