package com.localqbank.library

/** Bookmark intent boundary. StudyStateRepository/ProgressRepository remain authoritative. */
class QuizBookmarkUseCase(
    private val progress: ProgressRepository,
    private val readSnapshot: () -> ProgressSnapshot,
    private val adaptiveEvent: (() -> Unit)? = null
) {
    /** Synchronous reads are cache-only when a foreground snapshot is supplied. */
    fun current(stableKey: String): String? = readSnapshot().record(stableKey)?.bookmark
    fun set(stableKey: String, value: String?) {
        PerformanceManager.submit {
            progress.setBookmark(stableKey, value)
            PerformanceManager.invalidateProgress()
            adaptiveEvent?.invoke()
        }
    }

    fun mistakeType(stableKey: String): String? = readSnapshot().record(stableKey)?.mistake
    fun setMistakeType(stableKey: String, value: String?) = PerformanceManager.submit {
        progress.setMistakeType(stableKey, value)
        PerformanceManager.invalidateProgress()
    }
}
