package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max

/**
 * Compact, offline-only daily progress graph. Each point is a question's most recent
 * saved answer today; x = time of day and y = cumulative accuracy at that point.
 * This deliberately uses existing local progress records rather than inventing data.
 */
class TodayProgressGraphView(context: Context) : View(context) {
    private data class Point(val at: Long, val correct: Boolean)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { isAntiAlias = true }
    private var points: List<Point> = emptyList()

    fun setTodayProgress(records: List<Pair<Long, Boolean>>) {
        points = records.filter { it.first > 0L }.sortedBy { it.first }.takeLast(120).map { Point(it.first, it.second) }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val left = 30f*d; val right = max(left + 1f, width - 10f*d)
        val top = 14f*d; val bottom = max(top + 1f, height - 22f*d)
        val ac = ThemeManager.accent(context)
        grid.color = if (ThemeManager.isDark(context)) 0x50384A5A else 0x402D5BE6
        for (i in 0..4) {
            val y = bottom - (bottom-top)*i/4f
            c.drawLine(left,y,right,y,grid)
        }
        label.color = ThemeManager.muted(context); label.textSize = 9f*d
        c.drawText("100%", 2f*d, top+3f*d, label)
        c.drawText("50%", 7f*d, (top+bottom)/2f+3f*d, label)
        c.drawText("0%", 10f*d, bottom+3f*d, label)
        if (points.isEmpty()) {
            label.color = ThemeManager.muted(context); label.textSize = 11f*d
            c.drawText("Answer a few questions today to build the graph", left, (top+bottom)/2f+4f*d, label)
            return
        }
        val path = Path()
        var correct = 0
        points.forEachIndexed { i, p ->
            if (p.correct) correct++
            val accuracy = correct * 100f / (i+1)
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = p.at }
            val minutes = cal.get(java.util.Calendar.HOUR_OF_DAY)*60 + cal.get(java.util.Calendar.MINUTE) + cal.get(java.util.Calendar.SECOND)/60f
            val x = left + (right-left) * minutes / 1440f
            val y = bottom - (bottom-top) * accuracy / 100f
            if (i == 0) path.moveTo(x,y) else path.lineTo(x,y)
            dot.color = if (p.correct) 0xFF45D6A0.toInt() else 0xFFFF6E9C.toInt()
            c.drawCircle(x,y,5f*d,dot)
        }
        line.color = ac
        c.drawPath(path,line)
        label.color = ThemeManager.muted(context); label.textSize = 8.5f*d
        c.drawText("TODAY", left, height-5f*d, label)
        c.drawText("ACCURACY", right-54f*d, height-5f*d, label)
    }
}
