package com.localqbank.library

import android.content.Context
import android.graphics.Rect
import android.view.*
import android.webkit.WebView
import android.widget.EditText
import android.widget.HorizontalScrollView
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs

/** Gesture recognizer for section navigation. It never intercepts the child hierarchy itself. */
class RovexSectionSwipeDetector(private val context: Context, private val onSwipe: (Int) -> Unit) {
    private val density=context.resources.displayMetrics.density
    private val threshold=92f*density
    private var downX=0f
    private var downY=0f
    private var ignored=false
    private var consumed=false

    fun onTouchEvent(ev: MotionEvent): Boolean {
        when(ev.actionMasked){
            MotionEvent.ACTION_DOWN -> {
                downX=ev.x; downY=ev.y; consumed=false
                ignored=isHorizontalGestureExcluded(context, ev.rawX.toInt(), ev.rawY.toInt())
            }
            MotionEvent.ACTION_UP -> {
                if(!ignored){
                    val dx=ev.x-downX; val dy=ev.y-downY
                    if(abs(dx)>=threshold && abs(dx)>=abs(dy)*1.45f){
                        onSwipe(if(dx<0f) 1 else -1)
                        consumed=true
                    }
                }
                ignored=false
            }
            MotionEvent.ACTION_CANCEL -> ignored=false
        }
        return consumed
    }

    private fun isHorizontalGestureExcluded(c:Context,x:Int,y:Int):Boolean {
        val root=(c as? android.app.Activity)?.window?.decorView ?: return false
        val target=findDeepest(root,x,y) ?: return false
        var v:View?=target
        while(v!=null){
            if(v is WebView || v is EditText || v is HorizontalScrollView) return true
            if(v is RecyclerView && (v.canScrollHorizontally(-1) || v.canScrollHorizontally(1))) return true
            v=v.parent as? View
        }
        // If the actual touched view can already consume horizontal movement, preserve it.
        return target.canScrollHorizontally(-1) || target.canScrollHorizontally(1)
    }

    private fun findDeepest(v:View,x:Int,y:Int):View?{
        val loc=IntArray(2); v.getLocationOnScreen(loc)
        val rect=Rect(loc[0],loc[1],loc[0]+v.width,loc[1]+v.height)
        if(!rect.contains(x,y)) return null
        if(v is ViewGroup){
            for(i in v.childCount-1 downTo 0){
                val hit=findDeepest(v.getChildAt(i),x,y)
                if(hit!=null) return hit
            }
        }
        return v
    }
}
