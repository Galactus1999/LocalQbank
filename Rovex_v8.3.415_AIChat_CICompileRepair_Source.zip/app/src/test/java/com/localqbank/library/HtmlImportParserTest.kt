package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HtmlImportParserTest {
    @Test
    fun decodeHtmlEntitiesPreservesEmbeddedMarkup() {
        val source = "&lt;p&gt;MRI &amp; CT&lt;/p&gt; &quot;correct_answer&quot;: &quot;D. MRI&quot;"
        val decoded = HtmlImportParser.decodeHtmlEntitiesPreserveMarkup(source)
        assertEquals("<p>MRI & CT</p> \"correct_answer\": \"D. MRI\"", decoded)
    }

    @Test
    fun decodeHtmlEntitiesSupportsNumericAndDoubleEncodedEntities() {
        val source = "&#x3C;strong&#x3E;&amp;quot;MRI&amp;quot;&#x3C;/strong&#x3E;"
        val decoded = HtmlImportParser.decodeHtmlEntitiesPreserveMarkup(source)
        assertEquals("<strong>\"MRI\"</strong>", decoded)
    }

    @Test
    fun decodeHtmlEntitiesLeavesUnknownEntitiesUntouched() {
        val source = "drug &made_up;"
        val decoded = HtmlImportParser.decodeHtmlEntitiesPreserveMarkup(source)
        assertTrue(decoded.contains("&made_up;"))
    }
}
