package com.localqbank.library

import org.junit.Assert.assertTrue
import org.junit.Test

class ClinicalQueryExpansionTest {
    @Test fun cervicalCancerExpandsToCervixAndCarcinomaTerms() {
        val expanded = ClinicalQueryExpansion.expand("cervical cancer")
        assertTrue(expanded.contains("cervix cancer"))
        assertTrue(expanded.contains("cervical carcinoma"))
        assertTrue(expanded.contains("carcinoma cervix"))
    }

    @Test fun expansionNeverReplacesOriginalQuery() {
        assertTrue(!ClinicalQueryExpansion.expand("cervical cancer").contains("cervical cancer"))
    }
    @Test fun embeddedClinicalPhraseIsExpandedWithoutDroppingContext() {
        val expanded = ClinicalQueryExpansion.expand("cervical cancer screening")
        assertTrue(expanded.contains("cervix cancer screening"))
        assertTrue(expanded.contains("cervical carcinoma screening"))
    }

}

class LocalSearchIntentTest {
    @org.junit.Test fun punctuatedTopicStillUsesLocalRetrievalLane() {
        org.junit.Assert.assertTrue(LocalQBankSearchService.isLikelyTopicQuery("cervical cancer?"))
    }

    @org.junit.Test fun explanatoryQuestionUsesAnswerLane() {
        org.junit.Assert.assertTrue(!LocalQBankSearchService.isLikelyTopicQuery("what is cervical cancer?"))
    }
}
