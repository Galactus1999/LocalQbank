package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class SearchSessionSetTest {
    @Test fun preservesSearchOrderAndRemovesDuplicateIds() {
        assertEquals("30,11,44", buildSearchSessionIds(listOf(30L,11L,30L,44L)))
    }

    @Test fun capsSearchSessionAtFiveHundredQuestions() {
        val ids = buildSearchSessionIds((1L..600L).toList()).split(",")
        assertEquals(500, ids.size)
        assertEquals("1", ids.first())
        assertEquals("500", ids.last())
    }
}
