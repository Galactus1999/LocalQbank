package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class ProgressSnapshotTest {
    @Test
    fun snapshotRetainsSelectedAnswerAndMistakeFields() {
        val snapshot = ProgressSnapshot.from(
            mapOf(
                "test:4:key:answer" to "B",
                "test:4:key:status" to "wrong",
                "test:4:key:mistake" to "Concept confusion",
                "test:4:key:attempts" to 2,
            )
        )

        val record = snapshot.record("test:4:key")
        assertEquals("B", record?.selected)
        assertEquals("wrong", record?.status)
        assertEquals("Concept confusion", record?.mistake)
        assertEquals(2, record?.attempts)
    }
}
