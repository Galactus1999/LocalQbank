package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Device-level regression coverage for the real SQLiteOpenHelper-backed streak store.
 * Same-day study events are idempotent: concurrent quiz/flashcard completions must not
 * corrupt the durable streak row or manufacture extra study days.
 */
@RunWith(AndroidJUnit4::class)
class StreakDatabaseConcurrencyTest {
    private val context: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun concurrentSameDayRecordsRemainAtomicAndIdempotent() {
        val db = QBankDb(context)
        val today = LocalDate.now(ZoneId.systemDefault())
        val yesterday = today.minusDays(1)
        val yesterdayTs = yesterday.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val todayTs = today.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val original = db.readStudyStreak()
        try {
            // Establish a deterministic two-day history without touching unrelated tables.
            db.recordStudyStreakDay(yesterdayTs)
            db.recordStudyStreakDay(todayTs)

            val workers = 16
            val start = CountDownLatch(1)
            val done = CountDownLatch(workers)
            val executor = Executors.newFixedThreadPool(workers)
            repeat(workers) {
                executor.execute {
                    try {
                        start.await(5, TimeUnit.SECONDS)
                        QBankDb(context).recordStudyStreakDay(todayTs)
                    } finally {
                        done.countDown()
                    }
                }
            }
            start.countDown()
            check(done.await(15, TimeUnit.SECONDS)) { "streak concurrency test timed out" }
            executor.shutdownNow()

            val final = db.readStudyStreak()
            assertEquals(2, final.currentStreak)
            assertEquals(2, final.longestStreak)
            assertEquals(2, final.totalStudyDays)
            assertEquals(today.toString(), final.lastStudyDay)
        } finally {
            // Restore the user's real streak state; this is a regression test, not a data mutation.
            SQLiteDatabase.openDatabase(context.getDatabasePath("qbank.db").path, null, SQLiteDatabase.OPEN_READWRITE).use { raw ->
                raw.execSQL(
                    "UPDATE study_streak SET current_streak=?,longest_streak=?,total_study_days=?,last_study_day=? WHERE id=1",
                    arrayOf(original.currentStreak, original.longestStreak, original.totalStudyDays, original.lastStudyDay)
                )
            }
            db.close()
        }
    }
}
