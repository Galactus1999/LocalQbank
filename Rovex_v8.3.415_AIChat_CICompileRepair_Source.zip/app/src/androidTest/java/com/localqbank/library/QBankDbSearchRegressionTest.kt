package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Regression coverage for the normalized-table LIKE fallback used when FTS is unavailable/dirty.
 * The ESCAPE expression must resolve to exactly one SQLite character because escapeLike() uses
 * a single backslash to quote %, _, and backslash in user search terms.
 */
@RunWith(AndroidJUnit4::class)
class QBankDbSearchRegressionTest {
    private lateinit var db: SQLiteDatabase
    private lateinit var qbankDb: QBankDb

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        context.deleteDatabase("qbank.db")
        qbankDb = QBankDb(context)
        db = context.openOrCreateDatabase("qbank.db", 0, null)
        db.execSQL("DELETE FROM question_image")
        db.execSQL("DELETE FROM option_item")
        db.execSQL("DELETE FROM question")
        db.execSQL("DELETE FROM test")
        db.execSQL("DELETE FROM source")
        db.execSQL("DELETE FROM question_fts")
        db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','1')")
        db.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(1,'regression.apkg','Regression','test',1)")
        db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('reg-test',1,'Regression Test','regression',1)")
        db.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(1,'reg-test',0,'q1','acid_base disturbance','acid_base disturbance')")
        db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(1,'stem',0,'content://regression/image')")
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun searchLikeFallbackEscapesUnderscoreWithoutSQLiteEscapeError() {
        val results = qbankDb.search("acid_base")
        assertFalse("LIKE fallback must return the matching row", results.isEmpty())
        assertEquals(1L, results.single().questionId)
    }

    @Test
    fun imageSearchLikeFallbackEscapesUnderscoreWithoutSQLiteEscapeError() {
        val results = qbankDb.searchImageQuestions("acid_base")
        assertFalse("Image LIKE fallback must return the matching row", results.isEmpty())
        assertEquals(1L, results.single().questionId)
    }
}
