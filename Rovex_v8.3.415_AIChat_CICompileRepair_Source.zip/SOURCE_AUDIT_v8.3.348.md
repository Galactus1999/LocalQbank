# Rovex v8.3.348 source audit

Baseline: v8.3.347 / versionCode 440.

## Repairs
- Fixed the CI-reported Kotlin compile error in `RenActivity.kt` at the `RovexTableDisplayPrefs` call inside `buildString`.
- Corrected table-off HTML block protection so `table-as-sections` is not nested inside paragraph elements.
- Added readable section styling for table-off Frankenstein chat output.
- Explicit user requests such as "show this as a table" override the default table-off preference for the following Frankenstein response; explicit negative requests do not.

## Logo / header
- Replaced the Home header Earth/living-world animation with `RovexEnergyLogoView`.
- Uses the supplied cyan/violet emblem as the authoritative launcher/in-app artwork.
- Added bounded Canvas glow, moving colour sweep, animated arcs and continuous electrical discharges.
- Animation is lifecycle/visibility gated and stops when detached/invisible.
- Existing search/header controls remain intact.

## Release identity
- versionName: 8.3.348
- versionCode: 441

Android compilation remains a CI gate; no compile-green claim is made by this source audit.
