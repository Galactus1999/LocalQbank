# Rovex v8.3.326 — Persistent Bottom Navigation

## Scope
Ticket 1 only: replace the previous three-item Home-only navigation strip with a shared persistent five-destination Material Components `BottomNavigationView`.

## Destinations
- Home → `MainActivity`
- QBank → `MainQBankLibraryActivity`
- Flashcards → `FlashcardActivity`
- Ben → `RenActivity`
- Notes → `NotesActivity`

## Implementation
- Added `RovexBottomNavigation.kt` as the single navigation owner.
- Installs into the Activity content container so programmatic-layout screens share identical navigation without duplicated XML.
- Uses `FLAG_ACTIVITY_REORDER_TO_FRONT | FLAG_ACTIVITY_SINGLE_TOP` for destination switching.
- Selected/unselected icon and text colors use `ThemeManager.accent/text/muted`; no Material default palette is used.
- Menu labels/content descriptions come from `strings.xml`.
- Bottom system-bar insets are obtained with `WindowInsetsCompat`; no hardcoded system-navigation-bar height is assumed.
- Selected tab index is saved through `onSaveInstanceState`.
- Removed the old three-item Home XML footer.

## Activities integrated
`MainActivity`, `MainQBankLibraryActivity`, `FlashcardActivity`, `RenActivity`, and `NotesActivity`.

## Validation
- XML parse: PASS (0 errors).
- Duplicate IDs within individual layout files: PASS (0 duplicates).
- Local Android/Gradle compile: NOT VERIFIED because Gradle 9.3.1 is unavailable locally and `downloads.gradle.org` DNS is blocked. GitHub Actions remains the build gate.

## Stability notes
This batch intentionally does not implement Tickets 2–6. They remain separate auditable batches to avoid combining navigation-shell risk with search, accessibility, deletion, dashboard, or loading-state changes.
