# Rovex v8.3.360 — UI Cohesion + QBank/Search Deep Stability Fix

- VersionCode: 453
- Based directly on v8.3.359 / versionCode 452.
- Preserves legacy UI source and compatibility; does not delete the previous UI.
- Removes modern-to-hidden-legacy event routing for Search, Frankenstein, Performance Lab, and Daily Study Hub flashcard mixing.
- Stops the hidden legacy MainViewModel/QBank dashboard pipeline from continuing to refresh while the modern Home is active.
- Makes primary bottom-navigation QBank route to the modern subject-wise QBank dashboard.
- Fixes five-tab navigation mapping for Ben/Tools.
- Bounds Frankenstein semantic search fallback fan-out when FTS is incomplete.
- Bounds visual-search fallback fan-out when FTS is incomplete.
- Adds cached search-index health API for controlled fallback behavior.
- XML/duplicate-ID/static sanity audits completed.
- Android compilation not locally verified because Gradle distribution DNS is unavailable; CI is authoritative.
