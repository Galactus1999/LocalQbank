# Rovex v8.3.277 Offline Repair Audit

## Changes
- Replaced the retired `ThemeManager.AMOLED` API with `ThemeManager.AMOLED_DARK` (`amoled_dark`).
- Migrates the persisted legacy `amoled` preference to AMOLED Dark automatically.
- New AMOLED Dark palette: true-black root/reading background, near-black surfaces, cool high-contrast text, cyan accent, and dedicated semantic correct/wrong/explanation colors.
- Updated AMOLED atmosphere renderer to the new AMOLED Dark treatment.
- Updated Settings labels/descriptions and theme selectors to `AMOLED Dark`.
- Removed `Stats` from the bottom navigation. The navigation now contains Home, QBank, Cards, and Mastery. Internal analytics/statistics code was not deleted.
- Bumped version to `8.3.277` / versionCode `371`.
- Removed bundled Qualcomm/LiteRT native binaries from the upload source ZIP only; the existing Gradle preBuild runtime staging script remains authoritative for CI/device packaging.

## Offline validation
- All XML resources parsed successfully.
- Duplicate `@+id` checks per individual layout: 0 duplicates.
- `navStats` references in source/resources: 0.
- Old `ThemeManager.AMOLED` API references: 0.
- AMOLED Dark API references present: PASS.
- Bottom navigation weight sum: 4.
- Version identity: 8.3.277 / 371.
- `architecture_regression_audit.py`: PASS.
- `amoled_ui_audit.py`: PASS (one informational hard-coded-black candidate is a background, not foreground).
- `ruthless_audit.sh`: PASS.
- Offline Gradle compile could not be executed because the local Gradle 9.3.1 distribution is not installed and offline mode attempted to resolve `downloads.gradle.org`; DNS/network access is unavailable in this environment.

## CI requirement
The source ZIP is intended for the existing GitHub Actions workflow, which stages the required Qualcomm runtime through `tools/prepare_litert_qualcomm_v75_jit.sh` before packaging. The GitHub release workflow remains the authoritative compiler/release verification.
