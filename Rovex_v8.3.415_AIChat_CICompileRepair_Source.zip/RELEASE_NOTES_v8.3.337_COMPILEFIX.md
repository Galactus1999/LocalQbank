# Rovex v8.3.337 — v8.3.336 CI Compile Fix

## Root cause
GitHub Actions `:app:compileDebugKotlin` failed in `RovexBottomNavigation.kt:93` because `ColorDrawable` was referenced through the wrong Android package:

`android.graphics.ColorDrawable`

`ColorDrawable` actually belongs to `android.graphics.drawable.ColorDrawable`.

## Repair
The reference was corrected to:

`android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)`

No navigation behavior or UI geometry was changed by this compile-only repair.

## CI evidence
The v8.3.336 CI run reached Android resource processing and Kotlin compilation successfully, then failed on exactly this single unresolved reference. Gradle, Java, Android SDK, Qualcomm runtime cache, manifest processing, and resource processing were not the failure source.

## Version
- versionName: 8.3.337
- versionCode: 430

This source remains based on v8.3.336 and therefore retains its quiz answer-stability, compact navigation, Frankenstein navigation removal, Sound Feedback sizing, and AI table renderer changes.
