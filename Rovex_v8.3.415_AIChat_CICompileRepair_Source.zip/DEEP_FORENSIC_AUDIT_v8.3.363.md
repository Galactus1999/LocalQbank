# Rovex v8.3.363 — Deep Forensic Repair Audit

## Baseline
- Input baseline: Rovex v8.3.362 Deep Forensic Repair Source
- Package/applicationId: `com.localqbank.library`
- versionName: `8.3.363`
- versionCode: `456`
- Android targetSdk: 36
- Source compilation status: **NOT VERIFIED locally** because the Gradle 9.3.1 distribution could not be resolved from `downloads.gradle.org` (DNS failure).

## Remaining defects found after v8.3.362 review

### 1. Resume-target SQLite work could still occur on the UI callback path
`MainViewModel.refreshSourcesFast()` could receive its QBank-loading callback on the main thread and then call `repository.resumeTargets()`, which performs SQLite work. This was moved to the background QBank lane and only immutable results are published back to the UI.

### 2. Legacy MainActivity Continue action still performed synchronous SQLite
The old XML-based Continue button handler still called `MainRepository.latestResumeTarget()` directly. It is no longer the production Home tree, but it was a real latent main-thread I/O path. It is now backgrounded.

### 3. MainActivity QBank reorder persistence remained synchronous
The modern/legacy library reorder callback still wrote `setQBankLibraryOrder()` directly. It is now persisted through `PerformanceManager` and the UI renders the already-computed order immediately.

### 4. Lifecycle backup operations could block Activity lifecycle callbacks
`MainActivity.onStop()` and `QuizSessionLifecycleController.onStop()` could invoke cloud backup directly. Cloud/file I/O is now queued to a dedicated low-priority maintenance executor. This avoids putting network/storage latency into `Activity.onStop()` and avoids occupying the serialized QBank worker.

### 5. Quiz answer persistence was a synchronous SQLite write on the foreground interaction path
`QuizAnswerUseCase -> StudyStateRepository.commitAnswer -> ProgressStore.setAnswer` could block the UI when the database was contended. This was especially relevant to the previous QBank-deletion ANR evidence. The repair introduces an optimistic in-memory study-state overlay and serializes durable answer persistence through the QBank background lane. The answer UI can update immediately while persistence remains ordered and invalidates the progress snapshot after commit.

### 6. Notes image decoding occurred during view construction
Saved note images were decoded synchronously while creating note cards. Image decode is now done on the maintenance lane, with a placeholder UI view and lifecycle checks before attaching the resulting bitmap.

### 7. Knowledge Vault filesystem/database/bitmap work was only partially isolated
Artifact enumeration was already backgrounded, but artifact deletion and opening could still perform file deletion, bitmap decode, and text reads from a UI callback. Those operations are now on the maintenance lane, with generation/lifecycle protection before UI presentation.

### 8. Ben PDF Library performed disk enumeration, PDF rendering, and bitmap allocation on the UI thread
The PDF library was a genuine hidden performance hazard. It is now fully maintenance-worker based, with bounded page bitmap dimensions (max dimension 2048 px), asynchronous page-count lookup, generation cancellation, and explicit image cleanup.

### 9. Benchmark contract was stale after the modern Home migration
The Macrobenchmark still waited for legacy `homeSearchCard`/`libraryList` views that are deliberately no longer inflated by production Home. The benchmark was repaired to use stable accessibility contracts (`rovexHomeShell`, `qbankHomeCard`) and now contains a Home→QBank section journey.

### 10. Baseline profile still emphasized obsolete Home paths
The profile was extended with the modern Home, SearchActivity, and QBank dashboard paths. This is intended as a seed until the physical-device Macrobenchmark generator regenerates the release profile.

## Architecture changes

A third execution lane was added to PerformanceManager:

1. `qbank-worker`: serialized QBank/progress/database work.
2. `qbank-delete-worker`: serialized destructive database work at lowest thread priority.
3. `rovex-maintenance-worker`: serialized low-priority backup/PDF/artifact/file work.

This prevents maintenance I/O from monopolizing the QBank lane while still avoiding unmanaged `Thread {}` proliferation.

## Android guidance applied

Android's current ANR guidance identifies main-thread blocking, I/O, lock contention and expensive frames as common input-dispatch ANR causes. The default AOSP input timeout is about five seconds. Rovex's architecture now aggressively keeps database, filesystem, PDF, bitmap and cloud work outside the foreground interaction path.

StrictMode remains enabled for debug builds to detect accidental disk/network/SQLite work on the UI thread.

WebView containment from v8.3.362 was re-audited and retained: WebViews use `RovexSafeWebViewClient`, renderer termination is handled, dead WebViews are detached/stopped/destroyed, and the application remains alive. `MIXED_CONTENT_ALWAYS_ALLOW` remains absent.

Baseline Profiles and Macrobenchmark are retained as the performance advantage: critical startup/navigation/search/QBank paths can be AOT-optimized rather than waiting for JIT/profile collection on the user's device.

## Static checks
- XML parse errors: 0
- Duplicate IDs within individual XML layouts: 0
- `performClick()` occurrences: 1 (legitimate MotionEvent accessibility forwarding)
- `MIXED_CONTENT_ALWAYS_ALLOW`: 0
- stale modern-Home benchmark IDs: removed
- package/applicationId preserved
- versionName/versionCode updated monotonically
- changed Kotlin delimiter counts checked; no obvious source corruption detected
- ZIP integrity checked after packaging

## Verification limitation
A local compile was attempted with `./gradlew --offline :app:compileDebugKotlin --no-daemon`, but Gradle attempted to resolve Gradle 9.3.1 from `downloads.gradle.org` and DNS resolution failed. Therefore no Android compilation or runtime success is claimed.

## Required CI/device validation
1. Run the complete GitHub Actions release workflow.
2. Require successful Kotlin/resource compilation and release packaging.
3. Verify persistent signing certificate fingerprint.
4. Verify `lib/arm64-v8a/libzstd-jni-1.5.7-16.so` in the APK.
5. Run Macrobenchmark on a physical device for cold startup, Home→QBank, Search, and Frankenstein.
6. Device regression: cold launch → Home → QBank → all 19 subjects → QBank expansion → open test → back → Search → `cervical cancer` → QBank-name search → Frankenstein → rich table → Notes → Knowledge Vault → rapid Home/QBank/Search switching → large-QBank deletion stress.
7. Capture Perfetto/logcat/ANR traces if any latency regression occurs; do not infer root cause from a `DeadObjectException` alone.
