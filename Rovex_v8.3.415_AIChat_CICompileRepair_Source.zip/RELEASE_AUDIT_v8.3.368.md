# Rovex v8.3.368 — Deep Concurrency / Cache-Cohesion Repair Audit

## Identity
- Baseline: v8.3.367 / versionCode 460
- Output: v8.3.368 / versionCode 461
- applicationId: `com.localqbank.library`
- Package preserved.

## Why another scan was necessary
The v8.3.367 repair was directionally correct, but source inspection showed that several concurrency defects remained. The previous flashcard and StudyState fixes were re-checked and retained; they were not reverted.

## Confirmed remaining defects fixed

### 1. PerformanceManager stale-cache resurrection
`refs()`, `lightRefs()` and `progress()` could begin a database read, then an import/delete/answer mutation could call `invalidate()` while the read was still running. The old read could subsequently repopulate the cache and receive a fresh TTL, temporarily resurrecting stale state.

**Repair:** cache writes now capture the `generation` before I/O and publish the result only when the generation is unchanged. The query result is still returned to its current caller, but it cannot poison the shared cache after an invalidation.

### 2. QBankLoadingEngine in-flight coalescing race
The previous sequence was `containsKey()` → `submit()` → `map[key] = future`. Two callers could pass `containsKey()` simultaneously and start duplicate SQLite reads. A very fast task could also finish before the map insertion, leaving a stale in-flight marker.

**Repair:** replaced the check/insert sequence with atomic `putIfAbsent()`. The in-flight marker is removed from the worker's `finally` block. This makes warm-up and foreground section loading truly coalesced.

### 3. QBankLoadingEngine stale metadata cache after mutation
A section query could begin before an import/delete invalidated the cache and then publish old section/test metadata after invalidation.

**Repair:** added an invalidation epoch. Cache publication occurs only when the epoch captured at query start still matches the current epoch.

### 4. Home Study Goals dialog main-thread SQLite I/O
The previous v8.3.367 code synchronously read `dailyGoal()` and `weeklyGoal()` while constructing the dialog and synchronously wrote both values from the dialog's SAVE listener. This was a remaining foreground I/O escape hatch and directly contradicted the resource-governance goal.

**Repair:** the dialog now opens immediately, loads saved goals on the QBank worker, and persists both values on the worker. UI changes remain on the main thread. SAVE is disabled only while the initial load is pending and is re-enabled even if the load fails so the user can still enter new values.

## Previous v8.3.367 fixes re-verified
- Flashcard first-load DB dead path remains repaired.
- Flashcard stale-load generation handling remains present.
- Flashcard teardown remains lifecycle-safe.
- StudyState optimistic answer ordering remains persist → invalidate → refresh → overlay removal.
- Failed optimistic answer overlays remain reconciled.
- Smart Mix, Quiz Notes, and QuizBookmarkUseCase fixes remain present.

## Architectural advantage obtained
The repair strengthens the existing architecture rather than adding another business-logic owner:
- SQLite remains the authoritative source of truth.
- immutable cached snapshots remain presentation accelerators, not competing data owners;
- generation/epoch validation prevents stale asynchronous work from becoming authoritative;
- atomic in-flight coalescing reduces duplicate database work and CPU contention;
- foreground UI stays independent of heavy QBank reads/writes.

This aligns with current Android guidance: blocking I/O and lock contention should be kept off the main thread, repositories should expose a consistent source of truth, caches need thread-safe protection, and SQLite work should be minimized/indexed/batched. See Android Developers: ANR diagnosis, data-layer architecture, and SQLite performance guidance.

## Whole-project source validation
- XML files: 36
- XML parse errors: 0
- Duplicate IDs within individual XML files: 0
- Kotlin source files: 217
- Java source files: 0
- TODO/FIXME markers in main Kotlin source: 0
- `runBlocking`: 0
- `GlobalScope`: 0
- `Thread.sleep`: 0
- Package/applicationId preserved.
- Zstandard Android AAR preserved.
- Isolated Ben inference process preserved.
- Baseline profile preserved.

## Local compilation limitation
Standalone `kotlinc` parsing of changed files produced only the expected Android/project-class unresolved-reference cascade because the Android SDK/Gradle classpath is not supplied to that compiler invocation; no Kotlin syntax/structural diagnostic such as `expecting`, `type mismatch`, `no value passed`, or illegal-return diagnostics was observed in the changed files.

Full Android Gradle compilation is **not verified** in this environment because the Gradle wrapper previously could not resolve/download Gradle from `downloads.gradle.org` due environment DNS restrictions.

## Release status
**Source-audited, not build-green.** GitHub Actions must complete the complete release workflow before v8.3.368 is considered CI-green/release-green.
