# v8.3.404 — CommonMark forensic scan / collapsed-table activation

- Retained the v8.3.403 fix for the undefined `htmlTableTokens` compile reference.
- Activated both existing conservative collapsed-GFM-table normalizers before CommonMark parsing; they had been defined but were not invoked after the parser migration.
- Retained inline semantic-break and Markdown block-boundary preprocessing.
- Retained opaque imported HTML-table preservation.
- Bumped versionCode to 496 / versionName 8.3.404.
- No changes to Ben, IPC, EmbeddingGemma, APKG, flashcards, QBank, SRS, StudyCore, or import ownership.

Verification: forensic source scan completed. Full CI/Gradle verification remains required.
