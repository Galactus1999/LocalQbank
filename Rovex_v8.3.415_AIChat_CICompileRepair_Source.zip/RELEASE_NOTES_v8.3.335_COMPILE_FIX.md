# Rovex v8.3.335 — v8.3.334 CI compile fixes

Baseline: v8.3.334 Navigation + Quiz Performance + Ben Tables.

Fixes verified against CI run logs:
- `MainActivity.kt`: separated `StudyEventSpine.subscribe(milestoneListener)` from `RovexModernUi.applyMain(this)`; v8.3.334 had two Kotlin statements accidentally concatenated on one expression line, producing an unresolved reference and `Expecting an element`.
- `QuizAnswerInteractionController.kt`: changed the lifecycle owner type from `android.app.Activity` to `androidx.activity.ComponentActivity`, matching `QuizActivity` and making `lifecycleScope` valid.
- Bumped version to 8.3.335 / versionCode 428.

No functional navigation, quiz, or Ben table behavior was intentionally changed beyond the compile corrections.
