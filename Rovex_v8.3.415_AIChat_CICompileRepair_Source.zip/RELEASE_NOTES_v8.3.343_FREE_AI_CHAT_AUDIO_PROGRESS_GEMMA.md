# Rovex v8.3.343 — Free AI + Chat Layout + Audio + Progress + Local Neural Grounding

- Explicit RUN FREE AI / Ben+AI actions no longer depend on the separate cloud-fallback toggle.
- Free AI failure messaging now distinguishes no enabled provider from provider request failure.
- Ben+AI chrome compacted: horizontally scrollable mode/action rows, combined follow-up row, reduced footer height, fullscreen dialog gravity/inset hardening.
- Sound feedback now waits for asynchronous SoundPool load completion and exposes a TEST control.
- Plan My Day calendar export uses Android's documented ACTION_INSERT calendar contract with a calendar-app fallback.
- Home Today's Progress is now today-only with a time-of-day accuracy graph; Daily Progress remains the 28-day trend.
- QBank import completion schedules the bounded Ben local knowledge build; neural grounding can supplement lexical recall from that persistent index before EmbeddingGemma reranking and Gemma generation.
