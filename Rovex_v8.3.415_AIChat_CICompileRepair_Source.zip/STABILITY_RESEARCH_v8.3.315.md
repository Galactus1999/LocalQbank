# Rovex v8.3.315 — Stability Research Validation

## Evidence used
- Firebase Crashlytics Android NDK documentation: native symbol upload is required for readable native stack traces; `unstrippedNativeLibsDir` is appropriate for externally/custom-built native libraries.
- Android `ApplicationExitInfo`: Android 11+ exposes process death reasons, including `REASON_CRASH_NATIVE`, `REASON_CRASH`, and `REASON_ANR`, plus status, memory samples, descriptions, and native/ANR trace availability.
- Android testing guidance: fast unit tests should run continuously in CI; device/instrumentation tests complement local JVM tests.
- Android coroutine guidance: cancellation must not be swallowed by broad exception handling; long-running/blocking work belongs off the main thread.
- Android Room guidance: Room is the recommended abstraction for new/modern SQLite persistence, but migration of a large existing SQLite schema should be incremental rather than a destabilizing rewrite.

## v8.3.315 implementation
1. Retains Firebase Crashlytics NDK as the production native-crash reporting layer.
2. Retains unstripped-symbol upload configuration for the CI-staged Qualcomm/LiteRT native runtime.
3. Adds Android `ApplicationExitInfo` metadata correlation for the current process, without reading/uploading tombstone payloads during startup.
4. Retains focused JVM regression tests for spaced repetition, Thompson sampling, and Ben answer verification.
5. CI must execute the JVM unit-test task and the explicit Crashlytics native-symbol upload task; a release build alone is not considered test-complete.

## Deliberately not introduced yet
- No wholesale SQLiteOpenHelper-to-Room rewrite: the current DB layer already uses one shared `SQLiteOpenHelper` provider per process and a migration would touch the largest persistence surface. Room can be introduced incrementally after stability evidence, preserving the existing on-disk schema.
- No GWP-ASan production rollout: it is a diagnostic memory-corruption tool, not a replacement for Crashlytics NDK and should be enabled only when device/release diagnostics justify the overhead and compatibility review.
- No blanket replacement of every `runCatching`: only coroutine cancellation-sensitive paths should be changed based on code-path evidence; broad mechanical rewrites create unnecessary regression risk.
