# Rovex v8.3.274 Offline Performance/UX Patch

This compact source snapshot is derived from the latest green v8.3.274 CI-verified source artifact and then patched locally in this chat.

## Changes
- Dashboard section switching now uses a cached `DashboardSnapshot` instead of re-querying QBank progress and flashcard SQLite data on every section switch.
- Flashcard database summary is loaded lazily only when Cards is opened.
- QBank dashboard is fixed to 19 canonical subject groups, with Community Medicine and PSM merged.
- Added separate collapsed collections for PYQ, Custom, Subject Test, Image Test, and Other Test.
- QBank children remain available under each collapsed box, avoiding construction of hundreds of child views until requested.
- Mastery renders the 19 canonical subject summaries rather than the full sub-QBank list.
- Frankenstein result callbacks are guarded so rendering/memory callback exceptions do not escape the worker boundary and crash the app.
- AMOLED HTML text rendering removes both foreground and background color spans and re-applies visibility after dynamic question rendering.
- Heavy Qualcomm QNN/LiteRT Qualcomm native binaries were removed from this compact source because the current stable architecture deliberately does not use them; CI already removes/guards these binaries during its correction pipeline.

## Verification
- Python repair scripts compile successfully.
- ZIP integrity verified.
- Full Android Gradle compilation was not possible in this offline container because the Gradle distribution host was unavailable by DNS. The preceding GitHub Actions run #955 was fully green for the unmodified v8.3.274 release pipeline.
