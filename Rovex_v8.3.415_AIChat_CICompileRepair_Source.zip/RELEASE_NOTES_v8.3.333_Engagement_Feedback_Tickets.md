# Rovex v8.3.333 — Engagement, Motion & Feedback Tickets

Implemented the remaining motion/feedback tickets from the requested UX batch:

- Ticket 4: reusable non-blocking milestone particle celebration driven by StudyEventSpine; streak, deck-completion and question-count milestones are persisted/tracked.
- Ticket 5: subtle breathing amber border on the Home flashcard due/performance card; animation stops when the view is not visible.
- Ticket 6: shared ValueAnimator/Decelerate count helper with unchanged-value suppression; Performance Lab accuracy/solved/wrong and progress bars animate on changed data.
- Ticket 7: compact procedural Ben synapse thinking indicator tied to request/response/error lifecycle.
- Ticket 8: optional SoundPool feedback, off by default, with silent/vibrate and DND checks; Settings toggle is immediate.

The existing five-destination persistent navigation and exact launcher-only logo from v8.3.331/v8.3.332 are preserved.

Android compilation remains a CI gate; local Gradle compilation could not run because downloads.gradle.org DNS is unavailable in the source environment.
