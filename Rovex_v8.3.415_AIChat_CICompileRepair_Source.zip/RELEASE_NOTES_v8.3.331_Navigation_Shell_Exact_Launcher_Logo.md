# v8.3.331 — Navigation shell correction

- Removed the legacy four-destination in-content Home footer from RovexHomeRevolution.
- RovexBottomNavigation is now the sole persistent bottom-navigation owner.
- Corrected edge-to-edge bottom inset math: navigation sits above the live system navigation inset instead of subtracting it.
- Protected scroll content with the navigation shell footprint without creating a second footer.
- Preserved the exact launcher logo resource `rovex_app_logo.jpg`; it is manifest-only and is not rendered in the in-app Home header.
- VersionCode 424.

Android compilation remains a GitHub Actions gate.
