# Rovex v8.3.380 — Local QBank Retrieval Root Fix

- Introduces `LocalQBankSearchService` as the single deterministic local-QBank retrieval composition layer.
- Frankenstein/Ren, SearchActivity and the grounded neural evidence pipeline now share the same bounded clinical terminology expansion and literal+alias recall contract.
- Sparse literal hits no longer suppress clinically equivalent aliases.
- Short topic prompts with terminal punctuation (for example `cervical cancer?`) remain deterministic local retrieval requests unless an actual interrogative/explanatory cue is present.
- Keeps QBankDb authoritative for corpus access; the service does not own ranking, AI, learner state or UI.
- Preserves deterministic fallback before optional neural generation.
- Android compilation/CI must still be verified by GitHub Actions; local Gradle distribution access is unavailable in the current environment.
