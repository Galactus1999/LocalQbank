# Rovex v8.3.392 release/source audit

Baseline: v8.3.391 / versionCode 483
Candidate: v8.3.392 / versionCode 484

## CI failure investigated
Uploaded CI log `logs_97807643986.zip` was inspected directly.

The workflow successfully:
- selected `Rovex_v8.3.391_Flashcard_AnkiImport_Delete_RichText_Source.zip`;
- restored the Qualcomm runtime;
- passed the source integrity audit;
- reached and executed `:app:testDebugUnitTest`.

The JVM test task failed with exactly 3 failing tests out of 53:
- `RovexMarkdownTableParserTest.chatTableOffRendersReadableSectionsInsteadOfGrid` at line 60
- `RovexMarkdownTableParserTest.collapsedProviderTableIsRecovered` at line 76
- `RovexMarkdownTableParserTest.tablesRemainTablesWhenEnabled` at line 69

Raw CI result:
`53 tests completed, 3 failed`
`Execution failed for task ':app:testDebugUnitTest'.`
`BUILD FAILED in 2m 40s`

## Root cause
`rovexMarkdownBody()` parses Markdown tables into `pre`, but v8.3.391 never assigned `pre.toString()` back to `s` before continuing the rendering pipeline.

Therefore the table parsing/rendering branch was effectively discarded. This explains all three failing table tests:
- enabled tables were never emitted;
- disabled tables were never converted to readable sections;
- collapsed GFM normalization could run, but its reconstructed table was still discarded because the subsequent loop operated on the original `s`.

## Fix
Immediately after the table-processing loop:

```kotlin
s = pre.toString()
```

The assignment is deliberately placed before HTML preservation/escaping so the generated table tokens enter the remainder of the existing renderer.

No test was weakened or deleted.

## Version
- versionName: `8.3.392`
- versionCode: `484`

## Static verification
- changed `RovexMarkdown.kt` contains `s = pre.toString()` immediately after the table loop;
- versionCode/versionName updated monotonically;
- no test files were modified;
- source ZIP integrity verified after packaging.

## Build/test verification
The v8.3.391 CI test run is authoritative evidence of the pre-fix failure.

The v8.3.392 test suite has NOT been run successfully in this environment because the Gradle wrapper requires Gradle 9.3.1 and `downloads.gradle.org` is not DNS-resolvable here. Therefore CI-green is not claimed.

## Runtime verification
Not yet verified on the OnePlus CPH2691 / Android 16 device.
