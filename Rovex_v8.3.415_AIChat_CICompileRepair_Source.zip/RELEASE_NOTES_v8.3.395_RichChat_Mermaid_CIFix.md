# Rovex v8.3.395 — Rich Chat Mermaid CI Repair

- Fixed Mermaid sequence participant aliases: `participant A as Doctor` now displays `Doctor` while preserving `A` as the edge ID.
- Fixed direct/unfenced Mermaid `subgraph ...` fragments so they render as a `rich-mermaid-fragment` rather than plain/raw source.
- Mermaid-only `classDef`, `class`, `style`, and `linkStyle` directives are excluded from that fragment rendering.
- Existing tests are retained; no test was weakened or removed.
- Full CI/device verification remains pending.
