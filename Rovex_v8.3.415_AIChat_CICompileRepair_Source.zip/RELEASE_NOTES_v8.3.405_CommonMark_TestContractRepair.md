# Rovex v8.3.405 — CommonMark test-contract repair

## Defect
The v8.3.404 CI run compiled the app but failed the JVM suite: 76 tests completed, 8 failed. The failures were concentrated in rich-renderer tests whose assertions still expected serialization from the former regex renderer (`<b>`, `<hr>`, whitespace-free `<ul>`) rather than standards-based CommonMark HTML (`<strong>`, `<hr />`, newline-separated block elements).

## Repair
- Updated rich-renderer regression assertions to validate semantic HTML structure rather than legacy exact serialization.
- Updated the flashcard Markdown bold regression to accept the CommonMark `<strong>` element.
- Kept the table-as-sections contract aligned with the existing renderer (`<b>Finding</b>: ...`).
- No production Ben, IPC, APKG, QBank, SRS, or importer architecture was changed.

## Verification
CI must rerun the full JVM suite and release workflow. Local Gradle verification is blocked in this environment because `downloads.gradle.org` DNS resolution is unavailable.
