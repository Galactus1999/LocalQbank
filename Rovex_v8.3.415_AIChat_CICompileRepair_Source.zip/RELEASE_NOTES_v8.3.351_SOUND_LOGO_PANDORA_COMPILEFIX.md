# Rovex v8.3.351 — Sound + Logo Identity + Pandora Living World + CI Compile Fix

- versionName: 8.3.351
- versionCode: 444
- Baseline: v8.3.350 / code 443.

## CI failure repaired
The uploaded CI log failed at `NotesActivity.kt:300` because `ViewGroup` was referenced by the new WebView cleanup without importing `android.view.ViewGroup`. The resulting `childCount`/`getChildAt` errors were secondary unresolved references. The missing import is now added.

## Attached button-click sound
- The supplied 48 ms MP3 is now packaged as `res/raw/rovex_button_click.mp3`.
- `RovexSoundFeedback` now has a dedicated CLICK cue.
- The Settings TEST action previews the supplied click sound.
- The immersive chat reveal/control button uses the same click cue when sound feedback is enabled.
- Existing correct/milestone cues remain separate.

## Rovex header identity
- Removed the old moving Earth-like header artwork.
- Replaced it with the actual `rovex_app_logo.jpg` application logo.
- Added lightweight cyan/violet emission and animated lightning arcs originating from the logo.
- No external bitmap/video is added for the header.

## Pandora theme
- Reworked Pandora from predominantly green to a multi-colour bioluminescent world:
  cyan/electric blue, violet, magenta, teal and warm amber.
- Added generic humanoid explorer silhouettes, planets/moons, flying fauna, deer-like ground fauna, glowing flowers, spores/fireflies, layered mountains and water-light.
- The scene remains procedural/offline to avoid shipping large copyrighted wallpaper files.
- Visual direction was cross-checked against public Pandora/bioluminescent wallpaper references; the app uses an original procedural composition rather than bundling third-party wallpaper assets.

## Verification
- Source audit and targeted static checks performed offline.
- Full local Gradle compilation remains environment-dependent; GitHub Actions is the authoritative build gate.
