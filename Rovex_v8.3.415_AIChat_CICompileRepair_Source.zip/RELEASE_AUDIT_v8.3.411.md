# Rovex v8.3.411 — Regression Repair Audit

## Defect
Functional search regression in the normalized SQLite LIKE fallback used by `QBankDb.search()` and `QBankDb.searchImageQuestions()`.

## Root cause
The two fallback SQL builders used `ESCAPE '\\\\'` in Kotlin source, which resolves to a two-character SQLite escape expression (`\\`). SQLite requires the ESCAPE expression to be exactly one character. `escapeLike()` correctly escapes `%`, `_`, and `\\` using a single backslash, so the fallback SQL and parameter escaping were inconsistent.

`searchSections()` already used the correct Kotlin source form `ESCAPE '\\'`, resolving to one backslash at runtime.

## Repair
Changed all 24 malformed ESCAPE clauses in the two affected `likeRows()` builders to the same source form used by `searchSections()`. No other search logic was changed.

Added `QBankDbSearchRegressionTest` as an Android instrumented regression test covering both affected public methods against a deliberately dirty/empty FTS index so the normalized-table LIKE fallback is exercised. The test searches for `acid_base`, verifying underscore escaping and returned-row correctness.

## Verification
- Kotlin runtime escape micro-test: PASS; generated SQLite ESCAPE literal length = 1.
- SQLite in-memory semantic test: PASS; escaped underscore query returns expected row.
- Source scan: 0 remaining four-backslash ESCAPE clauses in `QBankDb.kt`.
- Correct one-backslash ESCAPE clauses present in all 30 relevant predicates.
- Version: 8.3.411 / versionCode 503.
- Full Android Gradle/instrumented test execution: PENDING; local Gradle distribution download is environment-blocked by DNS if applicable. Do not claim CI green until executed on GitHub Actions.

## Regression classification
v8.3.410 contains a confirmed functional regression relative to the intended search behavior. It is release-blocking. v8.3.411 is a repair candidate until CI and device verification pass.

## Scope note
The separate rich-chat OOM/full-history re-render/performance concerns remain tracked and are not silently marked fixed by this search repair. Current `addChatTurn()` itself does not contain the claimed missing `isFinishing/isDestroyed` guard; the lifecycle checks exist in surrounding UI/request paths. That particular claim should therefore not be treated as a confirmed defect without a specific reproducer.
