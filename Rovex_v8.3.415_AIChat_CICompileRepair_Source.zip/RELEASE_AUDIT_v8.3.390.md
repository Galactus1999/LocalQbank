# Rovex v8.3.390 Release Audit

## Baseline
- Previous source: v8.3.389 / versionCode 481
- Current source: v8.3.390 / versionCode 482
- Package: com.localqbank.library
- Target SDK: 36

## Root-cause findings from device log
1. Flashcard import crash was caused by Android 16 rejecting WorkManager's foreground service start because `ForegroundInfo` supplied service type `none` while the app targets SDK 36. The manifest already declared `dataSync`; the missing piece was the runtime `ForegroundInfo` service-type bit.
2. The tap sound asset was a 48 ms MP3. Device log showed MediaExtractor error -1010 followed by `SoundPool::Sound: doLoad: unable to load sound`. The exact supplied sound was preserved semantically and re-encoded as PCM WAV under the same resource name.
3. Explanation note selection was unreachable because `configureNoteSelection()` was guarded by `role == "note"` while the explanation is rendered with role `"explanation"`.
4. Imported explanations containing Markdown emphasis were rendered directly as HTML, so literal `**bold**` could appear. They now pass through the existing Rovex Markdown-to-HTML body renderer before theme-safe HTML rendering.
5. Deck deletion could fail against legacy Anki hierarchy delimiters because SQL deletion assumed `::`; deletion now normalizes stored names before matching descendants.

## Static verification
- XML parse errors: 0
- Duplicate IDs within individual layout files: 0
- APK sound resource: PCM WAV, 48 kHz mono, 16-bit, 46.875 ms
- Supplied tap sound MP3 SHA-256: 8d81cbfe9a05b30da6730f03c1976e59143cb425f8fa4d9e4129df6f65643b7a
- Source ZIP integrity: PASS
- Manifest FGS type: dataSync
- Worker runtime FGS type: FOREGROUND_SERVICE_TYPE_DATA_SYNC on API 29+
- Explanation Markdown path: PASS
- Explanation selection path: PASS

## Build verification
Command:
`./gradlew :app:testDebugUnitTest --no-daemon --stacktrace`

Result: BLOCKED before build because Gradle distribution host DNS cannot resolve `downloads.gradle.org`.

Raw failure:
`curl: (6) Could not resolve host: downloads.gradle.org`

Exit status: 6.

## Runtime verification
Not yet verified on-device for v8.3.390. The v8.3.389 log proves the original crash root cause; the v8.3.390 correction must still be exercised on the target Android 16 device.
