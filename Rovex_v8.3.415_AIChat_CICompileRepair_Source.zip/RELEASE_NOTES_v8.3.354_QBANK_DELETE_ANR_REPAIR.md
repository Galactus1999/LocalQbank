# Rovex v8.3.354 — QBank Delete ANR Repair

- versionName: 8.3.354
- versionCode: 447

## Root cause addressed
The supplied OnePlus/Android 16 LADB capture showed a foreground input ANR while QBank deletion was running. The qbank-worker consumed very high CPU and the foreground MainQBankLibraryActivity missed its input deadline.

## Repair
- Added a dedicated single-flight `qbank-delete-worker` at lowest process priority.
- Replaced the per-test deletion loop with set-based SQLite deletion.
- Uses WAL-friendly `beginTransactionNonExclusive()` for normalized data and FTS cleanup.
- Materializes question/test IDs once in temporary indexed tables instead of repeatedly rescanning question/test for every child table.
- FTS cleanup is separated from the normalized-data transaction so the main database transaction is shorter.
- Preserved progress, resume metadata, question notes/images, options, legacy progress, tests, and source cleanup.
- Both QBank-library and Home deletion routes use the same serialized low-priority deletion executor.

## Verification
- Source version bumped from 8.3.353/code 446 to 8.3.354/code 447.
- Source/static audits performed.
- Full Gradle compilation could not be performed locally because `downloads.gradle.org` DNS is unavailable in the current environment; GitHub Actions remains the authoritative build gate.
