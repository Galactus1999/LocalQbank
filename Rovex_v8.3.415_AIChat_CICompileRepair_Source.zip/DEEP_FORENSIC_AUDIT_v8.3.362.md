# Rovex v8.3.362 — Deep Forensic Stability / Performance / WebView Audit

## Baseline
- Previous baseline: v8.3.361 / versionCode 454
- New source: v8.3.362 / versionCode 455
- Package/applicationId: `com.localqbank.library`
- Android compilation: **NOT VERIFIED locally**. The Gradle wrapper attempted to download Gradle 9.3.1 and DNS resolution for `downloads.gradle.org` failed. GitHub Actions remains the authoritative build gate.

## Previous-fix verification
The v8.3.361 repairs were re-audited rather than assumed correct.

### Confirmed correct
1. Production Home starts from a minimal `dashboardRoot`; the old XML dashboard is no longer inflated into a hidden runtime tree.
2. Modern Home navigation no longer uses legacy `performClick()` bridges. The only remaining `performClick()` is the legitimate touch-accessibility forwarding in `FlashcardStudyActivity`.
3. QBank library ordering reads/writes are intended to stay off the UI thread.
4. Search index dirty state exists and interactive search has a bounded fallback path.
5. Bookmark/progress refresh work is consolidated instead of repeatedly scanning the DB from Home construction.
6. Milestone targeting uses modern Home tags.

### Defects still present after v8.3.361
1. **QBank library render still persisted order on the main thread.** `renderSources()` called `persistOrder()` after the earlier background refactor. Fixed: persistence now occurs in the background load worker; rendering is UI-only.
2. **Main QBank metadata edit was asynchronous in `MainQBankLibraryActivity`, but the parallel MainActivity ViewModel path was still synchronous.** Fixed: `MainViewModel.updateSourceMetadata()` now executes through the shared background executor and returns a main-thread callback.
3. **TestListActivity still constructed `QBankDb`/`ProgressStore` on the main thread and the adapter read resume position from `ProgressStore` during `onBindViewHolder`.** Fixed: TestList now consumes the already-loaded `ProgressSummary.resumePosition`; DB handles are worker-scoped.
4. **Study Tools could execute full-QBank `PerformanceManager.refs/lightRefs/progress` scans directly from click callbacks.** Fixed: revision/weak/unsolved/wrong/PYQ/mistake/custom/exam pool generation is now worker-side, with UI navigation only after the IDs are ready. `ProgressSnapshot` now also carries the stored mistake tag, eliminating per-question DB calls for mistake review.
5. **SearchActivity constructed `QBankDb` and `ProgressStore` during Activity creation.** Fixed: database access is now operation-scoped inside the search worker; the Activity starts with UI only.
6. **Search filter changes could race two searches using the same generation value.** Fixed: filter changes increment the search generation before launching the new query.
7. **Search result opening performed a synchronous `testById()` query on the main thread.** Fixed: existence validation is now backgrounded before navigation.
8. **NotesActivity performed note-record DB reads, select-all reads, question validation, and note deletions on the UI thread.** Fixed: all DB work is worker-side with generation-based stale-result suppression.
9. **Knowledge Vault scanned files and queried question context on the UI thread on every search/filter change.** Fixed: artifact discovery/filtering is worker-side with generation-based stale-result suppression.
10. **Home QBank-card tap still performed `MainRepository.resumeTarget()` synchronously on the main thread.** Fixed: resume lookup is now backgrounded.
11. **Performance Lab could call `PerformanceManager.progress()` from its UI rendering path after refs were loaded.** Fixed: the progress snapshot is prepared off-main and passed into the prepared renderer.
12. **FTS health had a subtle same-count stale-index hole.** A missing/stale FTS row can coexist with an equal row count. v8.3.361's count+dirty scheme reduced this risk but still allowed a mutation path to mark clean solely from counts. Fixed: mutations never publish the clean state. The authoritative rebuild is now the only operation that sets `dirty=0`; mutation paths schedule repair instead.
13. **WebView renderer termination was not uniformly contained.** Fixed by introducing `RovexSafeWebViewClient`, applied across Rovex WebViews. Dead renderers are detached/stopped/destroyed and the app remains alive. Existing specialized WebView callbacks remain in their subclasses.
14. **Quiz fallback/full-screen WebViews used `MIXED_CONTENT_ALWAYS_ALLOW`.** Fixed to `MIXED_CONTENT_COMPATIBILITY_MODE` to reduce unnecessary mixed-content exposure while retaining compatibility with legacy QBank media.
15. **NoteFullScreenViewer did not explicitly destroy its WebView on dialog dismissal.** Fixed with explicit stop/detach/destroy lifecycle cleanup.
16. **Custom Flashcard/Quiz renderer-gone paths destroyed WebViews without explicitly detaching them first.** Fixed to detach before destroy.

## Architecture principles applied
- UI thread owns View creation/mutation only.
- Local SQLite remains the authoritative offline source of truth.
- Background workers perform DB/file/index computation.
- Shared `PerformanceManager` serialization continues to bound CPU/SQLite contention.
- Destructive QBank deletion remains on the dedicated lowest-priority deletion executor.
- No parallel business-logic owner was introduced.
- No heavyweight neural model or IPC rewrite was introduced.
- No WorkManager migration was made for interactive foreground work; WorkManager remains appropriate for durable deferred backup/import-style work.

## Current Android guidance used
- Android documents that the main thread handles UI/input/drawing and that blocking it can produce jank and five-second input-dispatch ANRs.
- Android's offline-first guidance identifies the local data source as the canonical source of truth and recommends local reads without waiting for network state.
- Android's SQLite guidance recommends WAL and appropriate indexing; Rovex already has WAL, so this release does not replace the working database architecture.
- Android's WebView guidance states that WebView has substantial native memory cost, must be explicitly destroyed when no longer needed, and renderer termination must be handled with `onRenderProcessGone`.
- Android guidance discourages `MIXED_CONTENT_ALWAYS_ALLOW`; Rovex now uses the compatibility mode where legacy media requires mixed-content support.

## Static verification
- XML parse errors: 0
- Duplicate IDs within individual XML files: 0
- Remaining `performClick()` calls: 1, only legitimate touch forwarding in `FlashcardStudyActivity`
- Package/applicationId preserved: `com.localqbank.library`
- versionName: `8.3.362`
- versionCode: `455`
- Modified Kotlin brace/parenthesis/bracket balance: passed for all modified Kotlin files
- ZIP integrity: required after packaging

## Build verification limitation
Local Gradle compilation was attempted with:
`./gradlew --offline :app:compileDebugKotlin --no-daemon`
The wrapper attempted to download Gradle 9.3.1 and failed because `downloads.gradle.org` could not be resolved by DNS. Therefore this source must not be described as CI-green until GitHub Actions completes successfully.

## Device regression gate
After CI produces the release APK, test in this order:
1. Cold launch.
2. Home → QBank.
3. Open all 19 canonical subjects.
4. Expand several subject categories and open a QBank.
5. Back to QBank and rapid Home/QBank switching.
6. Search `cervical cancer` and several QBank names.
7. Change search filters rapidly while typing.
8. Open a search result.
9. Frankenstein query → rendered answer → Notes save/open → rich table note.
10. Notes search/filter/select-all/delete stress.
11. Knowledge Vault search/filter/open/delete.
12. Study Tools → Today's Revision / Weakest 50 / Unsolved / Wrong / PYQ / Custom / Exam.
13. Edit main QBank name/series and sub-QBank name/series.
14. Large-QBank deletion stress while repeatedly touching/navigating.
15. WebView renderer-pressure tests: long rich answers, many images, Notes rich tables, Google Search, Flashcards.
16. Repeat under low-memory/thermal pressure.
17. Inspect Logcat/ANR traces and persistent performance markers.

## Release rule
No APK is considered release-ready until the complete GitHub Actions release workflow passes, including the existing signing-certificate fingerprint assertion and Zstandard Android AAR assertion.
