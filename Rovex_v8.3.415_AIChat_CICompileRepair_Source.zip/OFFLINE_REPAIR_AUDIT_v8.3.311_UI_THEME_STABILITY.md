# Rovex v8.3.311 Offline UI / Theme / Stability Repair Audit

Baseline: v8.3.309 source.

## Repairs
- Rebuild MainActivity home shell when Settings changes the global theme, preventing mixed-theme custom dashboard views.
- Dark theme home cards now use dark adaptive surfaces rather than light pastel fills.
- Replaced Home's Today-only accuracy chart with a 28-day study-history graph: solved-volume columns plus accuracy dots.
- Added original lightweight procedural Earth-like planet rendering to Space/Cosmos and retained OLED-conscious sparse rendering for AMOLED.
- Added an original procedural Frankenstein logo view and placed it in the Home Frankenstein card and Frankenstein workspace header.
- Restored animated Dr. Frankenstein jumping wordmark and Ben+AI flowing-color heading.
- Responsive Ben/Frankenstein tables now fit the viewport by default and wrap long cell content; horizontal scrolling remains available for genuinely oversized content.
- Main Imported QBank IMPORT button now launches the Storage Access Framework directly, supports multiple HTML files, persists URI read access, and hands selected URIs to the existing importer.
- Main QBank library refreshes after returning from import and rebuilds on theme changes.
- Version metadata advanced to versionCode 404 / versionName 8.3.311.

## Audits
- XML parsing: PASS (27 XML files)
- Duplicate IDs within individual layouts: PASS
- Frankenstein policy audit: PASS
- AMOLED foreground audit: PASS (0 hard-coded black foreground candidates)
- Phase-2 stability assertions: PASS
- Architecture audit: PASS with existing large-file warnings
- Architecture regression audit: existing baseline warnings remain for MainActivity size and RenActivity direct chat preference access; no new broad Throwable catch or unsafe child reparent pattern introduced.
- Local Gradle compilation: NOT VERIFIED because downloads.gradle.org DNS is unavailable in the execution environment.
