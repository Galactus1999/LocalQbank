# v8.3.372 — Search, Rich Chat, Sound, and Resume Root-Cause Repair

## Baseline
- v8.3.371 / versionCode 464
- New version: v8.3.372 / versionCode 465

## Main QBank search
The search UI previously placed optional FTS preparation, the PerformanceManager progress snapshot, section search, and question search in one failure path. An unrelated progress/cache failure could therefore make the primary search appear broken even though the authoritative QBank database was available.

Repair:
- FTS preparation is best-effort.
- ProgressSnapshot has an empty immutable fallback.
- Section and question retrieval have independent failure boundaries.
- QBankDb.search() remains authoritative and retains its FTS -> normalized SQLite fallback.
- Search failures are breadcrumbed by stage instead of collapsing the whole result path.

## Uploaded sound
The supplied `denielcz-immersivecontrol-button-click-sound-463065.mp3` was verified byte-for-byte against `res/raw/rovex_button_click.mp3`: SHA-256 `8d81cbfe9a05b30da6730f03c1976e59143cb425f8fa4d9e4129df6f65643b7a`. The binary asset was already correct; the defect was incomplete call-site deployment.

Repair:
- Quiz question-option taps call the supplied click sound.
- The separate correct-answer sound is removed from that answer interaction, so the interaction emits only the supplied sound.
- Flashcard card taps and flashcard button controls call the same supplied click sound.

## Frankenstein / Ben+AI rich chat
The screenshot contains valid Mermaid source (`subgraph`, `:::stage`, `classDef`) rendered as raw code. The previous renderer recognized only a limited Mermaid subset; a valid subgraph-first fragment fell through to `<pre>`. The table path similarly depended too heavily on strict line-oriented Markdown and did not normalize provider HTML tables.

Repair:
- Mermaid subgraph/classDef/node fragments render as safe rich blocks.
- HTML `<table>` responses become native scrollable tables.
- Rich blocks are protected from paragraph wrapping.
- Existing fenced Mermaid/chart/tree/slides handling remains.
- Regression tests cover HTML tables and Mermaid subgraph output.

## Chat continuity
RenActivity kept the visible transcript in a ViewModel but did not write new turns into the already-existing bounded RenMemoryStore. Process recreation therefore lost the conversational transcript.

Repair:
- New bounded turns are persisted to RenMemoryStore.
- Stored turns are hydrated before the chat WebView is built.
- The model still receives only a bounded recent context window.

## Today/Home Continue
The resume path could fall back to a bare position and used a broad `contains("collection")` check. Resume targets now carry question identity where available, and Home Continue passes the exact questionId to QuizActivity. Global/source fallback positions are resolved back to the actual question before navigation. Collection detection now requires the exact `:collection` session suffix.

## Research basis
Current AI platform documentation describes function/tool calling as an application-controlled loop and structured outputs as schema-constrained final presentation; multi-turn systems preserve prior interaction/tool results as conversation state. citeturn1search0turn1search1turn1search5

## Validation
- XML parse errors: 0
- Duplicate IDs within individual XML layouts: 0
- Kotlin source files scanned: 217
- `runBlocking`: 0
- `GlobalScope`: 0
- `Thread.sleep`: 0
- `catch(Throwable)`: 0
- Supplied click sound SHA-256 matches exact uploaded file.
- Local Gradle compile was attempted and blocked before compilation because `downloads.gradle.org` could not be resolved. Android compilation is therefore NOT verified.
- GitHub Actions remains the authoritative build gate. v8.3.372 must not be called CI-green until the complete workflow succeeds.
