# Rovex v8.3.371 — Frankenstein Root-Cause Hardening + Real Chat Tables

Baseline: v8.3.370 / versionCode 463
Release: v8.3.371 / versionCode 464

## Root causes addressed
1. FrankensteinSupportEngine converted any exception from the deterministic cognitive route into the user-visible generic message `I could not complete that request safely`. This masked the actual failing layer and made a recoverable local-search failure appear like a safety refusal.
2. RenCognitiveEngine had no bounded raw-QBank fallback if the clinical terminology/ranking layer threw. The authoritative QBank database path therefore was not reachable when an upstream enrichment layer failed.
3. Chat table presentation defaulted `show_tables_in_chat` to false, so valid Markdown tables were deliberately converted into section cards unless the user explicitly requested a table or changed the setting. This was inconsistent with the chat requirement for real table rendering.

## Repairs
- Added staged deterministic recovery in RenCognitiveEngine: clinical-understanding failure -> raw local QBank retrieval; ranked-search failure -> raw local QBank retrieval.
- Added failure breadcrumbs/logging with exception class names at each recovery boundary.
- Hardened search-ID retrieval with bounded direct database fallback.
- Hardened FrankensteinSupportEngine's final containment boundary so internal exceptions no longer immediately produce the old generic safety phrase; it attempts the deterministic retrieval recovery path first.
- Changed chat table preference default to true. Existing user preference remains authoritative; real Markdown tables use the existing horizontally scrollable renderer.
- Preserved bounded table limits (12 columns / 80 rows) and existing safe Markdown sanitization.

## Structural checks
- XML parsing: pass
- duplicate IDs within each XML layout: pass
- runBlocking: 0
- GlobalScope: 0
- Thread.sleep: 0
- no new catch(Throwable) introduced

## Verification status
- Source repair completed.
- Android/Gradle compilation is NOT claimed here until GitHub Actions verifies v8.3.371.
