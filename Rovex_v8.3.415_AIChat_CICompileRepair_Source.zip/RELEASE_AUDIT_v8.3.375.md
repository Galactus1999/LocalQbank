# Rovex v8.3.375 Release Audit

Baseline: v8.3.374 / versionCode 467.
Target: v8.3.375 / versionCode 468.

## CI root-cause repair
The uploaded v8.3.374 CI log failed during Kotlin compilation in `RovexMarkdown.kt`.
The primary source defect was:
`replace("&quot;", """)`
inside `htmlCellText()`. The malformed Kotlin string terminated the source string and caused a large cascade of unresolved references and syntax errors throughout the remainder of the file, including the `wrapMarkdownDocument()` CSS/HTML block.

The repair is:
`replace("&quot;", "\\\"")`
so the HTML quote entity is decoded to a literal double-quote without breaking the Kotlin source.

No renderer functionality was removed and no failing test was disabled.

## Structural audit
- XML files: 37
- XML parse errors: 0
- Duplicate IDs within individual XML layouts: 0
- Kotlin files: 217
- `runBlocking`: 0
- `GlobalScope`: 0
- `Thread.sleep`: 0
- `catch(Throwable)`: 0
- supplied click sound SHA-256: `8d81cbfe9a05b30da6730f03c1976e59143cb425f8fa4d9e4129df6f65643b7a`
- versionCode: 468
- versionName: 8.3.375

## Verification status
Local full Android Gradle compilation is not claimed; this environment has previously been unable to resolve `downloads.gradle.org` for the required Gradle distribution.
CI/device validation remains required. v8.3.375 is **not CI-green until the complete GitHub Actions workflow succeeds**.
