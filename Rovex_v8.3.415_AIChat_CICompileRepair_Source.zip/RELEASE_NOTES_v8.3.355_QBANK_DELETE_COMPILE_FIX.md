# Rovex v8.3.355 — QBank Delete Compile Fix

- Version code: 448
- Version name: 8.3.355
- Baseline: v8.3.354 QBank Delete ANR repair.

## Repair
v8.3.354 moved QBank deletion onto the dedicated low-priority deletion executor, but its `MainViewModel` completion path incorrectly called suspend `withContext()` from the executor's ordinary `() -> Unit` callback. CI correctly rejected that source.

v8.3.355 removes that invalid coroutine boundary and posts the completion/state-refresh work explicitly to the Android main looper with `Handler(Looper.getMainLooper())`.

The destructive deletion itself remains on the serialized lowest-priority `qbank-delete-worker`; no deletion database work is moved back to the UI thread.

## Verification status
- Source/static checks: performed before packaging.
- Local full Gradle compilation: not claimed; the environment previously could not resolve the Gradle distribution host.
- CI is the authoritative build gate.
