# v8.3.400 — Rich Chat CI Compile Fix

- Fixes the v8.3.399 JVM test compilation failure.
- `RovexRichRendererTest.contentHasExplicitNormalWeightContract` now tests through the public `rovexMarkdownToHtml()` API instead of calling the private `wrapMarkdownDocument()`.
- No production behavior change from v8.3.399.
- No changes to Ben IPC, EmbeddingGemma, APKG import, flashcards, QBank, SRS, or database architecture.
- CI/device verification remains required.
