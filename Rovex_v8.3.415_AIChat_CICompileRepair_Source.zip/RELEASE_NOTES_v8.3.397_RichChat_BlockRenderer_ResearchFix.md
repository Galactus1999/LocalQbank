# Rovex 8.3.397 — Rich Chat Block Renderer / Paragraph Repair

## Root cause
The chat renderer was not a CommonMark block parser. It wrapped the remaining response in `<p>` and converted every source newline to `<br>`, so normal Markdown soft breaks, headings, thematic breaks and lists lost block semantics. AI/provider output such as `...children. --- ### 2. ...` therefore appeared as one paragraph with literal Markdown/table syntax.

A second defect in `normalizeCollapsedGfmTables()` allowed its delimiter regex to consume newline characters. That could make `match.range.first - lineStart` negative when a normal multi-line GFM table was encountered.

## Repair
- Recover conservative provider block boundaries before table parsing.
- Render headings, thematic breaks, unordered lists and ordered lists as semantic HTML blocks.
- Keep ordinary soft line breaks inside a paragraph as whitespace instead of forcing `<br>`.
- Preserve existing Mermaid/rich-block tokenization before block parsing.
- Restrict collapsed-GFM delimiter recognition to a single physical line.
- Keep the existing safe custom Mermaid/SVG renderer and fallback behavior unchanged.
- No new JavaScript, CDN, network, WebView, AI/IPC, database, importer, or Ben dependency.

## Research basis
OpenRouter, Groq and DeepSeek chat APIs stream generated text as incremental content deltas; they do not define Android presentation semantics. Rich chat presentation therefore belongs in the client renderer. CommonMark defines paragraphs as sequences of non-blank lines and distinguishes block elements from soft line breaks. CommonMark-java 0.30.0 is current upstream, but this repair deliberately avoids replacing the existing renderer with a new dependency in a crash-sensitive patch. Markwon demonstrates a mature Android-native CommonMark/Spannable approach and supports paragraphs, lists, tables, HTML, images and more.

## Tests added
- appended heading + thematic break become semantic blocks
- ordinary soft breaks remain one paragraph
- adjacent bullet items become a semantic `<ul>`
