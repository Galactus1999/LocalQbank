# Rovex v8.3.358 — Resource Governance Phase 2

## Baseline
- v8.3.357 / versionCode 450
- Current objective: reduce foreground CPU contention after the documented QBank-deletion input ANR.

## Changes
- Changed `PerformanceManager` shared background executor from two workers to one worker.
- Kept the worker at Android background priority.
- Kept the dedicated QBank-deletion executor serialized at `THREAD_PRIORITY_LOWEST`.
- No database schema, deletion semantics, UI business logic, or Ben inference architecture changes.

## Rationale
The LADB capture showed `com.localqbank.library` and `qbank-worker` consuming very high CPU around the input-dispatch timeout. A second worker allows independent database-heavy tasks to overlap with deletion and increases CPU/I/O contention. A single shared worker bounds this class of background concurrency while preserving asynchronous execution.

This is deliberately a small, reversible stability change before larger workload-specific optimizations.

## Verification required
- Whole-project source/XML audit.
- Kotlin compile through GitHub Actions.
- Release APK/signing/Zstd/Firebase checks through the existing CI workflow.
- Device stress test: large QBank deletion while navigating/scrolling the foreground library.
- Compare `RovexPerf` traces and ANR evidence before/after.

CI-green is **not claimed** until the complete workflow succeeds.
