# Rovex v8.3.336 — Quiz answer crash boundary, compact navigation, real AI tables

## Root causes addressed
- Quiz answer: persistence already moved off the UI thread in v8.3.334, but the post-commit UI callback could still crash while rendering explanation/media. v8.3.336 makes the durable answer boundary explicit and isolates optional answer-feedback rendering with non-fatal diagnostics.
- AI tables: the provider can collapse Markdown table header/separator/rows onto one physical line. The old renderer recognized the separator but could leave the following cells as one malformed row. The renderer now uses the separator's column count to normalize collapsed rows deterministically.
- Frankenstein navigation: RenActivity no longer installs the persistent five-tab navigation bar.
- Bottom navigation: replaced the Material BottomNavigationView shell with an exact 50dp native five-item shell, removing Material-3 minimum-height/active-indicator behavior and duplicate shell styling.
- Settings sound feedback: compact SwitchCompat with bounded dimensions and zero default minimum sizing.
- WebView lifecycle: Ben question chat WebView is explicitly destroyed when its dialog is dismissed.
- Duplicate installs: removed redundant bottom-nav installation from MainActivity and FlashcardActivity.
