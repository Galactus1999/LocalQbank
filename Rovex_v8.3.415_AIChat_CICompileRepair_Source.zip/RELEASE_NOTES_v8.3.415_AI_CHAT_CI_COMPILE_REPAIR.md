# Rovex v8.3.415 — AI Chat CI Compile Repair

## Trigger
GitHub Actions JVM-test stage for v8.3.414 failed during Kotlin compilation.

## Verified compiler findings
1. `BenCloudAiGateway.kt`: `cfg.id` referenced a `Config` object without an `id` property; provider ID is `cfg.provider.id`.
2. `BenQuestionAiContextDialog.kt`: trailing lambda at the `renderFree()` call bound to `initialDocument` instead of `buttonState`; the call now uses named `buttonState`.
3. `BenQuestionAiContextDialog.kt`: `generateStreaming()` has `onChunk` before `explicitCloudAction`; the call used a trailing lambda after a named argument, producing missing/too-many argument errors. It now passes `onChunk = { ... }` explicitly.
4. `RovexChatDocument.kt`: a multiline string cannot be a `const val`; the JavaScript shell is now a regular `val`.

## No functional redesign
These are compile-contract repairs only. The v8.3.414 chat rendering/streaming design is preserved.

## Version
- versionName: 8.3.415
- versionCode: 507

## Verification status
Local Android Gradle verification depends on external Gradle/dependency availability. The uploaded CI log is the authoritative evidence for the above compile errors. No build is claimed green until CI completes successfully.
