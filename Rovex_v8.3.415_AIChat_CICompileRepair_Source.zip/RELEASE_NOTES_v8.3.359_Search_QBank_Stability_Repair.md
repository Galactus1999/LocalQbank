# Rovex v8.3.359 — QBank/Search Stability Repair

## Root-cause repair
The interactive search path previously called `QBankDb.ensureSearchIndex()`, which synchronously rebuilt the entire FTS4 corpus whenever `question_fts` row count differed from the normalized `question` table. On a large imported QBank this converted a user typing/search action into a potentially long SQLite write transaction and high CPU workload.

This is unsafe for a foreground medical study application and can explain search stalls/resource contention. The repair changes the contract:

- interactive search performs only a lightweight FTS schema/health check;
- an incomplete FTS index never triggers a synchronous full rebuild;
- search falls back to bounded normalized-table LIKE retrieval while FTS is incomplete;
- a single lowest-priority background worker may repair the FTS index;
- repeated searches are coalesced through the repair gate;
- the existing FTS path remains authoritative when its row count matches the question corpus.

## QBank launch stabilization
`MainQBankLibraryActivity` no longer starts duplicate source-load operations during the initial `onCreate` → `onResume` sequence.

The activity also avoids rewriting the persistent QBank order metadata when the order has not changed.

## Scope
- versionCode: 452
- versionName: 8.3.359
- package/applicationId: com.localqbank.library

## Verification status
Source-level/static verification performed on the prepared source tree. Android compilation and CI release status are **not claimed green** until the GitHub Actions workflow completes successfully.
