# Rovex v8.3.364 — Deep Forensic Architecture Repair Audit

## Baseline
- Input: `Rovex_v8.3.363_Deep_Forensic_Repair2_Source.zip`
- Package/applicationId: `com.localqbank.library`
- Version: `8.3.364` / versionCode `457`
- Target SDK: 36; compile SDK: 37
- Source contained 522 files at extraction: 233 Kotlin, 38 XML, plus resources/assets.
- Modules: `:app`, `:benchmark`
- Git metadata was not present in the supplied ZIP; an audit-only Git repository/branch was created in the working copy.

## Validation limitation
The supplied Gradle wrapper requires Gradle 9.3.1. Local `./gradlew test --no-daemon --offline` could not start because the wrapper distribution was not cached and DNS could not resolve `downloads.gradle.org`. Therefore Android compilation, lint, unit-test execution, APK packaging, instrumentation tests, and runtime behavior are **not claimed as verified**.

## Deep findings confirmed from source

### F1 — P1 — Quiz foreground progress path could synchronously touch SQLite
- Locations: `QuizActivity.kt` around question rendering/answer navigation; `QuizViewModel.kt` progress/persistence methods.
- Root cause: foreground rendering used `ProgressRepository` directly for status, selected answer, bookmark/mistake reads and position/time persistence. `ProgressStore` is SQLite-backed.
- Impact: question transitions and answer/UI callbacks could contend with SQLite and create frame stalls/ANR risk on large/contended databases.
- Fix: QuizViewModel now reads immutable `PerformanceManager` snapshots for foreground progress facts, maintains short-lived optimistic overlays for bookmark/mistake mutations, and queues position/time/mistake writes on the serialized QBank worker.
- Validation: static source inspection confirms the Activity no longer directly accesses `ProgressRepository`; runtime/build unverified.

### F2 — P1 — Flashcard study UI directly executed SQLite work
- Location: `FlashcardStudyActivity.kt`.
- Root cause: `FlashcardDb` queries/mutations were executed from `show()`, bookmark/mark taps, rating, undo, bury, suspend, and study-set navigation callbacks.
- Impact: flashcard interaction could block the UI thread, especially during due-card selection/rating.
- Fix: added a dedicated lifecycle-scoped `flashcard-study-db` executor, cached current card/count, asynchronous card loading, and background mutation paths. UI receives immutable results and renders them on main.
- Validation: static inspection confirms remaining `FlashcardDb` calls are confined to the executor path or lifecycle cleanup; runtime/build unverified.

### F3 — P1 — Performance Lab loaded SQLite-backed telemetry during Settings screen construction
- Location: `SettingsScreen.kt:addPerformance()`.
- Root cause: `PerformanceManager.lightRefs()` and `PerformanceManager.progress()` were called synchronously while constructing the Settings UI.
- Impact: opening Performance & Resources could perform QBank reads on the main thread.
- Fix: immutable performance-page data is prepared under `Dispatchers.IO`; the main thread only renders the result.
- Validation: source inspection confirms the two QBank snapshot reads are inside the IO block.

### F4 — P1 — Notification-permission prompt path performed SQLite work from a UI callback
- Location: `StreakManager.kt:maybeRequestStudyNotificationPermission()`.
- Root cause: checking/marking the durable prompt state touched `qbank.db` synchronously from Settings/Quiz interaction paths.
- Impact: unnecessary UI-thread database work during a permission interaction.
- Fix: durable prompt check/write moved to `PerformanceManager`'s background lane; only the final Android permission request is posted to main.

## Existing architecture confirmed during audit
- Main QBank, Notes, Knowledge Vault, Search and section dashboard DB operations are already predominantly worker/maintenance based.
- `RovexSafeWebViewClient` containment remains in place.
- `MIXED_CONTENT_ALWAYS_ALLOW`: 0 occurrences.
- Duplicate IDs within individual XML files: 0.
- XML parse errors: 0.
- `runBlocking`, `GlobalScope`, `AsyncTask`: 0 occurrences.
- Remaining `performClick()` is the existing accessibility forwarding in `FlashcardStudyActivity`.
- Application uses an explicit `specialUse` foreground-service type with the corresponding permission. Android documentation requires explicit FGS type/permission for Android 14+ and recommends purpose-built alternatives where applicable. citeturn0search0turn0search1

## Important remaining risks / backlog
1. Android build/lint/unit/instrumentation validation remains blocked by unavailable Gradle distribution DNS in this environment.
2. `FlashcardStudyActivity` still uses synchronous lifecycle `SharedPreferences.commit()` for the tiny local cursor at `onPause`/`onStop`/`onSaveInstanceState`; this is deliberately retained for durability and is bounded, but should be profiled on-device.
3. The app retains `android:largeHeap="true"`. This may be intentional for the optional neural/PDF workload, but should be justified by device memory profiling rather than treated as a performance optimization. Android exposes it as an explicit large-heap request. citeturn0search3
4. `HtmlImportActivity` and `FlashcardStudyActivity` use JavaScript bridges for trusted, locally selected/imported content. Their exposed methods remain a security-sensitive surface and should continue to be constrained to non-sensitive operations. Android's security guidance recommends minimizing WebView capabilities and treating JavaScript interfaces carefully. citeturn0search15
5. The project ZIP contains no `.github` workflow directory, so CI workflow validation/signing assertions cannot be executed from this supplied source alone.

## Web research applied
Android's current ANR guidance explicitly identifies main-thread I/O and lock contention as common causes of ANRs and recommends moving long-running I/O to worker threads/repositories. The repairs above target those exact boundaries. citeturn0search9turn0search17

Android 14+ requires foreground-service types and matching permissions; Android 15 adds timeout constraints for `dataSync` foreground services. Rovex's current manifest declares the relevant types, but device/CI validation is still required for the actual service start/stop behavior. citeturn0search1turn0search5turn0search12
