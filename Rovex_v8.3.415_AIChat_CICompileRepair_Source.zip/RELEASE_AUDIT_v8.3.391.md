# Rovex v8.3.391 release/source audit

Baseline: v8.3.390 / versionCode 482
Candidate: v8.3.391 / versionCode 483

## Defect 1 — Explanation shows literal HTML tags
Root cause: `rovexMarkdownBody()` escaped the complete prose buffer after Markdown conversion, so imported `<p>`, `<strong>`, `<sup>`, etc. became visible source text.
Fix: protect a bounded presentation-safe HTML vocabulary before escaping prose, then restore the tags for Android `Html.fromHtml()`.
Regression test: `FlashcardImportRecoveryRegressionTest.importedHtmlMarkupRemainsMarkupInsteadOfVisibleSource`.

## Defect 2 — No multi-deck deletion
Root cause: Flashcard UI only exposed single-deck/category actions.
Fix: added bulk-selection mode, concrete deck-ID selection, one confirmation, and one transactional `deleteDecks()` operation. Subdecks are not implicitly deleted in bulk; they can be selected explicitly.
Postcondition: the deletion transaction verifies zero selected deck rows remain.

## Defect 3 — Old imported decks not deleting
Root cause: legacy Anki hierarchy delimiters and stale/partially migrated deck rows could bypass the displayed-tree matching path.
Fix: existing normalized hierarchy matching retained; deletion now scans/normalizes stored names and uses one transactional delete path with a postcondition. Source deletion also trims source identity before matching.

## Defect 4 — APKG import stalls/fails intermittently
Root causes found in source:
1. Fresh imports were incorrectly classified as resumes because the importer wrote `VALIDATED` with `totalCards` and then tested `saved.totalCards > 0`. Consequently a fresh import did not clear an existing source/deck.
2. Per-card `Exception` handling also surrounded the SQLite insert, so database/constraint/storage failures could be silently counted as skipped cards instead of aborting the import.
3. Progress was emitted only at batch boundaries, making a large adaptive batch look stalled.

Fix:
- resume detection is now based on the persisted checkpoint phase before validation (`STAGED`/`VALIDATED` = fresh; `IMPORTING`/`CHECKPOINT`/`RESUMING`/`FINALIZING` = resumable);
- content/template/media preparation remains recoverable per card, but SQLite insertion failures propagate and fail the worker;
- a lightweight 25-card progress heartbeat is emitted without committing the transaction;
- existing durable staging, checkpointing, lazy media extraction, bounded transactions, WorkManager lifecycle, and FGS `dataSync` execution remain in place.

Anki/AnkiDroid research basis: current AnkiDroid exposes `Collection.importAnkiPackage()` as a worker/backend import operation; current Anki routes the package import to its backend `import_anki_package` operation rather than implementing the import in the UI. Rovex cannot simply transplant Anki's Rust backend, so v8.3.391 adopts the applicable architectural properties: background-owned import, validated package staging, durable recovery state, transactional database writes, and explicit import results.

## Defect 5 — Deleted QBank still appears
Root cause: `QBankLoadingEngine.loadSources()` could repopulate the source cache from a read that started before `invalidate()`, because the cache epoch was not checked on that path. A stale callback could therefore repaint a deleted QBank.
Fix: source, dashboard, and section metadata reads now capture a cache epoch and discard stale results after invalidation. QBank deletion is also idempotent and verifies that no tests/questions remain attached to the source ID before committing success.

## Static verification
- XML parse errors: 0
- duplicate IDs within individual XML layouts: 0
- FGS manifest dataSync declaration: present
- FGS runtime dataSync type: present
- fresh-import phase guard: present
- bulk flashcard deletion API: present
- QBank cache epoch guards: present
- rich HTML preservation: present
- source ZIP integrity: PASS

## Build/test verification
Command:
`./gradlew :app:testDebugUnitTest --no-daemon --stacktrace`

Result: BLOCKED by environment DNS. Gradle 9.3.1 could not be downloaded because `downloads.gradle.org` could not be resolved. No Android compilation or unit-test pass is claimed.

## Runtime verification
Not yet verified on the OnePlus CPH2691 / Android 16 device. Runtime import, deletion, sound, and rich explanation behavior must be tested after CI produces an APK.
