# Rovex v8.3.376 Release Audit — EmbeddingGemma Semantic Cache / Isolation Hardening

Target: **v8.3.376 / versionCode 469**
Baseline: **v8.3.375 / versionCode 468**, supplied source ZIP `Rovex_v8.3.375_Search_Chat_Sound_Resume_RootFix4_Source.zip`.

## Implemented

- Added `BenSemanticEmbeddingCache` as a bounded persistent vector cache owned by the isolated `:inference_process`.
- Cache keys include model SHA, tokenizer SHA, and canonical document text. Stale model/document vectors therefore cannot be silently reused.
- Added isolated `CMD_EMBED_BATCH` IPC for bounded 1–8 document embedding batches.
- Added a dedicated `BenSemanticIndexWorker` rather than adding native AI work to the existing deterministic knowledge worker.
- Semantic indexing is constrained to charging + battery-not-low + device-idle conditions, protecting foreground study from bulk embedding work.
- Semantic indexing is resumable by question-id cursor and retries without advancing past a failed neural batch.
- Semantic cache capacity is bounded at 5,000 vectors (~15 MB at 768-float32 dimensions before SQLite overhead).
- Main grounded Ben retrieval still uses deterministic FTS/knowledge-index recall; EmbeddingGemma remains a reranker and cache accelerator rather than becoming an unbounded second source of truth.
- Query-time reranking now uses the same title-aware document prompt form used by the background cache: `title: ... | text: ...`.
- EmbeddingGemma model/tokenizer identity hashing is memoized by file path/size/mtime, avoiding repeated hashing of the ~170 MB model during one query.
- Frankenstein passive context no longer instantiates a direct native EmbeddingGemma runtime. It asks the authoritative isolated service whether the embedding runtime is already warm and only then requests IPC reranking. Passive context therefore cannot cold-start the model.
- Added user-visible semantic-index status/control alongside the existing Ben local knowledge index controls.
- Semantic background indexing is disabled when the user's Ben AI runtime policy is OFF or its failure circuit is open.

## Reverification checklist

- Latest baseline verified: v8.3.375 / versionCode 468.
- Version increment: 468 → 469.
- XML parsing: PASS (0 malformed XML files).
- Duplicate IDs: PASS (0 duplicate `@+id` declarations within individual XML layouts).
- Source-wide legacy `sourceQuestionId` audit: PASS; only the canonical `QBankDb` stable-key implementation retains the database column name.
- Zstandard Android AAR dependency: PASS — `com.github.luben:zstd-jni:1.5.7-16@aar`.
- Isolated inference service declaration: PASS — `android:process=":inference_process"`.
- Changed-source parser-style Kotlin check: PASS. Standalone `kotlinc` cannot resolve Android/Gradle dependencies in this environment, but no Kotlin parser-style errors were emitted.
- Whole-project changed-file review: 7 existing Kotlin files modified plus 2 new Kotlin files; no unrelated source rewrite detected.
- Gradle test/build: **NOT VERIFIED**. The environment cannot resolve `downloads.gradle.org`, so Gradle distribution acquisition fails before compilation.
- GitHub Actions CI: **NOT VERIFIED in this audit**. Do not label this release CI-green until the actual repository workflow completes successfully.
- OnePlus SM8650 runtime validation: **NOT VERIFIED for v8.3.376**. The previous v8.3.140 native EmbeddingGemma proof remains historical evidence only.

## Self-review questions answered before packaging

### 1. Was the requested change actually implemented?
Yes. The semantic path now has persistent isolated-process document-vector caching, bounded background preparation, title-aware document inputs, and unified IPC use from the passive Frankenstein context path.

### 2. Is there a better solution than the previous implementation?
Yes. The previous implementation repeatedly embedded the same bounded candidate documents during reranking and Frankenstein could instantiate a separate direct engine. v8.3.376 removes both inefficiencies while preserving deterministic recall and process isolation.

### 3. Is it completely corrected?
The specific source-level defects addressed here are corrected and statically rechecked. A release cannot honestly be called completely verified because Android compilation, CI, and actual device stress/runtime validation remain outstanding.

### 4. Is anything still missing?
Yes, deliberately:
- full-corpus semantic candidate generation is not enabled yet;
- the cache is not a standalone vector-search ANN index;
- MRL 512/256/128 storage has not been forced because it needs actual SM8650 retrieval-quality/performance measurement first;
- EmbeddingGemma task-specific QA/fact-check/classification/clustering lanes are not yet wired into product behavior;
- Gemma 3 270M still needs broader structured-tool/context/decoder utilization work;
- v8.3.376 still requires GitHub CI and Phase-2 OnePlus SM8650 validation.

These are roadmap gaps, not silently ignored defects.

## Design rationale

The current implementation intentionally does **not** brute-force a 768-dimensional vector scan over the entire QBank. EmbeddingGemma officially supports 768 dimensions with Matryoshka truncation to 512/256/128 dimensions, and the document prompt supports an actual title. Those capabilities make a future compact vector index viable, but forcing a lower-dimensional representation before measuring retrieval quality on Rovex's real medical corpus would be premature.

The present design therefore captures the highest-confidence architectural improvement first: deterministic recall remains authoritative, native embedding remains isolated, repeated document inference is cached persistently, and bulk preparation is deferred to device-idle/charging conditions.

## Current validation limitation

**Never claim v8.3.376 is build-green until GitHub Actions or a successful Android Gradle build actually proves it.** The local environment fails during Gradle distribution resolution because `downloads.gradle.org` DNS is unavailable.
