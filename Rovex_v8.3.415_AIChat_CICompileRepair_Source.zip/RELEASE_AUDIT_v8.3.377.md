# Rovex v8.3.377 — Frankenstein / Ben Search Root Fix + Rich-AI Rendering Repair

Baseline: v8.3.376 / versionCode 469.
Target: v8.3.377 / versionCode 470.

## Root-cause findings

### 1. Frankenstein / Ben local search
The visible Frankenstein/Ben UI is `RenActivity`, and its active request route is:

`RenActivity.respond()` → `AppManagers.frankensteinSupport.respond()` → `AppManagers.renCognitive` → `RenCognitiveEngine.searchQuestionIds()` → `searchQuestionRefs()` → `QBankDb.search()`.

The old/hidden MainActivity UI is not the active controller for Frankenstein search. Modern Home opens `RenActivity` directly. `BenLocalResearchEngine` and `BenFrankensteinEngine` are internal adapter/orchestration classes; they are not separate visible search UIs.

The actual retrieval defect was in the authoritative `RenCognitiveEngine` ranking path:

- every primary lexical hit was previously inserted into `strictPrimary`;
- therefore, if even one weak primary hit existed, the final result set was filtered to those primary hits;
- clinically equivalent terminology expansions could be retrieved but then discarded;
- while FTS was rebuilding, semantic expansion was completely disabled, leaving only the primary lexical query;
- this combination could produce the user-visible "I could not find a matching local QBank result" even when the clinical terminology layer had a valid expansion.

### 2. AI search screenshot / raw Mermaid
The screenshot showed Mermaid source (`subgraph`, `classDef`, `fill`, `stroke`, etc.) rendered as ordinary text. The existing renderer correctly handled fenced Mermaid but did not recover when a provider stripped the Markdown fence while leaving the Mermaid payload.

## Repairs

- Primary lexical hits are no longer automatically treated as hard-filtered strict matches.
- Strict filtering is retained only for compact two-token topic searches whose requested tokens are both present in the actual question stem.
- Terminology expansion results remain eligible for ranking when the primary lane is sparse.
- During FTS repair, semantic expansion is restored but bounded to at most two expansion queries, preventing the previous unbounded full-corpus scan risk.
- FTS-ready searches retain the normal broader expansion lane.
- Added recovery for common unfenced Mermaid fragments before ordinary Markdown escaping.
- Existing fenced Mermaid, Markdown tables, HTML tables, code blocks, and deterministic rendering remain intact.
- Added JVM regression coverage for the exact unfenced Mermaid pattern represented by the supplied screenshot.

## Duplicate / hidden UI audit

The active Frankenstein/Ben search surface is the single `RenActivity` implementation. Modern Home launches it directly; it does not route through the hidden legacy `renCard` or another legacy Frankenstein view.

`BenLocalResearchEngine` and `BenFrankensteinEngine` are retained as non-UI architecture adapters. They ultimately delegate local retrieval to the same `RenCognitiveEngine` authority and do not create a second visible search screen.

No new parallel Frankenstein search manager was introduced.

## Verification

- XML files scanned: 36.
- XML parse errors: 0.
- Duplicate IDs within individual XML layouts: 0.
- Kotlin files scanned: 219.
- `runBlocking`: 0.
- `GlobalScope`: 0.
- `Thread.sleep`: 0.
- broad `catch(Throwable)`: 0.
- Changed-source Kotlin compiler parser check: no Kotlin syntax/parse errors; unresolved Android/project symbols are expected because the standalone compiler invocation has no Android/Gradle classpath.
- Isolated pure Markdown renderer compilation with temporary Android/JSON stubs: PASS.
- Exact unfenced-Mermaid regression execution: PASS.
- Zstandard dependency remains `com.github.luben:zstd-jni:1.5.7-16@aar`.
- Isolated `:inference_process` remains declared.
- Version increment: 469 → 470.
- Android Gradle compilation: **not claimable**; Gradle 9.3.1 download failed because `downloads.gradle.org` DNS is unavailable in this environment.
- GitHub CI/device validation: required before calling the release green.

## Verification questions answered before packaging

**Implemented?** Yes. The root retrieval and renderer defects are changed in the authoritative paths.

**Better solution available?** Yes, and this patch uses it: expansion is retained as a bounded second recall lane rather than either disabling expansion during FTS repair or performing unbounded full-corpus expansion scans. Search ownership remains centralized instead of adding another manager.

**Completely corrected?** The identified source-level defects are corrected and regression-tested where the environment permits. Full Android build and physical-device search validation remain outstanding, so a CI-green/device-proven claim would be false.

**Missing something?** No additional duplicate visible Frankenstein/Ben search UI was found. The remaining architectural adapters are non-UI and now route through the authoritative `AppManagers.renCognitive` instance when the application is initialized.
