# Rovex v8.3.387 Source Audit

Baseline: v8.3.386 / versionCode 478
Output: v8.3.387 / versionCode 479
Baseline source ZIP SHA-256: 18229db70252024a46c12a53e1bc9870f59f7dadfe6d2778f11513140840a22e

## Implemented
- HTML srcdoc entity decoding that preserves embedded markup.
- Generic question normalization now accepts array-shaped options and object-shaped options such as CoreBTR `{A: "...", B: "..."}`.
- Additional aliases: `ans`, `expl`, `img`/image aliases, `items`, `question_text`.
- Main/local search FTS and LIKE fallback now include correct answer, bot/video/audio metadata, option labels/text, plus existing stem/raw/explanation/source fields. Large image URI/data blobs are deliberately not copied into FTS to avoid index bloat.
- Existing 48 ms `rovex_button_click.mp3` is retained unchanged; default sound feedback is now enabled for users without an explicit preference. Existing Quiz answer selection and Flashcard study controls already call the centralized sound manager.
- MainActivity was deliberately not structurally rewritten in this release; no risky monolith refactor was introduced.

## Source-derived validation
- Radiology: 15 embedded srcdoc sections; after entity decoding, 315 question records are structurally present and 313 satisfy the current >=2-options MCQ invariant.
- CoreBTR: 27 folders, 229 lessons, 7158 question objects; all 7158 have >=2 object-shaped options under the new normalization path, and all have `img` + `expl` fields recognized by the new aliases.
- XML: 38 files parsed; 0 parse errors; 0 duplicate IDs within any individual layout.
- R.raw references: 0 missing resources.
- Tap sound SHA-256: 8d81cbfe9a05b30da6730f03c1976e59143cb425f8fa4d9e4129df6f65643b7a.
- Tap sound: 1536 bytes, 48 ms, 48 kHz.
- Exact HtmlImportParser source compile check with local API stubs: exit 0; only unused-stub warnings and one existing local variable-shadow warning.
- Entity decoder harness: `ENTITY_DECODER_TESTS: PASS`.
- FTS SQL smoke test: expanded rebuild SELECT succeeded; fallback has 12 placeholders/token; FTS retrieval of `MRI` from correct-answer content succeeded.
- Full Gradle test command could not start the build because the environment cannot resolve `downloads.gradle.org`.

## Verification boundary
Android Gradle compilation, instrumentation tests, signed APK generation, and CI-green status are NOT claimed.
