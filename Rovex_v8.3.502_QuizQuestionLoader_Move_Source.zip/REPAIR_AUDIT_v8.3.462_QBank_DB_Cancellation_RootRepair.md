# v8.3.462 — Repair Audit

## Evidence driving this batch
CI log `logs_98615006977.zip` executed v8.3.461:
- source SHA matched `eeec3edb01d722fedc5baebb773b165fd1de6768455526f993b0ecde531f475e`
- debug build PASS
- debug Android test APK PASS
- instrumented suite: 40 tests, 1 failure
- failure: `localSearchCancellationBoundaryStopsAliasFanout`
- assertion: `cancellation boundary was not consulted`
- stack: `QBankStartupPerformanceRegressionTest.kt:123`
- same run logged 8–13 waiters on `QBankDatabaseProvider.get()` and 232–444 ms monitor contention while `StreakManager` exercised the shared database.
- SQLite also logged inability to change WAL to TRUNCATE during test cleanup because the database was locked.

## Root repairs
1. Test boundary: explicitly provide `extraVariants=["startup-token"]` and assert the continuation callback is called before/between alias admissions.
2. DB provider contention: release the outer provider monitor before `SQLiteOpenHelper.getWritableDatabase()`. The helper remains the sole shared database owner; helper creation and filesystem reconciliation remain synchronized.
3. Add `Rovex:qbank-db-open` trace section for future attribution.

## Not claimed
- No runtime symptom is marked fixed from this source change.
- No SM8650/real-device validation has been performed by this batch.
- No Ben/Gemma IPC or neural runtime changes were made.
