# v8.3.469 — SentencePiece protobuf isolation repair

## Evidence
v8.3.468 CI failed at `:app:checkDebugDuplicateClasses` / `:app:mergeDebugJavaResource` because adding the required `protobuf-java:4.32.1` for sentencepiece4j introduced duplicate `com.google.protobuf` classes/resources against Firebase `protolite-well-known-types:18.0.1`.

## Root cause
The v8.3.467 isolated EmbeddingGemma diagnostic proved that the previous global exclusion of `protobuf-java` caused sentencepiece4j 1.0.2 to fail lazily with `NoClassDefFoundError: com/google/protobuf/GeneratedMessage$ExtendableMessage`. v8.3.468 restored the full runtime, but that full runtime cannot coexist with Firebase's Android protobuf-lite/protolite dependency graph.

## Repair
- Removed external `io.github.eix128:sentencepiece4j` dependency.
- Removed direct `com.google.protobuf:protobuf-java:4.32.1` dependency.
- Restored the existing global exclusion of `protobuf-java`.
- Vendored the small Apache-2.0 SentencePiece4J algorithm surface under `com.sentencepiece`.
- Replaced its generated full-protobuf `SentencepieceModel` dependency with a bounded local protobuf-wire decoder that reads only SentencePiece `ModelProto` fields Rovex actually uses: repeated `pieces`, each piece's `piece`, `score`, `type`, and `TrainerSpec.unk_id`; unknown protobuf fields are skipped safely.
- Replaced fastutil trie storage with JDK `HashMap` to avoid introducing another dependency solely for the vendored tokenizer.
- Added a JVM regression test covering wire parsing, unknown-field-tolerant structure, token lookup, segmentation, and decoding.

## Non-goals
- No Ben IPC transport changes.
- No LiteRT/LiteRT-LM changes.
- No Firebase dependency exclusions.
- No QBank/database changes.
- No neural inference behavior changes beyond restoring tokenizer parsing without the conflicting full protobuf runtime.

## Verification status
- STATIC: pending final source audit.
- JVM TEST: must execute on GitHub CI.
- BUILD: blocked until GitHub CI runs v8.3.469.
- DEVICE: blocked until a built v8.3.469 APK is installed.
- EmbeddingGemma isolated diagnostic: expected next gate is tokenizer_parse -> runtime inventory -> compiled_model_create -> tensor contract -> native_run -> output_read -> semantic smoke. No PASS may be claimed until actual device evidence reaches those stages.
