# Rovex v8.3.460 — Phase 1 QBank Visibility / Frankenstein Contention Root Repair

## Version
- versionName: 8.3.460
- versionCode: 551
- package: com.localqbank.library
- parent source: v8.3.459

## Scope
This batch continues Phase 1 QBank data/performance stability. It is deliberately limited to two source-proven contention paths:

1. QBank Library visibility still had a second queue boundary after the dedicated source query: MainQBankLibraryActivity handed the callback to PerformanceManager's serialized `qbank-worker` for ordering/persistence before rendering.
2. Frankenstein UI generation fencing hid stale results but did not cancel the backend Job, so a newer request could coexist with an older retrieval/neural request and consume additional CPU/SQLite/model resources.

A bounded cancellation hook was also added to shared deterministic local-search alias fan-out so cancellation can stop starting additional alias queries between SQLite calls.

## Root-cause evidence from v8.3.459 source
### QBank Library
- `QBankLoadingEngine` already had a dedicated `qbank-source-loader`.
- `MainQBankLibraryActivity.load()` nevertheless called `PerformanceManager.submit { ... applyOrder(raw) ... persistOrder(...) ... renderSources(...) }` after the source callback.
- `PerformanceManager` owns a single serialized `qbank-worker`.
- Therefore the source read could finish while the visible library remained behind an unrelated serialized worker backlog.

### Frankenstein
- `RenActivity` incremented `requestGeneration` and discarded stale callbacks, but did not retain/cancel the actual `FrankensteinSupportEngine` Job.
- `FrankensteinSupportEngine` already tracked `runningJobs`, proving that the backend operation was a cancellable coroutine Job, but `respond()` returned `Unit`.
- Consequently UI generation fencing prevented stale UI publication but did not stop an abandoned backend request.

### Search fan-out
- `LocalQBankSearchService` intentionally performs a primary search and, when recall is sparse, up to eight bounded alias searches.
- Before this repair there was no cancellation predicate between those alias searches.
- This did not create a full-corpus rebuild, but it allowed an already-obsolete request to continue launching additional retrieval work after cancellation.

## Repairs
### 1. Dedicated ordered QBank-library lane
Added `QBankLoadingEngine.loadLibrarySources()`.
- Runs source metadata and persisted library-order lookup on `qbank-source-loader`.
- Preserves cache-epoch stale-result fencing.
- Returns the already ordered catalog directly to the Activity.
- Adds `android.os.Trace` sections:
  - `Rovex.qbank-library-source-read`
  - `Rovex.qbank-library-order-read`
- Adds slow-operation diagnostic logging through `RovexPerformanceTrace`.

`MainQBankLibraryActivity.load()` now renders the ordered catalog directly from that lane and no longer depends on `PerformanceManager.submit()` for the critical visibility path.

### 2. Frankenstein latest-request cancellation
- `FrankensteinSupportEngine.respond()` now returns its actual coroutine `Job`.
- `RenActivity` stores that Job as `frankensteinJob`.
- Submitting a new Frankenstein request cancels the previous backend Job before starting the new request.
- Activity destruction also cancels the backend Job.
- Expected `CancellationException` is not shown as a user-facing failure.
- Cached responses are also returned through a cancellable coroutine Job rather than the old fire-and-forget executor callback.

This preserves the existing UI generation fence; it adds actual backend cancellation instead of replacing the fence.

### 3. Cancellation-aware deterministic search fan-out
- `LocalQBankSearchService.search()` now accepts an optional `shouldContinue` predicate.
- Alias retrieval checks this predicate before and between variants.
- Frankenstein passes its coroutine Job's live `CoroutineContext` activity state.
- Therefore cancellation stops starting additional alias SQLite queries after the currently executing SQLite operation returns.
- Primary retrieval remains authoritative and unchanged.
- FTS/LIKE semantics, limits, visual-only filtering, and ranking contracts are unchanged.

### 4. Performance evidence instrumentation
- Wrapped local question and hierarchy retrieval in `RovexPerformanceTrace` sections.
- Added a Macrobenchmark for `MainQBankLibraryActivity` measuring:
  - startup timing
  - frame timing
  - peak memory
  - source-read trace section
  - library-order trace section
- This converts the reported "Loading imported QBanks…" symptom into measurable source-read/order-read timing on a real device.

## Regression coverage added/updated
`QBankStartupPerformanceRegressionTest` now additionally covers the cancellation boundary and uses `loadLibrarySources()` for the catalog-lane regression.

The existing v8.3.459 bounded-deletion test remains unchanged in production semantics.

## Static verification executed
PASS:
- `verify_search_regression_repair.sh`
- `verify_search_qbank_regressions.sh`
- `verify_performance_search_architecture.sh`
- `verify_root_architecture.sh`
- `verify_defect_regressions.sh`
- `verify_phase1_qbank_contention.sh`
- `phase0_offline_gate.py`
- `audit_coroutine_cancellation.py`
- `audit_frankenstein_policy.py`
- `architecture_regression_audit.py`
- modified Kotlin brace/parenthesis/bracket balance

Diff scope against v8.3.459 was manually inspected. Production changes are limited to QBank loading, QBank-library rendering boundary, Frankenstein cancellation, deterministic local-search cancellation, benchmark instrumentation, and their regression tests/audits.

## Build / runtime boundary
NOT VERIFIED for v8.3.460.

The available execution environment has no system Gradle installation and the project's Gradle wrapper distribution is not locally cached. Earlier v8.3.458 CI proved the project can compile in CI, but that does not prove this source revision compiles or runs.

Therefore this release must not be called BUILD PASS, CI PASS, INSTRUMENTED PASS, DEVICE PASS, or FUNCTIONALLY FIXED until v8.3.460 is actually built and exercised.

## Required proof for this batch
1. CI must select the exact v8.3.460 source SHA.
2. Debug APK and Android test APK must build.
3. Full instrumented suite must pass, including the new cancellation and library-lane tests.
4. Macrobenchmark must run on a physical device or approved benchmark environment.
5. Real device must measure QBank Library cold/warm source-read/order-read durations and confirm the screen becomes usable without waiting for `qbank-worker` backlog.
6. Real device must exercise rapid Frankenstein A -> B -> C request switching and confirm obsolete backend jobs are cancelled rather than merely hidden.
7. Real device must exercise QBank loading + deletion/recovery + Frankenstein/Ben search together, with Perfetto/logcat evidence for CPU/SQLite contention.
8. Celebration must still be separately validated; this batch does not claim a new Celebration fix.

## Research basis
- Android SQLite performance guidance: minimize rows/columns, push aggregation into SQLite, use indexes, WAL, and short write transactions.
- Android Macrobenchmark guidance: measure startup/runtime with repeated iterations, traces, frame timing, and memory metrics; benchmark on physical devices.
- Android Baseline Profile guidance: measure TTID and TTFD rather than treating first-frame display as full usability.
- Android Performance Samples: Macrobenchmark, Baseline Profile, JankStats, WorkManager examples.
- Perfetto: Android's production tracing system for CPU scheduling, memory, jank, startup and root-cause analysis.
- No Gemma/EmbeddingGemma model/runtime changes were made. There is no source evidence in this batch that neural model implementation is the root cause of QBank catalog visibility or stale Frankenstein request contention.
