package com.localqbank.library

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.test.platform.app.InstrumentationRegistry
import com.localqbank.library.data.quiz.QuizCollectionDataSource
import com.localqbank.library.data.quiz.QuizNoteDataSource
import com.localqbank.library.data.quiz.QuizQuestionDataSource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Characterization tests for the current QuizViewModel before any further extraction.
 *
 * These tests intentionally describe the behavior of the existing ViewModel rather than
 * introducing a new abstraction. They are the regression fence for the first move-only
 * refactor step: no WebView/gesture/onCreate code should be moved until this contract runs
 * successfully on the target emulator/device.
 */
class QuizViewModelCharacterizationTest {
    private val context: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    private fun newViewModel(): QuizViewModel {
        val repository = QuizSessionRepository(
            context = context,
            questions = FakeQuestionDataSource(),
            notes = FakeNoteDataSource(),
            collections = FakeCollectionDataSource()
        )
        return QuizViewModel(
            appContext = context.applicationContext,
            data = repository,
            navigation = QuizNavigationUseCase(repository),
            session = QuizSessionUseCase(context),
            answerUseCase = QuizAnswerUseCase(StudyStateRepository(context)),
            savedState = SavedStateHandle()
        )
    }

    @Test
    fun configureAndResolvePreserveCurrentQuizStateContract() {
        val vm = newViewModel()
        vm.configureSession(
            title = "Characterization",
            requestedTestId = "test-1",
            collectionMode = false,
            examMode = true,
            examDurationMinutes = 30,
            practiceMode = false,
            sessionLabel = "Stage test",
            sectionLabel = "Medicine"
        )

        vm.applyResolution(
            QuizNavigationUseCase.SessionResolution(
                testId = "test-1",
                sourceId = 7L,
                questionCount = 100,
                position = 36,
                collectionIds = longArrayOf(),
                bankName = "Medicine"
            ),
            preferResolutionPosition = true
        )

        assertEquals("test-1", vm.state.testId)
        assertEquals(100, vm.state.questionCount)
        assertEquals(36, vm.state.position)
        assertEquals(36, vm.state.resumePosition)
        assertEquals("Stage test", vm.state.bankName)
        assertEquals("Medicine", vm.state.sectionLabel)
        assertTrue(vm.state.examMode)
        assertEquals(30, vm.state.examDurationMinutes)
    }

    @Test
    fun answerInExamModeRemainsAcceptedAndCorrectWithoutPersistenceGate() {
        val vm = newViewModel()
        val result = vm.answer(
            question = question(correctLabel = "B"),
            label = "B",
            practiceMode = false,
            examMode = true
        )

        assertTrue(result.accepted)
        assertTrue(result.correct)
        assertEquals("q-1", result.stableKey)
    }

    @Test
    fun answerInExamModeCanBeRecordedAndExamCountsRemainStable() {
        val vm = newViewModel()
        vm.recordExamAnswer("q-1", true)
        vm.recordExamAnswer("q-2", false)
        vm.recordExamAnswer("", true)

        assertEquals(2, vm.examAttemptedCount())
        assertEquals(1, vm.examCorrectCount())
        assertFalse(vm.state.examAnswers.containsKey(""))
    }

    @Test
    fun positionMutationRemainsClampedWithoutChangingResumePolicy() {
        val vm = newViewModel()
        vm.configureSession("Characterization", "test-1", false, false, 0, true, null, null)
        vm.applyResolution(
            QuizNavigationUseCase.SessionResolution("test-1", 7L, 100, 20, longArrayOf(), "Medicine"),
            preferResolutionPosition = true
        )

        vm.setPosition(36)

        assertEquals(36, vm.state.position)
        assertEquals(20, vm.state.resumePosition)
    }

    @Test
    fun positionAndExamRemainingAreClampedAsTheyAreToday() {
        val vm = newViewModel()
        vm.configureSession("Characterization", "test-1", false, true, 30, false, null, null)
        vm.applyResolution(
            QuizNavigationUseCase.SessionResolution("test-1", 7L, 10, 0, longArrayOf(), "Medicine")
        )

        vm.setPosition(999)
        vm.setExamRemainingMs(-1L)

        assertEquals(9, vm.state.position)
        assertEquals(0L, vm.state.examRemainingMs)
    }

    private fun question(correctLabel: String): Question = Question(
        id = 1L,
        stableKey = "q-1",
        position = 0,
        sourceId = "source-1",
        text = "Characterization question",
        rawText = null,
        correctAnswer = null,
        explanation = null,
        bot = null,
        video = null,
        audio = null,
        options = listOf(
            Option("A", "Wrong", false),
            Option(correctLabel, "Correct", true)
        ),
        questionImages = emptyList(),
        explanationImages = emptyList()
    )

    private class FakeQuestionDataSource : QuizQuestionDataSource {
        override fun existingQuestionIds(ids: LongArray) = ids
        override fun questionById(id: Long): Question? = if (id == 1L) questionStatic() else null
        override fun questionAt(testId: String, position: Int): Question? = questionStatic()
        override fun testIdForQuestion(id: Long): String? = if (id == 1L) "test-1" else null
        override fun sourceIdForTest(testId: String): Long = 7L
        override fun sourceNameForTest(testId: String): String? = "Medicine"
        override fun questionCount(testId: String): Int = if (testId == "test-1") 100 else 0
        override fun rawQuestionPosition(testId: String, questionId: Long): Int? = 0
        override fun questionByStableKey(stableKey: String): Question? = if (stableKey == "q-1") questionStatic() else null
        override fun close() = Unit

        companion object {
            private fun questionStatic() = Question(
                1L, "q-1", 0, "source-1", "Characterization question", null, null,
                null, null, null, null, listOf(Option("B", "Correct", true)), emptyList(), emptyList()
            )
        }
    }

    private class FakeNoteDataSource : QuizNoteDataSource {
        override fun note(questionId: Long): String? = null
        override fun saveNote(questionId: Long, note: String) = Unit
        override fun close() = Unit
    }

    private class FakeCollectionDataSource : QuizCollectionDataSource {
        override fun questionIds(filterType: String, filterValue: String): LongArray = longArrayOf(1L)
    }
}
