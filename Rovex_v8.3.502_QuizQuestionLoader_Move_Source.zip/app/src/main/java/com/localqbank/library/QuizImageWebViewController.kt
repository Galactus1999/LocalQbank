package com.localqbank.library

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.webkit.WebView
import android.webkit.WebSettings

/**
 * Owns the WebView presentation paths used when displaying question images.
 * This is a move-only extraction: image URL semantics and WebView configuration
 * intentionally remain equivalent to the previous implementation.
 */
class QuizImageWebViewController(
    private val context: Context,
    private val dp: (Int) -> Int,
    private val onFullscreenRequested: (String) -> Unit
) {
    fun replaceWithFallbackWebView(image: ImageView, host: ViewGroup, raw: String) {
        if (raw.isBlank()) return
        val index = host.indexOfChild(image)
        if (index < 0) return
        val relation = if (raw.startsWith("rovex-rel://image?")) resultOf {
            val q = raw.substringAfter('?')
            val params = q.split('&').mapNotNull { part ->
                val i = part.indexOf('=')
                if (i <= 0) null else part.substring(0, i) to java.net.URLDecoder.decode(part.substring(i + 1), Charsets.UTF_8.name())
            }.toMap()
            params["base"] to params["path"]
        }.getOrNull() else null
        val imageSrc = relation?.second ?: raw
        val baseUrl = relation?.first ?: raw
        val web = WebView(context).apply {
            settings.javaScriptEnabled = false
            settings.domStorageEnabled = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.setSupportZoom(true)
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webViewClient = object : RovexSafeWebViewClient() {}
            setBackgroundColor(Color.TRANSPARENT)
            var tapDownX = 0f
            var tapDownY = 0f
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { tapDownX = event.x; tapDownY = event.y; false }
                    MotionEvent.ACTION_UP -> {
                        val dx = event.x - tapDownX
                        val dy = event.y - tapDownY
                        if (kotlin.math.abs(dx) < dp(18) && kotlin.math.abs(dy) < dp(18)) onFullscreenRequested(raw)
                        false
                    }
                    else -> false
                }
            }
        }
        val html = "<html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head><body style=\"margin:0;background:transparent;text-align:center;\"><img src=\"${android.text.TextUtils.htmlEncode(imageSrc)}\" style=\"max-width:100%;height:auto;display:inline-block;\"></body></html>"
        host.removeViewAt(index)
        host.addView(web, index, LinearLayout.LayoutParams(-1, dp(220)))
        web.webViewClient = QuizFallbackImageFitWebViewClient()
        web.loadDataWithBaseURL(baseUrl, html, "text/html", "UTF-8", null)
    }

    fun showFullscreen(raw: String) {
        val dlg = Dialog(context).apply { window?.setBackgroundDrawableResource(android.R.color.black) }
        val web = WebView(context).apply {
            settings.javaScriptEnabled = false
            settings.domStorageEnabled = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.setSupportZoom(true)
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            webViewClient = QuizFullscreenImageWebViewClient { dlg.dismiss() }
            setBackgroundColor(Color.BLACK)
            setOnClickListener { dlg.dismiss() }
        }
        dlg.setContentView(web)
        dlg.show()
        dlg.window?.setLayout(-1, -1)
        val relation = QuizImageUriResolver.parseRelativeImage(raw)
        val imageSrc = relation?.second ?: raw
        val baseUrl = relation?.first ?: when {
            raw.startsWith("http://", true) || raw.startsWith("https://", true) -> raw.substringBeforeLast('/', raw)
            raw.startsWith("data:image", true) -> "https://rovex.local/"
            else -> raw.substringBeforeLast('/', raw)
        }
        val safe = android.text.TextUtils.htmlEncode(imageSrc)
        val page = "<html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=8,user-scalable=yes\"></head><body style=\"margin:0;background:#000;width:100%;height:100vh;display:flex;align-items:center;justify-content:center;overflow:auto;\"><img src=\"$safe\" style=\"max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain;\"></body></html>"
        web.loadDataWithBaseURL(baseUrl, page, "text/html", "UTF-8", null)
    }
}
