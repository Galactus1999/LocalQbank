package com.localqbank.library

import android.webkit.WebView

/**
 * Verbatim extraction of QuizActivity's first inline image WebView client.
 *
 * Move-only refactor: rendering behavior intentionally remains unchanged.
 */
class QuizImageFitWebViewClient : RovexSafeWebViewClient() {
    override fun onPageFinished(view: WebView?, url: String?) {
        view?.evaluateJavascript("""
                                (function(){
                                  var i=document.images[0];
                                  if(!i)return;
                                  function fit(){
                                    var nw=i.naturalWidth||0, nh=i.naturalHeight||0;
                                    if(!nw||!nh)return;
                                    var w=Math.max(1,window.innerWidth-8);
                                    var h=Math.max(40,Math.min(720,nh*(w/nw)));
                                    document.body.style.height=Math.ceil(h)+'px';
                                  }
                                  i.onload=fit; i.onerror=function(){document.body.style.height='40px';};
                                  fit(); setTimeout(fit,250); setTimeout(fit,1000);
                                })();
                            """.trimIndent(), null)

}
}
