package com.localqbank.library
import android.content.Intent
import com.localqbank.library.UiActionGuard.setGuardedClick
import com.localqbank.library.ai.context.ContextPackBuilder
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.net.Uri
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Spanned
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.app.AlertDialog
import android.app.Dialog
import android.view.MotionEvent
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.widget.*
import android.os.SystemClock
import android.text.InputType
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class QuizActivity : AppCompatActivity() {
    private val quizViewModel: QuizViewModel by viewModels { (application as LocalQBankApplication).appContainer.quizViewModelFactory() }
    private val quizRichTextRenderer by lazy { QuizRichTextRenderer(this) { questionId, note -> quizViewModel.appendNote(questionId, note) } }
    private val quizDialogController by lazy {
        QuizDialogController(
            context = this,
            quizViewModel = quizViewModel,
            dp = ::dp,
            rounded = ::rounded,
            showQuestion = ::show,
            openAiQuestionContext = { question -> BenQuestionAiContextDialog().show(this, question, quizViewModel.selectedAnswer(question.stableKey)) },
            postToMain = { action -> runOnUiThread(action) },
            isHostFinishing = { isFinishing || isDestroyed }
        )
    }
    private val quizMenuController by lazy {
        QuizMenuController(
            context = this,
            quizViewModel = quizViewModel,
            scroll = scroll,
            dp = ::dp,
            rounded = ::rounded,
            actionButton = ::actionButton,
            getFontScale = { fontScale },
            setFontScale = { fontScale = it },
            getFontFamily = { fontFamily },
            setFontFamily = { fontFamily = it },
            getHeaderMm = { headerMm },
            setHeaderMm = { headerMm = it },
            uiPreferences = uiPreferences,
            persistPosition = quizViewModel::persistPosition,
            showQuestion = ::show,
            applyHeaderHeight = ::applyHeaderHeight,
            showCelebrationPlanner = ::showCelebrationPlanner,
            recreateQuestion = { recreate() },
            captureAutoNote = { q, done -> quizViewModel.captureQuestionToKnowledge(q, "Question settings", done) }
        )
    }
    private val sessionLifecycle by lazy {
        QuizSessionLifecycleController(quizViewModel, this, ::recordCurrentTime)
    }
    private lateinit var content: LinearLayout
    private lateinit var counter: TextView
    private lateinit var result: TextView
    private lateinit var scroll: LockedScrollView
    private lateinit var bookmarkButton: TextView
    private lateinit var nextButton: TextView
    private var nextTransitionInProgress = false
    private val answerController by lazy { QuizAnswerInteractionController(this, quizViewModel, ::recordCurrentTime, contentProvider = { content }) { q, label, outcome -> handleAcceptedAnswer(q, label, outcome) } }
        private lateinit var settingsButton: TextView
    private lateinit var sectionChip: TextView
    private lateinit var jumpButton: TextView
    private var fontScale = 1f
    private var fontFamily = "sans-serif"
    private var headerMm = 10f
    private val uiPreferences by lazy { QuizUiPreferences(this) }
    private val quizTimers = QuizTimerController(
        onExamTick = { remaining -> quizViewModel.setExamRemainingMs(remaining); updateExamTimer() },
        onExamFinish = { quizViewModel.setExamRemainingMs(0L); updateExamTimer(); submitExam(true) },
        onGuidanceTick = { remaining -> guidanceRemainingMs = remaining; updateGuidanceTimer() },
        onGuidanceFinish = { guidanceRemainingMs = 0L; updateGuidanceTimer() }
    )
    private var guidanceRemainingMs = 0L
    private val guidanceSecondsPerQuestion = 60L
    private lateinit var bankNameView: TextView
    private var questionStartedAt = 0L
    private var timeRecordedForKey: String? = null
    /** Number of accepted answers in this quiz Activity lifetime; celebration policy decides which counts fire. */
    private var sessionAnsweredCount = 0
    private var celebrationIndex = 0
    private var celebrationView: RovexCelebrationView? = null
    private val imageExecutor by lazy { LifecycleExecutor(java.util.concurrent.Executors.newFixedThreadPool(PerformanceManager.recommendedImageConcurrency()) { r -> Thread(r, "quiz-image") }) }
    private val prefetchExecutor = LifecycleExecutor(java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "quiz-prefetch") })
    private val questionLoader by lazy {
        QuizQuestionLoader(
            quizViewModel = quizViewModel,
            executor = prefetchExecutor,
            cache = questionCache,
            postToMain = { action -> runOnUiThread(action) },
            isHostFinishing = { isFinishing || isDestroyed },
            showLoading = { message -> counter.text = message; result.visibility = View.GONE },
            showUnavailable = { counter.text = "Question unavailable" },
            onLoaded = { show() }
        )
    }
    private val spannedCache = object : java.util.LinkedHashMap<String, Spanned>(16, 0.75f, true) { override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Spanned>?) = size > 16 }
    private val questionCache = object : java.util.LinkedHashMap<String, Question>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Question>?): Boolean = size > 16
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        ResilienceManager.activityStarted(this, this)
        ResilienceManager.heartbeat(this)
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = !ThemeManager.isDark(this)
        // main thread during Activity startup; large QBanks can otherwise turn a normal launch
        // into an ANR. Rendering remains on the main thread after the bounded resolution completes.
        lifecycleScope.launch {
            try {
                val requestedTitle = extraText("title") ?: "QBank"
                val requestedTestId = extraText("testId") ?: ""
                val sessionIdsRaw = extraText("sessionIds")
                val requestedCollectionMode = intent.getBooleanExtra("collectionMode", false) || !sessionIdsRaw.isNullOrBlank()
                val exactQuestionId = extraLong("questionId")
                val requestedPosition = extraInt("position", -1)
                val requestedExamMode = intent.getBooleanExtra("examMode", false)
                val requestedExamDuration = extraInt("examDurationMinutes", 0).coerceIn(1, 240)
                val requestedSessionLabel = extraText("sessionLabel")
                val requestedPracticeMode = intent.getBooleanExtra("practiceMode", false)
                val requestedSectionLabel = extraText("sectionLabel")
                quizViewModel.configureSession(
                    title = requestedTitle, requestedTestId = requestedTestId, collectionMode = requestedCollectionMode,
                    examMode = requestedExamMode, examDurationMinutes = requestedExamDuration,
                    practiceMode = requestedPracticeMode, sessionLabel = requestedSessionLabel, sectionLabel = requestedSectionLabel
                )
                val resolution = withContext(Dispatchers.IO) {
                    quizViewModel.resolveSession(
                        title = quizViewModel.state.title, requestedTestId = quizViewModel.state.testId, requestedQuestionId = exactQuestionId,
                        requestedPosition = requestedPosition, sessionIdsRaw = sessionIdsRaw, collectionMode = quizViewModel.state.collectionMode,
                        filterType = extraText("collectionFilterType") ?: "status",
                        filterValue = extraText("collectionFilterValue") ?: "unsolved", sessionLabel = quizViewModel.state.sessionLabel
                    ).getOrElse { throw it }
                }
                quizViewModel.applyResolution(resolution, preferResolutionPosition = exactQuestionId > 0L)
                fontScale = uiPreferences.fontScale()
                fontFamily = uiPreferences.fontFamily()
                headerMm = uiPreferences.headerMm()
                val built = build()
                if (isFinishing || isDestroyed) return@launch
                setContentView(built)
                celebrationView = RovexCelebrationHost.install(findViewById(android.R.id.content))
                AliveMotion.installTree(built)
                AdaptiveTypographyManager.apply(built)
                AdaptiveLayoutManager.install(this@QuizActivity, built, topExtraDp = 0, bottomExtraDp = 0) { m ->
                    val density=resources.displayMetrics.density
                    val compactHeight=m.heightPx/density < 620f
                    if (built.childCount >= 5) {
                        val top=built.getChildAt(0); val info=built.getChildAt(1)
                        top.layoutParams=top.layoutParams.apply{height=dp(if(compactHeight) 52 else if(m.windowClass==AdaptiveLayoutManager.WindowClass.EXPANDED) 60 else 56)}
                        info.layoutParams=info.layoutParams.apply{height=dp(if(compactHeight) 36 else 38)}
                        top.requestLayout(); info.requestLayout()
                    }
                }
                // Full question content is deliberately loaded off the UI thread.
                show()
                TransitionCoordinator.install(this@QuizActivity)
                // Opening a QBank is not itself a study interaction. The durable Continue
                // cursor is updated only by explicit question navigation or an accepted answer,
                // so merely browsing a recent QBank cannot steal the last active study position.
                StudyEventSpine.publishAsync(StudyEventSpine.Event("quiz_opened", quizViewModel.state.currentQuestion?.stableKey, "quiz"))
                if (quizViewModel.state.examMode && quizViewModel.state.examDurationMinutes > 0) startExamTimer(quizViewModel.state.examDurationMinutes)
                else if (!quizViewModel.state.examMode) startGuidanceTimer()
            } catch (t: Exception) {
                if (!isFinishing && !isDestroyed) {
                    showFatalError("Unable to open this question. The QBank data is still safe.\n\n${t.javaClass.simpleName}: ${t.message ?: "unknown error"}")
                }
            }
        }
    }
    /** Read navigation extras defensively. Older builds may have stored IDs as numeric extras. */
    private fun extraText(key: String): String? = when (val v = intent.extras?.get(key)) {
        null -> null
        is String -> v
        is CharSequence -> v.toString()
        is Number -> v.toString()
        else -> v.toString()
    }
    private fun extraLong(key: String): Long = when (val v = intent.extras?.get(key)) {
        is Number -> v.toLong()
        is String -> v.toLongOrNull() ?: -1L
        else -> -1L
    }
    private fun extraInt(key: String, fallback: Int): Int = when (val v = intent.extras?.get(key)) {
        is Number -> v.toInt()
        is String -> v.toIntOrNull() ?: fallback
        else -> fallback
    }
    private fun showFatalError(message: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            background=ThemeManager.backgroundDrawable(this@QuizActivity)
        }
        val titleView = TextView(this).apply {
            text = "Could not open question"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@QuizActivity))
            gravity = Gravity.CENTER
        }
        val detail = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(ThemeManager.muted(this@QuizActivity))
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(20))
        }
        val back = Button(this).apply {
            text = "← Back"
            setOnClickListener { finish() }
        }
        root.addView(titleView, LinearLayout.LayoutParams(-1, -2))
        root.addView(detail, LinearLayout.LayoutParams(-1, -2))
        root.addView(back, LinearLayout.LayoutParams(-2, dp(52)))
        setContentView(root)
    }
    private fun startGuidanceTimer(){
        if(quizViewModel.state.examMode || quizViewModel.state.questionCount<=0) return
        guidanceRemainingMs=guidanceSecondsPerQuestion*1000L
        updateGuidanceTimer()
        quizTimers.startGuidance(guidanceRemainingMs)
    }
    private fun updateGuidanceTimer(){
        if(!::counter.isInitialized || quizViewModel.state.examMode) return
        val sec=(guidanceRemainingMs/1000).coerceAtLeast(0)
        val label=if(sec>0) String.format("%02d:%02d",sec/60,sec%60) else "Overtime"
        counter.text="Question ${quizViewModel.state.position+1} / ${quizViewModel.state.questionCount}  •  Guide $label"
    }
    private fun startExamTimer(minutes:Int){
        quizTimers.cancelExam()
        quizViewModel.setExamRemainingMs(minutes*60_000L)
        updateExamTimer()
        quizTimers.startExam(quizViewModel.state.examRemainingMs)
    }
    private fun updateExamTimer(){
        if (!::counter.isInitialized) return
        val sec=(quizViewModel.state.examRemainingMs/1000).coerceAtLeast(0)
        val text=String.format("%02d:%02d",sec/60,sec%60)
        counter.text="${quizViewModel.state.position+1}/${quizViewModel.state.questionCount}  •  $text"
    }
    private fun submitExam(auto:Boolean=false){
        quizTimers.cancelExam()
        val total=quizViewModel.state.examAnswers.size
        val correct=quizViewModel.state.examAnswers.values.count{it}
        val wrong=total-correct
        val unanswered=(quizViewModel.state.questionCount-total).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(if(auto) "Time is up" else "Exam submitted")
            .setMessage("Correct: $correct\nWrong: $wrong\nUnanswered: $unanswered\nAttempted: $total/${quizViewModel.state.questionCount}")
            .setPositiveButton("Done"){_,_->finish()}
            .setCancelable(false).show()
    }
        override fun onDestroy() {
        imageExecutor.close(); prefetchExecutor.close(); quizTimers.close()
        super.onDestroy()
    }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (quizSwipeNavigationController.onTouchEvent(ev)) return true
        return super.dispatchTouchEvent(ev)
    }
    override fun onPause() {
        sessionLifecycle.onPause()
        super.onPause()
    }
private val quizSwipeNavigationController by lazy {
        QuizSwipeNavigationController(
            density = resources.displayMetrics.density,
            position = { quizViewModel.state.position },
            questionCount = { quizViewModel.state.questionCount },
            examMode = { quizViewModel.state.examMode },
            onRecordCurrentTime = { recordCurrentTime() },
            onMoveToPosition = { position -> quizViewModel.moveToPosition(position) },
            onShow = { show() },
            onStartGuidanceTimer = { startGuidanceTimer() },
            onFinishStudySession = { finishStudySession() },
            onSubmitExam = { submitExam(false) }
        )
    }
    private fun enforceThemeTextVisibility(root: View){
    // Rendering invariant: imported HTML owns formatting only, never semantic text colour.
    // ThemeManager is the sole owner of question/option/AI foreground colours.
    fun roleColor(v: TextView): Int? = when(v.tag?.toString().orEmpty()) {
        "quiz:question" -> ThemeManager.questionText(this@QuizActivity)
        "quiz:explanation" -> ThemeManager.explanationText(this@QuizActivity)
        "quiz:ai" -> ThemeManager.aiText(this@QuizActivity)
        "quiz:option" -> ThemeManager.optionText(this@QuizActivity)
        "quiz:option-label" -> ThemeManager.optionText(this@QuizActivity)
        "quiz:option:correct", "quiz:option-label:correct" -> ThemeManager.correctText(this@QuizActivity)
        "quiz:option:wrong", "quiz:option-label:wrong" -> ThemeManager.wrongText(this@QuizActivity)
        "quiz:option:neutral", "quiz:option-label:neutral" -> ThemeManager.muted(this@QuizActivity)
        else -> null
    }
    fun walk(v: View){
        if(v is TextView){
            val spanned=v.text as? android.text.Spanned
            if(spanned!=null && spanned.isNotEmpty()){
                val clean=android.text.SpannableString(spanned)
                quizRichTextRenderer.sanitizeColorSpans(clean)
                v.text=clean
            }
            roleColor(v)?.let { v.setTextColor(it) }
            v.invalidate()
        }
        if(v is ViewGroup) for(i in 0 until v.childCount) walk(v.getChildAt(i))
    }
    walk(root)
}
override fun onResume() {
        super.onResume()
        window.decorView.post { enforceThemeTextVisibility(window.decorView) }
        sessionLifecycle.onResume()
    }
    override fun onStop() {
        sessionLifecycle.onStop()
        quizTimers.cancelGuidance()
        quizTimers.cancelExam()
        super.onStop()
    }
    private fun recordCurrentTime() {
        val key = quizViewModel.state.currentQuestion?.stableKey
        if (questionStartedAt <= 0L || key.isNullOrBlank() || timeRecordedForKey == key) return
        quizViewModel.recordElapsedTime(key, (SystemClock.elapsedRealtime() - questionStartedAt).coerceAtLeast(0L))
        timeRecordedForKey = key
    }
    private fun build(): LinearLayout {
        val built = QuizLayoutBuilder(
            context = this,
            quizViewModel = quizViewModel,
            fontScale = fontScale,
            fontFamily = fontFamily,
            dp = ::dp,
            rounded = ::rounded,
            headerButton = ::headerButton,
            onFinish = { finish() },
            onSubmitExam = { submitExam(false) },
            onShowSettings = ::showSettingsMenu,
            onShowQuestionJump = ::showQuestionJumpMenu,
            onMoveQuestion = ::moveQuestion,
            onShowBookmark = quizMenuController::showBookmarkMenu,
            onAdvanceQuestion = { if (!nextTransitionInProgress) advanceQuestion() }
        ).build()
        bankNameView = built.bankNameView
        sectionChip = built.sectionChip
        counter = built.counter
        settingsButton = built.settingsButton
        jumpButton = built.jumpButton
        scroll = built.scroll
        content = built.content
        result = built.result
        bookmarkButton = built.bookmarkButton
        nextButton = built.nextButton
        return built.root
    }
    private fun headerButton(label: String, size: Float, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(if (ThemeManager.isDark(this@QuizActivity)) Color.rgb(31,43,58) else Color.rgb(28,70,103), 12f)
        setOnClickListener { click() }
        isClickable = true
        isFocusable = true
    }
    private fun bookmarkPopupDrawable(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), if (ThemeManager.isDark(this@QuizActivity)) Color.rgb(75,88,105) else Color.rgb(205,215,225))
    }
    private fun readableForeground(background: Int): Int {
        val yiq = (Color.red(background) * 299 +
            Color.green(background) * 587 +
            Color.blue(background) * 114) / 1000
        return if (yiq >= 150) Color.rgb(20, 30, 40) else Color.WHITE
    }
    private fun actionButton(label: String, color: Int, size: Float = 13f, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(ThemeManager.text(this@QuizActivity))
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = bookmarkPopupDrawable(color)
        elevation = dp(3).toFloat()
        setPadding(dp(8), 0, dp(8), 0)
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }
    private fun optionCard(q: Question, option: Option, answered: Boolean) {
        val correct = option.correct ||
            q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
        val selected = answered && quizViewModel.selectedAnswer(q.stableKey)?.equals(option.label, true) == true
        val bg = when {
            !answered -> ThemeManager.optionBg(this@QuizActivity)
            correct -> ThemeManager.correctBg(this@QuizActivity)
            selected -> ThemeManager.wrongBg(this@QuizActivity)
            else -> ThemeManager.elevated(this@QuizActivity)
        }
        val fg = when {
            !answered -> ThemeManager.optionText(this@QuizActivity)
            correct -> ThemeManager.correctText(this@QuizActivity)
            selected -> ThemeManager.wrongText(this@QuizActivity)
            else -> ThemeManager.muted(this@QuizActivity)
        }
        val row = LinearLayout(this).apply {
            tag = "option:${option.label}"
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = if (answered) dp(62) else dp(70)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = rounded(bg, 20f)
            isClickable = !answered
            isFocusable = !answered
            if (!answered) setOnClickListener {
                // Audio is emitted only after the answer is durably accepted so a milestone can
                // replace the ordinary click cue instead of overlapping it with a second sound.
                answer(option.label)
            }
        }
        if (!answered) AliveMotion.install(row)
        val letter = TextView(this).apply {
            tag = "quiz:option-label"
            text = option.label
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(if (!answered) (if (ThemeManager.get(this@QuizActivity) == ThemeManager.AMOLED) ThemeManager.panel(this@QuizActivity) else if (ThemeManager.isDark(this@QuizActivity)) Color.rgb(43,60,79) else Color.rgb(207,224,240)) else bg, 50f)
        }
        row.addView(letter, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(0, 0, dp(14), 0) })
        val optionBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val text = TextView(this).apply {
            tag = "quiz:option"
            this.text = quizRichTextRenderer.optionSpanned(option.text, fg)
            textSize = 17.5f * fontScale
            setTypeface(Typeface.create(fontFamily, Typeface.NORMAL))
            setTextColor(fg)
            setLinkTextColor(ThemeManager.accent(this@QuizActivity))
            gravity = Gravity.CENTER_VERTICAL
            setLineSpacing(0f, 1.16f)
        }
        optionBody.addView(text, LinearLayout.LayoutParams(-1, -2))
        extractImageUris(option.text).forEach { addImage(it, optionBody) }
        row.addView(optionBody, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) })
    }
    private fun answer(label: String) {
        val q = quizViewModel.state.currentQuestion ?: return
        answerController.submit(q, label)
    }
    private fun handleAcceptedAnswer(q: Question, label: String, outcome: QuizAnswerUseCase.Result) {
        // The answer has already crossed the persistence boundary on Dispatchers.IO. From here
        // forward this callback is UI-only. A rendering/notification failure must never finish
        // QuizActivity and expose the Home screen as if the answer tap itself failed.
        try {
            if (!quizViewModel.state.examMode) {
                StudyEventSpine.publishAsync(StudyEventSpine.Event(
                    "quiz_completed", outcome.stableKey, "quiz", metadata = mapOf("correct" to outcome.correct.toString())
                ))
                resultOf { maybeRequestStudyNotificationPermission(this) }
            }
            if (quizViewModel.state.examMode) {
                quizViewModel.recordExamAnswer(q.stableKey, outcome.correct)
                quizViewModel.setPracticeAnsweredKey(q.stableKey)
            } else {
                quizViewModel.setPracticeAnsweredKey(if (quizViewModel.state.practiceMode) q.stableKey else null)
            }
            val current = quizViewModel.state.position
            val next = QuizResumePolicy.afterAnswer(current, quizViewModel.state.questionCount)
            // The answer is committed first; now move the durable resume target to the next
            // question. Do not perform a database lookup on this UI callback.
            quizViewModel.setResumeCursor(next, null)
            content.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
            // Exactly one audio cue is emitted per accepted answer. At a configured milestone,
            // the milestone cue replaces the ordinary click cue; they never overlap.
            val milestoneTriggered = triggerQuestionMilestone()
            val plan = RovexCelebrationPreferences.load(this)
            if (milestoneTriggered && plan.sound) {
                RovexSoundFeedback.playMilestone(this)
            } else {
                RovexSoundFeedback.playClick(this)
            }
            showAnsweredInPlace(q, label, outcome.correct)
        } catch (e: Exception) {
            ProductionCrashReporter.recordNonFatal(e, "QUIZ_ANSWER_UI", mapOf("question_key" to q.stableKey.take(120)))
            setOptionsEnabledAfterAnswerFailure()
            RovexUndoSnackbar.show(window.decorView, "Answer saved, but feedback could not be rendered. Continue studying.")
        }
    }

    /**
     * Stability-first milestone feedback. Answer persistence is already complete before this is
     * called. The user's Celebration Lab plan decides the exact question counts and visual style.
     * Any rendering/sound failure is isolated from the quiz state.
     */
    private fun triggerQuestionMilestone(): Boolean {
        sessionAnsweredCount += 1
        if (isFinishing || isDestroyed) return false
        val plan = RovexCelebrationPreferences.load(this)
        if (!RovexCelebrationPreferences.shouldCelebrate(sessionAnsweredCount, plan.targets)) return false
        val celebrationNumber = celebrationIndex++
        val variant = RovexCelebrationPreferences.variantFor(plan, celebrationNumber)
        runCatching {
            val host = findViewById<ViewGroup>(android.R.id.content)
            val celebration = celebrationView
                ?: host.findViewWithTag<RovexCelebrationView>("rovex_celebration_host")
                ?: RovexCelebrationHost.install(host).also { celebrationView = it }
            val target = if (::counter.isInitialized) counter else content
            celebration.post {
                if (!isFinishing && !isDestroyed) {
                    celebration.celebrateAt(target, variant)
                }
            }
        }.onFailure {
            ProductionCrashReporter.recordNonFatal(it, "QUIZ_MILESTONE_CELEBRATION")
        }
        return true
    }

    private fun setOptionsEnabledAfterAnswerFailure() {
        if (!::content.isInitialized) return
        for (i in 0 until content.childCount) {
            val row = content.getChildAt(i)
            if (row.tag?.toString()?.startsWith("option:") == true) {
                row.isClickable = false
                row.isFocusable = false
            }
        }
    }
    private fun showAnsweredInPlace(q: Question, label: String, correct: Boolean) {
        val dark = ThemeManager.isDark(this@QuizActivity)
        for (i in 0 until content.childCount) {
            val row = content.getChildAt(i) as? LinearLayout ?: continue
            val tag = row.tag?.toString() ?: continue
            if (!tag.startsWith("option:")) continue
            val optionLabel = tag.removePrefix("option:")
            val option = q.options.firstOrNull { it.label.equals(optionLabel, true) } ?: continue
            val isCorrect = option.correct || q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true || q.correctAnswer?.trim()?.equals(option.label.trim()+".", true) == true
            val isSelected = option.label.equals(label, true)
            val bg = when { isCorrect -> ThemeManager.correctBg(this@QuizActivity); isSelected -> ThemeManager.wrongBg(this@QuizActivity); else -> ThemeManager.elevated(this@QuizActivity) }
            val fg = when { isCorrect -> ThemeManager.correctText(this@QuizActivity); isSelected -> ThemeManager.wrongText(this@QuizActivity); else -> ThemeManager.muted(this@QuizActivity) }
            row.background = rounded(bg,20f); row.isClickable=false; row.isFocusable=false
            if (isSelected) {
                row.post {
                    if (correct) RovexPulseEffect.play(row) else RovexPulseEffect.shake(row)
                }
            }
            (row.getChildAt(0) as? TextView)?.apply { this.tag="quiz:option-label:" + if(isCorrect) "correct" else if(isSelected) "wrong" else "neutral"; setTextColor(fg); background=rounded(bg,50f) }
            (row.getChildAt(1) as? TextView)?.apply { this.tag="quiz:option:" + if(isCorrect) "correct" else if(isSelected) "wrong" else "neutral"; setTextColor(fg) }
        }
        if (::bookmarkButton.isInitialized) updateBookmarkButton(q, bookmarkButton)
        // Answer status is communicated directly on the option cards. Keep the bottom
        // action bar clean: no redundant "Correct / Answer" banner above Bookmark/Next.
        result.visibility = View.GONE
        scroll.isVerticalScrollBarEnabled = true
        // Keep answer feedback instant; explanation is added on the next UI turn so the
        // selected state gets a frame before potentially expensive HTML parsing/layout.
        content.post {
            if (isFinishing || isDestroyed || quizViewModel.state.currentQuestion?.stableKey != q.stableKey) return@post
            try {
                appendAnswerDetails(q, !correct)
            } catch (e: Exception) {
                // Explanation HTML/media is optional feedback. Never let it crash the quiz
                // Activity after the durable answer has already been committed.
                ProductionCrashReporter.recordNonFatal(e, "QUIZ_ANSWER_DETAILS", mapOf("question_key" to q.stableKey.take(120)))
            }
        }
    }
    private fun appendAnswerDetails(q: Question, wrong: Boolean) {
        // Avoid duplicate explanation if a rapid lifecycle callback already appended it.
        if (content.findViewWithTag<View>("explanation-panel:${q.stableKey}") != null) return
        if (wrong) {
            val why = TextView(this).apply {
                text = quizViewModel.mistakeType(q.stableKey)?.let { "Why I missed it: $it  •  Tap to change" } ?: "🧠 Why did I miss this?"
                textSize = 12.5f * fontScale; setTypeface(null, Typeface.BOLD); setTextColor(ThemeManager.accent(this@QuizActivity)); setPadding(dp(4),dp(10),dp(4),dp(4)); setOnClickListener{showMistakeTypeDialog(q)}
            }
            content.addView(why,LinearLayout.LayoutParams(-1,-2)); why.tag="explanation-why:${q.stableKey}"
        }
        val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(4));background=rounded(ThemeManager.explanationBg(this@QuizActivity),16f);tag="explanation-panel:${q.stableKey}"}
        panel.addView(TextView(this).apply{text="EXPLANATION";textSize=12.5f*fontScale;setTypeface(Typeface.create(fontFamily,Typeface.BOLD));setTextColor(ThemeManager.explanationTitle(this@QuizActivity));setLetterSpacing(.06f)},LinearLayout.LayoutParams(-1,dp(28)))
        content.addView(panel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(2))})
        addHtmlText(rovexMarkdownBody(q.explanation ?: "<p>No explanation available.</p>", true),17f*fontScale,false,ThemeManager.explanationText(this@QuizActivity),q.id,"explanation")
        q.explanationImages.forEach{addImage(it)}
        val flashcardCta = TextView(this).apply {
            text = "MAKE FLASHCARD  •  ANSWER ONLY"
            textSize = 11.5f * fontScale
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.accent(this@QuizActivity))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(this@QuizActivity))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), ThemeManager.accent(this@QuizActivity))
            }
            setPadding(dp(12), 0, dp(12), 0)
            contentDescription = "Make flashcard from this question"
            setOnClickListener {
                quizViewModel.createFlashcard(q.id, "Manual • ${if (wrong) "Wrong" else "Solved"}") { r ->
                    Toast.makeText(this@QuizActivity, if (r.created > 0) "Flashcard created • answer-only reveal" else "Flashcard already exists", Toast.LENGTH_SHORT).show()
                }
            }
        }
        content.addView(flashcardCta, LinearLayout.LayoutParams(-1, dp(46)).apply { setMargins(0, dp(12), 0, dp(18)) })
    }
    private fun show() {
        content.removeAllViews()
        if (quizViewModel.state.questionCount == 0) {
            counter.text = "No questions imported"
            addHtmlText("<h2>No questions</h2><p>Import a QBank HTML file first.</p>", 20f)
            result.visibility = View.GONE
            scroll.locked = true
            return
        }
        val key = if (quizViewModel.state.collectionMode) "id:${quizViewModel.state.collectionQuestionIds.getOrNull(quizViewModel.state.position) ?: -1L}" else "${quizViewModel.state.testId}:${quizViewModel.state.position}"
        val q = synchronized(questionCache) { questionCache[key] }
        if (q == null) {
            questionLoader.load(key)
            return
        }
        recordCurrentTime()
        quizViewModel.setCurrentQuestion(q)
        questionStartedAt = SystemClock.elapsedRealtime()
        timeRecordedForKey = null
        quizViewModel.persistPosition()
        val status = quizViewModel.progressStatus(q.stableKey)
        val answered = if (quizViewModel.state.examMode) quizViewModel.state.examAnswers.containsKey(q.stableKey) else status != null
        if(quizViewModel.state.examMode) updateExamTimer() else updateGuidanceTimer()
        jumpButton.text = (quizViewModel.state.position + 1).toString()
        // The question area must remain scrollable even before answering, especially for image-based questions.
        // Explanations are only added after an answer, so there is nothing to reveal prematurely.
        scroll.locked = false
        scroll.isVerticalScrollBarEnabled = answered
        updateSectionChip(q, status)
        updateBookmarkButton(q, bookmarkButton)
        updateNextButton()
        addHtmlText(q.text, 20f * fontScale, true, ThemeManager.questionText(this@QuizActivity), role="question")
        q.questionImages.forEach { addImage(it) }
        val aiContext = RovexColorFlowTextView(this).apply {
            tag = "quiz:ai"
            text = "✦  BEN + AI • EXAM CONTEXT"
            textSize = 11.5f * fontScale
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.aiText(this@QuizActivity))
            background = rounded(ThemeManager.explanationBg(this@QuizActivity), 14f)
            contentDescription = "Get Ben and AI context for this question"
            setPadding(dp(10), dp(9), dp(10), dp(9))
            setOnClickListener { showAiQuestionContext(q) }
        }
        content.addView(aiContext, LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, dp(10), 0, dp(8)) })
        q.options.forEach { optionCard(q, it, answered) }
        if (answered && !quizViewModel.state.examMode) {
            // Do not show a redundant answer-status banner; the highlighted options
            // already communicate correct/wrong state.
            result.visibility = View.GONE
            if (status == "wrong") {
                val why = TextView(this).apply {
                    text = quizViewModel.mistakeType(q.stableKey)?.let { "Why I missed it: $it  •  Tap to change" } ?: "🧠 Why did I miss this?"
                    textSize = 12.5f * fontScale
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(ThemeManager.accent(this@QuizActivity))
                    setPadding(dp(4), dp(10), dp(4), dp(4))
                    setOnClickListener { showMistakeTypeDialog(q) }
                }
                content.addView(why, LinearLayout.LayoutParams(-1, -2))
            }
            val explanationPanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(4))
                background = rounded(ThemeManager.explanationBg(this@QuizActivity), 16f)
            }
            val explanationTitle = TextView(this).apply {
                text = "EXPLANATION"
                textSize = 12.5f * fontScale
                setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
                setTextColor(ThemeManager.explanationTitle(this@QuizActivity))
                setLetterSpacing(0.06f)
            }
            explanationPanel.addView(explanationTitle, LinearLayout.LayoutParams(-1, dp(28)))
            val answerAiContext = RovexColorFlowTextView(this).apply {
                tag = "quiz:ai"
                text = "✦  BEN + AI • ANSWER & DISTRACTOR CONTEXT"
                textSize = 10.8f * fontScale
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(ThemeManager.aiText(this@QuizActivity))
                background = ThemeManager.backgroundDrawable(this@QuizActivity)
                contentDescription = "Analyze this question, answer and distractors with Ben and AI"
                setPadding(dp(8), dp(7), dp(8), dp(7))
                setOnClickListener { showAiQuestionContext(q) }
            }
            explanationPanel.addView(answerAiContext, LinearLayout.LayoutParams(-1, dp(38)).apply {
                setMargins(0, dp(4), 0, dp(6))
            })
            content.addView(explanationPanel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(2)) })
            addHtmlText(rovexMarkdownBody(q.explanation ?: "<p>No explanation available.</p>", true), 17f * fontScale, false, ThemeManager.explanationText(this@QuizActivity), q.id, "explanation")
            q.explanationImages.forEach { addImage(it) }
        } else {
            result.visibility = View.GONE
        }
        AdaptiveTypographyManager.apply(content)
        // Imported HTML can carry theme-hostile color/background spans. The parser strips them,
        // and this pass repairs any dynamically created TextViews after the question is attached.
        enforceThemeTextVisibility(content)
        AliveMotion.installTree(content)
        scroll.post { scroll.scrollTo(0, 0) }
        prefetchNextQuestion()
    }
    private fun prefetchNextQuestion() {
        // Adaptive controller may safely choose a rolling window of 1..3 questions.
        val depth = if (AppManagers.isReady()) PerformanceManager.effectivePrefetchDepth() else 2
        val targets = (1..depth).map { quizViewModel.state.position + it }.filter { it < quizViewModel.state.questionCount }
        if (targets.isEmpty()) return
        prefetchExecutor.execute {
            targets.forEach { target ->
                resultOf {
                    val key = if (quizViewModel.state.collectionMode) "id:${quizViewModel.state.collectionQuestionIds.getOrNull(target) ?: return@forEach}" else "${quizViewModel.state.testId}:$target"
                    synchronized(questionCache) { if (questionCache.containsKey(key)) return@resultOf }
                    val q = if (quizViewModel.state.collectionMode) quizViewModel.state.collectionQuestionIds.getOrNull(target)?.let { quizViewModel.questionById(it) } else quizViewModel.questionAt(quizViewModel.state.testId,target)
                    if (q != null) synchronized(questionCache) { questionCache[key] = q }
                }
            }
        }
    }
    private fun updateSectionChip(q: Question, status: String?) {
        val bookmark = quizViewModel.bookmark(q.stableKey)
        val raw = quizViewModel.state.sectionLabel?.trim()?.takeIf { it.isNotBlank() && !it.equals("practice", true) }
            ?: bookmark?.let { bookmarkLabel(it) }
            ?: when {
                status == "wrong" -> "Wrong"
                status == "correct" -> "Solved"
                else -> "Unsolved"
            }
        sectionChip.text = raw.uppercase()
        val bg = when (raw.lowercase()) {
            "important" -> ThemeManager.bookmarkFill(this, "important")
            "revise" -> ThemeManager.bookmarkFill(this, "revise")
            "doubt" -> ThemeManager.bookmarkFill(this, "doubt")
            "favourite", "favorite" -> ThemeManager.bookmarkFill(this, "favorite")
            "wrong" -> ThemeManager.wrongBg(this)
            "solved" -> ThemeManager.correctBg(this)
            else -> ThemeManager.explanationBg(this)
        }
        sectionChip.setTextColor(when (raw.lowercase()) {
            "wrong" -> ThemeManager.wrongText(this)
            "solved" -> ThemeManager.correctText(this)
            "important", "revise", "doubt", "favourite", "favorite" -> ThemeManager.bookmarkText(this, raw)
            else -> ThemeManager.accent(this)
        })
        sectionChip.background = rounded(bg, 10f)
    }
    private fun applyHeaderHeight() {
        val root = window.decorView.findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0) as? ViewGroup
        val header = root?.getChildAt(0)
        if (header != null) {
            header.minimumHeight = headerHeightPx()
            val lp = header.layoutParams
            lp.height = headerHeightPx()
            header.layoutParams = lp
            header.requestLayout()
        }
    }
    private fun headerHeightPx(): Int {
        val dpi = resources.displayMetrics.densityDpi.toFloat()
        val px = dpi * (headerMm / 25.4f)
        return px.toInt().coerceIn(dp(44), dp(60))
    }
    private fun showQuestionJumpMenu(anchor: View) {
        quizMenuController.showQuestionJumpMenu(anchor)
    }
    private fun showSettingsMenu(anchor: View) {
        quizMenuController.showSettingsMenu(anchor)
    }
    private fun showCelebrationPlanner() {
        RovexCelebrationPlannerDialog.show(this, if (::counter.isInitialized) counter else content)
    }

    private fun updateNextButton() {
        if (!::nextButton.isInitialized) return
        nextButton.text = if (quizViewModel.state.position >= quizViewModel.state.questionCount - 1) {
            if (quizViewModel.state.examMode) "Submit  →" else "Finish  →"
        } else {
            "Next  →"
        }
        nextButton.contentDescription = if (quizViewModel.state.position >= quizViewModel.state.questionCount - 1) "Finish question session" else "Next question"
    }
    private fun moveQuestion(delta: Int) {
        if (quizViewModel.state.questionCount <= 0 || delta == 0) return
        val target = quizViewModel.targetPosition(quizViewModel.state.position, delta)
        if (target == quizViewModel.state.position) {
            Toast.makeText(this, if (delta < 0) "Already at the first question" else "Already at the last question", Toast.LENGTH_SHORT).show()
            return
        }
        recordCurrentTime()
        quizViewModel.moveToPosition(target)
        show()
        startGuidanceTimer()
    }
    private fun advanceQuestion() {
        if (quizViewModel.state.questionCount <= 0 || isFinishing || isDestroyed) return
        val current=quizViewModel.state.position
        val target=quizViewModel.targetPosition(current,1)
        nextTransitionInProgress=true
        nextButton.isEnabled=false
        nextButton.alpha=0.72f
        recordCurrentTime()
        if (target != current) {
            quizViewModel.moveToPosition(target)
            // The question loader may be asynchronous. Always hand control back to the UI
            // queue so the button cannot race show()/prefetch state on the same frame.
            content.post {
                if (!isFinishing && !isDestroyed) {
                    show()
                    startGuidanceTimer()
                }
                nextTransitionInProgress=false
                if (::nextButton.isInitialized) { nextButton.isEnabled=true; nextButton.alpha=1f }
            }
        } else if (quizViewModel.state.examMode) {
            nextTransitionInProgress=false
            nextButton.isEnabled=true
            nextButton.alpha=1f
            submitExam(false)
        } else {
            nextTransitionInProgress=false
            nextButton.isEnabled=true
            nextButton.alpha=1f
            finishStudySession()
        }
    }
    private fun finishStudySession() {
        recordCurrentTime()
        quizViewModel.persistPosition()
        val attempted = quizViewModel.state.position + 1
        val total = quizViewModel.state.questionCount
        AlertDialog.Builder(this)
            .setTitle("Question bank complete")
            .setMessage("You reached the end of this study set.\n\nQuestions reached: $attempted/$total")
            .setNegativeButton("Stay") { _, _ -> }
            .setPositiveButton("Finish") { _, _ ->
                StudyEventSpine.publishAsync(StudyEventSpine.Event("quiz_finished", quizViewModel.state.currentQuestion?.stableKey, "quiz"))
                finish()
            }
            .show()
    }
    private fun updateBookmarkButton(q: Question, button: TextView) {
        val value = quizViewModel.bookmark(q.stableKey)
        if (value.isNullOrBlank()) {
            button.text = "🔖  Bookmark"
            button.setTextColor(ThemeManager.text(this@QuizActivity))
            button.background = rounded(ThemeManager.elevated(this@QuizActivity), 16f)
        } else {
            button.text = "🔖  ${bookmarkLabel(value)}"
            button.setTextColor(ThemeManager.bookmarkText(this, value))
            button.background = rounded(ThemeManager.bookmarkFill(this, value), 16f)
        }
    }
    private fun bookmarkLabel(value: String) = when (value) {
        "important" -> "Important"
        "revise" -> "Revise"
        "doubt" -> "Doubt"
        "favorite" -> "Favourite"
        else -> "Bookmark"
    }
    private fun addHtmlText(html: String?, size: Float, bold: Boolean = false, color: Int? = null, noteQuestionId: Long? = null, role: String = "generic") {
        quizRichTextRenderer.renderHtmlText(
            content = content,
            html = html,
            size = size,
            bold = bold,
            color = color,
            noteQuestionId = noteQuestionId,
            role = role,
            fontFamily = fontFamily,
            addImage = ::addImage
        )
    }
    private fun extractImageUris(html: String?): List<String> = QuizImageUriResolver.extractImageUris(html)
    private fun addImage(uri: String, host: ViewGroup = content) {
        QuizImageController(
            context = this,
            dp = ::dp,
            rounded = ::rounded,
            readableForeground = ::readableForeground,
            currentQuestion = { quizViewModel.state.currentQuestion },
            onFullscreenRequested = ::showImageFullscreen,
            onSaveImageRequested = ::showImageSaveMenu,
            onSaveImageWithNoteRequested = ::showImageNoteEditor
        ).addImage(uri, host)
    }
    private fun parseRelativeImage(raw: String): Pair<String, String>? = QuizImageUriResolver.parseRelativeImage(raw)
    private fun fallbackImageWebView(image: ImageView, host: ViewGroup, raw: String) {
        QuizImageWebViewController(this, ::dp, ::showImageFullscreen).replaceWithFallbackWebView(image, host, raw)
    }
    private fun showImageFullscreen(raw:String){
        QuizImageWebViewController(this, ::dp, ::showImageFullscreen).showFullscreen(raw)
    }
    private fun decodeScaledImage(value: String, maxW: Int, maxH: Int): android.graphics.Bitmap? =
        QuizImageDecoder.decodeScaledImage(value, maxW, maxH, contentResolver)

    private fun showImageSaveMenu(raw:String, q:Question) {
        QuizImageSaveController(
            context = this,
            dp = ::dp,
            readableForeground = ::readableForeground,
            rounded = ::rounded,
            saveKnowledgeImage = { image, questionId, done -> quizViewModel.saveKnowledgeImage(image, questionId, done) },
            saveKnowledgeImageWithNote = { image, questionId, note, done -> quizViewModel.saveKnowledgeImageWithNote(image, questionId, note, done) },
            onSuccess = { message -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show() },
            onFailure = { message -> RovexUndoSnackbar.show(window.decorView, message) }
        ).showSaveMenu(raw, q.id)
    }
    private fun showImageNoteEditor(raw:String,q:Question){
        QuizImageSaveController(
            context = this,
            dp = ::dp,
            readableForeground = ::readableForeground,
            rounded = ::rounded,
            saveKnowledgeImage = { image, questionId, done -> quizViewModel.saveKnowledgeImage(image, questionId, done) },
            saveKnowledgeImageWithNote = { image, questionId, note, done -> quizViewModel.saveKnowledgeImageWithNote(image, questionId, note, done) },
            onSuccess = { message -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show() },
            onFailure = { message -> RovexUndoSnackbar.show(window.decorView, message) }
        ).showNoteEditor(raw, q.id)
    }
    private fun showMistakeTypeDialog(q: Question) {
        quizDialogController.showMistakeTypeDialog(q)
    }
    private fun showNoteEditor(q:Question){
        quizDialogController.showNoteEditor(q)
    }
    fun saveAiResponseToNotes(questionId: Long, content: String) {
        quizDialogController.saveAiResponseToNotes(questionId, content)
    }
    private fun showAiQuestionContext(q: Question) {
        quizDialogController.showAiQuestionContext(q)
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius * resources.displayMetrics.density
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
