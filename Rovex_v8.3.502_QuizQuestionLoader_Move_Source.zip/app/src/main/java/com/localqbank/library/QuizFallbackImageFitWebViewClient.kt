package com.localqbank.library

class QuizFallbackImageFitWebViewClient : RovexSafeWebViewClient() {
    override fun onPageFinished(view: android.webkit.WebView?, url: String?) {
        view?.evaluateJavascript("(function(){var i=document.images[0];if(!i)return;var h=Math.max(40,Math.min(window.innerHeight*0.8,i.naturalHeight?i.naturalHeight:220));document.body.style.height=h+'px';})()", null)
    }
}
