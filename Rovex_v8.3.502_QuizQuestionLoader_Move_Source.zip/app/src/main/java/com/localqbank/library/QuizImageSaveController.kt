package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Owns the image-save and image+note dialogs used by the quiz image flow.
 * Move-only extraction: wording, validation, theme colors, callbacks, and
 * persistence sequencing remain equivalent to the previous implementation.
 */
class QuizImageSaveController(
    private val context: Context,
    private val dp: (Int) -> Int,
    private val readableForeground: (Int) -> Int,
    private val rounded: (Int, Float) -> android.graphics.drawable.GradientDrawable,
    private val saveKnowledgeImage: (String, Long, (Boolean) -> Unit) -> Unit,
    private val saveKnowledgeImageWithNote: (String, Long, String, (Boolean) -> Unit) -> Unit,
    private val onSuccess: (String) -> Unit,
    private val onFailure: (String) -> Unit
) {
    fun showSaveMenu(raw: String, questionId: Long) {
        val dialog = Dialog(context)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(ThemeManager.dialogBg(context))
                cornerRadius = dp(24).toFloat()
            }
        }
        root.addView(TextView(context).apply {
            text = "Save this image"
            textSize = 20f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(context))
        })
        root.addView(TextView(context).apply {
            text = "Keep the image alone, or attach your own memory note so it appears together in My Notes."
            textSize = 11.5f
            setTextColor(ThemeManager.muted(context))
            setPadding(0, dp(4), 0, dp(12))
        })
        fun action(title: String, sub: String, fill: Int, fg: Int, click: () -> Unit) = TextView(context).apply {
            text = android.text.SpannableStringBuilder().append(title).append("\n").append(sub)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(fg)
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(fill, 15f)
            setOnClickListener { click(); dialog.dismiss() }
        }
        root.addView(action(
            "SAVE IMAGE",
            "Save image only to Knowledge Vault",
            if (ThemeManager.isDark(context)) Color.rgb(126,190,235) else Color.rgb(220,240,252),
            if (ThemeManager.isDark(context)) Color.rgb(12,28,40) else Color.rgb(25,57,76)
        ) { saveKnowledgeImage(raw, questionId) { ok ->
            if (ok) onSuccess("Image saved to Knowledge Vault") else onFailure("Could not save this image.")
        } }, LinearLayout.LayoutParams(-1, dp(58)))
        val notesActionFill = if (ThemeManager.isDark(context)) Color.rgb(255,219,118) else Color.rgb(255,240,188)
        root.addView(action(
            "SAVE TO MY NOTES + IMAGE",
            "Write a memory cue and attach this image to My Notes",
            notesActionFill,
            readableForeground(notesActionFill)
        ) { showNoteEditor(raw, questionId) }, LinearLayout.LayoutParams(-1, dp(70)).apply {
            setMargins(0, dp(8), 0, 0)
        })
        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((context.resources.displayMetrics.widthPixels * .92f).toInt(), -2)
        AdaptiveTypographyManager.apply(root)
    }

    fun showNoteEditor(raw: String, questionId: Long) {
        val input = EditText(context).apply {
            hint = "Write your memory cue, trap, mnemonic…"
            textSize = 15f
            minLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setTextColor(ThemeManager.text(context))
            setHintTextColor(ThemeManager.muted(context))
            background = rounded(ThemeManager.elevated(context), 14f)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), 0)
            background = rounded(ThemeManager.dialogBg(context), 20f)
        }
        box.addView(TextView(context).apply {
            text = "Note attached below saved image"
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(context))
            setPadding(dp(4), dp(4), dp(4), dp(8))
        })
        box.addView(input, LinearLayout.LayoutParams(-1, dp(140)))
        val d = AlertDialog.Builder(context)
            .setTitle("Save to My Notes")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("SAVE TO NOTES", null)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val note = input.text.toString().trim()
                if (note.isBlank()) {
                    input.error = "Add a short memory cue, trap or mnemonic"
                    return@setOnClickListener
                }
                saveKnowledgeImageWithNote(raw, questionId, note) { ok ->
                    if (ok) onSuccess("Image + note saved to My Notes") else onFailure("Could not save image + note.")
                }
                d.dismiss()
            }
        }
        d.show()
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val saveButton = d.getButton(AlertDialog.BUTTON_POSITIVE)
        val saveButtonFill = if (ThemeManager.isDark(context)) Color.rgb(255,219,118) else Color.rgb(255,240,188)
        saveButton.setTextColor(readableForeground(saveButtonFill))
        saveButton.background = rounded(saveButtonFill, 12f)
        saveButton.setPadding(dp(14), 0, dp(14), 0)
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ThemeManager.text(context))
    }
}
