package com.localqbank.library

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView

class LockedScrollView(context: Context) : ScrollView(context) {
    var locked: Boolean = false
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onInterceptTouchEvent(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onTouchEvent(ev)
}

/**
 * Move-only extraction of the quiz shell construction.
 * The builder owns construction of the quiz shell only; session/business state remains in the host.
 */
class QuizLayoutBuilder(
    private val context: Context,
    private val quizViewModel: QuizViewModel,
    private val fontScale: Float,
    private val fontFamily: String,
    private val dp: (Int) -> Int,
    private val rounded: (Int, Float) -> GradientDrawable,
    private val headerButton: (String, Float, () -> Unit) -> TextView,
    private val onFinish: () -> Unit,
    private val onSubmitExam: () -> Unit,
    private val onShowSettings: (View) -> Unit,
    private val onShowQuestionJump: (View) -> Unit,
    private val onMoveQuestion: (Int) -> Unit,
    private val onShowBookmark: (View) -> Unit,
    private val onAdvanceQuestion: () -> Unit
) {
    data class Result(
        val root: LinearLayout,
        val counter: TextView,
        val result: TextView,
        val scroll: LockedScrollView,
        val content: LinearLayout,
        val bookmarkButton: TextView,
        val nextButton: TextView,
        val sectionChip: TextView,
        val settingsButton: TextView,
        val jumpButton: TextView,
        val bankNameView: TextView
    )

    fun build(): Result {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background=ThemeManager.backgroundDrawable(context)
            clipChildren = false
        }
        // Compact, camera-safe header: no full-width colored slab and no oversized controls.
        val top = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(5), dp(12), dp(6))
            background=ThemeManager.backgroundDrawable(context)
            elevation = dp(1).toFloat()
        }
        val back = headerButton("‹", 30f) { onFinish() }
        back.background = rounded(ThemeManager.elevated(context), 14f)
        back.setTextColor(ThemeManager.text(context))
        top.addView(back, LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(0, 0, dp(10), 0) })
        val titleBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(context).apply {
            text = quizViewModel.state.title
            textSize = 16.5f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.text(context))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        titleBox.addView(tv, LinearLayout.LayoutParams(-1, dp(24)))
        val subRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val bankNameView = TextView(context).apply {
            text = quizViewModel.state.bankName
            textSize = 10.5f
            setTextColor(ThemeManager.muted(context))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        subRow.addView(bankNameView, LinearLayout.LayoutParams(0, dp(20), 1f))
        val sectionChip = TextView(context).apply {
            textSize = 9.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.accent(context))
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(ThemeManager.explanationBg(context), 10f)
        }
        subRow.addView(sectionChip, LinearLayout.LayoutParams(-2, dp(20)).apply { setMargins(dp(6), 0, 0, 0) })
        titleBox.addView(subRow, LinearLayout.LayoutParams(-1, dp(20)))
        top.addView(titleBox, LinearLayout.LayoutParams(0, dp(50), 1f))
        // Settings intentionally does not live in the QBank title header. Keeping it beside
        // the question counter makes it independent of the device notification/cutout area.
        if (quizViewModel.state.examMode) {
            val submit = headerButton("✓", 18f) { onSubmitExam() }
            submit.background = rounded(ThemeManager.elevated(context), 14f)
            submit.setTextColor(ThemeManager.accent(context))
            submit.contentDescription="Submit exam"
            top.addView(submit, LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(dp(6), 0, 0, 0) })
        }
        root.addView(top, LinearLayout.LayoutParams(-1, dp(56)))
        // Lightweight progress rail. It is visually separate from the content and does not
        // consume the large vertical band used by the previous header/info combination.
        val infoRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(3), dp(18), dp(4))
            background=ThemeManager.backgroundDrawable(context)
        }
        val counter = TextView(context).apply {
            textSize = 12.5f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.muted(context))
            gravity = Gravity.CENTER_VERTICAL
        }
        infoRow.addView(counter, LinearLayout.LayoutParams(0, dp(30), 1f))
        val settingsButton = TextView(context).apply {
            text = "⚙"
            textSize = 16f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.accent(context))
            background = rounded(ThemeManager.elevated(context), 11f)
            contentDescription = "Question settings"
            setOnClickListener { onShowSettings(this) }
        }
        infoRow.addView(settingsButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(dp(6),0,dp(6),0) })
        val jumpButton = TextView(context).apply {
            textSize = 12.5f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.accent(context))
            gravity = Gravity.CENTER
            background = rounded(ThemeManager.explanationBg(context), 11f)
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { onShowQuestionJump(this) }
            contentDescription = "Jump to question"
        }
        infoRow.addView(jumpButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(dp(10), 0, 0, 0) })
        root.addView(infoRow, LinearLayout.LayoutParams(-1, dp(38)))
        val scroll = LockedScrollView(context).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setBackgroundColor(ThemeManager.panel(context))
        }
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(50))
            setBackgroundColor(ThemeManager.panel(context))
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val result = TextView(context).apply {
            setPadding(dp(18), dp(6), dp(18), dp(6))
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setBackgroundColor(ThemeManager.panel(context))
            visibility = View.GONE
        }
        root.addView(result, LinearLayout.LayoutParams(-1, dp(24)))
        // Floating-style study dock: compact, balanced controls with a single visual primary action.
        val actionWrap = FrameLayout(context).apply {
            setPadding(dp(12), dp(8), dp(12), dp(10))
            background=ThemeManager.backgroundDrawable(context)
        }
        val actionBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(context))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), if (ThemeManager.isDark(context)) Color.rgb(48,61,75) else Color.rgb(222,227,231))
            }
            elevation = dp(4).toFloat()
        }
        val previous = TextView(context).apply {
            text = "‹"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.muted(context))
            background = rounded(ThemeManager.panel(context), 17f)
            contentDescription = "Previous question"
            isClickable = true
            isFocusable = true
            setOnClickListener { onMoveQuestion(-1) }
        }
        actionBar.addView(previous, LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(0, 0, dp(5), 0) })
        val bookmarkButton = TextView(context).apply {
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(context))
            background = rounded(ThemeManager.panel(context), 17f)
            setPadding(dp(8), 0, dp(8), 0)
            contentDescription = "Bookmark question"
            setOnClickListener { onShowBookmark(this) }
        }
        actionBar.addView(bookmarkButton, LinearLayout.LayoutParams(0, dp(42), 1.05f).apply { setMargins(dp(2), 0, dp(5), 0) })
        val nextButton = TextView(context).apply {
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(if (ThemeManager.isDark(context)) Color.rgb(58, 139, 214) else Color.rgb(34, 111, 188))
                cornerRadius = dp(17).toFloat()
            }
            setPadding(dp(14), 0, dp(14), 0)
            contentDescription = "Next question"
            setOnClickListener { onAdvanceQuestion() }
        }
        actionBar.addView(nextButton, LinearLayout.LayoutParams(0, dp(42), 1.35f).apply { setMargins(dp(5), 0, 0, 0) })
        actionWrap.addView(actionBar, FrameLayout.LayoutParams(-1, dp(60)))
        root.addView(actionWrap, LinearLayout.LayoutParams(-1, dp(78)))
        return Result(root, counter, result, scroll, content, bookmarkButton, nextButton, sectionChip, settingsButton, jumpButton, bankNameView)
    }
}
