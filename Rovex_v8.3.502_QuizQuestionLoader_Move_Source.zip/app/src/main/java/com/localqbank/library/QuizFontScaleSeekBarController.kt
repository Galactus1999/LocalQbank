package com.localqbank.library

import android.content.Context
import android.content.res.ColorStateList
import android.view.View
import android.widget.SeekBar

/**
 * Move-only extraction of the question-settings font-scale SeekBar from QuizActivity.
 * Behavior, bounds, persistence callback, and refresh callback are supplied by the Activity.
 */
class QuizFontScaleSeekBarController(
    private val context: Context,
    private val initialFontScale: Float,
    private val onFontScaleChanged: (Float) -> Unit,
    private val onTrackingStopped: () -> Unit
) {
    fun create(): SeekBar = SeekBar(context).apply {
        max = 45
        progress = ((initialFontScale - .85f) / .01f).toInt().coerceIn(0, 45)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    onFontScaleChanged((.85f + p * .01f).coerceIn(.85f, 1.30f))
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) = onTrackingStopped()
        })
        progressTintList = ColorStateList.valueOf(ThemeManager.accent(context))
    }
}
