# v8.3.485 — Quiz first WebViewClient move-only extraction

## Scope

- Extracted the first inline WebViewClient in the current v8.3.484 QuizActivity source (the image-sizing client in `addImage`) into `QuizImageFitWebViewClient`.
- Preserved the `onPageFinished` JavaScript and timing behavior verbatim.
- Rewired the original call site to instantiate the named client.
- No business logic, lifecycle behavior, WebView settings, or rendering behavior intentionally changed.
- No second WebViewClient extraction was performed.

## Verification status

- Static/source audit: pending final batch audit.
- Full Gradle/CI/device verification: pending.
