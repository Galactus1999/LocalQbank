# v8.3.468 — Ben EmbeddingGemma Protobuf Linkage Repair

## Root cause
The v8.3.467 device diagnostic reached isolated EmbeddingGemma model preparation and failed with:
`NoClassDefFoundError: com/google/protobuf/GeneratedMessage$ExtendableMessage`.

`sentencepiece4j:1.0.2` declares `com.google.protobuf:protobuf-java:4.32.1` as a compile dependency. Rovex previously globally excluded `protobuf-java` to avoid a historical duplicate-class collision with `protobuf-javalite`. That exclusion left the tokenizer's required full protobuf runtime absent at runtime.

## Repair
- versionName 8.3.468 / versionCode 559
- stop globally excluding `protobuf-java`
- globally exclude `protobuf-javalite` so only one `com.google.protobuf` runtime is packaged
- explicitly include `com.google.protobuf:protobuf-java:4.32.1`, matching sentencepiece4j 1.0.2
- no Ben IPC transport changes
- no inference engine logic changes
- no database changes

## Verification
STATIC: dependency/source consistency reviewed.
STATIC: QBankDb construction count unchanged from 8.3.467 baseline (61 occurrences outside QBankDb.kt).
BUILD: BLOCKED locally because Gradle distribution/dependency resolution is unavailable in the offline environment.
DEVICE: BLOCKED pending CI/device build.

## Risk to watch
This changes the protobuf runtime used by Google/ML components. The historical duplicate-class problem is specifically avoided by packaging one runtime, but Firestore/ML Kit behavior must be verified on CI/device before release.
