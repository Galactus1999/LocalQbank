# Rovex v8.3.708 — Phase 0 build-contract test path fix

- Version: 8.3.708; versionCode: 794.
- Baseline: v8.3.707 / versionCode 793.
- Root cause: after the malformed Kotlin string was repaired, `releaseOptimizationStaysExplicitlyDisabledUntilRuntimeMatrixPasses` read `build.gradle.kts` through a helper that searches the project root before `app/`. The root build file does not own the Android `release` build type, so the assertion inspected the wrong file and failed.
- Repair: the test now requests `app/build.gradle.kts` explicitly, preserving the assertion that both R8 minification and resource shrinking remain disabled until the release validation matrix passes.
- The original escaped-newline syntax repair is retained.
- Verification is recorded in the companion audit; no Gradle/CI success is implied by this source edit.
