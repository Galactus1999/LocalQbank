# Rovex v8.3.702 — Phase 0 A3 WebView boundary + incomplete-code scan

## Baseline
- Source: v8.3.701 Phase 0 A2 source ZIP (includes A1 friend-code rules and A2 study-event/XP trust-boundary changes).
- Version: 8.3.702 / versionCode 788.

## Confirmed defects and repairs
1. `FlashcardStudyActivity.imageBridge.open()` used `canonicalPath.startsWith(mediaRoot.canonicalPath)` for local file authorization. A sibling path such as `flashcard_media_evil` can share the prefix. Replaced with `FlashcardImageUriPolicy`, which canonicalizes both paths and uses path-segment-aware `Path.startsWith`, requires a real file strictly below the media root, and rejects missing paths.
2. The image bridge now allow-lists HTTP(S) URLs with a host and no embedded user-info, bounded `data:image/` URLs, and existing app-private media files. Other schemes, including `javascript:` and `content:`, are rejected. Preview callback is lifecycle guarded.
3. The fullscreen image WebView now explicitly disables JavaScript, DOM storage, content access, file-origin cross-file/universal access, and mixed content. File access remains enabled only because verified app-private media is a supported flashcard feature.
4. `runCardDb()` previously returned immediately if `acquireWorkerDb()` returned null, skipping its `onDone` callback and potentially leaving a caller's UI state incomplete. It now always dispatches completion from `finally` and reports temporary DB unavailability to the user.
5. Added `FlashcardImageUriPolicyTest` coverage for HTTP(S) with/without credentials, unsupported schemes, oversized data images, valid descendants, sibling-prefix traversal, directories and missing files.

## Incomplete-code scan
- Scanned 329 production Kotlin files: 0 TODO/FIXME/NotImplemented markers.
- Scanned production Java/Kotlin/JS/KTS/shell paths: 0 TODO/FIXME/NotImplemented markers.
- Parsed all main-source XML and checked duplicate IDs only within each individual XML file: PASS.
- Rechecked A1/A2 source-contract presence and version increment: PASS.

## Verification status
- A2 static security-contract test: PASS (`node firestore-tests/static-security-contract.test.js`).
- Cloud Function and Firestore test JavaScript syntax: PASS (`node --check`).
- A3 source-contract assertions: PASS.
- Main XML parse and per-file duplicate-ID audit: PASS.
- ZIP integrity: PASS.
- JVM test execution, Android Gradle compilation, release/R8 compatibility, GitHub Actions, Firebase emulator/deploy, and device runtime: NOT RUN / NOT VERIFIED in this environment. Do not treat this source snapshot as a green build or deployed security fix.

## Research basis
Android Developers' WebView security guidance warns about JavaScript interfaces exposed to untrusted content and file access from WebViews. This patch narrows the bridge and hardens the preview surface; it does not claim the entire WebView estate is fully audited. Further review is still required for the primary card WebView's file-origin architecture and all other WebView call sites.

## Remaining Phase 0 work
- R8/minification/shrink audit, including JNI/reflection and native library compatibility, before enabling it.
- Review all WebViews, especially `HtmlImportActivity` and flashcard card HTML, for origin isolation and file access. This patch is a targeted repair, not a complete WebView security certification.
- Run Firestore emulator suite and full canonical CI; reconcile legacy online XP aggregates before treating leaderboard totals as trustworthy.
- Review LiteRT Qualcomm runtime download integrity/pinning and build-time execution in the next supply-chain subphase.
