# Rovex Universal Reader — v8.3.695

Date: 2026-10-18

## Goal

Make the HTML/offline-export ingestion path source-independent: identify a likely source from a bounded prefix and filename, retain the existing provider-specific fast paths, and expand generic question/option normalization so changing variable names and common field aliases do not force a new provider-specific importer.

## Changes in this increment

- Added `UniversalImportAdapterRegistry` for bounded source/format hints and provider labels (Marrow, DocTutorials, PrepLadder, DAMS, Cerebellum, DBMCI, eGurukul, generic imports).
- Wired bounded-prefix detection into the HTML import worker. The prefix is capped at 64 KiB; it does not buffer the entire export.
- Preserved the existing Marrow `srcdoc` route, native HTML/JSON parser, large-file streaming scanner, and WebView compatibility fallback.
- Expanded generic stem, options, answer, explanation, section-title, and nested-container aliases in both native and streaming parsing paths.
- Added regression fixtures for provider hints and cross-platform field aliases.
- Version bumped to 8.3.695 / versionCode 781.

## Safety invariants

- Source signatures are hints, not proof that extraction succeeded.
- A large import must pass the read-only question preflight before replacing a database source.
- Zero-question extraction is a failure; it must not commit an empty QBank.
- Large inputs continue to use the bounded streaming path; the detector reads only a bounded prefix.
- This reader processes user-provided exports the user is authorized to access. It does not bypass authentication, subscriptions, DRM, or protected video playback.

## Known limitations / next implementation gates

- This increment is an adaptive HTML/offline-export ingestion improvement, not a claim of universal support for every export schema.
- Source branding may be absent; in that case the provider label remains `Imported` and generic parsing is attempted.
- DOM-only HTML exports without recognizable structured payloads still depend on the compatibility extractor; robust streaming DOM extraction needs its own bounded parser and fixture corpus.
- Raw JSON, APKG, PDF, EPUB, and protected video are separate import routes. The detector identifies some formats for diagnostics but does not silently route those formats through the HTML parser.
- No real Marrow, DocTutorials, PrepLadder, or DAMS export corpus was supplied in this task, so compatibility with each actual current export is not verified.

## Verification status

- Source edits and regression tests added: yes.
- ZIP integrity and static consistency checks: pending at packaging time.
- Gradle/JUnit execution: blocked because this environment cannot resolve `downloads.gradle.org` for Gradle 9.3.1.
- Android compilation, full GitHub Actions workflow, device import, large-file memory profiling: not verified.
