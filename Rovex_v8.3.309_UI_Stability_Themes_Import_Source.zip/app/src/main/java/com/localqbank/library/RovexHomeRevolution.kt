package com.localqbank.library

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.abs

/** Home dashboard: adaptive, data-backed and deliberately light on runtime work. */
object RovexHomeRevolution {
    private const val TAG = "ROVEX_HOME_SHELL"
    private data class DynamicResult(val today:Int,val attempted:Int,val correct:Int,val wrong:Int,val week:Int,val daily:Int,val weekly:Int,val points:List<Pair<Long,Boolean>>)
    private fun d(v:Int,c:Context)=(v*c.resources.displayMetrics.density).toInt()

    private fun tv(c:Context,s:String,z:Float,col:Int=ThemeManager.text(c),bold:Boolean=true)=TextView(c).apply{
        text=s;textSize=z;setTextColor(col);if(bold)setTypeface(typeface,Typeface.BOLD);includeFontPadding=false
    }

    private fun card(c:Context,index:Int=0):GradientDrawable {
        val base=ThemeManager.pastelAccentFill(c,index)
        val end=when(index%4){0->ThemeManager.panel(c);1->ThemeManager.elevated(c);2->ThemeManager.panel(c);else->ThemeManager.elevated(c)}
        return GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(base,end)).apply{
            cornerRadius=d(22,c).toFloat()
            val ac=ThemeManager.accent(c)
            setStroke(d(1,c),Color.argb(if(ThemeManager.isDark(c))95 else 70,Color.red(ac),Color.green(ac),Color.blue(ac)))
        }
    }

    private fun feature(a:MainActivity,title:String,sub:String,icon:String,index:Int,target:()->Unit):View{
        val box=FrameLayout(a).apply{background=card(a,index);setPadding(d(14,a),d(13,a),d(10,a),d(10,a));isClickable=true;isFocusable=true;elevation=d(4,a).toFloat();setOnClickListener{target()}}
        val col=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL}
        val iconColor=ThemeManager.accent(a)
        col.addView(tv(a,icon,29f,iconColor,true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Color.argb(if(ThemeManager.isDark(a))55 else 95,Color.red(iconColor),Color.green(iconColor),Color.blue(iconColor)));setStroke(d(1,a),Color.argb(90,Color.red(iconColor),Color.green(iconColor),Color.blue(iconColor)))}},LinearLayout.LayoutParams(d(50,a),d(50,a)).apply{bottomMargin=d(8,a)})
        col.addView(tv(a,title,18f,ThemeManager.text(a),true))
        col.addView(tv(a,sub,11.5f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(4,a)})
        box.addView(col,FrameLayout.LayoutParams(-1,-1))
        box.addView(tv(a,"›",28f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER},FrameLayout.LayoutParams(d(30,a),d(30,a),Gravity.END or Gravity.BOTTOM))
        return box
    }

    private fun openSection(a:MainActivity,id:String,focusKind:String?=null){
        a.startActivity(Intent(a,RovexSectionDashboardActivity::class.java).apply{
            putExtra("section",id);focusKind?.let{putExtra("focusKind",it)}
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        })
    }

    private fun navigateNav(a:MainActivity,index:Int,flashcards:View?){
        when(index.coerceIn(0,3)){
            0->a.startActivity(Intent(a,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            1->openSection(a,"qbank")
            2->flashcards?.performClick() ?: a.startActivity(Intent(a,FlashcardActivity::class.java))
            3->a.startActivity(Intent(a,StudyToolsActivity::class.java))
        }
    }

    fun refreshTheme(a:MainActivity){
        val root=a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        root.findViewWithTag<FrameLayout>(TAG)?.let{it.background=ThemeManager.backgroundDrawable(a);it.invalidate()}
    }

    fun apply(a:MainActivity){
        val root=a.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        if(root.getTag(R.id.dashboardRoot)=="UI304")return
        root.setTag(R.id.dashboardRoot,"UI304")
        val legacy=FrameLayout(a)
        // Detach the existing XML children before re-parenting them. Calling
        // addView() while a child still belongs to dashboardRoot throws
        // IllegalStateException: "The specified child already has a parent"
        // during MainActivity startup.
        while(root.childCount>0){
            val child=root.getChildAt(0)
            root.removeViewAt(0)
            legacy.addView(child)
        }
        legacy.visibility=View.GONE

        val shell=FrameLayout(a).apply{tag=TAG;background=ThemeManager.backgroundDrawable(a)}
        val scroll=ScrollView(a).apply{overScrollMode=View.OVER_SCROLL_NEVER;clipToPadding=false;isFillViewport=true}
        val content=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(14,a),d(14,a),d(14,a),d(104,a))}
        scroll.addView(content);shell.addView(scroll,FrameLayout.LayoutParams(-1,-1))

        val top=LinearLayout(a).apply{gravity=Gravity.CENTER_VERTICAL}
        top.addView(RovexHeaderCosmicView(a),LinearLayout.LayoutParams(d(48,a),d(44,a)).apply{rightMargin=d(4,a)})
        top.addView(RovexWaveTextView(a).apply{text="Rovex";textSize=29f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(a));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,d(48,a),1f))
        top.addView(tv(a,"⚙",23f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;contentDescription="Settings";background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(ThemeManager.peacockFill(a));setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{a.startActivity(Intent(a,SettingsActivity::class.java))}},LinearLayout.LayoutParams(d(48,a),d(48,a)))
        content.addView(top,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(9,a)})

        val search=tv(a,"⌕   Search questions, topics, anything…   ✦",14f,ThemeManager.text(a),false).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(d(16,a),0,d(16,a),0);background=card(a,0);setOnClickListener{a.findViewById<View>(R.id.homeSearchCard)?.performClick()}}
        content.addView(search,LinearLayout.LayoutParams(-1,d(52,a)).apply{bottomMargin=d(13,a)})

        val greet=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL}
        greet.addView(tv(a,"Good Evening,",15f,ThemeManager.muted(a),false))
        greet.addView(tv(a,"Future Doctor 👋",29f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)})
        greet.addView(tv(a,"Small steps. Big Doctor.",13f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)})
        content.addView(greet,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(12,a)})

        val progress=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16,a),d(14,a),d(16,a),d(14,a));background=card(a,2);elevation=d(4,a).toFloat()}
        val progressTitle=tv(a,"Today's Progress",18f,ThemeManager.text(a),true)
        val progressValue=tv(a,"Loading calibrated progress…",29f,ThemeManager.text(a),true)
        val progressMeta=tv(a,"Using saved answers only",11.5f,ThemeManager.muted(a),false)
        val progressGraph=TodayProgressGraphView(a)
        val continueButton=tv(a,"▶  CONTINUE MOST RECENT QBANK",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{
            PerformanceManager.submit{
                val target=runCatching{val db=QBankDb(a.applicationContext);try{MainRepository(a.applicationContext).use{it.latestResumeTarget(db.sources())}}finally{db.close()}}.getOrNull()
                a.runOnUiThread{if(!a.isFinishing&&!a.isDestroyed){if(target!=null)a.startActivity(Intent(a,QuizActivity::class.java).putExtra("testId",target.testId).putExtra("title",target.title).putExtra("position",target.position).putExtra("practiceMode",true))else a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))}}
            }
        }}
        progress.addView(progressTitle);progress.addView(progressValue,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)});progress.addView(progressGraph,LinearLayout.LayoutParams(-1,d(132,a)).apply{topMargin=d(7,a)});progress.addView(progressMeta,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(2,a)});progress.addView(continueButton,LinearLayout.LayoutParams(-1,d(38,a)).apply{topMargin=d(8,a)})
        content.addView(progress,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        val grid=GridLayout(a).apply{columnCount=2}
        fun add(v:View,i:Int){val lp=GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED,1f),GridLayout.spec(GridLayout.UNDEFINED,1f));lp.width=0;lp.height=d(160,a);lp.setMargins(d(4,a),d(4,a),d(4,a),d(4,a));grid.addView(v,lp)}
        add(feature(a,"QBank","19 subjects • imported content","📚",0){openSection(a,"qbank")},0)
        add(feature(a,"Flashcards","Spaced repetition • review","🧠",1){a.startActivity(Intent(a,FlashcardActivity::class.java))},1)
        add(feature(a,"Performance Lab","Measured study telemetry","📊",2){a.findViewById<View>(R.id.performanceLabCard)?.performClick()},2)
        add(feature(a,"Frankenstein","Ben / AI study partner","🤖",3){a.findViewById<View>(R.id.renCard)?.performClick()},3)
        content.addView(grid,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(9,a)})

        val qbox=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,1)}
        qbox.addView(tv(a,"QBank Library",17f,ThemeManager.text(a),true))
        qbox.addView(tv(a,"Browse the main imported QBank list, then open any bank for its subject/test content.",11.5f,ThemeManager.muted(a),false),LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(3,a)})
        val qb=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun action(label:String,click:()->Unit)=tv(a,label,10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.peacockFill(a));cornerRadius=d(18,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{click()}}
        qb.addView(action("BROWSE QBANKS"){a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))},LinearLayout.LayoutParams(0,d(44,a),1f).apply{rightMargin=d(4,a)})
        qb.addView(action("IMPORT QBANK"){a.openQBankImporterFromHome()},LinearLayout.LayoutParams(0,d(44,a),1f).apply{leftMargin=d(4,a)})
        qbox.addView(qb,LinearLayout.LayoutParams(-1,d(44,a)).apply{topMargin=d(8,a)})
        content.addView(qbox,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        RovexDailyStudyHub.install(a,content,a.findViewById(R.id.flashcardCard))

        content.addView(tv(a,"Quick Tools",18f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{leftMargin=d(3,a);bottomMargin=d(7,a)})
        val qr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL}
        val qscroll=HorizontalScrollView(a).apply{isHorizontalScrollBarEnabled=false}
        val tools=listOf(
            "▣\nPYQ" to {openSection(a,"qbank","PYQ")},
            "✓\nTests" to {openSection(a,"tests","Subject Test")},
            "✎\nNotes" to {a.startActivity(Intent(a,NotesActivity::class.java))},
            "▤\nLibrary" to {a.startActivity(Intent(a,MainQBankLibraryActivity::class.java))},
            "⌘\nTools" to {a.startActivity(Intent(a,StudyToolsActivity::class.java))},
            "⚙\nSettings" to {a.startActivity(Intent(a,SettingsActivity::class.java))}
        )
        tools.forEachIndexed{index,p->qr.addView(tv(a,p.first,13f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER;background=card(a,index);setOnClickListener{p.second()}},LinearLayout.LayoutParams(d(98,a),d(70,a)).apply{rightMargin=d(7,a)})}
        qscroll.addView(qr);content.addView(qscroll,LinearLayout.LayoutParams(-1,d(78,a)).apply{bottomMargin=d(13,a)})

        val goal=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(15,a),d(12,a),d(15,a),d(12,a));background=card(a,2)}
        val goalTitle=tv(a,"🏆  Weekly Goal",17f,ThemeManager.text(a),true)
        val goalText=tv(a,"Goals not set",12.5f,ThemeManager.muted(a),false)
        val goalBar=ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;this.progress=0;progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(a));progressBackgroundTintList=android.content.res.ColorStateList.valueOf(ThemeManager.peacockFill(a))}
        val setGoals=tv(a,"SET DAILY / WEEKLY GOAL",10.5f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(17,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};setOnClickListener{showGoalDialog(a){refreshDynamic(a,progressValue,progressMeta,progressGraph,goalText,goalBar)}}}
        goal.addView(goalTitle);goal.addView(goalText,LinearLayout.LayoutParams(-1,-2).apply{topMargin=d(6,a)});goal.addView(goalBar,LinearLayout.LayoutParams(-1,d(7,a)).apply{topMargin=d(7,a)});goal.addView(setGoals,LinearLayout.LayoutParams(-1,d(38,a)).apply{topMargin=d(8,a)})
        content.addView(goal,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(13,a)})

        content.addView(tv(a,"Continue Learning",18f,ThemeManager.text(a),true),LinearLayout.LayoutParams(-1,-2).apply{leftMargin=d(3,a);bottomMargin=d(7,a)})
        val hs=HorizontalScrollView(a).apply{isHorizontalScrollBarEnabled=false};val hr=LinearLayout(a).apply{orientation=LinearLayout.HORIZONTAL};hs.addView(hr)
        content.addView(hs,LinearLayout.LayoutParams(-1,d(128,a)).apply{bottomMargin=d(13,a)})
        refreshContinue(a,hr)

        content.addView(tv(a,"✦   Discipline today, Doctor tomorrow.   ›",16f,ThemeManager.accent(a),true).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(d(16,a),0,d(16,a),0);background=card(a,3)},LinearLayout.LayoutParams(-1,d(62,a)))

        val nav=LinearLayout(a).apply{gravity=Gravity.CENTER;setPadding(d(7,a),d(5,a),d(7,a),d(5,a));background=GradientDrawable().apply{setColor(ThemeManager.elevated(a));cornerRadius=d(24,a).toFloat();setStroke(d(1,a),ThemeManager.accent(a))};elevation=d(12,a).toFloat()}
        val names=arrayOf("⌂\nHome","▣\nQBank","▤\nCards","•••\nMore")
        names.indices.forEach{i->nav.addView(tv(a,names[i],11.5f,if(i==0)ThemeManager.accent(a) else ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;setPadding(0,d(2,a),0,d(2,a));if(i==0)background=GradientDrawable().apply{setColor(ThemeManager.peacockFill(a));cornerRadius=d(18,a).toFloat()};setOnClickListener{navigateNav(a,i,a.findViewById(R.id.flashcardCard))}},LinearLayout.LayoutParams(0,d(56,a),1f))}
        shell.addView(nav,FrameLayout.LayoutParams(-1,d(66,a),Gravity.BOTTOM).apply{leftMargin=d(11,a);rightMargin=d(11,a);bottomMargin=d(9,a)})

        var downX=0f;var downY=0f
        shell.setOnTouchListener{_,e->when(e.actionMasked){MotionEvent.ACTION_DOWN->{downX=e.x;downY=e.y;true};MotionEvent.ACTION_UP->{val dx=e.x-downX;val dy=e.y-downY;if(abs(dx)>d(72,a)&&abs(dx)>abs(dy)*1.3f){if(dx<0)navigateNav(a,1,a.findViewById(R.id.flashcardCard)) else navigateNav(a,3,a.findViewById(R.id.flashcardCard));true}else false};else -> false}}
        shell.addView(legacy,FrameLayout.LayoutParams(1,1));root.addView(shell,ViewGroup.LayoutParams(-1,-1))

        refreshDynamic(a,progressValue,progressMeta,progressGraph,goalText,goalBar)
    }

    private fun refreshContinue(a:MainActivity,row:LinearLayout){
        PerformanceManager.submit{
            val data=runCatching{
                val db=QBankDb(a.applicationContext)
                try { db.sources() to db.dashboardTestRows() } finally { db.close() }
            }.getOrNull() ?: return@submit
            val sources=data.first;val rows=data.second
            val cards=sources.map{src->
                val relevant=rows.filter{it.source==src.fileName};val total=relevant.sumOf{it.total};val solved=relevant.sumOf{it.solved};Triple(src,total,solved)
            }.sortedByDescending{it.third}.take(6)
            a.runOnUiThread{
                val hr=row
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                hr.removeAllViews()
                if(cards.isEmpty()){
                    hr.addView(tv(a,"No imported QBank yet\nImport a QBank to start learning",13f,ThemeManager.muted(a),false).apply{gravity=Gravity.CENTER;background=card(a,0)},LinearLayout.LayoutParams(d(210,a),d(116,a)))
                } else cards.forEachIndexed{index,item->
                    val src=item.first;val total=item.second;val solved=item.third
                    val label=if(total>0)"$solved / $total solved" else "No question data yet"
                    val box=tv(a,"📘\n${src.fileName}\n$label",13f,ThemeManager.text(a),true).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER;background=card(a,index);setPadding(d(8,a),d(7,a),d(8,a),d(7,a))
                        setOnClickListener{
                            val repo=MainRepository(a.applicationContext)
                            val target=runCatching{repo.resumeTarget(src)}.getOrNull();repo.close()
                            if(target!=null) a.startActivity(Intent(a,QuizActivity::class.java).putExtra("testId",target.testId).putExtra("title",target.title).putExtra("position",target.position).putExtra("practiceMode",true))
                            else a.startActivity(Intent(a,TestListActivity::class.java).putExtra("sourceId",src.id).putExtra("sourceName",src.fileName))
                        }}
                    hr.addView(box,LinearLayout.LayoutParams(d(170,a),d(116,a)).apply{rightMargin=d(8,a)})
                }
            }
        }
    }

    private fun refreshDynamic(a:MainActivity,value:TextView,meta:TextView,graph:TodayProgressGraphView,goalText:TextView,goalBar:ProgressBar){
        PerformanceManager.submit{
            val result=runCatching{
                val refs=PerformanceManager.lightRefs(a.applicationContext)
                val day=AppManagers.analytics.snapshot(refs,1)
                val week=AppManagers.analytics.snapshot(refs,7)
                val goals=MainRepository(a.applicationContext)
                val daily=goals.dailyGoal();val weekly=goals.weeklyGoal();goals.close()
                DynamicResult(day.todaySolved,day.attempted,day.correct,day.wrong,week.attempted,daily,weekly,
                    PerformanceManager.progress(a.applicationContext).all().values
                        .filter { it.lastAttempted >= startOfToday() && it.status != null }
                        .map { it.lastAttempted to (it.status == "correct") })
            }.getOrNull() ?: return@submit
            a.runOnUiThread{
                if(a.isFinishing||a.isDestroyed)return@runOnUiThread
                val today=result.today;val attempted=result.attempted;val correct=result.correct;val wrong=result.wrong;val week=result.week;val daily=result.daily;val weekly=result.weekly
                value.text=if(daily>0)"$today / $daily" else "$today solved today"
                graph.setTodayProgress(result.points)
                meta.text="$attempted attempted • $correct correct • $wrong wrong"
                goalText.text=if(weekly>0)"$week / $weekly questions this week" else "$week questions attempted this week • weekly goal not set"
                goalBar.progress=if(weekly>0)(week*100/weekly).coerceIn(0,100) else 0
            }
        }
    }

    private fun startOfToday(): Long = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0) }.timeInMillis

    private fun showGoalDialog(a:MainActivity,onSaved:()->Unit){
        val box=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(d(20,a),d(5,a),d(20,a),0)}
        val daily=EditText(a).apply{hint="Daily questions (0 = not set)";inputType=android.text.InputType.TYPE_CLASS_NUMBER;setText(MainRepository(a.applicationContext).use{it.dailyGoal().takeIf{v->v>0}?.toString().orEmpty()})}
        val weekly=EditText(a).apply{hint="Weekly questions (0 = not set)";inputType=android.text.InputType.TYPE_CLASS_NUMBER;setText(MainRepository(a.applicationContext).use{it.weeklyGoal().takeIf{v->v>0}?.toString().orEmpty()})}
        box.addView(daily,LinearLayout.LayoutParams(-1,d(56,a)));box.addView(weekly,LinearLayout.LayoutParams(-1,d(56,a)))
        AlertDialog.Builder(a).setTitle("Study goals").setMessage("Only your saved answer history is used for progress. No target is invented automatically.").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE"){_,_->MainRepository(a.applicationContext).use{it.setDailyGoal(daily.text.toString().toIntOrNull()?:0);it.setWeeklyGoal(weekly.text.toString().toIntOrNull()?:0)};onSaved()}.show()
    }
}
