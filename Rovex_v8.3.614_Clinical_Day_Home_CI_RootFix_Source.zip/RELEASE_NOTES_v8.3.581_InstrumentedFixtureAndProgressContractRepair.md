# Rovex v8.3.581 — Instrumented Fixture and Progress Contract Repair

## Root causes addressed
- `QBankDeletionIsolationTest.foregroundInterruptionBetweenQuestionBatchesLeavesDurableRecoveryBoundary` deleted question rows but reinserted the already-existing `delete-test` and `keep-test` primary keys, causing `UNIQUE constraint failed: test.id`.
- `QBankImportWriter` progress emission was made explicit and auditable at the authoritative count increment; the existing first/checkpoint/final cadence is preserved.

## Verification status
- Source repair: COMPLETE
- Local Android/Gradle execution: BLOCKED by unavailable Gradle distribution DNS in this environment
- GitHub CI: PENDING
- Instrumented tests: PENDING
