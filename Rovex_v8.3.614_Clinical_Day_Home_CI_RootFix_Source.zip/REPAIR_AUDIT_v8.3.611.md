# v8.3.611 Visual Theme JVM Test Contract Repair

## Root cause from CI v8.3.610
GitHub Actions reached `:app:testDebugUnitTest` after production and unit-test compilation. Exactly two tests failed:
- `RovexThemeProfileTest.allEightThemesHaveDistinctVisualProfiles`
- `RovexThemeProfileTest.motionProfilesRemainBounded`

Both failed with `java.lang.RuntimeException` from `RovexThemeProfileTest.kt`. The theme profile factory called Android framework `Color.rgb()`/`Color.WHITE`/`Color.BLACK` during a JVM unit test. In the JVM test environment these Android framework methods are mocked and can throw `RuntimeException`. This is a testability defect in the new immutable theme profile, not evidence that the visual profile values are wrong.

## Repair
- Replaced `Color.rgb(r,g,b)` in `RovexThemeProfile` with equivalent packed ARGB integer literals.
- Replaced `Color.WHITE` and `Color.BLACK` with packed ARGB literals.
- Removed the now-unneeded Android `Color` import.
- No test assertion was weakened or removed.
- No visual values were intentionally changed.
- Bumped version to 8.3.611 / versionCode 697.

## Proof
- Pure Kotlin compilation of the actual `RovexThemeProfile.kt` plus a minimal `ThemeManager` test stub succeeded.
- Actual `RovexThemeProfileTest` was executed against the repaired profile with minimal JUnit stubs: `RovexThemeProfileTest PASS`.
- Source brace/parenthesis balance verified.
- No remaining `Color.*` references in `RovexThemeProfile.kt`.
- No production QBank/Ben ownership changes.
- Android Gradle/CI for 8.3.611 remains pending.

## CI status
8.3.610 is NOT green. It had 166 JVM tests with 2 failures. v8.3.611 has not yet been run in GitHub Actions and must not be called green until the full workflow passes.
