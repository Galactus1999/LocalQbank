# AUDIT PROOF — v8.3.595
## CI root-cause repair after v8.3.594 QBankDb extraction

### 1. CI evidence
Uploaded log: `logs_101878056525.zip`.

The Android workflow failed during `:app:compileDebugKotlin`.

The compiler emitted a cascade beginning in `QBankDb.kt` and `QBankStudyStateStore.kt`, including:
- missing `QBankDb.StoredProgress`
- missing `QBankDb.HomeStudyStats`
- missing `QBankDb.StudyAttemptHistoryRow`
- missing `dashboardTestRows()`
- resulting type-inference/buildMap/destructuring failures
- `StudyCore.kt` `timeMs` cascade

The final `StudyCore.kt:57` diagnostic was not the primary root cause.

### 2. Root cause
The v8.3.594 QBankDb extraction removed nested compatibility types and facade methods that existing callers still referenced.

Compared with v8.3.593, the extracted QBankDb no longer declared:
- `StoredProgress`
- `HomeStudyStats`
- `StudyAttemptHistoryRow`

It also lost the facade method `dashboardTestRows()`.

Additional compatibility members omitted by the extraction were:
- `bookmarkCounts()`
- `homeStudyStats()`
- `studyAttemptHistory()`
- `recordStudyAttempt()`
- `updateLatestStudyAttemptTime()`
- `seedStudyAttemptHistoryIfNeeded()`
- private `images()`
- private `stableKey()`

These omissions caused the large compiler cascade.

### 3. Repair
v8.3.595 restores the three nested data classes on `QBankDb` so existing source/API references remain valid.

It restores `dashboardTestRows()` as a QBankDb facade method, retaining the existing SQLite query implementation.

It restores the study-state facade delegates to `QBankStudyStateStore`.

It restores the two private QBankDb compatibility helpers required by remaining QBankDb search/read code.

`StudyCore.snapshot()` was separately corrected to avoid the mixed `StudyState`/`ProgressRecord` expression that caused the reported `timeMs` inference cascade. The persisted record is now explicitly `ProgressRecord?`.

### 4. Rescan
- 326 Kotlin files scanned.
- 38 XML files scanned.
- XML parse failures: 0.
- Duplicate `@+id` values within individual layouts: 0.
- Actual merge-conflict marker lines: 0.
- Changed `StudyCore.kt` catch(Throwable): 0.
- Original v8.3.593 nested model declarations restored: PASS.
- Original compiler-reported facade symbols restored: PASS.
- Direct `QBankDb(...).method()` call scan found no remaining calls to missing facade methods.
- QBankDb method comparison shows only `categoryFor()` remains intentionally absent; it was a private, unused helper with no callers.
- QBankDb line count after compatibility restoration: 1,467.
- Version: 8.3.595 / versionCode 681.

### 5. Research basis
Current Kotlin documentation confirms that lambda/scope expressions introduce their own scopes and that type inference operates over expression branches; explicit local typing/early return is preferable when branches have different concrete types. Current Kotlin guidance also recommends avoiding confusing nested scope-function chains.

### 6. Verification boundary
The uploaded CI log is verified evidence of the v8.3.594 failure.
Static/source verification of v8.3.595 is complete.
Android Gradle CI has NOT yet run on v8.3.595.
Therefore v8.3.595 is NOT claimed CI-green or device-validated.
