# Rovex QBankDb Final Extraction Audit — v8.3.596

## Status
- Version: 8.3.596
- versionCode: 682
- Previous verified CI baseline: v8.3.595 / versionCode 681 (user reports GitHub run green)
- v8.3.596 Android CI: **NOT YET RUN / NOT VERIFIED**
- Device validation: **NOT RUN**
- Local Gradle compile: **BLOCKED** because Gradle distribution resolution cannot resolve `downloads.gradle.org` in this environment.

## Objective
Final QBankDb extraction pass: determine whether extraction was complete, extract remaining repository/lifecycle seams that were clearly embedded in QBankDb, preserve compatibility APIs, and audit related regressions.

## Major extractions completed
1. `QBankDatabaseProvider.kt`
   - SQLiteOpenHelper/provider ownership and full QBank schema creation moved out of QBankDb.
   - `QBankDb` retains its compatibility reset hook.
2. `QBankSearchIndexCoordinator.kt`
   - FTS schema validation, health, bounded rebuild, dirty generation, maintenance scheduling, and finalization moved out.
   - Rebuild/schema writes now use the shared `QBankWriteCoordinator`.
   - Health proof now checks distinct live question IDs and rejects duplicate live FTS rows; matching counts alone are no longer sufficient.
3. `QBankSearchRepository.kt`
   - FTS/LIKE question search, image-question search, and section search moved out.
   - Existing search behavior was compared against the v8.3.595 source block with zero semantic text diff.
4. `QBankDashboardRepository.kt`
   - Dashboard test-row aggregation moved out of QBankDb.
5. `QBankStreamingImportSession.kt`
   - Long-lived HTML streaming import session/writer moved out.
   - `QBankDb.StreamingImportSession` compatibility wrapper retained so callers using the historical nested type are not broken.
6. `ProgressStore.kt`
   - The complete top-level ProgressStore implementation was moved out of QBankDb with an exact source-block comparison: zero diff.

## QBankDb size
- v8.3.595 baseline: 1,467 lines
- v8.3.596: 633 lines
- Reduction from v8.3.595: 834 lines / 56.85%
- Historical v8.3.594 size: 1,708 lines
- Reduction from v8.3.594: 1,075 lines / 62.94%

## What remains in QBankDb by design
The remaining code is primarily the compatibility façade and source lifecycle/orchestration:
- stable public façade delegates
- source deletion admission/recovery/tombstone lifecycle
- source/test metadata mutation
- progress summary aggregation that still intentionally bridges the legacy ProgressStore contract
- import identity replacement orchestration
- streaming-import source creation
- database snapshot/close compatibility methods
- public/nested model compatibility types

These are not parallel repositories duplicating ownership. They are façade/lifecycle responsibilities and should not be split into arbitrary micro-classes merely to reduce line count.

## Related regression fixed during this pass
QBank search-index maintenance previously performed FTS rebuild writes outside the shared QBank write coordinator. This could race normal import/deletion writes. v8.3.596 serializes FTS schema mutation, full-index clearing, and FTS batch insertion with `QBankWriteCoordinator`.

Deletion now explicitly marks the search index dirty in addition to `garbage_pending`, so a completed deletion cannot accidentally publish a clean FTS state based only on live-row cardinality.

## Compatibility checks
- Historical QBankDb public façade method set preserved.
- `QBankDb.StoredProgress`, `HomeStudyStats`, `StudyAttemptHistoryRow`, and `NoteRecord` remain nested compatibility types.
- `QBankDb.StreamingImportSession` nested compatibility façade retained.
- Existing `ProgressStore` remains top-level with the same name and package.
- QBankDb constructor count: 64 in v8.3.595 and 64 in v8.3.596; no new database construction regression introduced.

## Static audit
- Kotlin files: 280
- XML files: 36
- XML parse errors: 0
- Duplicate `@+id` values within individual layouts: 0
- Merge-conflict markers: 0
- `catch(Throwable)` deltas against v8.3.595: 0
- stale exact versionName/versionCode assertions for 8.3.595/681 and 8.3.594/680: 0
- ZIP/project source was checked for accidental new QBankDb construction; none introduced.

## Research basis
Android's current SQLite performance guidance recommends reducing rows/columns read, pushing filtering/sorting into SQLite, using appropriate indexes, batching writes in transactions, and serializing writes because only one write transaction can occur at a time. citeturn0search6

SQLite's official query-planner documentation recommends `EXPLAIN QUERY PLAN` for interactive diagnosis and emphasizes indexes, multi-column/covering indexes, and avoiding unnecessary temporary sorting. citeturn0search0turn0search2turn0search3

## Verification boundary
The source audit is complete for this extraction phase, but v8.3.596 is **not** build-green until GitHub Actions compiles the exact source and the complete release workflow succeeds. Device/runtime validation is also still required after CI for this database architecture change.
