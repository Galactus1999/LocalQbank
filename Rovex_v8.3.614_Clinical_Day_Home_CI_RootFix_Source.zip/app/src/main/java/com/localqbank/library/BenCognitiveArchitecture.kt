package com.localqbank.library

import android.content.Context
import kotlin.math.roundToInt

/**
 * Ben's lightweight cognitive architecture.
 *
 * This is deliberately model-independent: retrieval, routing, memory, planning and
 * verification continue to work with the neural backend disabled. A future local model
 * is an accelerator behind BenInferenceBackend, never the owner of study state.
 */
class BenCognitiveArchitecture(context: Context, private val deterministic: RenCognitiveEngine = RenCognitiveEngine(context.applicationContext)) {
    private val app = context.applicationContext
    private val knowledge = BenKnowledgeGraph(app)
    private val learner = BenLearnerModel(app)
    private val planner = BenPlanner(knowledge, learner)
    private val verifier = BenAnswerVerifier()
    private val control = BenCognitiveControl(app)
    private val frankenstein = BenFrankensteinEngine(app, deterministic)
    private val experience = BenExperienceMemory(app)
    private val knowledgeIndex = BenLocalKnowledgeIndex(app)
    private val taskDecomposer = BenTaskDecomposer()
    private val cognitiveExecutor = BenCognitiveExecutor(frankenstein, learner)

    data class Plan(
        val query: String,
        val intent: String?,
        val concepts: List<String>,
        val domains: Set<String>,
        val tools: List<String>,
        val confidence: Int,
        val specialist: String = "clinical_retrieval",
        val retrievedQuestionCount: Int = 0,
        val indexedEvidenceCount: Int = 0,
        val knowledgeGraphEdges: Int = 0,
        val visualIntent: Boolean = false,
        val examTerms: List<String> = emptyList()
    )

    data class Result(
        val answer: String,
        val plan: Plan,
        val verified: Boolean,
        val confidence: Int,
        val modelUsed: Boolean,
        val cognitivePlan: BenCognitivePlan? = null,
        val reasoningBrief: String = ""
    )

    fun answer(
        query: String,
        currentQuestion: Question? = null,
        baseAnswer: String? = null,
        modelUsed: Boolean = false,
        evidence: List<BenAnswerVerifier.EvidenceItem> = emptyList()
    ): Result {
        val clean = BenResearchInputPolicy.normalize(query)
            ?: return Result("Give Ben a clinical term, topic, question, or study task.", Plan("", null, emptyList(), emptySet(), emptyList(), 0), true, 0, false)
        if (!control.cognitiveCoreEnabled) {
            val fallback = baseAnswer?.takeIf { it.isNotBlank() } ?: deterministic.answer(clean, currentQuestion).body
            return Result(BenResponsePolicy.normalize(fallback).orEmpty(), Plan(clean, null, emptyList(), emptySet(), listOf("legacy_local_fallback"), 35), true, 35, false)
        }
        val understanding = runCatching { knowledge.understand(clean) }.getOrElse {
            ClinicalKnowledgeLayer.Understanding(clean, clean, emptyList(), null, emptySet(), listOf(clean), false, emptySet(), emptyList())
        }
        val basePlan = if (control.plannerEnabled) planner.plan(clean, control.knowledgeGraphEnabled, understanding) else BenCognitiveArchitecture.Plan(clean, null, emptyList(), emptySet(), emptyList(), 30)
        val retrieval = if (control.retrievalEnabled) frankenstein.retrieve(clean, 12, understanding) else BenFrankensteinEngine.Retrieval(LongArray(0), emptyList(), listOf(clean), emptySet())
        val indexed = if (control.knowledgeIndexEnabled) runCatching { knowledgeIndex.retrieve(clean, retrieval.concepts, 8) }.getOrDefault(BenLocalKnowledgeIndex.Retrieval(emptyList(), 0)) else BenLocalKnowledgeIndex.Retrieval(emptyList(), 0)
        if (control.knowledgeIndexEnabled) runCatching { knowledgeIndex.observe(clean, retrieval.concepts, retrieval.domains) }
        val specialist = if (control.specialistRoutingEnabled) frankenstein.specialist(clean, understanding) else BenFrankensteinEngine.Specialist("clinical_retrieval", "Clinical retrieval", "Specialist routing disabled")
        val plan = basePlan.copy(
            concepts = if (basePlan.concepts.isNotEmpty()) basePlan.concepts else retrieval.concepts,
            domains = if (basePlan.domains.isNotEmpty()) basePlan.domains else retrieval.domains,
            tools = (basePlan.tools + specialist.id + if (retrieval.questionIds.isNotEmpty()) "local_rag" else "").filter { it.isNotBlank() }.distinct(),
            specialist = specialist.id,
            retrievedQuestionCount = retrieval.questionIds.size,
            indexedEvidenceCount = indexed.evidence.size,
            knowledgeGraphEdges = indexed.edgeCount,
            visualIntent = understanding.visualIntent,
            examTerms = understanding.examTerms.take(8),
            confidence = (basePlan.confidence + (if (retrieval.questionIds.isNotEmpty()) 8 else 0) + indexed.evidence.size.coerceAtMost(4) + (if (indexed.edgeCount > 0) 3 else 0)).coerceIn(0, 95)
        )
        val cognitivePlan = taskDecomposer.decompose(clean, understanding, plan)
        val cognitiveExecution = runCatching {
            cognitiveExecutor.execute(clean, understanding, cognitivePlan, retrieval)
        }.getOrNull()
        if (control.learnerMemoryEnabled) {
            learner.observeQuery(plan)
            if (currentQuestion != null) learner.observeQuestion(currentQuestion)
        }
        val candidate = baseAnswer?.takeIf { it.isNotBlank() }
            ?: deterministic.answer(clean, currentQuestion).body
        val verification = if (control.verifierEnabled || (modelUsed && evidence.isNotEmpty())) {
            verifier.verify(clean, candidate, plan, evidence)
        } else {
            BenAnswerVerifier.Verification(true, plan.confidence, emptyList(), true)
        }
        // A rejected neural draft is never repaired into a student-facing answer.
        // Repairing an unsupported medical claim would turn a failed safety gate into a
        // false-positive verification. Callers that supplied a neural draft must discard it.
        BenNeuralTelemetry.verifier(verification)
        val rejectedNeural = modelUsed && !verification.acceptable
        val finalResult = if (rejectedNeural) {
            // A failed neural grounding gate is terminal for that draft. Never repair or return
            // the rejected medical prose. Re-enter the deterministic Ren path instead.
            val fallback = runCatching { deterministic.answer(clean, currentQuestion) }.getOrNull()?.body
                ?: "Ben could not safely verify the neural draft; deterministic retrieval is unavailable."
            fallback to false
        } else {
            candidate to modelUsed
        }
        val final = finalResult.first
        val finalModelUsed = finalResult.second
        val confidence = if (rejectedNeural) {
            plan.confidence.coerceIn(0, 100)
        } else {
            ((plan.confidence * 0.7f) + (verification.score * 0.3f)).roundToInt().coerceIn(0, 100)
        }
        val result = Result(
            answer = BenResponsePolicy.normalize(final).orEmpty(),
            plan = plan,
            verified = !rejectedNeural && verification.acceptable || rejectedNeural,
            confidence = confidence,
            modelUsed = finalModelUsed,
            cognitivePlan = cognitivePlan,
            reasoningBrief = cognitiveExecution?.reasoningBrief.orEmpty()
        )
        if (control.experienceMemoryEnabled) {
            runCatching { frankenstein.observe(clean, plan, result) }
            runCatching { experience.record(clean, plan, result) }
        }
        return result
    }

    fun control(): BenCognitiveControl = control
    fun learner(): BenLearnerModel = learner

    fun capabilitySummary(): List<String> = listOf(
        "Intent routing", "Explicit cognitive task graph", "Bounded multi-hop reasoning", "Working memory",
        "Clinical concept graph", "Hybrid local retrieval planning", "INI-CET/NEET-PG terminology",
        "Visual-question grounding", "Learner memory", "Adaptive tool selection", "Evidence verification",
        "Offline-first reasoning", "Optional neural accelerator", "Local knowledge index and concept-edge graph"
    )

    fun cognitivePlan(query: String): BenCognitivePlan? = runCatching {
        val clean = BenResearchInputPolicy.normalize(query) ?: return null
        val understanding = knowledge.understand(clean)
        val plan = planner.plan(clean, control.knowledgeGraphEnabled, understanding)
        taskDecomposer.decompose(clean, understanding, plan)
    }.getOrNull()

    fun toolRegistry(): BenToolRegistry = BenToolRegistry(app)
    fun frankenstein(): BenFrankensteinEngine = frankenstein
    fun experience(): BenExperienceMemory = experience
    fun knowledgeIndex(): BenLocalKnowledgeIndex = knowledgeIndex
}

/** Compact concept graph built from the existing clinical lexicon plus learned usage edges. */
