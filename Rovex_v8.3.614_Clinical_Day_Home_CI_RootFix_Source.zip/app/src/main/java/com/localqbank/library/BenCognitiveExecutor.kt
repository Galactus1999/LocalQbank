package com.localqbank.library

/**
 * Executes the deterministic part of Ben's task graph. It performs bounded multi-hop evidence
 * expansion and produces a trace for the neural composer/verifier. It never invents clinical facts.
 */
class BenCognitiveExecutor(
    private val frankenstein: BenFrankensteinEngine,
    private val learner: BenLearnerModel
) {
    data class Execution(
        val plan: BenCognitivePlan,
        val memory: BenWorkingMemory.Snapshot,
        val evidence: List<BenWorkingMemory.Evidence>,
        val learnerWeakness: String?,
        val reasoningBrief: String
    )

    fun execute(
        query: String,
        understanding: ClinicalKnowledgeLayer.Understanding,
        plan: BenCognitivePlan,
        primary: BenFrankensteinEngine.Retrieval
    ): Execution {
        val memory = BenWorkingMemory().also { it.start(plan) }
        primary.questionIds.take(8).forEachIndexed { index, id ->
            memory.addEvidence(id, "Local QBank question $id (rank ${index + 1})")
        }
        memory.complete("understand", "Intent=${understanding.intent ?: "general"}; concepts=${plan.concepts.take(6).joinToString()}")
        memory.complete("retrieve", "Primary retrieval returned ${primary.questionIds.size} bounded candidates.")

        val connected = plan.tasks.firstOrNull { it.type == BenCognitiveTask.Type.CONNECT }
        if (connected != null && connected.concepts.isNotEmpty()) {
            val secondHopQuery = connected.concepts.take(3).joinToString(" ").take(500)
            val secondHop = runCatching { frankenstein.retrieve(secondHopQuery, 6, understanding) }.getOrNull()
            if (secondHop != null) {
                secondHop.questionIds.take(4).forEach { id -> memory.addEvidence(id, "Second-hop local QBank question $id") }
                memory.complete("connect", "Second-hop concept traversal added ${secondHop.questionIds.size} bounded candidates.")
            } else {
                memory.fail("connect", "Second-hop retrieval unavailable; primary evidence retained.")
            }
        }

        val weakest = plan.concepts.minByOrNull { learner.stats(it).mastery }
        plan.tasks.firstOrNull { it.type == BenCognitiveTask.Type.PERSONALIZE }?.let {
            if (weakest != null) memory.complete("personalize", "Weakest mapped concept: $weakest (${learner.stats(weakest).mastery}% mastery).")
            else memory.skip("personalize", "No learner concept signal available.")
        }
        plan.tasks.firstOrNull { it.type == BenCognitiveTask.Type.COMPARE }?.let {
            memory.complete("compare", "Comparison requested; composer must preserve distinctions rather than merge entities.")
        }
        plan.tasks.firstOrNull { it.type == BenCognitiveTask.Type.EXPLAIN }?.let {
            memory.complete("explain", "Explanation task selected for intent ${understanding.intent ?: "general"}.")
        }
        plan.tasks.firstOrNull { it.type == BenCognitiveTask.Type.VISUAL_GROUND }?.let {
            memory.complete("visual_ground", "Visual claims require actual image evidence; text-only clues are insufficient.")
        }
        val snapshotBeforeVerify = memory.snapshot()
        val brief = buildString {
            append("QUERY: ").append(query.take(240)).append('\n')
            append("COGNITIVE TASK GRAPH:\n")
            plan.tasks.forEach { task -> append("- ").append(task.id).append(": ").append(task.objective).append('\n') }
            append("WORKING MEMORY:\n")
            snapshotBeforeVerify.steps.forEach { step -> append("- ").append(step.id).append("=").append(step.status).append("; ").append(step.note).append('\n') }
            append("LEARNER SIGNAL: ").append(weakest?.let { "$it (${learner.stats(it).mastery}% mastery)" } ?: "none").append('\n')
            append("RULE: retrieved evidence is evidence, not truth by itself; verifier remains authoritative.")
        }
        memory.complete("verify", "Verification gate reserved for final generated/deterministic answer.")
        memory.complete("compose", "Composer receives only bounded task trace and grounded evidence.")
        return Execution(plan, memory.snapshot(), memory.snapshot().evidence, weakest, brief)
    }
}
