package com.localqbank.library.benchmark

import android.content.ComponentName
import android.content.Intent
import androidx.benchmark.macro.CompilationMode
import androidx.benchmark.macro.ExperimentalMetricApi
import androidx.benchmark.macro.FrameTimingMetric
import androidx.benchmark.macro.MemoryCountersMetric
import androidx.benchmark.macro.MemoryUsageMetric
import androidx.benchmark.macro.StartupMode
import androidx.benchmark.macro.StartupTimingMetric
import androidx.benchmark.macro.TraceSectionMetric
import androidx.benchmark.macro.junit4.MacrobenchmarkRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import androidx.test.uiautomator.uiAutomator
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

private const val TARGET_PACKAGE = "com.localqbank.library"
private const val MAIN_ACTIVITY = "$TARGET_PACKAGE.MainActivity"

@OptIn(ExperimentalMetricApi::class)
@LargeTest
@RunWith(AndroidJUnit4::class)
class ColdStartupBenchmark {
    @get:Rule
    val benchmarkRule = MacrobenchmarkRule()

    private fun measureStartup(compilationMode: CompilationMode) = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(
            StartupTimingMetric(),
            FrameTimingMetric(),
            MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max),
            MemoryCountersMetric(),
            TraceSectionMetric("Rovex.StartupCoordinator"),
            TraceSectionMetric("Rovex.MainActivity.firstUsable")
        ),
        compilationMode = compilationMode,
        startupMode = StartupMode.COLD,
        iterations = 5,
        setupBlock = { pressHome() }
    ) {
        uiAutomator {
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, MAIN_ACTIVITY)))
            // Production Home is now programmatically rendered; legacy XML IDs are intentionally
            // absent from the runtime tree. Benchmark stable accessibility contracts instead.
            onElement(10_000) { contentDescription == "rovexHomeShell" && isVisibleToUser }
            onElement(10_000) { contentDescription == "qbankHomeCard" && isVisibleToUser }
        }
    }

    @Test
    fun coldStartupNoCompilation() = measureStartup(CompilationMode.None())

    @Test
    fun frankensteinWorkspaceStartup() = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(
            StartupTimingMetric(),
            FrameTimingMetric(),
            MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max)
        ),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.COLD,
        iterations = 5,
        setupBlock = { pressHome() }
    ) {
        uiAutomator {
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, "$TARGET_PACKAGE.RenActivity")))
            onElement(10_000) { contentDescription == "frankensteinPrompt" && isVisibleToUser }
        }
    }


    @Test
    fun qbankLibraryStartup() = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(
            StartupTimingMetric(),
            FrameTimingMetric(),
            MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max),
            TraceSectionMetric("Rovex.qbank-library-source-read"),
            TraceSectionMetric("Rovex.qbank-library-order-read")
        ),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.COLD,
        iterations = 5,
        setupBlock = { pressHome() }
    ) {
        uiAutomator {
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, "$TARGET_PACKAGE.MainQBankLibraryActivity")))
            onElement(10_000) { text == "Imported QBanks" && isVisibleToUser }
        }
    }

    @Test
    fun homeToQBankSection() = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(StartupTimingMetric(), FrameTimingMetric(), MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max)),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.WARM,
        iterations = 5,
        setupBlock = {
            pressHome()
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, MAIN_ACTIVITY)))
        }
    ) {
        uiAutomator {
            onElement(10_000) { contentDescription == "qbankHomeCard" && isVisibleToUser }.click()
            onElement(10_000) { text == "QBank" && isVisibleToUser }
        }
    }

    @Test
    fun coldStartupPartialCompilation() = measureStartup(CompilationMode.Partial())
    @Test
    fun searchJourney() = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(StartupTimingMetric(), FrameTimingMetric(), MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max)),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.COLD,
        iterations = 5,
        setupBlock = { pressHome() }
    ) {
        uiAutomator {
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, "$TARGET_PACKAGE.SearchActivity")))
            onElement(10_000) { contentDescription == "rovexSearchInput" && isVisibleToUser }.text = "subarachnoid hemorrhage"
            onElement(10_000) { text?.contains("questions") == true && isVisibleToUser }
        }
    }

    @Test
    fun performanceLabOpen() = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(StartupTimingMetric(), FrameTimingMetric(), MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max)),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.WARM,
        iterations = 5,
        setupBlock = {
            pressHome()
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, MAIN_ACTIVITY)))
        }
    ) {
        uiAutomator {
            onElement(10_000) { text == "Performance Lab" && isVisibleToUser }.click()
            onElement(10_000) { text == "PERFORMANCE LAB" && isVisibleToUser }
        }
    }

    @Test
    fun studyHealthOpen() = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(StartupTimingMetric(), FrameTimingMetric(), MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max)),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.WARM,
        iterations = 5,
        setupBlock = {
            pressHome()
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, MAIN_ACTIVITY)))
        }
    ) {
        uiAutomator {
            onElement(10_000) { text == "Study Health" && isVisibleToUser }.click()
            onElement(10_000) { text == "Study Health" && isVisibleToUser }
        }
    }

    @Test
    fun themeSwitchJourney() = benchmarkRule.measureRepeated(
        packageName = TARGET_PACKAGE,
        metrics = listOf(StartupTimingMetric(), FrameTimingMetric(), MemoryUsageMetric(mode = MemoryUsageMetric.Mode.Max)),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.WARM,
        iterations = 5,
        setupBlock = {
            pressHome()
            startActivityAndWait(Intent().setComponent(ComponentName(TARGET_PACKAGE, "$TARGET_PACKAGE.SettingsActivity")).putExtra("section", "appearance"))
        }
    ) {
        uiAutomator {
            onElement(10_000) { text == "Pandora • Living World" && isVisibleToUser }.click()
            onElement(10_000) { text == "Appearance & Themes" && isVisibleToUser }
        }
    }

}
