# Rovex v8.3.572 — QBank Test/Verification Repair

## CI evidence addressed
The v8.3.569 CI run executed the complete JVM/build stages successfully but failed during the 67-test instrumented suite with four failures.

Two failures were test-fixture defects:
- `QBankDeletionIsolationTest.foregroundInterruptionBetweenQuestionBatchesLeavesDurableRecoveryBoundary` cleared the keep-side question and then asserted it remained.
- `QBankImportIdentityRegressionTest.reimportAfterExplicitTombstoneFinishesOldPhysicalDataBeforeReplacement` assumed a short import key was stored verbatim although `safeImportKey()` normalizes it.

The two `QBankImportWriterRegressionTest` progress assertions are retained as production-path regression gates; no weakening of those assertions is made here.

## Important
This release has NOT been declared CI-green. The next CI run must independently verify the corrected source, including the complete instrumented suite.
