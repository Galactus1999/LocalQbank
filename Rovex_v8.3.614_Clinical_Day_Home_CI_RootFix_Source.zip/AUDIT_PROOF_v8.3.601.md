# Rovex v8.3.601 — CI root-cause repair proof

## CI evidence
Source log: logs_101905531180.zip.

The Android project compiled far enough to execute 73 instrumented tests.
The test runner reported exactly 2 distinct failures:
- QBankDbSearchRegressionTest.deletingQBankIsFastSafeAndLeavesStaleFtsForIdleMaintenance: line 109, expected dirty=0 but got 1.
- QBankDeletionIsolationTest.deletingOneQBankPreservesAnotherAndSearchRemainsLive: line 118, expected dirty=0 but got 1.

EmbeddingGemma real-inference test was skipped by JUnit assumption (status -4), not failed.

## Root cause
QBankSourceDeletionManager called the generic `markSearchIndexDirty()` after a physical source deletion.
The intended deletion contract is:
- normalized live corpus is immediately authoritative and excludes the deleted source;
- FTS4 rows for the deleted source may remain as physical garbage until idle maintenance;
- `garbage_pending=1` requests deferred cleanup;
- `dirty=0` means live-question FTS coverage remains usable;
- search joins FTS matches to live question/test/source rows, preventing deleted sources from being returned.

Setting dirty=1 was therefore a behavioral regression against the existing deletion contract and tests.

## Fix
Added `QBankSearchIndexCoordinator.markGarbagePending()`:
- increments mutation generation;
- records `garbage_pending=1`;
- invalidates cached health;
- does NOT set `dirty=1`.

Rewired QBankDb and QBankSourceDeletionManager to use this method after deletion.

## Additional proven/future-risk cleanup
- HtmlImportParser: removed nullable `JSONObject.optString(k, null)` Java interop warning by returning `optString(k)` after explicit null check.
- ProgressStore: aligned override parameter name with `ProgressRepository.answer`.
- QBankStudyStateStore: explicit `Array<Any?>` for heterogeneous SQLite bind arguments.
- QBankStreamingImportSessionSourceRegressionTest: eliminated nullable `readText()` warning.
- ApkgImporter: made nullable regex group handling explicit.
- StreakDatabaseConcurrencyTest and FlashcardDb: explicit heterogeneous SQLite bind arrays.

## Static verification
- package declarations: one per Kotlin file
- merge-conflict markers: none detected
- source version: 8.3.601 / versionCode 687
- no 8.3.600 version references in source
- QBank deletion callback now targets markSearchIndexGarbagePending
- no remaining QBankSourceDeletionManager reference to markSearchIndexDirty
- ZIP integrity checked after packaging

## Verification boundary
v8.3.601 has not yet been run through GitHub Actions. Do not call it CI-green or device-validated until the exact source is built and the complete workflow log is inspected.
