# Rovex v8.3.609 — Living Visual System + Performance Phase 1

## Baseline
- Based on the last green/tested QBank/Ben-concurrency baseline v8.3.607.
- v8.3.608 Ben Agentic Cognitive Tools is intentionally not folded into this release until its own CI/device validation is complete.

## Visual changes
- Replaced the old shared light-theme atmosphere with eight distinct visual profiles: Clinical Day, Pastel Prism, Living Mint, Solar Ember, Iris Aurora, OLED Aurora, Pandora Living World and Deep Cosmos.
- Added `RovexLivingBackgroundDrawable` with Android 13+ AGSL flow-field rendering and a Canvas fallback for older devices.
- Removed the obsolete `ThemeAtmosphereDrawable` implementation from the active source.
- Added subtle animated ribbons, aurora, particles, bubbles, cloud haze and celestial effects; all are procedurally generated in-app with no third-party animation/video assets.
- Added adaptive theme profiles for panel/elevated/accent/secondary-accent/text/muted tokens.
- Added restrained deep-touch and theme-switch audio cues generated locally as PCM assets; existing SoundPool single-stream exclusivity is preserved.
- Added context-click haptic feedback for primary buttons/cards.
- Added theme-switch fade transition around Activity recreation.
- Updated the theme audit marker to include all eight themes.

## Performance changes
- Theme profile caching avoids repeated palette construction/SharedPreferences work on hot draw paths.
- Background animation uses a single reusable shader/paint path and bounded particle counts.
- Performance Lab database/history analytics and current metrics are now computed on `PerformanceManager` rather than on the UI thread; only rendering remains on main.
- Performance telemetry graph was upgraded with grid/soft glow while keeping one-second sampling and bounded history.
- Added Macrobenchmark journeys for Search, Performance Lab, Study Health and theme switching in addition to existing startup/QBank journeys.
- Added stable accessibility identifier for the Search input to support repeatable performance measurement.

## Safety/performance constraints
- No third-party Lottie/Rive/video assets were added.
- No QBank ownership or database semantics were changed.
- No new QBankDb construction was introduced by the visual layer.
- No neural inference/IPC transport changes are included.
- Animation respects `AnimationPolicy` and pauses when the drawable is detached.

## Verification required
- Source/static audit: required.
- Pure Kotlin compile where possible: required.
- Full Android CI: pending.
- Macrobenchmark physical-device measurements: pending.
- Device visual inspection across all eight themes: pending.
- No numerical performance improvement should be claimed until benchmark/device results exist.
