# v8.3.600 CI Root-Cause Repair Audit

Date: 2026-10-07

## 1. Proven CI root cause

Uploaded CI archive: `logs_101897351378.zip`.

The first causal Kotlin compiler errors occur in:
`app/src/main/java/com/localqbank/library/QBankStreamingImportSession.kt`

The CI log records 10 unresolved references to `bindNullable` at source lines 77 and 79 (log lines 1209-1218 in the aggregated build log). The build then fails at `:app:compileDebugKotlin`.

This is an extraction regression: the helper existed in `QBankDb.kt` / `QBankImportWriter.kt` in the pre-extraction corpus but was not moved/copied into the newly extracted `QBankStreamingImportSession.kt`.

## 2. Exact repair

Restored the helper locally in `QBankStreamingImportSession.kt`:

`private fun bindNullable(statement: android.database.sqlite.SQLiteStatement, index: Int, value: String?) {`
`    if (value == null) statement.bindNull(index) else statement.bindString(index, value)`
`}`

The implementation matches the existing established helper in `QBankImportWriter.kt`.

Added `QBankStreamingImportSessionSourceRegressionTest.kt` to prevent the extraction seam from silently losing this helper again.

## 3. Further static audit

- Kotlin files: 332
- XML files: 38
- XML parsing errors: 0
- Duplicate @+id values within individual layouts: 0
- Multiple package declarations: 0
- Broad catch(Throwable) in QBank/import area: 0
- Remaining literal 8.3.598 references outside historical audit proof: 0
- QBankDb constructor sites: compared against v8.3.595; no new construction site introduced by this repair.

Apparent merge-marker scan hits were inspected individually. They are report separator strings such as `============================`, not Git conflict markers. No actual conflict markers were found.

## 4. Online research applied

SQLite FTS5 official documentation confirms that external/contentless FTS indexes must be explicitly maintained in sync with their content tables and provides an `integrity-check` command; rebuild is the authoritative repair mechanism when an index becomes inconsistent:
https://sqlite.org/fts5.html

This supports retaining explicit FTS consistency/rebuild handling rather than assuming row counts alone prove index integrity.

## 5. Verification boundary

Local Android compilation was attempted with the repository Gradle wrapper. It could not start because the wrapper attempted to resolve `downloads.gradle.org` and DNS failed (`Could not resolve host: downloads.gradle.org`). Therefore this audit does NOT claim Android compilation success.

Verified locally:
- source patch exists
- helper symbol is now defined in the extracted class
- all 10 CI-reported references are now resolvable by source structure
- version is 8.3.600 / versionCode 686
- XML parse and duplicate-ID checks pass
- package declaration checks pass
- ZIP integrity passes after packaging

Required next proof:
Run the exact v8.3.600 source through GitHub Actions and inspect the complete compiler/build log. Only that run can establish CI-green.
