# QBankDb Audit Proof — v8.3.594

## Scope
Continuation of v8.3.592 QBank deletion/background-cleanup hardening.

## Research basis
- Android SQLite performance guidance: bounded result sets, push filtering into SQLite, indexes, batched transactions, serialized writes, EXPLAIN QUERY PLAN.
- SQLite WAL guidance: readers/writers can overlap, but writes/checkpoints still require careful bounded transactions.
- Android WorkManager guidance: persistent background work should use WorkManager; constraints should match the actual work contract.

## v8.3.594 changes
1. Kept v8.3.592 deletion admission repair: no DeviceIdle gate for explicit physical QBank deletion; battery-not-low constraint plus foreground yielding.
2. Kept immediate qbank_delete_requested cache invalidation.
3. Hardened live-corpus read contract for tombstoned sources:
   - questionExists()
   - existingQuestionIds()
   - allStableKeys()
   - note()
   - notes()
   - noteCount()
   - noteImages()
   now join through test/source and require source.deleting=0.
4. Added instrumentation assertions proving a tombstoned source is absent from those read-side APIs while its physical rows still exist.
5. Version 8.3.594 / versionCode 680.

## Static checks performed
- Kotlin source files: 323 scanned.
- XML files: 37 parsed.
- Duplicate layout IDs: 0.
- TODO/FIXME/NotImplemented markers: 0.
- Merge conflict markers: 0.
- Stale 8.3.592/versionCode 678 references: expected only in historical audit text; source/build references updated to 8.3.594/679.
- Changed-surface catch(Throwable): none introduced.

## Runtime/build boundary
Full Android Gradle compilation and instrumentation execution are not claimed here. The local environment cannot resolve downloads.gradle.org for the required Gradle distribution. CI/device validation is required before release.


## v8.3.594 extraction phase
- Extracted live-corpus catalog/question read responsibilities into QBankQuestionRepository.
- QBankDb remains the compatibility facade and database lifecycle owner.
- No deletion/import/search-index/study-state ownership was moved.
- All extracted reads retain source.deleting=0 live-corpus isolation.
- QBankDb reduced from 1708 to 1474 lines.
