# Rovex v8.3.603 — Deep Correction / Hallucination Audit

## Verification identity
- Baseline compared: v8.3.601 source archive.
- Candidate repaired source: v8.3.603.
- Version: 8.3.603 / versionCode 689.
- This report records only checks actually executed in the model/container environment.
- Android Gradle compilation and instrumented tests are **not claimed green** because the supplied wrapper is missing `gradle-wrapper.jar` and the environment cannot resolve `downloads.gradle.org`.

## Direct diff verification
The following requested v8.3.602 changes were verified as physically present in source:
1. FTS finalize logic changed from the incorrect global-cardinality gate to live-question coverage + duplicate-live-row invariants.
2. Delete -> import regression coverage exists.
3. `medical_taxonomy.tsv` exists in app assets with 19 unique subjects and 121 data rows.
4. `MedicalTaxonomyModels.kt` and `MedicalTaxonomyRepository.kt` exist and are referenced by search/classification paths.
5. `DeletedQBankActivity.kt` exists and is registered `android:exported="false"`.
6. `QBankDeletedSourceRepository.kt` exists and reads only durable `deleting=1 AND delete_requested=1` tombstones.
7. Main QBank library exposes a DELETED entry point.
8. Permanent purge runs through the existing authoritative `QBankDb.deleteSource()` / `QBankSourceDeletionManager`; no parallel deletion engine was introduced.

## Additional real defect found and repaired during this deep scan
`MainRepository.purgeDeletedQBank(sourceId)` originally trusted its caller and directly invoked physical deletion. It now first requires `QBankDeletedSourceRepository.isPending(sourceId)`, which checks the durable deletion tombstone. A regression test `permanentPurgeRejectsNonDeletedSource` was added.

The redundant direct `garbage_pending` SQL write in `QBankSourceDeletionManager` was also removed; `QBankSearchIndexCoordinator.markGarbagePending()` is now the single owner of that state transition.

## Taxonomy verification
- TSV parses with exactly 5 columns on every row.
- 19 unique subjects confirmed.
- 121 taxonomy rows confirmed.
- RTA -> renal tubular acidosis query expansion verified at runtime using a Kotlin compilation with Android Context/AssetManager test stubs.
- Pathology/nephrotic classification verified.
- Pharmacology/atropine classification verified.
- Taxonomy Kotlin classes compiled successfully with test stubs.

## FTS verification
`finalizeIncremental()` now publishes clean only when:
- every live question has an FTS row; and
- no live question has a duplicate FTS row.

Physically retained rows belonging to deleted sources are treated as garbage and do not make interactive live search unhealthy. Background maintenance remains responsible for full cleanup/rebuild.

The existing delete -> import regression asserts:
- `dirty = 0`
- `garbage_pending = 1`
- newly imported live content is searchable.

This is consistent with SQLite FTS4's documented separation between the FTS index and authoritative content and its documented rebuild/maintenance mechanisms.

## Deleted-QBank safety verification
- Pending list filters `deleting=1` and `delete_requested=1`.
- Permanent purge is now rejected for an active/non-tombstoned source.
- Actual physical deletion remains owned by `QBankSourceDeletionManager`.
- Deleted activity is non-exported.
- UI deletion is backgrounded through the existing `PerformanceManager.submitQBankDeletion` path.
- Activity checks lifecycle state before updating UI.

## Structural regression scans
- XML parse errors: 0.
- Duplicate XML IDs within individual layouts: 0.
- Merge markers in changed files: 0.
- Literal escaped-newline corruption in changed files: 0.
- New/changed `catch(Throwable)`: 0.
- New source files over 400 lines: 0.
- No new QBankDb construction introduced by this repair.
- No parallel physical QBank deletion owner introduced.
- Manifest registration verified.
- Version monotonicity verified: 8.3.601/versionCode 687 -> 8.3.603/versionCode 689.

## Cross-component call-chain verification
- `LocalQBankSearchService` -> `MedicalTaxonomyRepository.expandQuery()` verified in question and section search.
- `QBankCategoryClassifier` -> taxonomy classification verified.
- `TestListActivity` -> taxonomy display is an additive adapter update; existing constructor call compatibility preserved through a default parameter.
- `MainQBankLibraryActivity` -> `DeletedQBankActivity` verified.
- `DeletedQBankActivity` -> `MainRepository.purgeDeletedQBank()` verified.
- `MainRepository.purgeDeletedQBank()` -> tombstone validation -> `QBankDb.deleteSource()` -> authoritative `QBankSourceDeletionManager` verified.
- `QBankSourceDeletionManager` -> `markGarbagePending()` verified.
- `QBankDb` remains the compatibility facade; extracted repositories/managers remain separate owners.

## Build limitations
Attempted local `bash gradlew :app:compileDebugKotlin --offline`.
Result: wrapper attempted to download Gradle 9.3.1 and failed because `downloads.gradle.org` DNS resolution is unavailable. The source archive also does not contain `gradle/wrapper/gradle-wrapper.jar`.
Therefore:
- Android compilation: NOT VERIFIED.
- Instrumented tests: NOT VERIFIED.
- Device runtime: NOT VERIFIED.
- Release APK: NOT VERIFIED.

## Remaining non-blocking code-quality observations
The inherited project still contains several >240-character lines in older/existing files, including some changed files whose long lines predate this repair. They were not mass-formatted because doing so would create unrelated diff churn. The extracted `QBankSearchIndexCoordinator` also has inherited compact formatting that should be cleaned in a dedicated style-only change after CI is green.

## Research basis
Android architecture guidance recommends clear responsibility boundaries, repositories/data sources, and a single source of truth; the new taxonomy repository and deleted-source repository follow that boundary. SQLite's FTS4 documentation explicitly documents index/content consistency and rebuild mechanisms. WorkManager is the Android-recommended mechanism for reliable deferrable asynchronous work, consistent with the existing background cleanup approach.

## Final status
**SOURCE CORRECTION: VERIFIED STATICALLY.**
**TAXONOMY: VERIFIED.**
**DELETED-QBANK FEATURE: VERIFIED STATICALLY.**
**FTS STATE MACHINE: VERIFIED STATICALLY + REGRESSION TEST ADDED.**
**ANDROID BUILD: BLOCKED/UNVERIFIED.**
**DEVICE: UNVERIFIED.**
**CI: MUST BE RUN BEFORE ANY GREEN/RELEASE CLAIM.**
