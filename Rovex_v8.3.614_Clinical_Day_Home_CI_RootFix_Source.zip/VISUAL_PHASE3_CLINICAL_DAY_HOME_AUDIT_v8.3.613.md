# Rovex v8.3.613 — Clinical Day Home Visual Phase

## Scope

This release is intentionally **one theme + one screen**: the Clinical Day (LIGHT) Home dashboard.
Other themes and other screens are not visually rehauled in this release.

## Implemented

- Added `RovexClinicalDayHomeVisuals.kt` as a bounded, home-only visual component file.
- Replaced the Clinical Day Home's old wallpaper-backed atmosphere with a procedural daylight environment.
- Android 13+ path uses `RuntimeShader`/AGSL for the background field; fallback precomputes Canvas gradients on bounds changes rather than allocating gradient objects per frame.
- Removed the outlined wave/ribbon motif from the Clinical Day Home background.
- Added soft daylight volumes, atmospheric cloud masses, restrained light motes and depth-like colour fields.
- Added a premium Clinical Day surface drawable with gradient material, adaptive accent edge and specular highlight.
- Added a real Home “Today • Study Cockpit” hero using actual saved-progress data.
- Added a bounded progress ring; it shows solved count and only shows percentage-of-goal when a daily goal actually exists.
- Replaced emoji feature icons on Clinical Day Home with small custom line icons for QBank, Flashcards, Performance Lab, Study Health and Ben/AI.
- Existing dark/other themes continue through their existing visual paths.
- No database/business ownership was changed.

## Performance design

- No bitmap/video wallpaper was added.
- No third-party animation asset was added.
- No per-frame `Paint`/`Path`/`RectF` allocation was introduced in the new background or surface draw paths.
- Clinical background animation runs at a bounded 20 Hz update cadence.
- The new custom views use fixed small object sets and bounded geometry.
- The existing Home database work remains on `PerformanceManager`.

## Research basis

Current Android documentation was reviewed before implementation:

- Material 3 Expressive supports explicit colour, typography, shape and motion systems and expanded shape scales.
- Android AGSL `RuntimeShader` supports programmable GPU fragment effects from API 33.
- Android hardware-accelerated Views recommend minimizing allocations in draw/onDraw and unnecessary invalidation.
- Macrobenchmark is the appropriate end-user measurement layer for startup, interaction and animation; JankStats is appropriate for frame-level jank analysis.
- Google Material Symbols are Apache-2.0 and may be incorporated legally; this release does not add the font yet because the Clinical Home icon treatment is currently custom-rendered and bounded.

References:
- https://developer.android.com/develop/ui/compose/designsystems/material3
- https://developer.android.com/reference/kotlin/androidx/compose/material3/MotionScheme
- https://developer.android.com/develop/ui/views/graphics/agsl
- https://developer.android.com/develop/ui/views/layout/custom-views/optimizing-view
- https://developer.android.com/topic/performance/benchmarking/benchmarking-overview
- https://github.com/google/material-design-icons

## Static verification

- New file brace balance: PASS
- New file parenthesis balance: PASS
- Changed Kotlin `catch(Throwable)`: PASS / none introduced
- Changed Kotlin merge markers: PASS / none
- Changed Kotlin literal escaped-newline corruption: PASS / none introduced by this change
- XML parse errors: 0
- Duplicate XML IDs: 0
- Version: 8.3.613 / versionCode 699
- Source diff versus 8.3.612: 1 new visual file + targeted Home changes + version bump
- QBank database ownership: unchanged
- QBankDb constructions: unchanged from baseline Home implementation
- ZIP integrity: to be verified after packaging

## Not yet proven

- Android compilation of 8.3.613
- GitHub CI
- instrumented tests
- actual APK visual screenshots
- device frame-time/jank measurements
- memory/power measurements

No green/build/device claim is made until those gates are actually run.

## Remaining Clinical Day Home work

Estimated remaining for this single-screen mini-project: **~60%**.

Still to refine after the first real APK screenshot:

1. Header/brand composition and settings affordance.
2. Search surface and search interaction motion.
3. Progress graph visual language.
4. Feature-card hierarchy and density.
5. Quick-tools rail.
6. Continue-learning cards.
7. Persistent bottom navigation treatment on Clinical Day Home.
8. Loading/empty/error states.
9. Device screenshot comparison and pixel-level refinement.
10. Macrobenchmark/JankStats validation and GPU/memory tuning.

Only after Clinical Day Home passes these gates should the same process move to Clinical Day QBank.
