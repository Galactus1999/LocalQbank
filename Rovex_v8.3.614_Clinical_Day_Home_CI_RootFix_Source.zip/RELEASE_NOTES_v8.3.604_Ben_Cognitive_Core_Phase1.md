# Rovex v8.3.605 — Ben Cognitive Core Phase 1

## Verified source changes

- Split the former 618-line `BenCognitiveArchitecture.kt` god file into bounded components:
  - `BenKnowledgeGraph.kt`
  - `BenLearnerModel.kt`
  - `BenPlanner.kt`
  - `BenExperienceMemory.kt`
  - `BenAnswerVerifier.kt`
  - `BenToolRegistry.kt`
- Added `BenCognitiveTask.kt` for an explicit task graph with understand/retrieve/connect/compare/explain/personalize/visual-ground/verify/compose stages.
- Added `BenWorkingMemory.kt` for bounded per-request cognitive state.
- Added `BenCognitiveExecutor.kt` for bounded deterministic multi-hop evidence expansion and a reasoning trace.
- Integrated the cognitive plan into `BenCognitiveArchitecture.Result` and the grounded neural prompt.
- Added unit coverage for comparison and visual-grounding task decomposition.
- Preserved deterministic QBank truth, existing verifier authority, isolated neural execution, and resource-governor boundaries.
- No multimodal model capability is claimed for the installed Gemma 3 270M text model.

## Verification status

Static/source verification: REQUIRED before packaging.
Pure task-graph compile/test: REQUIRED before packaging.
Android Gradle compilation: NOT CLAIMED until CI passes.
Instrumented/device validation: NOT CLAIMED until CI/device evidence exists.
