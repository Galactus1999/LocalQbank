# Rovex v8.3.586 — QBank category classification hardening

## Scope
- Consolidated QBank subject/kind classification into `QBankCategoryClassifier`.
- Preserved the legacy `QuestionRef.category` contract separately via `legacyCategory()`.
- Added JVM regression coverage for the 19 canonical subjects, PSM/Community Medicine normalization, Medicine/Surgery aliases, test kinds, and separator/case normalization.
- Dashboard now consumes the same deterministic subject/kind classifier instead of maintaining a second copy of classification rules.

## Verification
- Pure Kotlin classifier compilation: PASS.
- Standalone classifier behavior harness: PASS.
- Source structural brace/parenthesis scan: PASS.
- Merge-marker scan: PASS; separator strings are report formatting, not conflict markers.
- Targeted catch(Throwable) scan of changed QBank/dashboard surfaces: PASS.
- Android Gradle/CI/device validation: NOT CLAIMED until CI executes.
