# Rovex v8.3.600 — CI Root-Cause Repair Proof

Date: 2026-10-07

## Evidence source

CI log: logs_101900613437.zip

The first Kotlin compiler errors in the uploaded CI log were:

1. `ProgressStore.kt:7:22` and `:7:41`: `ProgressDbRegistry` was private in `QBankDb.kt` and therefore inaccessible from the extracted `ProgressStore.kt`.
2. `QBankStreamingImportSession.kt:33:111..215`: the restored `bindNullable` helper had literal `\\n` characters in the Kotlin source, causing syntax errors and an unresolved `n`.
3. `QBankStreamingImportSession.kt:71:20`: `makeId` was not available after extraction from `QBankImportWriter`.

The final CI status was BUILD FAILED during `:app:compileDebugKotlin`. This is direct evidence from the uploaded log; no inference is used for the root cause.

## Repairs

### 1. ProgressDbRegistry ownership/visibility

Moved `ProgressDbRegistry` from the bottom of `QBankDb.kt` into its own `ProgressDbRegistry.kt` file and made it `internal`.

Reason: Kotlin top-level `private` declarations are visible only inside their declaring file. Kotlin's official documentation confirms this. An `internal` declaration is visible throughout the same module.

### 2. Streaming bindNullable corruption

Replaced the literal escaped-newline source corruption with valid Kotlin multiline source.

### 3. Missing makeId helper

Restored the exact SHA-256 based `makeId(file, original, index)` behavior into `QBankStreamingImportSession`, preserving the existing 24-character identifier format used by the import writer.

### 4. Dead helper cleanup

Removed the now-unused `QBankDb.bindNullable` helper. It had no remaining QBankDb callers after extraction.

### 5. Regression guard

Updated `QBankStreamingImportSessionSourceRegressionTest` to assert both extracted helpers exist in the extracted session source.

## Static proof after repair

- Kotlin main-source files: 281
- XML main-source files: 37
- Multiple package declarations: 0
- Actual merge conflict markers: 0
- Literal `\\n` corruption in QBankStreamingImportSession: 0
- Broad `catch(Throwable)` in Kotlin main source: 0
- Old version 8.3.599 / versionCode 685 references in source/config: 0
- `ProgressDbRegistry` references: only its owner file and ProgressStore
- `makeId` present in both intended import writers
- `bindNullable` present only in intended writer/state-store owners
- QBankDb obsolete bindNullable helper: removed
- Brace balance for QBankDb, ProgressStore, QBankStreamingImportSession, ProgressDbRegistry: balanced
- ZIP integrity: PASS

## Research basis

Kotlin official visibility documentation: top-level `private` declarations are visible only within their declaring file; `internal` declarations are visible within the same module.

Kotlin official package/import documentation confirms that top-level private entities cannot be imported/used from another file.

SQLite/Android database behavior should continue to be validated through the existing CI/device tests; this repair does not alter the established SQLite transaction model.

## Verification boundary

This is a source/static repair. The environment does not provide a verified Android Gradle build for this exact source. Therefore this report does NOT claim Android compilation, CI-green, APK validity, signing validation, or device PASS for v8.3.600.

The next proof gate is an exact v8.3.600 GitHub Actions run followed by inspection of the complete log.
