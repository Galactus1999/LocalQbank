# Rovex v8.3.598 — Deep Application Audit / Final QBankDb Repair

Date: 2026-10-07

## Scope
Deep static/source audit of v8.3.596 after the QBankDb extraction. Focus: lost functions, wrong links, incomplete extraction, structural abnormalities, database/search regressions, transaction failure paths, compatibility, XML integrity, and broad exception handling.

## Root causes found and repaired
1. **Malformed extracted database provider**
   - `QBankDatabaseProvider.kt` contained two package declarations and duplicated imports.
   - Removed the duplicate header.

2. **FTS false-clean state**
   - Incremental FTS finalization previously considered the index clean when live-question count matched distinct live FTS IDs, even if stale/orphan FTS rows remained.
   - Clean publication now requires total FTS row count == live question count, distinct live IDs == live question count, and zero duplicate live rows.
   - This aligns the cleanliness invariant with the actual live corpus rather than a count-only approximation.

3. **Unsafe broad exception handling around transaction acquisition**
   - `QBankStreamingImportSession` and `QBankImportWriter` caught `Throwable` only to release the write lock.
   - Narrowed these catches to `Exception`; catastrophic `Error`/OOM/LinkageError is no longer intercepted by this layer.

4. **Streaming import partial-source leak on finalization failure**
   - `HtmlImportActivity` calls `session.finish(true)` and, if that throws, subsequently calls `session.abort()`.
   - The old `finish()` closed the session in `finally`, making the subsequent `abort()` a no-op and potentially leaving a partially committed source.
   - `finish()` now performs bounded source cleanup itself when the final commit/end-transaction path throws, before closing the session.

5. **Internal test compatibility**
   - Restored `QBankDb.resetForTest(Context)` as a compatibility alias to the extracted provider, while retaining `resetDatabaseForTest(Context)`.

## Final structural results
- QBankDb: 637 lines; remains a compatibility façade/lifecycle owner rather than a second repository implementation.
- Database lifecycle/schema: `QBankDatabaseProvider`.
- Question/catalog reads: `QBankQuestionRepository`.
- Notes: `QBankNotesRepository`.
- Search reads: `QBankSearchRepository`.
- Search index policy/health/rebuild: `QBankSearchIndexCoordinator`.
- Dashboard aggregation: `QBankDashboardRepository`.
- Streaming HTML insertion session: `QBankStreamingImportSession`.
- Progress/study state: `QBankStudyStateStore` / `ProgressStore`.
- Normalized batch import: `QBankImportWriter`.
- Destructive deletion: `QBankSourceDeletionManager`.
- Shared write serialization: `QBankWriteCoordinator`.

## Static verification
- Kotlin source files: 280
- XML files: 37
- Kotlin files with duplicate package declaration: 0
- broad `catch(Throwable)` in project: 0
- XML parse errors: 0
- duplicate @+id within individual layouts: 0
- ZIP integrity: PASS
- build/APK/AAB artifacts in source ZIP: none
- applicationId: `com.localqbank.library`
- versionName: `8.3.598`
- versionCode: `684`

## Verification boundary
Android compilation was attempted with the repository Gradle wrapper but is blocked in this environment because the required Gradle distribution cannot resolve `downloads.gradle.org` (DNS failure). Therefore this source is **not claimed CI-green or device-validated**.

The next validation gate is GitHub Actions on the exact v8.3.598 source, followed by device tests for QBank import, streaming HTML import failure recovery, deletion, FTS/search, dashboard counts, progress, notes, and AI-index access.

## Research basis
Android's SQLite guidance recommends batching writes, serializing writes, pushing filtering/aggregation into SQLite, and using appropriate indexes. SQLite's foreign-key documentation recommends indexes on child-key columns for efficient parent mutation checks. These principles are preserved by the extracted architecture and shared write coordinator.
