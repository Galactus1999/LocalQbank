package com.localqbank.library

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var store: ProgressStore
    private lateinit var qs: List<Question>
    private var pos = 0
    private lateinit var title: String
    private lateinit var content: LinearLayout
    private lateinit var counter: TextView
    private lateinit var result: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = QBankDb(this)
        store = ProgressStore(this)
        title = intent.getStringExtra("title") ?: "QBank"
        qs = db.questions(intent.getStringExtra("testId") ?: "")
        pos = intent.getIntExtra("position", 0).coerceIn(0, (qs.size - 1).coerceAtLeast(0))
        setContentView(build())
        SystemUi.immersive(this)
        show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) SystemUi.immersive(this)
    }

    private fun build(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 252))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 7, 8, 7)
            setBackgroundColor(Color.rgb(22, 72, 112))
        }
        val tv = TextView(this).apply {
            text = title
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 2
        }
        top.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton("‹ Back", Color.rgb(48, 105, 151)) { finish() }, LinearLayout.LayoutParams(92, 48))
        root.addView(top)

        counter = TextView(this).apply {
            setPadding(14, 8, 14, 8)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(54, 76, 101))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(counter)

        scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setBackgroundColor(Color.WHITE)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 22)
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        result = TextView(this).apply {
            setPadding(14, 8, 14, 8)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setBackgroundColor(Color.rgb(238, 246, 251))
            visibility = View.GONE
        }
        root.addView(result)

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(7, 5, 7, 6)
            setBackgroundColor(Color.WHITE)
        }
        nav.addView(actionButton("‹ Previous", Color.rgb(77, 96, 117)) { if (pos > 0) { pos--; show() } }, LinearLayout.LayoutParams(0, 56, 1f).apply { setMargins(3, 0, 3, 0) })
        lateinit var bm: Button
        bm = actionButton("🔖 Bookmark", Color.rgb(82, 67, 137)) { showBookmarkMenu(bm) }
        nav.addView(bm, LinearLayout.LayoutParams(0, 56, 1f).apply { setMargins(3, 0, 3, 0) })
        nav.addView(actionButton("Next ›", Color.rgb(29, 132, 91)) { if (pos < qs.lastIndex) { pos++; show() } }, LinearLayout.LayoutParams(0, 56, 1f).apply { setMargins(3, 0, 3, 0) })
        root.addView(nav)
        return root
    }

    private fun actionButton(label: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setTextColor(Color.WHITE)
        background = rounded(color, 14f)
        stateListAnimator = null
        minHeight = 48
        minimumHeight = 48
        setPadding(8, 0, 8, 0)
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun optionCard(q: Question, option: Option, answered: Boolean) {
        val correct = option.correct ||
            q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
        val selected = store.selected(q.stableKey)?.equals(option.label, true) == true

        val bg = when {
            !answered -> Color.rgb(231, 241, 250)
            correct -> Color.rgb(220, 244, 228)
            selected -> Color.rgb(252, 226, 230)
            else -> Color.rgb(241, 244, 248)
        }
        val fg = when {
            !answered -> Color.rgb(18, 39, 61)
            correct -> Color.rgb(17, 91, 54)
            selected -> Color.rgb(137, 36, 52)
            else -> Color.rgb(91, 105, 121)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = 88
            setPadding(14, 10, 14, 10)
            background = rounded(bg, 18f)
            isClickable = !answered
            isFocusable = !answered
            if (!answered) setOnClickListener { answer(option.label) }
        }

        val letter = TextView(this).apply {
            text = option.label
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(if (!answered) Color.rgb(207, 224, 240) else bg, 50f)
        }
        row.addView(letter, LinearLayout.LayoutParams(54, 54).apply { setMargins(0, 0, 14, 0) })

        val text = TextView(this).apply {
            this.text = toSpanned(option.text)
            textSize = 18f
            setTextColor(fg)
            gravity = Gravity.CENTER_VERTICAL
            setLineSpacing(0f, 1.1f)
        }
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))

        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 10) })
    }

    private fun answer(label: String) {
        if (qs.isEmpty()) return
        val q = qs[pos]
        if (store.status(q.stableKey) != null) return
        val selected = q.options.firstOrNull { it.label.equals(label, true) }
        val correct = selected?.correct == true ||
            q.correctAnswer?.trim()?.equals(label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(label.trim() + ".", true) == true
        store.setAnswer(q.stableKey, label, if (correct) "correct" else "wrong")
        show()
        scroll.post { scroll.smoothScrollTo(0, 0) }
    }

    private fun show() {
        content.removeAllViews()
        if (qs.isEmpty()) {
            counter.text = "No questions imported"
            addHtmlText("<h2>No questions</h2><p>Import a QBank HTML file first.</p>", 18f)
            result.visibility = View.GONE
            return
        }
        val q = qs[pos]
        val status = store.status(q.stableKey)
        val answered = status != null
        counter.text = "Question ${pos + 1} / ${qs.size}"
        addHtmlText(q.text, 22f, true)
        q.questionImages.forEach { addImage(it) }
        q.options.forEach { optionCard(q, it, answered) }
        if (!answered) {
            // Fill the available quiz area so the pre-answer screen does not leave a large blank block.
            scroll.post { content.minimumHeight = (scroll.height - content.paddingTop - content.paddingBottom).coerceAtLeast(0) }
        } else {
            content.minimumHeight = 0
        }

        if (answered) {
            result.visibility = View.VISIBLE
            result.text = if (status == "correct") "✓ Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}" else "✗ Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}"
            result.setTextColor(if (status == "wrong") Color.rgb(150, 38, 55) else Color.rgb(31, 96, 69))
            addHtmlText("<h2>Explanation</h2>${q.explanation ?: "<p>No explanation available.</p>"}", 18f)
            q.explanationImages.forEach { addImage(it) }
        } else {
            result.visibility = View.GONE
            val hint = TextView(this).apply {
                text = "Select an option to reveal the answer and full explanation."
                textSize = 15f
                setTextColor(Color.rgb(86, 101, 121))
                setPadding(14, 14, 14, 14)
                background = rounded(Color.rgb(242, 245, 249), 16f)
            }
            content.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 10) })
        }
        scroll.post { scroll.scrollTo(0, 0) }
    }

    private fun addHtmlText(html: String?, size: Float, bold: Boolean = false, color: Int = Color.rgb(21, 38, 59)) {
        val t = TextView(this).apply {
            text = toSpanned(html ?: "")
            textSize = size
            setTextColor(color)
            setLineSpacing(0f, 1.18f)
            setPadding(0, 0, 0, 9)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun toSpanned(value: String): Spanned = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)

    private fun addImage(uri: String) {
        val image = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(0, 6, 0, 10) }
        try {
            val parsed = android.net.Uri.parse(uri)
            if (parsed.scheme == "data") {
                val comma = uri.indexOf(',')
                if (comma > 0) {
                    val data = android.util.Base64.decode(uri.substring(comma + 1), android.util.Base64.DEFAULT)
                    image.setImageBitmap(android.graphics.BitmapFactory.decodeByteArray(data, 0, data.size))
                }
            } else image.setImageURI(parsed)
            content.addView(image, LinearLayout.LayoutParams(-1, -2))
        } catch (_: Exception) { }
    }

    private fun showBookmarkMenu(anchor: View) {
        if (qs.isEmpty()) return
        val popup = PopupWindow(this).apply {
            width = (resources.displayMetrics.density * 320).toInt()
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            isOutsideTouchable = true
            elevation = resources.displayMetrics.density * 10
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            background = rounded(Color.WHITE, 20f)
        }
        val title = TextView(this).apply {
            text = "Bookmark this question"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(22, 39, 59))
            setPadding(4, 2, 4, 10)
        }
        box.addView(title, LinearLayout.LayoutParams(-1, -2))
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val items = listOf("important" to "★  Important", "revise" to "↻  Revise", "doubt" to "❔  Doubt", "favorite" to "♥  Favourite")
        items.forEachIndexed { index, pair ->
            val b = actionButton(pair.second, bookmarkColor(pair.first)) {
                store.setBookmark(qs[pos].stableKey, pair.first)
                popup.dismiss()
                show()
            }
            b.textSize = 14f
            val lp = LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(4, 4, 4, 4) }
            if (index < 2) row1.addView(b, lp) else row2.addView(b, lp)
        }
        box.addView(row1, LinearLayout.LayoutParams(-1, -2))
        box.addView(row2, LinearLayout.LayoutParams(-1, -2))
        popup.contentView = box
        popup.showAsDropDown(anchor, -218, -190)
    }

    private fun bookmarkColor(v: String) = when (v) {
        "important" -> Color.rgb(138, 90, 0)
        "revise" -> Color.rgb(37, 99, 166)
        "doubt" -> Color.rgb(122, 63, 145)
        else -> Color.rgb(177, 58, 84)
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius * resources.displayMetrics.density }
}
