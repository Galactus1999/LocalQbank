package com.localqbank.library

import android.content.Context

/**
 * Offline-only research gateway for Ben.
 *
 * This is deliberately an adapter boundary, not an AI runtime. It never opens a URL,
 * performs network I/O, or downloads a model. Until a validated LiteRT-LM backend is
 * installed, requests fall back to Rovex's existing local clinical/QBank intelligence.
 * This keeps the stability build deterministic while leaving a safe insertion point for
 * an on-device Hugging Face/LiteRT model later.
 */
class BenLocalResearchEngine(context: Context) {
    private val app = context.applicationContext

    data class Capability(
        val offlineOnly: Boolean = true,
        val modelBackendAvailable: Boolean = false,
        val groundedInLocalQBank: Boolean = true
    )

    data class Result(
        val answer: String,
        val source: String,
        val modelUsed: Boolean
    )

    fun capability(): Capability = Capability()

    fun research(query: String): Result {
        val clean = query.trim()
        if (clean.isBlank()) {
            return Result("Give Ben a clinical term, topic, question, or study task.", "local-safety", false)
        }
        val insight = runCatching {
            if (AppManagers.isReady()) AppManagers.renCognitive.answer(clean)
            else RenCognitiveEngine(app).answer(clean)
        }.getOrElse {
            RenCognitiveEngine(app).answer(clean)
        }
        return Result(insight.body, "Rovex local clinical/QBank engine", false)
    }
}
