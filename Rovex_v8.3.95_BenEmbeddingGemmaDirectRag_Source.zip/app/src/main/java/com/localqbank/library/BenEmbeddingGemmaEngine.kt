package com.localqbank.library

import android.content.Context
import com.google.ai.edge.localagents.rag.models.EmbedData
import com.google.ai.edge.localagents.rag.models.Embedder
import com.google.ai.edge.localagents.rag.models.EmbeddingRequest
import com.google.ai.edge.localagents.rag.models.GeckoEmbeddingModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Optional
import kotlin.math.max

/**
 * CPU-first EmbeddingGemma adapter using the Google AI Edge LocalAgents native embedding path.
 *
 * The class is named GeckoEmbeddingModel in the upstream SDK, but the adapter accepts a
 * user-supplied LiteRT/TFLite text-embedding graph plus its SentencePiece tokenizer. This is
 * intentionally isolated behind Ben's existing governor and deterministic fallback boundary.
 * It never owns retrieval policy or study/business logic.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)
    data class Result<T>(val hits: List<SemanticHit<T>>, val elapsedMs: Long, val usedModel: Boolean)

    suspend fun <T> rerank(query: String, candidates: List<T>, textOf: (T) -> String, limit: Int = 8): Result<T> =
        withContext(Dispatchers.IO) {
            val started = System.currentTimeMillis()
            val installed = models.installed(profile)
            val tokenizer = models.installedEmbeddingGemmaTokenizer()
            if (installed == null) {
                BenNeuralTelemetry.blocked("EmbeddingGemma 300M model is not installed")
                return@withContext fallback(candidates, limit, started)
            }
            if (tokenizer == null) {
                BenNeuralTelemetry.blocked("EmbeddingGemma tokenizer is not installed")
                return@withContext fallback(candidates, limit, started)
            }
            if (!policy.mayStartModel(profile.estimatedModelMb) || !governor.mayRun(policy, profile.estimatedRuntimeMb)) {
                BenNeuralTelemetry.blocked("EmbeddingGemma blocked by policy/resource governor")
                return@withContext fallback(candidates, limit, started)
            }
            val cleanQuery = clean(query)
            if (cleanQuery.length < 2 || candidates.isEmpty()) return@withContext fallback(candidates, limit, started)
            try {
                val embedder = createEmbedder(installed.file, tokenizer)
                try {
                    val queryVector = embed(embedder, cleanQuery, EmbedData.TaskType.RETRIEVAL_QUERY)
                    val selected = candidates.take(8)
                    val scored = selected.map { candidate ->
                        val text = clean(textOf(candidate))
                        val vector = embed(embedder, text, EmbedData.TaskType.RETRIEVAL_DOCUMENT)
                        SemanticHit(candidate, cosine(queryVector, vector))
                    }.sortedByDescending { it.similarity }.take(limit.coerceIn(1, 8))
                    policy.recordBackendSuccess()
                    Result(scored, max(0L, System.currentTimeMillis() - started), true)
                } finally { closeQuietly(embedder) }
            } catch (error: Exception) {
                BenNeuralTelemetry.error("EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
                policy.recordBackendFailure()
                fallback(candidates, limit, started)
            }
        }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile) ?: run {
            BenNeuralTelemetry.blocked("EmbeddingGemma 300M model is not installed")
            return@withContext null
        }
        val tokenizer = models.installedEmbeddingGemmaTokenizer() ?: run {
            BenNeuralTelemetry.blocked("EmbeddingGemma tokenizer is not installed")
            return@withContext null
        }
        if (!policy.mayStartModel(profile.estimatedModelMb) || !governor.mayRun(policy, profile.estimatedRuntimeMb)) return@withContext null
        try {
            val embedder = createEmbedder(installed.file, tokenizer)
            try {
                val a = embed(embedder, clean(first), EmbedData.TaskType.RETRIEVAL_QUERY)
                val b = embed(embedder, clean(second), EmbedData.TaskType.RETRIEVAL_QUERY)
                val score = cosine(a, b)
                policy.recordBackendSuccess()
                BenNeuralTelemetry.semantic(max(0L, System.currentTimeMillis() - started), true)
                score
            } finally { closeQuietly(embedder) }
        } catch (error: Exception) {
            BenNeuralTelemetry.error("EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            null
        }
    }

    private fun createEmbedder(model: File, tokenizer: File): Embedder<String> =
        GeckoEmbeddingModel(model.absolutePath, Optional.of(tokenizer.absolutePath), false)

    private suspend fun embed(embedder: Embedder<String>, text: String, task: EmbedData.TaskType): List<Float> {
        val data = EmbedData.create(text.take(1800), task)
        val request = EmbeddingRequest.create(listOf(data))
        return embedder.getEmbeddings(request).await().toList()
    }

    private fun cosine(a: List<Float>, b: List<Float>): Double {
        val n = minOf(a.size, b.size)
        if (n == 0) return 0.0
        var dot = 0.0; var aa = 0.0; var bb = 0.0
        for (i in 0 until n) { val x=a[i].toDouble(); val y=b[i].toDouble(); dot += x*y; aa += x*x; bb += y*y }
        return if (aa <= 0.0 || bb <= 0.0) 0.0 else (dot / (kotlin.math.sqrt(aa)*kotlin.math.sqrt(bb))).coerceIn(-1.0,1.0)
    }

    private fun clean(value: String) = value.replace(Regex("\\s+"), " ").trim().take(1800)

    private fun <T> fallback(candidates: List<T>, limit: Int, started: Long) =
        Result(candidates.take(limit.coerceAtLeast(0)).map { SemanticHit(it, 0.0) }, max(0L, System.currentTimeMillis()-started), false)

    private fun closeQuietly(value: Any?) { runCatching { if (value is AutoCloseable) value.close() } }
}
