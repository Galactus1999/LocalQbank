package com.localqbank.library
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin
class RovexHeaderCosmicView @JvmOverloads constructor(context:Context,attrs:AttributeSet?=null):View(context,attrs){
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG);private var t=0f;private var running=false
    override fun onAttachedToWindow(){super.onAttachedToWindow();running=true;postInvalidateOnAnimation()}
    override fun onDetachedFromWindow(){running=false;super.onDetachedFromWindow()}
    override fun onWindowVisibilityChanged(visibility:Int){super.onWindowVisibilityChanged(visibility);running=visibility==View.VISIBLE;if(running)postInvalidateOnAnimation()}
    override fun onDraw(c:Canvas){
        val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0||!running)return
        paint.style=Paint.Style.FILL;paint.color=ThemeManager.bg(context);c.drawRect(0f,0f,w,h,paint)
        val ex=w*.70f;val ey=h*.56f;val er=minOf(w,h)*.30f
        val a=ThemeManager.accent(context);val a2=ThemeManager.accent2(context);paint.shader=RadialGradient(ex-er*.35f,ey-er*.4f,er,intArrayOf(a,a2,ThemeManager.panel(context)),null,Shader.TileMode.CLAMP);c.drawCircle(ex,ey,er,paint);paint.shader=null
        paint.color=ThemeManager.accent2(context);c.drawOval(ex-er*.45f,ey-er*.15f,ex+er*.05f,ey+er*.28f,paint);c.drawOval(ex+er*.02f,ey-er*.55f,ex+er*.45f,ey-er*.05f,paint)
        t+=.04f;val sx=w*.34f;val sy=h*(.35f+.04f*sin(t));paint.color=ThemeManager.text(context)
        c.drawOval(sx-16,sy-3,sx+12,sy+5,paint);paint.color=ThemeManager.accent(context);c.drawCircle(sx-4,sy+1,2.2f,paint)
        if(running)postInvalidateOnAnimation()
    }
}
