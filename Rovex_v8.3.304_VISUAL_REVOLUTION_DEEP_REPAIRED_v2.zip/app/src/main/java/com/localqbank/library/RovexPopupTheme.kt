package com.localqbank.library

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Theme boundary for PopupWindow content; dialogs do not automatically theme popup windows. */
object RovexPopupTheme {
    private fun dp(v:Int,x:View)=(v*x.resources.displayMetrics.density).toInt().coerceAtLeast(1)
    private fun surface(x:View, top:Int, bottom:Int, radius:Int=18):GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(top,bottom)).apply {
            cornerRadius=dp(radius,x).toFloat()
            val a=ThemeManager.accent(x.context)
            setStroke(dp(1,x),Color.argb(if(ThemeManager.isDark(x.context))170 else 90,Color.red(a),Color.green(a),Color.blue(a)))
        }
    fun apply(window:PopupWindow, content:View){
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        walk(content)
    }
    private fun walk(v:View){
        val c=v.context
        when(v){
            is Button->{v.background=surface(v,ThemeManager.peacockFill(c),ThemeManager.statsFill(c),16);v.setTextColor(ThemeManager.peacockText(c));v.stateListAnimator=null;v.minHeight=dp(42,v);v.isAllCaps=false}
            is ImageButton->{v.background=surface(v,ThemeManager.elevated(c),ThemeManager.peacockFill(c),14);v.elevation=dp(3,v).toFloat()}
            is EditText->{v.background=surface(v,ThemeManager.elevated(c),ThemeManager.panel(c),14);v.setTextColor(ThemeManager.text(c));v.setHintTextColor(ThemeManager.muted(c));v.backgroundTintList=ColorStateList.valueOf(ThemeManager.accent(c))}
            is CompoundButton->{v.setTextColor(ThemeManager.text(c));v.buttonTintList=ColorStateList.valueOf(ThemeManager.accent(c))}
            is TextView->{if(!v.isClickable||v.background==null)v.setTextColor(ThemeManager.text(c));if(v.isClickable&&v.background==null){v.background=surface(v,ThemeManager.peacockFill(c),ThemeManager.statsFill(c),13);v.setTextColor(ThemeManager.peacockText(c));v.setPadding(dp(10,v),dp(6,v),dp(10,v),dp(6,v))}}
        }
        if(v.isClickable&&v.foreground==null){val a=ThemeManager.accent(c);v.foreground=RippleDrawable(ColorStateList.valueOf(Color.argb(if(ThemeManager.isDark(c))75 else 40,Color.red(a),Color.green(a),Color.blue(a))),null,null)}
        if(v is ViewGroup)for(i in 0 until v.childCount)walk(v.getChildAt(i))
    }
}
