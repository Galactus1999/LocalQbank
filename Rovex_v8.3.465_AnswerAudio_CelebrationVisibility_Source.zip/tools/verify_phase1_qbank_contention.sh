#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOAD="$ROOT/app/src/main/java/com/localqbank/library/QBankLoadingEngine.kt"
LIB="$ROOT/app/src/main/java/com/localqbank/library/MainQBankLibraryActivity.kt"
FRANK="$ROOT/app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt"
REN="$ROOT/app/src/main/java/com/localqbank/library/RenActivity.kt"
SEARCH="$ROOT/app/src/main/java/com/localqbank/library/LocalQBankSearchService.kt"
BENCH="$ROOT/benchmark/src/main/kotlin/com/localqbank/library/benchmark/ColdStartupBenchmark.kt"
fail(){ echo "FAIL: $*" >&2; exit 1; }
grep -Fq 'fun loadLibrarySources' "$LOAD" || fail 'dedicated ordered library source lane missing'
grep -Fq 'sourceExecutor.execute' "$LOAD" || fail 'library source lane is not isolated on source executor'
grep -Fq 'RovexPerformanceTrace.scoped("qbank-library-source-read")' "$LOAD" || fail 'library source timing trace missing'
grep -Fq 'RovexPerformanceTrace.scoped("qbank-library-order-read")' "$LOAD" || fail 'library order timing trace missing'
grep -Fq 'loadLibrarySources(forceRefresh = forceRefresh)' "$LIB" || fail 'QBank library still uses old callback path'
if sed -n '/private fun load(/,/^    private fun applyOrder/p' "$LIB" | grep -Fq 'PerformanceManager.submit'; then fail 'QBank library critical visibility path still depends on serialized qbank-worker'; fi
grep -Fq 'frankensteinJob?.cancel()' "$REN" || fail 'latest-request cancellation missing from Frankenstein UI'
grep -Fq '): kotlinx.coroutines.Job' "$FRANK" || fail 'Frankenstein backend does not return cancellable job'
grep -Fq 'return job' "$FRANK" || fail 'Frankenstein backend does not expose running job'
grep -Fq 'shouldContinue: () -> Boolean' "$SEARCH" || fail 'search cancellation boundary missing'
grep -Fq 'takeWhile { shouldContinue() }' "$SEARCH" || fail 'search alias fanout does not stop after cancellation'
grep -Fq 'TraceSectionMetric("Rovex.StartupCoordinator")' "$BENCH" || fail 'startup benchmark missing trace metrics'
echo 'PASS: dedicated QBank catalog lane'
echo 'PASS: QBank library no longer waits on serialized qbank-worker after source read'
echo 'PASS: Frankenstein latest-request cancellation boundary'
echo 'PASS: bounded local-search cancellation boundary'
echo 'PASS: benchmark trace instrumentation present'
