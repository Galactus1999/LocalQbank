# Rovex v8.3.460 — Phase 1 QBank Contention Root Repair

## What changed
- Removed the remaining serialized `qbank-worker` dependency from the QBank Library's critical source-catalog visibility path.
- Added dedicated ordered source loading with Perfetto/Macrobenchmark trace points.
- Added actual latest-request cancellation for Frankenstein backend Jobs; UI generation fencing remains in place.
- Added cancellation checks between bounded deterministic search alias queries.
- Added QBank Library Macrobenchmark coverage for startup, frames, memory and source/order trace sections.
- Added/updated instrumented regression coverage.

## What was deliberately not changed
- QBank schema ownership.
- QBank FTS/LIKE search semantics.
- Ben IPC transport.
- EmbeddingGemma/Gemma runtime.
- Deletion business logic.
- Celebration implementation.

## Verification status
STATIC AUDIT: PASS.
BUILD: NOT EXECUTED in the current environment.
CI: PENDING.
INSTRUMENTED TEST: PENDING for v8.3.460.
MACROBENCHMARK: PENDING.
DEVICE: PENDING.

No runtime fix is claimed until those gates produce evidence.
