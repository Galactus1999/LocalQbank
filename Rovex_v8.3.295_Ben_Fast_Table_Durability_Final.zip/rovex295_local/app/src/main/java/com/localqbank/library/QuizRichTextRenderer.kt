package com.localqbank.library

import android.text.Html
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.TextAppearanceSpan
import android.content.Context

/**
 * Dedicated imported-HTML renderer for question/option/explanation text.
 *
 * The renderer owns the theme-safety boundary so QuizActivity remains a session/controller
 * rather than accumulating HTML parsing and span-sanitization policy.
 */
internal class QuizRichTextRenderer(private val context: Context) {

    fun themeSafeSpanned(html: String, forcedColor: Int? = null): Spanned {
        val sanitized = sanitizeImportedColors(html)
        val parsed = Html.fromHtml(sanitized, Html.FROM_HTML_MODE_LEGACY)
        if (parsed !is Spannable) return parsed

        val out = SpannableString(parsed)
        sanitizeColorSpans(out)
        // Theme colour is applied by TextView.setTextColor(), never as a span.
        // Spans have higher precedence and can otherwise preserve an old/imported colour across theme changes.
        @Suppress("UNUSED_VARIABLE") val ignoredForcedColor = forcedColor
        return out
    }

    /** Remove only imported foreground/background color declarations; preserve other markup. */
    private fun sanitizeImportedColors(raw: String): String {
        var out = raw
        out = out.replace(Regex("(?is)(<font\\b[^>]*?)\\s+color\\s*=\\s*(?:\\\"[^\\\"]*\\\"|'[^']*'|[^\\s>]+)"), "$1")
        out = out.replace(Regex("(?is)(<[^>]+?)\\s+(?:color|bgcolor)\\s*=\\s*(?:\\\"[^\\\"]*\\\"|'[^']*'|[^\\s>]+)"), "$1")
        out = out.replace(Regex("(?is)(<[^>]+?\\s+style\\s*=\\s*['\\\"])(.*?)(['\\\"][^>]*>)")) { m ->
            var style = m.groupValues[2]
            style = style.replace(Regex("(?i)(?:^|;)\\s*(?:color|background-color|background|text-color)\\s*:[^;]+;?"), ";")
            val normalized = style.trim().trim(';').trim()
            if (normalized.isBlank()) "${m.groupValues[1]}${m.groupValues[3]}"
            else "${m.groupValues[1]}$normalized${m.groupValues[3]}"
        }
        return out
    }

    /**
     * Android Html.fromHtml() can represent HTML colours as ForegroundColorSpan or
     * TextAppearanceSpan. Both override a TextView's base textColor, so remove them
     * centrally while retaining bold/italic/underline/size/typeface spans.
     */
    internal fun sanitizeColorSpans(out: Spannable) {
        out.getSpans(0, out.length, ForegroundColorSpan::class.java).forEach(out::removeSpan)
        out.getSpans(0, out.length, BackgroundColorSpan::class.java).forEach(out::removeSpan)
        out.getSpans(0, out.length, TextAppearanceSpan::class.java).forEach { span ->
            val start = out.getSpanStart(span)
            val end = out.getSpanEnd(span)
            val flags = out.getSpanFlags(span)
            out.removeSpan(span)
            if (start >= 0 && end > start) {
                out.setSpan(TextAppearanceSpan(span.family, span.textStyle, span.textSize, null, null), start, end, flags)
            }
        }
        // Defensive postcondition: no parser-created foreground/background span may survive.
        out.getSpans(0, out.length, ForegroundColorSpan::class.java).forEach(out::removeSpan)
        out.getSpans(0, out.length, BackgroundColorSpan::class.java).forEach(out::removeSpan)
    }

    fun toSpanned(html: String): Spanned {
        return themeSafeSpanned(html)
    }

    fun optionSpanned(html: String, color: Int): Spanned {
        return themeSafeSpanned(html, color)
    }
}
