package com.localqbank.library

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class QBankStreamingImportSessionSourceRegressionTest {
    @Test
    fun extractedStreamingSessionRetainsRequiredHelpers() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/QBankStreamingImportSession.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/QBankStreamingImportSession.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText() ?: ""
        assertTrue(
            "QBankStreamingImportSession.kt must retain its extracted bindNullable helper",
            source != null && source.contains(
                "private fun bindNullable(\n        statement: android.database.sqlite.SQLiteStatement"
            )
        )
        assertTrue(
            "QBankStreamingImportSession.kt must retain its extracted makeId helper",
            source != null && source.contains(
                "private fun makeId(file: String, original: String, index: Int): String"
            )
        )
    }
    @Test
    fun largeHtmlImportPreflightsQuestionsBeforeReplacingDatabaseSource() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/HtmlImportActivity.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/HtmlImportActivity.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText().orEmpty()
        val preflight = source.indexOf("val validatedCount = LargeHtmlScanner(tmp)")
        val replacement = source.indexOf("repository.beginStreamingImport(", preflight.coerceAtLeast(0))
        assertTrue("large HTML scan must preflight before beginStreamingImport deletes/replaces the old source", preflight >= 0 && replacement > preflight)
        assertTrue("zero-question preflight must fail with a clear error", source.contains("No valid questions were detected in this large HTML file"))
    }

    @Test
    fun streamingSessionRejectsZeroQuestionFinish() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/QBankStreamingImportSession.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/QBankStreamingImportSession.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText().orEmpty()
        assertTrue("streaming session must refuse empty imports", source.contains("if (total <= 0)" ) && source.contains("Refusing to finish an empty QBank import"))
    }

}
