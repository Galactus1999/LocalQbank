# Rovex v8.2.7 Release Audit

- Package ID unchanged: `com.localqbank.library` (update-over-existing-install).
- Version: `8.2.7`, versionCode `95`.
- Fixed CI-blocking XML mismatch in `activity_main.xml`: `RovexFlowBorderLayout` now has its matching closing tag.
- Parsed all 23 Android resource XML files successfully.
- Ran findViewById/XML type compatibility audit; no mismatches found.
- Checked for unsafe PRAGMA via execSQL, global native auto-size typography, and removed automatic wrong-question flashcard path; none found.
- CI Gradle build must be run by GitHub Actions. Local environment cannot download Gradle 8.11.1 because external DNS/network is unavailable.
