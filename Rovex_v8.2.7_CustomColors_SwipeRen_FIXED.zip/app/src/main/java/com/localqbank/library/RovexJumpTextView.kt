package com.localqbank.library

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.widget.TextView
import kotlin.math.sin

/** Ren wordmark: letters rise sequentially while retaining the normal TextView contract. */
class RovexJumpTextView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : TextView(context, attrs) {
    private var phase = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() { super.onAttachedToWindow(); start() }
    override fun onDetachedFromWindow() { animator?.cancel(); animator = null; super.onDetachedFromWindow() }

    private fun start() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800L; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val value = text?.toString().orEmpty()
        if (value.isEmpty()) return super.onDraw(canvas)
        val p = Paint(paint).apply { shader = null }
        val total = p.measureText(value)
        var x = (width - total) / 2f
        val baseline = (height - (p.ascent() + p.descent())) / 2f
        value.forEachIndexed { i, ch ->
            val center = (phase * value.length + i) % value.length
            val distance = minOf(center, value.length - center)
            val jump = if (distance < 1f) sin((1f - distance) * Math.PI).toFloat() * dp(5f) else 0f
            canvas.drawText(ch.toString(), x, baseline - jump, p)
            x += p.measureText(ch.toString())
        }
    }
    private fun dp(v: Float) = v * resources.displayMetrics.density
}
