package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/** Compact rainbow spectrum line used by Rovex's colour popup. */
class RovexColorSpectrumView(context: Context) : View(context) {
    var color: Int = Color.RED
        set(value) { field = value; invalidate() }
    var onColorChanged: ((Int) -> Unit)? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hueColors = intArrayOf(
        Color.RED, Color.MAGENTA, Color.BLUE, Color.CYAN, Color.GREEN, Color.YELLOW, Color.RED
    )
    init { isClickable = true; minimumHeight = dp(34f).toInt() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = dp(4f); val right = width - dp(4f); val cy = height / 2f
        paint.shader = LinearGradient(left, cy, right, cy, hueColors, null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(left, cy-dp(7f), right, cy+dp(7f), dp(7f), dp(7f), paint)
        paint.shader = null
        val hsv = FloatArray(3); Color.colorToHSV(color, hsv)
        val x = left + (hsv[0] / 360f) * (right-left)
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE
        canvas.drawCircle(x, cy, dp(10f), paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2f); paint.color = Color.BLACK
        canvas.drawCircle(x, cy, dp(10f), paint)
        paint.style = Paint.Style.FILL
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_UP) {
            val left = dp(4f); val right = width - dp(4f)
            val hue = (((event.x.coerceIn(left,right)-left)/(right-left))*360f).coerceIn(0f,360f)
            color = Color.HSVToColor(floatArrayOf(hue,1f,1f)); onColorChanged?.invoke(color)
            return true
        }
        return true
    }
    private fun dp(v:Float)=v*resources.displayMetrics.density
}
