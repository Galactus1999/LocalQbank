package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Permanent, exportable diagnostics surface for Ben and future Rovex performance tests. */
class RovexDiagnosticsDataCenter : AppCompatActivity() {
    private lateinit var reportView: TextView
    private lateinit var summaryView: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        setContentView(build())
    }

    private fun build(): ScrollView {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(28)); setBackgroundColor(ThemeManager.bg(this@RovexDiagnosticsDataCenter)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply { text = "‹"; textSize = 32f; gravity = Gravity.CENTER; setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter)); setOnClickListener { finish() } }, LinearLayout.LayoutParams(dp(42), dp(48)))
        header.addView(TextView(this).apply { text = "Rovex Test & Diagnostics Center"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter)); setPadding(dp(6), 0, 0, 0) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(header)
        root.addView(label("One permanent window for reproducible model, IPC, resource, Graph-RAG and import measurements."), lpWrap(0, 10))

        val summary = card(); summary.addView(title("CURRENT SNAPSHOT")); summaryView = label(""); summary.addView(summaryView); root.addView(summary, cardLp(0, 10))
        val actions = card(); actions.addView(title("EMBEDDINGGEMMA CONTRACT + NPU TEST"))
        actions.addView(label("Runs the existing non-destructive diagnostic path: artifact identity, tokenizer, tensor contract, backend/QNN, latency, semantic separation, RAM and thermal gates."), lpWrap(0, 6))
        actions.addView(button("RUN FULL EMBEDDINGGEMMA TEST") { runEmbeddingDiagnostic() }, lp(0, 8))
        actions.addView(button("REFRESH SNAPSHOT") { refreshSnapshot() }, lp(0, 4))
        actions.addView(button("SHARE COMPLETE DIAGNOSTICS") { shareDiagnostics() }, lp(0, 4))
        root.addView(actions, cardLp(0, 10))

        val report = card(); report.addView(title("LATEST TEST REPORT")); reportView = label("No test has been run in this session. The latest published report will appear here."); reportView.textSize = 12f; reportView.setTextIsSelectable(true); report.addView(reportView, lpWrap(0, 6)); root.addView(report, cardLp(0, 10))
        val telemetry = card(); telemetry.addView(title("LIVE TELEMETRY")); telemetry.addView(label(telemetryText())); root.addView(telemetry, cardLp(0, 10))
        refreshSnapshot()
        return ScrollView(this).apply { addView(root); isFillViewport = true }
    }

    private fun runEmbeddingDiagnostic() {
        reportView.text = "Running EmbeddingGemma diagnostic…"
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching { BenInferenceProcessClient(this@RovexDiagnosticsDataCenter).use { it.diagnosticSuspend() } }
            withContext(Dispatchers.Main) {
                reportView.text = result.getOrNull() ?: "Diagnostic failed: ${result.exceptionOrNull()?.message ?: "no report returned"}"
                refreshSnapshot()
            }
        }
    }

    private fun refreshSnapshot() {
        if (!::summaryView.isInitialized) return
        val t = BenNeuralTelemetry.snapshot()
        val g = BenAiResourceGovernor(this).snapshot(true)
        summaryView.text = "Stage: ${t.stage.name}\nModel: ${t.activeModel}\nLast latency: ${t.lastElapsedMs} ms\nConfidence: ${t.lastConfidence}%\nEvidence: ${t.lastEvidenceCount}\nVerified: ${if (t.lastVerified) "YES" else "NO"}\nRAM: ${g.availableMemoryMb} MB\nThermal: ${g.thermalStatus}\nPower-save: ${if (g.powerSave) "ON" else "OFF"}"
    }

    private fun telemetryText(): String {
        val t = BenNeuralTelemetry.snapshot()
        return "Requests ${t.totalRequests} • neural ${t.neuralRequests} • fallback ${t.fallbackRequests} • blocked ${t.blockedRequests}\nSemantic runs ${t.semanticRuns} • generation runs ${t.generationRuns}\nLast error: ${t.lastError ?: "None"}"
    }

    private fun shareDiagnostics() {
        val t = BenNeuralTelemetry.snapshot()
        val gov = BenAiResourceGovernor(this).snapshot(true)
        val lines = linkedMapOf<String, String>()
        lines["exportedAt"] = System.currentTimeMillis().toString()
        lines["stage"] = t.stage.name
        lines["stageDetail"] = t.stageDetail
        lines["activeModel"] = t.activeModel
        lines["modelKind"] = t.modelKind
        lines["lastLatencyMs"] = t.lastElapsedMs.toString()
        lines["lastSemanticMs"] = t.lastSemanticMs.toString()
        lines["lastGenerationMs"] = t.lastGenerationMs.toString()
        lines["evidenceCount"] = t.lastEvidenceCount.toString()
        lines["verified"] = t.lastVerified.toString()
        lines["confidence"] = t.lastConfidence.toString()
        lines["criticalClaimsChecked"] = t.lastCriticalClaimsChecked.toString()
        lines["criticalClaimsSupported"] = t.lastCriticalClaimsSupported.toString()
        lines["citationValid"] = t.lastCitationValid.toString()
        lines["neuralAccepted"] = t.lastNeuralAccepted.toString()
        lines["fallbackReason"] = t.lastFallbackReason ?: ""
        lines["totalRequests"] = t.totalRequests.toString()
        lines["neuralRequests"] = t.neuralRequests.toString()
        lines["fallbackRequests"] = t.fallbackRequests.toString()
        lines["blockedRequests"] = t.blockedRequests.toString()
        lines["semanticRuns"] = t.semanticRuns.toString()
        lines["generationRuns"] = t.generationRuns.toString()
        lines["ramAvailableMb"] = gov.availableMemoryMb.toString()
        lines["thermalStatus"] = gov.thermalStatus.toString()
        lines["powerSave"] = gov.powerSave.toString()
        lines["lastError"] = t.lastError ?: ""
        lines["lastDiagnosticReport"] = t.lastDiagnosticReport ?: ""
        val text = buildString { lines.forEach { (k, v) -> append(k).append('=').append(v.replace("\n", "\\n")).append('\n') } }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Rovex diagnostics"); putExtra(Intent.EXTRA_TEXT, text) }, "Share Rovex diagnostics"))
    }

    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(ThemeManager.elevated(this@RovexDiagnosticsDataCenter), 18) }
    private fun title(t: String) = TextView(this).apply { text = t; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter)) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 12f; setTextColor(ThemeManager.muted(this@RovexDiagnosticsDataCenter)) }
    private fun button(t: String, click: () -> Unit) = TextView(this).apply { text = t; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(ThemeManager.accent(this@RovexDiagnosticsDataCenter), 13); setOnClickListener { click() } }
    private fun lp(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun lpWrap(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun cardLp(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
}
