package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

/** Lightweight sinking ocean-liner animation with visible bubbles. */
class RovexHeaderTitanicView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var started = 0L
    private var running = false
    private val cycle = 8200L
    override fun onAttachedToWindow(){super.onAttachedToWindow();started=SystemClock.uptimeMillis();running=true;postInvalidateOnAnimation()}
    override fun onDetachedFromWindow(){running=false;super.onDetachedFromWindow()}
    override fun onWindowVisibilityChanged(visibility:Int){super.onWindowVisibilityChanged(visibility);running=visibility==View.VISIBLE;if(running)postInvalidateOnAnimation()}
    override fun onDraw(c:Canvas){
        val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0||!running)return
        val d=resources.displayMetrics.density
        val t=((SystemClock.uptimeMillis()-started)%cycle).toFloat()/cycle
        val sink=(t*1.12f).coerceAtMost(1f)
        val x=w*(.72f-.25f*t)
        val y=h*(.38f+.42f*sink)+sin(t*6.28f).toFloat()*d
        p.style=Paint.Style.STROKE;p.strokeWidth=1.3f*d;p.color=if(ThemeManager.isDark(context))0x8874C9FF.toInt() else 0x66447EA1
        for(i in 0..4){val bx=x+(-26+i*12)*d;val by=h*(.83f-i*.10f);c.drawCircle(bx,by,(2f+i*.5f)*d,p)}
        p.style=Paint.Style.FILL;c.save();c.translate(x,y);c.rotate(-18f*sink);c.scale(d,d)
        p.color=if(ThemeManager.isDark(context))0xFFE8EDF2.toInt() else 0xFF465764.toInt();c.drawRoundRect(-28f,-5f,30f,5f,3f,3f,p)
        p.color=if(ThemeManager.isDark(context))0xFFFFC56E.toInt() else 0xFF9D5D2E.toInt();c.drawRect(-23f,5f,24f,8f,p)
        p.color=if(ThemeManager.isDark(context))0xFFF7F7F4.toInt() else 0xFFEFE6D8.toInt();c.drawRect(-16f,-12f,17f,-5f,p)
        p.color=if(ThemeManager.isDark(context))0xFFD65B5B.toInt() else 0xFF8C3B2C.toInt();for(i in -1..1)c.drawRect((i*12-2).toFloat(),-19f,(i*12+2).toFloat(),-12f,p)
        c.restore();postInvalidateOnAnimation()
    }
}
