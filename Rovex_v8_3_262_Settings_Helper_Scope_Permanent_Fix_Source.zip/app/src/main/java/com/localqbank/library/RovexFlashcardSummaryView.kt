package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.roundToInt
import kotlin.math.sin

/** Compact animated SRS dashboard with a card-stack visual and explicit progress scale. */
class RovexFlashcardSummaryView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var cards=0; private var due=0; private var reviews=0; private var running=false; private var started=0L
    fun setStats(cards:Int,due:Int,reviews:Int){this.cards=cards.coerceAtLeast(0);this.due=due.coerceAtLeast(0);this.reviews=reviews.coerceAtLeast(0);invalidate()}
    override fun onAttachedToWindow(){super.onAttachedToWindow();running=true;started=SystemClock.uptimeMillis();postInvalidateOnAnimation()}
    override fun onDetachedFromWindow(){running=false;super.onDetachedFromWindow()}
    override fun onWindowVisibilityChanged(visibility:Int){super.onWindowVisibilityChanged(visibility);running=visibility==View.VISIBLE;if(running)postInvalidateOnAnimation()}
    override fun onDraw(c:Canvas){
        super.onDraw(c);val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0||!running)return
        val d=resources.displayMetrics.density;val dark=ThemeManager.isDark(context);val accent=ThemeManager.accent(context)
        val pulse=((sin((SystemClock.uptimeMillis()-started)/700.0)+1)/2).toFloat()
        p.style=Paint.Style.FILL
        p.color=if(dark)0xFF152431.toInt() else 0xFFF1F5F6.toInt();c.drawRoundRect(3*d,3*d,w-3*d,h-3*d,16*d,16*d,p)
        // layered cards
        for(i in 0..2){p.color=if(dark)0xFF243848.toInt() else 0xFFE0E8EA.toInt();val y=(12+i*5)*d;c.save();c.rotate((i-1)*3f,w*.52f,y+24*d);c.drawRoundRect(13*d,y,w-13*d,y+44*d,7*d,7*d,p);c.restore()}
        p.color=if(dark)0xFFEEF6FA.toInt() else 0xFFFFFFFF.toInt();c.drawRoundRect(11*d,10*d,w-11*d,54*d,8*d,8*d,p)
        p.color=accent;p.textSize=8.5f*d;p.isFakeBoldText=true;c.drawText("FLASHCARDS",17*d,23*d,p)
        p.color=if(dark)0xFFEAF0F4.toInt() else 0xFF263C46.toInt();p.textSize=17*d;c.drawText(cards.toString(),17*d,43*d,p)
        p.isFakeBoldText=false;p.textSize=7*d;c.drawText("CARDS",40*d,43*d,p)
        val denominator=maxOf(cards,1);val pct=((reviews.toFloat()/denominator)*100f).roundToInt().coerceIn(0,100)
        p.color=if(dark)0xFF344B59.toInt() else 0xFFD5E1E5.toInt();c.drawRoundRect(12*d,61*d,w-12*d,67*d,3*d,3*d,p)
        p.color=accent;c.drawRoundRect(12*d,61*d,12*d+(w-24*d)*(pct/100f),67*d,3*d,3*d,p)
        p.color=if(dark)0xFFAFC0CA.toInt() else 0xFF62747D.toInt();p.textSize=7.5f*d;c.drawText("$pct% reviewed",13*d,80*d,p)
        p.color=if(due>0)0xFFD65F5F.toInt() else 0xFF36B77C.toInt();p.isFakeBoldText=true;c.drawText(if(due>0)"$due DUE" else "UP TO DATE",13*d,91*d,p)
        p.isFakeBoldText=false;p.color=accent;c.drawCircle(w-13*d,13*d,(2f+1.5f*pulse)*d,p)
        if(running)postInvalidateOnAnimation()
    }
}
