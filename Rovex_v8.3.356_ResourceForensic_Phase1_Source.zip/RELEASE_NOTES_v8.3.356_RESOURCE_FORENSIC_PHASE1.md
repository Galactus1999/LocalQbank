# Rovex v8.3.356 — Resource Forensic Stability Phase 1

- versionName: 8.3.356
- versionCode: 449
- baseline: v8.3.355 / versionCode 448

## Objective
Begin the next stability phase after the QBank deletion ANR investigation. This release adds low-overhead forensic performance instrumentation without introducing a new scheduler, database owner, or business-logic layer.

## Changes
- Added `RovexPerformanceTrace` for slow-operation diagnostics.
- Captures elapsed wall time, per-thread CPU time, Java heap usage, native heap usage, available RAM/low-memory state, and Android thermal status for operations that exceed the 150 ms diagnostic threshold.
- Added Android `Trace` sections so supported system profiling can identify Rovex background-task boundaries.
- Wrapped existing `PerformanceManager` background work and the serialized QBank deletion worker with the diagnostic tracer.
- No database schema changes.
- No change to QBank deletion ownership or authoritative manager ownership.
- Existing WAL, battery policy, adaptive safe mode, inference isolation, and deterministic fallback remain intact.

## Stability intent
The instrumentation is deliberately observational. It must not block foreground study, change scheduling policy, or create a second resource governor. The resulting device log captures can identify which existing workloads actually consume CPU/RAM/time before behavioral optimization is applied.

## Verification
- Baseline preserved from v8.3.355.
- versionCode incremented monotonically to 449.
- Source/static audits required before CI.
- Local full Android Gradle compilation remains subject to the environment's Gradle distribution DNS limitation; CI is authoritative.
