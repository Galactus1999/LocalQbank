package com.localqbank.library

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import android.os.SystemClock
import android.os.Trace
import android.util.Log

/**
 * Low-overhead forensic performance tracing.
 *
 * This is diagnostic instrumentation only: it does not schedule work, change database policy,
 * or own any business logic. Slow background operations are logged with elapsed time and memory
 * pressure so device captures can identify the actual workload instead of relying on guesses.
 */
object RovexPerformanceTrace {
    private const val TAG = "RovexPerf"
    private const val SLOW_MS = 150L

    data class Snapshot(
        val elapsedMs: Long,
        val javaHeapMb: Long,
        val javaHeapLimitMb: Long,
        val nativeHeapMb: Long,
        val availableRamMb: Long,
        val lowMemory: Boolean,
        val thermalStatus: Int,
    )

    inline fun <T> scoped(name: String, block: () -> T): T {
        val context = runCatching { RovexApplicationContextHolder.context }.getOrNull()
        val start = SystemClock.elapsedRealtime()
        val startCpu = Debug.threadCpuTimeNanos()
        Trace.beginSection("Rovex:$name")
        return try {
            block()
        } finally {
            Trace.endSection()
            val elapsed = SystemClock.elapsedRealtime() - start
            if (elapsed >= SLOW_MS) {
                val snapshot = snapshot(context, elapsed, startCpu)
                Log.i(TAG, "$name ${snapshot.elapsedMs}ms cpu=${cpuMs(startCpu)}ms " +
                    "heap=${snapshot.javaHeapMb}/${snapshot.javaHeapLimitMb}MB " +
                    "native=${snapshot.nativeHeapMb}MB " +
                    "ramAvail=${snapshot.availableRamMb}MB low=${snapshot.lowMemory} " +
                    "thermal=${snapshot.thermalStatus}")
            }
        }
    }

    fun snapshot(context: Context?, elapsedMs: Long = 0L, startCpuNanos: Long = 0L): Snapshot {
        val runtime = Runtime.getRuntime()
        val appContext = context?.applicationContext
        val am = appContext?.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val info = ActivityManager.MemoryInfo()
        runCatching { am?.getMemoryInfo(info) }
        val power = appContext?.getSystemService(android.os.PowerManager::class.java)
        val thermal = if (android.os.Build.VERSION.SDK_INT >= 29) {
            runCatching { power?.currentThermalStatus ?: 0 }.getOrDefault(0)
        } else 0
        return Snapshot(
            elapsedMs = elapsedMs,
            javaHeapMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L),
            javaHeapLimitMb = runtime.maxMemory() / (1024L * 1024L),
            nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024L * 1024L),
            availableRamMb = info.availMem / (1024L * 1024L),
            lowMemory = info.lowMemory,
            thermalStatus = thermal,
        )
    }

    private fun cpuMs(startNanos: Long): Long =
        if (startNanos <= 0L) 0L else (Debug.threadCpuTimeNanos() - startNanos) / 1_000_000L
}
