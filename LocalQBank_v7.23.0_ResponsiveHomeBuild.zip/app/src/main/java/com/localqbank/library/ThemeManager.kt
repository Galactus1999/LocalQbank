package com.localqbank.library

import android.content.Context
import android.graphics.Color

object ThemeManager {
    const val LIGHT="light"; const val DARK="dark"; const val SEPIA="sepia"
    const val AMOLED="amoled"; const val MIDNIGHT="midnight"
    fun get(c:Context)=c.getSharedPreferences("ui",Context.MODE_PRIVATE).getString("theme",LIGHT)?:LIGHT
    fun set(c:Context,v:String){c.getSharedPreferences("ui",Context.MODE_PRIVATE).edit().putString("theme",v).apply()}
    fun isDark(c:Context)=get(c) in setOf(DARK,AMOLED,MIDNIGHT)
    fun bg(c:Context)=when(get(c)){AMOLED->Color.BLACK;MIDNIGHT->Color.rgb(7,14,28);DARK->Color.rgb(9,13,18);SEPIA->Color.rgb(246,239,218);else->Color.rgb(247,249,246)}
    fun panel(c:Context)=when(get(c)){AMOLED->Color.rgb(8,8,8);MIDNIGHT->Color.rgb(13,24,43);DARK->Color.rgb(17,23,30);SEPIA->Color.rgb(251,245,227);else->Color.rgb(251,253,250)}
    fun elevated(c:Context)=when(get(c)){AMOLED->Color.rgb(18,18,18);MIDNIGHT->Color.rgb(19,33,55);DARK->Color.rgb(24,32,42);SEPIA->Color.rgb(255,248,231);else->Color.WHITE}
    fun text(c:Context)=when(get(c)){AMOLED->Color.rgb(245,245,245);MIDNIGHT->Color.rgb(235,242,255);DARK->Color.rgb(235,240,247);SEPIA->Color.rgb(70,57,39);else->Color.rgb(21,38,59)}
    fun muted(c:Context)=when(get(c)){AMOLED->Color.rgb(170,170,170);MIDNIGHT->Color.rgb(169,190,219);DARK->Color.rgb(176,188,202);SEPIA->Color.rgb(111,94,69);else->Color.rgb(80,94,110)}
    fun accent(c:Context)=when(get(c)){AMOLED->Color.rgb(112,190,255);MIDNIGHT->Color.rgb(126,181,255);DARK->Color.rgb(157,194,255);SEPIA->Color.rgb(91,74,45);else->Color.rgb(24,91,130)}
    fun optionBg(c:Context)=when(get(c)){AMOLED->Color.rgb(20,20,20);MIDNIGHT->Color.rgb(20,37,61);DARK->Color.rgb(27,37,49);SEPIA->Color.rgb(250,243,223);else->Color.rgb(232,242,251)}
    fun optionText(c:Context)=when(get(c)){AMOLED->Color.rgb(240,240,240);MIDNIGHT->Color.rgb(231,240,255);DARK->Color.rgb(232,239,248);SEPIA->Color.rgb(68,54,36);else->Color.rgb(18,39,61)}
    fun correctBg(c:Context)=when(get(c)){AMOLED->Color.rgb(14,45,27);MIDNIGHT->Color.rgb(17,55,52);DARK->Color.rgb(28,52,76);SEPIA->Color.rgb(224,239,220);else->Color.rgb(220,244,228)}
    fun correctText(c:Context)=when(get(c)){AMOLED->Color.rgb(130,235,160);MIDNIGHT->Color.rgb(137,230,214);DARK->Color.rgb(178,218,255);SEPIA->Color.rgb(35,91,54);else->Color.rgb(17,91,54)}
    fun wrongBg(c:Context)=when(get(c)){AMOLED->Color.rgb(55,17,24);MIDNIGHT->Color.rgb(62,24,38);DARK->Color.rgb(67,29,38);SEPIA->Color.rgb(247,225,225);else->Color.rgb(252,226,230)}
    fun wrongText(c:Context)=when(get(c)){AMOLED->Color.rgb(255,145,165);MIDNIGHT->Color.rgb(255,158,185);DARK->Color.rgb(255,190,201);SEPIA->Color.rgb(120,38,52);else->Color.rgb(137,36,52)}
    fun explanationBg(c:Context)=when(get(c)){AMOLED->Color.rgb(13,13,13);MIDNIGHT->Color.rgb(16,29,48);DARK->Color.rgb(24,33,44);SEPIA->Color.rgb(237,225,199);else->Color.rgb(232,244,252)}
    fun explanationTitle(c:Context)=when(get(c)){AMOLED->Color.rgb(126,205,255);MIDNIGHT->Color.rgb(144,201,255);DARK->Color.rgb(164,207,255);SEPIA->Color.rgb(76,62,42);else->Color.rgb(35,91,125)}
    fun dialogBg(c:Context)=if(isDark(c)) elevated(c) else Color.WHITE
    fun dialogText(c:Context)=text(c)
    fun dialogMuted(c:Context)=muted(c)
    fun resultBg(c:Context)=when(get(c)){AMOLED->Color.rgb(14,45,27);MIDNIGHT->Color.rgb(17,55,52);DARK->Color.rgb(28,52,76);SEPIA->Color.rgb(237,225,199);else->Color.rgb(238,246,251)}
    fun bookmarkFill(c:Context,type:String):Int=if(isDark(c))when(type.lowercase()){"important"->Color.rgb(61,48,12);"revise"->Color.rgb(18,48,78);"doubt"->Color.rgb(42,47,55);"favorite","favourite"->Color.rgb(70,27,39);else->Color.rgb(35,43,52)} else when(type.lowercase()){"important"->Color.rgb(255,238,184);"revise"->Color.rgb(216,235,255);"doubt"->Color.rgb(232,237,241);"favorite","favourite"->Color.rgb(255,221,229);else->Color.rgb(232,239,244)}
    fun bookmarkText(c:Context,type:String):Int=if(isDark(c))when(type.lowercase()){"important"->Color.rgb(255,219,105);"revise"->Color.rgb(151,211,255);"doubt"->Color.rgb(210,218,228);"favorite","favourite"->Color.rgb(255,171,190);else->Color.rgb(225,233,242)} else when(type.lowercase()){"important"->Color.rgb(105,72,0);"revise"->Color.rgb(18,78,135);"doubt"->Color.rgb(52,64,78);"favorite","favourite"->Color.rgb(139,38,65);else->Color.rgb(35,52,70)}
}
