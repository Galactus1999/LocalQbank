package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexRichRendererTest {
    @Test fun labeledMermaidFlowchartRendersAsDiagram() {
        val markdown = """
            ## Decision flow

            ```mermaid
            flowchart TD
              A[Patient presents with cystocele] --> B{Stage of prolapse?}
              B -->|I-II| C[Conservative: PT + pessary]
              B -->|III-IV| D[Conservative trial + consider surgery]
              D --> E{Symptomatic?}
              E -->|Yes| F[Continue pessary & PT]
              E -->|No| G[Follow-up; consider surgery if symptoms develop]
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Patient presents with cystocele"))
        assertTrue(html.contains("I-II"))
        assertFalse(html.contains("```mermaid"))
    }

    @Test fun mermaidFlowchartWithDecisionBracesRendersAfterPolicy() {
        val raw = BenResponsePolicy.normalize("""## Decision flow

```mermaid
flowchart TD
A[Patient presents] --> B{Stage?}
B -->|I-II| C[Conservative]
B -->|III-IV| D[Consider surgery]
```""")!!
        val html = rovexMarkdownToHtml(raw, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Stage?"))
        assertTrue(html.contains("Conservative"))
        assertFalse(html.contains("```mermaid"))
    }

    @Test fun collapsedAiResponseWithTableAndMermaidIsRecoveredEndToEnd() {
        val raw = """## Antagonism

Mechanism summary | Drug | Effect | | --- | --- | | Atropine | M1 blockade |

#### Mermaid: M1 Antagonism → EPS Mitigation
mermaid flowchart TD M1[M1 Receptor] -->|Gq| PLC[PLC] PLC --> IP3[IP3]"""
        val normalized = BenResponsePolicy.normalize(raw)!!
        val html = rovexMarkdownToHtml(normalized, true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("Atropine"))
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("M1 Receptor"))
        assertFalse(html.contains("mermaid flowchart TD"))
        assertFalse(html.contains("| --- | --- |"))
    }

    @Test fun unsafeHtmlAndEventHandlersDoNotReachChatHtml() {
        val normalized = BenResponsePolicy.normalize("<script>alert(1)</script><img src=\"https://example.com/a.png\" onerror=\"alert(1)\">")!!
        val html = rovexMarkdownToHtml(normalized, true)
        assertFalse(html.contains("<script", ignoreCase = true))
        assertFalse(html.contains("onerror", ignoreCase = true))
    }

    @Test fun twoBacktickProviderFenceIsRecovered() {
        val markdown = """
            Text before

            `` mermaid
            flowchart LR
              A[Start] -->|yes| B[Finish]
            ``

            Text after
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Start"))
        assertFalse(html.contains("`` mermaid"))
    }

    @Test fun sequenceDiagramDoesNotBecomeRawSource() {
        val markdown = """
            ```mermaid
            sequenceDiagram
              participant A as Doctor
              participant B as Patient
              A->>B: Explain diagnosis
              B-->>A: Ask question
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Doctor"))
        assertTrue(html.contains("Explain diagnosis"))
    }

    @Test fun stateDiagramDoesNotBreakNormalChat() {
        val markdown = """
            ```mermaid
            stateDiagram-v2
              [*] --> Idle
              Idle --> Processing : start
              Processing --> Done : complete
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Processing"))
    }

    @Test fun malformedDiagramFallsBackWithoutThrowing() {
        val html = rovexMarkdownToHtml(
            "```mermaid\nthis is not valid mermaid and should remain readable\n```",
            true
        )
        assertTrue(html.contains("rich-mermaid-fragment"))
        assertTrue(html.contains("this is not valid mermaid"))
    }
    @Test fun appendedHeadingAndThematicBreakBecomeBlocks() {
        val html = rovexMarkdownToHtml("Children may need special care. --- ### 2. Insomnia Associated with Medical Conditions\n\nCondition | Age\n--- | ---\nOSA | All ages", true)
        assertTrue(html.contains("<hr"))
        assertTrue(html.contains("<h3>2. Insomnia Associated with Medical Conditions</h3>"))
        assertTrue(html.contains("<table>"))
        assertFalse(html.contains("<p>Children may need special care. <hr>"))
    }

    @Test fun normalSoftBreaksStayInsideOneParagraph() {
        val html = rovexMarkdownToHtml("First sentence.\nSecond sentence.\nThird sentence.", true)
        assertTrue(html.contains("<p>First sentence.") && html.contains("Second sentence.") && html.contains("Third sentence.</p>"))
        assertFalse(html.contains("First sentence.<br>Second"))
    }

    @Test fun adjacentListItemsBecomeSemanticList() {
        val html = rovexMarkdownToHtml("- One\n- Two\n- Three", true)
        assertTrue(html.contains("<ul>"))
        assertTrue(html.contains("<li>One</li>"))
        assertTrue(html.contains("<li>Two</li>"))
        assertTrue(html.contains("<li>Three</li>"))
    }

    @Test fun collapsedDistractorTableIsRecoveredWithoutPipeSource() {
        val markdown = "9. Close distractors & why they’re wrong | Distractor | Why it’s incorrect | |-------------|-------------------| “HPV 16 is the only HPV type that causes cervical cancer.” | HPV 18 also accounts for a significant proportion of cases (Q1). |"
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("HPV 16 is the only HPV type"))
        assertFalse(html.contains("|-------------|-------------------|"))
    }

    @Test fun inlineBoldCannotConsumeFollowingParagraph() {
        val markdown = "**Only this phrase is bold.** Normal text continues.\n\nNext paragraph text stays normal."
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<strong>Only this phrase is bold.</strong> Normal text continues."))
        assertFalse(html.contains("Next paragraph text stays normal.</p>") && html.contains("Normal text continues. Next paragraph"))
        assertTrue(html.contains("</p>\n<p>Next paragraph text stays normal.</p>") || html.contains("</p><p>Next paragraph text stays normal.</p>"))
    }


    @Test fun collapsedThreeColumnTableIsRecoveredFromSingleLine() {
        val markdown = "3. Diagnosis | Modality | What it shows | Typical findings | |---|---|---| Pap smear | Cytologic atypia | ASC-US, LSIL, HSIL, SCC || HPV DNA test | Presence of high-risk HPV | Positive for HPV-16/18 || Colposcopy | Cervical architecture | Acetowhite changes, mosaicism, punctuation || Biopsy | Histology | CIN 1–3, invasive squamous cell carcinoma |"
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<th>Modality</th>"))
        assertTrue(html.contains("<th>Typical findings</th>"))
        assertTrue(html.contains("<td>Pap smear</td>"))
        assertFalse(html.contains("|---|---|---|"))
    }

    @Test fun inlineClinicalBulletsBecomeSeparateBlocks() {
        val markdown = "Primary screening: Cytology or HPV DNA testing. - Co-testing: HPV + Pap is recommended. - Screening interval: Pap alone every 3 y."
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<ul>"))
        assertTrue(html.contains("<li>Co-testing: HPV + Pap is recommended.</li>"))
        assertTrue(html.contains("<li>Screening interval: Pap alone every 3 y.</li>"))
        assertTrue(html.contains("Screening interval: Pap alone every 3 y."))
    }

    @Test fun contentHasExplicitNormalWeightContract() {
        val html = rovexMarkdownToHtml("Normal paragraph. **Important term.**", true)
        assertTrue(html.contains("font-weight:400"))
        assertTrue(html.contains("strong,b{font-weight:650}"))
    }

    @Test fun numberedClinicalSectionTitleGetsProfessionalHeading() {
        val markdown = """
            9. Close distractors & why they’re wrong

            | Distractor | Why |
            | --- | --- |
            | HPV 16 | HPV 18 also contributes (Q1). |
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<h3>9. Close distractors &amp; why they’re wrong</h3>"))
    }

    @Test fun inlineMermaidSurvivesProviderCollapsedWhitespace() {
        val markdown = "#### Mermaid: M1 Antagonism → EPS Mitigation mermaid flowchart TD | M1[M1 Receptor] -->|Gq| PLC PLC -->|IP3/Ca2+| PKC PKC -->|↑| CholinergicTone CholinergicTone -->|↑| EPS M1 -->|Antagonist| Anticholinergic Anticholinergic -->|↓| EPS"
        val normalized = BenResponsePolicy.normalize(markdown)!!
        val html = rovexMarkdownToHtml(normalized, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("M1 Receptor"))
        assertTrue(html.contains("Anticholinergic"))
        assertFalse(html.contains("mermaid flowchart TD | M1[M1 Receptor]"))
    }

    @Test fun commonMarkPreservesParagraphBoundariesAndInlineEmphasis() {
        val html = rovexMarkdownToHtml(
            "First paragraph with **one bold term** and *one italic term*.\nSecond source line stays in the same paragraph.\n\nSecond paragraph is separate.",
            true
        )
        assertTrue(html.contains("<p>First paragraph with <strong>one bold term</strong> and <em>one italic term</em>."))
        assertTrue(html.contains("Second source line stays in the same paragraph."))
        assertTrue(html.contains("</p>\n<p>Second paragraph is separate.</p>"))
    }

    @Test fun commonMarkRendersNestedListsAndBlockquotes() {
        val markdown = """
            - Parent
              - Child
            - Second parent

            > Clinical tip: screen according to the patient's risk profile.
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<ul>"))
        assertTrue(html.contains("<li>Parent"))
        assertTrue(html.contains("<li>Child</li>"))
        assertTrue(html.contains("<blockquote>"))
        assertTrue(html.contains("Clinical tip:"))
    }


    @Test fun wrappedTableHeaderCellIsRecoveredIntoCommonMarkTable() {
        val markdown = """
            Drug Interactions | Interaction | Effect |
            | Clinical Implication | ------------- | -------- ||
            | CYP3A4 inducers (e.g., rifampicin, carbamazepine itself) | ↓ metabolism → ↓ serum levels | Dose escalation may be required |
            | CYP3A4 inhibitors (e.g., ketoconazole, erythromycin) | ↓ metabolism → ↑ serum levels | Risk of toxicity; monitor levels |
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<th>Interaction</th>"))
        assertTrue(html.contains("<th>Effect</th>"))
        assertTrue(html.contains("<th>Clinical Implication</th>"))
        assertTrue(html.contains("<td>CYP3A4 inducers"))
        assertFalse(html.contains("| Clinical Implication |"))
        assertFalse(html.contains("------------- | --------"))
    }

    @Test fun commonMarkRendersGfmTableStructure() {
        val markdown = """
            | Modality | What it shows |
            | --- | --- |
            | Pap smear | Cytologic atypia |
            | HPV DNA | High-risk HPV |
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<th>Modality</th>"))
        assertTrue(html.contains("<td>Pap smear</td>"))
        assertFalse(html.contains("| --- | --- |"))
    }

    @Test fun commonMarkKeepsInlineHtmlSafeRichFormatting() {
        val html = rovexMarkdownToHtml(
            "<p><strong>Clinical pearl</strong>: HPV <sup>16</sup> is high risk.</p>",
            true
        )
        assertTrue(html.contains("<strong>Clinical pearl</strong>"))
        assertTrue(html.contains("<sup>16</sup>"))
        assertFalse(html.contains("&lt;strong&gt;"))
    }

}

// Paragraph/block regression coverage: AI providers often omit blank lines between semantic blocks.
// The renderer must recover structure without forcing every soft newline into a <br>.
