# Rovex v8.3.345 — Chat/Resume/Bookmarks Rendering Repair

## Source baseline
- Built in-place from v8.3.344 (versionCode 437).
- New versionCode: 438.
- Package/applicationId remains `com.localqbank.library`.

## Repairs in this source batch
- Replaced permissive/collapsed Markdown table inference with a conservative structural parser.
- Genuine Markdown tables remain supported; pipe-heavy prose, pseudo-columns and malformed rows are rejected as tables.
- Added JVM regression tests for numbered lists, pseudo-columns, prose pipes, genuine tables, mixed prose/tables and malformed rows.
- Hardened Frankenstein and Ben+AI chat chrome so a deliberate touch/scroll on the reading surface enters immersive reading while the existing reveal affordance restores controls.
- Frankenstein now collapses its top chrome as well as bottom chrome through the existing `RovexChatChromeController`.
- Quiz answer rendering now derives answered state from durable progress rather than the volatile practice-only key, restoring explanation/answer panels after recreation/resume.
- Added a durable resume cursor separate from the visible quiz position: after an accepted answer it advances the resume target exactly once to the next question; explicit navigation updates the resume target to the viewed question.
- Progress meta resume checkpoints now also use the next-question semantics and mark completed QBanks so Home/Continue surfaces do not reopen completed sessions.
- Restored an explicit Bookmarked MCQs surface and Quick Tools entry on the current Home dashboard; it uses the existing `CollectionActivity`/progress repository path.
- Existing SoundPool feedback remains lifecycle-safe; the exact user-supplied MP3 could not be packaged in this source batch because that file is not currently present in the accessible conversation/Library filesystem.

## Verification policy
- Local Android Gradle compilation is not claimed. GitHub Actions remains the definitive build gate.
- Whole-project source/runtime-risk audit is required before CI acceptance.
