# Rovex v8.3.580 — LargeHtmlScanner JVM JSON Runtime Repair

## Authoritative CI failure

CI run `37575529218` checked out commit `97113829039a1a97dfa338ddacd102e798996356` and selected:

`Rovex_v8.3.579_LargeHtmlScanner_PermanentBoundaryRepair_Source.zip`

CI source archive SHA-256:
`47f1e42013ace5a965455883189c9cdf5863009a04fd00786f486822bc4bab07`

The source compiled, then `:app:testDebugUnitTest` failed:

`152 tests completed, 10 failed`

All 10 failures were in `LargeHtmlScannerRegressionTest`.

## Root cause

The failures form one shared JVM-test-environment defect, not ten independent scanner parsing defects.

`LargeHtmlScanner` parses production data with Android's framework `org.json.JSONObject`/`JSONArray`. The JVM unit-test environment was not supplying a real JVM `org.json` implementation.

Consequences in the existing scanner:

- `parseCandidate()` catches the framework JSON failure and silently skips the question, producing assertion failures.
- `parseRootQuestion()` catches the same class of failure, then `android.util.Log.w()` can itself throw under Android JVM stubs, producing the observed `RuntimeException`.
- This explains the exact split between assertion failures and runtime failures in the CI log.

The prior v8.3.579 assignment-boundary repair was therefore not the shared root cause of this CI failure.

## Repair

1. Added JVM-only dependency:
   `testImplementation("org.json:json:20260719")`
2. Added a direct regression test proving a real JVM `JSONObject` implementation is available.
3. Made recoverable root-question logging defensive with `runCatching`, so Android framework logging stubs cannot convert malformed-card recovery into a test crash.
4. Preserved the streaming lexical scanner and deterministic alias normalization; no speculative parser rewrite was introduced.
5. Removed the obsolete active `build-ben-qbank-579.yml` workflow from the source package so a stale version-specific CI gate cannot reappear.

Production Android continues using its normal framework `org.json` implementation; the JSON dependency is test-only.

## Version

- versionName: 8.3.580
- versionCode: 666
- applicationId: com.localqbank.library

## Verification

The exact Android Gradle test task was attempted locally but is BLOCKED by Gradle distribution DNS resolution:

`curl: (6) Could not resolve host: downloads.gradle.org`

Therefore Android `BUILD PASS` and `CI PASS` are not claimed.

A standalone JVM harness using the repaired production `LargeHtmlScanner` and representative JSON implementation passed all 10 CI regression cases.

