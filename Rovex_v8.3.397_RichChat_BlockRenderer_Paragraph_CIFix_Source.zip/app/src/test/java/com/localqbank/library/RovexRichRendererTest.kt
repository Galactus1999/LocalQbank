package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexRichRendererTest {
    @Test fun labeledMermaidFlowchartRendersAsDiagram() {
        val markdown = """
            ## Decision flow

            ```mermaid
            flowchart TD
              A[Patient presents with cystocele] --> B{Stage of prolapse?}
              B -->|I-II| C[Conservative: PT + pessary]
              B -->|III-IV| D[Conservative trial + consider surgery]
              D --> E{Symptomatic?}
              E -->|Yes| F[Continue pessary & PT]
              E -->|No| G[Follow-up; consider surgery if symptoms develop]
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Patient presents with cystocele"))
        assertTrue(html.contains("I-II"))
        assertFalse(html.contains("```mermaid"))
    }

    @Test fun twoBacktickProviderFenceIsRecovered() {
        val markdown = """
            Text before

            `` mermaid
            flowchart LR
              A[Start] -->|yes| B[Finish]
            ``

            Text after
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Start"))
        assertFalse(html.contains("`` mermaid"))
    }

    @Test fun sequenceDiagramDoesNotBecomeRawSource() {
        val markdown = """
            ```mermaid
            sequenceDiagram
              participant A as Doctor
              participant B as Patient
              A->>B: Explain diagnosis
              B-->>A: Ask question
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Doctor"))
        assertTrue(html.contains("Explain diagnosis"))
    }

    @Test fun stateDiagramDoesNotBreakNormalChat() {
        val markdown = """
            ```mermaid
            stateDiagram-v2
              [*] --> Idle
              Idle --> Processing : start
              Processing --> Done : complete
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Processing"))
    }

    @Test fun malformedDiagramFallsBackWithoutThrowing() {
        val html = rovexMarkdownToHtml(
            "```mermaid\nthis is not valid mermaid and should remain readable\n```",
            true
        )
        assertTrue(html.contains("rich-mermaid-fragment"))
        assertTrue(html.contains("this is not valid mermaid"))
    }
    @Test fun appendedHeadingAndThematicBreakBecomeBlocks() {
        val html = rovexMarkdownToHtml("Children may need special care. --- ### 2. Insomnia Associated with Medical Conditions\n\nCondition | Age\n--- | ---\nOSA | All ages", true)
        assertTrue(html.contains("<hr>"))
        assertTrue(html.contains("<h3>2. Insomnia Associated with Medical Conditions</h3>"))
        assertTrue(html.contains("<table>"))
        assertFalse(html.contains("<p>Children may need special care. <hr>"))
    }

    @Test fun normalSoftBreaksStayInsideOneParagraph() {
        val html = rovexMarkdownToHtml("First sentence.\nSecond sentence.\nThird sentence.", true)
        assertTrue(html.contains("<p>First sentence. Second sentence. Third sentence.</p>"))
        assertFalse(html.contains("First sentence.<br>Second"))
    }

    @Test fun adjacentListItemsBecomeSemanticList() {
        val html = rovexMarkdownToHtml("- One\n- Two\n- Three", true)
        assertTrue(html.contains("<ul><li>One</li><li>Two</li><li>Three</li></ul>"))
    }
}

// Paragraph/block regression coverage: AI providers often omit blank lines between semantic blocks.
// The renderer must recover structure without forcing every soft newline into a <br>.
