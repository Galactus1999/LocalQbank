# Rovex v8.3.299 — Offline UI/Adaptive Phase

Baseline imported from GitHub Actions artifact: Rovex-v8.3.298-source-under25mb.zip (run 56 source artifact, SHA-256 3a9e96f2a3c1b75d0eda6d36c14d94cde916a580f1e9eb453b01e5441c230107).

## Implemented offline
- Fixed the RenActivity chat-state property accessor that blocked CI compilation.
- Version advanced to 8.3.299 / versionCode 393.
- Added RovexModernUi: centralized lightweight semantic surfaces, rounded cards, elevated navigation capsule, button treatment, typography tinting, and Frankenstein workspace styling.
- Applied the visual system to MainActivity, RovexSectionDashboardActivity and RenActivity without bitmap assets or WebView UI dependencies.
- Preserved existing Obsidian Night semantic palette and accessibility content descriptions.
- Preserved landscape sizing and rotation-safe RenChatViewModel state.
- Preserved WebView horizontal overflow/touch work from 8.3.298.

## Verification
- All Android XML resources parse successfully.
- Modified Kotlin files have balanced structural braces and expected integration markers.
- Local Gradle compile was attempted offline but the wrapper requires Gradle 9.3.1 and the environment cannot resolve downloads.gradle.org. Therefore compilation is NOT claimed here; GitHub Actions remains the authoritative build gate.

## UI design references
The two supplied share.google links could not be fetched in this environment, so no claim is made that the new UI is pixel-identical to those references. The implementation is an app-wide modern visual-system pass based on the existing Rovex palette and structure. If the reference screenshots are uploaded directly, a second offline pass can reproduce their exact spacing, typography and component geometry.
