package com.localqbank.library

import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Central typography policy for the existing Views architecture.
 *
 * It deliberately uses Android's native auto-size engine for constrained controls rather
 * than repeatedly multiplying pixel sizes. Reading text is left alone; labels/headings get
 * a bounded range so a larger phone does not produce tiny labels and a narrow phone does
 * not overflow them.
 */
object AdaptiveTypographyManager {
    private const val BASE_TAG = 0x7f0f1001

    fun apply(root: View) { root.post { walk(root) } }

    private fun walk(v: View) {
        if (v is TextView) tune(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
    }

    private fun tune(v: TextView) {
        val text = v.text?.toString()?.trim().orEmpty()
        if (text.isEmpty() || v.width <= 0) return
        val clickable = v.isClickable || v is android.widget.Button
        val compact = v.height in 1..dp(v, 58)
        val heading = v.typeface?.isBold == true && text.length <= 48
        val tagLike = text.length <= 22 && v.height in 1..dp(v, 46)
        if (!clickable && !heading && !tagLike) return

        val density = v.resources.displayMetrics.density
        val baseSp = (v.getTag(BASE_TAG) as? Float)?.div(v.resources.displayMetrics.scaledDensity)
            ?: (v.textSize / v.resources.displayMetrics.scaledDensity).also { v.setTag(BASE_TAG, v.textSize) }

        val minSp = when {
            tagLike -> 10.5f
            clickable -> 12f
            else -> 13f
        }
        val maxSp = min(24f, max(minSp + 1f, baseSp + if (heading) 1f else 0f))
        val availableDp = v.width / density
        val widthMin = when {
            availableDp < 80f -> minSp
            availableDp < 120f -> max(minSp, min(maxSp, baseSp - 1.5f))
            else -> min(maxSp, baseSp)
        }
        v.setAutoSizeTextTypeUniformWithConfiguration(
            widthMin.roundToIntSafe(v),
            maxSp.roundToIntSafe(v),
            1,
            TypedValue.COMPLEX_UNIT_SP
        )
        if (clickable || tagLike) v.setIncludeFontPadding(false)
    }

    private fun Float.roundToIntSafe(v: View): Int = kotlin.math.round(this).toInt().coerceAtLeast(1)
    private fun dp(v: View, value: Int) = (value * v.resources.displayMetrics.density).toInt()
}
