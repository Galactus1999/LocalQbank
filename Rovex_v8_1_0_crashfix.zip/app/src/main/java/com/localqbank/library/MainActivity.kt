package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.roundToInt
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

private fun roundedDrawable(context: Context, color: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply {
    setColor(color)
    cornerRadius = radius * context.resources.displayMetrics.density
}

class MainActivity: AppCompatActivity(){
    private var isVisible = false
    private val stateListener:()->Unit={if(!isFinishing && !isDestroyed && isVisible)runOnUiThread{if(::db.isInitialized)runCatching{render();refreshOpenAnalyticsDialog()}}}
    private fun dp(value:Int):Int = (value * resources.displayMetrics.density).roundToInt()
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    private var analyticsDialog: Dialog? = null
    private var analyticsPeriod: Int = 0
    override fun onCreate(b:Bundle?){super.onCreate(b)
        // Everything below used to run unguarded: a single throw anywhere in this chain
        // (theme/resource lookup, edge-to-edge inset setup, etc.) had nothing catching it
        // yet, so it force-closed the app on every launch before a frame ever drew. Each
        // step is now isolated with runCatching so a failure in one cosmetic step can't take
        // down the whole launcher screen; setContentView is the one call allowed to propagate
        // since without it there is no screen to show at all.
        runCatching { AppManagers.initialize(applicationContext) }
        runCatching { SystemUi.immersive(this) }
        setContentView(R.layout.activity_main)
        runCatching { applyResponsiveHomeLayout() }
        // db/store are lateinit and other code already guards on `::db.isInitialized`
        // (see stateListener, onResume, onStop), so leaving them uninitialized on failure
        // here is consistent with the rest of the class instead of letting an exception
        // propagate out of onCreate.
        runCatching { db=QBankDb(this);store=ProgressStore(this) }
        runCatching { AppState.register(stateListener) }
        runCatching { TransitionCoordinator.install(this) }
        runCatching { styleHeaderControls() }
        runCatching { styleHomeNavigation() }
        runCatching {
            findViewById<ImageButton>(R.id.themeButton)?.setOnClickListener{startActivity(Intent(this,SettingsActivity::class.java))};findViewById<View>(R.id.homeSearchCard)?.setOnClickListener{openSearch()};findViewById<View>(R.id.renCard)?.setOnClickListener{startActivity(Intent(this,RenActivity::class.java))}
            listOf(R.id.homeSearchCard,R.id.renCard,R.id.analyticsCard,R.id.todaySolvedCard,R.id.studyMenuCard,R.id.flashcardCard,R.id.qbankSection).forEach{id->findViewById<View>(id)?.let(AliveMotion::install)}
        }
        render();window.decorView.postDelayed({runCatching{showRecoveryPrompt()}},500)}
    override fun onStart(){ super.onStart(); isVisible = true }
    override fun onResume(){super.onResume(); AppManagers.dashboard.prepareForDisplay(); if(::db.isInitialized) render()}
    override fun onPause(){ super.onPause() }
    override fun onStop(){ isVisible = false; if(::db.isInitialized) BackupManager(this).flushCloudBackup(); super.onStop() }
    private fun showRecoveryPrompt(){
        if (isFinishing || isDestroyed || !ResilienceManager.shouldOfferRecovery(this)) return
        val recovery = ResilienceManager.recovery(this) ?: return
        AlertDialog.Builder(this)
            .setTitle("Resume protected study session?")
            .setMessage("Rovex saved question ${recovery.position + 1} before the previous interruption. Your QBank data was preserved.")
            .setNegativeButton("Later") { _, _ -> ResilienceManager.dismissRecoveryOffer(this) }
            .setPositiveButton("Resume") { _, _ ->
                ResilienceManager.dismissRecoveryOffer(this)
                val intent = Intent(this, QuizActivity::class.java).apply {
                    putExtra("testId", recovery.testId)
                    putExtra("position", recovery.position)
                    putExtra("sessionLabel", recovery.session)
                    if (recovery.stableKey.isNotBlank()) putExtra("questionId", recovery.stableKey.substringAfterLast(':').toLongOrNull() ?: -1L)
                }
                startActivity(intent)
            }.show()
    }

    private fun refreshOpenAnalyticsDialog(){
        val dialog=analyticsDialog
        if(dialog!=null && dialog.isShowing && !isFinishing && !isDestroyed){
            PerformanceManager.submit {
                val refs = PerformanceManager.refs(applicationContext)
                runOnUiThread { if (!isFinishing && !isDestroyed) runCatching { showInteractiveAnalytics(refs, analyticsPeriod) } }
            }
        }
    }
    private fun styleHeaderControls(){
        styleHomeNavigation()
        findViewById<ImageButton>(R.id.themeButton)?.apply{
            background = null
            backgroundTintList = null
            setImageResource(R.drawable.ic_settings)
            imageTintList = android.content.res.ColorStateList.valueOf(ThemeManager.text(this@MainActivity))
            contentDescription = "Settings and app menu"
            scaleType = ImageView.ScaleType.CENTER
            setPadding(dp(8),dp(8),dp(8),dp(8))
            minimumWidth = 0
            minimumHeight = 0
            elevation = 0f
        }
        findViewById<View>(R.id.mainHeader)?.background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        findViewById<View>(R.id.renCard)?.background = roundedDrawable(this, ThemeManager.explanationBg(this), 16f)
        findViewById<View>(R.id.renCard)?.elevation = dp(1).toFloat()
        findViewById<RovexWaveLogoView>(R.id.appLogoText)?.clearColorFilter()
        (findViewById<View>(R.id.mainHeader) as? LinearLayout)?.getChildAt(1)?.let { (it as? TextView)?.setTextColor(ThemeManager.text(this@MainActivity)) }
        // Add QBank now lives beside the "Dashboard" heading on the light body background,
        // so it needs a solid dark pill instead of the white-on-header treatment it used to have.
        findViewById<Button>(R.id.addButton)?.apply{
            backgroundTintList=null
            background=GradientDrawable().apply{setColor(if(ThemeManager.isDark(this@MainActivity)) Color.rgb(48,105,145) else Color.rgb(35,92,123));cornerRadius=20f*resources.displayMetrics.density}
            setTextColor(Color.WHITE); minHeight=dp(40); isAllCaps=false
            setPadding(dp(16),dp(2),dp(16),dp(2))
            elevation=dp(2).toFloat()
        }
    }

    private fun openSearch(){
        startActivity(Intent(this,SearchActivity::class.java).putExtra("focusSearch",true))
    }

    private fun scrollHomeTop(){
        findViewById<ScrollView>(R.id.dashboardScroll)?.smoothScrollTo(0,0)
    }

    private fun render(){
        if (isFinishing || isDestroyed) return
        styleHeaderControls()
        val generation=PerformanceManager.currentGeneration()
        PerformanceManager.submit {
            val model=runCatching{AppManagers.dashboard.build()}.getOrNull() ?: return@submit
            runOnUiThread{
                if(isFinishing||isDestroyed||generation!=PerformanceManager.currentGeneration())return@runOnUiThread
                runCatching{renderUi(model.refs,model.sources,model.analytics,model.bookmarks,model.sourceProgress)}
                    .onFailure{Toast.makeText(this,"Dashboard refresh failed. Your data is safe.",Toast.LENGTH_SHORT).show()}
            }
        }
    }

    private fun renderUi(refs: List<QuestionRef>, sources: List<Source>, snapshot: AnalyticsSnapshot, bookmarks: Map<String, Int>, sourceProgress: Map<Long, ProgressSummary>) {
        findViewById<View>(R.id.dashboardRoot)?.setBackgroundColor(ThemeManager.bg(this@MainActivity))
        val total=snapshot.total; val solved=snapshot.correct; val wrong=snapshot.wrong
        val attempted=snapshot.attempted; val accuracy=snapshot.accuracy; val due=snapshot.due
                findViewById<TextView>(R.id.analyticsSub)?.text="$solved correct • $wrong wrong • ${snapshot.bookmarks} bookmarked"
        findViewById<TextView>(R.id.analyticsAccuracy)?.text="$accuracy%"
        findViewById<TextView>(R.id.analyticsAttempted)?.text="$attempted"
        findViewById<TextView>(R.id.analyticsDue)?.text="$due"
        findViewById<ProgressBar>(R.id.analyticsProgress)?.apply { progress = accuracy; progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(34,125,143)); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(40,80,100,120)) }
        findViewById<TextView>(R.id.todaySolvedCount)?.apply{textSize=30f;text="${snapshot.todaySolved}"}
        val hour=java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greeting=when(hour){in 5..11->"Good morning";in 12..16->"Good afternoon";else->"Good evening"}
        findViewById<RovexWaveTextView>(R.id.dashboardGreeting)?.text=greeting
        findViewById<TextView>(R.id.dashboardFocus)?.text=runCatching{AppManagers.adaptive.studyStrategy()}.getOrDefault("Your adaptive study plan is ready.")
        findViewById<TextView>(R.id.dashboardAccuracyHero)?.text="${accuracy}%\naccuracy"
        findViewById<TextView>(R.id.heroDue)?.text=due.toString()
        findViewById<TextView>(R.id.heroSolved)?.text=snapshot.todaySolved.toString()
        findViewById<View>(R.id.heroAction)?.setOnClickListener{startTodaySolved(refs)}
        findViewById<View>(R.id.quickRevision)?.setOnClickListener{launchQuickCollection(dueIdsFor(refs),"Today’s Revision")}
        findViewById<View>(R.id.quickSubject)?.setOnClickListener{startActivity(Intent(this,StudyToolsActivity::class.java).putExtra("openSubjectFocus",true))}
        findViewById<View>(R.id.quickWrong)?.setOnClickListener{launchQuickCollection(wrongIdsFor(refs),"Wrong Questions")}

        findViewById<TextView>(R.id.studyMenuSub)?.apply{text="";visibility=View.GONE}
        findViewById<TextView>(R.id.studyMenuTitle)?.text="Study tools"
        findViewById<TextView>(R.id.studyMenuTitle)?.textSize=20f
        listOf(R.id.analyticsCard to R.id.analyticsCardAction).forEach{(card,action)->
            val bg=if(ThemeManager.isDark(this@MainActivity)) ThemeManager.elevated(this@MainActivity) else Color.rgb(249,251,247)
            findViewById<View>(card)?.background=GradientDrawable().apply{setColor(bg);cornerRadius=16f*resources.displayMetrics.density;setStroke(dp(1),if(ThemeManager.isDark(this@MainActivity)) Color.rgb(48,61,75) else Color.rgb(224,232,226))}
            findViewById<View>(action)?.background=GradientDrawable().apply{setColor(if(ThemeManager.isDark(this@MainActivity)) Color.rgb(29,55,72) else Color.rgb(225,241,243));cornerRadius=10f*resources.displayMetrics.density}
        }
        findViewById<View>(R.id.analyticsCard)?.setOnClickListener{showInteractiveAnalytics(refs)}
        findViewById<View>(R.id.analyticsCardAction)?.setOnClickListener{showInteractiveAnalytics(refs)}
        findViewById<View>(R.id.todaySolvedCard)?.setOnClickListener{startTodaySolved(refs)}
        findViewById<View>(R.id.studyMenuCard)?.setOnClickListener{startActivity(Intent(this,StudyToolsActivity::class.java))}
        findViewById<View>(R.id.flashcardCard)?.apply{background=GradientDrawable().apply{setColor(if(ThemeManager.isDark(this@MainActivity))ThemeManager.elevated(this@MainActivity) else Color.WHITE);cornerRadius=16f*resources.displayMetrics.density};setOnClickListener{startActivity(Intent(this@MainActivity,FlashcardActivity::class.java))}}
        applyDashboardTheme()
        styleDashboardHero()
        setCollectionButton(R.id.importantButton,"★ Important",bookmarks["important"] ?: 0,ThemeManager.bookmarkFill(this@MainActivity,"important"),ThemeManager.bookmarkText(this@MainActivity,"important"))
        setCollectionButton(R.id.reviseButton,"↻ Revise",bookmarks["revise"] ?: 0,ThemeManager.bookmarkFill(this@MainActivity,"revise"),ThemeManager.bookmarkText(this@MainActivity,"revise"))
        setCollectionButton(R.id.doubtButton,"❔ Doubt",bookmarks["doubt"] ?: 0,ThemeManager.bookmarkFill(this@MainActivity,"doubt"),ThemeManager.bookmarkText(this@MainActivity,"doubt"))
        setCollectionButton(R.id.favoriteButton,"♥ Favourite",bookmarks["favorite"] ?: 0,ThemeManager.bookmarkFill(this@MainActivity,"favorite"),ThemeManager.bookmarkText(this@MainActivity,"favorite"))
        styleDashboardCards()
        AdaptiveTypographyManager.apply(findViewById(R.id.dashboardRoot))
        findViewById<Button>(R.id.addButton).setOnClickListener{openImporter()}
        setupCollection(R.id.importantButton,"bookmark","important"); setupCollection(R.id.reviseButton,"bookmark","revise"); setupCollection(R.id.doubtButton,"bookmark","doubt"); setupCollection(R.id.favoriteButton,"bookmark","favorite")
        val list=findViewById<LinearLayout>(R.id.libraryList); list.removeAllViews(); sources.forEachIndexed{index,source->addSourceCard(list,source,index,sourceProgress[source.id])}
    }


    private fun continueStudy(refs: List<QuestionRef>, sources: List<Source>) {
        runCatching {
            val session = AppManagers.sessionStore.current()
            if (session != null && session.testId.isNotBlank() && !session.id.contains("collection", true)) {
                val test = db.testById(session.testId)
                if (test != null && test.count > 0) {
                    startActivity(Intent(this, QuizActivity::class.java).apply {
                        putExtra("testId", test.id)
                        putExtra("title", test.title)
                        putExtra("position", session.position.coerceIn(0, test.count - 1))
                        putExtra("sessionLabel", test.title)
                    })
                    return
                }
            }
            for (source in sources) {
                val resume = store.sourceResume(source.id)?.split("|", limit = 2)
                    ?: store.sourceResumeByName(source.fileName)?.split("|", limit = 2)
                val testId = resume?.getOrNull(0).orEmpty()
                val test = testId.takeIf { it.isNotBlank() }?.let { db.testById(it) }
                if (test != null && test.count > 0) {
                    startActivity(Intent(this, QuizActivity::class.java).apply {
                        putExtra("testId", test.id)
                        putExtra("title", test.title)
                        putExtra("position", resume?.getOrNull(1)?.toIntOrNull()?.coerceIn(0, test.count - 1) ?: 0)
                        putExtra("sessionLabel", test.title)
                    })
                    return
                }
            }
            val first = refs.firstOrNull()
            if (first != null) {
                startActivity(Intent(this, QuizActivity::class.java).apply {
                    putExtra("testId", first.testId)
                    putExtra("title", first.testTitle)
                    putExtra("position", first.position)
                    putExtra("sessionLabel", first.testTitle)
                })
            } else Toast.makeText(this, "Import a QBank to continue studying", Toast.LENGTH_SHORT).show()
        }.onFailure { Toast.makeText(this, "Could not resume this study session. Your progress is safe.", Toast.LENGTH_SHORT).show() }
    }

    private fun launchQuickCollection(ids:LongArray,label:String){
        if(ids.isEmpty()){Toast.makeText(this,"No questions available",Toast.LENGTH_SHORT).show();return}
        startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.take(100).joinToString(",")).putExtra("sessionLabel",label).putExtra("practiceMode",true).putExtra("title",label))
    }
    private fun dueIdsFor(refs:List<QuestionRef>):LongArray {
        val p=PerformanceManager.progress(applicationContext);val now=System.currentTimeMillis()
        return refs.asSequence().filter{r->val x=p.record(r.stableKey); x?.status != null && (x.nextDue>0L && now>=x.nextDue || x.nextDue==0L && x.lastAttempted>0L && now-x.lastAttempted>=when(x.attempts){1->86_400_000L;2->3*86_400_000L;3->7*86_400_000L;4->14*86_400_000L;else->30*86_400_000L})}.take(100).map{it.id}.toList().toLongArray()
    }
    private fun wrongIdsFor(refs:List<QuestionRef>):LongArray {
        val p=PerformanceManager.progress(applicationContext);return refs.filter{p.record(it.stableKey)?.status=="wrong"}.sortedByDescending{p.record(it.stableKey)?.attempts?:0}.take(100).map{it.id}.toLongArray()
    }

    private fun todaySolvedCount(refs:List<QuestionRef>):Int = AppManagers.todaySolved.count(refs)

    private fun startTodaySolved(refs:List<QuestionRef>){
        if (isFinishing || isDestroyed) return
        runCatching {
            val ids = AppManagers.todaySolved.ids(refs, 200).filter { runCatching { db.questionExists(it) }.getOrDefault(false) }
            if(ids.isEmpty()){ Toast.makeText(this,"No questions solved today",Toast.LENGTH_SHORT).show(); return }
            startActivity(Intent(this,QuizActivity::class.java).apply{
                putExtra("sessionIds",ids.joinToString(","))
                putExtra("collectionMode",true)
                putExtra("title","Today’s Solved")
                putExtra("sessionLabel","Today’s Solved")
                putExtra("position",0)
                putExtra("practiceMode",true)
            })
        }.onFailure { Toast.makeText(this,"Today's Solved could not be opened. Your progress is safe.",Toast.LENGTH_LONG).show() }
    }

    private fun todaysRevisionCount(refs:List<QuestionRef>):Int = runCatching {
        val p=PerformanceManager.progress(applicationContext)
        refs.count { r -> val state=p.record(r.stableKey); state?.status=="wrong" || !state?.bookmark.isNullOrBlank() }
    }.getOrDefault(0)

    private fun startTodayRevision(refs:List<QuestionRef>){
        runCatching {
            val p=PerformanceManager.progress(applicationContext)
            val pool=refs.filter { r ->
                val state=p.record(r.stableKey)
                state?.status=="wrong" || !state?.bookmark.isNullOrBlank()
            }.distinctBy { it.id }
            if(pool.isEmpty()){Toast.makeText(this,"No wrong or bookmarked questions available for today's revision",Toast.LENGTH_SHORT).show();return}
            val day=java.time.LocalDate.now().toEpochDay()
            val ids=pool.shuffled(java.util.Random(day xor 0x52_4F_56_45_58L)).take(100).map{it.id}
            startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Today's Revision").putExtra("practiceMode",true).putExtra("title","Today's Revision"))
        }.onFailure { Toast.makeText(this,"Revision could not be opened. Your progress is safe.",Toast.LENGTH_SHORT).show() }
    }

    private fun currentQBankRefs(allRefs:List<QuestionRef>):List<QuestionRef>{
        if(allRefs.isEmpty()) return emptyList()
        val session=AppManagers.sessionStore.current()
        val currentSourceId=session?.testId?.let { id -> allRefs.firstOrNull { it.testId==id }?.sourceId } ?: 0L
        val sourceId=if(currentSourceId>0L) currentSourceId else allRefs.firstOrNull()?.sourceId ?: return allRefs
        return allRefs.filter{it.sourceId==sourceId}
    }

    private fun showInteractiveAnalytics(allRefs:List<QuestionRef>,periodDays:Int=0){
        if (isFinishing || isDestroyed || !::db.isInitialized || !::store.isInitialized) return
        try {
        analyticsPeriod=periodDays
        val baseRefs=if(periodDays<=0) allRefs else { val since=System.currentTimeMillis()-periodDays*86_400_000L; val progress=PerformanceManager.progress(applicationContext); allRefs.filter{progress.record(it.stableKey)?.lastAttempted?.let{t->t>=since}==true} }
        val refs=currentQBankRefs(baseRefs)
        val snap=AppManagers.analytics.snapshot(refs)
        val solved=snap.correct
        val wrong=snap.wrong
        val attempted=snap.attempted
        val total=snap.total
        val accuracy=snap.accuracy
        val mastery=snap.mastery
        val due=snap.due
        val notes=snap.notes
        val bookmarks=snap.bookmarks
        val avgMs=snap.averageTimeMs
        val today=snap.todaySolved
        val dark=ThemeManager.isDark(this)
        analyticsDialog?.dismiss()
        val dialog=Dialog(this)
        analyticsDialog=dialog
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@MainActivity))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(18),dp(12),dp(10),dp(8));background=GradientDrawable().apply{setColor(if(dark)Color.rgb(18,43,57)else Color.rgb(24,84,108));cornerRadius=0f}}
        top.addView(TextView(this).apply{text="⚡ PERFORMANCE LAB";textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(TextView(this).apply{text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(dp(48),dp(48)))
        root.addView(top)
        val periods=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(10),dp(12),dp(2))}
        listOf(1 to "DAILY",7 to "WEEKLY",30 to "MONTHLY",0 to "ALL TIME").forEach{(days,label)->
            val selected=periodDays==days
            val chip=TextView(this).apply{text=label;textSize=10.5f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(if(selected)Color.WHITE else ThemeManager.text(this@MainActivity));background=roundedDrawable(this@MainActivity,if(selected)ThemeManager.accent(this@MainActivity) else ThemeManager.elevated(this@MainActivity),14f);setPadding(dp(8),dp(7),dp(8),dp(7));setOnClickListener{dialog.dismiss();showInteractiveAnalytics(allRefs,days)}}
            periods.addView(chip,LinearLayout.LayoutParams(0,dp(38),1f).apply{setMargins(dp(3),0,dp(3),0)})
        }
        root.addView(periods)
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(26))}

        val hero=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(16),dp(14),dp(16));background=GradientDrawable().apply{setColor(if(dark)Color.rgb(24,42,55)else Color.rgb(233,247,250));cornerRadius=24f}}
        hero.addView(PerformanceRing(this,accuracy,mastery,dark),LinearLayout.LayoutParams(dp(126),dp(126)))
        val heroText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(4),0)}
        heroText.addView(TextView(this).apply{text=when{attempted==0->"Ready to build your profile";accuracy>=85->"Elite accuracy zone";accuracy>=70->"Strong base — sharpen weak areas";else->"High-yield opportunity zone"};textSize=19f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity))})
        heroText.addView(TextView(this).apply{text="${accuracy}% accuracy  •  ${mastery}% mastery";textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@MainActivity));setPadding(0,dp(7),0,dp(5))})
        heroText.addView(TextView(this).apply{text="${today} questions in this period. ${if(due>0)"${due} questions are waiting for revision." else "No revision backlog is waiting."}";textSize=12.5f;setTextColor(ThemeManager.muted(this@MainActivity));setLineSpacing(0f,1.15f)})
        hero.addView(heroText,LinearLayout.LayoutParams(0,-2,1f));box.addView(hero)

        val section=TextView(this).apply{text="YOUR CONTROL PANEL";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@MainActivity));setPadding(dp(2),dp(18),dp(2),dp(8))};box.addView(section)
        val actionRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f}
        fun action(label:String,value:String,bg:Int,click:()->Unit){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(7),dp(11),dp(7),dp(10));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(27,35,45)else bg,18f);setOnClickListener{click()}};c.addView(TextView(this).apply{text=value;textSize=22f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@MainActivity))});c.addView(TextView(this).apply{text=label;textSize=10.5f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@MainActivity))});actionRow.addView(c,LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(3),0,dp(3),0)})}
        action("WRONG",wrong.toString(),Color.rgb(253,232,235)){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","status").putExtra("filterValue","wrong"))}
        val currentRefs=currentQBankRefs(refs)
        val currentDue=todaysRevisionCount(currentRefs)
        action("DUE NOW",currentDue.toString(),Color.rgb(255,243,214)){startTodayRevision(currentRefs)}
        action("UNSOLVED",(total-attempted).coerceAtLeast(0).toString(),Color.rgb(230,241,248)){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","status").putExtra("filterValue","unsolved"))}
        box.addView(actionRow)

        val speed=if(avgMs>0)"${(avgMs/1000).coerceAtLeast(1)}s / question" else "—"
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f;setPadding(0,dp(10),0,0)}
        fun metric(label:String,value:String,click:(()->Unit)?=null){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(11),dp(10),dp(8),dp(10));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(22,29,38)else Color.rgb(248,250,252),16f);if(click!=null){isClickable=true;isFocusable=true;setOnClickListener{click()}}};c.addView(TextView(this).apply{text=value;textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity))});c.addView(TextView(this).apply{text=label;textSize=10.5f;setTextColor(ThemeManager.muted(this@MainActivity));setPadding(0,dp(3),0,0)});stats.addView(c,LinearLayout.LayoutParams(0,dp(70),1f).apply{setMargins(dp(3),0,dp(3),0)})}
        metric("AVG TIME",speed);metric("BOOKMARKS",bookmarks.toString()){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue","all"))};metric("NOTES",notes.toString()){startActivity(Intent(this,NotesActivity::class.java))};box.addView(stats)

        box.addView(TextView(this).apply{text="QBANK FOCUS MAP";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@MainActivity));setPadding(dp(2),dp(18),dp(2),dp(7))})
        val sources=db.sources()
        sources.take(10).forEachIndexed{idx,src->
            val r=refs.filter{it.sourceName==src.fileName}; val p=PerformanceManager.progress(applicationContext); val a=r.count{p.record(it.stableKey)?.status!=null}; val c=r.count{p.record(it.stableKey)?.status=="correct"}; val pct=if(a==0)0 else c*100/a
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(9),dp(12),dp(9));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(22,29,38)else Color.rgb(248,250,247),16f)}
            val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            head.addView(TextView(this).apply{text=src.fileName;textSize=13.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity));maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,-2,1f))
            head.addView(TextView(this).apply{text="$a/${r.size}  •  $pct%";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@MainActivity));gravity=Gravity.END})
            row.addView(head)
            val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pct;progressTintList=android.content.res.ColorStateList.valueOf(if(pct>=80)Color.rgb(35,145,103)else if(pct>=60)Color.rgb(34,125,143)else Color.rgb(210,115,70));backgroundTintList=android.content.res.ColorStateList.valueOf(Color.argb(40,80,100,120))}
            row.addView(bar,LinearLayout.LayoutParams(-1,dp(6)).apply{setMargins(0,dp(8),0,0)})
            row.setOnClickListener{startActivity(Intent(this,TestListActivity::class.java).putExtra("sourceId",src.id).putExtra("sourceName",src.fileName))}
            box.addView(row,LinearLayout.LayoutParams(-1,dp(70)).apply{setMargins(0,dp(3),0,dp(3))})
        }
        box.addView(TextView(this).apply{text="ADAPTIVE INSIGHT\n\n${AppManagers.adaptive.insight()}\n\nStudy guidance: ${AppManagers.learning.recommendation(refs)}";textSize=12.5f;setTextColor(ThemeManager.text(this@MainActivity));setLineSpacing(0f,1.12f);setPadding(dp(14),dp(13),dp(14),dp(13));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(25,32,41)else Color.rgb(255,247,225),16f)})
        box.addView(TextView(this).apply{text="Open Study Menu  →";textSize=14f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@MainActivity));setPadding(0,dp(16),0,dp(4));setOnClickListener{dialog.dismiss();startActivity(Intent(this@MainActivity,StudyToolsActivity::class.java))}})
        scroll.addView(box);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if (isFinishing || isDestroyed) return
        dialog.setContentView(root)
        dialog.setOnDismissListener { if (analyticsDialog === dialog) analyticsDialog = null }
        dialog.show()
        dialog.window?.setLayout(-1,(resources.displayMetrics.heightPixels*0.92f).toInt())
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        } catch (t:Throwable) {
            analyticsDialog = null
            runCatching { if (!isFinishing && !isDestroyed) Toast.makeText(this,"Analytics could not be opened. Please try again.",Toast.LENGTH_SHORT).show() }
        }
    }

    private class PerformanceRing(context:Context,private val accuracy:Int,private val mastery:Int,private val dark:Boolean):View(context){
        private val density=context.resources.displayMetrics.density
        private val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{style=android.graphics.Paint.Style.STROKE;strokeWidth=14f*density;strokeCap=android.graphics.Paint.Cap.ROUND}
        private val t=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{textAlign=android.graphics.Paint.Align.CENTER;typeface=Typeface.DEFAULT_BOLD}
        override fun onDraw(c:android.graphics.Canvas){super.onDraw(c);val cx=width/2f;val cy=height/2f;val r=minOf(width,height)*.34f;p.color=if(dark)Color.rgb(55,70,84)else Color.rgb(207,224,231);c.drawCircle(cx,cy,r,p);p.color=if(accuracy>=80)Color.rgb(39,150,113)else Color.rgb(35,126,151);c.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,accuracy*3.6f,false,p);t.color=if(dark)Color.WHITE else Color.rgb(19,55,70);t.textSize=25f*density;c.drawText("$accuracy%",cx,cy+8f*density,t);t.textSize=9.5f*density;t.color=if(dark)Color.LTGRAY else Color.rgb(82,105,116);c.drawText("ACCURACY",cx,cy+25f*density,t)}
    }

    private fun addSourceCard(list: LinearLayout, source: Source, index: Int, cachedProgress: ProgressSummary? = null) {
        val density = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(10), dp(11))
        }
        val cardBg = GradientDrawable().apply {
            setColor(if(ThemeManager.isDark(this@MainActivity)) Color.rgb(24,32,42) else when (index % 5) {
                0 -> Color.rgb(235, 245, 255)
                1 -> Color.rgb(238, 249, 242)
                2 -> Color.rgb(255, 245, 228)
                3 -> Color.rgb(246, 239, 255)
                else -> Color.rgb(255, 237, 241)
            })
            cornerRadius = 16f * density
        }
        card.background = cardBg

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "${index + 1}. ${source.fileName}"
            textSize = 15f
            setTextColor(ThemeManager.text(this@MainActivity))
            setTypeface(null, 1)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val pr = cachedProgress ?: ProgressSummary(0,0,0,0)
        val count = TextView(this).apply {
            text = "${pr.solved}/${pr.total}"
            textSize = 12f
            setTypeface(null, 1)
            setTextColor(ThemeManager.muted(this@MainActivity))
            gravity = Gravity.CENTER_VERTICAL
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = pr.total.coerceAtLeast(1)
            this.progress = pr.solved.coerceIn(0, max)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(34, 125, 143))
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(45, 80, 100, 120))
        }
        val progressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        progressRow.addView(progress, LinearLayout.LayoutParams(0, dp(7), 1f).apply { setMargins(0, dp(6), dp(8), 0) })
        progressRow.addView(count, LinearLayout.LayoutParams(dp(48), dp(24)).apply { setMargins(0, dp(1), 0, 0) })
        body.addView(title)
        body.addView(progressRow)
        card.addView(body, LinearLayout.LayoutParams(0, -2, 1f))

        val resumeData = (store.sourceResumeByName(source.fileName) ?: store.sourceResume(source.id))?.split("|", limit = 2)
        val rt = resumeData?.getOrNull(0)?.let { db.testById(it) }
        if (rt != null) {
            val rb = TextView(this).apply {
                text = "RESUME"
                textSize = 10f
                setTypeface(null, 1)
                setTextColor(ThemeManager.accent(this@MainActivity))
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    setColor(if(ThemeManager.isDark(this@MainActivity)) Color.rgb(24,52,72) else Color.rgb(225,243,246))
                    cornerRadius = 11f * density
                }
                setPadding(dp(8), 0, dp(8), 0)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, QuizActivity::class.java)
                        .putExtra("testId", rt.id)
                        .putExtra("title", rt.title)
                        .putExtra("position", resumeData.getOrNull(1)?.toIntOrNull() ?: 0))
                }
            }
            card.addView(rb, LinearLayout.LayoutParams(dp(76), dp(38)).apply {
                gravity = Gravity.CENTER_VERTICAL
                setMargins(dp(8), 0, 0, 0)
            })
        }

        card.setOnClickListener {
            startActivity(Intent(this, TestListActivity::class.java)
                .putExtra("sourceId", source.id)
                .putExtra("sourceName", source.fileName))
        }
        card.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle("Delete QBank?")
                .setMessage("Remove ${source.fileName} and all its imported questions from Rovex?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ ->
                    db.deleteSource(source.id)
                    Toast.makeText(this, "QBank deleted", Toast.LENGTH_SHORT).show()
                    render()
                }.show()
            true
        }
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, dp(5), 0, dp(5))
        })
    }

    private fun setCollectionButton(id:Int,label:String,count:Int,bg:Int,fg:Int){
        val b=findViewById<Button>(id)
        val text=SpannableString("$label\n$count")
        text.setSpan(RelativeSizeSpan(1.0f),0,label.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        text.setSpan(RelativeSizeSpan(1.55f),label.length+1,text.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        b.text=text
        b.setTextColor(fg)
        // Android Button styles can apply a theme tint over a custom drawable. Clear it
        // so each bookmark collection keeps its own semantic color.
        b.backgroundTintList = null
        b.stateListAnimator = null
        b.elevation = 0f
        b.background=GradientDrawable().apply{setColor(bg);cornerRadius=18f*resources.displayMetrics.density;setStroke((1*resources.displayMetrics.density).toInt(),Color.argb(55,100,120,140))}
    }
    private fun applyResponsiveHomeLayout(){
        val widthDp=resources.configuration.screenWidthDp
        val compact=widthDp<360
        val expanded=widthDp>=600
        findViewById<View>(R.id.homeSearchCard)?.let{ v ->
            v.layoutParams?.let{ lp ->
                lp.height=dp(if(compact) 50 else if(expanded) 60 else 56)
                v.layoutParams=lp
            }
        }
        listOf(R.id.todaySolvedCard,R.id.studyMenuCard).forEach{ id ->
            findViewById<View>(id)?.let{ v ->
                v.layoutParams?.let{ lp ->
                    lp.height=dp(if(compact) 136 else if(expanded) 154 else 144)
                    v.layoutParams=lp
                }
            }
        }
    }

    private fun styleHomeNavigation(){
        val dark=ThemeManager.isDark(this@MainActivity)
        val searchBg=ThemeManager.elevated(this@MainActivity)
        val border=if(dark) Color.rgb(63,78,96) else Color.rgb(211,220,226)
        findViewById<View>(R.id.homeSearchCard)?.background=GradientDrawable().apply{
            setColor(searchBg);cornerRadius=18f*resources.displayMetrics.density;setStroke(dp(1),border)
        }
        findViewById<ImageView>(R.id.homeSearchIcon)?.setColorFilter(ThemeManager.accent(this@MainActivity))
        findViewById<TextView>(R.id.homeSearchText)?.setTextColor(ThemeManager.muted(this@MainActivity))
        findViewById<TextView>(R.id.homeSearchShortcut)?.apply{
            setTextColor(ThemeManager.accent(this@MainActivity))
            background=GradientDrawable().apply{setColor(if(dark) Color.rgb(31,44,58) else Color.rgb(239,244,247));cornerRadius=9f*resources.displayMetrics.density}
        }
    }

    private fun styleDashboardHero(){
        val theme=ThemeManager.get(this@MainActivity)
        val dark=ThemeManager.isDark(this@MainActivity)
        val hero=findViewById<View>(R.id.dashboardHero) ?: return
        val heroColors=when(theme){
            ThemeManager.AMOLED -> intArrayOf(Color.rgb(20,34,43),Color.rgb(8,18,24))
            ThemeManager.MIDNIGHT -> intArrayOf(Color.rgb(25,52,91),Color.rgb(11,24,47))
            ThemeManager.DARK -> intArrayOf(Color.rgb(30,58,76),Color.rgb(17,30,42))
            ThemeManager.SEPIA -> intArrayOf(Color.rgb(113,91,60),Color.rgb(76,61,42))
            else -> intArrayOf(Color.rgb(35,101,126),Color.rgb(28,67,93))
        }
        hero.background=GradientDrawable(GradientDrawable.Orientation.TL_BR,heroColors).apply{cornerRadius=22f*resources.displayMetrics.density}
        findViewById<RovexWaveTextView>(R.id.dashboardGreeting)?.setTextColor(Color.WHITE)
        findViewById<TextView>(R.id.dashboardFocus)?.setTextColor(Color.argb(220,255,255,255))
        findViewById<TextView>(R.id.dashboardAccuracyHero)?.apply{
            setTextColor(Color.WHITE)
            background=GradientDrawable().apply{setColor(Color.argb(if(dark)70 else 48,255,255,255));cornerRadius=37f*resources.displayMetrics.density;setStroke(dp(1),Color.argb(75,255,255,255))}
        }
        findViewById<TextView>(R.id.heroDue)?.setTextColor(Color.WHITE)
        findViewById<TextView>(R.id.heroSolved)?.setTextColor(Color.WHITE)
        findViewById<TextView>(R.id.heroAction)?.apply{
            setTextColor(if(dark)ThemeManager.text(this@MainActivity) else Color.rgb(18,58,78))
            background=GradientDrawable().apply{setColor(if(dark)ThemeManager.elevated(this@MainActivity) else Color.rgb(239,248,250));cornerRadius=20f*resources.displayMetrics.density;setStroke(dp(1),Color.argb(90,255,255,255))}
        }
        // Semantic quick actions: tinted surfaces adapt to every theme instead of plain white.
        val quickColors=when(theme){
            ThemeManager.AMOLED -> intArrayOf(Color.rgb(22,43,48),Color.rgb(27,39,58),Color.rgb(48,31,42))
            ThemeManager.MIDNIGHT -> intArrayOf(Color.rgb(19,48,69),Color.rgb(28,45,72),Color.rgb(52,31,48))
            ThemeManager.DARK -> intArrayOf(Color.rgb(23,48,59),Color.rgb(27,43,62),Color.rgb(52,32,44))
            ThemeManager.SEPIA -> intArrayOf(Color.rgb(238,229,201),Color.rgb(228,220,191),Color.rgb(239,215,214))
            else -> intArrayOf(Color.rgb(226,243,241),Color.rgb(228,237,249),Color.rgb(247,230,233))
        }
        listOf(R.id.quickRevision,R.id.quickSubject,R.id.quickWrong).forEachIndexed{idx,id->findViewById<TextView>(id)?.apply{setTextColor(ThemeManager.text(this@MainActivity));background=GradientDrawable().apply{setColor(quickColors[idx]);cornerRadius=14f*resources.displayMetrics.density;setStroke(dp(1),if(dark)Color.rgb(54,70,84) else Color.argb(100,90,110,125))}}}
    }

    private fun applyDashboardTheme(){
        val root=findViewById<View>(R.id.dashboardRoot)
        fun walk(v:View){
            if(v.id==R.id.mainHeader || v.id==R.id.dashboardHero) return
            if(v is TextView && v !is Button) v.setTextColor(ThemeManager.text(this@MainActivity))
            if(v is ViewGroup) for(i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(root)
    }
    private fun styleDashboardCards(){
        val dark=ThemeManager.isDark(this@MainActivity)
        styleDashboardHero()
        val ids=listOf(R.id.importantButton,R.id.reviseButton,R.id.doubtButton,R.id.favoriteButton)
        ids.forEach{findViewById<View>(it)?.let{v->v.background=v.background}}
        findViewById<View>(R.id.qbankSection)?.background=GradientDrawable().apply{setColor(if(dark)Color.rgb(17,23,30) else Color.rgb(248,250,247));cornerRadius=18f*resources.displayMetrics.density;setStroke(dp(1),if(dark)Color.rgb(48,61,75) else Color.rgb(224,232,226))}
        findViewById<View>(R.id.analyticsCard)?.background=GradientDrawable().apply{setColor(if(dark)Color.rgb(17,23,30) else Color.rgb(249,251,247));cornerRadius=18f*resources.displayMetrics.density;setStroke(dp(1),if(dark)Color.rgb(48,61,75) else Color.rgb(224,232,226))}
        val border=if(dark)Color.rgb(48,61,75) else Color.rgb(218,226,231)
        val cardColors=if(dark) listOf(ThemeManager.elevated(this@MainActivity),Color.rgb(23,39,50),Color.rgb(28,36,53)) else listOf(Color.rgb(235,246,247),Color.rgb(238,243,250),Color.rgb(244,239,250))
        listOf(R.id.todaySolvedCard,R.id.studyMenuCard,R.id.flashcardCard).forEachIndexed{idx,id->findViewById<View>(id)?.background=GradientDrawable().apply{setColor(cardColors[idx]);cornerRadius=16f*resources.displayMetrics.density;setStroke(dp(1),border)}}
    }
    private fun showThemeMenu(anchor: View) {
        val dialog=Dialog(this)
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(16));setBackgroundColor(ThemeManager.dialogBg(this@MainActivity))}
        root.addView(TextView(this).apply{text="Appearance & Typography";textSize=20f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@MainActivity));setPadding(dp(6),dp(2),dp(6),dp(4))})
        root.addView(TextView(this).apply{text="Theme and quiz font in one adaptive panel";textSize=11.5f;setTextColor(ThemeManager.muted(this@MainActivity));setPadding(dp(6),0,dp(6),dp(10))})
        fun section(title:String,subtitle:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=roundedDrawable(this@MainActivity,ThemeManager.elevated(this@MainActivity),14f);addView(TextView(this@MainActivity).apply{text=title;textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(this@MainActivity))});addView(TextView(this@MainActivity).apply{text=subtitle;textSize=11f;setTextColor(ThemeManager.muted(this@MainActivity));setPadding(0,dp(3),0,dp(6))})}
        val themeCard=section("Theme","Choose the global appearance")
        val themes=linkedMapOf(ThemeManager.LIGHT to "Light",ThemeManager.DARK to "Dark",ThemeManager.SEPIA to "Sepia",ThemeManager.AMOLED to "AMOLED Black",ThemeManager.MIDNIGHT to "Midnight Blue")
        themes.forEach{(key,label)->themeCard.addView(TextView(this).apply{text=if(ThemeManager.get(this@MainActivity)==key)"✓  $label" else label;textSize=13f;gravity=Gravity.CENTER_VERTICAL;setTextColor(ThemeManager.text(this@MainActivity));background=roundedDrawable(this@MainActivity,ThemeManager.bg(this@MainActivity),10f);setPadding(dp(10),0,dp(10),0);setOnClickListener{ThemeManager.set(this@MainActivity,key);dialog.dismiss();recreate()}},LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(0,dp(3),0,dp(3))})}
        root.addView(themeCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(5))})
        val fontCard=section("Quiz font","Choose the reading style used in question solving")
        val fonts=linkedMapOf("sans-serif" to "Modern Sans","serif" to "Serif / textbook","sans-serif-condensed" to "Condensed Sans","sans-serif-light" to "Light Sans")
        val prefs=getSharedPreferences("ui",MODE_PRIVATE);val current=prefs.getString("quiz_font_family","sans-serif")?:"sans-serif"
        fonts.forEach{(key,label)->fontCard.addView(TextView(this).apply{text=if(current==key)"✓  $label" else label;textSize=13f;gravity=Gravity.CENTER_VERTICAL;setTextColor(ThemeManager.text(this@MainActivity));background=roundedDrawable(this@MainActivity,ThemeManager.bg(this@MainActivity),10f);setPadding(dp(10),0,dp(10),0);setOnClickListener{prefs.edit().putString("quiz_font_family",key).apply();dialog.dismiss();Toast.makeText(this@MainActivity,"Quiz font updated",Toast.LENGTH_SHORT).show()}},LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(0,dp(3),0,dp(3))})}
        root.addView(fontCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(4))})
        val more=TextView(this).apply{text="More settings  ›";textSize=12.5f;gravity=Gravity.CENTER_VERTICAL;setTextColor(ThemeManager.accent(this@MainActivity));setPadding(dp(12),dp(10),dp(12),dp(10));setOnClickListener{dialog.dismiss();startActivity(Intent(this@MainActivity,SettingsActivity::class.java).putExtra("section","all"))}}
        root.addView(more)
        scroll.addView(root);dialog.setContentView(scroll);dialog.show();dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.window?.setLayout(dp(350),ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    private fun setupCollection(id:Int,type:String,value:String){findViewById<View>(id).setOnClickListener{startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType",type).putExtra("filterValue",value))}}
    private fun openImporter(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/html","text/plain","application/xhtml+xml"));putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,42)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data);if(requestCode!=42||resultCode!=RESULT_OK||data==null)return
        val uris=ArrayList<android.net.Uri>();data.clipData?.let{c->for(i in 0 until c.itemCount)uris.add(c.getItemAt(i).uri)};if(uris.isEmpty())data.data?.let{uris.add(it)}
        if(uris.isNotEmpty())startActivity(Intent(this,HtmlImportActivity::class.java).putParcelableArrayListExtra("uris",uris))
    }
    override fun onDestroy(){analyticsDialog?.dismiss();analyticsDialog=null;AppState.unregister(stateListener);if(::db.isInitialized)runCatching{db.close()};super.onDestroy()}
}

class SourceAdapter(
    private val items:List<Source>,
    private val store:ProgressStore,
    private val db:QBankDb,
    private val click:(Source)->Unit,
    private val delete:(Long)->Unit
):RecyclerView.Adapter<SourceAdapter.VH>(){
    private val cache=HashMap<Long,ProgressSummary>()
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val title=TextView(v.context); val sub=TextView(v.context); val resume=TextView(v.context)
        init{
            v.orientation=LinearLayout.HORIZONTAL;v.setPadding(16,11,12,11)
            val body=LinearLayout(v.context).apply{orientation=LinearLayout.VERTICAL}
            title.textSize=16f; title.setTextColor(Color.rgb(23,32,51)); title.setTypeface(null,1); title.maxLines=2; title.ellipsize=android.text.TextUtils.TruncateAt.END
            sub.textSize=12f; sub.setTextColor(Color.rgb(82,98,117)); sub.setPadding(0,5,0,0); body.addView(title); body.addView(sub)
            v.addView(body,LinearLayout.LayoutParams(0,-2,1f))
            resume.text="RESUME";resume.textSize=11f;resume.setTypeface(null,1);resume.setTextColor(Color.rgb(25,91,111));resume.gravity=Gravity.CENTER;resume.background=GradientDrawable().apply{setColor(Color.rgb(225,243,246));cornerRadius=12f*v.resources.displayMetrics.density};resume.setPadding(10,0,10,0);v.addView(resume,LinearLayout.LayoutParams(82,42).apply{gravity=Gravity.CENTER_VERTICAL;setMargins(8,0,0,0)})
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{
        val v=LinearLayout(p.context);
        v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)}
        return VH(v)
    }
    override fun onBindViewHolder(h:VH,i:Int){
        val x=items[i]; val pr=cache.getOrPut(x.id){db.progressSummaryForSource(x.id,store)}
        h.title.text="${i + 1}. ${x.fileName}"
        h.sub.text=when {
            pr.total==0 -> "No questions"
            pr.solved==0 -> "Not started  •  ${pr.total} questions"
            pr.solved>=pr.total -> "✓ Completed  •  ${pr.solved}/${pr.total} solved"
            else -> "↻ In progress  •  ${pr.solved}/${pr.total} solved"
        }
        val resumeTarget=store.sourceResume(x.id)?.split("|",limit=2)
        val rt=resumeTarget?.getOrNull(0)?.let{db.testById(it)}
        h.resume.visibility=if(rt!=null)View.VISIBLE else View.GONE
        h.resume.setOnClickListener{ if(rt!=null) clickSourceResume(h.itemView.context,rt,store.sourceResume(x.id)?.split("|")?.getOrNull(1)?.toIntOrNull()?:0) }
        val bg=when(i%5){0->Color.rgb(235,245,255);1->Color.rgb(238,249,242);2->Color.rgb(255,245,228);3->Color.rgb(246,239,255);else->Color.rgb(255,237,241)}
        h.itemView.background=roundedDrawable(h.itemView.context,bg,18f)
        h.itemView.setOnClickListener{click(x)}
        h.itemView.setOnLongClickListener{
            AlertDialog.Builder(h.itemView.context).setTitle("Delete QBank?").setMessage("Remove ${x.fileName} and all its imported questions from Rovex?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->delete(x.id)}.show(); true
        }
    }
    private fun clickSourceResume(c:android.content.Context,t:Test,pos:Int){c.startActivity(Intent(c,QuizActivity::class.java).putExtra("testId",t.id).putExtra("title",t.title).putExtra("position",pos))}
    fun refresh(){cache.clear();notifyDataSetChanged()}
    override fun getItemCount()=items.size
}
