package com.localqbank.library

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

/** Tiered startup: only critical managers are created synchronously; heavy work remains lazy. */
object StartupCoordinator {
    private val starting = AtomicBoolean(false)
    fun initialize(context: Context) {
        // Only mark "ready" once AppManagers has actually finished. Marking it ready before
        // the call (the previous behavior) meant a single failed construction would
        // permanently prevent every later retry, leaving AppManagers.xyz lateinit access
        // throwing for the rest of the process lifetime with no way to recover.
        if (AppManagers.isReady()) return
        if (!starting.compareAndSet(false, true)) return
        try {
            AppManagers.initialize(context.applicationContext)
            // Search indexing and large QBank scans are intentionally deferred until first use.
        } finally {
            starting.set(false)
        }
    }
}
