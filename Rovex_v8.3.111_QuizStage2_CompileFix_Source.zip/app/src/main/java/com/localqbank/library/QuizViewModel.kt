package com.localqbank.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/**
 * Lifecycle owner for quiz-session data dependencies.
 *
 * The first migration deliberately keeps this ViewModel small. It owns the session persistence
 * seam and opening/routing logic while QuizActivity continues to own view construction. Later
 * stages can extract focused UI use-cases without creating a second business-logic authority.
 */
class QuizViewModel(application: Application) : AndroidViewModel(application) {
    val state = QuizUiState()
    val data = QuizSessionRepository(application)
    private val navigation = QuizNavigationUseCase(data)
    private val session = QuizSessionUseCase(application)
    private val notes = QuizNotesUseCase(data)
    private val bookmarks = QuizBookmarkUseCase(data.progress) {
        if (AppManagers.isReady()) AppManagers.adaptive.onEvent("bookmark_changed")
    }
    private val answerUseCase = QuizAnswerUseCase(data.progress, StudyStateRepository(application))
    private val flashcards = QuizFlashcardUseCase()
    private val knowledge = QuizKnowledgeUseCase()

    fun answer(question: Question, label: String, practiceMode: Boolean, examMode: Boolean): QuizAnswerUseCase.Result =
        answerUseCase.answer(question, label, practiceMode, examMode)

    fun resolveSession(
        title: String, requestedTestId: String, requestedQuestionId: Long, requestedPosition: Int,
        sessionIdsRaw: String?, collectionMode: Boolean, filterType: String, filterValue: String, sessionLabel: String?
    ): Result<QuizNavigationUseCase.SessionResolution> =
        navigation.resolve(title, requestedTestId, requestedQuestionId, requestedPosition, sessionIdsRaw, collectionMode, filterType, filterValue, sessionLabel)

    fun note(questionId: Long): String? = notes.get(questionId)
    fun saveNote(questionId: Long, value: String) = notes.save(questionId, value)
    fun appendNote(questionId: Long, value: String) = notes.append(questionId, value)
    fun bookmark(stableKey: String): String? = bookmarks.current(stableKey)
    fun setBookmark(stableKey: String, value: String?) = bookmarks.set(stableKey, value)
    fun mistakeType(stableKey: String): String? = bookmarks.mistakeType(stableKey)
    fun setMistakeType(stableKey: String, value: String?) = bookmarks.setMistakeType(stableKey, value)
    fun createFlashcard(questionId: Long, contextLabel: String, onResult: (FlashcardIntelligenceManager.Result) -> Unit) =
        flashcards.createFromQuestion(questionId, contextLabel, onResult)

    fun captureQuestionToKnowledge(question: Question, reason: String, onDone: (KnowledgeEngineManager.Result) -> Unit) =
        knowledge.captureQuestion(question, reason, onDone)

    fun saveKnowledgeImage(raw: String, questionId: Long, onDone: (Boolean) -> Unit) =
        knowledge.saveImage(raw, questionId, onDone)

    fun saveKnowledgeImageWithNote(raw: String, questionId: Long, note: String, onDone: (Boolean) -> Unit) =
        knowledge.saveImageWithNote(raw, questionId, note, onDone)

    fun existingQuestionIds(ids: LongArray): LongArray = data.existingQuestionIds(ids)
    fun questionById(id: Long): Question? = data.questionById(id)
    fun questionAt(testId: String, position: Int): Question? = data.questionAt(testId, position)
    fun testIdForQuestion(questionId: Long): String = data.testIdForQuestion(questionId).orEmpty()
    fun sourceIdForTest(testId: String): Long = data.sourceIdForTest(testId)
    fun sourceNameForTest(testId: String): String? = data.sourceNameForTest(testId)
    fun questionCount(testId: String): Int = data.questionCount(testId)
    fun rawQuestionPosition(testId: String, questionId: Long): Int? = data.rawQuestionPosition(testId, questionId)
    fun progressStatus(stableKey: String): String? = data.progress.status(stableKey)
    fun selectedAnswer(stableKey: String): String? = data.progress.selected(stableKey)
    fun addTime(stableKey: String, elapsedMs: Long) = data.progress.addTime(stableKey, elapsedMs)
    fun sessionKey(label: String?, title: String, testId: String, collectionMode: Boolean): String = session.sessionKey(label, title, testId, collectionMode)
    fun saveSessionCursor(key: String, testId: String, position: Int, stableKey: String?) = session.saveCursor(key, testId, position, stableKey)
    fun checkpoint(testId: String, position: Int, stableKey: String?, sessionLabel: String?) = session.checkpoint(testId, position, stableKey, sessionLabel)
    fun savePosition(testId: String, position: Int, sourceId: Long, bankName: String) {
        if (testId.isNotBlank()) data.progress.setPosition(testId, position, sourceId, bankName)
    }

    fun findTestIdForQuestion(questionId: Long): String = data.testIdForQuestion(questionId).orEmpty()
    fun moveToPosition(position: Int) {
        setPosition(position)
        persistPosition()
    }

    fun persistPosition() {
        if (state.collectionMode || state.testId.isBlank()) return
        data.progress.setPosition(state.testId, state.position, state.sourceId, state.bankName)
    }

    fun persistSessionCursor() {
        saveSessionCursor(
            sessionKey(state.sessionLabel, state.title, state.testId, state.collectionMode),
            state.testId, state.position, state.currentQuestion?.stableKey
        )
    }

    fun checkpointSession() {
        checkpoint(state.testId, state.position, state.currentQuestion?.stableKey, state.sessionLabel)
    }

    fun recordElapsedTime(stableKey: String, elapsedMs: Long) {
        if (stableKey.isBlank() || elapsedMs <= 0L) return
        data.progress.addTime(stableKey, elapsedMs)
    }


    fun configureSession(
        title: String,
        requestedTestId: String,
        collectionMode: Boolean,
        examMode: Boolean,
        examDurationMinutes: Int,
        practiceMode: Boolean,
        sessionLabel: String?,
        sectionLabel: String?
    ) {
        state.title = title
        state.testId = requestedTestId
        state.collectionMode = collectionMode
        state.examMode = examMode
        state.examDurationMinutes = examDurationMinutes
        state.practiceMode = practiceMode
        state.sessionLabel = sessionLabel
        state.sectionLabel = sectionLabel
        state.resetForNewSession()
    }

    fun applyResolution(resolution: QuizNavigationUseCase.SessionResolution) {
        state.testId = resolution.testId
        state.sourceId = resolution.sourceId
        state.questionCount = resolution.questionCount
        state.position = resolution.position
        state.collectionQuestionIds = resolution.collectionIds
        state.bankName = state.sessionLabel ?: resolution.bankName
    }

    fun setCurrentQuestion(question: Question?) { state.currentQuestion = question }
    fun setPosition(position: Int) { state.position = position.coerceIn(0, (state.questionCount - 1).coerceAtLeast(0)) }
    fun setPracticeAnsweredKey(key: String?) { state.practiceAnsweredKey = key }
    fun setExamRemainingMs(value: Long) { state.examRemainingMs = value.coerceAtLeast(0L) }
    fun recordExamAnswer(key: String, correct: Boolean) { state.examAnswers[key] = correct }
    fun examAttemptedCount(): Int = state.examAnswers.size
    fun examCorrectCount(): Int = state.examAnswers.values.count { it }

    override fun onCleared() {
        data.close()
        super.onCleared()
    }
}
