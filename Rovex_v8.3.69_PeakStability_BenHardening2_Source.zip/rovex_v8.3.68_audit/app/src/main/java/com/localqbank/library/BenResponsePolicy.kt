package com.localqbank.library

/** Deterministic bounds for text returned by an optional local Ben backend. */
object BenResponsePolicy {
    const val MAX_RESPONSE_CHARS = 16_384

    fun normalize(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val bounded = if (raw.length > MAX_RESPONSE_CHARS) raw.substring(0, MAX_RESPONSE_CHARS) else raw
        return bounded.trim().takeIf { it.isNotEmpty() }
    }
}
