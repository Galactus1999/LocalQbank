package com.localqbank.library

/** Deterministic, allocation-bounded input policy for Ben's local research gateway. */
object BenResearchInputPolicy {
    const val MAX_QUERY_CHARS = 4096

    fun normalize(raw: String): String? {
        if (raw.isEmpty()) return null
        // Bound both output size and scan work. Do not walk an arbitrarily large pasted payload.
        val bounded = if (raw.length > MAX_QUERY_CHARS) raw.substring(0, MAX_QUERY_CHARS) else raw
        val clean = buildString(bounded.length) {
            var pendingSpace = false
            for (ch in bounded) {
                when {
                    ch.isISOControl() && ch != '\n' && ch != '\t' -> Unit
                    ch.isWhitespace() -> pendingSpace = true
                    else -> {
                        if (pendingSpace && isNotEmpty()) append(' ')
                        pendingSpace = false
                        append(ch)
                    }
                }
            }
        }.trim()
        if (clean.isEmpty()) return null
        return clean.take(MAX_QUERY_CHARS).trimEnd()
    }
}
