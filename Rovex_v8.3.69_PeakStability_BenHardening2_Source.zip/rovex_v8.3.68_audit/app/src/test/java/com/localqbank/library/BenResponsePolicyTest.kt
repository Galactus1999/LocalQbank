package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BenResponsePolicyTest {
    @Test fun blankResponseIsRejected() { assertNull(BenResponsePolicy.normalize("  \n\t")) }

    @Test fun responseIsTrimmed() { assertEquals("clinical answer", BenResponsePolicy.normalize("  clinical answer  ")) }

    @Test fun oversizedResponseIsBounded() {
        val result = BenResponsePolicy.normalize("x".repeat(BenResponsePolicy.MAX_RESPONSE_CHARS + 500))
        assertEquals(BenResponsePolicy.MAX_RESPONSE_CHARS, result?.length)
    }
}
