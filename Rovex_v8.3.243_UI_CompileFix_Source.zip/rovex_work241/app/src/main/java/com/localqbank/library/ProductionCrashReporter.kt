package com.localqbank.library

import android.content.Context
import android.content.pm.PackageManager
import com.google.firebase.crashlytics.FirebaseCrashlytics

/** Privacy-bounded production diagnostics. Never records question text, answers, notes, or API keys. */
object ProductionCrashReporter {
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        initialized = true
        runCatching {
            val c = FirebaseCrashlytics.getInstance()
            c.setCustomKey("rovex_version", runCatching {
                context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown"
            }.getOrDefault("unknown"))
            c.setCustomKey("sdk", android.os.Build.VERSION.SDK_INT)
            c.setCustomKey("device", android.os.Build.MODEL.take(80))
            c.setCustomKey("ben_inference_process", false)
        }
    }

    fun recordNonFatal(throwable: Throwable, stage: String, details: Map<String, String> = emptyMap()) {
        runCatching {
            val c = FirebaseCrashlytics.getInstance()
            c.setCustomKey("rovex_stage", stage.take(80))
            details.forEach { (k, v) ->
                if (k.length <= 40) c.setCustomKey(k, v.take(120))
            }
            c.recordException(throwable)
        }
    }
}
