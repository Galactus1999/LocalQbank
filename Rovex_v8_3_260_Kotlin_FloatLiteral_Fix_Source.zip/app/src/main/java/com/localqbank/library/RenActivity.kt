package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Chat-first Dr. Frankenstein workspace. Detailed diagnostics live in Model Lab / Adaptive Engine. */
class RenActivity : Activity() {
    private var openMatchButton: TextView? = null
    private var liveStatus: TextView? = null
    private val liveScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var liveJob: Job? = null
    private var cloudJob: Job? = null
    private var contextCard: LinearLayout? = null
    private var promptInput: EditText? = null
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(build())
    }

    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            background=ThemeManager.backgroundDrawable(this@RenActivity)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(42), dp(48)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6),0,dp(6),0) }
        titleBox.addView(TextView(this).apply { text="Dr. Frankenstein"; textSize=22f; typeface=Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RenActivity)) })
        titleBox.addView(TextView(this).apply { text="Local study intelligence"; textSize=11f; setTextColor(ThemeManager.muted(this@RenActivity)) })
        header.addView(titleBox, LinearLayout.LayoutParams(0,-2,1f))
        val lab = TextView(this).apply {
            text = "MODEL LAB"; textSize=10.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.elevated(this@RenActivity),12f)
            setPadding(dp(10),0,dp(10),0); setOnClickListener { startActivity(Intent(this@RenActivity, BenModelLabActivity::class.java)) }
        }
        header.addView(lab, LinearLayout.LayoutParams(dp(96),dp(48)))
        root.addView(header)

        val modelPill = TextView(this).apply {
            text = modelStatus(); textSize=11f; gravity=Gravity.CENTER_VERTICAL
            setTextColor(ThemeManager.muted(this@RenActivity)); setPadding(dp(10),0,dp(10),0)
            background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.elevated(this@RenActivity),11f)
        }
        root.addView(modelPill, LinearLayout.LayoutParams(-1,dp(30)).apply{setMargins(dp(4),dp(3),dp(4),dp(4))})

        val brainMode = TextView(this).apply {
            text = BenModelRouter(applicationContext).uiSummary()
            textSize = 10.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(ThemeManager.muted(this@RenActivity))
            setPadding(dp(10),0,dp(10),0)
            background = UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.bg(this@RenActivity),11f)
            contentDescription = "Ben model router status"
        }
        root.addView(brainMode, LinearLayout.LayoutParams(-1,dp(27)).apply{setMargins(dp(4),0,dp(4),dp(4))})
        val memoryControl = TextView(this).apply {
            text = memoryStatusLabel()
            textSize = 9.5f; gravity = Gravity.CENTER_VERTICAL; setTextColor(ThemeManager.muted(this@RenActivity)); setPadding(dp(8),0,dp(8),0)
            setOnClickListener {
                AlertDialog.Builder(this@RenActivity).setTitle("Clear Frankenstein context?")
                    .setMessage("This removes the bounded Frankenstein chat continuity. QBank data, answers and study history are not deleted.")
                    .setNegativeButton("CANCEL",null).setPositiveButton("CLEAR") { _, _ ->
                        AppManagers.renMemory.clearChatContext()
                    text = memoryStatusLabel()
                    Toast.makeText(this@RenActivity,"Frankenstein chat cleared",Toast.LENGTH_SHORT).show()
                    }.show()
            }
        }
        root.addView(memoryControl, LinearLayout.LayoutParams(-1,dp(25)).apply{setMargins(dp(4),0,dp(4),dp(3))})

        contextCard = buildFrankensteinContextCard()
        root.addView(contextCard, LinearLayout.LayoutParams(-1, dp(92)).apply { setMargins(dp(4), 0, dp(4), dp(5)) })

        val answerScroll = ScrollView(this).apply { isFillViewport=true; clipToPadding=false }
        val chatSurface = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(2),dp(2),dp(2),dp(8)) }
        val answer = TextView(this).apply {
            text="Local Ben first • EmbeddingGemma retrieval • Gemma 3 270M generation • optional Free AI"
            textSize=16f; setTextColor(ThemeManager.text(this@RenActivity)); setPadding(dp(18),dp(18),dp(18),dp(20))
            background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@RenActivity));cornerRadius=22f*resources.displayMetrics.density;setStroke(dp(1),ThemeManager.accent(this@RenActivity))}; gravity=Gravity.TOP; setLineSpacing(0f,1.22f)
        }
        chatSurface.addView(answer, LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(8))})
        answerScroll.addView(chatSurface, android.widget.FrameLayout.LayoutParams(-1,-2))
        root.addView(answerScroll, LinearLayout.LayoutParams(-1,0,1f))
        liveStatus = TextView(this).apply {
            text="BEN • READY"; textSize=10.5f; setTextColor(ThemeManager.muted(this@RenActivity)); setPadding(dp(4),dp(5),dp(4),dp(5))
        }
        root.addView(liveStatus, LinearLayout.LayoutParams(-1,dp(28)))

        val input = EditText(this).apply {
            hint="Ask Dr. Frankenstein…"; textSize=15f; setTextColor(ThemeManager.text(this@RenActivity)); setHintTextColor(ThemeManager.muted(this@RenActivity))
            setSingleLine(false); minLines=2; maxLines=4; gravity=Gravity.TOP; setPadding(dp(16),dp(12),dp(16),dp(12))
            background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.elevated(this@RenActivity),16f)
        }
        promptInput = input
        root.addView(input, LinearLayout.LayoutParams(-1,dp(78)).apply{setMargins(0,dp(2),0,dp(8))})

        val core=TextView(this).apply{
            text="BEN + FREE AI"; textSize=13f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(Color.WHITE); background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.accent(this@RenActivity),16f)
            contentDescription="Run Ben with a configured free AI provider"
            setOnClickListener{runCombinedCore(input,answer,modelPill)}
        }
        root.addView(core,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(2),0,dp(7))})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        openMatchButton=TextView(this).apply{ text="MATCH"; textSize=11f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); visibility=View.GONE; background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.accent(this@RenActivity),13f) }
        row.addView(openMatchButton,LinearLayout.LayoutParams(dp(78),dp(46)).apply{setMargins(0,0,dp(6),0)})
        val ask=TextView(this).apply{ text="ASK BEN"; textSize=12f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.accent(this@RenActivity),14f); setOnClickListener{respond(input,answer,modelPill)} }
        row.addView(ask,LinearLayout.LayoutParams(0,dp(46),1f).apply{weight=1f})
        val freeAi=TextView(this).apply{
            text="FREE AI"; textSize=10.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.elevated(this@RenActivity),14f)
            contentDescription="Open Free AI provider menu"; setOnClickListener{showFreeAiMenu()}
        }
        row.addView(freeAi,LinearLayout.LayoutParams(dp(78),dp(46)).apply{setMargins(dp(6),0,dp(4),0)})
        val search=TextView(this).apply{
            text="SEARCH"; textSize=10.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); background=UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.elevated(this@RenActivity),14f)
            contentDescription="Search the web for the current study request"; setOnClickListener{openWebSearch(input.text?.toString().orEmpty())}
        }
        row.addView(search,LinearLayout.LayoutParams(dp(72),dp(46)).apply{setMargins(0,0,dp(4),0)})
        root.addView(row)

        // Android 15+/API 36 edge-to-edge can ignore the legacy resize hint. Apply the IME
        // inset directly to the chat surface so the composer and its typed text always remain
        // above the keyboard. This also keeps the last lines visible while the user types.
        val baseLeft=root.paddingLeft;val baseTop=root.paddingTop;val baseRight=root.paddingRight;val baseBottom=root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root){_,insets->
            val ime=insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            val bottom=baseBottom+(if(ime>bars)ime else bars)
            root.setPadding(baseLeft,baseTop,baseRight,bottom)
            if(ime>0){
                input.post{
                    val r=Rect(0,0,input.width,input.height)
                    input.requestRectangleOnScreen(r,true)
                }
            }
            insets
        }
        ViewCompat.requestApplyInsets(root)
        input.setOnFocusChangeListener{_,hasFocus->
            if(hasFocus) input.post{input.requestRectangleOnScreen(Rect(0,0,input.width,input.height),true)}
        }
        return root
    }

    private fun memoryStatusLabel(): String {
        val chat = if (AppManagers.renMemory.chatContext().isBlank()) "EMPTY" else "READY"
        return "CHAT MEMORY • $chat • CLEAR"
    }


    private fun buildFrankensteinContextCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply{setColor(ThemeManager.elevated(this@RenActivity));cornerRadius=18f*resources.displayMetrics.density;setStroke(dp(1),ThemeManager.accent(this@RenActivity))}
        }
        val title = TextView(this).apply {
            text = "🧠 FRANKENSTEIN CONTEXT"
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@RenActivity))
        }
        card.addView(title)
        val summary = TextView(this).apply {
            text = "Ready • local QBank + learner memory + notes"
            textSize = 11f
            setTextColor(ThemeManager.muted(this@RenActivity))
            setPadding(0, dp(3), 0, dp(5))
        }
        card.addView(summary)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun chip(label: String, action: () -> Unit): TextView = TextView(this).apply {
            text = label; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); setBackground(UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.bg(this@RenActivity),12f))
            setPadding(dp(9), 0, dp(9), 0); setOnClickListener { action() }
        }
        val inspect = chip("INSPECT") {
            val prompt = "Build my Frankenstein Context for this study request: ${currentPromptForContext().take(2500)}"
            if (prompt.endsWith(":")) Toast.makeText(this, "Enter a topic first", Toast.LENGTH_SHORT).show()
            else showFrankensteinContext(prompt.removePrefix("Build my Frankenstein Context for this study request: "))
        }
        val local = chip("LOCAL") { showFrankensteinContext(currentPromptForContext()) }
        val weak = chip("WEAKNESS") { showWeaknessContext() }
        chips.addView(inspect, LinearLayout.LayoutParams(0, dp(32), 1f).apply { setMargins(0, 0, dp(5), 0) })
        chips.addView(local, LinearLayout.LayoutParams(0, dp(32), 1f).apply { setMargins(0, 0, dp(5), 0) })
        chips.addView(weak, LinearLayout.LayoutParams(0, dp(32), 1f))
        card.addView(chips)
        return card
    }

    private fun currentPromptForContext(): String = promptInput?.text?.toString()?.trim().orEmpty()

    private fun showFrankensteinContext(query: String) {
        if (query.isBlank()) { Toast.makeText(this, "Enter a topic or question first", Toast.LENGTH_SHORT).show(); return }
        liveScope.launch(Dispatchers.IO) {
            val context = try {
                AppManagers.frankensteinContext.buildEnhanced(
                    Question(0L, "context", 0, null, query, query, null, null, null, null, null, emptyList(), emptyList(), emptyList())
                )
            } catch (t: CancellationException) {
                throw t
            } catch (_: Exception) { null }
            val local = try { AppManagers.benBrain.answer(query) } catch (_: Exception) { null }
            val concepts = context?.concepts.orEmpty().ifEmpty { local?.plan?.concepts.orEmpty() }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val message = buildString {
                    append("LOCAL CONTEXT\n\n")
                    append("Concepts: ").append(concepts.take(6).joinToString(", ").ifBlank { "not confidently mapped" }).append("\n")
                    append("Related questions: ").append(context?.relatedQuestions?.size ?: 0).append("\n")
                    append("Source clusters: ").append(context?.relatedSources?.joinToString(" • ").ifNullOrBlank("none found")).append("\n")
                    local?.plan?.specialist?.let { append("Specialist: ").append(it).append("\n") }
                    local?.confidence?.let { append("Local confidence: ").append(it).append("/100\n") }
                    append("\nThis is the bounded context Ben can hand to the selected Free AI accelerator. Your QBank answer and study state remain authoritative.")
                }
                AlertDialog.Builder(this@RenActivity).setTitle("Frankenstein Context").setMessage(message).setPositiveButton("OK", null).show()
            }
        }
    }

    private fun String?.ifNullOrBlank(fallback: String): String = if (this.isNullOrBlank()) fallback else this

    private fun showWeaknessContext() {
        val text = currentPromptForContext()
        if (text.isBlank()) { Toast.makeText(this, "Ask Ben a topic first so I can inspect your weak concepts", Toast.LENGTH_SHORT).show(); return }
        liveScope.launch(Dispatchers.IO) {
            val local = runCatching { AppManagers.benBrain.answer(text) }.getOrNull()
            val concepts = local?.plan?.concepts.orEmpty()
            val model = AppManagers.benBrain.learner()
            val rows = concepts.map { it to model.stats(it) }.sortedBy { it.second.mastery }.take(5)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                AlertDialog.Builder(this@RenActivity)
                    .setTitle("Your local weakness map")
                    .setMessage(rows.joinToString("\n") { (c, s) -> "${s.mastery}% • $c • ${s.wrong} wrong / ${s.seen} seen" }.ifBlank { "No weakness data yet." })
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    private fun modelStatus(): String {
        val m=BenNeuralModelManager(this)
        val e=m.installed(BenNeuralModelRegistry.embeddingGemma300m)!=null
        val g=m.installed(BenNeuralModelRegistry.gemma3_270m)!=null
        return when { e&&g -> "Neural: EmbeddingGemma + Gemma 3 270M ready"; e -> "Neural: EmbeddingGemma installed • generation fallback"; g -> "Neural: Gemma 3 270M installed • semantic fallback"; else -> "Neural: models not installed • deterministic Ben ready" }
    }

    private fun respond(input:EditText,answer:TextView,modelPill:TextView){
        val cmd=input.text?.toString().orEmpty().trim()
        openMatchButton?.visibility=View.GONE
        if(cmd.isBlank()){answer.text="Ask Ben a question first.";return}
        AppManagers.renMemory.putWorking(cmd)
        AppManagers.renMemory.appendChatTurn("USER", cmd)
        answer.text="Ben is working…"
        liveJob?.cancel()
        liveJob=liveScope.launch{
            while(isActive){
                val t=BenNeuralTelemetry.snapshot()
                val gov=BenAiResourceGovernor(this@RenActivity).snapshot(foreground=true)
                liveStatus?.text="BEN • ${t.stage.name.replace('_',' ')} • ${t.stageDetail}"
                modelPill.text="${t.activeModel} • RAM ${gov.availableMemoryMb} MB • thermal ${gov.thermalStatus}"
                if(t.stage==BenNeuralTelemetry.Stage.COMPLETE||t.stage==BenNeuralTelemetry.Stage.FALLBACK||t.stage==BenNeuralTelemetry.Stage.ERROR||t.stage==BenNeuralTelemetry.Stage.BLOCKED) break
                delay(180L)
            }
        }
        AppManagers.frankensteinSupport.respond(cmd){ insight, ids ->
            runOnUiThread{
                liveJob?.cancel()
                val t=BenNeuralTelemetry.snapshot()
                liveStatus?.text="BEN • ${if(t.lastGeneratorUsed||t.lastSemanticUsed) "NEURAL" else "DETERMINISTIC FALLBACK"} • ${t.lastElapsedMs} ms"
                modelPill.text="${t.activeModel} • evidence ${t.lastEvidenceCount} • verifier ${if(t.lastVerified) "PASS" else "REVIEW"}"
                if(isFinishing||isDestroyed)return@runOnUiThread
                answer.text=rovexMarkdownToSpanned(insight.body)
                if(insight.actions.contains("Open matching questions")&&ids.isNotEmpty()){
                    openMatchButton?.visibility=View.VISIBLE
                    val query=cmd.replace(Regex("(?i)\\b(find|search|show|give|open|questions?|qbank|topic|subject|about)\\b")," ").replace(Regex("\\s+")," ").trim()
                    openMatchButton?.setOnClickListener{startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Dr. Frankenstein • $query").putExtra("practiceMode",true).putExtra("title","Dr. Frankenstein • $query"))}
                }
                AppManagers.renMemory.putStudy(answer.text.toString())
                AppManagers.renMemory.appendChatTurn("BEN", insight.body)
            }
        }
    }

    private fun runCombinedCore(input:EditText, answer:TextView, modelPill:TextView){
        val cmd=input.text?.toString().orEmpty().trim()
        if(cmd.isBlank()){answer.text="Ask a clinical/study question first.";return}
        cloudJob?.cancel()
        answer.text="Ben is preparing local evidence, then routing to Free AI…"
        liveStatus?.text="BEN • LOCAL → FREE AI"
        cloudJob=liveScope.launch(Dispatchers.IO){
            val local=runCatching{AppManagers.benBrain.answer(cmd)}.getOrNull()
            val route=BenModelRouter(applicationContext).route(cmd)
            if(route.mode==BenModelRouter.Mode.LOCAL || !route.cloudEligible){
                runOnUiThread{if(!isFinishing&&!isDestroyed){answer.text=local?.answer?.takeIf{it.isNotBlank()} ?: "Ben could not produce a local answer.";modelPill.text=route.label;liveStatus?.text="BEN • LOCAL • ${route.reason}"}}
                return@launch
            }
            val context=runCatching{
                AppManagers.frankensteinContext.build(Question(0L,"context",0,null,cmd,cmd,null,null,null,null,null,emptyList(),emptyList(),emptyList())).promptBlock()
            }.getOrDefault("No bounded local context was available.")
            val prompt=buildString{
                append(benExamPromptContext(applicationContext)).append("\n\n")
                append("RECENT CHAT CONTINUITY (may be empty):\n").append(AppManagers.renMemory.chatContext()).append("\n\n")
                append("USER REQUEST:\n").append(cmd.take(5000)).append("\n\n")
                append(context.take(9000)).append("\n\n")
                append("Use local evidence as supporting context. Do not claim web search. Do not override the QBank keyed answer. Explain why plausible distractors are wrong when relevant. Treat recent chat continuity as conversational context, never as authoritative medical evidence.")
            }
            val result=AppManagers.cloudAi.generate(prompt=prompt,system="You are a free cloud reasoning accelerator inside Rovex Ben. Produce concise exam-oriented medical reasoning. Never pretend you searched the web. Treat deterministic QBank evidence and Ben verification as authoritative.",maxTokens=1600)
            runOnUiThread{
                if(isFinishing||isDestroyed)return@runOnUiThread
                if(result!=null){
                    answer.text=rovexMarkdownToSpanned("${result.text}\n\n[${result.provider.label} • ${result.model}]")
                    modelPill.text="${result.provider.label} • ${result.model}"
                    liveStatus?.text="BEN • FREE AI • LOCAL CONTEXT SUPPLIED"
                    AppManagers.renMemory.putStudy(answer.text.toString())
                    AppManagers.renMemory.appendChatTurn("BEN", result.text)
                }else{
                    answer.text=local?.answer?.takeIf{it.isNotBlank()} ?: "No Free AI provider is connected. Tap FREE AI to connect OpenRouter or Groq."
                    modelPill.text="FREE AI unavailable • deterministic fallback"
                    liveStatus?.text="BEN • DETERMINISTIC FALLBACK"
                }
            }
        }
    }

    private fun showFreeAiMenu() { BenFreeAiDialog(this, liveScope).show() }

    private fun openWebSearch(query:String){
        val clean=query.trim().ifBlank{"medical study question"}
        val q="${currentBenExamProfile(this).label} medical exam context: $clean"
        startActivity(Intent(this,GoogleSearchActivity::class.java).putExtra("query",q))
    }

    override fun onDestroy(){liveJob?.cancel();cloudJob?.cancel();liveScope.cancel();super.onDestroy()}
}
