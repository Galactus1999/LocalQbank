# Rovex v8.3.580 — LargeHtmlScanner Repair Audit

## Evidence baseline

CI run: 37575529218
Commit: 97113829039a1a97dfa338ddacd102e798996356
Selected archive: Rovex_v8.3.579_LargeHtmlScanner_PermanentBoundaryRepair_Source.zip
Selected archive SHA-256: 47f1e42013ace5a965455883189c9cdf5863009a04fd00786f486822bc4bab07
CI result: FAILED
Task: :app:testDebugUnitTest
Tests: 152 completed, 10 failed

## Failure cluster

All 10 failures were LargeHtmlScannerRegressionTest cases:
- explicitJsonNullDoesNotMaskQuestionAndOptionAliases
- assignmentInsideJavascriptCommentDoesNotHijackScanner
- quotedFakeAssignmentDoesNotHijackScanner
- windowQualifiedQuestionAliasIsRecognized
- blockCommentAssignmentDoesNotHijackScanner
- testArrayEmitsFirstQuestion
- rootQuestionArrayEmitsFirstQuestion
- declarationAndWhitespaceVariantsAreRecognized
- rootQuestionArrayUsesQuestionAliasWhenTextAliasesAreAbsent
- identifierSubstringCannotHijackSupportedAlias

## Shared root cause

The JVM unit-test runtime lacked a real JVM implementation of Android framework org.json. Production scanner parsing therefore failed at the JSON boundary.

Non-root test objects were silently discarded by parseCandidate's recoverable exception path, yielding assertion failures.

Root-question tests entered parseRootQuestion's exception path, where Android framework Log.w could itself throw under local JVM stubs, yielding RuntimeException.

This pattern accounts for all 10 failures without requiring ten independent scanner defects.

## Repair evidence

- test-only org.json dependency added at 20260719.
- direct JVM JSON runtime regression test added.
- root-question diagnostic logging made defensive.
- LargeHtmlScanner lexical boundary and normalization logic preserved.
- obsolete version-specific build-ben-qbank-579 workflow removed from repaired source package.

## Local verification

Exact Gradle task attempted:
`./gradlew :app:testDebugUnitTest --tests com.localqbank.library.LargeHtmlScannerRegressionTest --no-daemon --stacktrace`

Result: BLOCKED before Gradle execution because `downloads.gradle.org` DNS could not be resolved.

Standalone JVM harness:
10/10 representative CI cases PASS.

## Static correlated audit

- LargeHtmlScanner assignment regex search: no production assignment detector duplicate found.
- JSONObject.NULL / opt / isNull patterns: reviewed across production sources; no duplicate LargeHtmlScanner alias normalizer found.
- Worker idle/backoff incompatibility: no source file contains both `setRequiresDeviceIdle(true)` and `setBackoffCriteria(...)`.
- applicationId preserved.
- versionName/versionCode updated coherently to 8.3.580 / 666.
- stale active v8.3.579 workflow removed from the repaired package.
- no change to QBankDb ownership or Ben architecture.

## Status

Source repair: STATIC AUDIT PASS
Standalone scanner harness: PASS
Android unit test: BLOCKED
Android BUILD: PENDING
CI: PENDING
Device: PENDING
