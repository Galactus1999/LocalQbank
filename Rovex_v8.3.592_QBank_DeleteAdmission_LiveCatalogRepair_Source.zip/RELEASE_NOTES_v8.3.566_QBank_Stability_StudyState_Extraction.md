# Rovex v8.3.566 — QBank Stability + Study-State Extraction

## Priority
QBankDb / QBank recovery only. Visual/interaction overhaul is intentionally deferred to a later release.

## P0 crash repair
Fixed the startup crash reported by device logcat:
`IllegalArgumentException: Cannot set backoff criteria on an idle mode job`.

Root cause: `QBankDeletionRecoveryWorker` combined `setRequiresDeviceIdle(true)` with WorkManager `setBackoffCriteria(...)`, which AndroidX WorkManager rejects while building the request. The recovery request remains DeviceIdle-constrained but no longer configures incompatible WorkManager backoff.

## Build/instrumented-log repairs
- `foregroundInterruptionBetweenQuestionBatchesLeavesDurableRecoveryBoundary` was asserting physical remaining rows through `questionCount()`, whose production contract intentionally hides tombstoned sources. The regression test now checks the physical question table directly for the deleted source while retaining the public read-side visibility assertion for the unrelated source.
- Added `QBankStudyStateExtractionTest` to exercise the new study-state component through the real QBankDb facade.
- The EmbeddingGemma instrumented assumption remains an environment/device capability gate; it is not converted into a production dependency.

## QBankDb Stage 4
Extracted durable Study-State/Progress SQL from QBankDb into `QBankStudyStateStore`, while keeping QBankDb as the compatibility facade and authoritative public database boundary.

Extracted responsibilities:
- progress_v2 read/write/delete and bulk replacement
- progress_meta access and atomic resume metadata transaction
- study streak state and notification/reminder state
- Home progress/bookmark aggregates
- append-only study-attempt history and reconciliation

Preserved:
- shared QBankDatabaseProvider ownership
- existing QBankDb public method signatures
- existing SQL semantics
- source-scoped visibility/tombstone joins
- transactional progress/resume writes
- immutable study-attempt history semantics

## Explicitly deferred
No theme, animation, touch-sound, home visual, border, or color-grading overhaul is included in this release.

## Verification boundary
- Static delimiter/source inspection: PASS
- Local Gradle compilation: BLOCKED because Gradle 9.3.1 cannot resolve `downloads.gradle.org` in the current environment.
- CI build/device validation: PENDING until GitHub Actions/device execution.
- This source package must not be described as CI-green or device-verified until those gates pass.
