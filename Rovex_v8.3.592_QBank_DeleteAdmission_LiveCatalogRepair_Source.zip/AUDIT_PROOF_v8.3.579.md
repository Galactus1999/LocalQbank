# Rovex v8.3.579 — LargeHtmlScanner Permanent Assignment-Boundary Repair

## Authoritative CI failure
The uploaded `logs_101783705550.zip` selected the exact v8.3.578 archive (SHA-256 `8b72eb5fea918aa9154dbb397e909cdd0ba4a0bae640662ceb81c634d8dcf525`).
It completed compilation and failed `:app:testDebugUnitTest`: 147 tests completed, 5 failed, all in `LargeHtmlScannerRegressionTest`.

Failures:
- explicitJsonNullDoesNotMaskQuestionAndOptionAliases
- assignmentInsideJavascriptCommentDoesNotHijackScanner
- testArrayEmitsFirstQuestion
- rootQuestionArrayEmitsFirstQuestion
- rootQuestionArrayUsesQuestionAliasWhenTextAliasesAreAbsent

## Root-cause correction
The previous repairs repeatedly changed regex escaping while leaving the critical JavaScript assignment boundary dependent on regex matching. v8.3.579 removes regex from that boundary entirely.

The scanner now:
1. lexically removes comments and quoted/template strings;
2. checks only when the actual opening `[` is encountered;
3. extracts the immediately preceding identifier and `=`;
4. validates the identifier against the supported alias set;
5. accepts const/let/var, window-qualified assignments, and arbitrary whitespace/newlines;
6. rejects identifier-substring collisions.

## Regression coverage added
- existing five CI regressions
- block-comment fake assignment
- quoted fake assignment
- window-qualified alias
- multiline declaration/whitespace
- identifier-substring collision

## Similar-error audit
- No remaining LargeHtmlScanner assignment regex.
- No second production `TESTS_LIST`/`QUESTIONS_DATA` assignment detector found.
- No worker `setRequiresDeviceIdle(true)` + `setBackoffCriteria(...)` combination found.
- Package/applicationId preserved.
- versionName 8.3.579 / versionCode 665.
- CI/device/build PASS is not claimed.
