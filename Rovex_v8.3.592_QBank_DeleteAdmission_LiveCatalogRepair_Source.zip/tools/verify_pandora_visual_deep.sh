#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
THEME="$ROOT/app/src/main/java/com/localqbank/library/ThemeManager.kt"
SETTINGS="$ROOT/app/src/main/java/com/localqbank/library/SettingsScreen.kt"
ATM="$ROOT/app/src/main/java/com/localqbank/library/ThemeAtmosphereDrawable.kt"
LOAD="$ROOT/app/src/main/java/com/localqbank/library/QBankLoadingEngine.kt"
DB="$ROOT/app/src/main/java/com/localqbank/library/QBankDb.kt"
BUILD="$ROOT/app/build.gradle.kts"
fail(){ echo "FAIL: $*" >&2; exit 1; }

grep -Fq 'PANDORA->Color.rgb(3,10,27)' "$THEME" || fail 'Pandora background palette missing'
grep -Fq 'PANDORA->Color.rgb(6,22,38)' "$THEME" || fail 'Pandora panel palette missing'
grep -Fq 'PANDORA->Color.rgb(10,32,48)' "$THEME" || fail 'Pandora elevated palette missing'
grep -Fq 'PANDORA->Color.rgb(91,255,203)' "$THEME" || fail 'Pandora accent palette missing'
grep -Fq 'PANDORA->Color.rgb(125,238,255)' "$THEME" || fail 'Pandora peacock text contrast repair missing'
grep -Fq 'PANDORA->Color.rgb(7,25,48)' "$SETTINGS" || fail 'Pandora settings swatch still uses old green'

grep -Fq 'private fun drawAuroraVeils' "$ATM" || fail 'Aurora veil renderer missing'
grep -Fq 'private fun drawLuminousTerrain' "$ATM" || fail 'Luminous terrain renderer missing'
grep -Fq 'private fun bioPetalPath' "$ATM" || fail 'Bezier petal geometry missing'
grep -Fq 'private fun elegantTree' "$ATM" || fail 'Path-based tree renderer missing'
grep -Fq 'private fun bioFlower' "$ATM" || fail 'Bioluminescent flower renderer missing'
grep -Fq 'private fun mountainRange' "$ATM" || fail 'Curved mountain renderer missing'
grep -Fq 'private fun pandoraPerson' "$ATM" || fail 'Pandora explorer helper missing'
grep -Fq 'private fun pandoraFlyingCreature' "$ATM" || fail 'Pandora flying creature helper missing'
grep -Fq 'private fun glow' "$ATM" || fail 'Shared glow helper missing'
for old in 'private fun mountain(' 'private fun tree(' 'private fun pandoraFlower(' 'private fun bird(' 'private fun creature('; do
  grep -Fq "$old" "$ATM" && fail "legacy Pandora helper remains: $old"
done

grep -Fq 'private val animationRunnable = Runnable { invalidateSelf() }' "$ATM" || fail 'Drawable animation runnable missing'
grep -Fq 'scheduleSelf(animationRunnable' "$ATM" || fail 'Drawable scheduler not fenced by reusable runnable'
grep -Fq 'unscheduleSelf(animationRunnable)' "$ATM" || fail 'Drawable does not cancel scheduled animation when hidden'
grep -Fq 'private val context = context.applicationContext' "$ATM" || fail 'Drawable retains caller Activity context'

python3 - "$LOAD" <<'PY'
import sys
from pathlib import Path
p=Path(sys.argv[1]); s=p.read_text()
start=s.index('fun loadSectionBundle')
end=s.index('fun warmSource', start)
block=s[start:end]
if 'if (cacheEpoch.get() == epoch)' not in block:
    raise SystemExit('FAIL: bundle epoch guard missing')
# The callback must be lexically inside the epoch guard. For this compact function, require the
# first callback occurrence to be contained in the guard block and reject an unconditional sibling.
guard=block.index('if (cacheEpoch.get() == epoch)')
cb=block.index('onLoaded(bundle)')
if cb < guard or 'onLoaded(bundle)' not in block[guard:]:
    raise SystemExit('FAIL: stale bundle callback escapes epoch guard')
print('PASS: stale section-bundle callback cannot repaint an invalidated epoch')
PY

grep -Fq 'versionCode = 658' "$BUILD" || fail 'versionCode 658 missing'
grep -Fq 'versionName = "8.3.570"' "$BUILD" || fail 'versionName 8.3.570 missing'
grep -Fq 'sourceNameForId = { id -> sourceNameForId(id) }' "$DB" || fail 'restored sourceNameForId provider wiring missing'

echo 'PANDORA_VISUAL_DEEP_AUDIT=PASS'
