# Rovex v8.3.591 — QBank write-coordination and live-corpus audit

## Scope
Continuation of v8.3.590. This step does not perform a blind QBankDb extraction. It closes a concrete write-serialization gap and fixes two live-corpus accounting inconsistencies.

## Research basis
- Android SQLite guidance recommends short/batched transactions and serializing writes because only one write transaction can occur at a time.
- SQLite query-planner guidance recommends appropriate indexes and measurement with EXPLAIN QUERY PLAN rather than speculative hints.
- Android database testing guidance recommends device/instrumented tests against the actual SQLite engine for database behavior.

## Source changes
1. `QBankImportWriter` now acquires `QBankWriteCoordinator` for each bounded write transaction and releases it immediately after commit/rollback. It does not hold the coordinator across the full import.
2. `QBankDb.beginStreamingImport()` serializes source creation with the same coordinator.
3. `QBankDb.StreamingImportSession` holds the coordinator only for the current bounded transaction; `commitSection()` releases it before starting the next transaction. Abort cleanup obtains the coordinator separately.
4. `QBankDb.requestSourceDeletion()` now serializes the durable tombstone transaction with the same coordinator.
5. `QBankDb.restoreLegacyTombstonedSources()` serializes each restoration transaction with the same coordinator.
6. Search-index rebuild now compares indexed rows with the **live** normalized question corpus. Physically retained tombstoned rows are not incorrectly treated as missing FTS rows.
7. `aiIndexQuestionCount()` now reports the same live corpus that `aiIndexBatch()` actually returns.
8. Version bumped to 8.3.591 / versionCode 677.

## Verification performed in this offline environment
- Source archive v8.3.590 extracted and audited as the starting baseline.
- Kotlin/XML/source scans and targeted changed-surface review performed.
- No intentional architecture owner was added; `QBankWriteCoordinator` remains the existing shared process-local write boundary.
- Existing QBank import/search/deletion/reset tests were retained; a new instrumented regression test covers FTS repair with physically retained tombstone rows.

## Verification limits
- Full Android Gradle compilation was not available from this source archive because it has no `gradlew`; the environment also has the previously observed Gradle distribution DNS limitation.
- v8.3.591 GitHub CI and device validation are NOT claimed green until the exact source archive is supplied to CI and the complete workflow succeeds.
