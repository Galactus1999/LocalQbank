# Rovex v8.3.587

- Fixed dashboard omission of unassigned ordinary QBank collections.
- Preserved canonical 19-subject classification and test-kind precedence.
- Added regression coverage for ordinary QBank classification.
- No QBankDb ownership changes.
- No workflow changes.
