package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class QBankWriteCoordinatorTest {
    @Test
    fun sharedCoordinatorSerializesDestructiveWriteSections() {
        val active = AtomicInteger(0)
        val maximum = AtomicInteger(0)
        val start = CountDownLatch(1)
        val done = CountDownLatch(2)

        repeat(2) {
            Thread {
                try {
                    start.await(5, TimeUnit.SECONDS)
                    QBankWriteCoordinator.lock.lock()
                    try {
                        val now = active.incrementAndGet()
                        maximum.updateAndGet { old -> maxOf(old, now) }
                        Thread.sleep(20)
                        active.decrementAndGet()
                    } finally {
                        QBankWriteCoordinator.lock.unlock()
                    }
                } finally {
                    done.countDown()
                }
            }.start()
        }

        start.countDown()
        assertTrue(done.await(5, TimeUnit.SECONDS))
        assertEquals(1, maximum.get())
        assertEquals(0, active.get())
    }
}
