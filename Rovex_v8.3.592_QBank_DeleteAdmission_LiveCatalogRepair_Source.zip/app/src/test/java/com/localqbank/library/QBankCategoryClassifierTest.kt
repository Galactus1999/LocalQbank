package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class QBankCategoryClassifierTest {
    @Test fun canonicalSubjectsAreExactlyNineteenAndPsmIsCombined() {
        assertEquals(19, QBankCategoryClassifier.canonicalSubjects.size)
        assertEquals("Community Medicine / PSM", QBankCategoryClassifier.subject("PSM", "", ""))
        assertEquals("Community Medicine / PSM", QBankCategoryClassifier.subject("", "Community Medicine", ""))
    }

    @Test fun subjectAliasesNormalizeToCanonicalSubjects() {
        assertEquals("General Medicine", QBankCategoryClassifier.subject("Medicine & Allied", "", ""))
        assertEquals("General Surgery", QBankCategoryClassifier.subject("Surgery & Allied", "", ""))
        assertEquals("Orthopedics", QBankCategoryClassifier.subject("Orthopaedics", "", ""))
        assertEquals("Obstetrics & Gynecology", QBankCategoryClassifier.subject("OBGYN", "", ""))
        assertEquals("ENT", QBankCategoryClassifier.subject("Otorhinolaryngology", "", ""))
        assertNull(QBankCategoryClassifier.subject("Random Collection", "Mock Questions", "misc"))
    }

    @Test fun qbankKindsHaveStablePrecedence() {
        assertEquals("PYQ", QBankCategoryClassifier.kind("", "Medicine PYQ", ""))
        assertEquals("Custom", QBankCategoryClassifier.kind("", "Custom QBank", ""))
        assertEquals("Subject Test", QBankCategoryClassifier.kind("", "Pathology Subject Test", ""))
        assertEquals("Image Test", QBankCategoryClassifier.kind("", "Image Based Test", ""))
        assertEquals("Other Test", QBankCategoryClassifier.kind("", "Grand Test", ""))
        assertEquals("QBank", QBankCategoryClassifier.kind("", "Medicine Chapter 1", ""))
    }


    @Test fun ordinaryQBankKindRemainsVisibleAsQBankCollection() {
        assertEquals("QBank", QBankCategoryClassifier.kind("", "Anatomy Chapter 1", ""))
        assertEquals("QBank", QBankCategoryClassifier.kind("", "Random Question Collection", ""))
    }

    @Test fun kindClassificationKeepsSpecificKindsBeforeGenericTest() {
        assertEquals("PYQ", QBankCategoryClassifier.kind("", "Medicine PYQ Test Series", ""))
        assertEquals("Custom", QBankCategoryClassifier.kind("", "Custom QBank Test", ""))
        assertEquals("Image Test", QBankCategoryClassifier.kind("", "Image Based Test Series", ""))
        assertEquals("Subject Test", QBankCategoryClassifier.kind("", "Pathology Subject Test", ""))
    }

    @Test fun subjectClassificationDoesNotUseUnrelatedPartialWords() {
        assertNull(QBankCategoryClassifier.subject("", "Eye Bank Questions", ""))
        assertEquals("General Surgery", QBankCategoryClassifier.subject("Surgery & Allied", "", ""))
    }

    @Test fun classificationIsIndependentOfCaseAndSeparators() {
        assertEquals("Community Medicine / PSM", QBankCategoryClassifier.subject("preventive-and-social medicine", "", ""))
        assertEquals("General Medicine", QBankCategoryClassifier.subject("internal_medicine", "", ""))
        assertEquals("Obstetrics & Gynecology", QBankCategoryClassifier.subject("Obstetrics / Gynaecology", "", ""))
    }
}
