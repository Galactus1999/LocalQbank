package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class PerformanceLabMetricsTest {
    private fun ref(position: Int) = QuestionRef(
        id = position.toLong(), stableKey = "t:$position:", testId = "t", position = position,
        text = "", testTitle = "Test", sourceId = 1L, sourceName = "source", category = ""
    )

    @Test fun currentControlPanelUsesLatestQBankStatus() {
        val refs = (0..4).map(::ref)
        val now = 10_000_000L
        val values = mapOf(
            "t:0::status" to "correct", "t:0::lastAttempted" to now, "t:0::attempts" to 1,
            "t:1::status" to "wrong", "t:1::lastAttempted" to now, "t:1::attempts" to 1,
            "t:2::status" to "wrong", "t:2::lastAttempted" to now, "t:2::attempts" to 1,
            "t:3::status" to "correct", "t:3::lastAttempted" to now, "t:3::attempts" to 1,
            "t:4::status" to null
        )
        val snapshot = ProgressSnapshot.from(values)
        val metrics = PerformanceLabMetrics.current(refs, snapshot, now)
        assertEquals(4, metrics.attempted)
        assertEquals(2, metrics.correct)
        assertEquals(2, metrics.wrong)
        assertEquals(1, metrics.unsolved)
        assertEquals(0, metrics.due)
    }

    @Test fun dueUsesSameCurrentProgressSnapshot() {
        val refs = listOf(ref(0))
        val values = mapOf(
            "t:0::status" to "wrong", "t:0::lastAttempted" to 1L, "t:0::attempts" to 1
        )
        val metrics = PerformanceLabMetrics.current(refs, ProgressSnapshot.from(values), 86_400_001L)
        assertEquals(1, metrics.wrong)
        assertEquals(1, metrics.due)
        assertEquals(0, metrics.unsolved)
    }
    @Test fun periodFallsBackToCurrentProgressWhenAttemptLedgerIsEmpty() {
        val refs = (0..2).map(::ref)
        val today = 1_000_000L
        val values = mapOf(
            "t:0::status" to "correct", "t:0::lastAttempted" to today + 10, "t:0::attempts" to 1,
            "t:1::status" to "wrong", "t:1::lastAttempted" to today + 20, "t:1::attempts" to 1,
            "t:2::status" to null
        )
        val metrics = PerformanceLabMetrics.period(
            refs, ProgressSnapshot.from(values), emptyList(), today, today, daily = true
        )
        assertEquals(2, metrics.attempted)
        assertEquals(1, metrics.correct)
        assertEquals(1, metrics.wrong)
        assertEquals(2, metrics.todaySolved)
        assertEquals(false, metrics.usedHistory)
    }

    @Test fun periodUsesRepeatedAttemptHistoryWhenAvailable() {
        val refs = listOf(ref(0))
        val progress = ProgressSnapshot.from(mapOf(
            "t:0::status" to "correct", "t:0::lastAttempted" to 2_000L, "t:0::attempts" to 2
        ))
        val history = listOf(
            QBankDb.StudyAttemptHistoryRow("t:0:", 1_000L, false, 100L),
            QBankDb.StudyAttemptHistoryRow("t:0:", 2_000L, true, 120L)
        )
        val metrics = PerformanceLabMetrics.period(refs, progress, history, 0L, 1_500L, daily = false)
        assertEquals(2, metrics.attempted)
        assertEquals(1, metrics.correct)
        assertEquals(1, metrics.wrong)
        assertEquals(1, metrics.todaySolved)
        assertEquals(true, metrics.usedHistory)
    }

}
