package com.localqbank.library

import java.util.concurrent.locks.ReentrantLock

/**
 * Process-local serialization boundary for destructive QBank writes.
 *
 * SQLite/WAL allows readers to continue while writes are short, but two independent
 * QBank write coordinators must still not race on related learner/content state. Keep
 * this lock narrow and hold it only around bounded write transactions.
 */
internal object QBankWriteCoordinator {
    val lock = ReentrantLock()
}
