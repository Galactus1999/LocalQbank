# Rovex v8.3.590 — QBank Recent-Change Audit Proof

Date: 2026-10-07
Package: `com.localqbank.library`
Version: `8.3.590` / versionCode `676`

## Candidate input

Audited source: `Rovex_v8.3.589_QBank_DeleteSchema_PerformanceHardening_Source.zip`
SHA-256: `4c33602ba272f4a3212a85f1b491727832825a691c230d911766d8caeca1659c`

Recent archives compared: v8.3.583 through v8.3.589.

## Findings

1. v8.3.589 correctly moved large progress cleanup from giant Kotlin-generated IN lists to SQLite subqueries.
2. v8.3.589 correctly added child lookup indexes for option_item, question_image, and source catalog ordering.
3. A concurrency gap remained: QBankSourceDeletionManager and QBankProgressResetter used different process-local locks, allowing their write transactions to race.
4. v8.3.590 introduces `QBankWriteCoordinator`, shared by both components for transaction-scoped serialization. The deletion manager retains a separate deletion single-flight lock so the shared lock is not held across the entire long-running deletion operation.
5. A pure JVM regression test was added for the shared coordinator; a standalone smoke execution also passed.
6. The Android schema-index regression test now also asserts the existing question-note-image child index.

## Static verification performed

- Kotlin source delimiter balance: PASS for changed files.
- Kotlin compiler: `QBankWriteCoordinator.kt` compiled successfully with installed Kotlin compiler.
- Shared coordinator standalone concurrency smoke test: PASS.
- 323 Kotlin source files scanned.
- 36 XML files parsed successfully.
- Changed-area `catch(Throwable)`: none found.
- Merge-conflict markers in changed files: none found.
- Stale v8.3.589/versionCode 675 references: none found after bump.
- Package ID preserved: `com.localqbank.library`.
- ZIP integrity: PASS.

## SQLite proof

A representative SQLite schema was exercised with `EXPLAIN QUERY PLAN`.

Observed indexed plans included:
- `progress_v2` -> `idx_progress_v2_test_status`
- `test(source_id)` -> `idx_test_source`
- `question(test_id,position)` -> `idx_question_test`
- `option_item(question_id)` -> `idx_option_item_question`
- `progress_meta` primary-key lookup for generated meta keys

Set-based deletion test preserved unrelated source-2 rows while deleting source-1 rows.

## CI/device boundary

No Android Gradle build or device test was executed locally from this archive. The source archive does not contain a Gradle wrapper and the environment cannot be used as proof of Android compilation.

The latest repository CI run inspected during this audit was green, but its logs prove it selected v8.3.586, not v8.3.589/590. Therefore that run is NOT claimed as validation for v8.3.590.

The v8.3.590 source archive must be supplied to the repository/CI before Android build and instrumentation results can be claimed.
