# AUDIT PROOF — v8.3.577

### Authoritative CI failure
`logs_101626728955.zip`

CI completed Kotlin compilation and then failed `:app:testDebugUnitTest`: `147 tests completed, 5 failed`. All five failures were in `LargeHtmlScannerRegressionTest`.

### Five failures
1. `explicitJsonNullDoesNotMaskQuestionAndOptionAliases` — RuntimeException at test line 74.
2. `assignmentInsideJavascriptCommentDoesNotHijackScanner` — AssertionError at line 96.
3. `testArrayEmitsFirstQuestion` — AssertionError at line 27.
4. `rootQuestionArrayEmitsFirstQuestion` — RuntimeException at line 59.
5. `rootQuestionArrayUsesQuestionAliasWhenTextAliasesAreAbsent` — RuntimeException at line 41.

### Repair proof
`LargeHtmlScanner.normalize()` now uses typed JSON accessors and explicit null-safe helpers rather than relying on raw `JSONObject.NULL` values and nullable Java `optString` defaults. `parseRootQuestion()` now protects only the telemetry breadcrumb from secondary failure. No broad `catch(Throwable)` was introduced.

### Isolated execution proof
A local JVM harness using the repaired scanner and a minimal `org.json` compatibility stub exercised all five CI scenarios. Results: all five emitted the expected question/section data, including explicit-null fallback and comment filtering. This is isolated source-level execution evidence, not an Android/CI build claim.

### Structural proof
- applicationId/package preserved: `com.localqbank.library`
- versionName `8.3.577`
- versionCode `663`
- current workflow: `build-ben-qbank-575.yml`
- layout XML parse: PASS
- no idle + explicit backoff WorkManager combination found in worker sources
- current scanner has no known unmatched-brace defect by lexical scan

### Verification boundary
CI/device/build PASS is not claimed. The next gate is a fresh complete GitHub Actions run for v8.3.577 followed by independent inspection of the complete log.
