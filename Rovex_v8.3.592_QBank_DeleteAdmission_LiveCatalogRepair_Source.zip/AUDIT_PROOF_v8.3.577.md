# Rovex v8.3.577 — LargeHtmlScanner Root-Cause Repair

## Authoritative CI evidence
The uploaded CI log `logs_101773253696.zip` reports 147 unit tests with 5 failures in `LargeHtmlScannerRegressionTest`, followed by `:app:testDebugUnitTest FAILED` and `BUILD FAILED`.

## Root cause
`LargeHtmlScanner.seekToDataArray()` used a Kotlin ordinary string for a regex containing `\b`. In a Kotlin ordinary string, that escape is interpreted as the Kotlin backspace escape, not the regex word-boundary escape intended by the regex engine. Therefore supported assignment detection can fail before parsing begins, causing the five downstream scanner tests to fail at the same boundary.

## Repair
The assignment regex is now a Kotlin raw triple-quoted string, preserving regex escapes literally. The comment/string-aware lexical scanner and deterministic null-safe normalization are otherwise preserved.

## Required verification
Run the complete GitHub Actions JVM test task and inspect the complete log. Do not claim CI/build/device/release PASS until the workflow actually passes.
