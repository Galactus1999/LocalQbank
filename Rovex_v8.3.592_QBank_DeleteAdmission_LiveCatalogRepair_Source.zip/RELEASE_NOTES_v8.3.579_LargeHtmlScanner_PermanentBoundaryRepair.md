# Rovex v8.3.579 — LargeHtmlScanner Permanent Assignment-Boundary Repair

## Authoritative failure
v8.3.578 CI selected the exact v8.3.578 archive (SHA-256 8b72eb5fea918aa9154dbb397e909cdd0ba4a0bae640662ceb81c634d8dcf525) but still failed all five existing LargeHtmlScannerRegressionTest cases.

## Root cause
The prior repairs repeatedly changed regex escaping/normalization while leaving the critical assignment boundary dependent on regex matching. The boundary is now regex-free and deterministic.

## Repair
- Replaced assignment regex matching with exact lexical suffix parsing.
- Preserved comment/string exclusion.
- Supports const/let/var, window-qualified names, whitespace/newline around '=', and all existing aliases.
- Rejects identifier substrings such as MY_TESTS_LIST.
- Added regression tests for block comments, quoted fake assignments, window-qualified aliases, multiline declarations, and identifier-substring collisions.
- Preserved streaming/bounded-memory parsing.

Version: 8.3.579
versionCode: 665

CI/device/release PASS is not claimed until the actual v8.3.579 workflow passes.
