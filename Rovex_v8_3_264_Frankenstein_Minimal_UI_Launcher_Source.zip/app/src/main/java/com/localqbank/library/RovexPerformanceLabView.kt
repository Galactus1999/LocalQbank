package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Home "Performance Lab" widget, v2. Same ring language as RovexFlashcardSummaryView.
 * The three metric rows now get real spacing and readable type (9.5sp minimum instead of
 * 6.5sp) rather than being crammed to fit — this was the single biggest legibility problem
 * in the old widget.
 */
class RovexPerformanceLabView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var health = 0; private var resilience = 0; private var ram = 0
    private val animated = FloatArray(3)
    private var running = false; private var started = 0L

    fun setScores(health: Int, resilience: Int, ram: Int) {
        this.health = health.coerceIn(0, 100); this.resilience = resilience.coerceIn(0, 100); this.ram = ram.coerceIn(0, 100)
        invalidate()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; started = SystemClock.uptimeMillis(); postInvalidateOnAnimation() }
    override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); running = visibility == View.VISIBLE; if (running) postInvalidateOnAnimation() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0 || h <= 0 || !running) return
        val d = resources.displayMetrics.density
        val dark = ThemeManager.isDark(context)
        val accent = ThemeManager.accent(context)
        val target = floatArrayOf(health.toFloat(), resilience.toFloat(), ram.toFloat())
        for (i in 0..2) animated[i] += (target[i] - animated[i]) * 0.14f
        val score = animated.average().roundToInt().coerceIn(0, 100)

        val panelColor = ThemeManager.panel(context)
        p.shader = RadialGradient(w * 0.25f, h * 0.1f, w * 1.1f, intArrayOf(lighten(panelColor, if (dark) 1.16f else 1.0f), panelColor), null, Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        c.drawRoundRect(0f, 0f, w, h, 18 * d, 18 * d, p)
        p.shader = null

        val cx = w * 0.26f; val cy = h * 0.5f; val r = minOf(w, h) * 0.26f
        p.style = Paint.Style.STROKE; p.strokeWidth = 7.5f * d; p.strokeCap = Paint.Cap.ROUND
        p.color = if (dark) 0xFF2C414E.toInt() else 0xFFD5E2E7.toInt()
        c.drawCircle(cx, cy, r, p)
        p.color = accent
        c.drawArc(cx - r, cy - r, cx + r, cy + r, -90f, score * 3.6f, false, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = ThemeManager.text(context); p.isFakeBoldText = true; p.textSize = 15.5f * d
        c.drawText("$score%", cx, cy + 5.5f * d, p)
        p.isFakeBoldText = false; p.color = ThemeManager.muted(context); p.textSize = 7.5f * d
        c.drawText("HEALTH", cx, cy + 17 * d, p)
        p.textAlign = Paint.Align.LEFT

        // Three rows, generously spaced. Each row: coloured status dot, label, value —
        // value and label sit on the same baseline instead of stacking a caption above a bar.
        val labels = arrayOf("Health" to animated[0], "Resilience" to animated[1], "RAM" to animated[2])
        val left = w * 0.50f; val right = w - 12 * d; val rowH = (h - 16 * d) / 3f
        labels.forEachIndexed { idx, pair ->
            val v = pair.second.roundToInt().coerceIn(0, 100)
            val rowTop = 8 * d + idx * rowH
            val dotY = rowTop + rowH * 0.32f
            val grade = grade(v)
            p.color = grade
            c.drawCircle(left + 4 * d, dotY, 3.5f * d, p)
            p.isFakeBoldText = true; p.textSize = 10.5f * d; p.color = ThemeManager.text(context)
            c.drawText(pair.first, left + 12 * d, dotY + 3.5f * d, p)
            p.textAlign = Paint.Align.RIGHT; p.color = grade
            c.drawText("$v%", right, dotY + 3.5f * d, p)
            p.textAlign = Paint.Align.LEFT; p.isFakeBoldText = false

            // Track sits below the label with real clearance, not squeezed against it.
            val barY = rowTop + rowH * 0.62f
            val barBottom = barY + 5 * d
            p.color = if (dark) 0xFF263945.toInt() else 0xFFE3EBED.toInt()
            c.drawRoundRect(left, barY, right, barBottom, 2.5f * d, 2.5f * d, p)
            p.color = grade
            c.drawRoundRect(left, barY, left + (right - left) * v / 100f, barBottom, 2.5f * d, 2.5f * d, p)
        }

        val pulse = ((sin((SystemClock.uptimeMillis() - started) / 700.0) + 1) / 2).toFloat()
        p.color = accent
        c.drawCircle(w - 10 * d, 10 * d, (2f + 1.4f * pulse) * d, p)
        if (running) postInvalidateOnAnimation()
    }

    private fun lighten(color: Int, factor: Float): Int {
        val r = ((color shr 16 and 0xFF) * factor).roundToInt().coerceIn(0, 255)
        val g = ((color shr 8 and 0xFF) * factor).roundToInt().coerceIn(0, 255)
        val b = ((color and 0xFF) * factor).roundToInt().coerceIn(0, 255)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }
    private fun grade(v: Int) = when { v >= 85 -> 0xFF36B77C.toInt(); v >= 70 -> 0xFF4FA4D8.toInt(); v >= 50 -> 0xFFE3AE45.toInt(); else -> 0xFFD65F5F.toInt() }
}
