package com.localqbank.library

import android.text.Html
import android.text.Spannable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.TextAppearanceSpan
import android.content.Context

/**
 * Dedicated imported-HTML renderer for question/option/explanation text.
 *
 * The renderer owns the theme-safety boundary so QuizActivity remains a session/controller
 * rather than accumulating HTML parsing and span-sanitization policy.
 */
internal class QuizRichTextRenderer(private val context: Context) {

    fun themeSafeSpanned(html: String, forcedColor: Int? = null): Spanned {
        val sanitized = html
            .replace(
                Regex("(?is)<font\\s+[^>]*?color\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)[^>]*>"),
                "<font>"
            )
            .replace(
                Regex("(?is)\\s+(?:color|bgcolor)\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)"),
                ""
            )
            .replace(
                Regex("(?is)\\s+style\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)"),
                ""
            )

        val parsed = Html.fromHtml(sanitized, Html.FROM_HTML_MODE_LEGACY)
        if (parsed !is Spannable) return parsed

        val out = SpannableString(parsed)
        out.getSpans(0, out.length, ForegroundColorSpan::class.java)
            .forEach(out::removeSpan)
        out.getSpans(0, out.length, BackgroundColorSpan::class.java)
            .forEach(out::removeSpan)

        out.getSpans(0, out.length, TextAppearanceSpan::class.java).forEach { span ->
            val start = out.getSpanStart(span)
            val end = out.getSpanEnd(span)
            val flags = out.getSpanFlags(span)
            out.removeSpan(span)
            if (start >= 0 && end > start) {
                out.setSpan(
                    TextAppearanceSpan(span.family, span.textStyle, span.textSize, null, null),
                    start,
                    end,
                    flags
                )
            }
        }

        // TextView.setTextColor() cannot override an embedded ForegroundColorSpan.
        // Re-apply one final authoritative span after all imported color spans are removed.
        forcedColor?.let { color ->
            if (out.isNotEmpty()) {
                out.setSpan(
                    ForegroundColorSpan(color),
                    0,
                    out.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        return out
    }

    fun toSpanned(html: String): Spanned {
        return themeSafeSpanned(html)
    }

    fun optionSpanned(html: String, color: Int): Spanned {
        return themeSafeSpanned(html, color)
    }
}
