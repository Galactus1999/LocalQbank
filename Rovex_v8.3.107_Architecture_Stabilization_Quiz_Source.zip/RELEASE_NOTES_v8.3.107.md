# Rovex v8.3.107

## Architecture Stabilization — Quiz foundation

- Began the planned Rovex Architecture Stabilization program.
- Added `QuizViewModel` as the lifecycle owner for Quiz session dependencies.
- Added `QuizSessionRepository` as a thin persistence seam over the existing QBankDb/ProgressRepository authorities.
- Added `QuizAnswerUseCase` so answer acceptance/correctness and study-state commit coordination are no longer owned by QuizActivity.
- Removed direct QBankDb/ProgressStore ownership from QuizActivity.
- Preserved StudyCore/StudyStateRepository and AppManagers as authoritative business owners.
- No Compose migration and no Hilt/Dagger migration introduced.
- Existing Ben, QNN, EmbeddingGemma, zstd, signing, APKG, SRS, notes, flashcards, themes, WebView/QBank and benchmark infrastructure are preserved.

Build/runtime status:
- Static audit: PASS.
- Local Android Gradle build: unavailable because services.gradle.org DNS is blocked in the current environment.
- CI: must pass before this release is called green.
- Device runtime: not verified by this source-only change.
