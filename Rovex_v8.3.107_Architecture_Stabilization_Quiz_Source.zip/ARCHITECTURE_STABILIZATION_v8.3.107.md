# Rovex v8.3.107 — Architecture Stabilization Audit / Stage 1 + Quiz Stage 2 Slice

## Identity
- Baseline: v8.3.106 / versionCode 204
- This source: v8.3.107 / versionCode 205
- Purpose: begin Architecture Stabilization without rewriting authoritative engines.
- CI status: **NOT VERIFIED GREEN**. Local Android Gradle compilation is blocked because `services.gradle.org` DNS is unavailable in this environment.

## Stage 1 — Full Architecture Reconnaissance

### Project shape
- Kotlin source files before this slice: 92-ish application files in the previous baseline; exact baseline archive contained the existing source set.
- Current application Kotlin files after this slice: 95.
- Unit-test Kotlin files: 21.
- Android instrumented-test files: 0.
- Compose usage: 0.
- Hilt/Dagger usage: 0.
- XML layouts/resources parsed: 27; XML parse errors: 0.
- Duplicate `@+id` values within individual XML files: 0.
- Typed `findViewById<T>()` calls audited against parsed XML widget tags: 63; detected type mismatches: 0.

### Largest application classes
| File | Approx. size | Functions |
|---|---:|---:|
| QuizActivity.kt | 93 KB baseline | 89 baseline |
| MainActivity.kt | 68 KB | 61 |
| HtmlImportActivity.kt | 63 KB | 63 |
| SettingsActivity.kt | 58 KB | 29 |
| QBankDb.kt | 51 KB | 92 |
| FlashcardActivity.kt | 44 KB | 44 |
| BackupManager.kt | 35 KB | 40 |
| FlashcardDb.kt | 26 KB | 51 |
| ApkgImporter.kt | 26 KB | 31 |

The four principal God Activities are therefore confirmed rather than hypothetical: Quiz, Main, HTML import, and Settings remain the first refactoring targets.

### Direct persistence from UI
Direct `QBankDb(...)` construction remains present in several Activities, including MainActivity, QuizActivity (removed by this v8.3.107 slice), CollectionActivity, SearchActivity, HtmlImportActivity, StudyToolsActivity, and other screens.

Direct SharedPreferences usage remains in Activities, especially QuizActivity, MainActivity, SettingsActivity, FlashcardStudyActivity and StudyToolsActivity.

This confirms that persistence seams exist in the project but are not consistently used by the presentation layer.

### Dependency/ownership map
- `AppManagers` is the application-level owner/coordinator for the existing managers and engines.
- `StudyCore` / `StudyStateRepository` remains the canonical study-state facade.
- `ImportPipelineCoordinator` remains the canonical import authority.
- `AdaptiveEngineManager`, `PerformanceManager`, `ResilienceManager`, `EngineHealthManager`, `EngineMeshCoordinator`, `IntelligenceOrchestrator`, and related engines remain domain authorities.
- `RovexBatteryManager` remains governor/policy-only.
- Ben Cognitive Architecture remains Ben's orchestration authority.
- Activities currently call these authorities directly in many places; this is the main UI/business-logic coupling to reduce.

### Global/singleton state
There are numerous Kotlin `object` declarations. Some are intentional stateless utilities or registries; `AppManagers`, `AppState`, `AppEventBus`, `ThemeManager`, `PerformanceManager`, and related process-level coordinators are architectural singletons and require controlled ownership rather than indiscriminate removal.

The correct target is therefore not “zero objects”; it is controlled lifecycle/ownership and no new uncontrolled global business state.

### Coroutine/lifecycle audit
Current source scan found:
- `runBlocking`: 0
- `Thread.sleep`: 0
- `GlobalScope`: 0
- active `catch(Throwable)`: 0
- unsafe `PRAGMA foreign_keys=ON`: 0
- `selectAllOnFocus`: 0
- `viewModelScope`: 0 before this migration
- `lifecycleScope`: 0

There are several explicit `CoroutineScope`/`launch` sites. These require lifecycle review, but no blanket unsafe pattern above was found.

### Startup/onCreate risks
The Activities remain initialization-heavy. MainActivity, QuizActivity, HtmlImportActivity, and SettingsActivity perform substantial dependency setup, state loading, persistence access, and UI construction from `onCreate`/resume paths. This confirms startup/lifecycle extraction as a major stabilization goal.

## Stage 2 — QuizActivity first stabilization slice

This release begins the QuizActivity refactor using a strangler/seam approach rather than a risky rewrite.

### Added
- `QuizSessionRepository.kt`
  - thin persistence seam around `QBankDb` and `ProgressRepository`
  - no duplicated quiz business rules
  - owns DB lifetime through the ViewModel
- `QuizViewModel.kt`
  - Activity-scoped lifecycle owner for quiz-session data dependencies
  - owns `QuizSessionRepository`
  - moves collection-ID derivation and question/test routing helpers out of Activity
- `QuizAnswerUseCase.kt`
  - moves answer correctness/acceptance and study-state commit coordination out of Activity
  - keeps `StudyStateRepository` authoritative
  - keeps adaptive recording through `AppManagers.adaptive`

### QuizActivity changes
- Removed direct `QBankDb` and `ProgressStore` fields.
- Removed Activity-owned DB close logic.
- Replaced direct persistence calls with the ViewModel-backed data seam.
- Removed `buildCollectionQuestionIds()` and `findTestIdForQuestion()` from Activity.
- Moved answer business decision/commit logic into `QuizAnswerUseCase`.
- UI rendering remains in QuizActivity intentionally; this is the first incremental slice, not a claim that QuizActivity is already thin.

### Why this approach
A full 93 KB Activity rewrite in one release would create excessive regression risk. The migration therefore establishes lifecycle-safe seams first, then moves focused use cases/state in subsequent Quiz stages.

## Required next Quiz refactor slices
1. Move quiz launch/session state into a typed `QuizSessionState` owned by QuizViewModel.
2. Extract navigation/progress checkpoint use cases.
3. Extract note/bookmark/mistake-state actions behind focused use cases.
4. Reduce Activity access to AppManagers to presentation events only.
5. Move question loading/prefetch orchestration behind a repository/use-case boundary while preserving existing executor/performance behavior.
6. Add QuizActivity instrumentation tests before deleting the old seams.

## Architecture quality conclusion
The audit confirms the external 6/10 criticism is materially justified for the application shell. Ben/engine architecture is significantly more mature than the UI architecture. The correct response is incremental structural refactoring, not a rewrite and not a superficial Hilt/Compose migration.

## Verification
- Whole-project Kotlin source scan: PASS for prohibited patterns listed above.
- XML parsing: PASS (27 files).
- Per-layout duplicate ID audit: PASS.
- `findViewById<T>()` vs XML type audit: PASS for 63 statically resolvable calls.
- Version identity: v8.3.107 / 205 aligned in Gradle and CI assertions.
- Local Gradle compilation: **BLOCKED** by `services.gradle.org` DNS resolution.
- GitHub CI: **NOT YET RUN/PASSED for v8.3.107**.
- Device runtime: **NOT VERIFIED**.
