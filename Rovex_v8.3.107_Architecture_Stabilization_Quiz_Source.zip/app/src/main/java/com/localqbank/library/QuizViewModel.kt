package com.localqbank.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/**
 * Lifecycle owner for quiz-session data dependencies.
 *
 * The first migration deliberately keeps this ViewModel small. It owns the session persistence
 * seam and opening/routing logic while QuizActivity continues to own view construction. Later
 * stages can extract focused UI use-cases without creating a second business-logic authority.
 */
class QuizViewModel(application: Application) : AndroidViewModel(application) {
    val data = QuizSessionRepository(application)
    private val answerUseCase = QuizAnswerUseCase(data.progress, StudyStateRepository(application))

    fun answer(question: Question, label: String, practiceMode: Boolean, examMode: Boolean): QuizAnswerUseCase.Result =
        answerUseCase.answer(question, label, practiceMode, examMode)

    fun buildCollectionQuestionIds(type: String, value: String): LongArray {
        val refs = PerformanceManager.refs(getApplication<Application>())
        val progress = PerformanceManager.progress(getApplication<Application>())
        return refs.asSequence().filter { r ->
            val p = progress.record(r.stableKey)
            when (type) {
                "status" -> when (value) {
                    "unsolved" -> p?.status == null
                    else -> p?.status == value
                }
                "bookmark" -> if (value == "all") !p?.bookmark.isNullOrBlank() else p?.bookmark == value
                else -> false
            }
        }.map { it.id }.toList().toLongArray()
    }

    fun findTestIdForQuestion(questionId: Long): String = data.testIdForQuestion(questionId).orEmpty()

    override fun onCleared() {
        data.close()
        super.onCleared()
    }
}
