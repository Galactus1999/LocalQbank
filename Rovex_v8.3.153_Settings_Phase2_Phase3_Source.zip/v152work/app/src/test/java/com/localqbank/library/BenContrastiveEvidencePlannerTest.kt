package com.localqbank.library

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class BenContrastiveEvidencePlannerTest {
    @Test
    fun plannerSeparatesStrongAndLowerRankedEvidence() {
        val candidates = List(10) { i -> BenContrastiveEvidencePlanner.Candidate(i.toLong(), "candidate $i") }
        val bundle = BenContrastiveEvidencePlanner.plan("question", candidates, maxAnswer = 4, maxDistractor = 4)
        assertEquals(1, bundle.question.size)
        assertEquals(4, bundle.answers.size)
        assertEquals(4, bundle.distractors.size)
        assertTrue(bundle.answers.all { it.role == BenContrastiveEvidence.Role.ANSWER_EVIDENCE })
        assertTrue(bundle.distractors.all { it.role == BenContrastiveEvidence.Role.DISTRACTOR_EVIDENCE })
    }

    @Test
    fun blankQuestionDoesNotCreateSyntheticEvidence() {
        val bundle = BenContrastiveEvidencePlanner.plan("  ", listOf(BenContrastiveEvidencePlanner.Candidate(1L, "candidate")))
        assertTrue(bundle.question.isEmpty())
    }
}
