package com.localqbank.library

/**
 * Deterministic Phase-3 contrastive evidence planner.
 *
 * Retrieval metadata only. It does not decide clinical truth and never replaces
 * BenAnswerVerifier. The strongest retrieved candidates are separated from lower-ranked
 * distractor context so neural generation can reason contrastively without promoting every hit.
 */
internal object BenContrastiveEvidencePlanner {
    data class Candidate(val sourceId: Long, val text: String, val score: Double = 0.0)

    fun plan(query: String, candidates: List<Candidate>, maxAnswer: Int = 4, maxDistractor: Int = 4): BenContrastiveEvidence.Bundle {
        val answerLimit = maxAnswer.coerceAtLeast(0)
        val distractorLimit = maxDistractor.coerceAtLeast(0)
        val answers = candidates.take(answerLimit).map {
            BenContrastiveEvidence.Item(BenContrastiveEvidence.Role.ANSWER_EVIDENCE, it.sourceId, clean(it.text), it.score)
        }
        val distractors = candidates.drop(answerLimit).take(distractorLimit).map {
            BenContrastiveEvidence.Item(BenContrastiveEvidence.Role.DISTRACTOR_EVIDENCE, it.sourceId, clean(it.text), it.score)
        }
        val question = query.takeIf { it.isNotBlank() }?.let {
            listOf(BenContrastiveEvidence.Item(BenContrastiveEvidence.Role.QUESTION_EVIDENCE, -1L, clean(it), 1.0))
        }.orEmpty()
        return BenContrastiveEvidence.Bundle(question, distractors, answers)
            .bounded(maxQuestion = 1, maxDistractors = distractorLimit, maxAnswers = answerLimit)
    }

    private fun clean(text: String): String = text.replace(Regex("\\s+"), " ").trim().take(700)
}
