package com.localqbank.library

import org.junit.Assert.*
import org.junit.Test

class RovexMarkdownTableParserTest {
    @Test fun numberedListIsNotATable() {
        val lines = listOf("1. Step one | important", "2. Step two | more detail")
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }

    @Test fun pseudoColumnsAreNotATableWithoutDelimiterRow() {
        val lines = listOf("Step | 1 | 2 | 3 | 4", "Integrated reasoning | Notes | Persistence")
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }

    @Test fun proseWithPipesIsNotATable() {
        val lines = listOf("HPV | smoking | persistence", "Risk rises | but this is prose")
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }

    @Test fun genuineTableIsRecognized() {
        val lines = listOf(
            "| Feature | Finding |",
            "| --- | --- |",
            "| HPV | Persistent infection |",
            "| Smoking | Synergistic risk |",
            "",
            "Next paragraph"
        )
        val table = RovexMarkdownTableParser.parse(lines, 0)
        assertNotNull(table)
        assertEquals(listOf("Feature", "Finding"), table!!.header)
        assertEquals(2, table.rows.size)
        assertEquals(4, table.nextIndex)
    }

    @Test fun mixedProseAndTableStopsAtProse() {
        val lines = listOf(
            "Intro paragraph",
            "| A | B |",
            "| --- | --- |",
            "| 1 | 2 |",
            "| 3 | 4 |",
            "After table"
        )
        val table = RovexMarkdownTableParser.parse(lines, 1)
        assertNotNull(table)
        assertEquals(5, table!!.nextIndex)
        assertEquals("After table", lines[table.nextIndex])
    }

    @Test fun chatTableOffRendersReadableSectionsInsteadOfGrid() {
        val markdown = """| Feature | Finding |
| --- | --- |
| HPV | Persistent infection |
| Smoking | Synergistic risk |"""
        val html = rovexMarkdownBody(markdown, showTables = false)
        assertFalse(html.contains("<table>"))
        assertTrue(html.contains("<h4>HPV</h4>"))
        assertTrue(html.contains("<b>Finding:</b> Persistent infection"))
    }

    @Test fun tablesRemainTablesWhenEnabled() {
        val markdown = """| Feature | Finding |
| --- | --- |
| HPV | Persistent infection |"""
        val html = rovexMarkdownBody(markdown, showTables = true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<th>Feature</th>"))
    }

    @Test fun mismatchedRowDoesNotBecomeMalformedTable() {
        val lines = listOf(
            "| A | B |",
            "| --- | --- |",
            "| 1 | 2 | 3 |"
        )
        assertNull(RovexMarkdownTableParser.parse(lines, 0))
    }
}
