package com.localqbank.library

/**
 * Conservative Markdown table recognizer shared by chat and saved-note rendering.
 * A table is recognized only when the header, separator and every contiguous data row
 * are physically separate Markdown lines with the same column count. This intentionally
 * rejects "collapsed" provider output instead of guessing that pipe-heavy prose is a table.
 */
object RovexMarkdownTableParser {
    data class Table(val header: List<String>, val rows: List<List<String>>, val nextIndex: Int)

    private val separatorCell = Regex(":?-{3,}:?")

    fun parse(lines: List<String>, start: Int, maxColumns: Int = 12, maxRows: Int = 80): Table? {
        if (start < 0 || start + 1 >= lines.size) return null
        val header = split(lines[start])
        if (header.size < 2 || header.size > maxColumns || header.any { it.isBlank() }) return null
        val separator = split(lines[start + 1])
        if (separator.size != header.size || separator.any { !separatorCell.matches(it) }) return null

        val rows = ArrayList<List<String>>()
        var i = start + 2
        while (i < lines.size && rows.size < maxRows) {
            val line = lines[i]
            if (line.isBlank()) break
            val cells = split(line)
            if (cells.size != header.size) break
            if (cells.all { it.isBlank() }) break
            rows += cells
            i++
        }
        // A delimiter/header pair with no real row is too easy to produce accidentally in
        // prose/AI output, so require at least one data row for a rendered table.
        if (rows.isEmpty()) return null
        return Table(header, rows, i)
    }

    fun split(line: String): List<String> = line.trim().trim('|').split('|').map { it.trim() }
}
