package com.localqbank.library

import org.junit.Assert.assertTrue
import org.junit.Test

class BenCognitiveTaskTest {
    private val decomposer = BenTaskDecomposer()

    @Test
    fun comparisonQueryCreatesExplicitComparisonAndVerificationTasks() {
        val understanding = ClinicalKnowledgeLayer.Understanding(
            query = "compare nephrotic and nephritic syndrome",
            normalized = "compare nephrotic and nephritic syndrome",
            concepts = emptyList(),
            intent = "mechanism",
            domains = setOf("renal"),
            expansions = listOf("nephrotic syndrome", "nephritic syndrome"),
            visualIntent = false,
            visualKinds = emptySet(),
            examTerms = emptyList()
        )
        val plan = BenCognitiveArchitecture.Plan(
            query = understanding.query,
            intent = understanding.intent,
            concepts = listOf("nephrotic syndrome", "nephritic syndrome"),
            domains = understanding.domains,
            tools = listOf("clinical_retrieval"),
            confidence = 70
        )

        val result = decomposer.decompose(understanding.query, understanding, plan)

        assertTrue(result.hasComparison)
        assertTrue(result.tasks.any { it.type == BenCognitiveTask.Type.EXPLAIN })
        assertTrue(result.tasks.any { it.type == BenCognitiveTask.Type.VERIFY })
        assertTrue(result.tasks.any { it.type == BenCognitiveTask.Type.COMPOSE })
    }

    @Test
    fun visualQueryRequiresVisualGroundingTask() {
        val understanding = ClinicalKnowledgeLayer.Understanding(
            query = "identify this ECG image",
            normalized = "identify this ecg image",
            concepts = emptyList(),
            intent = "imaging",
            domains = setOf("cardiology"),
            expansions = listOf("ecg"),
            visualIntent = true,
            visualKinds = setOf("ecg"),
            examTerms = emptyList()
        )
        val plan = BenCognitiveArchitecture.Plan(
            understanding.query,
            understanding.intent,
            listOf("ecg"),
            understanding.domains,
            listOf("visual_question_retrieval"),
            70,
            visualIntent = true
        )

        val result = decomposer.decompose(understanding.query, understanding, plan)

        assertTrue(result.tasks.any { it.type == BenCognitiveTask.Type.VISUAL_GROUND })
        assertTrue(result.visualKinds.contains("ecg"))
    }
}
