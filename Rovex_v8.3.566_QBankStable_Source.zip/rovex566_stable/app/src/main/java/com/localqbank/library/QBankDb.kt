package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.security.MessageDigest
import android.database.Cursor
import android.util.Log

private fun createQBankSchema(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS source(id INTEGER PRIMARY KEY AUTOINCREMENT, file_name TEXT UNIQUE NOT NULL, display_name TEXT, series_number TEXT, provider TEXT NOT NULL, imported_at INTEGER NOT NULL, deleting INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS test(id TEXT PRIMARY KEY, source_id INTEGER NOT NULL, title TEXT NOT NULL, path TEXT, num_questions INTEGER, total_marks REAL, duration_seconds INTEGER, time_per_question REAL, original_id TEXT, series_number TEXT, FOREIGN KEY(source_id) REFERENCES source(id) ON DELETE CASCADE)")
        ensureQBankColumn(db, "source", "display_name", "TEXT")
        ensureQBankColumn(db, "source", "series_number", "TEXT")
        ensureQBankColumn(db, "source", "deleting", "INTEGER NOT NULL DEFAULT 0")
        // `deleting` is a visibility/tombstone state. `delete_requested` records an explicit
        // user/import replacement intent so crash recovery can never mistake an old hidden
        // source for a QBank the user actually asked us to destroy.
        ensureQBankColumn(db, "source", "delete_requested", "INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_source_deleting ON source(deleting,id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_source_delete_requested ON source(delete_requested,deleting,id)")
        ensureQBankColumn(db, "test", "series_number", "TEXT")
        db.execSQL("CREATE TABLE IF NOT EXISTS question(id INTEGER PRIMARY KEY AUTOINCREMENT, test_id TEXT NOT NULL, position INTEGER NOT NULL, source_question_id TEXT, text TEXT, raw_text TEXT, correct_answer TEXT, explanation TEXT, bot TEXT, video TEXT, audio TEXT, FOREIGN KEY(test_id) REFERENCES test(id) ON DELETE CASCADE, UNIQUE(test_id,position))")
        db.execSQL("CREATE TABLE IF NOT EXISTS option_item(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, position INTEGER NOT NULL, label TEXT, text TEXT, is_correct INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_image(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, kind TEXT NOT NULL, position INTEGER NOT NULL, uri TEXT NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS progress(question_id INTEGER PRIMARY KEY, selected_answer TEXT, status TEXT, bookmark TEXT, review INTEGER DEFAULT 0, attempt_count INTEGER DEFAULT 0, last_attempted INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        // v2 progress store: stable-key based durable study state. The legacy `progress`
        // table is retained for backward compatibility, but all new quiz progress is written
        // transactionally here. This avoids coupling progress identity to mutable numeric IDs.
        db.execSQL("CREATE TABLE IF NOT EXISTS progress_v2(stable_key TEXT PRIMARY KEY NOT NULL, test_id TEXT, selected_answer TEXT, status TEXT, bookmark TEXT, review INTEGER DEFAULT 0, attempts INTEGER DEFAULT 0, last_attempted INTEGER DEFAULT 0, time_ms INTEGER DEFAULT 0, mistake_type TEXT, ease_factor REAL DEFAULT 2.5, repetitions INTEGER DEFAULT 0, interval_days REAL DEFAULT 0, next_due INTEGER DEFAULT 0)")
        // Durable per-attempt history. progress_v2 intentionally stores only current state; this
        // append-only ledger is the authoritative source for real daily/weekly/monthly/all-time
        // performance metrics and preserves repeated attempts instead of collapsing them.
        db.execSQL("CREATE TABLE IF NOT EXISTS study_attempt_history(id INTEGER PRIMARY KEY AUTOINCREMENT, stable_key TEXT NOT NULL, test_id TEXT NOT NULL, source_id INTEGER NOT NULL DEFAULT 0, attempted_at INTEGER NOT NULL, correct INTEGER NOT NULL, time_ms INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_study_attempt_history_key_time ON study_attempt_history(stable_key,attempted_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_study_attempt_history_time ON study_attempt_history(attempted_at)")
        db.execSQL("CREATE TABLE IF NOT EXISTS progress_meta(meta_key TEXT PRIMARY KEY NOT NULL, meta_value TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS search_index_meta(meta_key TEXT PRIMARY KEY NOT NULL, meta_value TEXT NOT NULL)")
        db.execSQL("INSERT OR IGNORE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")
        db.execSQL("INSERT OR IGNORE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending','0')")
        db.execSQL("CREATE TABLE IF NOT EXISTS study_streak(id INTEGER PRIMARY KEY CHECK(id=1), current_streak INTEGER NOT NULL DEFAULT 0, longest_streak INTEGER NOT NULL DEFAULT 0, total_study_days INTEGER NOT NULL DEFAULT 0, last_study_day TEXT, last_reminder_day TEXT, notification_prompted INTEGER NOT NULL DEFAULT 0)")
        ensureQBankColumn(db, "study_streak", "current_streak", "INTEGER NOT NULL DEFAULT 0")
        ensureQBankColumn(db, "study_streak", "longest_streak", "INTEGER NOT NULL DEFAULT 0")
        ensureQBankColumn(db, "study_streak", "total_study_days", "INTEGER NOT NULL DEFAULT 0")
        ensureQBankColumn(db, "study_streak", "last_study_day", "TEXT")
        ensureQBankColumn(db, "study_streak", "last_reminder_day", "TEXT")
        ensureQBankColumn(db, "study_streak", "notification_prompted", "INTEGER NOT NULL DEFAULT 0")
        db.execSQL("INSERT OR IGNORE INTO study_streak(id) VALUES(1)")
        ensureQBankColumn(db, "progress_v2", "test_id", "TEXT")
        val progressTestIdMigrated = db.rawQuery("SELECT meta_value FROM progress_meta WHERE meta_key='progress_v2_test_id_migrated' LIMIT 1", null).use { c -> c.moveToFirst() && c.getString(0) == "1" }
        if (!progressTestIdMigrated) {
            db.execSQL("UPDATE progress_v2 SET test_id=substr(stable_key,1,instr(stable_key,':')-1) WHERE (test_id IS NULL OR test_id='') AND instr(stable_key,':')>1")
            db.execSQL("INSERT OR REPLACE INTO progress_meta(meta_key,meta_value) VALUES('progress_v2_test_id_migrated','1')")
        }
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_progress_v2_test_status ON progress_v2(test_id,status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_progress_v2_due ON progress_v2(next_due,last_attempted)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_source ON test(source_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_test ON question(test_id,position)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_source ON question(source_question_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_note(question_id INTEGER PRIMARY KEY, note TEXT NOT NULL, updated_at INTEGER NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_note_image(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, path TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_note_image_question ON question_note_image(question_id,created_at)")
        // FTS4 keeps global search fast even for very large QBanks. Content is rebuilt lazily
        // from the normalized SQLite tables, so the 160 MB source HTML is never searched.
        try {
            db.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS question_fts USING fts4(question_id UNINDEXED, test_id UNINDEXED, source_id UNINDEXED, content)")
        } catch (_: Exception) { /* Some vendor SQLite builds may omit FTS; LIKE fallback remains available. */ }
    }
private fun ensureQBankColumn(db: SQLiteDatabase, table: String, column: String, definition: String) {
        val exists = db.rawQuery("PRAGMA table_info($table)", null).use { c ->
            var found = false
            while (c.moveToNext()) if (c.getString(1).equals(column, true)) { found = true; break }
            found
        }
        if (!exists) db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
    }
private object QBankDatabaseProvider {
    private const val DB_NAME = "qbank.db"
    private const val DB_VERSION = 6
    @Volatile private var helper: Helper? = null
    fun resetForTest(context: Context) {
        synchronized(this) {
            runCatching { helper?.close() }
            helper = null
            context.applicationContext.deleteDatabase(DB_NAME)
        }
    }
    fun get(context: Context): SQLiteDatabase {
        val appContext = context.applicationContext
        // Only helper identity/filesystem reconciliation needs the provider monitor. Do not hold
        // the process-wide provider lock while SQLiteOpenHelper opens/configures the database:
        // SQLiteOpenHelper already serializes its own getWritableDatabase() path, and keeping the
        // outer lock across it makes unrelated QBank callers queue behind database initialization.
        val h = synchronized(this) {
            val databaseFile = appContext.getDatabasePath(DB_NAME)
            val existing = helper
            // If the database path was externally removed while SQLiteOpenHelper was still
            // open, the helper may retain an unlinked old inode. Reusing it would make a new
            // qbank.db path appear schema-less to other connections. Reconcile the helper with
            // the filesystem before handing out the shared database.
            if (existing != null && !databaseFile.exists()) {
                runCatching { existing.close() }
                helper = null
            }
            helper ?: Helper(appContext).also { helper = it }
        }
        return RovexPerformanceTrace.scoped("qbank-db-open") {
            h.writableDatabase
        }
    }
    private class Helper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onConfigure(db: SQLiteDatabase) {
            super.onConfigure(db)
            db.setForeignKeyConstraintsEnabled(true)
            db.enableWriteAheadLogging()
        }
        override fun onCreate(db: SQLiteDatabase) = createQBankSchema(db)
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = createQBankSchema(db)
    }
}

private val qBankDatabaseProvider = QBankDatabaseProvider

class QBankDb(context: Context) {
    private val appContext = context.applicationContext

    /**
     * Resolve the current provider-owned database for every operation. The test/reset lifecycle
     * may close and replace the shared SQLiteOpenHelper; retaining a SQLiteDatabase reference
     * here would leave long-lived managers pointing at a permanently closed handle.
     */
    private val db: SQLiteDatabase
        get() = qBankDatabaseProvider.get(appContext)

    /** Reset implementation is extracted, but resolves the provider-owned DB per operation. */
    private val progressResetter by lazy {
        QBankProgressResetter(
            dbProvider = { db },
            sourceNameForId = { id -> sourceNameForId(id) }
        )
    }

    /** Resolve a source display name for progress-reset compatibility. */
    private fun sourceNameForId(sourceId: Long): String = db.rawQuery(
        "SELECT COALESCE(display_name,file_name,'') FROM source WHERE id=? LIMIT 1",
        arrayOf(sourceId.toString())
    ).use { c -> if (c.moveToFirst()) c.getString(0).orEmpty() else "" }

    /** Physical source deletion is extracted and wired here; QBankDb remains its facade. */
    private val sourceDeletionManager by lazy {
        QBankSourceDeletionManager(
            dbProvider = { db },
            appContext = appContext,
            scheduleSearchIndexRepair = { scheduleSearchIndexRepair() }
        )
    }

    /** Durable learner state is extracted behind the QBankDb compatibility facade. */
    private val studyStateStore by lazy {
        QBankStudyStateStore(
            dbProvider = { db },
            sourceIdForTest = { id -> sourceIdForTest(id) },
            lock = qBankDatabaseProvider
        )
    }


    /**
     * Search-index health check.
     *
     * IMPORTANT: this method is called from interactive search paths. It must never rebuild the
     * entire FTS corpus synchronously: a large QBank can contain hundreds of thousands of rows,
     * and doing the rebuild here can monopolize SQLite/CPU long enough to make the foreground
     * Activity appear hung. Interactive search therefore uses FTS opportunistically and falls back
     * only when necessary; repair is deferred to an idle-only WorkManager task.
     */
    fun ensureSearchIndex(){
        // Interactive callers only verify the schema. They must never enqueue a full-corpus
        // repair merely because the index is dirty; search has a bounded FTS-first fallback and
        // maintenance is handled by WorkManager while the device is idle.
        ensureSearchIndexSchema()
    }

    /** Cached health signal for callers that must bound fallback fan-out while FTS is rebuilding. */
    fun isSearchIndexReady(): Boolean = isSearchIndexComplete()

    private fun ensureSearchIndexSchema(){
        runCatching {
            var schemaOk=false
            db.rawQuery("PRAGMA table_info(question_fts)", null).use { c ->
                var cols=0
                while(c.moveToNext()){
                    if(c.getString(1)=="source_id") schemaOk=true
                    cols++
                }
                if(cols < 4) schemaOk=false
            }
            if(!schemaOk){
                db.execSQL("DROP TABLE IF EXISTS question_fts")
                db.execSQL("CREATE VIRTUAL TABLE question_fts USING fts4(question_id UNINDEXED, test_id UNINDEXED, source_id UNINDEXED, content)")
                db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','1')")
            }
        }.onFailure { e ->
            android.util.Log.w("QBankDb", "Search index schema check deferred: ${e.message}")
            ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.search_index_schema_check_failed:${e.javaClass.simpleName}")
        }
    }

    /**
     * Rebuild only when requested by the background repair executor. Kept separate from the
     * interactive search path so an incomplete index can never turn typing into a long SQLite
     * write transaction.
     */
    private fun rebuildSearchIndexIfNeeded(){
        try {
            ensureSearchIndexSchema()
            val dirty = db.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='dirty' LIMIT 1", null).use { c ->
                c.moveToFirst() && c.getString(0) != "0"
            }
            val garbagePending = db.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='garbage_pending' LIMIT 1", null).use { c ->
                c.moveToFirst() && c.getString(0) != "0"
            }
            if (!dirty && !garbagePending) return
            val repairGeneration = searchIndexMutationGeneration.get()

            // Rebuild in small, independently committed batches. The previous implementation
            // held one transaction for the entire corpus; on a large QBank that monopolized the
            // SQLite writer and CPU and starved foreground navigation/Ben/Frankenstein.
            db.beginTransactionNonExclusive()
            try {
                db.delete("question_fts", null, null)
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }

            var lastId = 0L
            var inserted = 0L
            while (true) {
                val rows = db.rawQuery(
                    "SELECT q.id,q.test_id,s.id,COALESCE(q.text,'')||' '||COALESCE(q.raw_text,'')||' '||COALESCE(q.correct_answer,'')||' '||COALESCE(q.explanation,'')||' '||COALESCE(q.bot,'')||' '||COALESCE(q.video,'')||' '||COALESCE(q.audio,'')||' '||COALESCE(t.title,'')||' '||COALESCE(t.path,'')||' '||COALESCE(s.display_name,s.file_name,'')||' '||COALESCE((SELECT group_concat(COALESCE(o.label,'')||' '||COALESCE(o.text,''),' ') FROM option_item o WHERE o.question_id=q.id),'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.id>? ORDER BY q.id LIMIT 100",
                    arrayOf(lastId.toString())
                ).use { c ->
                    buildList { while (c.moveToNext()) add(arrayOf(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3))) }
                }
                if (rows.isEmpty()) break
                db.beginTransactionNonExclusive()
                try {
                    val st = db.compileStatement("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)")
                    try {
                        rows.forEach { row ->
                            st.bindLong(1, row[0] as Long)
                            st.bindString(2, row[1] as String)
                            st.bindLong(3, row[2] as Long)
                            st.bindString(4, row[3] as String)
                            st.executeInsert()
                            st.clearBindings()
                        }
                    } finally { st.close() }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
                lastId = rows.last()[0] as Long
                inserted += rows.size
            }

            val indexed = db.rawQuery("SELECT COUNT(*) FROM question_fts", null).use { c -> c.moveToFirst(); c.getLong(0) }
            val questions = db.rawQuery("SELECT COUNT(*) FROM question", null).use { c -> c.moveToFirst(); c.getLong(0) }
            if (indexed == questions && searchIndexMutationGeneration.get() == repairGeneration) {
                db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")
                db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending','0')")
                synchronized(searchIndexHealthLock) {
                    searchIndexHealthy = true
                    searchIndexHealthCheckedAt = android.os.SystemClock.elapsedRealtime()
                }
            } else {
                markSearchIndexDirty()
            }
        } catch (e: Exception) {
            android.util.Log.w("QBankDb", "Search index maintenance deferred: ${e.message}")
            markSearchIndexDirty()
        }
    }

    /** Called only by idle WorkManager maintenance; never from an interactive search path. */
    fun repairSearchIndexForMaintenance(): Boolean {
        rebuildSearchIndexIfNeeded()
        return isSearchIndexComplete()
    }

    private fun isSearchIndexComplete(): Boolean {
        val now = android.os.SystemClock.elapsedRealtime()
        synchronized(searchIndexHealthLock) {
            if (now - searchIndexHealthCheckedAt < SEARCH_INDEX_HEALTH_TTL_MS) {
                return searchIndexHealthy
            }
            val healthy = runCatching {
                val dirty = db.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='dirty' LIMIT 1", null).use { c ->
                    c.moveToFirst() && c.getString(0) != "0"
                }
                if (dirty) false else {
                    val live = db.rawQuery(
                        "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
                        null
                    ).use { c -> c.moveToFirst(); c.getLong(0) }
                    val indexedLive = db.rawQuery(
                        "SELECT COUNT(*) FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
                        null
                    ).use { c -> c.moveToFirst(); c.getLong(0) }
                    live == indexedLive
                }
            }.getOrDefault(false)
            searchIndexHealthy = healthy
            searchIndexHealthCheckedAt = now
            return healthy
        }
    }

    private fun scheduleSearchIndexRepair() {
        runCatching {
            QBankSearchIndexMaintenanceWorker.enqueue(RovexApplicationContextHolder.context)
        }.onFailure {
            ProductionCrashReporter.breadcrumb(
                RovexApplicationContextHolder.context,
                "QBankDb.search_index_maintenance_enqueue_failed:${it.javaClass.simpleName}"
            )
        }
    }

    private fun markSearchIndexDirty() {
        searchIndexMutationGeneration.incrementAndGet()
        runCatching { db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','1')") }
        synchronized(searchIndexHealthLock) {
            searchIndexHealthy = false
            searchIndexHealthCheckedAt = 0L
        }
    }

    /**
     * A matching row count is not sufficient proof that FTS content is current: one stale row
     * can replace one missing row and produce the same count. Mutations therefore never declare
     * the index clean. The authoritative rebuild is the only operation allowed to publish the
     * clean state; this turns a subtle same-count stale-index bug into a bounded background repair.
     */
    private fun finalizeIncrementalSearchIndex() {
        // Import paths populate FTS transactionally as each question is inserted. Rebuilding the
        // entire corpus after every successful import was redundant and could make the device
        // look hung immediately after import. Publish the existing index only when its cardinality
        // exactly matches the normalized question table; otherwise retain the dirty flag and let
        // the bounded background repair rebuild it.
        val consistent = runCatching {
            // Import writes FTS rows transactionally with normalized questions. Do not compare
            // global cardinality here: stale rows from a previously tombstoned source may still
            // exist physically until idle compaction, while live-question search remains correct.
            db.rawQuery("SELECT 1 FROM question_fts LIMIT 1", null).use { true }
        }.getOrDefault(false)
        if (consistent) {
            val liveQuestions = runCatching {
                db.rawQuery("SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0", null).use { c -> c.moveToFirst(); c.getLong(0) }
            }.getOrDefault(-1L)
            val indexedLiveQuestions = runCatching {
                db.rawQuery("SELECT COUNT(*) FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0", null).use { c -> c.moveToFirst(); c.getLong(0) }
            }.getOrDefault(-2L)
            if (liveQuestions >= 0L && liveQuestions == indexedLiveQuestions) {
                runCatching { db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')") }
                synchronized(searchIndexHealthLock) {
                    searchIndexHealthy = true
                    searchIndexHealthCheckedAt = android.os.SystemClock.elapsedRealtime()
                }
            } else {
                markSearchIndexDirty()
                scheduleSearchIndexRepair()
            }
        } else {
            markSearchIndexDirty()
            scheduleSearchIndexRepair()
        }
    }

    internal fun hasLegacyTombstonedSources(): Boolean = db.rawQuery(
        "SELECT 1 FROM source WHERE deleting=1 AND COALESCE(delete_requested,0)=0 LIMIT 1", null
    ).use { it.moveToFirst() }

    fun questionExists(questionId:Long):Boolean = db.rawQuery("SELECT 1 FROM question WHERE id=? LIMIT 1", arrayOf(questionId.toString())).use { it.moveToFirst() }
    /**
     * Lightweight keyset-paginated corpus access for offline AI indexing. This returns only
     * bounded text/context rows and never materializes the whole QBank in memory.
     */
    fun aiIndexQuestionCount(): Int = db.rawQuery("SELECT COUNT(*) FROM question", null).use { c -> c.moveToFirst(); c.getInt(0) }

    fun aiIndexBatch(afterQuestionId: Long = 0L, limit: Int = 64): List<AiIndexRow> {
        val safeLimit = limit.coerceIn(1, 256)
        val sql = "SELECT q.id, COALESCE(q.text,''), COALESCE(q.explanation,''), COALESCE(t.title,''), COALESCE(t.path,''), COALESCE(s.display_name,s.file_name,'') " +
            "FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 " +
            "WHERE q.id>? ORDER BY q.id LIMIT $safeLimit"
        return db.rawQuery(sql, arrayOf(afterQuestionId.toString())).use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(AiIndexRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5)))
                }
            }
        }
    }

    /** Bulk existence check used by collection/backup flows. Avoids one SQLite query per ID. */
    fun existingQuestionIds(ids: LongArray): LongArray {
        if (ids.isEmpty()) return longArrayOf()
        val out = ArrayList<Long>(ids.size)
        ids.distinct().chunked(500).forEach { chunk ->
            val placeholders = chunk.joinToString(",") { "?" }
            db.rawQuery("SELECT id FROM question WHERE id IN ($placeholders)", chunk.map { it.toString() }.toTypedArray()).use { c ->
                while (c.moveToNext()) out.add(c.getLong(0))
            }
        }
        return out.toLongArray()
    }

    data class StoredProgress(
        val selected: String?, val status: String?, val bookmark: String?, val review: Boolean,
        val attempts: Int, val lastAttempted: Long, val timeMs: Long, val mistake: String?,
        val easeFactor: Float, val repetitions: Int, val intervalDays: Float, val nextDue: Long
    )

    fun readStoredProgress(stableKey: String): StoredProgress? = studyStateStore.readStoredProgress(stableKey)
    fun writeStoredProgress(stableKey: String, value: StoredProgress) = studyStateStore.writeStoredProgress(stableKey, value)
    fun deleteStoredProgress(stableKey: String) = studyStateStore.deleteStoredProgress(stableKey)
    fun allStoredProgress(): Map<String, StoredProgress> = studyStateStore.allStoredProgress()
    fun getProgressMeta(key: String): String? = studyStateStore.getProgressMeta(key)
    fun putProgressMeta(key: String, value: String?) = studyStateStore.putProgressMeta(key, value)
    fun allProgressMeta(): Map<String,String> = studyStateStore.allProgressMeta()
    fun recordStudyStreakDay(timestamp: Long = System.currentTimeMillis()): StreakManager.Snapshot = studyStateStore.recordStudyStreakDay(timestamp)
    fun readStudyStreak(): StreakManager.Snapshot = studyStateStore.readStudyStreak()
    fun studyReminderAlreadySent(day: String): Boolean = studyStateStore.studyReminderAlreadySent(day)
    fun markStudyReminderSent(day: String) = studyStateStore.markStudyReminderSent(day)
    fun notificationPermissionPrompted(): Boolean = studyStateStore.notificationPermissionPrompted()
    fun markNotificationPermissionPrompted() = studyStateStore.markNotificationPermissionPrompted()
    fun replaceStoredProgress(entries: Map<String, StoredProgress>, meta: Map<String,String>) = studyStateStore.replaceStoredProgress(entries, meta)
    fun beginProgressMetaTransaction(testId:String, position:Int, sourceId:Long, sourceName:String?, resumeSavedAt:Long? = null) = studyStateStore.beginProgressMetaTransaction(testId, position, sourceId, sourceName, resumeSavedAt)

    internal fun snapshotTo(destination: File) {
        destination.parentFile?.mkdirs()
        if (destination.exists()) destination.delete()
        db.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { }
        val escaped = destination.absolutePath.replace("'", "''")
        db.rawQuery("VACUUM INTO '$escaped'", null).use { }
        check(destination.isFile && destination.length() > 0L) { "Database snapshot failed: ${destination.name}" }
    }
    fun close(){ /* shared process-scoped database */ }

    fun sources(): List<Source> =
        db.rawQuery("SELECT id,COALESCE(display_name,file_name),provider,COALESCE(series_number,'') FROM source WHERE deleting=0 ORDER BY imported_at DESC",null).use{c->buildList{while(c.moveToNext())add(Source(c.getLong(0),c.getString(1),c.getString(2),c.getString(3)))}}

    /**
     * Records an explicit user deletion intent and hides the QBank immediately.
     *
     * This is deliberately separate from [deleteSource]. The latter performs the potentially
     * large physical cleanup and is still used by import replacement and recovery. Interactive
     * UI must never wait for that cleanup before refreshing its catalog. The tombstone is the
     * durable hand-off between the UI and the resumable deletion worker.
     */
    fun requestSourceDeletion(sourceId: Long): Boolean {
        if (sourceId <= 0L) return false
        return runCatching {
            withWriteRetry("request-source-deletion") {
                db.beginTransactionNonExclusive()
                try {
                    val exists = db.rawQuery(
                        "SELECT 1 FROM source WHERE id=? LIMIT 1",
                        arrayOf(sourceId.toString())
                    ).use { it.moveToFirst() }
                    if (!exists) {
                        db.setTransactionSuccessful()
                        return@withWriteRetry false
                    }
                    db.execSQL(
                        "UPDATE source SET deleting=1,delete_requested=1 WHERE id=?",
                        arrayOf(sourceId.toString())
                    )
                    db.setTransactionSuccessful()
                    true
                } finally {
                    db.endTransaction()
                }
            }.also { accepted ->
                if (accepted) {
                    // This is the durable admission boundary for crash/process-death recovery.
                    // Startup only consults this tiny marker; it does not open SQLite merely to
                    // discover whether there is work to recover.
                    QBankDeletionRecoveryWorker.markRecoveryNeeded(appContext)
                    AppState.changed("qbank_delete_requested")
                    PerformanceManager.invalidate()
                }
            }
        }.getOrElse { e ->
            Log.e("QBankDb", "QBank deletion request failed for source=$sourceId", e)
            ProductionCrashReporter.recordNonFatal(e, "QBANK_DELETE_REQUEST", mapOf("source_id" to sourceId.toString()))
            false
        }
    }
    fun sourceById(sourceId: Long): Source? = db.rawQuery("SELECT id,COALESCE(display_name,file_name),provider,COALESCE(series_number,'') FROM source WHERE id=? AND deleting=0 LIMIT 1", arrayOf(sourceId.toString())).use { c ->
        if (c.moveToFirst()) Source(c.getLong(0), c.getString(1), c.getString(2), c.getString(3)) else null
    }
    fun sourceNameForTest(testId:String):String? = db.rawQuery("SELECT COALESCE(s.display_name,s.file_name) FROM source s JOIN test t ON t.source_id=s.id WHERE t.id=? AND s.deleting=0 LIMIT 1", arrayOf(testId)).use { c -> if (c.moveToFirst()) c.getString(0) else null }
    fun testById(testId:String):Test? = db.rawQuery("SELECT t.id,t.title,t.path,t.num_questions,t.total_marks,t.duration_seconds,t.time_per_question,COALESCE(t.series_number,'') FROM test t JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.id=? LIMIT 1",arrayOf(testId)).use { c -> if(c.moveToFirst()) Test(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getDouble(4),c.getInt(5),c.getDouble(6),c.getString(7)) else null }
    fun tests(sourceId:Long):List<Test> = db.rawQuery("SELECT t.id,t.title,t.path,t.num_questions,t.total_marks,t.duration_seconds,t.time_per_question,COALESCE(t.series_number,'') FROM test t JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.source_id=? ORDER BY t.rowid",arrayOf(sourceId.toString())).use{c->buildList{while(c.moveToNext())add(Test(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getDouble(4),c.getInt(5),c.getDouble(6),c.getString(7)))}}
    fun questionContext(questionId:Long):Pair<String,String> = db.rawQuery("SELECT COALESCE(t.title,''), COALESCE(t.path,'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.id=? LIMIT 1",arrayOf(questionId.toString())).use { c ->
        if(c.moveToFirst()){ val title=c.getString(0).orEmpty(); val path=c.getString(1).orEmpty(); val subject=(path.split("/","\\",">","::").map{it.trim()}.filter{it.isNotBlank()}.firstOrNull() ?: title.substringBefore("-").trim()).ifBlank{"General"}; subject to title.ifBlank{"Question $questionId"} } else "Unlinked" to "Question $questionId"
    }

    fun questionCount(testId:String):Int = db.rawQuery("SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.test_id=? AND s.deleting=0", arrayOf(testId)).use { c -> c.moveToFirst(); c.getInt(0) }
    fun questionByStableKey(stableKey:String):Question? {
        val parts = stableKey.split(":")
        if (parts.size < 3) return null
        val testId = parts.dropLast(2).joinToString(":")
        val position = parts[parts.size - 2].toIntOrNull() ?: return null
        val sourceQuestionId = parts.last()
        return questionAt(testId, position)?.takeIf { it.sourceId.orEmpty() == sourceQuestionId }
    }

    fun rawQuestionPosition(testId:String, questionId:Long):Int? = db.rawQuery("SELECT q.position FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.test_id=? AND q.id=? AND s.deleting=0 LIMIT 1", arrayOf(testId, questionId.toString())).use { c -> if (c.moveToFirst()) c.getInt(0) else null }

    fun questionAt(testId:String, position:Int):Question? {
        return db.rawQuery("SELECT q.id,q.position,q.source_question_id,COALESCE(q.text,''),q.raw_text,q.correct_answer,q.explanation,q.bot,q.video,q.audio FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.test_id=? AND q.position=? AND s.deleting=0 LIMIT 1", arrayOf(testId, position.toString())).use { c ->
            if (!c.moveToFirst()) return@use null
            val id=c.getLong(0); val opts=mutableListOf<Option>()
            db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position",arrayOf(id.toString())).use{o->while(o.moveToNext())opts.add(Option(o.getString(0) ?: "",o.getString(1) ?: "",o.getInt(2)!=0))}
            Question(id,stableKey(testId,c.getInt(1),c.getString(2)),c.getInt(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),opts,images(id,"question"),images(id,"explanation"))
        }
    }

    fun questionById(questionId:Long):Question? {
        return db.rawQuery("SELECT q.test_id,q.position FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.id=? AND s.deleting=0 LIMIT 1", arrayOf(questionId.toString())).use { c ->
            if (!c.moveToFirst()) return@use null
            questionAt(c.getString(0), c.getInt(1))
        }
    }

    fun sourceIdForTest(testId:String):Long = db.rawQuery("SELECT t.source_id FROM test t JOIN source s ON s.id=t.source_id WHERE t.id=? AND s.deleting=0 LIMIT 1",arrayOf(testId)).use { c -> if(c.moveToFirst()) c.getLong(0) else 0L }
    fun testIdForQuestion(questionId:Long):String? = db.rawQuery("SELECT q.test_id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.id=? AND s.deleting=0 LIMIT 1", arrayOf(questionId.toString())).use { c -> if(c.moveToFirst()) c.getString(0) else null }

    fun questions(testId:String):List<Question>{
        val out=mutableListOf<Question>()
        db.rawQuery("SELECT q.id,q.position,q.source_question_id,q.text,q.raw_text,q.correct_answer,q.explanation,q.bot,q.video,q.audio FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.test_id=? AND s.deleting=0 ORDER BY q.position",arrayOf(testId)).use{c->while(c.moveToNext()){
            val id=c.getLong(0); val opts=mutableListOf<Option>()
            db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position",arrayOf(id.toString())).use{o->while(o.moveToNext())opts.add(Option(o.getString(0) ?: "",o.getString(1) ?: "",o.getInt(2)!=0))}
            out.add(Question(id,stableKey(testId,c.getInt(1),c.getString(2)),c.getInt(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),opts,images(id,"question"),images(id,"explanation")))
        }}
        return out
    }
    private fun images(qid:Long,kind:String)=db.rawQuery("SELECT uri FROM question_image WHERE question_id=? AND kind=? ORDER BY position",arrayOf(qid.toString(),kind)).use{c->buildList{while(c.moveToNext())add(c.getString(0))}}
    private fun stableKey(testId:String, position:Int, sourceQuestionId:String?):String = "$testId:$position:${sourceQuestionId.orEmpty()}"

    data class HomeStudyStats(
        val todayRecords: List<Pair<Long, Boolean>>,
        val today: Int,
        val attempted: Int,
        val correct: Int,
        val wrong: Int,
        val week: Int,
        val bookmarks: Int,
        val days: List<Pair<Long, Pair<Int, Int>>>
    )

    /**
     * Home-only aggregate path. It deliberately avoids materializing every QuestionRef and every
     * progress record on application resume. All aggregation is performed by SQLite over sparse
     * progress_v2 rows and live QBank joins.
     */
    fun bookmarkCounts(): Map<String, Int> = studyStateStore.bookmarkCounts()
    fun homeStudyStats(todayStart: Long, weekStart: Long, graphStart: Long): HomeStudyStats = studyStateStore.homeStudyStats(todayStart, weekStart, graphStart)

    data class StudyAttemptHistoryRow(
        val stableKey: String, val attemptedAt: Long, val correct: Boolean, val timeMs: Long
    )

    fun studyAttemptHistory(stableKeys: Set<String>, since: Long): List<StudyAttemptHistoryRow> = studyStateStore.studyAttemptHistory(stableKeys, since)
    fun recordStudyAttempt(stableKey: String, testId: String, sourceId: Long, attemptedAt: Long, correct: Boolean) = studyStateStore.recordStudyAttempt(stableKey, testId, sourceId, attemptedAt, correct)
    fun updateLatestStudyAttemptTime(stableKey: String, elapsedMs: Long) = studyStateStore.updateLatestStudyAttemptTime(stableKey, elapsedMs)
    fun seedStudyAttemptHistoryIfNeeded() = studyStateStore.seedStudyAttemptHistoryIfNeeded()

    fun allStableKeys():List<String> = db.rawQuery("SELECT test_id,position,source_question_id FROM question ORDER BY rowid",null).use { c -> buildList { while(c.moveToNext()) add(stableKey(c.getString(0), c.getInt(1), c.getString(2))) } }

    /**
     * Question-reference index. Dashboard paths use lightweight=true so opening Rovex never
     * materializes every question's HTML/text just to count or route questions.
     */
    /**
     * Dashboard-only index: one lightweight row per imported test, with progress
     * aggregated in SQLite. This avoids materializing one QuestionRef object for
     * every question just to draw the section dashboard.
     */
    fun dashboardTestRows(): List<DashboardTestRow> {
        // Dashboard rendering must never scan/materialize the question corpus. The imported
        // test row already owns the authoritative question count; durable progress is sparse
        // in progress_v2 and can be aggregated independently. This keeps opening the QBank
        // dashboard proportional to the number of sub-QBanks rather than total questions.
        val sql = """
            SELECT t.id,
                   COALESCE(t.title, ''),
                   COALESCE(t.path, ''),
                   COALESCE(s.display_name, s.file_name, ''),
                   COALESCE(t.num_questions, 0),
                   COALESCE((SELECT SUM(COALESCE(t2.num_questions,0)) FROM test t2 WHERE t2.source_id=t.source_id), 0),
                   COALESCE(p.solved, 0),
                   COALESCE(p.correct, 0),
                   COALESCE(CAST(m.meta_value AS INTEGER), 0)
            FROM test t
            JOIN source s ON s.id=t.source_id AND s.deleting=0
            LEFT JOIN (
                SELECT test_id,
                       SUM(CASE WHEN status IS NOT NULL AND status <> '' THEN 1 ELSE 0 END) AS solved,
                       SUM(CASE WHEN status = 'correct' THEN 1 ELSE 0 END) AS correct
                FROM progress_v2
                WHERE test_id IS NOT NULL AND test_id <> ''
                GROUP BY test_id
            ) p ON p.test_id=t.id
            LEFT JOIN progress_meta m ON m.meta_key=(t.id || ':position')
            ORDER BY s.imported_at DESC, t.rowid
        """.trimIndent()
        return db.rawQuery(sql, null).use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(DashboardTestRow(
                        testId = c.getString(0),
                        name = c.getString(1),
                        path = c.getString(2),
                        source = c.getString(3),
                        total = c.getInt(4),
                        sourceTotal = c.getInt(5),
                        solved = c.getInt(6),
                        correct = c.getInt(7),
                        position = c.getInt(8).coerceAtLeast(0)
                    ))
                }
            }
        }
    }

    fun allQuestionRefs(lightweight: Boolean = false):List<QuestionRef> {
        val textExpr = if (lightweight) "''" else "COALESCE(q.text,'')"
        val sql = "SELECT q.id,q.test_id,q.position,q.source_question_id,$textExpr,t.title,t.path,s.id,COALESCE(s.display_name,s.file_name) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 ORDER BY s.imported_at DESC,t.rowid,q.position"
        return db.rawQuery(sql,null).use{c->buildList{while(c.moveToNext()){
            val id=c.getLong(0); val testId=c.getString(1); val pos=c.getInt(2); val sid=c.getString(3)
            add(QuestionRef(id,"$testId:$pos:${sid ?: ""}",testId,pos,c.getString(4) ?: "",c.getString(5),c.getLong(7),c.getString(8),categoryFor(c.getString(6), c.getString(5), c.getString(8))))
        }}}
    }
    private fun categoryFor(path:String?, title:String, sourceName:String):String {
        fun useful(v:String):Boolean {
            val x=v.trim().lowercase()
            return x.isNotBlank() && x !in setOf("test","tests","section","sections","qbank","question bank","quiz","quizzes","practice")
        }
        val raw=(path ?: "").trim().trim('/').replace("\\", "/")
        val parts=raw.split('/').map{it.trim()}.filter{useful(it)}
        if(parts.isNotEmpty()) return parts.last().take(48)
        val titleParts=title.split(Regex("\\s*[-–—|:]\\s*"), limit=2).map{it.trim()}
        if(titleParts.isNotEmpty() && useful(titleParts.first())) return titleParts.first().take(48)
        val file=sourceName.substringBeforeLast('.', sourceName).trim()
        return if(useful(file)) file.take(48) else "General"
    }

    fun updateSourceMetadata(sourceId:Long, displayName:String, seriesNumber:String):Boolean {
        val name = displayName.trim().take(180)
        if (name.isBlank()) return false
        return try {
            db.execSQL("UPDATE source SET display_name=?,series_number=? WHERE id=?", arrayOf<Any?>(name, seriesNumber.trim().take(80), sourceId))
            AppState.changed()
            true
        } catch (_: android.database.sqlite.SQLiteConstraintException) { false }
    }

    fun updateTestMetadata(testId:String, title:String, seriesNumber:String):Boolean {
        val name = title.trim().take(180)
        if (name.isBlank()) return false
        return try {
            db.execSQL("UPDATE test SET title=?,series_number=? WHERE id=?", arrayOf(name, seriesNumber.trim().take(80), testId))
            markSearchIndexDirty()
            AppState.changed()
            true
        } catch (_: Exception) { false }
    }

    /**
     * Resets the learner state for exactly one imported QBank while preserving its questions,
     * tests, media and immutable study-attempt history. This is intentionally a source-scoped
     * operation so another QBank can never be reset as a side effect.
     */
    /**
     * Resets learner state for exactly one imported sub-QBank/test. Questions and the parent
     * source remain intact; immutable study-attempt history is retained.
     */
    fun resetTestProgress(testId: String): Boolean {
        val reset = progressResetter.resetTestProgress(testId)
        if (reset) AppState.changed()
        return reset
    }

    fun resetSourceProgress(sourceId: Long): Boolean {
        val reset = progressResetter.resetSourceProgress(sourceId)
        if (reset) {
            PerformanceManager.invalidateProgress()
            AppState.changed()
        }
        return reset
    }


    /**
     * Deletes an imported QBank without monopolizing the database connection.
     *
     * The old implementation performed several deletes once per test while holding one
     * long write transaction. On large QBanks that made foreground readers wait long enough
     * to trigger an Android input ANR. This implementation uses set-based SQL, WAL-friendly
     * non-exclusive transactions, and a separate low-priority deletion executor at the caller.
     * FTS cleanup is intentionally a separate transaction so the normalized question/test
     * database is released quickly; search-index cleanup cannot make deleted questions visible
     * because all searches join the normalized tables.
     */
    /**
     * One-time safety reconciliation for the pre-v8.3.434 tombstone bug. Before import identity
     * was separated from the human filename, importing a second same-named QBank could mark the
     * existing source deleting and then fail on SQLite locking/replace. A complete source with
     * all expected questions is not a partially-deleted source, so it is safe to restore it.
     * Partially deleted sources remain tombstoned for normal resumable deletion.
     */
    /**
     * Recovers legacy hidden sources created before the deletion-intent split. These rows are
     * never auto-deleted: they are data-recovery candidates, not proof of a user delete. A
     * source with any surviving test/question content is restored so existing user data remains
     * reachable. Explicit deletes in the current schema set delete_requested=1 and are handled
     * separately by the resumable deletion worker.
     */
    fun restoreLegacyTombstonedSources(): Int {
        var restored = 0
        db.rawQuery(
            "SELECT s.id FROM source s WHERE s.deleting=1 AND COALESCE(s.delete_requested,0)=0 ORDER BY s.imported_at,s.id", null
        ).use { c ->
            val ids = buildList { while (c.moveToNext()) add(c.getLong(0)) }
            ids.forEach { sourceId ->
                val hasContent = runCatching {
                    db.rawQuery(
                        "SELECT EXISTS(SELECT 1 FROM test WHERE source_id=?) OR EXISTS(SELECT 1 FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?)",
                        arrayOf(sourceId.toString(), sourceId.toString())
                    ).use { x -> x.moveToFirst() && x.getInt(0) == 1 }
                }.getOrDefault(false)
                if (hasContent) {
                    runCatching {
                        db.beginTransactionNonExclusive()
                        try {
                            db.execSQL("UPDATE source SET deleting=0 WHERE id=? AND delete_requested=0", arrayOf(sourceId))
                            db.setTransactionSuccessful()
                            restored++
                        } finally { db.endTransaction() }
                    }
                }
            }
        }
        if (restored > 0) {
            PerformanceManager.invalidate()
            AppState.changed("qbank_legacy_tombstones_recovered")
        }
        return restored
    }

    /** Returns only explicit deletion intents; legacy hidden sources are never destroyed by recovery. */
    fun pendingDeletingSourceIds(): List<Long> =
        db.rawQuery("SELECT id FROM source WHERE deleting=1 AND delete_requested=1 ORDER BY imported_at,id", null).use { c ->
            buildList { while(c.moveToNext()) add(c.getLong(0)) }
        }

    /**
     * Root-safe, resumable QBank deletion facade. Physical cleanup is owned by
     * [QBankSourceDeletionManager]; QBankDb remains the database-facing compatibility API.
     */
    fun deleteSource(
        sourceId:Long,
        repairSearchIndex:Boolean = true,
        maxQuestionBatches:Int = Int.MAX_VALUE,
        shouldPause: (() -> Boolean)? = null
    ): Boolean = sourceDeletionManager.deleteSource(
        sourceId = sourceId,
        repairSearchIndex = repairSearchIndex,
        maxQuestionBatches = maxQuestionBatches,
        shouldPause = shouldPause
    )

    private inline fun <T> withWriteRetry(label: String, attempts: Int = 4, block: () -> T): T {
        var last: Throwable? = null
        for (attempt in 0 until attempts) {
            try { return block() } catch (t: android.database.sqlite.SQLiteDatabaseLockedException) {
                last = t
                if (attempt + 1 >= attempts) break
                java.util.concurrent.locks.LockSupport.parkNanos((20L shl attempt).coerceAtMost(160L) * 1_000_000L)
                if (Thread.currentThread().isInterrupted) throw InterruptedException("QBank delete interrupted")
            }
        }
        throw last ?: IllegalStateException("$label failed")
    }

    fun questionRefsForStableKeys(keys: Collection<String>): List<QuestionRef> {
        if (keys.isEmpty()) return emptyList()
        val parsed = keys.mapNotNull { key ->
            val first = key.indexOf(':')
            val last = key.lastIndexOf(':')
            if (first <= 0 || last <= first || last >= key.lastIndex) null
            else Triple(key.substring(0, first), key.substring(first + 1, last).toIntOrNull() ?: return@mapNotNull null, key.substring(last + 1))
        }.distinct()
        if (parsed.isEmpty()) return emptyList()
        val out = ArrayList<QuestionRef>(parsed.size)
        parsed.chunked(100).forEach { chunk ->
            val where = chunk.joinToString(" OR ") { "(q.test_id=? AND q.position=?)" }
            val args = chunk.flatMap { listOf(it.first, it.second.toString()) }.toTypedArray()
            db.rawQuery("SELECT q.id,q.test_id,q.position,COALESCE(q.source_question_id,''),COALESCE(q.text,''),COALESCE(t.title,''),s.id,COALESCE(s.display_name,s.file_name,''),COALESCE(t.path,'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE $where ORDER BY s.imported_at DESC,t.rowid,q.position", args).use { c ->
                while (c.moveToNext()) {
                    val testId=c.getString(1); val pos=c.getInt(2); val sourceQuestionId=c.getString(3)
                    out.add(QuestionRef(c.getLong(0), stableKey(testId,pos,sourceQuestionId), testId, pos, c.getString(4), c.getString(5), c.getLong(6), c.getString(7), categoryFor(c.getString(8), c.getString(5), c.getString(7))))
                }
            }
        }
        return out
    }

    /**
     * Resolves only the requested live question IDs. Unlike questionRefsForIds(), this never
     * materializes the entire QBank corpus; callers such as Frankenstein/Ren use it on bounded
     * candidate sets only.
     */
    fun questionRefsForIdsBounded(ids:LongArray):List<QuestionRef>{
        if(ids.isEmpty()) return emptyList()
        val unique = ids.asList().distinct().take(100)
        if(unique.isEmpty()) return emptyList()
        val byId = LinkedHashMap<Long, QuestionRef>(unique.size)
        unique.chunked(100).forEach { chunk ->
            val placeholders = chunk.joinToString(",") { "?" }
            val args = chunk.map(Long::toString).toTypedArray()
            db.rawQuery(
                "SELECT q.id,q.test_id,q.position,COALESCE(q.source_question_id,''),COALESCE(q.text,'')," +
                    "COALESCE(t.title,''),s.id,COALESCE(s.display_name,s.file_name,''),COALESCE(t.path,'') " +
                    "FROM question q JOIN test t ON t.id=q.test_id " +
                    "JOIN source s ON s.id=t.source_id AND s.deleting=0 " +
                    "WHERE q.id IN ($placeholders) ORDER BY q.id",
                args
            ).use { c ->
                while(c.moveToNext()) {
                    val testId = c.getString(1)
                    val pos = c.getInt(2)
                    val sourceQuestionId = c.getString(3)
                    byId[c.getLong(0)] = QuestionRef(
                        c.getLong(0),
                        stableKey(testId,pos,sourceQuestionId),
                        testId,
                        pos,
                        c.getString(4),
                        c.getString(5),
                        c.getLong(6),
                        c.getString(7),
                        categoryFor(c.getString(8), c.getString(5), c.getString(7))
                    )
                }
            }
        }
        return unique.mapNotNull { byId[it] }
    }

    fun questionRefsForIds(ids:LongArray):List<QuestionRef>{
        if(ids.isEmpty()) return emptyList()
        return questionRefsForIdsBounded(ids)
    }
    fun questionIdsMatchingText(token:String):LongArray = search(token).map{it.id}.toLongArray()
    fun saveNote(questionId:Long,note:String){
        val cleaned=note.trim()
        db.beginTransaction()
        try {
            if(cleaned.isBlank()) {
                // An image can itself be the saved note. Keep the owning Notes row alive
                // while attachments exist so image+text relationships are never orphaned
                // from the Notes surface when the text is cleared.
                val hasImages=db.rawQuery(
                    "SELECT 1 FROM question_note_image WHERE question_id=? LIMIT 1",
                    arrayOf(questionId.toString())
                ).use { it.moveToFirst() }
                if(hasImages) {
                    db.execSQL(
                        "INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)",
                        arrayOf<Any?>(questionId,"[Image note]",System.currentTimeMillis())
                    )
                } else {
                    db.delete("question_note","question_id=?",arrayOf(questionId.toString()))
                }
            } else {
                db.execSQL(
                    "INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)",
                    arrayOf<Any?>(questionId,cleaned,System.currentTimeMillis())
                )
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        AppState.changed()
    }
    fun deleteNote(questionId:Long){
        val paths=noteImages(questionId)
        db.beginTransaction()
        try {
            db.delete("question_note","question_id=?",arrayOf(questionId.toString()))
            db.delete("question_note_image","question_id=?",arrayOf(questionId.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        paths.forEach { runCatching { File(it).delete() } }
        AppState.changed()
    }
    fun deleteNotes(questionIds:LongArray){
        if(questionIds.isEmpty()) return
        val ids=questionIds.distinct()
        val paths=ids.flatMap { noteImages(it) }
        db.beginTransaction()
        try {
            ids.chunked(500).forEach { chunk ->
                val args=chunk.map{it.toString()}.toTypedArray()
                val placeholders=chunk.joinToString(","){ "?" }
                db.delete("question_note","question_id IN ($placeholders)",args)
                db.delete("question_note_image","question_id IN ($placeholders)",args)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        paths.forEach { runCatching { File(it).delete() } }
        AppState.changed()
    }
    fun note(questionId:Long):String? = db.rawQuery("SELECT note FROM question_note WHERE question_id=?",arrayOf(questionId.toString())).use{c->if(c.moveToFirst())c.getString(0) else null}
    fun notes():List<Pair<Long,String>> = db.rawQuery("SELECT question_id,note FROM question_note ORDER BY updated_at DESC",null).use{c->buildList{while(c.moveToNext())add(c.getLong(0) to c.getString(1))}}
    data class NoteRecord(
        val questionId: Long, val note: String, val updatedAt: Long,
        val testId: String, val subject: String, val testTitle: String, val sourceName: String, val position: Int,
        val imagePaths: List<String> = emptyList()
    )

    fun noteCount(): Int = db.rawQuery("SELECT COUNT(*) FROM question_note", null).use { c -> c.moveToFirst(); c.getInt(0) }

    fun noteRecords(): List<NoteRecord> = db.rawQuery(
        "SELECT n.question_id,n.note,n.updated_at,COALESCE(t.id,''),COALESCE(t.path,''),COALESCE(t.title,''),COALESCE(s.display_name,s.file_name,''),q.position,COALESCE((SELECT group_concat(path, char(31)) FROM question_note_image ni WHERE ni.question_id=n.question_id), '') FROM question_note n JOIN question q ON q.id=n.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 ORDER BY n.updated_at DESC", null
    ).use { c -> buildList {
        while (c.moveToNext()) {
            val testId = c.getString(3).orEmpty()
            val path = c.getString(4).orEmpty()
            val title = c.getString(5).orEmpty().ifBlank { "Question ${c.getLong(0)}" }
            val sourceName = c.getString(6).orEmpty().ifBlank { "Unknown QBank" }
            val subject = path.split('/', '\\', '>', ':').map { it.trim() }.firstOrNull { it.isNotBlank() }
                ?: title.split(Regex("\\s*[-–—|:]\\s*"), limit = 2).firstOrNull().orEmpty().trim().ifBlank { "General" }
            val images = c.getString(8).orEmpty().split(31.toChar()).map { it.trim() }.filter { it.isNotBlank() }
            add(NoteRecord(c.getLong(0), c.getString(1).orEmpty(), c.getLong(2), testId, subject, title, sourceName, c.getInt(7), images))
        }
    } }
    fun addNoteImage(questionId: Long, path: String) {
        if (path.isBlank()) return
        db.execSQL("INSERT INTO question_note_image(question_id,path,created_at) VALUES(?,?,?)", arrayOf<Any?>(questionId, path, System.currentTimeMillis()))
        AppState.changed()
    }
    fun noteImages(questionId: Long): List<String> = db.rawQuery("SELECT path FROM question_note_image WHERE question_id=? ORDER BY created_at", arrayOf(questionId.toString())).use { c -> buildList { while(c.moveToNext()) add(c.getString(0)) } }
    fun replaceNotes(notes:List<Pair<Long,String>>){
        db.beginTransaction()
        try {
            db.delete("question_note", null, null)
            db.delete("question_note_image", null, null)
            val st=db.compileStatement("INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)")
            notes.forEach { (id,note) -> if(note.isNotBlank()){ st.bindLong(1,id); st.bindString(2,note); st.bindLong(3,System.currentTimeMillis()); st.executeInsert(); st.clearBindings() } }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        AppState.changed()
    }
    fun questionRefsByKeyword(keyword:String):List<QuestionRef>{
        val k=keyword.trim(); if(k.isBlank()) return emptyList()
        return allQuestionRefs().filter{it.testTitle.contains(k,true)||it.category.contains(k,true)||it.sourceName.contains(k,true)}
    }
    fun sourceQuestionCount(sourceId:Long):Int=db.rawQuery("SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.source_id=?",arrayOf(sourceId.toString())).use{c->c.moveToFirst();c.getInt(0)}
    fun testQuestionRefs(testId:String):List<QuestionRef> = allQuestionRefs().filter { it.testId == testId }
    fun progressSummaryForTest(testId:String, store:ProgressStore):ProgressSummary {
        var total=0; var solved=0; var correct=0; var resume=0; var foundResume=false
        db.rawQuery("SELECT q.position,q.source_question_id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.test_id=? ORDER BY q.position",arrayOf(testId)).use { c ->
            while(c.moveToNext()) {
                total++
                val key="$testId:${c.getInt(0)}:${c.getString(1)}"
                val st=store.status(key)
                if(st!=null){ solved++; if(st=="correct") correct++ } else if(!foundResume){ resume=c.getInt(0); foundResume=true }
            }
        }
        return ProgressSummary(total,solved,correct,resume)
    }
    fun progressSummaryForSource(sourceId:Long, store:ProgressStore):ProgressSummary {
        var total=0; var solved=0; var correct=0
        db.rawQuery("SELECT q.test_id,q.position,q.source_question_id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.source_id=? ORDER BY t.rowid,q.position",arrayOf(sourceId.toString())).use { c ->
            while(c.moveToNext()){ total++; val key="${c.getString(0)}:${c.getInt(1)}:${c.getString(2)}"; val st=store.status(key); if(st!=null){solved++;if(st=="correct")correct++} }
        }
        return ProgressSummary(total,solved,correct,0)
    }
    fun testProgressSummaries(sourceId:Long):Map<String,ProgressSummary> {
        // Opening a sub-QBank is a navigation operation, not a request to walk every question.
        // The old implementation materialized one Kotlin stable-key lookup per question, so a
        // 50k-question source could consume the shared qbank worker immediately after navigation.
        // Aggregate the same information in SQLite using the indexed progress_v2.test_id field
        // and the authoritative test.num_questions value.
        val sql = """
            SELECT t.id,
                   COALESCE(t.num_questions,0),
                   COALESCE(p.solved,0),
                   COALESCE(p.correct,0),
                   COALESCE(CAST(m.meta_value AS INTEGER),0)
            FROM test t
            JOIN source s ON s.id=t.source_id AND s.deleting=0
            LEFT JOIN (
                SELECT test_id,
                       SUM(CASE WHEN status IS NOT NULL AND status <> '' THEN 1 ELSE 0 END) AS solved,
                       SUM(CASE WHEN status = 'correct' THEN 1 ELSE 0 END) AS correct
                FROM progress_v2
                WHERE test_id IN (SELECT id FROM test WHERE source_id=?)
                GROUP BY test_id
            ) p ON p.test_id=t.id
            LEFT JOIN progress_meta m ON m.meta_key=(t.id || ':position')
            WHERE t.source_id=?
            ORDER BY t.rowid
        """.trimIndent()
        return db.rawQuery(sql, arrayOf(sourceId.toString(), sourceId.toString())).use { c ->
            buildMap {
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val total = c.getInt(1).coerceAtLeast(0)
                    val solved = c.getInt(2).coerceAtLeast(0).coerceAtMost(total)
                    val correct = c.getInt(3).coerceAtLeast(0).coerceAtMost(solved)
                    val resume = c.getInt(4).coerceIn(0, (total - 1).coerceAtLeast(0))
                    put(id, ProgressSummary(total, solved, correct, resume))
                }
            }
        }
    }

    fun search(query:String, resultLimit:Int = 400):List<SearchHit>{
        val rawTokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
        if(rawTokens.isEmpty()) return emptyList()
        // Natural-language questions contain grammatical stop words. Requiring every surface
        // token in FTS made normal questions such as "What is the mechanism of action of
        // atropine?" fail even when the clinical terms were present. Keep strict recall first,
        // then broaden to meaningful-token recall; Ben/Ren performs the semantic ranking later.
        val stopWords=setOf("a","an","the","is","are","was","were","be","been","being",
            "what","which","who","whom","whose","where","when","why","how","does","do","did",
            "can","could","will","would","should","may","might","of","to","in","on","at","for",
            "from","with","by","and","or","but","as","than","then","this","that","these","those",
            "please","tell","me","give","show","find","search","about","question","questions")
        val meaningful=rawTokens.flatMap{it.replace(Regex("[^\\p{L}\\p{N}_%\\\\]+")," ").split(Regex("\\s+"))}
            .filter{it.length>=2 && it.lowercase() !in stopWords}.distinct().take(8)
        val ftsTokens=if(meaningful.isNotEmpty()) meaningful else rawTokens
        val tokens=ftsTokens
        // Literal punctuation must bypass FTS tokenization. This preserves exact search semantics
        // for %, _, backslash, and hyphen-bearing question/import identities.
        val hasLikeLiteralSyntax=rawTokens.any { raw -> raw.any { it == '%' || it == '_' || it == '\\' } }
        val hasHyphenSyntax=rawTokens.any { raw -> raw.contains('-') }
        val likeTokens=rawTokens.mapNotNull { raw ->
            if (raw.any { it == '%' || it == '_' || it == '\\' }) raw
            else raw.takeIf { it.length >= 2 && it.lowercase() !in stopWords }
        }.distinct().take(8).ifEmpty { rawTokens }
        val limit=resultLimit.coerceIn(1,1200)
        val fullQuery=query.trim().lowercase()
        fun read(match:String):List<SearchHit> =db.rawQuery(
            "SELECT q.id,q.test_id,t.title,q.position,q.source_question_id,q.text,t.path,COALESCE(s.display_name,s.file_name) FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE question_fts MATCH ? ORDER BY CASE WHEN lower(q.text) LIKE ? ESCAPE CHAR(92) THEN 0 WHEN lower(t.title) LIKE ? ESCAPE CHAR(92) OR lower(COALESCE(t.path,'')) LIKE ? ESCAPE CHAR(92) OR lower(COALESCE(s.display_name,s.file_name)) LIKE ? ESCAPE CHAR(92) THEN 1 ELSE 2 END, s.imported_at DESC,t.rowid,q.position LIMIT $limit",
            arrayOf(match,QBankSearchSql.likePattern(fullQuery),QBankSearchSql.likePattern(fullQuery),QBankSearchSql.likePattern(fullQuery),QBankSearchSql.likePattern(fullQuery))
        ).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
        try {
            if (hasHyphenSyntax) {
                // FTS treats '-' as an operator unless the surface form is quoted.
                // Quoted FTS preserves token boundaries: "question-A" matches that
                // identity without broad substring matching such as question-A2.
                val hyphenQuery=rawTokens.filter { it.contains('-') }
                    .joinToString(" ") { "\"${it.replace("\"", "\"\"")}\"" }
                val exact=read(hyphenQuery)
                if (exact.isNotEmpty()) return exact
            } else if (!hasLikeLiteralSyntax) {
                val strict=read(ftsTokens.joinToString(" AND "){"$it*"})
                if(strict.isNotEmpty()) return strict
                val broad=read(ftsTokens.joinToString(" OR "){"$it*"})
                if(broad.isNotEmpty()) return broad
            }
        } catch (e:Exception) {
            Log.w("QBankDb", "FTS search fallback: ${e.message}")
            ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.fts_search_failed:${e.javaClass.simpleName}")
        }
        fun likeRows(all:Boolean):List<SearchHit>{
            val plan = QBankSearchQueryBuilder.textLikePlan(likeTokens, limit, all)
            return db.rawQuery(plan.sql, plan.args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
        }
        if (hasLikeLiteralSyntax) return likeRows(true)
        // A hyphen query that reached this point did not produce an exact FTS hit.
        // Never broaden it to substring LIKE, which can conflate distinct identities.
        if (hasHyphenSyntax) return emptyList()
        val strictFallback=likeRows(true)
        return if(strictFallback.isNotEmpty() || likeTokens.size<=1) strictFallback else likeRows(false)
    }

    /**
     * Hard-filtered visual retrieval. A question must own at least one imported
     * question/explanation image; textual mentions of "image" are never sufficient.
     * This is intentionally separate from generic FTS search so a request such as
     * "pathology slides" can return image-bearing pathology questions whose stems
     * never contain the words slide/image.
     */
    fun searchImageQuestions(query:String, resultLimit:Int = 400):List<SearchHit>{
        val rawTokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
        if(rawTokens.isEmpty()) return emptyList()
        val stopWords=setOf("a","an","the","is","are","was","were","be","been","being","what","which","who","whom","whose","where","when","why","how","does","do","did","can","could","will","would","should","may","might","of","to","in","on","at","for","from","with","by","and","or","but","as","than","then","this","that","these","those","please","tell","me","give","show","find","search","about","question","questions","image","images","visual","related")
        val meaningful=rawTokens.flatMap{it.replace(Regex("[^\\p{L}\\p{N}_%\\\\]+")," ").split(Regex("\\s+"))}
            .filter{it.length>=2 && it.lowercase() !in stopWords}.distinct().take(8)
        val ftsTokens=if(meaningful.isNotEmpty()) meaningful else rawTokens
        val tokens=ftsTokens
        val hasLikeLiteralSyntax=rawTokens.any { raw -> raw.any { it == '%' || it == '_' || it == '\\' } }
        val hasHyphenSyntax=rawTokens.any { raw -> raw.contains('-') }
        val likeTokens=rawTokens.mapNotNull { raw ->
            if (raw.any { it == '%' || it == '_' || it == '\\' }) raw
            else raw.takeIf { it.length >= 2 && it.lowercase() !in stopWords }
        }.distinct().take(8).ifEmpty { rawTokens }
        val safeLimit=resultLimit.coerceIn(1,1200)
        fun fts(match:String):List<SearchHit>{
            val sql="SELECT q.id,q.test_id,t.title,q.position,q.source_question_id,q.text,t.path,COALESCE(s.display_name,s.file_name) " +
                "FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 " +
                "WHERE question_fts MATCH ? AND EXISTS(SELECT 1 FROM question_image qi WHERE qi.question_id=q.id) " +
                "ORDER BY s.imported_at DESC,t.rowid,q.position LIMIT $safeLimit"
            return db.rawQuery(sql,arrayOf(match)).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
        }
        try {
            if (hasHyphenSyntax) {
                val hyphenQuery=rawTokens.filter { it.contains('-') }
                    .joinToString(" ") { "\"${it.replace("\"", "\"\"")}\"" }
                val exact=fts(hyphenQuery)
                if (exact.isNotEmpty()) return exact
            } else if (!hasLikeLiteralSyntax) {
                val strict=fts(ftsTokens.joinToString(" AND "){"$it*"})
                if(strict.isNotEmpty()) return strict
                val broad=fts(ftsTokens.joinToString(" OR "){"$it*"})
                if(broad.isNotEmpty()) return broad
            }
        } catch (e:Exception) {
            Log.w("QBankDb", "FTS search fallback: ${e.message}")
            ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.fts_search_failed:${e.javaClass.simpleName}")
        }
        fun likeRows(all:Boolean):List<SearchHit>{
            val plan = QBankSearchQueryBuilder.textLikePlan(likeTokens, safeLimit, all)
            return db.rawQuery(plan.sql,plan.args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
        }
        if (hasLikeLiteralSyntax) return likeRows(true)
        if (hasHyphenSyntax) return emptyList()
        val strictFallback=likeRows(true)
        return if(strictFallback.isNotEmpty() || likeTokens.size<=1) strictFallback else likeRows(false)
    }

    fun searchSections(query:String):List<SectionHit>{
        val tokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
        if(tokens.isEmpty()) return emptyList()
        // Hierarchy search is a recall problem, not an AND-filter problem. A subsection can
        // legitimately contain only one clinically meaningful token (e.g. "Cervix") while the
        // question corpus contains the full phrase. Use OR recall and rank rows by the number of
        // matched title/path/source tokens so QBank/sub-QBank discovery never collapses to empty.
        val clauses=tokens.map{ "(t.title LIKE ? ESCAPE CHAR(92) OR COALESCE(t.path,'') LIKE ? ESCAPE CHAR(92) OR COALESCE(s.display_name,s.file_name) LIKE ? ESCAPE CHAR(92))" }
        val whereArgs=tokens.flatMap{ val like=QBankSearchSql.likePattern(it); listOf(like,like,like) }
        val scoreParts=tokens.map{
            "CASE WHEN t.title LIKE ? ESCAPE CHAR(92) THEN 3 ELSE 0 END + " +
                "CASE WHEN COALESCE(t.path,'') LIKE ? ESCAPE CHAR(92) THEN 2 ELSE 0 END + " +
                "CASE WHEN COALESCE(s.display_name,s.file_name) LIKE ? ESCAPE CHAR(92) THEN 1 ELSE 0 END"
        }
        val scoreArgs=whereArgs
        val sql="SELECT t.id,t.title,COALESCE(t.path,''),COALESCE(s.display_name,s.file_name),t.num_questions FROM test t JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE ${clauses.joinToString(" OR ")} ORDER BY (${scoreParts.joinToString(" + ")}) DESC,s.imported_at DESC,t.rowid LIMIT 200"
        val args=whereArgs + scoreArgs
        return db.rawQuery(sql,args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SectionHit(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4)))}}
    }

    private fun safeImportKey(importKey: String): String {
        val key = importKey.trim()
        if (key.startsWith("rvx-uri-") && key.length >= 20) return key
        val digest = MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return "rvx-legacy-$digest"
    }

    fun beginStreamingImport(importKey:String, displayName:String, provider:String): StreamingImportSession {
        val stableImportKey = safeImportKey(importKey)
        val existingSourceId = db.rawQuery("SELECT id FROM source WHERE file_name=? LIMIT 1", arrayOf(stableImportKey)).use { c ->
            if (c.moveToFirst()) c.getLong(0) else 0L
        }
        if (existingSourceId > 0L) {
            val deleted = deleteSource(existingSourceId, repairSearchIndex = false)
            check(deleted) { "Previous import is still being removed; retry import after recovery completes" }
        }
        markSearchIndexDirty()
        var sourceId = 0L
        db.beginTransaction()
        try {
            val st=db.compileStatement("INSERT INTO source(file_name,display_name,series_number,provider,imported_at) VALUES(?,?,?,?,?)")
            st.bindString(1,stableImportKey); st.bindString(2,displayName); st.bindString(3,""); st.bindString(4,provider); st.bindLong(5,System.currentTimeMillis())
            sourceId=st.executeInsert()
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return StreamingImportSession(sourceId, stableImportKey)
    }

    inner class StreamingImportSession(private val sourceId:Long, private val fileName:String) {
        private val tests=LinkedHashMap<String,Pair<String,Int>>()
        private var total=0
        private var closed=false
        private var inTransaction=false
        // Reuse compiled statements across the streaming session. This avoids reparsing SQL
        // for every question/option/image and materially reduces large-import CPU overhead.
        private val questionStatement = db.compileStatement("INSERT INTO question(test_id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio) VALUES(?,?,?,?,?,?,?,?,?,?)")
        private val optionStatement = db.compileStatement("INSERT INTO option_item(question_id,position,label,text,is_correct) VALUES(?,?,?,?,?)")
        private val imageStatement = db.compileStatement("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)")
        private val ftsStatement: android.database.sqlite.SQLiteStatement? = try {
            db.compileStatement("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)")
        } catch (_: Exception) { null }

        init { beginTransaction() }

        private fun beginTransaction() {
            if (!inTransaction && !closed) {
                db.beginTransaction()
                inTransaction=true
            }
        }

        /** Commit the questions accumulated for the current HTML section, then start a fresh transaction. */
        fun commitSection() {
            if (closed || !inTransaction) return
            try {
                for ((_,pair) in tests) db.execSQL("UPDATE test SET num_questions=? WHERE id=?", arrayOf<Any?>(pair.second,pair.first))
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
                inTransaction=false
            }
            beginTransaction()
        }

        fun addQuestion(section:String, q:ImportedQuestion) {
            check(!closed) { "Import session is closed" }
            beginTransaction()
            val title=section.trim().ifBlank { "Imported Section" }.take(120)
            val test=tests.getOrPut(title) {
                val original=title
                val id=makeId(fileName, original, tests.size)
                db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions,total_marks,duration_seconds,time_per_question,original_id,series_number) VALUES(?,?,?,?,?,?,?,?,?,?)", arrayOf<Any?>(id,sourceId,title,null,0,0.0,0,0.0,original,""))
                id to 0
            }
            val testId=test.first
            val pos=test.second
            questionStatement.bindString(1,testId); questionStatement.bindLong(2,pos.toLong()); bindNullable(questionStatement,3,q.sourceId); bindNullable(questionStatement,4,q.text); bindNullable(questionStatement,5,q.rawText); bindNullable(questionStatement,6,q.correctAnswer); bindNullable(questionStatement,7,q.explanation); bindNullable(questionStatement,8,q.bot); bindNullable(questionStatement,9,q.video); bindNullable(questionStatement,10,q.audio)
            val qid=questionStatement.executeInsert(); questionStatement.clearBindings()
            q.options.forEachIndexed { i,o -> optionStatement.bindLong(1,qid); optionStatement.bindLong(2,i.toLong()); bindNullable(optionStatement,3,o.label); bindNullable(optionStatement,4,o.text); optionStatement.bindLong(5,if(o.correct)1L else 0L); optionStatement.executeInsert(); optionStatement.clearBindings() }
            q.questionImages.forEachIndexed { i,u -> imageStatement.bindLong(1,qid); imageStatement.bindString(2,"question"); imageStatement.bindLong(3,i.toLong()); imageStatement.bindString(4,u); imageStatement.executeInsert(); imageStatement.clearBindings() }
            q.explanationImages.forEachIndexed { i,u -> imageStatement.bindLong(1,qid); imageStatement.bindString(2,"explanation"); imageStatement.bindLong(3,i.toLong()); imageStatement.bindString(4,u); imageStatement.executeInsert(); imageStatement.clearBindings() }
            ftsStatement?.let { st ->
                try { st.bindLong(1,qid); st.bindString(2,testId); st.bindLong(3,sourceId); st.bindString(4,q.text+" "+(q.rawText ?: "")+" "+(q.correctAnswer ?: "")+" "+(q.explanation ?: "")+" "+(q.bot ?: "")+" "+(q.video ?: "")+" "+(q.audio ?: "")+" "+title+" "+q.options.joinToString(" "){it.label+" "+it.text}+" "+fileName); st.executeInsert() } catch (e: Exception) {
                    Log.w("QBankDb", "FTS row skipped: ${e.message}")
                    ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.fts_row_skipped")
                } finally { st.clearBindings() }
            }
            tests[title]=testId to (pos+1)
            total++
            // Keep very large single-section QBanks from holding one SQLite transaction for hours.
            if(total % 250 == 0) commitSection()
        }

        /** Roll back only the active transaction and remove any already-committed partial import. */
        fun abort() {
            if (closed) return
            try {
                if (inTransaction) {
                    db.endTransaction()
                    inTransaction=false
                }
                db.beginTransaction()
                db.delete("source", "id=?", arrayOf(sourceId.toString()))
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
                questionStatement.close(); optionStatement.close(); imageStatement.close(); ftsStatement?.close()
                closed=true
            }
        }

        fun finish(success:Boolean) {
            if(closed) return
            if (!success) { abort(); return }
            var committed = false
            try {
                for ((_,pair) in tests) db.execSQL("UPDATE test SET num_questions=? WHERE id=?", arrayOf<Any?>(pair.second,pair.first))
                if(inTransaction) db.setTransactionSuccessful()
                if(inTransaction) db.endTransaction()
                inTransaction=false
                committed = true
            } finally {
                if(inTransaction) runCatching { db.endTransaction() }
                inTransaction=false
                questionStatement.close(); optionStatement.close(); imageStatement.close(); ftsStatement?.close()
                closed=true
            }
            if (committed) {
                finalizeIncrementalSearchIndex()
                // Streaming HTML imports do not pass through importBundle(), so they must
                // publish the same committed-state invalidation explicitly. Without this,
                // QBankLoadingEngine can legitimately serve its cached non-empty source list
                // after the import Activity finishes, making a newly imported QBank appear to
                // have vanished until a process/cache reset.
                AppState.changed("import_completed")
            }
        }
    }

    /**
     * Imports a parsed HTML QBank without holding the entire corpus in one SQLite transaction.
     *
     * A single giant transaction is attractive for atomicity, but on large QBanks it can hold the
     * WAL/write lock for a very long time and defer the expensive commit/fsync until the very end.
     * That made imports appear frozen at the database-writing stage even though parsing had already
     * completed. We therefore commit bounded batches while keeping the source itself recoverable:
     * a failure cleans the partially-created source so callers never observe a half-imported QBank.
     *
     * FTS rows are still written transactionally with their normalized question rows. The index is
     * marked dirty until the complete source import finishes, so interactive search can safely fall
     * back to normalized-table retrieval during the import.
     */
    /** Compatibility overload for internal tests/legacy callers. */
    fun importBundle(fileName:String, provider:String, tests:List<ImportedTest>, onProgress:(done:Int,total:Int)->Unit = {_,_->}):Int =
        importBundle(fileName, fileName, provider, tests, onProgress)

    fun importBundle(importKey:String, displayName:String, provider:String, tests:List<ImportedTest>, onProgress:(done:Int,total:Int)->Unit = {_,_->}):Int {
        val stableImportKey = safeImportKey(importKey)
        val existingSourceId = db.rawQuery("SELECT id FROM source WHERE file_name=? LIMIT 1", arrayOf(stableImportKey)).use { c ->
            if (c.moveToFirst()) c.getLong(0) else 0L
        }
        if (existingSourceId > 0L) {
            val deleted = deleteSource(existingSourceId, repairSearchIndex = false)
            check(deleted) { "Previous import is still being removed; retry import after recovery completes" }
        }
        markSearchIndexDirty()
        return QBankImportWriter(db,
            deleteSource = { sourceId -> deleteSource(sourceId, repairSearchIndex = false) },
            markSearchIndexDirty = { markSearchIndexDirty() },
            finalizeSearchIndex = { finalizeIncrementalSearchIndex() }
        ).import(stableImportKey, displayName, provider, tests, onProgress)
            .also { AppState.changed("import_completed") }
    }

    private fun bindNullable(st:android.database.sqlite.SQLiteStatement,i:Int,v:String?){if(v==null)st.bindNull(i) else st.bindString(i,v)}
    private fun makeId(file:String,original:String,index:Int):String{val raw="$file|$original|$index";return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).joinToString(""){String.format("%02x",it)}.take(24)}

    companion object {
        /** Test-only reset of the authoritative shared database provider. */
        internal fun resetDatabaseForTest(context: Context) =
            qBankDatabaseProvider.resetForTest(context)

        private const val SEARCH_INDEX_HEALTH_TTL_MS = 1_000L
        private val searchIndexHealthLock = Any()
        @Volatile private var searchIndexHealthy = false
        @Volatile private var searchIndexHealthCheckedAt = 0L
        private val searchIndexMutationGeneration = java.util.concurrent.atomic.AtomicLong(0L)
    }
}


data class Source(val id:Long,val fileName:String,val provider:String,val seriesNumber:String="")
data class Test(val id:String,val title:String,val path:String?,val count:Int,val marks:Double,val duration:Int,val timePerQuestion:Double,val seriesNumber:String="")
data class Option(val label:String,val text:String,val correct:Boolean)
data class Question(val id:Long,val stableKey:String,val position:Int,val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<Option>,val questionImages:List<String>,val explanationImages:List<String>)

data class AiIndexRow(val id:Long,val text:String,val explanation:String,val testTitle:String,val path:String,val sourceName:String)
data class DashboardTestRow(
    val testId:String, val name:String, val path:String, val source:String,
    val total:Int, val sourceTotal:Int=total, val solved:Int, val correct:Int, val position:Int
)

data class QuestionRef(val id:Long,val stableKey:String,val testId:String,val position:Int,val text:String,val testTitle:String,val sourceId:Long,val sourceName:String,val category:String)
data class SearchHit(val id:Long,val testId:String,val testTitle:String,val position:Int,val text:String,val path:String?,val sourceName:String,val stableKey:String)
data class SectionHit(val testId:String,val title:String,val path:String,val sourceName:String,val count:Int)
data class ProgressSummary(val total:Int,val solved:Int,val correct:Int,val resumePosition:Int)
data class ImportedTest(val originalId:String?,val title:String,val path:String?,val totalMarks:Double,val duration:Int,val timePerQuestion:Double,val questions:List<ImportedQuestion>,val seriesNumber:String?=null)
data class ImportedQuestion(val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<ImportedOption>,val questionImages:List<String>,val explanationImages:List<String>)
data class ImportedOption(val label:String,val text:String,val correct:Boolean)

private object ProgressDbRegistry {
    @Volatile private var instance: QBankDb? = null
    fun get(context: Context): QBankDb {
        instance?.let { return it }
        return synchronized(this) {
            instance ?: QBankDb(context.applicationContext).also { instance = it }
        }
    }
}

class ProgressStore(context: Context) : ProgressRepository, AutoCloseable {
    private val appContext = context.applicationContext
    private val db = ProgressDbRegistry.get(appContext)
    private val legacyPrefs = appContext.getSharedPreferences("progress", Context.MODE_PRIVATE)
    private val migrationKey = "__sqlite_progress_v2_migrated"
    private val fields = setOf("answer", "status", "bookmark", "review", "attempts", "lastAttempted", "timeMs", "mistake", "ef", "reps", "intervalDays", "nextDue")

    init { synchronized(db) { migrateLegacyIfNeeded() } }

    private fun key(id:String,s:String)=id+":"+s
    private fun changed(cloud:Boolean=true){
        PerformanceManager.invalidateProgress()
        AppState.changed()
        BackupManager(appContext).onProgressChanged(cloud)
    }

    private fun stored(id: String): QBankDb.StoredProgress = db.readStoredProgress(id)
        ?: QBankDb.StoredProgress(null,null,null,false,0,0L,0L,null,2.5f,0,0f,0L)

    override fun selected(id:String)=stored(id).selected
    override fun status(id:String)=stored(id).status
    override fun bookmark(id:String)=stored(id).bookmark
    override fun review(id:String)=stored(id).review
    override fun position(testId:String):Int=db.getProgressMeta(key(testId,"position"))?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    override fun sourceResume(sourceId:Long):String?=db.getProgressMeta("source:$sourceId:resume")
    override fun sourceResumeByName(sourceName:String):String?=db.getProgressMeta("sourceName:${sourceName}:resume")

    override fun setPosition(testId:String,position:Int,sourceId:Long,sourceName:String?){
        val value=position.coerceAtLeast(0)
        db.beginProgressMetaTransaction(testId, value, sourceId, sourceName)
        changed(false)
    }

    override fun clearCompletion(testId:String){
        if(testId.isBlank()) return
        synchronized(db) { db.putProgressMeta("${testId}:completed", "0") }
    }

    override fun easeFactor(id:String)=stored(id).easeFactor
    override fun repetitions(id:String)=stored(id).repetitions
    override fun intervalDays(id:String)=stored(id).intervalDays
    override fun nextDue(id:String)=stored(id).nextDue
    override fun allProgressKeys():Set<String> = synchronized(db) { db.allStoredProgress().keys }

    override fun setAnswer(id:String,a:String,status:String){
        synchronized(db) {
        val previous=stored(id)
        val result=SpacedRepetitionScheduler.schedule(
            SpacedRepetitionScheduler.ScheduleInput(
                correct=status=="correct", easeFactor=previous.easeFactor,
                repetitions=previous.repetitions, previousIntervalDays=previous.intervalDays
            ), now=System.currentTimeMillis()
        )
        val answeredAt = System.currentTimeMillis()
        db.writeStoredProgress(id, previous.copy(
            selected=a, status=status, attempts=previous.attempts+1,
            lastAttempted=answeredAt, easeFactor=result.easeFactor,
            repetitions=result.repetitions, intervalDays=result.intervalDays, nextDue=result.nextDueAt
        ))
        val answerTestId = id.substringBefore(':').takeIf { it.isNotBlank() }.orEmpty()
        db.recordStudyAttempt(id, answerTestId, db.sourceIdForTest(answerTestId), answeredAt, status == "correct")
        // Every accepted answer is also a durable resume checkpoint. The resume cursor is the
        // NEXT question, not the question just answered. This closes the old half-solved-QBank
        // bug when the user answers Q42 and leaves before pressing Next.
        val first = id.indexOf(':')
        val second = id.indexOf(':', first + 1)
        if (first > 0 && second > first) {
            val resumeTestId = id.substring(0, first)
            val answeredPosition = id.substring(first + 1, second).toIntOrNull()
            if (!resumeTestId.isNullOrBlank() && answeredPosition != null) {
                val test = db.testById(resumeTestId)
                val nextPosition = if (test != null && test.count > 0) (answeredPosition + 1).coerceAtMost(test.count - 1) else answeredPosition
                val sourceId = db.sourceIdForTest(resumeTestId)
                val sourceName = db.sourceNameForTest(resumeTestId)
                val solvedAt = System.currentTimeMillis()
                db.beginProgressMetaTransaction(resumeTestId, nextPosition, sourceId, sourceName, resumeSavedAt = solvedAt)
                db.putProgressMeta("last_solved_global", "$resumeTestId|$answeredPosition|$sourceId|$solvedAt")
                if (test != null && answeredPosition >= test.count - 1) {
                    db.putProgressMeta("${resumeTestId}:completed", "1")
                } else {
                    db.putProgressMeta("${resumeTestId}:completed", "0")
                }
            }
        }
        changed()
        }
    }

    override fun isDue(id:String):Boolean{
        val x=stored(id); if(x.status==null)return true
        if(x.lastAttempted==0L)return true
        if(x.nextDue>0L)return System.currentTimeMillis()>=x.nextDue
        val day=86_400_000L
        return System.currentTimeMillis()-x.lastAttempted>=when(x.attempts){1->day;2->3*day;3->7*day;4->14*day;else->30*day}
    }
    override fun isScheduledDue(id:String):Boolean{
        val x=stored(id); if(x.status.isNullOrBlank())return false
        if(x.nextDue>0L)return System.currentTimeMillis()>=x.nextDue
        if(x.lastAttempted<=0L)return false
        val day=86_400_000L
        return System.currentTimeMillis()-x.lastAttempted>=when(x.attempts){1->day;2->3*day;3->7*day;4->14*day;else->30*day}
    }
    override fun attempts(id:String)=stored(id).attempts
    override fun lastAttempted(id:String)=stored(id).lastAttempted
    override fun timeMs(id:String)=stored(id).timeMs
    override fun mistakeType(id:String)=stored(id).mistake
    override fun setMistakeType(id:String,value:String?){ synchronized(db) { db.writeStoredProgress(id,stored(id).copy(mistake=value?.takeIf{it.isNotBlank()})) }; changed() }
    override fun addTime(id:String,elapsedMs:Long){
        if(elapsedMs<=0L)return
        synchronized(db) {
            val x=stored(id)
            db.writeStoredProgress(id,x.copy(timeMs=x.timeMs+elapsedMs))
            db.updateLatestStudyAttemptTime(id, elapsedMs)
        }
        changed(false)
    }
    override fun setBookmark(id:String,value:String?){
        synchronized(db) { db.writeStoredProgress(id,stored(id).copy(bookmark=value?.takeIf{it.isNotBlank()})) }
        changed()
    }
    override fun setReview(id:String,value:Boolean){
        synchronized(db) { db.writeStoredProgress(id,stored(id).copy(review=value)) }
        changed()
    }
    override fun clear(id:String){ synchronized(db) { db.deleteStoredProgress(id) }; changed() }

    /** Export-compatible view. Values retain the old key names so existing backup format stays stable. */
    override fun allEntries():Map<String,*> = synchronized(db) { buildMap {
        db.allStoredProgress().forEach { (id,x) ->
            x.selected?.let { put(key(id,"answer"),it) }; x.status?.let { put(key(id,"status"),it) }
            x.bookmark?.let { put(key(id,"bookmark"),it) }; if(x.review) put(key(id,"review"),true)
            if(x.attempts>0) put(key(id,"attempts"),x.attempts); if(x.lastAttempted>0) put(key(id,"lastAttempted"),x.lastAttempted)
            if(x.timeMs>0) put(key(id,"timeMs"),x.timeMs); x.mistake?.let { put(key(id,"mistake"),it) }
            put(key(id,"ef"),x.easeFactor); put(key(id,"reps"),x.repetitions); put(key(id,"intervalDays"),x.intervalDays); put(key(id,"nextDue"),x.nextDue)
        }
        putAll(db.allProgressMeta())
    } }

    override fun restore(entries:Map<String,*>){
        restoreInternal(entries, notify=true)
    }

    /** Backup restore uses this to avoid publishing an intermediate state before notes/UI/flashcards commit. */
    internal fun restoreSilently(entries:Map<String,*>) { restoreInternal(entries, notify=false) }

    private fun restoreInternal(entries:Map<String,*>, notify:Boolean){
        synchronized(db) {
            val grouped=HashMap<String,MutableMap<String,Any?>>()
            val meta=HashMap<String,String>()
            entries.forEach { (full,value) ->
                val suffix=full.substringAfterLast(":","")
                if(suffix in fields){ val id=full.substringBeforeLast(":"); grouped.getOrPut(id){HashMap()}[suffix]=value }
                else if(suffix=="position" || full.startsWith("source:") || full.startsWith("sourceName:") || full==migrationKey) meta[full]=value?.toString().orEmpty()
            }
            val out=grouped.mapValues { (_,m) ->
                fun str(k:String)=m[k] as? String
                fun long(k:String)=when(val v=m[k]){is Long->v;is Int->v.toLong();is Float->v.toLong();is Double->v.toLong();is Number->v.toLong();else->0L}
                fun int(k:String)=long(k).toInt()
                fun float(k:String,default:Float)=when(val v=m[k]){is Number->v.toFloat();else->default}
                QBankDb.StoredProgress(str("answer"),str("status"),str("bookmark"),m["review"]==true,int("attempts"),long("lastAttempted"),long("timeMs"),str("mistake"),float("ef",2.5f),int("reps"),float("intervalDays",0f),long("nextDue"))
            }
            db.replaceStoredProgress(out,meta)
        }
        if(notify) changed()
    }

    private fun migrateLegacyIfNeeded(){
        if(db.getProgressMeta(migrationKey)=="1") return
        val entries=legacyPrefs.all
        if(entries.isNotEmpty()) restoreInternal(entries, notify=false)
        db.putProgressMeta(migrationKey,"1")
        // Keep the legacy preferences intact for one release as a rollback/source-of-truth snapshot.
        // New writes never touch them. They can be removed in a later cleanup release after backup validation.
    }

    // The SQLite handle is process-scoped because ProgressStore is used by multiple authoritative
    // managers and Activities. Closing one repository instance must never invalidate another.
    override fun close() = Unit
}


