package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/** Permanent, exportable diagnostics surface for Ben and future Rovex performance tests. */
class RovexDiagnosticsDataCenter : AppCompatActivity() {
    private lateinit var reportView: TextView
    private lateinit var summaryView: TextView
    private lateinit var statusView: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var runButton: TextView
    private var diagnosticJob: Job? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        setContentView(build())
    }

    override fun onResume() {
        super.onResume()
        if (::reportView.isInitialized) {
            reportView.text = RovexDiagnosticsStore.latest(this) ?: "No completed EmbeddingGemma diagnostic is stored yet."
            refreshSnapshot()
        }
    }

    private fun build(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(28))
            setBackgroundColor(ThemeManager.bg(this@RovexDiagnosticsDataCenter))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter))
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(42), dp(48)))
        header.addView(TextView(this).apply {
            text = "Rovex Test & Diagnostics Center"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter)); setPadding(dp(6), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(header)
        root.addView(label("The single test window for EmbeddingGemma, Ben IPC, resources and future runtime measurements."), lpWrap(0, 10))

        val summary = card(); summary.addView(title("CURRENT SNAPSHOT")); summaryView = label(""); summary.addView(summaryView); root.addView(summary, cardLp(0, 10))

        val actions = card(); actions.addView(title("EMBEDDINGGEMMA FULL TEST"))
        actions.addView(label("Contract → tokenizer → backend/NPU → inference → semantic smoke test → RAM/thermal report. First runtime initialization can take around 20 seconds."), lpWrap(0, 6))
        statusView = label("Ready • no test running"); statusView.textSize = 13f; statusView.setTextColor(ThemeManager.text(this)); actions.addView(statusView, lpWrap(0, 4))
        progressBar = ProgressBar(this).apply { isIndeterminate = true; visibility = ProgressBar.GONE }
        actions.addView(progressBar, LinearLayout.LayoutParams(-1, dp(4)).apply { setMargins(0, dp(2), 0, dp(6)) })
        runButton = button("RUN FULL EMBEDDINGGEMMA TEST") { runEmbeddingDiagnostic() }
        actions.addView(runButton, lp(0, 8))
        actions.addView(button("RUN ISOLATED BEN IPC TEST") { runIsolatedIpcDiagnostic() }, lp(0, 4))
        actions.addView(label("The full EmbeddingGemma test is a direct main-process control test based on the previously working v8.3.140 diagnostic path. The IPC test is separate so a Binder/process failure cannot hide a model-runtime result."), lpWrap(0, 4))
        actions.addView(button("OPEN BEN MODEL LAB") { startActivity(Intent(this, BenModelLabActivity::class.java)) }, lp(0, 4))
        actions.addView(button("REFRESH SNAPSHOT") { refreshSnapshot() }, lp(0, 4))
        actions.addView(button("SHARE COMPLETE DIAGNOSTICS") { shareDiagnostics() }, lp(0, 4))
        root.addView(actions, cardLp(0, 10))

        val report = card(); report.addView(title("LATEST TEST REPORT"))
        val stored = RovexDiagnosticsStore.latest(this)
        val storedStatus = RovexDiagnosticsStore.latestStatus(this)
        reportView = label(when {
            !stored.isNullOrBlank() -> stored
            !storedStatus.isNullOrBlank() -> "Latest diagnostic status: $storedStatus"
            else -> "No completed EmbeddingGemma diagnostic is stored yet."
        })
        reportView.textSize = 12f; reportView.setTextIsSelectable(true)
        report.addView(reportView, lpWrap(0, 6)); root.addView(report, cardLp(0, 10))

        val telemetry = card(); telemetry.addView(title("LIVE TELEMETRY")); telemetry.addView(label(telemetryText())); root.addView(telemetry, cardLp(0, 10))
        refreshSnapshot()
        return ScrollView(this).apply { addView(root); isFillViewport = true }
    }

    private fun runEmbeddingDiagnostic() {
        if (diagnosticJob?.isActive == true) return
        runButton.text = "STOP TEST"
        runButton.setOnClickListener { diagnosticJob?.cancel() }
        progressBar.visibility = ProgressBar.VISIBLE
        reportView.text = "Direct control test started. The proven v8.3.140-style EmbeddingGemma diagnostic is running in the main process.\n\nNo study data will be changed."
        statusView.text = "STARTING • direct EmbeddingGemma control path…"
        val started = System.currentTimeMillis()
        diagnosticJob = lifecycleScope.launch {
            try {
                val report = withTimeout(DIRECT_DIAGNOSTIC_TIMEOUT_MS) {
                    withContext(Dispatchers.IO) {
                        BenEmbeddingGemmaEngine(applicationContext).diagnostic { progress ->
                            runOnUiThread { statusView.text = "RUNNING • $progress" }
                        }
                    }
                }
                if (!report.isNullOrBlank()) {
                    RovexDiagnosticsStore.publish(this@RovexDiagnosticsDataCenter, report)
                    BenNeuralTelemetry.setDiagnosticReport(report)
                    reportView.text = report
                    statusView.text = "COMPLETE • direct control report stored • ${System.currentTimeMillis() - started} ms"
                } else {
                    val reason = "DIRECT_DIAGNOSTIC_EMPTY_REPORT"
                    RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, reason)
                    reportView.text = "Direct EmbeddingGemma diagnostic failed.\n\nReason: $reason\n\nThe direct control path returned no report. No study data was changed."
                    statusView.text = "FAILED • $reason"
                }
                refreshSnapshot()
            } catch (_: kotlinx.coroutines.TimeoutCancellationException) {
                val reason = "DIRECT_DIAGNOSTIC_TIMEOUT_${DIRECT_DIAGNOSTIC_TIMEOUT_MS}MS"
                RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, reason)
                reportView.text = "Direct EmbeddingGemma diagnostic timed out.\n\nReason: $reason\n\nThis is independent of Binder/isolated-process IPC. No study data was changed."
                statusView.text = "FAILED • $reason"
            } catch (_: kotlinx.coroutines.CancellationException) {
                RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, "DIRECT_DIAGNOSTIC_CANCELLED")
                reportView.text = "Direct EmbeddingGemma diagnostic cancelled. No study data was changed."
                statusView.text = "CANCELLED • direct control test"
            } catch (e: Exception) {
                val reason = "DIRECT_DIAGNOSTIC_EXCEPTION: ${e.javaClass.simpleName}: ${e.message ?: "unknown"}".take(500)
                RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, reason)
                reportView.text = "Direct EmbeddingGemma diagnostic failed.\n\nReason: $reason\n\nNo study data was changed."
                statusView.text = "FAILED • direct control exception"
            } finally {
                if (!isFinishing) finishDiagnosticUi()
            }
        }
    }

    private fun runIsolatedIpcDiagnostic() {
        if (diagnosticJob?.isActive == true) return
        runButton.text = "STOP TEST"
        runButton.setOnClickListener { diagnosticJob?.cancel() }
        progressBar.visibility = ProgressBar.VISIBLE
        reportView.text = "Isolated Ben IPC diagnostic started. This test is intentionally separate from the direct EmbeddingGemma control test."
        statusView.text = "STARTING • binding isolated inference process…"
        val started = System.currentTimeMillis()
        diagnosticJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    BenInferenceProcessClient(this@RovexDiagnosticsDataCenter).use { client ->
                        client.diagnosticSuspend { progress ->
                            runOnUiThread { statusView.text = "RUNNING • IPC • $progress" }
                        }
                    }
                }
                val report = result.report
                if (!report.isNullOrBlank()) {
                    RovexDiagnosticsStore.publish(this@RovexDiagnosticsDataCenter, report)
                    BenNeuralTelemetry.setDiagnosticReport(report)
                    reportView.text = report
                    statusView.text = "COMPLETE • isolated IPC report stored • ${System.currentTimeMillis() - started} ms"
                } else {
                    val reason = result.failure ?: "IPC_DIAGNOSTIC_EMPTY_RESULT"
                    RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, reason)
                    reportView.text = "Isolated Ben IPC diagnostic failed.\n\nReason: $reason\n\nThe direct control test remains available to isolate model/runtime behavior."
                    statusView.text = "FAILED • $reason"
                }
                refreshSnapshot()
            } catch (_: kotlinx.coroutines.CancellationException) {
                RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, "IPC_DIAGNOSTIC_CANCELLED")
                reportView.text = "Isolated Ben IPC diagnostic cancelled. No study data was changed."
                statusView.text = "CANCELLED • IPC test"
            } catch (e: Exception) {
                val reason = "IPC_DIAGNOSTIC_EXCEPTION: ${e.javaClass.simpleName}: ${e.message ?: "unknown"}".take(500)
                RovexDiagnosticsStore.publishFailure(this@RovexDiagnosticsDataCenter, reason)
                reportView.text = "Isolated Ben IPC diagnostic failed.\n\nReason: $reason"
                statusView.text = "FAILED • IPC exception"
            } finally {
                if (!isFinishing) finishDiagnosticUi()
            }
        }
    }

    private fun finishDiagnosticUi() {
        progressBar.visibility = ProgressBar.GONE
        runButton.text = "RUN FULL EMBEDDINGGEMMA TEST"
        runButton.setOnClickListener { runEmbeddingDiagnostic() }
    }

    private fun refreshSnapshot() {
        if (!::summaryView.isInitialized) return
        val t = BenNeuralTelemetry.snapshot()
        val g = BenAiResourceGovernor(this).snapshot(true)
        val latest = RovexDiagnosticsStore.latest(this)
        summaryView.text = "Stage: ${t.stage.name}\nModel: ${t.activeModel}\nLast latency: ${t.lastElapsedMs} ms\nConfidence: ${t.lastConfidence}%\nEvidence: ${t.lastEvidenceCount}\nVerified: ${if (t.lastVerified) "YES" else "NO"}\nRAM: ${g.availableMemoryMb} MB\nThermal: ${g.thermalStatus}\nPower-save: ${if (g.powerSave) "ON" else "OFF"}\nStored diagnostic: ${if (latest.isNullOrBlank()) "NONE" else "AVAILABLE"}"

    }

    private fun telemetryText(): String {
        val t = BenNeuralTelemetry.snapshot()
        return "Requests ${t.totalRequests} • neural ${t.neuralRequests} • fallback ${t.fallbackRequests} • blocked ${t.blockedRequests}\nSemantic runs ${t.semanticRuns} • generation runs ${t.generationRuns}\nLast error: ${t.lastError ?: "None"}"

    }

    private fun shareDiagnostics() {
        val t = BenNeuralTelemetry.snapshot()
        val gov = BenAiResourceGovernor(this).snapshot(true)
        val latest = RovexDiagnosticsStore.latest(this)
        val latestStatus = RovexDiagnosticsStore.latestStatus(this)
        val text = buildString {
            appendLine("ROVEX COMPLETE DIAGNOSTICS EXPORT")
            appendLine("exportedAt=${System.currentTimeMillis()}")
            appendLine("stage=${t.stage.name}")
            appendLine("stageDetail=${t.stageDetail}")
            appendLine("activeModel=${t.activeModel}")
            appendLine("modelKind=${t.modelKind}")
            appendLine("lastLatencyMs=${t.lastElapsedMs}")
            appendLine("lastSemanticMs=${t.lastSemanticMs}")
            appendLine("lastGenerationMs=${t.lastGenerationMs}")
            appendLine("evidenceCount=${t.lastEvidenceCount}")
            appendLine("verified=${t.lastVerified}")
            appendLine("confidence=${t.lastConfidence}")
            appendLine("totalRequests=${t.totalRequests}")
            appendLine("neuralRequests=${t.neuralRequests}")
            appendLine("fallbackRequests=${t.fallbackRequests}")
            appendLine("blockedRequests=${t.blockedRequests}")
            appendLine("semanticRuns=${t.semanticRuns}")
            appendLine("generationRuns=${t.generationRuns}")
            appendLine("ramAvailableMb=${gov.availableMemoryMb}")
            appendLine("thermalStatus=${gov.thermalStatus}")
            appendLine("powerSave=${gov.powerSave}")
            appendLine("lastError=${t.lastError ?: ""}")
            appendLine("latestDiagnosticStatus=${latestStatus ?: "NONE"}")
            appendLine()
            appendLine(latest ?: "No completed EmbeddingGemma report stored.")
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Rovex complete diagnostics")
            putExtra(Intent.EXTRA_TEXT, text.take(28000))
        }, "Share Rovex diagnostics"))
    }

    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(ThemeManager.elevated(this@RovexDiagnosticsDataCenter), 18) }
    private fun title(t: String) = TextView(this).apply { text = t; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RovexDiagnosticsDataCenter)) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 12f; setTextColor(ThemeManager.muted(this@RovexDiagnosticsDataCenter)) }
    private fun button(t: String, click: () -> Unit) = TextView(this).apply { text = t; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(ThemeManager.accent(this@RovexDiagnosticsDataCenter), 13); setOnClickListener { click() } }
    private fun lp(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun lpWrap(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun cardLp(top: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    companion object {
        // Direct control path is intentionally generous because v8.3.140 was known to need
        // substantial cold-start time on the Qualcomm/SM8650 runtime.
        private const val DIRECT_DIAGNOSTIC_TIMEOUT_MS = 150_000L
    }
}
