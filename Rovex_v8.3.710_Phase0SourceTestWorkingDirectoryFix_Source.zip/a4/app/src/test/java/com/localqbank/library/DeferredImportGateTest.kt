package com.localqbank.library

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class DeferredImportGateTest {
    @Test fun callbackResultReturnsToWorkerExactlyOnce() {
        val gate = DeferredImportGate<String>(1, TimeUnit.SECONDS)
        assertTrue(gate.complete("all questions"))
        assertFalse(gate.complete("partial duplicate"))
        assertEquals("all questions", gate.await())
    }

    @Test fun callbackFailureIsPropagatedToWorker() {
        val gate = DeferredImportGate<String>(1, TimeUnit.SECONDS)
        assertTrue(gate.fail(IllegalArgumentException("unsupported structure")))
        val thrown = assertThrows(IllegalStateException::class.java) { gate.await() }
        assertTrue(thrown.message.orEmpty().contains("unsupported structure"))
    }

    @Test fun missingCallbackTimesOutInsteadOfStallingImportForever() {
        val gate = DeferredImportGate<String>(1, TimeUnit.MILLISECONDS)
        assertThrows(TimeoutException::class.java) { gate.await() }
    }
}
