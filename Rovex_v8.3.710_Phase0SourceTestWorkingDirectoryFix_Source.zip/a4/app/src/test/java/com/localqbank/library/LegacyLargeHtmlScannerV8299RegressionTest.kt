package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

/** Confirms the exact v8.3.299 streaming parser remains available as a no-write preflight fallback. */
class LegacyLargeHtmlScannerV8299RegressionTest {
    @Test
    fun v8299ScannerParsesKnownGoodCombinedTestArray() {
        val file = File.createTempFile("rovex-v8299-import", ".html")
        try {
            file.writeText("""
                <html><script>
                  const TESTS_LIST = [{
                    "title":"DAMS Pathology",
                    "questions":[{"id":"legacy-q1","text":"Which cell is characteristic?","options":[{"label":"A","text":"Reed-Sternberg cell"}]}]
                  }];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LegacyLargeHtmlScannerV8299(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("DAMS Pathology:Which cell is characteristic?"), seen)
        } finally {
            file.delete()
        }
    }
}
