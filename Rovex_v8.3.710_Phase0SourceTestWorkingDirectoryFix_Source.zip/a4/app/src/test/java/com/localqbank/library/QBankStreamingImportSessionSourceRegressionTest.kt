package com.localqbank.library

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class QBankStreamingImportSessionSourceRegressionTest {
    @Test
    fun extractedStreamingSessionRetainsRequiredHelpers() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/QBankStreamingImportSession.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/QBankStreamingImportSession.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText() ?: ""
        assertTrue(
            "QBankStreamingImportSession.kt must retain its extracted bindNullable helper",
            source != null && source.contains(
                "private fun bindNullable(\n        statement: android.database.sqlite.SQLiteStatement"
            )
        )
        assertTrue(
            "QBankStreamingImportSession.kt must retain its extracted makeId helper",
            source != null && source.contains(
                "private fun makeId(file: String, original: String, index: Int): String"
            )
        )
    }
    @Test
    fun largeHtmlImportPreflightsQuestionsBeforeReplacingDatabaseSource() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/HtmlImportActivity.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/HtmlImportActivity.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText().orEmpty()
        val preflight = source.indexOf("val preflightScanner = LargeHtmlScanner(")
        val validatedCount = source.indexOf("preflightScanner.scan()", preflight.coerceAtLeast(0))
        val replacement = source.indexOf("repository.beginStreamingImport(", validatedCount.coerceAtLeast(0))
        assertTrue("large HTML scan must preflight before beginStreamingImport deletes/replaces the old source", preflight >= 0 && validatedCount > preflight && replacement > validatedCount)
        assertTrue(
            "zero-question preflight must fail before replacement and identify both attempted parsers",
            source.contains("Neither the v8.3.299 nor the adaptive streaming importer found valid questions") &&
                source.contains("The existing QBank was not replaced.")
        )
        assertTrue(
            "large-file preflight must include adaptive scanner diagnostics in its failure",
            source.contains("Adaptive scanner diagnostics: ${'$'}{preflightScanner.diagnosticsSummary}")
        )
    }

    @Test
    fun streamingSessionRejectsZeroQuestionFinish() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/QBankStreamingImportSession.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/QBankStreamingImportSession.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText().orEmpty()
        assertTrue("streaming session must refuse empty imports", source.contains("if (total <= 0)" ) && source.contains("Refusing to finish an empty QBank import"))
    }


    @Test
    fun htmlCompatibilityExtractionStaysInsideOneCoordinatorJob() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val source = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/HtmlImportActivity.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/HtmlImportActivity.kt")
        ).firstOrNull { it.isFile }?.readText().orEmpty()
        assertTrue("unsupported/ambiguous small HTML imports must use the compatibility extractor", source.contains("extractWithWebView(text, uri.toString())"))
        assertTrue("native acceptance must not rely on the old arbitrary four-question threshold", !source.contains("nativeCount > 4"))
        assertTrue("WebView results must be collected without a native JavascriptInterface", source.contains("scheduleWebExtractionResultRead") && !source.contains("addJavascriptInterface"))
        assertTrue("late callbacks must be fenced by extraction request ID", source.contains("callbackId != request.requestId") && source.contains("__rovexImportRequestId"))
        assertTrue("WebView result collection must not race a nested enqueue against the coordinator gate", Regex("AppManagers\\.importer\\.enqueue\\(").findAll(source).count() == 1)
        assertTrue("unknown SAF sizes must be distinguished from zero-byte files", source.contains("return -1L // Unknown is distinct from an empty document."))
        assertTrue("large srcdoc exports must search beyond the first megabyte", source.contains("scanWholeFile = actualSize >= LARGE_FILE_LIMIT"))
        assertTrue("srcdoc section count must increment only for question-bearing sections", source.contains("lastSrcdocCount++") && source.contains("if (questions > 0)"))
    }

}
