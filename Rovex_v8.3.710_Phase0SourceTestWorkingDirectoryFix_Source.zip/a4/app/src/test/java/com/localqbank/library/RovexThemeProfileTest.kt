package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexThemeProfileTest {
    private val keys = listOf(
        ThemeManager.LIGHT, ThemeManager.PASTEL, ThemeManager.MINT, ThemeManager.SUNSET,
        ThemeManager.LAVENDER, ThemeManager.AMOLED, ThemeManager.PANDORA, ThemeManager.SPACE
    )

    @Test
    fun allEightThemesHaveDistinctVisualProfiles() {
        val profiles = keys.map(RovexThemeProfile::forKey)
        assertEquals(8, profiles.size)
        assertEquals(8, profiles.map { it.name }.distinct().size)
        assertEquals(8, profiles.map { it.accent }.distinct().size)
        assertTrue(profiles.all { it.cornerDp in 20..28 })
    }


    @Test
    fun selectedAccentForegroundMeetsWcagAaForEveryTheme() {
        keys.map(RovexThemeProfile::forKey).forEach { profile ->
            val foreground = RovexContrastPolicy.onColor(profile.accent)
            assertTrue(
                "${profile.name} accent contrast was ${RovexContrastPolicy.contrastRatio(foreground, profile.accent)}",
                RovexContrastPolicy.contrastRatio(foreground, profile.accent) >= 4.5
            )
        }
    }

    @Test
    fun contrastPolicyChoosesReadableForegroundForLightAndDarkFills() {
        val fills = listOf(
            0xFFFFFFFF.toInt(), 0xFF000000.toInt(),
            0xFF00B09A.toInt(), 0xFFF55D30.toInt(), 0xFF34BDFF.toInt(),
            0xFF78AEFF.toInt(), 0xFF7048FF.toInt(), 0xFF222222.toInt()
        )
        fills.forEach { fill ->
            val foreground = RovexContrastPolicy.onColor(fill)
            assertTrue(
                "Contrast too low for fill 0x${fill.toUInt().toString(16)}",
                RovexContrastPolicy.contrastRatio(foreground, fill) >= 4.5
            )
        }
    }

    @Test
    fun motionProfilesRemainBounded() {
        keys.map(RovexThemeProfile::forKey).forEach { profile ->
            assertTrue(profile.flowSpeed > 0f && profile.flowSpeed <= 1f)
            assertTrue(profile.motionAlpha >= 0f && profile.motionAlpha <= 1f)
        }
    }
}
