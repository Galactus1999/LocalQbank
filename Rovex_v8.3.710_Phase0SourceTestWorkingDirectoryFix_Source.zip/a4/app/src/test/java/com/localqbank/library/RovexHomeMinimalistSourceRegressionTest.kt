package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class RovexHomeMinimalistSourceRegressionTest {
    private fun source(name: String): String = File("src/main/java/com/localqbank/library/$name").readText()

    @Test fun homeFeatureCardsDoNotRenderSubtitles() {
        val s = source("RovexHomeRevolution.kt")
        assertFalse(s.contains("col.addView(tv(a,sub,"))
        assertFalse(s.contains("onlineCopy.addView(onlineStatus,"))
        assertFalse(s.contains("Your saved answer history drives the dashboard."))
        assertFalse(s.contains("Browse the main imported QBank list, then open any bank"))
        assertFalse(s.contains("rovex_home_bookmarks_meta"))
        assertTrue(s.contains("progressMeta"))
        assertTrue(s.contains("continueButton"))
    }

    @Test fun dailyHubKeepsDataButDropsExplanatoryCopy() {
        val s = source("RovexDailyStudyHub.kt")
        assertFalse(s.contains("dot position = accuracy"))
        assertFalse(s.contains("Accuracy: higher dot"))
        assertFalse(s.contains("Plan → revise → log → build the streak"))
        assertTrue(s.contains("Last28StudyDaysGraphView"))
        assertTrue(s.contains("PLAN MY DAY"))
    }
}
