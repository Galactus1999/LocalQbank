package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Source-level guardrails only; these do not replace Android/WebView runtime tests. */
class Phase0SecurityBuildContractSourceTest {
    private fun source(relativePath: String): String {
        val root = File(System.getProperty("user.dir")).absoluteFile.normalize()
        // Gradle may execute tests with either the repository root or the Android
        // module directory as user.dir. Resolve both layouts explicitly so this
        // guard reads the real app/build.gradle.kts rather than failing on a
        // duplicated app/app path.
        val candidates = linkedSetOf(
            File(root, relativePath),
            File(root, "app/$relativePath"),
            File(root.parentFile, relativePath),
            File(root.parentFile, "app/$relativePath")
        )
        return candidates.firstOrNull { it.isFile }?.readText()
            ?: throw AssertionError(
                "Required source file not found: $relativePath; searched: " +
                    candidates.joinToString { it.absolutePath }
            )
    }

    @Test fun htmlImporterDoesNotExposeJavascriptInterfaceAndBlocksNavigation() {
        val s = source("src/main/java/com/localqbank/library/HtmlImportActivity.kt")
        assertFalse("Imported HTML must not receive a native JavascriptInterface", s.contains("addJavascriptInterface"))
        assertTrue("Top-level navigation must remain blocked", s.contains("override fun shouldOverrideUrlLoading(v: WebView?, request: android.webkit.WebResourceRequest?): Boolean = true"))
        assertTrue("File-origin cross-access must remain disabled", s.contains("allowFileAccessFromFileURLs = false"))
        assertTrue("Universal file-origin access must remain disabled", s.contains("allowUniversalAccessFromFileURLs = false"))
        assertTrue("Mixed content must remain blocked", s.contains("MIXED_CONTENT_NEVER_ALLOW"))
    }

    @Test fun releaseOptimizationStaysExplicitlyDisabledUntilRuntimeMatrixPasses() {
        val s = source("app/build.gradle.kts")
        val release = s.substringAfter("release {").substringBefore("\n        }")
        assertTrue("R8 minification must not be enabled without release validation", release.contains("isMinifyEnabled = false"))
        assertTrue("Resource shrinking must not be enabled without release validation", release.contains("isShrinkResources = false"))
    }
}
