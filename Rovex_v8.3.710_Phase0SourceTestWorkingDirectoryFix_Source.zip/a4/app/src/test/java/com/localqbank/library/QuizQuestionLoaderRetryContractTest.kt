package com.localqbank.library

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Regression contract for the production retry loop; keeps cancellation semantics explicit. */
class QuizQuestionLoaderRetryContractTest {
    @Test fun retryLoopStopsWhenInterruptedOrSuperseded() {
        val source = File("src/main/java/com/localqbank/library/QuizQuestionLoader.kt").readText()
        assertTrue(source.contains("@Volatile private var loadToken"))
        assertTrue(source.contains("Thread.currentThread().isInterrupted || token != loadToken"))
        assertTrue(source.contains("return@execute"))
        assertTrue(source.contains("Thread.currentThread().interrupt()"))
        assertTrue(!source.contains("return@repeat"))
    }
}
