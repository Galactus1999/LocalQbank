package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HtmlImportParserTest {
    @Test
    fun decodeHtmlEntitiesPreservesEmbeddedMarkup() {
        val source = "&lt;p&gt;MRI &amp; CT&lt;/p&gt; &quot;correct_answer&quot;: &quot;D. MRI&quot;"
        val decoded = HtmlImportParser.decodeHtmlEntitiesPreserveMarkup(source)
        assertEquals("<p>MRI & CT</p> \"correct_answer\": \"D. MRI\"", decoded)
    }

    @Test
    fun decodeHtmlEntitiesSupportsNumericAndDoubleEncodedEntities() {
        val source = "&#x3C;strong&#x3E;&amp;quot;MRI&amp;quot;&#x3C;/strong&#x3E;"
        val decoded = HtmlImportParser.decodeHtmlEntitiesPreserveMarkup(source)
        assertEquals("<strong>\"MRI\"</strong>", decoded)
    }

    @Test
    fun decodeHtmlEntitiesLeavesUnknownEntitiesUntouched() {
        val source = "drug &made_up;"
        val decoded = HtmlImportParser.decodeHtmlEntitiesPreserveMarkup(source)
        assertTrue(decoded.contains("&made_up;"))
    }

    @Test
    fun nativePathIsRestrictedToExplicitlySupportedPayloadAliases() {
        assertTrue(HtmlImportParser.hasKnownNativePayload("<script>const TESTS_LIST = [{\"questions\":[]}];</script>"))
        assertTrue(HtmlImportParser.hasKnownNativePayload("<script>const quizData = [{\"questions\":[]}];</script>"))
        assertTrue(HtmlImportParser.hasKnownNativePayload("<script>const qbank = {\"questions\":[{}]};</script>"))
        assertTrue(!HtmlImportParser.hasKnownNativePayload("<script>renderProviderSpecificQuiz(); attachQuestionHandlers();</script>"))
    }

    @Test
    fun universalDetectorRecognizesPlatformHintsAndFormatWithoutDependingOnQuestionTitle() {
        val detection = UniversalImportAdapterRegistry.detect(
            "export.html",
            "<!doctype html><script>/* DocTutorials offline export */</script>"
        )
        assertEquals(UniversalImportAdapterRegistry.Format.HTML, detection.format)
        assertEquals("DocTutorials", detection.provider)
        assertTrue(detection.confidence >= 80)
    }

    @Test
    fun universalProviderDetectionUsesSourceNameAndBoundedContentSignature() {
        assertEquals("PrepLadder", HtmlImportParser.detectProvider(emptyList(), "PrepLadder_export.html", ""))
        assertEquals("DAMS", HtmlImportParser.detectProvider(emptyList(), "export.html", "<!-- DAMS offline test export -->"))
    }

    @Test
    fun nativeParserAcceptsCommonCrossPlatformQuestionAndOptionAliases() {
        val html = """<script>const TESTS_LIST = [{"title":"Anatomy","questions":[{"id":"u1","question_html":"Which structure?","answerOptions":[{"label":"A","text":"First"},{"label":"B","text":"Second"}],"solutionText":"Because anatomy"}]}];</script>"""
        val tests = HtmlImportParser.parseCombinedHtmlNative(html)
        assertEquals(1, tests.sumOf { it.questions.size })
        val question = tests.flatMap { it.questions }.single()
        assertEquals("Which structure?", question.text)
        assertEquals(listOf("First", "Second"), question.options.map { it.text })
    }

}
