package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Regression coverage for the current LargeHtmlScanner API.
 *
 * An earlier v8.3.568 experiment introduced tests for a transient progress/count API while the scanner
 * was being changed. That API was intentionally reverted after CI failures.
 * These tests exercise the production scanner contract: scan() emits normalized questions
 * through onQuestion, continues past empty duplicate assignments, and never reports a
 * successful count unless it actually emits questions.
 */
class LargeHtmlScannerRegressionTest {
    @Test
    fun jvmJsonImplementationIsAvailableForScannerTests() {
        val value = org.json.JSONObject("""{"text":"real-json"}""").optString("text")
        assertEquals("real-json", value)
    }

    @Test
    fun testArrayEmitsFirstQuestion() {
        val file = File.createTempFile("rovex-large-html", ".html")
        try {
            file.writeText("""
                <html><script>const TESTS_LIST = [
                  {"title":"Pathology","questions":[{"id":"q1","text":"What is the diagnosis?","options":[{"label":"A","text":"Option A"}]}]}
                ];</script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:What is the diagnosis?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun emptyFirstAssignmentDoesNotMaskLaterValidAssignmentWithSameAlias() {
        val file = File.createTempFile("rovex-large-html-duplicate-alias", ".html")
        try {
            file.writeText("""
                <html><script>
                  const TESTS_LIST = [];
                  window.__runtimeReady = true;
                  const TESTS_LIST = [{"title":"DAMS Pathology","questions":[
                    {"id":"real-q1","text":"Question from later payload?","options":[{"label":"A","text":"Yes"}]}
                  ]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertEquals(listOf("DAMS Pathology:Question from later payload?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun metadataOnlyFirstAssignmentDoesNotMaskLaterValidAssignmentWithSameAlias() {
        val file = File.createTempFile("rovex-large-html-duplicate-metadata", ".html")
        try {
            file.writeText("""
                <script>
                  const QUESTIONS_DATA = [{"title":"runtime metadata","items":[]}];
                  const QUESTIONS_DATA = [{"id":"q-real","question":"Question from second array?","choices":[{"text":"Option A"}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(1, count)
            assertEquals(listOf("Question from second array?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun rootQuestionArrayUsesQuestionAliasWhenTextAliasesAreAbsent() {
        val file = File.createTempFile("rovex-large-html-root-alias", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q1","question":"Alias question?","choices":[{"label":"A","text":"Yes"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Alias question?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun rootQuestionArrayEmitsFirstQuestion() {
        val file = File.createTempFile("rovex-large-html-root", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q1","question":"Which is correct?","options":[{"label":"A","text":"Yes"}]}];</script>
            """.trimIndent())
            var count = 0
            LargeHtmlScanner(file) { _, question ->
                count++
                assertTrue(question.text.contains("Which is correct?"))
            }.scan()
            assertEquals(1, count)
        } finally {
            file.delete()
        }
    }

    @Test
    fun explicitJsonNullDoesNotMaskQuestionAndOptionAliases() {
        val file = File.createTempFile("rovex-large-html-null-alias", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q-null","raw_text":null,"text":null,"question":"Fallback question","options":null,"choices":[{"label":"A","text":"Yes"},{"label":"B","text":"No"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<ImportedQuestion>()
            LargeHtmlScanner(file) { _, question -> seen += question }.scan()
            assertEquals(1, seen.size)
            assertEquals("Fallback question", seen.single().text)
            assertEquals(listOf("Yes", "No"), seen.single().options.map { it.text })
        } finally {
            file.delete()
        }
    }


    @Test
    fun assignmentInsideJavascriptCommentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-comment", ".html")
        try {
            file.writeText("""
                <script>
                  // const TESTS_LIST = [{"question":"wrong","options":[{"text":"bad"}]}];
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"id":"q2","text":"Actual question","options":[{"label":"A","text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Actual question"), seen)
        } finally {
            file.delete()
        }
    }


    @Test
    fun blockCommentAssignmentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-block-comment", ".html")
        try {
            file.writeText("""
                <script>
                  /* const TESTS_LIST = [{"title":"Wrong","questions":[{"text":"bad","options":[{"text":"bad"}]}]}; */
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun quotedFakeAssignmentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-string", ".html")
        try {
            file.writeText("""
                <script>
                  const fake = "const TESTS_LIST = [{\\"title\\":\\"Wrong\\"}]";
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun windowQualifiedQuestionAliasIsRecognized() {
        val file = File.createTempFile("rovex-large-html-window", ".html")
        try {
            file.writeText("""
                <script>window.QUESTIONS_DATA = [{"question":"Window alias","options":[{"text":"Yes"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Window alias"), seen)
        } finally { file.delete() }
    }

    @Test
    fun declarationAndWhitespaceVariantsAreRecognized() {
        val file = File.createTempFile("rovex-large-html-whitespace", ".html")
        try {
            file.writeText("""
                <script>
                  let
                    questionData
                    =
                    [
                      {"question":"Whitespace alias","options":[{"text":"Yes"}]}
                    ];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Whitespace alias"), seen)
        } finally { file.delete() }
    }

    @Test
    fun identifierSubstringCannotHijackSupportedAlias() {
        val file = File.createTempFile("rovex-large-html-identifier", ".html")
        try {
            file.writeText("""
                <script>
                  const MY_TESTS_LIST = [{"title":"Wrong","questions":[{"text":"bad","options":[{"text":"bad"}]}]}];
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun scanReturnsValidatedQuestionCountAndRecognizesCaseInsensitiveAliases() {
        val file = File.createTempFile("rovex-large-html-alias-case", ".html")
        try {
            file.writeText("""
                <script>const tests_list = [
                  {"title":"Pathology","questions":[
                    {"id":"q1","text":"First question?","options":["A"]},
                    {"id":"q2","text":"Second question?","options":["B"]}
                  ]}
                ];</script>
            """.trimIndent())
            var emitted = 0
            val count = LargeHtmlScanner(file) { _, _ -> emitted++ }.scan()
            assertEquals(2, count)
            assertEquals(count, emitted)
        } finally {
            file.delete()
        }
    }

    @Test
    fun emptySupportedArrayReportsZeroInsteadOfSuccessfulImportCount() {
        val file = File.createTempFile("rovex-large-html-empty", ".html")
        try {
            file.writeText("<script>const TESTS_LIST = [];</script>")
            val count = LargeHtmlScanner(file) { _, _ -> throw AssertionError("No question should be emitted") }.scan()
            assertEquals(0, count)
        } finally {
            file.delete()
        }
    }



    @Test
    fun prefersCombinedTestsListOverEarlierAppDataMetadataArray() {
        val file = File.createTempFile("rovex-large-html-array-priority", ".html")
        try {
            file.writeText("""
                <html><script>
                  const APP_DATA = [{"title":"Metadata only","folders":[]}];
                  const TESTS_LIST = [{"title":"DAMS Pathology","questions":[
                    {"id":"dams-1","text":"Real question?","options":[
                      {"label":"A","text":"Correct option","correct":true},
                      {"label":"B","text":"Other option","correct":false}
                    ],"correct_answer":"A","explanation":"Because the evidence supports A."}
                  ]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertEquals(listOf("DAMS Pathology:Real question?"), seen)
        } finally {
            file.delete()
        }
    }


    @Test
    fun nestedAppDataFallbackFindsQuestionsUnderFoldersAndLessons() {
        val file = File.createTempFile("rovex-large-html-nested-appdata", ".html")
        try {
            file.writeText("""
                <html><script>
                  const APP_DATA = [{"title":"Metadata folder","folders":[
                    {"title":"Pathology","lessons":[
                      {"title":"Renal","questions":[
                        {"id":"nested-1","text":"Nested DAMS question?","options":[
                          {"label":"A","text":"Yes"},{"label":"B","text":"No"}
                        ]}
                      ]}
                    ]}
                  ]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertTrue(seen.single().endsWith(":Nested DAMS question?"))
        } finally {
            file.delete()
        }
    }

    @Test
    fun largeScannerAcceptsLegacyOptionListAndQuestionTextAliases() {
        val file = File.createTempFile("rovex-large-html-legacy-dams", ".html")
        try {
            file.writeText("""
                <html><script>const TESTS_LIST = [
                  {"title":"DAMS","questions":[
                    {"id":"dams-1","questionText":"Which finding is correct?","option_list":[
                      {"label":"A","option_text":"First option"},
                      {"label":"B","option_text":"Second option"}
                    ],"correct":"B","explanationText":"The second option is correct."}
                  ]}
                ];</script></html>
            """.trimIndent())
            val seen = mutableListOf<ImportedQuestion>()
            val count = LargeHtmlScanner(file) { _, question -> seen += question }.scan()
            assertEquals(1, count)
            assertEquals(1, seen.size)
            assertEquals("Which finding is correct?", seen.single().text)
            assertEquals(listOf("First option", "Second option"), seen.single().options.map { it.text })
            assertEquals("B", seen.single().correctAnswer)
        } finally {
            file.delete()
        }
    }


    @Test
    fun emptyRuntimeTestsArrayDoesNotMaskLaterDamsTestsList() {
        val file = File.createTempFile("rovex-large-html-runtime-tests", ".html")
        try {
            file.writeText("""
                <html><script>
                  const tests = [];
                  const TESTS_LIST = [{
                    "id":"dams-test-1", "title":"DAMS Pathology", "num_questions":1,
                    "questions":[{
                      "id":"dams-q1", "text":"Which finding is correct?",
                      "raw_text":"Which finding is correct?",
                      "options":[
                        {"label":"A","text":"Correct option","correct":true},
                        {"label":"B","text":"Incorrect option","correct":false}
                      ],
                      "correct_answer":"A", "explanation":"The first option is correct."
                    }]
                  }];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertEquals(listOf("DAMS Pathology:Which finding is correct?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun nestedItemsAliasIsRecognizedInsideCombinedTest() {
        val file = File.createTempFile("rovex-large-html-items-alias", ".html")
        try {
            file.writeText("""
                <script>const TESTS_LIST = [{"title":"DAMS","items":[
                  {"id":"q1","questionText":"Nested item question?","optionList":[
                    {"label":"A","text":"Yes"},{"label":"B","text":"No"}
                  ]}
                ]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(1, count)
            assertEquals(listOf("Nested item question?"), seen)
        } finally {
            file.delete()
        }
    }


    @Test
    fun recognizesDamsPayloadAfterBlockWithoutSemicolon() {
        val file = File.createTempFile("rovex-large-html-asi-boundary", ".html")
        try {
            file.writeText("""
                <html><script>
                  function initializePage() { window.ready = true }
                  const TESTS_LIST = [{"title":"DAMS Pathology","questions":[
                    {"id":"dams-1","text":"Which finding is correct?","options":[
                      {"label":"A","text":"Correct","correct":true},
                      {"label":"B","text":"Incorrect","correct":false}
                    ],"correct_answer":"A"}
                  ]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertEquals(listOf("DAMS Pathology:Which finding is correct?"), seen)
        } finally {
            file.delete()
        }
    }


    @Test
    fun largeScannerSupportsCommonQuizAndExamExportAliases() {
        val file = File.createTempFile("rovex-large-html-quiz-alias", ".html")
        try {
            file.writeText("""
                <html><script>
                  const runtimeState = [];
                  const quizData = [{"title":"Cardiology","questions":[
                    {"id":"quiz-1","questionText":"Which valve is affected?","optionList":[
                      {"label":"A","text":"Mitral"},{"label":"B","text":"Aortic"}
                    ],"correctAnswer":"A"}
                  ]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(1, count)
            assertEquals(listOf("Cardiology:Which valve is affected?"), seen)
        } finally { file.delete() }
    }


    @Test
    fun largeScannerFindsQuestionArraysNestedInsideObjectRoot() {
        val file = File.createTempFile("rovex-large-html-object-root", ".html")
        try {
            file.writeText("""
                <html><script>
                  const qbankExport = {
                    "title": "Neurology",
                    "metadata": {"version": 1},
                    "questions": [
                      {"id":"n-1","questionText":"Which tract is affected?","optionList":[
                        {"label":"A","text":"Corticospinal"},{"label":"B","text":"Spinothalamic"}
                      ],"correctAnswer":"A"}
                    ]
                  };
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(1, count)
            assertEquals(listOf("Imported Section:Which tract is affected?"), seen)
        } finally { file.delete() }
    }

    @Test
    fun nestedPaperDataContainerEmitsQuestionsInsteadOfReportingZero() {
        val file = File.createTempFile("rovex-paper-data-nested", ".html")
        try {
            file.writeText("""
                <html><script>
                  const paper_data = [{
                    "title":"Cardiology",
                    "paper_data":{"sections":[{
                      "name":"Cardiology",
                      "questions":[{"id":"p1","question":"Which valve is affected?",
                        "options":[{"label":"A","text":"Mitral"},{"label":"B","text":"Aortic"}]}]
                    }]}
                  }];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { section, question ->
                seen += "$section:${question.text}"
            }.scan()
            assertEquals(1, count)
            assertEquals(listOf("Cardiology:Which valve is affected?"), seen)
        } finally { file.delete() }
    }

    @Test
    fun scannerAcceptsUniversalQuestionAndOptionAliases() {
        val file = File.createTempFile("rovex-universal-alias", ".html")
        try {
            file.writeText("""<script>const TESTS_LIST = [{"title":"DAMS Anatomy","questions":[{"id":"u2","question_html":"Universal alias question?","answerOptions":[{"label":"A","text":"First"},{"label":"B","text":"Second"}],"correctOption":"B","solutionText":"Explanation"}]}];</script>""")
            val questions = mutableListOf<ImportedQuestion>()
            val count = LargeHtmlScanner(file) { _, q -> questions += q }.scan()
            assertEquals(1, count)
            assertEquals("Universal alias question?", questions.single().text)
            assertEquals(listOf("First", "Second"), questions.single().options.map { it.text })
            assertEquals("Explanation", questions.single().explanation)
        } finally { file.delete() }
    }

    @Test
    fun candidateIndexUsesUtf8ByteOffsetsAndSkipsCommentedOrQuotedFakeArrays() {
        val file = File.createTempFile("rovex-large-html-byte-offset", ".html")
        try {
            file.writeText("""
                <html><body>हृदय परीक्षण</body><script>
                  // const TESTS_LIST = [{"text":"fake","options":["A"]}];
                  const note = "const TESTS_LIST = [{fake: true}]";
                  const TESTS_LIST = [];
                  const QUESTIONLIST = [{"id":"utf8-q","question":"Which finding is correct?","optionList":["A","B"]}];
                </script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            val count = LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(1, count)
            assertEquals(listOf("Which finding is correct?"), seen)
        } finally {
            file.delete()
        }
    }

}
