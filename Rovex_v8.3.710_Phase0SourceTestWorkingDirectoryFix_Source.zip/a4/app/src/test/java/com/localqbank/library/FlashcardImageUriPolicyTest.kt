package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.File

class FlashcardImageUriPolicyTest {
    @Test fun allowsHttpAndHttpsDeckImagesWithoutCredentials() {
        val root = createTempDir(prefix = "flashcard-media-")
        try {
            assertEquals("https://example.org/a.png", FlashcardImageUriPolicy.validatePreviewSource("https://example.org/a.png", root))
            assertEquals("http://example.org/a.png", FlashcardImageUriPolicy.validatePreviewSource("http://example.org/a.png", root))
            assertNull(FlashcardImageUriPolicy.validatePreviewSource("https://user:pass@example.org/a.png", root))
        } finally { root.deleteRecursively() }
    }

    @Test fun rejectsUnsupportedSchemesAndOversizedDataImages() {
        val root = createTempDir(prefix = "flashcard-media-")
        try {
            assertNull(FlashcardImageUriPolicy.validatePreviewSource("javascript:alert(1)", root))
            assertNull(FlashcardImageUriPolicy.validatePreviewSource("content://provider/item", root))
            assertNull(FlashcardImageUriPolicy.validatePreviewSource("data:text/html,boom", root))
            assertNull(FlashcardImageUriPolicy.validatePreviewSource("data:image/png;base64," + "A".repeat(8 * 1024 * 1024), root))
        } finally { root.deleteRecursively() }
    }

    @Test fun filePreviewMustBeARealDescendantOfMediaDirectory() {
        val parent = createTempDir(prefix = "flashcard-parent-")
        val media = File(parent, "flashcard_media").apply { mkdirs() }
        val valid = File(media, "valid.png").apply { writeBytes(byteArrayOf(1, 2, 3)) }
        val sibling = File(parent, "flashcard_media_evil").apply { mkdirs() }
        val outside = File(sibling, "evil.png").apply { writeBytes(byteArrayOf(1)) }
        try {
            assertEquals(valid.toURI().toString(), FlashcardImageUriPolicy.validatePreviewSource(valid.toURI().toString(), media))
            assertNull(FlashcardImageUriPolicy.validatePreviewSource(outside.toURI().toString(), media))
            assertNull(FlashcardImageUriPolicy.validatePreviewSource(media.toURI().toString(), media))
            assertNull(FlashcardImageUriPolicy.validatePreviewSource(File(parent, "missing.png").toURI().toString(), media))
        } finally { parent.deleteRecursively() }
    }
}
