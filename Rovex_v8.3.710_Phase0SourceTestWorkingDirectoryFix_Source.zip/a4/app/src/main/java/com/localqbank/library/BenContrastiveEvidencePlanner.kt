package com.localqbank.library

/**
 * Deterministic Phase-3 contrastive evidence planner.
 *
 * Retrieval metadata only. Rank is a recall heuristic, not proof that a record supports the
 * answer. Keep a wider bounded candidate set available to generation and verification; do not
 * mislabel lower-ranked results as distractors without an explicit contradiction classifier.
 */
internal object BenContrastiveEvidencePlanner {
    data class Candidate(val sourceId: Long, val text: String, val score: Double = 0.0)

    fun plan(
        query: String,
        candidates: List<Candidate>,
        maxCandidates: Int = 8,
        maxContrastive: Int = 0,
        maxTotalChars: Int = 5_000
    ): BenContrastiveEvidence.Bundle {
        val candidateLimit = maxCandidates.coerceAtLeast(0)
        val contrastiveLimit = maxContrastive.coerceAtLeast(0)
        val charBudget = maxTotalChars.coerceAtLeast(0)
        val normalized = candidates.asSequence()
            .filter { it.text.isNotBlank() }
            .sortedWith(compareByDescending<Candidate> { it.score }.thenBy { it.sourceId })
            .distinctBy { it.sourceId }
            .toList()
        var remaining = charBudget
        val question = query.takeIf { it.isNotBlank() }?.let {
            val clipped = clean(it).take(remaining.coerceAtLeast(0))
            remaining -= clipped.length
            listOf(BenContrastiveEvidence.Item(BenContrastiveEvidence.Role.QUESTION_EVIDENCE, -1L, clipped, 1.0))
        }.orEmpty()
        fun takeRole(items: List<Candidate>, limit: Int, role: BenContrastiveEvidence.Role): List<BenContrastiveEvidence.Item> {
            if (limit <= 0 || remaining <= 0) return emptyList()
            val out = ArrayList<BenContrastiveEvidence.Item>(limit)
            for (candidate in items) {
                if (out.size >= limit || remaining <= 0) break
                val text = clean(candidate.text)
                if (text.isBlank()) continue
                val clipped = text.take(remaining)
                if (clipped.isBlank()) continue
                out += BenContrastiveEvidence.Item(role, candidate.sourceId, clipped, candidate.score)
                remaining -= clipped.length
            }
            return out
        }
        val candidateItems = takeRole(normalized, candidateLimit, BenContrastiveEvidence.Role.CANDIDATE_EVIDENCE)
        // No candidate is labelled contrastive unless a separate, explicit contradiction
        // detector establishes that role. Rank alone is insufficient.
        return BenContrastiveEvidence.Bundle(question, emptyList(), candidateItems)
            .bounded(maxQuestion = 1, maxContrastive = contrastiveLimit, maxCandidates = candidateLimit)
    }

    private fun clean(text: String): String = text.replace(Regex("\\s+"), " ").trim().take(700)
}
