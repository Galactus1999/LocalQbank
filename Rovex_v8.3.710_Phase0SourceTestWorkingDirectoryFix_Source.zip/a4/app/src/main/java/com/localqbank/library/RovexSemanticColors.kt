package com.localqbank.library

import android.content.Context
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/**
 * Semantic foreground/background pairs for dynamically themed UI.
 *
 * Callers must pass the surface that will actually be painted behind the text. This avoids the
 * common failure mode where a dark-theme foreground is reused on a light dialog/card (or vice
 * versa). State colors such as correct/wrong answers remain explicit and are not auto-recolored.
 */
object RovexSemanticColors {
    enum class Role { PRIMARY_TEXT, SECONDARY_TEXT, DISABLED_TEXT, ICON, SURFACE, ELEVATED_SURFACE }

    fun surface(context: Context, elevated: Boolean = false): Int =
        if (ThemeManager.isDark(context)) {
            ThemeManager.elevated(context)
        } else {
            if (elevated) Color.rgb(250, 252, 255) else Color.rgb(244, 247, 252)
        }

    fun foreground(context: Context, background: Int, role: Role = Role.PRIMARY_TEXT): Int {
        val dark = ThemeManager.isDark(context)
        val primary = if (dark) Color.rgb(246, 248, 252) else Color.rgb(24, 29, 39)
        val secondary = if (dark) Color.rgb(201, 209, 222) else Color.rgb(66, 75, 91)
        val disabled = if (dark) Color.rgb(164, 174, 190) else Color.rgb(92, 101, 116)
        val candidate = when (role) {
            Role.PRIMARY_TEXT -> primary
            Role.SECONDARY_TEXT -> secondary
            Role.DISABLED_TEXT -> disabled
            Role.ICON -> if (dark) Color.rgb(225, 231, 241) else Color.rgb(48, 58, 76)
            Role.SURFACE, Role.ELEVATED_SURFACE -> return background
        }
        return ensureContrast(candidate, background, if (role == Role.PRIMARY_TEXT) 4.5 else 3.0)
    }

    fun ensureContrast(foreground: Int, background: Int, minimum: Double = 4.5): Int {
        if (contrastRatio(foreground, background) >= minimum) return foreground
        val black = Color.BLACK
        val white = Color.WHITE
        val target = if (contrastRatio(black, background) >= contrastRatio(white, background)) black else white
        var low = 0
        var high = 255
        var best = target
        while (low <= high) {
            val mid = (low + high) ushr 1
            val mixed = blend(foreground, target, mid)
            if (contrastRatio(mixed, background) >= minimum) {
                best = mixed
                high = mid - 1
            } else low = mid + 1
        }
        return best
    }

    fun contrastRatio(first: Int, second: Int): Double {
        val a = luminance(first)
        val b = luminance(second)
        return (max(a, b) + 0.05) / (min(a, b) + 0.05)
    }

    private fun blend(from: Int, to: Int, amount: Int): Int {
        val t = amount / 255.0
        fun channel(a: Int, b: Int) = (a + (b - a) * t).toInt().coerceIn(0, 255)
        return Color.rgb(channel(Color.red(from), Color.red(to)),
            channel(Color.green(from), Color.green(to)), channel(Color.blue(from), Color.blue(to)))
    }

    private fun luminance(color: Int): Double {
        fun linear(value: Int): Double {
            val c = value / 255.0
            return if (c <= 0.04045) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * linear(Color.red(color)) +
            0.7152 * linear(Color.green(color)) + 0.0722 * linear(Color.blue(color))
    }
}
