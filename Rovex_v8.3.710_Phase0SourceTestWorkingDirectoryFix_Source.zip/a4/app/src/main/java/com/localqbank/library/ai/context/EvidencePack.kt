package com.localqbank.library.ai.context

/** Explicit evidence contract. Retrieved records remain candidates until claim/citation checks pass. */
data class EvidencePack(
    val questionEvidence: List<Item> = emptyList(),
    val candidateEvidence: List<Item> = emptyList(),
    val contrastiveEvidence: List<Item> = emptyList()
) {
    data class Item(val sourceId: Long, val text: String, val score: Double = 0.0)

    fun bounded(maxEach: Int = 8, maxChars: Int = 5000): EvidencePack {
        var remaining = maxChars.coerceAtLeast(0)
        fun clip(items: List<Item>): List<Item> {
            val out = ArrayList<Item>(maxEach)
            for (item in items.take(maxEach)) {
                if (remaining <= 0) break
                val text = item.text.replace(Regex("\\s+"), " ").trim().take(remaining)
                if (text.isNotBlank()) {
                    out += item.copy(text = text)
                    remaining -= text.length
                }
            }
            return out
        }
        return EvidencePack(clip(questionEvidence), clip(candidateEvidence), clip(contrastiveEvidence))
    }

    fun candidatesForClaimVerification(): List<Item> = candidateEvidence
}

internal fun com.localqbank.library.BenContrastiveEvidence.Bundle.toEvidencePack(): EvidencePack = EvidencePack(
    questionEvidence = question.map { EvidencePack.Item(it.sourceId, it.text, it.score) },
    candidateEvidence = candidates.map { EvidencePack.Item(it.sourceId, it.text, it.score) },
    contrastiveEvidence = contrastive.map { EvidencePack.Item(it.sourceId, it.text, it.score) }
).bounded()
