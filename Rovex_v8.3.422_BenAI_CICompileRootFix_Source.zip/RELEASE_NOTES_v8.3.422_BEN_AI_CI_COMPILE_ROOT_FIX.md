# Rovex v8.3.422 — BEN + AI CI Compile Root Fix

## Baseline
- Previous candidate: v8.3.421
- Previous versionCode: 513
- Package/applicationId: com.localqbank.library

## CI evidence
GitHub Actions run `logs_98124040768.zip` failed during `:app:compileDebugKotlin`.

First/root compiler error:
`app/src/main/java/com/localqbank/library/BenQuestionAiContextDialog.kt:327:41`
`Unresolved reference 'LayoutParams'`

The failing code used `ScrollView.LayoutParams`. `ScrollView` does not expose that symbol as used here. The child can be attached using the generic `android.view.ViewGroup.LayoutParams`, which is appropriate for width/height parameters accepted by `ViewGroup.addView`.

## Repair
Changed:
`scroll.addView(text, ScrollView.LayoutParams(-1, -2))`

To:
`scroll.addView(text, android.view.ViewGroup.LayoutParams(-1, -2))`

No chat architecture, provider, Markdown, Mermaid, WebView, IPC, database, or unrelated business logic was changed.

## Additional source checks
- No `UPLOAD PDF` / `uploadPdf` / `uploadPdfButton` references remain in Kotlin/XML.
- `PDF TEXT` and `RELATED Qs` remain present in the BEN + AI surface.
- Package remains `com.localqbank.library`.
- Version incremented monotonically to 8.3.422 / versionCode 514.

## Verification
- ZIP structural integrity: to be verified after packaging.
- Local Gradle verification: BLOCKED because `downloads.gradle.org` DNS resolution fails in the current environment.
- GitHub CI verification: REQUIRED for this candidate.
- Device verification: REQUIRED; no device claim is made from source-only repair.

## CI environment warnings observed
These are not the root failure:
- `sdkmanager` deprecation warning.
- GitHub Actions warning regarding Node.js 20 deprecation for `actions/cache@v4` / `actions/checkout@v4`.

They should be treated as workflow-maintenance debt, not as justification for changing the application code in this repair.
