package com.localqbank.library

import android.text.Html
import android.text.Spanned

/**
 * Deterministic, dependency-free Markdown presentation for Ben/Frankenstein output.
 * The renderer intentionally supports the exam-chat subset: headings, strong/emphasis,
 * strike, inline/code blocks, bullets, numbered lists, quotes and basic links.
 * No WebView or network work is performed here.
 */
fun rovexMarkdownToSpanned(raw: String): Spanned {
    var s = raw.replace("\r\n", "\n").replace("\r", "\n")

    // Remove executable HTML constructs while preserving ordinary imported markup.
    s = s.replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        .replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
        .replace(Regex("(?is)on[a-z]+\\s*=\\s*(['\"]).*?\\1"), "")

    // Fenced code blocks first so their contents are not interpreted as Markdown.
    val fenced = ArrayList<String>()
    s = s.replace(Regex("(?s)```(?:[a-zA-Z0-9_+.-]+)?\\n(.*?)```")) { m ->
        fenced += m.groupValues[1]
        "<pre><code>${Html.escapeHtml(m.groupValues[1])}</code></pre>"
    }

    s = s.replace(Regex("(?m)^#{1,6}\\s+(.+)$"), "<b>$1</b>")
        .replace(Regex("(?m)^>\\s?(.+)$"), "<blockquote>$1</blockquote>")
        .replace(Regex("(?m)^[-*+]\\s+"), "• ")
        .replace(Regex("(?m)^(\\d+)[.)]\\s+"), "$1. ")
        .replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
        .replace(Regex("~~(.+?)~~", RegexOption.DOT_MATCHES_ALL), "<del>$1</del>")
        .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
        .replace(Regex("(?<!_)_([^_\\n]+?)_(?!_)"), "<i>$1</i>")
        .replace(Regex("`([^`\\n]+?)`"), "<tt>$1</tt>")
        .replace(Regex("\\[([^\\]]+)]\\((https?://[^\\s)]+)\\)"), "<a href=\"$2\">$1</a>")

    // Preserve readable paragraph spacing while avoiding an enormous HTML tree.
    s = s.replace(Regex("\\n{3,}"), "\n\n")
    return Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY)
}
