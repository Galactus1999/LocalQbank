package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.roundToInt

/** Lightweight analytical infographic: graded resource bars, state labels and a live pulse. */
class RovexPerformanceLabView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var health=0; private var resilience=0; private var ram=0
    private var animated=FloatArray(3)
    private var running=false
    private var started=0L
    fun setScores(health:Int,resilience:Int,ram:Int){
        this.health=health.coerceIn(0,100); this.resilience=resilience.coerceIn(0,100); this.ram=ram.coerceIn(0,100)
        invalidate()
    }
    override fun onAttachedToWindow(){super.onAttachedToWindow();running=true;started=SystemClock.uptimeMillis();postInvalidateOnAnimation()}
    override fun onDetachedFromWindow(){running=false;super.onDetachedFromWindow()}
    override fun onWindowVisibilityChanged(visibility:Int){super.onWindowVisibilityChanged(visibility);running=visibility==View.VISIBLE;if(running)postInvalidateOnAnimation()}
    override fun onDraw(c:Canvas){
        super.onDraw(c)
        val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0||!running)return
        val density=resources.displayMetrics.density
        val dark=ThemeManager.isDark(context)
        val target=floatArrayOf(health.toFloat(),resilience.toFloat(),ram.toFloat())
        for(i in 0..2) animated[i]+= (target[i]-animated[i])*0.14f
        val labels=arrayOf("HEALTH","RESILIENCE","RAM")
        val left=8f*density;val right=w-8f*density;val bw=right-left;val rowH=25f*density
        for(i in 0..2){
            val y=8f*density+i*rowH
            val value=animated[i].roundToInt().coerceIn(0,100)
            p.color=if(dark)0xFF24313B.toInt() else 0xFFDCE5E9.toInt();c.drawRoundRect(left,y,right,y+7f*density,5f*density,5f*density,p)
            p.color=gradeColor(value);c.drawRoundRect(left,y,left+bw*(value/100f),y+7f*density,5f*density,5f*density,p)
            p.color=if(dark)0xFFE7EDF2.toInt() else 0xFF33404A.toInt();p.textSize=8.5f*density;p.isFakeBoldText=true
            c.drawText(labels[i],left,y-2f*density,p)
            p.textSize=8f*density;p.isFakeBoldText=false;c.drawText("$value%",right-25f*density,y-2f*density,p)
            p.color=if(dark)0xFF9EB0BA.toInt() else 0xFF66757E.toInt();p.textSize=7f*density;c.drawText(state(value),left,y+16f*density,p)
        }
        val pulse=(kotlin.math.sin(((SystemClock.uptimeMillis()-started)/1000.0)*Math.PI*2.0).toFloat()+1f)*0.5f
        p.color=ThemeManager.accent(context);c.drawCircle(right-5f*density,h-6f*density,(2f+2f*pulse)*density,p)
        if(running)postInvalidateOnAnimation()
    }
    private fun state(v:Int)=when{v>=85->"OPTIMAL";v>=70->"STABLE";v>=50->"WATCH";else->"GUARDED"}
    private fun gradeColor(v:Int)=when{v>=85->0xFF36B77C.toInt();v>=70->0xFF7FB95A.toInt();v>=50->0xFFE3AE45.toInt();else->0xFFD65F5F.toInt()}
}
