package com.localqbank.library

/**
 * Canonical mode-specific evidence policy for the Question AI panel.
 * It never invents provenance: PYQ is restricted to rows explicitly labelled as PYQ.
 * PYT is broader because the local corpus may encode previous-year/topic/test information
 * in test/source metadata without a dedicated PYT flag.
 */
class BenQuestionAiContextPolicy {
    fun evidence(question: Question, context: FrankensteinContextEngine.ContextBundle, mode: BenQuestionAiMode): String =
        buildString {
            append("QUESTION AI MODE: ").append(mode.label).append('\n')
            append("MODE PROMPT: ").append(mode.prompt).append("\n\n")
            when (mode) {
                BenQuestionAiMode.PYQ_CONTEXT -> appendPyq(context)
                BenQuestionAiMode.PYT_CONTEXT -> appendPyt(context)
                BenQuestionAiMode.FUTURE_RELATED -> appendFuture(context)
                BenQuestionAiMode.OTHER_OPTIONS -> appendOtherOptions(question)
            }
        }.take(MAX_EVIDENCE_CHARS)

    private fun StringBuilder.appendPyq(context: FrankensteinContextEngine.ContextBundle) {
        val rows = context.relatedQuestions.filter { it.hasExplicitPyqProvenance() }
        append("EXPLICIT PYQ EVIDENCE: ").append(rows.size).append(" local rows\n")
        if (rows.isEmpty()) {
            append("No locally retrieved question has explicit PYQ provenance. Do not relabel ordinary QBank questions as PYQs.\n")
            return
        }
        rows.take(MAX_ROWS).forEachIndexed { i, row -> appendRow("PYQ-${i + 1}", row) }
    }

    private fun StringBuilder.appendPyt(context: FrankensteinContextEngine.ContextBundle) {
        val explicit = context.relatedQuestions.filter { it.hasExplicitPytProvenance() }
        val rows = (explicit + context.relatedQuestions.filterNot { it.hasExplicitPytProvenance() })
            .distinctBy { it.id }
        append("PREVIOUS-YEAR/TOPIC/TEST EVIDENCE: ").append(rows.size).append(" local rows\n")
        if (rows.isEmpty()) {
            append("No related local rows were retrieved. State that limitation instead of inventing a PYT pattern.\n")
            return
        }
        rows.take(MAX_ROWS).forEachIndexed { i, row -> appendRow("PYT-${i + 1}", row) }
        append("Interpret metadata as provenance only when it explicitly supports the claim.\n")
    }

    private fun StringBuilder.appendFuture(context: FrankensteinContextEngine.ContextBundle) {
        append("FUTURE-RELATED EVIDENCE BASE: ").append(context.relatedQuestions.size).append(" local rows\n")
        context.relatedQuestions.take(MAX_ROWS).forEachIndexed { i, row ->
            append("[RELATED-${i + 1}] ").append(row.exam.ifBlank { "Unknown test" })
                .append(" / ").append(row.source.ifBlank { "Unknown source" }).append('\n')
            append("STEM: ").append(row.text.take(700)).append('\n')
            append("KEY: ").append(row.answer.take(220)).append("\n")
        }
        append("Generate only bounded plausible themes/stems from these patterns; never present them as predictions or leaked exam content.\n")
    }

    private fun StringBuilder.appendOtherOptions(question: Question) {
        val key = question.correctAnswer.orEmpty().trim()
        append("AUTHORITATIVE KEY: ").append(key.ifBlank { "not supplied" }).append('\n')
        append("ALL OPTIONS / DISTRACTOR ANALYSIS INPUT:\n")
        question.options.forEach { option ->
            val keyed = isKeyed(option, key)
            append("[").append(if (keyed) "KEYED" else "DISTRACTOR").append("] ")
                .append(option.label).append(". ").append(option.text.take(1800)).append('\n')
        }
        question.explanation?.takeIf { it.isNotBlank() }?.let {
            append("QBANK EXPLANATION:\n").append(it.take(3000)).append('\n')
        }
        append("Explain every non-keyed option, including the clinical clue that would make it correct in a different context, without changing the QBank key.\n")
    }

    private fun StringBuilder.appendRow(prefix: String, row: FrankensteinContextEngine.RelatedQuestion) {
        append('[').append(prefix).append("] ")
            .append(row.exam.ifBlank { "Unknown test" }).append(" / ")
            .append(row.source.ifBlank { "Unknown source" }).append('\n')
        append("QUESTION: ").append(row.text.take(850)).append('\n')
        append("KEY: ").append(row.answer.take(260)).append('\n')
    }

    private fun FrankensteinContextEngine.RelatedQuestion.hasExplicitPyqProvenance(): Boolean =
        metadataText().containsToken("pyq")

    private fun FrankensteinContextEngine.RelatedQuestion.hasExplicitPytProvenance(): Boolean =
        metadataText().containsToken("pyt") || metadataText().contains("previous year") || metadataText().contains("previous-year")

    private fun FrankensteinContextEngine.RelatedQuestion.metadataText(): String =
        "${exam.lowercase()} ${source.lowercase()} ${category.lowercase()}"

    private fun String.containsToken(token: String): Boolean =
        Regex("(^|[^a-z0-9])${Regex.escape(token)}([^a-z0-9]|$)").containsMatchIn(this)

    private fun isKeyed(option: Option, key: String): Boolean {
        if (key.isBlank()) return false
        val k = key.trim().lowercase()
        val label = option.label.trim().lowercase()
        val text = option.text.trim().lowercase()
        return k == label || k == "${label}." || k == text ||
            k.startsWith("$label ") || k.startsWith("$label.") || text == k.substringAfter(".", "").trim()
    }

    companion object {
        private const val MAX_ROWS = 8
        private const val MAX_EVIDENCE_CHARS = 12_000
    }
}
