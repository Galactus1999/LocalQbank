package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View

/** Compact animated SRS dashboard for the Home Flashcards card. */
class RovexFlashcardSummaryView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var cards=0; private var due=0; private var reviews=0; private var running=false; private var started=0L
    fun setStats(cards:Int,due:Int,reviews:Int){this.cards=cards.coerceAtLeast(0);this.due=due.coerceAtLeast(0);this.reviews=reviews.coerceAtLeast(0);invalidate()}
    override fun onAttachedToWindow(){super.onAttachedToWindow();running=true;started=SystemClock.uptimeMillis();postInvalidateOnAnimation()}
    override fun onDetachedFromWindow(){running=false;super.onDetachedFromWindow()}
    override fun onWindowVisibilityChanged(visibility:Int){super.onWindowVisibilityChanged(visibility);running=visibility==View.VISIBLE;if(running)postInvalidateOnAnimation()}
    override fun onDraw(c:Canvas){
        val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0||!running)return
        val d=resources.displayMetrics.density;val dark=ThemeManager.isDark(context);val accent=ThemeManager.accent(context)
        p.color=if(dark)0xFF111C24.toInt() else 0xFFF0F6F5.toInt();c.drawRoundRect(4f*d,4f*d,w-4f*d,h-4f*d,18f*d,18f*d,p)
        p.color=accent;p.textSize=9f*d;p.isFakeBoldText=true;c.drawText("SRS",14f*d,18f*d,p)
        p.color=if(dark)0xFFE8EEF2.toInt() else 0xFF263C46.toInt();p.textSize=16f*d;c.drawText(cards.toString(),14f*d,38f*d,p)
        p.isFakeBoldText=false;p.textSize=7.5f*d;c.drawText("CARDS",14f*d,49f*d,p)
        val dueRatio=if(cards>0)(due.toFloat()/cards).coerceIn(0f,1f) else 0f
        val reviewRatio=((reviews.coerceAtMost(maxOf(cards,1))).toFloat()/maxOf(cards,1)).coerceIn(0f,1f)
        drawBar(c,14f*d,57f*d,w-14f*d,4f*d,dueRatio,if(due>0)0xFFD65F5F.toInt() else 0xFF43A77D.toInt())
        drawBar(c,14f*d,67f*d,w-14f*d,4f*d,reviewRatio,accent)
        p.color=if(dark)0xFFA8B6BE.toInt() else 0xFF60727B.toInt();p.textSize=7.5f*d;c.drawText(if(due>0)"$due DUE" else "UP TO DATE",14f*d,80f*d,p);c.drawText("$reviews REVIEWS",14f*d,90f*d,p)
        val pulse=(kotlin.math.sin(((SystemClock.uptimeMillis()-started)/1000.0)*Math.PI*2.0).toFloat()+1f)*0.5f
        p.color=accent;c.drawCircle(w-15f*d,18f*d,(2f+1.5f*pulse)*d,p)
        if(running)postInvalidateOnAnimation()
    }
    private fun drawBar(c:Canvas,l:Float,t:Float,r:Float,h:Float,value:Float,color:Int){p.color=0x223A4A55.toInt();c.drawRoundRect(l,t,r,t+h,h,h,p);p.color=color;c.drawRoundRect(l,t,l+(r-l)*value,t+h,h,h,p)}
}
