package com.localqbank.library

import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.webkit.WebView

/**
 * Keeps chat reading space dominant without removing any controls.
 * Chrome collapses while the WebView is scrolled and reappears on reverse scroll or via the
 * small SHOW CONTROLS affordance. This mirrors Android's documented enter-always/collapse
 * app-bar pattern without introducing a CoordinatorLayout around a WebView.
 */
class RovexChatChromeController(
    private val web: WebView,
    private val topChrome: ViewGroup,
    private val bottomChrome: ViewGroup,
    private val reveal: View,
    private val keepExpanded: () -> Boolean = { false }
) {
    private var lastY = web.scrollY
    private var hidden = false
    private val scrollListener = ViewTreeObserver.OnScrollChangedListener {
        if (!web.isShown || keepExpanded()) return@OnScrollChangedListener
        val y = web.scrollY
        if (!hidden && y > 48 && y > lastY + 8) hide()
        else if (hidden && (y < lastY - 8 || y < 24)) show()
        lastY = y
    }

    init {
        reveal.contentDescription = "Show chat controls"
        reveal.setOnClickListener { show() }
        reveal.visibility = View.GONE
        web.viewTreeObserver.addOnScrollChangedListener(scrollListener)
        web.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = Unit
            override fun onViewDetachedFromWindow(v: View) {
                if (web.viewTreeObserver.isAlive) web.viewTreeObserver.removeOnScrollChangedListener(scrollListener)
            }
        })
    }

    fun show() {
        if (!hidden) return
        hidden = false
        topChrome.visibility = View.VISIBLE
        bottomChrome.visibility = View.VISIBLE
        reveal.visibility = View.GONE
        topChrome.alpha = 0f
        bottomChrome.alpha = 0f
        topChrome.animate().alpha(1f).setDuration(150L).start()
        bottomChrome.animate().alpha(1f).setDuration(150L).start()
    }

    fun hide() {
        if (hidden || keepExpanded()) return
        hidden = true
        topChrome.animate().alpha(0f).setDuration(120L).withEndAction { topChrome.visibility = View.GONE }.start()
        bottomChrome.animate().alpha(0f).setDuration(120L).withEndAction { bottomChrome.visibility = View.GONE }.start()
        reveal.visibility = View.VISIBLE
        reveal.alpha = 0f
        reveal.animate().alpha(0.96f).setDuration(120L).start()
    }
}
