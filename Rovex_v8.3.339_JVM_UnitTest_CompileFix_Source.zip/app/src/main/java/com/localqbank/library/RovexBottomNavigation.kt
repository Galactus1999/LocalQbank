package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Single owner of Rovex's five primary destinations.
 *
 * This is deliberately a small native shell rather than Material BottomNavigationView: the
 * latter carries a Material-3 minimum-height/indicator policy that made the old footer visually
 * oversized on this compact phone UI. The shell has an exact bounded footprint and no per-item
 * outline/indicator.
 */
object RovexBottomNavigation {
    const val STATE_KEY = "rovex.bottom_navigation.selected_index"
    private const val NAV_TAG = "rovex_bottom_navigation"
    private const val NAV_HEIGHT_DP = 44
    private const val HORIZONTAL_MARGIN_DP = 7
    private const val BOTTOM_MARGIN_DP = 3

    enum class Destination(val index: Int, val menuId: Int, val activity: Class<out Activity>, val titleRes: Int, val iconRes: Int) {
        HOME(0, R.id.nav_home, MainActivity::class.java, R.string.nav_home, R.drawable.ic_nav_home),
        QBANK(1, R.id.nav_qbank, MainQBankLibraryActivity::class.java, R.string.nav_qbank, R.drawable.ic_nav_qbank),
        FLASHCARDS(2, R.id.nav_flashcards, FlashcardActivity::class.java, R.string.nav_flashcards, R.drawable.ic_nav_flashcards),
        BEN(3, R.id.nav_ben, RenActivity::class.java, R.string.nav_ben, R.drawable.ic_nav_ben),
        TOOLS(4, R.id.nav_tools, StudyToolsActivity::class.java, R.string.nav_tools, R.drawable.ic_nav_tools)
    }

    fun install(activity: Activity, selectedIndex: Int, savedInstanceState: Bundle? = null) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val existing = content.findViewWithTag<View>(NAV_TAG)
        if (existing is ViewGroup) {
            configure(activity, existing, selectedIndex, savedInstanceState)
            return
        }

        val shell = FrameLayout(activity).apply {
            tag = NAV_TAG
            id = R.id.rovexPersistentBottomNavigation
            setPadding(dp(activity, 4), dp(activity, 2), dp(activity, 4), dp(activity, 2))
            background = UiDrawableUtils.roundedDrawable(activity, ThemeManager.elevated(activity), 14f)
            elevation = dp(activity, 2).toFloat()
            clipChildren = true
            clipToPadding = true
        }
        val items = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        shell.addView(items, FrameLayout.LayoutParams(-1, -1))
        Destination.entries.forEach { destination ->
            items.addView(createItem(activity, destination), LinearLayout.LayoutParams(0, -1, 1f))
        }
        configure(activity, shell, selectedIndex, savedInstanceState)

        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, NAV_HEIGHT_DP)).apply {
            gravity = Gravity.BOTTOM
            leftMargin = dp(activity, HORIZONTAL_MARGIN_DP)
            rightMargin = dp(activity, HORIZONTAL_MARGIN_DP)
            bottomMargin = dp(activity, BOTTOM_MARGIN_DP)
        }
        content.addView(shell, lp)

        // The content root already reserves the system safe area. Reserve only the compact
        // application shell so scrollable study content cannot hide behind it.
        val root = content.getChildAt(0)
        root?.let { child ->
            val protected = dp(activity, NAV_HEIGHT_DP + BOTTOM_MARGIN_DP)
            val key = R.id.rovexNavOriginalPadding
            val original = child.getTag(key) as? IntArray ?: intArrayOf(child.paddingLeft, child.paddingTop, child.paddingRight, child.paddingBottom).also { child.setTag(key, it) }
            child.setPadding(original[0], original[1], original[2], original[3] + protected)
        }
    }

    fun saveInstanceState(outState: Bundle, selectedIndex: Int) {
        outState.putInt(STATE_KEY, selectedIndex.coerceIn(0, Destination.entries.lastIndex))
    }

    private fun createItem(activity: Activity, destination: Destination): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        isFocusable = true
        contentDescription = activity.getString(destination.titleRes)
        background = android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)
        setPadding(dp(activity, 1), 0, dp(activity, 1), 0)
        tag = "${NAV_TAG}_item_${destination.index}"
        addView(ImageView(activity).apply {
            tag = "${NAV_TAG}_icon_${destination.index}"
            setImageResource(destination.iconRes)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setColorFilter(ThemeManager.muted(activity))
        }, LinearLayout.LayoutParams(dp(activity, 17), dp(activity, 17)))
        addView(TextView(activity).apply {
            tag = "${NAV_TAG}_label_${destination.index}"
            text = activity.getString(destination.titleRes)
            textSize = 8.5f
            gravity = Gravity.CENTER
            setSingleLine(true)
            includeFontPadding = false
            setTextColor(ThemeManager.muted(activity))
            setPadding(0, dp(activity, 1), 0, 0)
        }, LinearLayout.LayoutParams(-1, dp(activity, 16)))
    }

    private fun configure(activity: Activity, shell: ViewGroup, selectedIndex: Int, savedInstanceState: Bundle?) {
        val restored = savedInstanceState?.getInt(STATE_KEY, selectedIndex) ?: selectedIndex
        val safeIndex = restored.coerceIn(0, Destination.entries.lastIndex)
        shell.background = UiDrawableUtils.roundedDrawable(activity, ThemeManager.elevated(activity), 14f)
        val items = shell.findViewWithTag<ViewGroup>("${NAV_TAG}_item_0")?.parent as? ViewGroup
            ?: return
        for (i in 0 until items.childCount) {
            val item = items.getChildAt(i) as? ViewGroup ?: continue
            val selected = i == safeIndex
            val icon = item.getChildAt(0) as? ImageView
            val label = item.getChildAt(1) as? TextView
            val tint = if (selected) ThemeManager.accent(activity) else ThemeManager.muted(activity)
            icon?.setColorFilter(tint)
            label?.setTextColor(tint)
            item.alpha = if (selected) 1f else .88f
            item.setOnClickListener {
                if (i == safeIndex) return@setOnClickListener
                val destination = Destination.entries[i]
                val intent = Intent(activity, destination.activity).apply {
                    addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                activity.startActivity(intent)
            }
        }
    }

    private fun dp(activity: Activity, value: Int): Int =
        (value * activity.resources.displayMetrics.density).toInt().coerceAtLeast(1)
}
