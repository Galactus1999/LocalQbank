package com.localqbank.library

import android.app.AlertDialog
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class BenFreeAiDialog(private val activity: RenActivity, private val scope: CoroutineScope) {
    private fun dp(v:Int)= (v*activity.resources.displayMetrics.density).toInt()

    private fun panel(c:Int, radius:Float=16f)=GradientDrawable().apply{setColor(c);cornerRadius=dp(radius.toInt()).toFloat()}

    fun show(){
        val gateway=AppManagers.cloudAi
        val body=LinearLayout(activity).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(8),dp(18),dp(8))
            background=panel(ThemeManager.dialogBg(activity),22f)
        }
        val header=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        header.addView(TextView(activity).apply{
            text="FREE AI";textSize=19f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))
        },LinearLayout.LayoutParams(0,dp(34),1f))
        header.addView(TextView(activity).apply{
            text="OPTIONAL";textSize=9f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER
            setTextColor(ThemeManager.aiText(activity));background=panel(ThemeManager.explanationBg(activity),10f);setPadding(dp(8),0,dp(8),0)
        },LinearLayout.LayoutParams(dp(70),dp(28)))
        body.addView(header)
        body.addView(TextView(activity).apply{
            text="Ben remains the local context and retrieval layer. Choose a connected provider only when you want cloud generation."
            textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(3),0,dp(10))
        })
        val status=TextView(activity).apply{
            text="Local Ben • ${currentBenExamProfile(activity).label}";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.aiText(activity));background=panel(ThemeManager.elevated(activity),12f);setPadding(dp(10),dp(8),dp(10),dp(8))
        }
        body.addView(status,LinearLayout.LayoutParams(-1,dp(36)).apply{bottomMargin=dp(8)})

        val test=TextView(activity).apply{
            text="TEST CONNECTED PROVIDERS";textSize=10f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(activity));background=panel(ThemeManager.elevated(activity),10f);setOnClickListener{
                scope.launch{
                    val connected=gateway.configs().filter{it.enabled&&it.hasKey}
                    if(connected.isEmpty()){Toast.makeText(activity,"No enabled provider is configured",Toast.LENGTH_SHORT).show();return@launch}
                    val results=connected.map{cfg->cfg.provider.label+": "+runCatching{gateway.test(cfg.provider)}.fold({"PASS"},{"FAIL • "+(it.message ?: "unknown error")})}
                    AlertDialog.Builder(activity).setTitle("AI provider diagnostics").setMessage(results.joinToString("\n\n")).setPositiveButton("DONE",null).show()
                }
            }
        }
        body.addView(test,LinearLayout.LayoutParams(-1,dp(34)).apply{bottomMargin=dp(6)})

        BenCloudAiGateway.Provider.values().forEach{provider->
            val cfg=gateway.configs().first{it.provider==provider}
            val row=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(7),dp(10),dp(7));background=panel(ThemeManager.elevated(activity),13f)}
            val title=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            title.addView(TextView(activity).apply{text=provider.label;textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))},LinearLayout.LayoutParams(0,dp(28),1f))
            title.addView(TextView(activity).apply{text=if(cfg.hasKey){if(cfg.enabled)"ON" else "OFF"}else"NOT CONNECTED";textSize=8.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(activity));background=panel(ThemeManager.dialogBg(activity),8f);setPadding(dp(7),0,dp(7),0)},LinearLayout.LayoutParams(dp(82),dp(24)))
            row.addView(title)
            row.addView(TextView(activity).apply{text=if(cfg.hasKey)cfg.model else "Connect an API key to use this provider";textSize=10f;setTextColor(ThemeManager.muted(activity));setPadding(0,0,0,dp(5))})
            val actions=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            fun small(label:String, click:()->Unit)=TextView(activity).apply{text=label;textSize=9.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(activity));background=panel(ThemeManager.dialogBg(activity),9f);setOnClickListener{click()}}
            actions.addView(small(if(cfg.hasKey)"UPDATE KEY" else "CONNECT"){showProviderKeyDialog(provider)},LinearLayout.LayoutParams(0,dp(32),1f))
            actions.addView(small("TEST"){scope.launch{val r=runCatching{gateway.test(provider)};Toast.makeText(activity,if(r.isSuccess)"${provider.label}: connection OK" else "${provider.label}: ${r.exceptionOrNull()?.message ?: "failed"}",Toast.LENGTH_LONG).show()}},LinearLayout.LayoutParams(0,dp(32),1f).apply{leftMargin=dp(5)})
            val sw=Switch(activity).apply{text="Use";textSize=10f;isChecked=cfg.enabled&&cfg.hasKey;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,v->gateway.setEnabled(provider,v)}}
            actions.addView(sw,LinearLayout.LayoutParams(dp(66),dp(34)).apply{leftMargin=dp(5)})
            row.addView(actions)
            body.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})
        }
        body.addView(TextView(activity).apply{
            text="Rovex never enables a provider automatically. Provider keys remain locally protected by Android Keystore."
            textSize=9.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,0)
        })
        val scroll=ScrollView(activity).apply{addView(body);isFillViewport=true}
        val dialog=AlertDialog.Builder(activity).setView(scroll).setPositiveButton("DONE",null).create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setOnShowListener{dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.94f).toInt(),(activity.resources.displayMetrics.heightPixels*0.86f).toInt())}
        dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.94f).toInt(),(activity.resources.displayMetrics.heightPixels*0.86f).toInt())
    }

    private fun showProviderKeyDialog(provider:BenCloudAiGateway.Provider){
        val gateway=AppManagers.cloudAi
        val layout=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(4),dp(20),0)}
        layout.addView(TextView(activity).apply{text="${provider.label} API key";textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));setPadding(0,0,0,dp(5))})
        layout.addView(TextView(activity).apply{text="Get the key from the provider's official page. Rovex encrypts it locally and never logs it.";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,0,0,dp(8))})
        val key=EditText(activity).apply{hint="Paste API key";inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD;setSingleLine(true)}
        layout.addView(key,LinearLayout.LayoutParams(-1,dp(52)))
        val model=EditText(activity).apply{hint="Model";setSingleLine(true);setText(gateway.configs().first{it.provider==provider}.model)}
        layout.addView(model,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(5),0,0)})
        val dialog=AlertDialog.Builder(activity).setTitle("Connect ${provider.label}").setView(layout).setNegativeButton("CANCEL",null).setNeutralButton("GET KEY"){_,_->runCatching{gateway.openKeyPage(activity,provider)}.onFailure{Toast.makeText(activity,"Could not open provider page",Toast.LENGTH_SHORT).show()}}.setPositiveButton("SAVE & TEST",null).create()
        dialog.setOnShowListener{dlg->
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val value=key.text.toString().trim()
                if(value.isBlank()){key.error="API key required";return@setOnClickListener}
                val modelValue=model.text.toString().trim()
                runCatching{
                    gateway.saveKey(provider,value)
                    gateway.setModel(provider,modelValue)
                    gateway.setEnabled(provider,true)
                }.onFailure{
                    key.error=it.message ?: "Could not save activity API key"
                    Toast.makeText(activity,"${provider.label}: ${it.message ?: "key storage failed"}",Toast.LENGTH_LONG).show()
                    return@onFailure
                }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled=false
                scope.launch{
                    val result=runCatching{gateway.test(provider)}
                    if(!activity.isFinishing && !activity.isDestroyed){
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled=true
                        if(result.isSuccess){
                            dlg.dismiss()
                            Toast.makeText(activity,"${provider.label} connected and tested successfully",Toast.LENGTH_LONG).show()
                            activity.recreate()
                        }else{
                            gateway.setEnabled(provider,false)
                            Toast.makeText(activity,
                                "${provider.label}: key saved locally, but connection test failed: ${result.exceptionOrNull()?.message ?: "unknown error"}.",
                                Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
        dialog.show()
    }

}
