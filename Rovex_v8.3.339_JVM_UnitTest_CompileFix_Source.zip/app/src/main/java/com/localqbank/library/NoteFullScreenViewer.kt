package com.localqbank.library

import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

/** Full-screen secondary reader for saved notes; the Notes list stays a lightweight index. */
class NoteFullScreenViewer {
    private fun dp(activity: NotesActivity, value: Int) = (value * activity.resources.displayMetrics.density).toInt()
    private fun rounded(activity: NotesActivity, fill: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(activity, radius.toInt()).toFloat()
    }

    fun show(activity: NotesActivity, title: String, bodyText: String, imagePaths: List<String>) {
        val dialog = Dialog(activity)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = ThemeManager.backgroundDrawable(activity)
            setPadding(dp(activity,10), dp(activity,8), dp(activity,10), dp(activity,8))
        }
        val header = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(activity).apply {
            text=title; textSize=18f; typeface=Typeface.DEFAULT_BOLD; maxLines=2
            ellipsize=android.text.TextUtils.TruncateAt.END; setTextColor(ThemeManager.text(activity))
        }, LinearLayout.LayoutParams(0,dp(activity,42),1f))
        header.addView(TextView(activity).apply {
            text="×"; textSize=25f; gravity=Gravity.CENTER; setTextColor(ThemeManager.text(activity))
            background=rounded(activity,ThemeManager.elevated(activity),12f); setOnClickListener{dialog.dismiss()}
        },LinearLayout.LayoutParams(dp(activity,42),dp(activity,42)))
        root.addView(header)

        if (imagePaths.isEmpty()) {
            val dark=ThemeManager.isDark(activity)
            val bg=String.format("#%06X",0xFFFFFF and ThemeManager.elevated(activity))
            val fg=String.format("#%06X",0xFFFFFF and ThemeManager.text(activity))
            val ac=String.format("#%06X",0xFFFFFF and ThemeManager.aiText(activity))
            val html="<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{background:$bg;color:$fg;font-family:sans-serif;font-size:17px;line-height:1.62;margin:0;padding:8px}p{margin:9px 0}h1{font-size:25px}h2{font-size:21px}h3{font-size:18px}pre{overflow:auto;padding:10px;border-radius:9px;background:${if(dark)"#11171C" else "#EEF1F3"}}.table-wrap{width:100%;max-width:100%;max-height:72vh;overflow:auto;touch-action:pan-x pan-y}.table-wrap table{width:max-content;min-width:680px;border-collapse:collapse}.table-wrap th,.table-wrap td{border:1px solid ${if(dark)"#385064" else "#CBD4DA"};padding:9px;text-align:left;vertical-align:top}.table-wrap th{background:${if(dark)"#1D3342" else "#EAF1F5"};color:$ac}img{max-width:100%;height:auto}</style></head><body>${rovexMarkdownBody(bodyText)}</body></html>"
            root.addView(WebView(activity).apply {
                settings.javaScriptEnabled=false;settings.domStorageEnabled=false;settings.allowFileAccess=false;settings.allowContentAccess=false
                settings.loadsImagesAutomatically=true;settings.mixedContentMode=android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                webViewClient=WebViewClient();setBackgroundColor(Color.TRANSPARENT);isHorizontalScrollBarEnabled=true
                loadDataWithBaseURL(null,html,"text/html","UTF-8",null)
            },LinearLayout.LayoutParams(-1,0,1f))
        } else {
            val scroll=ScrollView(activity).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
            val body=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(activity,4),dp(activity,4),dp(activity,4),dp(activity,18))}
            if(bodyText.isNotBlank()) body.addView(TextView(activity).apply{text=bodyText;textSize=17f;setTextColor(ThemeManager.text(activity));setLineSpacing(0f,1.45f);setPadding(dp(activity,4),dp(activity,4),dp(activity,4),dp(activity,10))})
            imagePaths.filter{java.io.File(it).exists()}.forEach{path->
                body.addView(ImageView(activity).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;setImageBitmap(decode(activity,path));contentDescription="Saved note image"},LinearLayout.LayoutParams(-1,dp(activity,420)).apply{topMargin=dp(activity,6)})
            }
            scroll.addView(body);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        }
        dialog.setContentView(root);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show()
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun decode(activity: NotesActivity,path:String):android.graphics.Bitmap? = runCatching {
        val opts=android.graphics.BitmapFactory.Options().apply{inJustDecodeBounds=true}
        android.graphics.BitmapFactory.decodeFile(path,opts)
        if(opts.outWidth<=0||opts.outHeight<=0)return@runCatching null
        var sample=1; val maxW=(activity.resources.displayMetrics.widthPixels*activity.resources.displayMetrics.density*.9f).toInt().coerceAtLeast(720)
        while(opts.outWidth/sample>maxW||opts.outHeight/sample>1000)sample*=2
        android.graphics.BitmapFactory.decodeFile(path,android.graphics.BitmapFactory.Options().apply{inSampleSize=sample;inPreferredConfig=android.graphics.Bitmap.Config.RGB_565})
    }.getOrNull()
}
