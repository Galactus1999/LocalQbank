package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.min
import kotlin.random.Random

/**
 * Portrait-first "Pulse -> Neural Network -> Rovex" launcher splash.
 *
 * Choreography follows the supplied reference video: a thin ECG/monitor trace wakes up,
 * hits a brilliant peak, explodes into amber particles, expands into a dense firing neural
 * network, then the network resolves around the handwritten Rovex wordmark and tagline.
 * Everything is procedurally drawn so the animation remains lightweight and sharp on OLED.
 * The layout is deliberately designed around a 9:16 portrait viewport while remaining adaptive
 * to other aspect ratios.
 */
class RovexSplashView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        // The reference clip is ~10 s; this keeps its choreography while avoiding an excessive
        // cold-launch wait. The final 1.1 s is a non-blocking visual hold/cross-fade window.
        const val DURATION_MS = 6500L
        private const val T_ECG_END = 0.28f
        private const val T_BURST_END = 0.36f
        private const val T_NETWORK_END = 0.73f
        private const val T_WORDMARK_START = 0.61f
        private const val T_WORDMARK_END = 0.83f
        private const val NODE_COUNT = 58
        private const val DUST_COUNT = 72
    }

    private val amber = intArrayOf(255, 178, 56)
    private val amberDim = intArrayOf(166, 100, 24)
    private val amberHot = intArrayOf(255, 226, 164)

    private val bgPaint = Paint().apply { color = Color.BLACK }
    private val ecgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isSubpixelText = true
    }
    private val taglinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isSubpixelText = true
    }

    private val ecgPath = Path()
    private val ecgMeasure = PathMeasure()
    private var ecgLength = 0f
    private var ecgBuilt = false
    private var originX = 0f
    private var originY = 0f
    private var hapticFired = false

    private var startTime = 0L
    private var running = false
    private var completionSent = false
    private var onFinished: (() -> Unit)? = null

    private val cursive: Typeface by lazy {
        runCatching { Typeface.createFromAsset(context.assets, "rovex_lobster_two.otf") }
            .getOrElse { Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    }

    private data class Node(
        val angle: Float,
        val radius: Float,
        val size: Float,
        val spawn: Float,
        val parent: Int
    )

    private data class Dust(
        val angle: Float,
        val radius: Float,
        val size: Float,
        val phase: Float,
        val speed: Float
    )

    private val nodes: List<Node> by lazy {
        val rnd = Random(1105)
        (0 until NODE_COUNT).map { i ->
            Node(
                angle = rnd.nextFloat() * (Math.PI.toFloat() * 2f),
                radius = 0.10f + rnd.nextFloat() * 0.90f,
                size = 1.0f + rnd.nextFloat() * 2.8f,
                spawn = (i.toFloat() / NODE_COUNT) * 0.48f,
                parent = if (i == 0) 0 else max(0, i - 1 - rnd.nextInt(4))
            )
        }
    }

    private val dust: List<Dust> by lazy {
        val rnd = Random(2407)
        (0 until DUST_COUNT).map {
            Dust(
                angle = rnd.nextFloat() * (Math.PI.toFloat() * 2f),
                radius = 0.35f + rnd.nextFloat() * 1.05f,
                size = 0.45f + rnd.nextFloat() * 1.8f,
                phase = rnd.nextFloat() * 6.28f,
                speed = 0.45f + rnd.nextFloat() * 1.1f
            )
        }
    }

    fun setOnFinished(listener: () -> Unit) { onFinished = listener }

    fun start() {
        if (running || completionSent) return
        startTime = SystemClock.uptimeMillis()
        running = true
        hapticFired = false
        invalidate()
    }

    fun skipToEnd() {
        if (completionSent) return
        running = false
        completionSent = true
        onFinished?.invoke()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        running = false
        onFinished = null
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        ecgBuilt = false
    }

    private fun buildEcgPath(w: Float, h: Float) {
        // Designed for portrait: the trace sits above the eventual wordmark/network centre.
        val y = h * 0.365f
        val left = w * 0.055f
        val right = w * 0.945f
        val span = right - left
        ecgPath.reset()
        ecgPath.moveTo(left, y)
        ecgPath.lineTo(left + span * 0.32f, y)
        ecgPath.lineTo(left + span * 0.365f, y + h * 0.009f)
        ecgPath.lineTo(left + span * 0.405f, y - h * 0.014f)
        ecgPath.lineTo(left + span * 0.455f, y + h * 0.075f)
        ecgPath.lineTo(left + span * 0.515f, y - h * 0.19f)
        ecgPath.lineTo(left + span * 0.555f, y + h * 0.045f)
        ecgPath.lineTo(left + span * 0.615f, y)
        ecgPath.lineTo(right, y)
        originX = left + span * 0.515f
        originY = y - h * 0.19f
        ecgMeasure.setPath(ecgPath, false)
        ecgLength = ecgMeasure.length
        ecgBuilt = true
    }

    private fun rgba(c: IntArray, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), c[0], c[1], c[2])

    private fun fireHaptic() {
        if (hapticFired) return
        hapticFired = true
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(18, 65))
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (!ecgBuilt) buildEcgPath(w, h)

        val elapsed = if (running) {
            (SystemClock.uptimeMillis() - startTime).coerceAtLeast(0L)
        } else {
            DURATION_MS
        }
        val t = (elapsed.toFloat() / DURATION_MS).coerceIn(0f, 1f)

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        drawDust(canvas, w, h, t)
        drawEcg(canvas, t)
        drawNetwork(canvas, w, h, t)
        drawWordmark(canvas, w * 0.5f, h, t)

        if (running) {
            if (elapsed >= DURATION_MS) {
                running = false
                if (!completionSent) {
                    completionSent = true
                    post { onFinished?.invoke() }
                }
            } else {
                postInvalidateOnAnimation()
            }
        }
    }

    private fun drawDust(canvas: Canvas, w: Float, h: Float, t: Float) {
        if (t < T_BURST_END * 0.65f) return
        val visibility = ((t - T_BURST_END * 0.65f) / 0.30f).coerceIn(0f, 1f)
        val cx = w * 0.5f
        val cy = h * 0.48f
        val radiusBase = min(w, h) * 0.29f
        for (p in dust) {
            val orbit = p.radius * radiusBase
            val a = p.angle + t * p.speed * 0.9f
            val x = cx + cos(a) * orbit
            val y = cy + sin(a) * orbit * 1.08f
            val twinkle = 0.45f + 0.55f * sin(t * 12f * p.speed + p.phase).coerceIn(-1f, 1f)
            val alpha = (70f * visibility * twinkle.coerceAtLeast(0.05f)).toInt()
            particlePaint.color = rgba(amberHot, alpha.coerceIn(0, 90))
            canvas.drawCircle(x, y, p.size, particlePaint)
        }
    }

    private fun drawEcg(canvas: Canvas, t: Float) {
        val sweep = (t / T_ECG_END).coerceIn(0f, 1f)
        if (sweep <= 0f) return
        val eased = 1f - (1f - sweep) * (1f - sweep)
        val segment = Path()
        ecgMeasure.getSegment(0f, ecgLength * eased, segment, true)
        val strokeWidth = if (height > this.width * 1.20f) {
            max(2.6f, this.width * 0.008f)
        } else 4.5f
        ecgPaint.strokeWidth = strokeWidth
        ecgPaint.color = rgba(amber, 245)
        ecgPaint.setShadowLayer(strokeWidth * 4.0f, 0f, 0f, rgba(amber, 150))
        canvas.drawPath(segment, ecgPaint)
        ecgPaint.clearShadowLayer()

        if (t in T_ECG_END - 0.055f..T_BURST_END) {
            if (sweep >= 0.985f) fireHaptic()
            val flash = ((t - (T_ECG_END - 0.055f)) / 0.12f).coerceIn(0f, 1f)
            val alpha = (250f * (1f - flash) * (1f - flash)).toInt()
            if (alpha > 3) {
                glowPaint.color = rgba(amberHot, alpha)
                glowPaint.setShadowLayer(26f, 0f, 0f, rgba(amber, alpha))
                canvas.drawCircle(originX, originY, 8f + min(this.width.toFloat(), height.toFloat()) * 0.018f * flash * 2f, glowPaint)
                glowPaint.clearShadowLayer()
                RovexPulseEffect.drawRadialFlash(
                    canvas, originX, originY,
                    12f + min(this.width.toFloat(), height.toFloat()) * 0.055f * flash,
                    alpha
                )
            }
        }
    }

    private fun drawNetwork(canvas: Canvas, w: Float, h: Float, t: Float) {
        if (t <= T_BURST_END) return
        val networkT = ((t - T_BURST_END) / (T_NETWORK_END - T_BURST_END)).coerceIn(0f, 1f)
        val settle = 1f - (1f - networkT) * (1f - networkT)
        val fadeIn = ((t - T_BURST_END) / 0.055f).coerceIn(0f, 1f)
        val cx = w * 0.5f
        val cy = h * 0.47f
        // Portrait composition: broad enough to feel like the reference web without hiding the logo.
        val maxR = min(w * 0.53f, h * 0.255f)
        val positions = FloatArray(nodes.size * 2)
        val active = BooleanArray(nodes.size)

        for ((i, n) in nodes.withIndex()) {
            val local = ((settle - n.spawn) / (1f - n.spawn)).coerceIn(0f, 1f)
            val ease = 1f - (1f - local) * (1f - local)
            val r = maxR * n.radius * ease
            val x = cx + cos(n.angle) * r
            val y = cy + sin(n.angle) * r
            positions[i * 2] = x
            positions[i * 2 + 1] = y
            active[i] = local > 0f

            if (i > 0 && local > 0f) {
                val p = nodes[n.parent]
                val pLocal = ((settle - p.spawn) / (1f - p.spawn)).coerceIn(0f, 1f)
                val pEase = 1f - (1f - pLocal) * (1f - pLocal)
                val pr = maxR * p.radius * pEase
                val px = cx + cos(p.angle) * pr
                val py = cy + sin(p.angle) * pr
                edgePaint.strokeWidth = if (h > w * 1.20f) 0.85f else 1.2f
                edgePaint.color = rgba(amberDim, (80f * local * fadeIn).toInt())
                edgePaint.setShadowLayer(4f, 0f, 0f, rgba(amber, 45))
                canvas.drawLine(x, y, px, py, edgePaint)
                edgePaint.clearShadowLayer()

                // Moving firing impulse, visually matching the reference video's live synapses.
                val fire = ((t * (0.95f + i * 0.006f) + i * 0.073f) % 1f)
                val fx = x + (px - x) * fire
                val fy = y + (py - y) * fire
                pulsePaint.color = rgba(amberHot, (190f * local * fadeIn).toInt())
                pulsePaint.setShadowLayer(5f, 0f, 0f, rgba(amber, 140))
                canvas.drawCircle(fx, fy, 1.15f + n.size * 0.18f, pulsePaint)
                pulsePaint.clearShadowLayer()
            }

            nodePaint.color = rgba(amber, (225f * local * fadeIn).toInt())
            nodePaint.setShadowLayer(6f, 0f, 0f, rgba(amber, 125))
            canvas.drawCircle(x, y, n.size * (0.45f + 0.55f * local), nodePaint)
            nodePaint.clearShadowLayer()
        }

        // Central firing core: the reference has several bright nodes that flare intermittently.
        if (t > T_NETWORK_END * 0.78f) {
            val flare = 0.5f + 0.5f * sin(t * 19f)
            glowPaint.color = rgba(amberHot, (115f * flare).toInt())
            glowPaint.setShadowLayer(22f, 0f, 0f, rgba(amber, 135))
            canvas.drawCircle(cx, cy, 3f + 3f * flare, glowPaint)
            glowPaint.clearShadowLayer()
        }
    }

    private fun drawWordmark(canvas: Canvas, cx: Float, h: Float, t: Float) {
        val wt = ((t - T_WORDMARK_START) / (T_WORDMARK_END - T_WORDMARK_START)).coerceIn(0f, 1f)
        if (wt <= 0f) return
        val ease = 1f - (1f - wt) * (1f - wt)
        // Lower centre leaves the neural field visible above and around the script, matching the reference.
        val y = h * 0.705f
        val scale = 0.72f + 0.28f * ease
        val breathe = if (t > T_WORDMARK_END) {
            RovexBreathing.factor(t - T_WORDMARK_END)
        } else 1f

        textPaint.typeface = cursive
        textPaint.textSize = min(wFromHeight(h) * 0.18f, h * 0.105f) * scale
        textPaint.color = rgba(amberHot, (255f * ease).toInt())
        textPaint.setShadowLayer(
            24f * breathe,
            0f,
            0f,
            rgba(amber, (175f * ease * breathe).toInt())
        )
        canvas.drawText("Rovex", cx, y, textPaint)
        textPaint.clearShadowLayer()

        val tagT = ((t - (T_WORDMARK_START + 0.10f)) / 0.25f).coerceIn(0f, 1f)
        if (tagT > 0f) {
            taglinePaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            taglinePaint.textSize = h * 0.018f
            taglinePaint.letterSpacing = 0.28f
            taglinePaint.color = rgba(amber, (180f * tagT).toInt())
            canvas.drawText(
                "PREPARE  ·  RECALL  ·  EXCEL",
                cx,
                y + h * 0.040f,
                taglinePaint
            )
        }
    }

    private fun wFromHeight(h: Float): Float = h * (9f / 16f)
}
