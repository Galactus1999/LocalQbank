package com.localqbank.library

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.app.NotificationManager

/** Optional, low-latency UI sound feedback. Disabled by default and silent outside normal audio mode. */
object RovexSoundFeedback {
    private const val PREFS = "ui"
    private const val KEY_ENABLED = "sound_feedback_enabled"
    private var pool: SoundPool? = null
    private var correctId = 0
    private var milestoneId = 0

    fun isEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (!enabled) release()
    }

    fun playCorrect(context: Context) = play(context, Cue.CORRECT)
    fun playMilestone(context: Context) = play(context, Cue.MILESTONE)

    private enum class Cue { CORRECT, MILESTONE }

    private fun play(context: Context, cue: Cue) {
        if (!isEnabled(context)) return
        val audio = context.getSystemService(AudioManager::class.java) ?: return
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val notifications = context.getSystemService(NotificationManager::class.java)
        if (notifications != null && android.os.Build.VERSION.SDK_INT >= 23 && notifications.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_NONE) return
        runCatching {
            ensurePool(context)
            val id = when (cue) { Cue.CORRECT -> correctId; Cue.MILESTONE -> milestoneId }
            if (id != 0) pool?.play(id, 0.42f, 0.42f, 1, 0, 1f)
        }
    }

    private fun ensurePool(context: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        pool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build().also { p ->
            correctId = p.load(context, R.raw.rover_correct, 1)
            milestoneId = p.load(context, R.raw.rover_milestone, 1)
        }
    }

    private fun release() { runCatching { pool?.release() }; pool = null; correctId = 0; milestoneId = 0 }
}
