package com.localqbank.library

import android.content.Context
import android.graphics.*
import kotlin.math.sqrt
import java.util.Random
import android.graphics.drawable.Drawable
import android.os.SystemClock
import kotlin.math.sin
import kotlin.math.cos

/**
 * Lightweight procedural atmosphere. It deliberately uses Canvas primitives rather than
 * bitmap/video assets so themes remain offline, small and memory-safe. Animation is paused
 * when the drawable is not visible and runs at a modest ~8 FPS while visible.
 */
class ThemeAtmosphereDrawable(private val context: Context) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stars = Array(96) { i -> Triple(((i * 47) % 101) / 100f, ((i * 71 + 11) % 101) / 100f, .5f + ((i * 17) % 10) / 10f) }
    private var phase = 0f
    private var visible = true
    private var planetBitmap: Bitmap? = null

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        when (ThemeManager.get(context)) {
            ThemeManager.PANDORA -> pandora(c, w, h)
            ThemeManager.SPACE -> space(c, w, h)
            ThemeManager.AMOLED -> dark(c, w, h)
            ThemeManager.MINT -> light(c, w, h, Color.rgb(229,255,248), Color.rgb(233,245,255), Color.rgb(91,220,192))
            ThemeManager.SUNSET -> light(c, w, h, Color.rgb(255,242,225), Color.rgb(255,229,239), Color.rgb(255,151,90))
            ThemeManager.LAVENDER -> light(c, w, h, Color.rgb(241,235,255), Color.rgb(225,242,255), Color.rgb(170,125,255))
            ThemeManager.PASTEL -> light(c, w, h, Color.rgb(228,241,255), Color.rgb(249,234,255), Color.rgb(121,169,255))
            else -> light(c, w, h, Color.rgb(239,246,255), Color.rgb(250,244,255), Color.rgb(112,155,255))
        }
        if (visible && (ThemeManager.get(context) == ThemeManager.PANDORA || ThemeManager.get(context) == ThemeManager.SPACE || ThemeManager.get(context) == ThemeManager.AMOLED)) {
            phase = (phase + .035f) % 100f
            scheduleSelf({ invalidateSelf() }, SystemClock.uptimeMillis() + 120L)
        }
    }

    private fun light(c: Canvas, w: Float, h: Float, a: Int, b: Int, glow: Int) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, a, b, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        val pts = arrayOf(floatArrayOf(w*.08f,h*.10f),floatArrayOf(w*.92f,h*.16f),floatArrayOf(w*.18f,h*.88f),floatArrayOf(w*.78f,h*.82f))
        pts.forEachIndexed { i, q ->
            p.shader = RadialGradient(q[0], q[1], minOf(w,h)*.42f,
                intArrayOf(Color.argb(70-i*8,Color.red(glow),Color.green(glow),Color.blue(glow)),Color.TRANSPARENT),
                floatArrayOf(0f,1f), Shader.TileMode.CLAMP)
            c.drawCircle(q[0],q[1],minOf(w,h)*.42f,p)
        }
        p.shader = null
    }

    private fun pandora(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f,0f,w,h,Color.rgb(2,18,22),Color.rgb(14,54,44),Shader.TileMode.CLAMP); c.drawRect(0f,0f,w,h,p)
        // Moonlit canopy + atmospheric depth.
        glow(c,w*.78f,h*.15f,minOf(w,h)*.34f,Color.rgb(108,255,218),95)
        glow(c,w*.18f,h*.42f,minOf(w,h)*.30f,Color.rgb(47,145,255),55)
        moon(c,w*.77f,h*.15f,minOf(w,h)*.09f)
        mountain(c,w,h,.59f,Color.rgb(7,31,31),.16f)
        mountain(c,w,h,.71f,Color.rgb(4,25,27),.20f)
        // Layered forest with varied crowns and bioluminescent plants.
        val base=h*.86f
        for (i in 0..25) {
            val x=(i/25f)*w + sin(phase*.11f+i)*w*.004f
            val treeH=h*(.075f + ((i*19)%13)/100f)
            tree(c,x,base,treeH,Color.rgb(5,40,34),Color.rgb(47,148,100))
        }
        for (i in 0..17) {
            val x=((i*53+11)%100)/100f*w
            val y=h*(.67f+((i*17)%22)/100f)
            glow(c,x,y,minOf(w,h)*.012f,Color.rgb(91,255,197),100)
            p.color=Color.rgb(55,210,150); c.drawCircle(x,y,minOf(w,h)*.005f,p)
        }
        // Wildlife silhouettes: distant deer on the forest floor and birds in flight.
        for(i in 0..2){
            val x=w*(.18f+i*.29f)+sin(phase*.08f+i)*w*.012f
            deer(c,x,base-h*.015f,minOf(w,h)*.035f)
        }
        for(i in 0..5){
            val x=((i*19+12)%92)/100f*w + sin(phase*.16f+i)*w*.018f
            val y=(.19f+i*.065f)*h + cos(phase*.12f+i)*h*.012f
            bird(c,x,y,minOf(w,h)*.018f)
        }
        // Fireflies create the living, slow-moving layer without bitmap/video assets.
        for(i in 0..26){
            val x=((i*37)%100)/100f*w + sin(phase*.32f+i)*w*.012f
            val y=((i*23+9)%72)/100f*h + cos(phase*.22f+i)*h*.010f
            glow(c,x,y,minOf(w,h)*.010f,Color.rgb(127,255,206),85)
        }
    }

    private fun space(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f,0f,w,h,Color.rgb(0,2,10),Color.rgb(6,8,30),Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p)
        // Broad procedural nebula bands.
        nebula(c,w*.62f,h*.30f,minOf(w,h)*.55f,Color.rgb(75,92,255),75)
        nebula(c,w*.18f,h*.73f,minOf(w,h)*.45f,Color.rgb(0,205,255),55)
        nebula(c,w*.48f,h*.55f,minOf(w,h)*.36f,Color.rgb(175,70,255),32)
        // Dense star field with subtle twinkle and a few brighter stars.
        stars.forEachIndexed { i,s ->
            val tw=.42f+.58f*((sin(phase*.50f+i*.71f)+1f)/2f)
            p.color=Color.argb((90+140*tw).toInt().coerceIn(0,255),190,220,255)
            c.drawCircle(s.first*w,s.second*h,s.third*(.35f+.28f*tw),p)
            if(i%17==0) starburst(c,s.first*w,s.second*h,minOf(w,h)*.008f,Color.WHITE,(80+100*tw).toInt())
        }
        // Original cached Earth-like planet texture: photo-like ocean/land/cloud detail
        // without shipping a large copyrighted bitmap or video. It is generated once and
        // reused for every animation frame.
        val r=minOf(w,h)*.19f; val px=w*.70f; val py=h*.66f
        planetBitmap()?.let { bmp ->
            val dst=RectF(px-r,py-r,px+r,py+r)
            c.drawBitmap(bmp,null,dst,p)
        }
        // Fine atmospheric rim and a subtle ring highlight.
        p.style=Paint.Style.STROKE;p.strokeWidth=r*.018f;p.color=Color.argb(145,155,215,255);c.drawCircle(px,py,r*1.01f,p);p.style=Paint.Style.FILL
        val mr=r*.045f; val mx=w*.31f; val my=h*.28f
        p.shader=RadialGradient(mx-mr*.3f,my-mr*.4f,mr,Color.WHITE,Color.rgb(80,100,170),Shader.TileMode.CLAMP);c.drawCircle(mx,my,mr,p);p.shader=null
        // Slow comet crossing the field.
        val t=(phase*.010f)%1f; val cx=(-.12f+t*1.30f)*w; val cy=(.12f+t*.30f)*h
        p.strokeWidth=minOf(w,h)*.007f;p.strokeCap=Paint.Cap.ROUND;p.color=Color.argb(125,170,225,255);c.drawLine(cx-w*.12f,cy-h*.055f,cx,cy,p);glow(c,cx,cy,minOf(w,h)*.016f,Color.WHITE,170)
    }

    private fun dark(c:Canvas,w:Float,h:Float){
        // AMOLED keeps the majority of the background at absolute black while retaining a
        // restrained cosmic layer so OLED power use remains materially lower than SPACE.
        p.style=Paint.Style.FILL;p.color=Color.BLACK;c.drawRect(0f,0f,w,h,p)
        nebula(c,w*.68f,h*.16f,minOf(w,h)*.50f,Color.rgb(28,72,255),28)
        nebula(c,w*.14f,h*.78f,minOf(w,h)*.34f,Color.rgb(0,175,255),22)
        stars.take(54).forEachIndexed{i,s->
            val tw=.45f+.55f*((sin(phase*.45f+i)+1f)/2f)
            p.color=Color.argb((70+120*tw).toInt(),180,215,255)
            c.drawCircle(s.first*w,s.second*h,s.third*.45f,p)
        }
        glow(c,w*.86f,h*.13f,minOf(w,h)*.055f,Color.rgb(55,196,255),80)
    }


    private fun planetBitmap(): Bitmap? {
        planetBitmap?.let { return it }
        val size=256
        val bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888)
        val px=IntArray(size*size)
        val rnd=Random(3181999L)
        val blobs=Array(18){floatArrayOf(rnd.nextFloat()*2f-1f,rnd.nextFloat()*2f-1f,.10f+rnd.nextFloat()*.32f)}
        for(y in 0 until size) for(x in 0 until size){
            val nx=(x/(size-1f))*2f-1f; val ny=(y/(size-1f))*2f-1f; val rr=nx*nx+ny*ny
            val idx=y*size+x
            if(rr>1f){px[idx]=Color.TRANSPARENT;continue}
            val z=sqrt((1f-rr).coerceAtLeast(0f));
            val light=(.32f + .68f*(.55f*nx+.35f*ny+.82f*z).coerceIn(0f,1f))
            var n=(sin(nx*8.7f+ny*3.1f)+sin(nx*17.3f-ny*9.4f)*.45f+sin(nx*31.1f+ny*18.7f)*.18f)
            var land=n>.55f
            blobs.forEach { b -> val dx=nx-b[0]; val dy=ny-b[1]; if(dx*dx+dy*dy < b[2]*b[2] && n>.05f) land=true }
            var r0=if(land) 84f else 22f; var g0=if(land) 86f else 104f; var b0=if(land) 68f else 150f
            val cloud=(sin(nx*21f+ny*13f)+sin(nx*39f-ny*17f)*.55f+sin(nx*67f+ny*29f)*.22f)/1.77f
            if(cloud>.58f){ r0=230f;g0=238f;b0=240f }
            val rim=(1f-z)*.55f
            val rrC=(r0*light + 105f*rim).toInt().coerceIn(0,255)
            val ggC=(g0*light + 185f*rim).toInt().coerceIn(0,255)
            val bbC=(b0*light + 255f*rim).toInt().coerceIn(0,255)
            val alpha=(255f*(.90f+.10f*z)).toInt().coerceIn(0,255)
            px[idx]=Color.argb(alpha,rrC,ggC,bbC)
        }
        bmp.setPixels(px,0,size,0,0,size,size)
        planetBitmap=bmp
        return bmp
    }

    private fun moon(c:Canvas,x:Float,y:Float,r:Float){
        p.style=Paint.Style.FILL
        p.shader=RadialGradient(x-r*.35f,y-r*.45f,r,Color.rgb(232,255,247),Color.rgb(70,132,125),Shader.TileMode.CLAMP)
        c.drawCircle(x,y,r,p);p.shader=null
        p.color=Color.argb(35,20,70,65)
        for(i in 0..5){ val cx=x+sin(i*2.1f)*r*.42f; val cy=y+cos(i*1.7f)*r*.42f; c.drawCircle(cx,cy,r*(.06f+.015f*i),p) }
    }
    private fun nebula(c:Canvas,x:Float,y:Float,r:Float,color:Int,alpha:Int){
        p.style=Paint.Style.FILL
        p.shader=RadialGradient(x-r*.18f,y-r*.12f,r,
            intArrayOf(Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color)),Color.argb(alpha/3,Color.red(color),Color.green(color),Color.blue(color)),Color.TRANSPARENT),
            floatArrayOf(0f,.42f,1f),Shader.TileMode.CLAMP)
        c.drawCircle(x,y,r,p);p.shader=null
    }
    private fun starburst(c:Canvas,x:Float,y:Float,r:Float,color:Int,alpha:Int){
        p.color=Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));p.strokeWidth=r*.55f; p.strokeCap=Paint.Cap.ROUND
        c.drawLine(x-r*2f,y,x+r*2f,y,p);c.drawLine(x,y-r*2f,x,y+r*2f,p)
    }
    private fun bird(c:Canvas,x:Float,y:Float,r:Float){
        p.style=Paint.Style.STROKE;p.strokeWidth=r*.30f;p.strokeCap=Paint.Cap.ROUND;p.color=Color.argb(205,5,21,25)
        val path=Path();path.moveTo(x-r*2f,y);path.quadTo(x-r*.8f,y-r*.9f,x,y);path.quadTo(x+r*.8f,y-r*.9f,x+r*2f,y);c.drawPath(path,p);p.style=Paint.Style.FILL
    }
    private fun deer(c:Canvas,x:Float,y:Float,r:Float){
        p.color=Color.argb(220,4,18,20)
        c.drawOval(x-r*1.7f,y-r*.75f,x+r*1.0f,y+r*.75f,p)
        c.drawOval(x+r*.65f,y-r*1.0f,x+r*1.55f,y-r*.15f,p)
        c.drawRect(x-r*1.05f,y+r*.55f,x-r*.78f,y+r*1.8f,p);c.drawRect(x+r*.35f,y+r*.55f,x+r*.62f,y+r*1.8f,p)
        p.style=Paint.Style.STROKE;p.strokeWidth=r*.16f;p.strokeCap=Paint.Cap.ROUND
        c.drawLine(x+r*1.25f,y-r*.75f,x+r*1.55f,y-r*1.55f,p);c.drawLine(x+r*1.55f,y-r*1.55f,x+r*1.75f,y-r*1.35f,p);c.drawLine(x+r*1.55f,y-r*1.55f,x+r*1.38f,y-r*1.25f,p);p.style=Paint.Style.FILL
    }

    private fun mountain(c:Canvas,w:Float,h:Float,base:Float,color:Int,offset:Float){
        val path=Path();path.moveTo(0f,h*base);for(i in 0..8){val x=w*i/8f;val y=h*(base-offset-(i%3)*.045f);path.lineTo(x,y)};path.lineTo(w,h);path.lineTo(0f,h);path.close();p.shader=null;p.color=color;c.drawPath(path,p)
    }
    private fun tree(c:Canvas,x:Float,base:Float,height:Float,trunk:Int,leaf:Int){
        p.color=trunk;c.drawRect(x-height*.07f,base-height*.38f,x+height*.07f,base,p)
        for(i in 0..4){val yy=base-height*(.42f+i*.12f);val rr=height*(.22f-.018f*i);p.color=if(i%2==0)leaf else Color.rgb(20,100,72);c.drawCircle(x+sin(i.toFloat())*height*.08f,yy,rr,p)}
    }
    private fun creature(c:Canvas,x:Float,y:Float,r:Float,color:Int){p.color=color;c.drawOval(x-r*2.0f,y-r*.35f,x,y+r*.35f,p);c.drawOval(x,y-r*.35f,x+r*2f,y+r*.35f,p);c.drawCircle(x,y,r*.28f,p)}
    private fun glow(c:Canvas,x:Float,y:Float,r:Float,color:Int,alpha:Int){p.style=Paint.Style.FILL;p.shader=RadialGradient(x-r*.25f,y-r*.3f,r,Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color)),Color.TRANSPARENT,Shader.TileMode.CLAMP);c.drawCircle(x,y,r,p);p.shader=null}

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean { this.visible=visible; if(visible&&restart)invalidateSelf(); return super.setVisible(visible,restart) }
    override fun setAlpha(a:Int){p.alpha=a}
    override fun setColorFilter(f:ColorFilter?){p.colorFilter=f}
    override fun getOpacity()=PixelFormat.TRANSLUCENT
}
