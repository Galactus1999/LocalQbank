package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

/** Notes-first revision screen: the saved note is the primary content; the original question is optional. */
class NotesActivity : Activity() {
    private lateinit var db: QBankDb
    private lateinit var list: LinearLayout
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        db=QBankDb(this)
        setContentView(build())
        render()
    }
    private fun build():ScrollView {
        val scroll=ScrollView(this).apply{setBackgroundColor(ThemeManager.bg(this@NotesActivity));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(24))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val back=TextView(this).apply{text="←";textSize=25f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@NotesActivity));background=rounded(ThemeManager.elevated(this@NotesActivity),16f);setOnClickListener{finish()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(52),dp(48)))
        bar.addView(TextView(this).apply{text="My Notes";textSize=24f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@NotesActivity));setPadding(dp(12),0,0,0)},LinearLayout.LayoutParams(0,dp(48),1f))
        root.addView(bar)
        root.addView(TextView(this).apply{text="Your saved text only. Tap View Question whenever you want the original MCQ.";textSize=13.5f;setTextColor(ThemeManager.muted(this@NotesActivity));setPadding(dp(4),dp(10),dp(4),dp(14))})
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(list)
        scroll.addView(root);return scroll
    }
    private fun rounded(fill:Int,r:Float)=GradientDrawable().apply{setColor(fill);cornerRadius=r}
    private fun render(){
        list.removeAllViews()
        val notes=db.notes()
        if(notes.isEmpty()){list.addView(TextView(this).apply{text="No notes saved yet.";textSize=16f;setTextColor(ThemeManager.muted(this@NotesActivity));setPadding(dp(8),dp(24),dp(8),dp(24))});return}
        notes.forEach{pair->
            val id=pair.first; val note=pair.second.orEmpty().trim()
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(12));background=rounded(if(ThemeManager.isDark(this@NotesActivity))ThemeManager.elevated(this@NotesActivity) else Color.WHITE,dp(16).toFloat())}
            card.addView(TextView(this).apply{text=note.ifBlank{"(Empty note)"};textSize=16.5f;setTextColor(ThemeManager.text(this@NotesActivity));setLineSpacing(0f,1.18f)})
            val q=runCatching{db.questionById(id)}.getOrNull()
            val actions=LinearLayout(this).apply{gravity=Gravity.END;setPadding(0,dp(10),0,0)}
            val view=TextView(this).apply{text="VIEW QUESTION";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=rounded(Color.rgb(35,103,120),dp(12).toFloat());setPadding(dp(16),0,dp(16),0);setOnClickListener{if(q!=null)startActivity(Intent(this@NotesActivity,QuizActivity::class.java).putExtra("questionId",id).putExtra("title","My Notes"))else Toast.makeText(this@NotesActivity,"Question no longer exists",Toast.LENGTH_SHORT).show()}}
            actions.addView(view,LinearLayout.LayoutParams(0,dp(40),1f))
            val del=TextView(this).apply{text="DELETE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.wrongText(this@NotesActivity));background=rounded(ThemeManager.wrongBg(this@NotesActivity),dp(12).toFloat());setPadding(dp(14),0,dp(14),0);setOnClickListener{AlertDialog.Builder(this@NotesActivity).setTitle("Delete note?").setMessage("This deletes the saved note for this question. The original question remains safe.").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->db.deleteNote(id);render()}.show()}}
            actions.addView(del,LinearLayout.LayoutParams(dp(88),dp(40)).apply{setMargins(dp(8),0,0,0)})
            card.addView(actions)
            list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
        }
    }
    override fun onResume(){super.onResume();if(::list.isInitialized)render()}
    override fun onDestroy(){db.close();super.onDestroy()}
}
