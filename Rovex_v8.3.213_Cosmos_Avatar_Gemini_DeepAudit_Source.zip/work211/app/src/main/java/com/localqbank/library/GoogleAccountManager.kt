package com.localqbank.library

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Google-account authentication for Gemini access. */
class GoogleAccountManager(private val activity: Activity) {
    private val context: Context get() = activity.applicationContext
    private val credentials by lazy { CredentialManager.create(activity) }

    fun auth(): FirebaseAuth? = runCatching {
        if (FirebaseAppAvailability.ensureInitialized(context) != null) FirebaseAuth.getInstance() else null
    }.getOrNull()

    fun currentEmail(): String? = auth()?.currentUser?.email

    suspend fun signIn(): Result<String> = withContext(Dispatchers.Main) {
        val firebaseAuth = auth() ?: return@withContext Result.failure(
            IllegalStateException("Firebase is not configured. Add google-services.json and enable Google sign-in.")
        )
        val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        val webClientId = id.takeIf { it != 0 }?.let(context::getString)?.trim().orEmpty()
        if (webClientId.isBlank()) return@withContext Result.failure(
            IllegalStateException("Missing default_web_client_id. Configure Firebase Google sign-in.")
        )
        val option = GetGoogleIdOption.Builder()
            .setServerClientId(webClientId)
            .setFilterByAuthorizedAccounts(false)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        try {
            val result = credentials.getCredential(activity, request)
            val credential = result.credential
            if (credential !is CustomCredential || credential.type != TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                return@withContext Result.failure(IllegalStateException("Selected credential was not a Google ID credential."))
            }
            val google = try { GoogleIdTokenCredential.createFrom(credential.data) }
            catch (e: GoogleIdTokenParsingException) { return@withContext Result.failure(e) }
            val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
            val signedIn = firebaseAuth.signInWithCredential(firebaseCredential).awaitTask()
            Result.success(signedIn.user?.email ?: "Google account")
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    suspend fun signOut() = withContext(Dispatchers.Main) {
        auth()?.signOut()
        runCatching { credentials.clearCredentialState(ClearCredentialStateRequest()) }
    }
}

private suspend fun <T> com.google.android.gms.tasks.Task<T>.awaitTask(): T =
    suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
        addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
        addOnCanceledListener { continuation.cancel() }
    }
