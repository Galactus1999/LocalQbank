package com.localqbank.library

import android.content.Context
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.Tool
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Cloud research collaborator. Local Ben remains authoritative for local retrieval and study state. */
class BenGeminiCoordinator(context: Context) {
    data class Source(val title: String, val uri: String)
    data class Result(val answer: String, val sources: List<Source>, val grounded: Boolean, val signedInEmail: String?, val searchEntryPointHtml: String? = null)
    private val app = context.applicationContext

    fun auth(): FirebaseAuth? = runCatching {
        if (FirebaseAppAvailability.ensureInitialized(app) != null) FirebaseAuth.getInstance() else null
    }.getOrNull()

    suspend fun research(query: String): Result = withContext(Dispatchers.IO) {
        val clean = BenResearchInputPolicy.normalize(query)
            ?: return@withContext Result("Give Ben a concrete research question.", emptyList(), false, auth()?.currentUser?.email)
        val firebaseAuth = auth()
            ?: return@withContext Result("Gemini is not configured. Add Firebase configuration and enable Google sign-in.", emptyList(), false, null)
        val user = firebaseAuth.currentUser
            ?: return@withContext Result("Sign in with your Google account before using Gemini web research.", emptyList(), false, null)

        val local = runCatching { AppManagers.renCognitive.answer(clean) }.getOrNull()
        val localContext = buildString {
            append("Ben local context. Supporting context only; it is not current web evidence.\n")
            if (local != null) {
                append("Local intent: ").append(local.plan.intent ?: "general").append('\n')
                append("Local concepts: ").append(local.plan.concepts.joinToString(", ")).append('\n')
                append("Local confidence: ").append(local.confidence).append("/100\n")
                append("Local answer: ").append(local.answer.take(3500)).append('\n')
            }
        }
        val model = Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = MODEL,
            tools = listOf(Tool.googleSearch())
        )
        val prompt = """
You are Gemini, the web-research collaborator inside Ben (Dr. Frankenstein).
The user explicitly requested current web research.
Use Google Search when current or externally verifiable information matters. Prefer primary/official sources,
major medical organizations, peer-reviewed literature, and authoritative guidelines. Distinguish established
facts from uncertainty and conflicting evidence. Do not blindly accept Ben's local context. Return a concise,
source-grounded synthesis that Ben can verify and present.

$localContext
RESEARCH QUESTION:
$clean
""".trimIndent()
        val response = model.generateContent(prompt)
        val text = response.text?.trim().orEmpty().ifBlank { "Gemini returned no textual result." }
        val metadata = response.candidates.firstOrNull()?.groundingMetadata
        val sources = metadata?.groundingChunks.orEmpty().mapNotNull { chunk ->
            val web = chunk.web ?: return@mapNotNull null
            val uri = web.uri?.trim().orEmpty()
            val title = web.title?.trim().orEmpty().ifBlank { uri }
            if (uri.isBlank()) null else Source(title, uri)
        }.distinctBy { it.uri }.take(12)
        Result(text, sources, sources.isNotEmpty(), user.email, metadata?.searchEntryPoint?.renderedContent)
    }

    companion object { const val MODEL = "gemini-3.8-flash" }
}

object FirebaseAppAvailability {
    fun isConfigured(context: Context): Boolean = ensureInitialized(context) != null

    fun ensureInitialized(context: Context): com.google.firebase.FirebaseApp? = runCatching {
        val existing = com.google.firebase.FirebaseApp.getApps(context).firstOrNull()
        if (existing != null) return@runCatching existing
        val app = com.google.firebase.FirebaseApp.initializeApp(context) ?: return@runCatching null
        if (com.localqbank.library.BuildConfig.DEBUG) {
            com.google.firebase.Firebase.appCheck.installAppCheckProviderFactory(
                com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory.getInstance()
            )
        } else {
            com.google.firebase.Firebase.appCheck.installAppCheckProviderFactory(
                com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory.getInstance()
            )
        }
        app
    }.getOrNull()
}
