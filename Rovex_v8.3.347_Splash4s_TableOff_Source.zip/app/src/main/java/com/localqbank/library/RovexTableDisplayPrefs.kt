package com.localqbank.library

import android.content.Context

/** User-facing AI chat presentation preference. Tables remain structurally supported. */
object RovexTableDisplayPrefs {
    private const val PREFS = "chat_ui"
    private const val KEY_SHOW_TABLES = "show_tables_in_chat"

    fun showTables(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SHOW_TABLES, false)

    fun setShowTables(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SHOW_TABLES, enabled).apply()
    }
}
