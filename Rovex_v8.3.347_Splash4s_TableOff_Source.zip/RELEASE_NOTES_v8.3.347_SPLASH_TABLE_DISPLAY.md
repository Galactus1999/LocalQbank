# Rovex v8.3.347 — Splash + AI Chat Table Display

- Reduced custom splash duration to exactly 4.0 seconds.
- Reworked splash particle, neural-network, pulse, and wordmark accents into a brighter multi-colour spectrum (gold/cyan/violet/magenta/coral) with stronger glow and spark visibility.
- Added persistent **AI Chat Display → Show tables in AI chat**, OFF by default.
- AI + Search and Frankenstein chat render genuine Markdown tables as readable per-item sections when the setting is OFF.
- Enabling the setting restores genuine scrollable Markdown table rendering.
- Notes rendering remains unchanged so saved tables are not flattened.
- Existing Markdown table parser remains authoritative; no duplicate renderer added.
