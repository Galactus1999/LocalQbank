package com.localqbank.library

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable

/** Rovex visual system: semantic tokens shared by every Activity and surface. */
object ThemeManager {
    const val LIGHT="light"
    const val PASTEL="pastel"
    const val MINT="mint"
    const val SUNSET="sunset"
    const val LAVENDER="lavender"
    const val AMOLED="amoled"
    const val CYBER="cyber"
    const val OCEAN="ocean"
    const val NEBULA="nebula"

    data class Preset(val key:String,val name:String,val description:String,val dark:Boolean,val c1:Int,val c2:Int,val accent:Int,val accent2:Int,val text:Int,val muted:Int)

    private const val PREF="ui"; private const val KEY="theme"
    val presets=listOf(
        Preset(LIGHT,"Clinical Light","Clean daylight • high-clarity reading",false,0xFFF7FAFF.toInt(),0xFFFFFFFF.toInt(),0xFF1F6FEB.toInt(),0xFF00AFA0.toInt(),0xFF14233D.toInt(),0xFF52657D.toInt()),
        Preset(PASTEL,"Aurora Pastel","Soft spectrum • calm study surfaces",false,0xFFEAF2FF.toInt(),0xFFFFF0FB.toInt(),0xFF5C63E8.toInt(),0xFFEC6BAA.toInt(),0xFF17233F.toInt(),0xFF596982.toInt()),
        Preset(MINT,"Bio Mint","Clinical mint • fresh concentration",false,0xFFE7FFF7.toInt(),0xFFE8F4FF.toInt(),0xFF00A98F.toInt(),0xFF238BFF.toInt(),0xFF12353A.toInt(),0xFF527277.toInt()),
        Preset(SUNSET,"Solar Coral","Warm coral • amber energy",false,0xFFFFF0DF.toInt(),0xFFFFE8F0.toInt(),0xFFFF7043.toInt(),0xFFFFB52E.toInt(),0xFF39222B.toInt(),0xFF775C66.toInt()),
        Preset(LAVENDER,"Iris Violet","Violet • electric blue focus",false,0xFFF1ECFF.toInt(),0xFFE6F0FF.toInt(),0xFF7C4DFF.toInt(),0xFF00A6FF.toInt(),0xFF24203C.toInt(),0xFF625E79.toInt()),
        Preset(AMOLED,"AMOLED","True black • luminous medical neon",true,0xFF000000.toInt(),0xFF050914.toInt(),0xFF39D9FF.toInt(),0xFF8B5CFF.toInt(),0xFFF3F7FF.toInt(),0xFF9EB3CC.toInt()),
        Preset(CYBER,"Cyber Pulse","Black glass • cyan / magenta energy",true,0xFF02050D.toInt(),0xFF0A0616.toInt(),0xFF00F0FF.toInt(),0xFFFF3DBB.toInt(),0xFFF6FBFF.toInt(),0xFFA2B5D1.toInt()),
        Preset(OCEAN,"Deep Ocean","Midnight blue • bioluminescent cyan",true,0xFF02111B.toInt(),0xFF061B2B.toInt(),0xFF27D7FF.toInt(),0xFF39E6B0.toInt(),0xFFF1FBFF.toInt(),0xFF9BB9CA.toInt()),
        Preset(NEBULA,"Nebula","Cosmic violet • blue stellar glow",true,0xFF05020E.toInt(),0xFF12052A.toInt(),0xFFB56CFF.toInt(),0xFF42A5FF.toInt(),0xFFF8F3FF.toInt(),0xFFB6A9D2.toInt())
    )
    private fun preset(c:Context)=presets.firstOrNull{it.key==normalize(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,LIGHT))}?:presets.first()
    private fun normalize(raw:String?):String=when(raw){LIGHT,PASTEL,MINT,SUNSET,LAVENDER,AMOLED,CYBER,OCEAN,NEBULA->raw!!;"amoled_dark","dark","obsidian_dark"->AMOLED;"sepia"->SUNSET;"midnight_blue"->OCEAN;"cosmos","cosmos_galaxy"->NEBULA;"avatar","pandora_avatar"->CYBER;else->LIGHT}
    fun get(c:Context):String=normalize(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,LIGHT))
    fun set(c:Context,v:String){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,normalize(v)).apply()}
    fun isDark(c:Context)=preset(c).dark
    fun bg(c:Context)=preset(c).c1
    fun panel(c:Context)=if(isDark(c))blend(preset(c).c1,preset(c).c2,.35f) else blend(preset(c).c1,preset(c).c2,.62f)
    fun elevated(c:Context)=if(isDark(c))blend(preset(c).c1,preset(c).c2,.62f) else blend(preset(c).c2,Color.WHITE,.38f)
    fun text(c:Context)=preset(c).text
    fun muted(c:Context)=preset(c).muted
    fun accent(c:Context)=preset(c).accent
    fun accent2(c:Context)=preset(c).accent2
    fun aiText(c:Context)=if(isDark(c))preset(c).accent else Color.rgb(73,63,180)
    fun questionText(c:Context)=text(c); fun explanationText(c:Context)=text(c)
    fun optionBg(c:Context)=if(isDark(c)) preset(c).c2 else Color.rgb(246,249,255)
    fun optionText(c:Context)=text(c)
    fun correctBg(c:Context)=if(isDark(c))Color.rgb(4,66,53) else Color.rgb(225,250,239)
    fun correctText(c:Context)=if(isDark(c))Color.rgb(83,255,191) else Color.rgb(0,119,78)
    fun wrongBg(c:Context)=if(isDark(c))Color.rgb(68,13,34) else Color.rgb(255,232,238)
    fun wrongText(c:Context)=if(isDark(c))Color.rgb(255,111,161) else Color.rgb(172,36,78)
    fun explanationBg(c:Context)=if(isDark(c))blend(preset(c).c1,preset(c).c2,.75f) else Color.rgb(241,247,255)
    fun explanationTitle(c:Context)=accent2(c)
    fun dialogBg(c:Context)=if(isDark(c))blend(preset(c).c1,preset(c).c2,.55f) else blend(preset(c).c1,preset(c).c2,.78f)
    fun dialogText(c:Context)=text(c); fun dialogMuted(c:Context)=muted(c)
    fun peacockFill(c:Context)=blend(preset(c).accent,preset(c).c2,if(isDark(c)) .20f else .88f)
    fun peacockText(c:Context)=if(isDark(c))Color.WHITE else darken(preset(c).accent,.48f)
    fun statsFill(c:Context)=if(isDark(c))blend(preset(c).accent2,preset(c).c1,.18f) else blend(preset(c).accent2,Color.WHITE,.88f)
    fun statsText(c:Context)=if(isDark(c))Color.WHITE else darken(preset(c).accent2,.55f)
    fun resultBg(c:Context)=correctBg(c)
    fun bookmarkFill(c:Context,type:String):Int=if(isDark(c))blend(preset(c).accent,preset(c).c1,.18f) else when(type.lowercase()){"important"->Color.rgb(255,242,196);"revise"->Color.rgb(225,239,255);"favorite","favourite"->Color.rgb(255,229,239);else->Color.rgb(238,243,250)}
    fun bookmarkText(c:Context,type:String)=if(isDark(c))preset(c).accent2 else Color.rgb(50,67,100)
    fun pastelBlueFill(c:Context)=blend(preset(c).accent,Color.WHITE,if(isDark(c)) .20f else .88f)
    fun pastelBlueText(c:Context)=if(isDark(c))Color.WHITE else darken(preset(c).accent,.55f)
    fun pastelPinkFill(c:Context)=blend(preset(c).accent2,Color.WHITE,if(isDark(c)) .20f else .88f)
    fun pastelPinkText(c:Context)=if(isDark(c))Color.WHITE else darken(preset(c).accent2,.55f)
    fun pastelRedFill(c:Context)=blend(Color.rgb(255,92,120),Color.WHITE,if(isDark(c)) .18f else .88f)
    fun pastelRedText(c:Context)=if(isDark(c))Color.rgb(255,150,175) else Color.rgb(171,64,80)
    fun pastelYellowFill(c:Context)=blend(Color.rgb(255,190,45),Color.WHITE,if(isDark(c)) .18f else .88f)
    fun pastelYellowText(c:Context)=if(isDark(c))Color.rgb(255,220,110) else Color.rgb(130,91,0)
    fun pastelLavenderFill(c:Context)=blend(preset(c).accent2,Color.WHITE,if(isDark(c)) .16f else .86f)
    fun pastelLavenderText(c:Context)=if(isDark(c))Color.WHITE else darken(preset(c).accent2,.55f)
    fun pastelAccentFill(c:Context,index:Int)=when(index%4){0->pastelBlueFill(c);1->pastelPinkFill(c);2->pastelYellowFill(c);else->pastelLavenderFill(c)}
    fun pastelAccentText(c:Context,index:Int)=when(index%4){0->pastelBlueText(c);1->pastelPinkText(c);2->pastelYellowText(c);else->pastelLavenderText(c)}
    fun transparentSectionDrawable(c:Context):Drawable=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.argb(if(isDark(c))90 else 35,Color.red(accent(c)),Color.green(accent(c)),Color.blue(accent(c))),Color.TRANSPARENT)).apply{setStroke((c.resources.displayMetrics.density).toInt().coerceAtLeast(1),Color.argb(if(isDark(c))150 else 80,Color.red(accent(c)),Color.green(accent(c)),Color.blue(accent(c))));cornerRadius=24f*c.resources.displayMetrics.density}
    fun backgroundDrawable(c:Context):Drawable=ThemeAtmosphereDrawable(c)
    private fun blend(a:Int,b:Int,t:Float)=Color.rgb((Color.red(a)*(1-t)+Color.red(b)*t).toInt(),(Color.green(a)*(1-t)+Color.green(b)*t).toInt(),(Color.blue(a)*(1-t)+Color.blue(b)*t).toInt())
    private fun darken(a:Int,f:Float)=Color.rgb((Color.red(a)*f).toInt(),(Color.green(a)*f).toInt(),(Color.blue(a)*f).toInt())
}
