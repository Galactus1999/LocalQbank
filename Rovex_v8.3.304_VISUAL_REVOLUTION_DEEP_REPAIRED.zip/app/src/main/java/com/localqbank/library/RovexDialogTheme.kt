package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Applies the active Rovex visual tokens to transient UI that lives in its own Window. */
object RovexDialogTheme {
    private fun dp(v:Int, view:View)= (v*view.resources.displayMetrics.density).toInt().coerceAtLeast(1)
    private fun stroke(c:Int, alpha:Int):Int=Color.argb(alpha,Color.red(c),Color.green(c),Color.blue(c))
    private fun surface(v:View, top:Int, bottom:Int, radius:Int=20):GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(top,bottom)).apply {
            cornerRadius=dp(radius,v).toFloat();setStroke(dp(1,v),stroke(ThemeManager.accent(v.context),if(ThemeManager.isDark(v.context))150 else 85))
        }

    fun apply(dialog: Dialog) {
        val w=dialog.window ?: return
        runCatching {
            w.setBackgroundDrawableResource(android.R.color.transparent)
            w.setDimAmount(if(ThemeManager.isDark(dialog.context)) .70f else .42f)
        }
        val decor=w.decorView
        decor.setBackgroundColor(Color.TRANSPARENT)
        walk(decor)
        if(dialog is AlertDialog) styleAlertButtons(dialog)
        decor.post {
            if(dialog.isShowing) {
                val maxW=(dialog.context.resources.displayMetrics.widthPixels*.94f).toInt()
                runCatching { w.setLayout(maxW,WindowManagerLayout.WRAP) }
            }
        }
    }

    private fun walk(v:View) {
        val c=v.context
        when(v) {
            is Button -> {
                v.background=surface(v,ThemeManager.peacockFill(c),ThemeManager.statsFill(c),18)
                v.setTextColor(ThemeManager.peacockText(c));v.stateListAnimator=null
                v.minHeight=dp(44,v);v.isAllCaps=false
            }
            is ImageButton -> {
                v.background=surface(v,ThemeManager.elevated(c),ThemeManager.peacockFill(c),16)
                v.elevation=dp(3,v).toFloat()
            }
            is EditText -> {
                v.background=surface(v,ThemeManager.elevated(c),ThemeManager.panel(c),16)
                v.setTextColor(ThemeManager.text(c));v.setHintTextColor(ThemeManager.muted(c))
                v.backgroundTintList=ColorStateList.valueOf(ThemeManager.accent(c))
            }
            is CheckBox, is RadioButton, is Switch -> {
                if(v is CompoundButton) {
                    v.setTextColor(ThemeManager.text(c))
                    v.buttonTintList=ColorStateList.valueOf(ThemeManager.accent(c))
                }
            }
            is TextView -> {
                if(!v.isClickable || v.background==null) v.setTextColor(ThemeManager.text(c))
                if(v.textSize>=16f) v.typeface=Typeface.create(v.typeface,Typeface.BOLD)
                if(v.isClickable && v.background==null) {
                    v.background=surface(v,ThemeManager.peacockFill(c),ThemeManager.statsFill(c),14)
                    v.setTextColor(ThemeManager.peacockText(c));v.setPadding(dp(10,v),dp(7,v),dp(10,v),dp(7,v))
                }
            }
        }
        if(v.isClickable && v.foreground==null){val ac=ThemeManager.accent(c);v.foreground=RippleDrawable(ColorStateList.valueOf(Color.argb(if(ThemeManager.isDark(c))70 else 35,Color.red(ac),Color.green(ac),Color.blue(ac))),null,null)}
        if(v is ViewGroup) for(i in 0 until v.childCount) walk(v.getChildAt(i))
    }

    private fun styleAlert(d:AlertDialog){ styleAlertButtons(d) }

    fun styleShown(dialog:Dialog){ apply(dialog); if(dialog is AlertDialog) dialog.setOnShowListener { styleAlert(dialog); styleAlertButtons(dialog) } }
    private fun styleAlertButtons(d:AlertDialog){
        d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(ThemeManager.peacockText(d.context))
        d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ThemeManager.text(d.context))
        d.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(ThemeManager.accent(d.context))
    }
    private object WindowManagerLayout { const val WRAP=-2 }

}

fun AlertDialog.Builder.rovexShow(): AlertDialog {
    val d=create(); d.show(); RovexDialogTheme.apply(d); return d
}
