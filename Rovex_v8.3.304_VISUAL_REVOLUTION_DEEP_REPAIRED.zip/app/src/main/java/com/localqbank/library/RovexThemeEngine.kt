package com.localqbank.library

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

/** App-wide visual pass: rounded 3D surfaces, semantic typography and adaptive accents. */
object RovexThemeEngine{
    private fun dp(v:Int,x:View)=(v*x.resources.displayMetrics.density).toInt().coerceAtLeast(1)
    private fun surface(x:View,top:Int,bottom:Int,stroke:Int,r:Int=20)=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(top,bottom)).apply{cornerRadius=dp(r,x).toFloat();setStroke(dp(1,x),stroke)}
    fun apply(a:Activity){
        val root=a.window.decorView.findViewById<ViewGroup>(android.R.id.content)?:return
        root.background=ThemeManager.backgroundDrawable(a)
        runCatching{WindowCompat.setDecorFitsSystemWindows(a.window,false);a.window.statusBarColor=Color.TRANSPARENT;a.window.navigationBarColor=Color.TRANSPARENT;WindowInsetsControllerCompat(a.window,a.window.decorView).isAppearanceLightStatusBars=!ThemeManager.isDark(a);WindowInsetsControllerCompat(a.window,a.window.decorView).isAppearanceLightNavigationBars=!ThemeManager.isDark(a)}
        walk(root,a,0)
    }
    private fun walk(v:View,a:Activity,depth:Int){if(v.tag=="rovexThemeSkip")return;if((v.tag as? String)?.startsWith("quiz:")==true)return;when(v){is Button->button(v,a);is ImageButton->imageButton(v,a);is EditText->edit(v,a);is ProgressBar->{v.progressTintList=ColorStateList.valueOf(ThemeManager.accent(a));v.progressBackgroundTintList=ColorStateList.valueOf(Color.argb(if(ThemeManager.isDark(a))80 else 35,Color.red(ThemeManager.accent(a)),Color.green(ThemeManager.accent(a)),Color.blue(ThemeManager.accent(a))))};is ImageView->image(v,a);is CompoundButton->compound(v,a);is TextView->text(v,a);is ViewGroup->group(v,a,depth)};if(v.isClickable && v.foreground==null){val a1=Color.argb(if(ThemeManager.isDark(a))70 else 35,Color.red(ThemeManager.accent(a)),Color.green(ThemeManager.accent(a)),Color.blue(ThemeManager.accent(a)));v.foreground=RippleDrawable(ColorStateList.valueOf(a1),null,null)};if(v is ViewGroup)for(i in 0 until v.childCount)walk(v.getChildAt(i),a,depth+1)}
    private fun group(v:ViewGroup,a:Activity,depth:Int){
        if(depth==0){v.background=ThemeManager.backgroundDrawable(a);return}
        val id=runCatching{v.resources.getResourceEntryName(v.id).lowercase()}.getOrDefault("")
        val cn=v.javaClass.name.lowercase()
        val semantic=id.contains("card")||id.contains("panel")||id.contains("sheet")||id.contains("dialog")||id.contains("hero")||id.contains("nav")||id.contains("pill")||id.contains("toolbar")||id.contains("search")||id.contains("section")||id.contains("header")||cn.contains("cardview")||cn.contains("bottomsheet")
        if(semantic && !id.contains("scroll") && !id.contains("list")){
            val ac=ThemeManager.accent(a); val ac2=ThemeManager.accent2(a)
            val top=if(id.contains("nav")||id.contains("hero"))ThemeManager.peacockFill(a) else ThemeManager.elevated(a)
            val bottom=if(id.contains("hero")||id.contains("nav"))ThemeManager.statsFill(a) else ThemeManager.panel(a)
            val stroke=Color.argb(if(ThemeManager.isDark(a))180 else 95,Color.red(if(id.contains("hero"))ac2 else ac),Color.green(if(id.contains("hero"))ac2 else ac),Color.blue(if(id.contains("hero"))ac2 else ac))
            v.background=surface(v,top,bottom,stroke,if(id.contains("nav")||id.contains("pill"))28 else 22)
            v.elevation=dp(if(id.contains("nav")||id.contains("hero"))9 else 4,v).toFloat();v.clipToOutline=true
        }
    }

    private fun compound(v:CompoundButton,a:Activity){
        v.setTextColor(ThemeManager.text(a));v.buttonTintList=ColorStateList.valueOf(ThemeManager.accent(a))
        if(v is Switch){v.thumbTintList=ColorStateList.valueOf(ThemeManager.text(a));v.trackTintList=ColorStateList.valueOf(ColorStateList.valueOf(ThemeManager.accent(a)).defaultColor)}
    }
    private fun image(v:ImageView,a:Activity){
        val id=runCatching{v.resources.getResourceEntryName(v.id).lowercase()}.getOrDefault("")
        if(id.contains("icon")||id.contains("avatar")||id.contains("hero")||id.contains("medical")||id.contains("cube")){
            val ac=ThemeManager.accent(a)
            v.background=surface(v,ThemeManager.elevated(a),ThemeManager.peacockFill(a),Color.argb(100,Color.red(ac),Color.green(ac),Color.blue(ac)),18)
            v.elevation=dp(4,v).toFloat();v.clipToOutline=true
        }
    }
    private fun text(v:TextView,a:Activity){val id=runCatching{v.resources.getResourceEntryName(v.id).lowercase()}.getOrDefault("");val color=when{ id.contains("ai")||id.contains("ben")||id.contains("franken")->ThemeManager.aiText(a);id.contains("hint")||id.contains("sub")||id.contains("muted")->ThemeManager.muted(a);else->ThemeManager.text(a)};if(!v.isClickable || v.background==null)v.setTextColor(color);if(v.textSize>=16f)v.typeface=Typeface.create(v.typeface,Typeface.BOLD);if(v.isClickable && v.background==null && v !is Button){val ac=ThemeManager.accent(a);v.background=surface(v,ThemeManager.peacockFill(a),ThemeManager.statsFill(a),14);v.setTextColor(ThemeManager.peacockText(a));v.setPadding(dp(10,v),dp(7,v),dp(10,v),dp(7,v));v.elevation=dp(2,v).toFloat()}}
    private fun button(v:Button,a:Activity){val ac=ThemeManager.accent(a);v.background=surface(v,ThemeManager.peacockFill(a),ThemeManager.statsFill(a),Color.argb(175,Color.red(ac),Color.green(ac),Color.blue(ac)),20);v.setTextColor(ThemeManager.peacockText(a));v.stateListAnimator=null;v.elevation=dp(6,v).toFloat();v.minHeight=dp(46,v);v.isAllCaps=false;v.setPadding(dp(15,v),dp(8,v),dp(15,v),dp(8,v));v.letterSpacing=.015f}
    private fun imageButton(v:ImageButton,a:Activity){val ac=ThemeManager.accent(a);v.background=surface(v,ThemeManager.elevated(a),ThemeManager.peacockFill(a),Color.argb(120,Color.red(ac),Color.green(ac),Color.blue(ac)),18);v.elevation=dp(5,v).toFloat()}
    private fun edit(v:EditText,a:Activity){val ac=ThemeManager.accent(a);v.background=surface(v,ThemeManager.elevated(a),ThemeManager.panel(a),Color.argb(80,Color.red(ac),Color.green(ac),Color.blue(ac)),18);v.setTextColor(ThemeManager.text(a));v.setHintTextColor(ThemeManager.muted(a));v.setPadding(dp(15,v),v.paddingTop,dp(15,v),v.paddingBottom);v.elevation=dp(2,v).toFloat()}
}