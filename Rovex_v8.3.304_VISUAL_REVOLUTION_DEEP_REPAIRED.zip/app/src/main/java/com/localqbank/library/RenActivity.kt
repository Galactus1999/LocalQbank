package com.localqbank.library
import android.app.AlertDialog

import android.app.Activity
import android.content.Intent
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Chat-first Dr. Frankenstein workspace. Ben retrieves bounded context; Free AI is the answerer in combined mode. */
class RenActivity : AppCompatActivity() {
    private var openMatchButton: TextView? = null
    private var liveStatus: TextView? = null
    private val liveScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var requestGeneration = 0L
    private var liveJob: Job? = null
    private var cloudJob: Job? = null
    private var promptInput: EditText? = null
    private var chatWeb: WebView? = null
    private val chatState:RenChatViewModel by viewModels()
    private val chatTurns:MutableList<Pair<String,String>> get()=chatState.turns
    private companion object {
        const val MAX_UI_CHAT_TURNS = 20
        const val MAX_UI_MESSAGE_CHARS = 20_000
    }
    private var lastBenReply: String
        get() = chatState.lastBenReply
        set(value) { chatState.lastBenReply = value }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        android.util.Log.i("Rovex.Frankenstein", "REN_POLICY=${BenResponsePolicy.POLICY_REVISION}; APP=${BuildConfig.VERSION_NAME}; CODE=${BuildConfig.VERSION_CODE}")
        runCatching { AppManagers.initialize(applicationContext) }
        SystemUi.immersive(this)
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(build())
        promptInput?.setText(chatState.prompt)
        promptInput?.setSelection(promptInput?.text?.length?:0)
    }

    private fun isLandscape()=resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE
    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(10))
            background = ThemeManager.backgroundDrawable(this@RenActivity)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text="‹"; textSize=30f; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity))
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(40),dp(42)))
        header.addView(Space(this), LinearLayout.LayoutParams(0,1,1f))
        fun headerButton(label:String, width:Int, click:()->Unit)=TextView(this).apply {
            text=label; textSize=10f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity))
            background=UiDrawableUtils.roundedDrawable(this@RenActivity,ThemeManager.elevated(this@RenActivity),10f)
            setPadding(dp(8),0,dp(8),0); setOnClickListener{click()}
        }
        header.addView(headerButton("FREE AI",78){showFreeAiMenu()},
            LinearLayout.LayoutParams(dp(78),if(isLandscape())dp(32) else dp(40)).apply{setMargins(0,0,dp(5),0)})
        header.addView(headerButton("MODEL LAB",94){startActivity(Intent(this@RenActivity,BenModelLabActivity::class.java))},
            LinearLayout.LayoutParams(dp(94),if(isLandscape())dp(32) else dp(40)))
        root.addView(header,LinearLayout.LayoutParams(-1,if(isLandscape())dp(34) else dp(42)))

        val modelPill=TextView(this).apply {
            text=modelStatus(); textSize=9f; visibility=View.GONE
            setTextColor(ThemeManager.muted(this@RenActivity))
        }

        val answer=BenChatWebView(this).apply {
            id = View.generateViewId()
            contentDescription = "frankensteinChat"
            settings.javaScriptEnabled=false
            settings.domStorageEnabled=false
            settings.allowFileAccess=false
            settings.allowContentAccess=false
            settings.loadsImagesAutomatically=true
            settings.mixedContentMode=android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient=object:WebViewClient(){
                override fun shouldOverrideUrlLoading(view:WebView, request:WebResourceRequest):Boolean {
                    val u=request.url.toString()
                    if(u.startsWith("https://")){ startActivity(Intent(Intent.ACTION_VIEW, request.url)); return true }
                    return true
                }
            }
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
        }
        chatWeb=answer
        root.addView(answer,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,dp(4),0,dp(8))})
        renderChat(answer)
        answer.postDelayed({if(chatState.webScrollY>0)answer.scrollTo(0,chatState.webScrollY)},120)

        liveStatus=TextView(this).apply {
            text="BEN • READY"; textSize=10.5f
            setTextColor(ThemeManager.muted(this@RenActivity))
            visibility=View.GONE
        }

        val input=EditText(this).apply {
            hint="Ask Dr. Frankenstein…"; textSize=15f
            contentDescription = "frankensteinPrompt"
            setTextColor(ThemeManager.text(this@RenActivity))
            setHintTextColor(ThemeManager.muted(this@RenActivity))
            setSingleLine(false); minLines=2; maxLines=4; gravity=Gravity.TOP
            setPadding(dp(16),dp(12),dp(16),dp(12))
            background=UiDrawableUtils.roundedDrawable(this@RenActivity,ThemeManager.elevated(this@RenActivity),16f)
        }
        promptInput=input
        root.addView(input,LinearLayout.LayoutParams(-1,if(isLandscape())dp(48) else dp(62)).apply{setMargins(0,dp(1),0,if(isLandscape())dp(3) else dp(5))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun action(label:String,click:()->Unit)=TextView(this).apply {
            text=label; textSize=11.5f; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity))
            background=UiDrawableUtils.roundedDrawable(this@RenActivity,ThemeManager.elevated(this@RenActivity),11f)
            setOnClickListener{click()}
        }
        row.addView(action("Dr.F"){respond(input,answer,modelPill)},
            LinearLayout.LayoutParams(0,if(isLandscape())dp(32) else dp(38),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(action("Dr.F + AI"){runCombinedCore(input,answer,modelPill)},
            LinearLayout.LayoutParams(0,if(isLandscape())dp(32) else dp(38),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(action("SAVE"){saveLastBenReplyToNotes()},
            LinearLayout.LayoutParams(0,if(isLandscape())dp(32) else dp(38),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(action("G.search"){openWebSearch(input.text?.toString().orEmpty())},
            LinearLayout.LayoutParams(0,if(isLandscape())dp(32) else dp(38),1f))
        root.addView(row)

        openMatchButton = TextView(this).apply {
            text = "OPEN MATCHING QUESTIONS"
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(ThemeManager.bg(this@RenActivity))
            background = UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.accent(this@RenActivity), 12f)
            setPadding(dp(10), 0, dp(10), 0)
            visibility = View.GONE
        }
        root.addView(openMatchButton, LinearLayout.LayoutParams(-1,if(isLandscape())dp(32) else dp(38)).apply {
            topMargin = if(isLandscape())dp(3) else dp(5)
        })

        val baseLeft=root.paddingLeft; val baseTop=root.paddingTop
        val baseRight=root.paddingRight; val baseBottom=root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root){_,insets->
            val ime=insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            root.setPadding(baseLeft,baseTop,baseRight,baseBottom+maxOf(ime,bars))
            insets
        }
        ViewCompat.requestApplyInsets(root)
        RovexModernUi.applyRen(root, this)
        input.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int)=Unit;override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){chatState.prompt=s?.toString().orEmpty()};override fun afterTextChanged(e:android.text.Editable?)=Unit})
        input.setOnFocusChangeListener{_,hasFocus->
            if(hasFocus) input.post{input.requestRectangleOnScreen(Rect(0,0,input.width,input.height),true)}
        }
        return root
    }

    private fun memoryStatusLabel(): String {
        val chat = if (AppManagers.renMemory.chatContext().isBlank()) "EMPTY" else "READY"
        return "CHAT MEMORY • $chat • CLEAR"
    }


    private fun buildFrankensteinContextCard(): LinearLayout {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    fun chip(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 9f; gravity = Gravity.CENTER
        setTextColor(ThemeManager.text(this@RenActivity))
        background = UiDrawableUtils.roundedDrawable(this@RenActivity, ThemeManager.elevated(this@RenActivity), 9f)
        setPadding(dp(4), 0, dp(4), 0)
        minHeight = 0
        setOnClickListener { action() }
    }
    val inspect = chip("INSPECT") {
        val prompt = currentPromptForContext()
        if (prompt.isBlank()) Toast.makeText(this, "Enter a topic first", Toast.LENGTH_SHORT).show()
        else showFrankensteinContext(prompt)
    }
    val local = chip("LOCAL") { showFrankensteinContext(currentPromptForContext()) }
    val weak = chip("WEAKNESS") { showWeaknessContext() }
    row.addView(inspect, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(0, 0, dp(4), 0) })
    row.addView(local, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(0, 0, dp(4), 0) })
    row.addView(weak, LinearLayout.LayoutParams(0, dp(30), 1f))
    return row
}

    private fun cleanAiAnswer(raw:String):String = try {
        BenResponsePolicy.normalize(raw).orEmpty().trim()
    } catch (t: StackOverflowError) {
        android.util.Log.e("Rovex.Frankenstein", "cleanAiAnswer stack overflow", t)
        raw.take(MAX_UI_MESSAGE_CHARS).trim()
    } catch (t: Exception) {
        android.util.Log.e("Rovex.Frankenstein", "cleanAiAnswer fallback", t)
        raw.take(MAX_UI_MESSAGE_CHARS).trim()
    }
    private fun safeAnswerSpanned(raw:String):android.text.Spanned {
        val safe=BenResponsePolicy.normalize(raw).orEmpty().take(BenResponsePolicy.MAX_RESPONSE_CHARS)
        return try { rovexMarkdownToSpanned(safe) }
        // Only formatting-specific failures are contained here; catastrophic memory errors
        // are not swallowed. Input is bounded before parsing to keep this path predictable.
        catch (_:StackOverflowError) { android.text.SpannedString(safe) }
        catch (_:Exception) { android.text.SpannedString(safe) }
    }

    private fun renderChat(web: WebView) {
        val dark=ThemeManager.isDark(this)
        val bg=String.format("#%06X",0xFFFFFF and ThemeManager.bg(this))
        val text=String.format("#%06X",0xFFFFFF and ThemeManager.text(this))
        val muted=String.format("#%06X",0xFFFFFF and ThemeManager.muted(this))
        val accent=String.format("#%06X",0xFFFFFF and ThemeManager.aiText(this))
        val body=if(chatTurns.isEmpty()) "<div class='empty'>Frankenstein ready.<br><span>Tables, Markdown images and long responses are supported.</span></div>" else buildString {
            chatTurns.forEach { (role,msg) ->
                val isUser=role=="YOU"
                append("<section class='turn ").append(if(isUser)"user" else "ben").append("'><div class='role'>").append(role).append("</div>")
                append(rovexMarkdownBody(msg))
                append("</section>")
            }
        }
        val html="""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>html,body{background:$bg!important;color:$text!important}body *{color:inherit}body{font-family:sans-serif;font-size:16px;line-height:1.58;margin:0;padding:4px 2px 20px;overflow-x:auto;overflow-wrap:anywhere}.turn{box-sizing:border-box;padding:12px 14px;margin:8px 0;border-radius:18px;border:1px solid ${if(dark)"#2B3948" else "#D8DEE3"};background:${if(dark)"#121821" else "#F7F8F9"}}.turn.user{background:${if(dark)"#152530" else "#EEF6FA"}}.role{font-size:10px;font-weight:800;letter-spacing:.1em;color:$accent;margin-bottom:7px}p{margin:7px 0;max-width:100%;white-space:normal}li,dd{margin:3px 0}h1{font-size:23px;line-height:1.22;margin:13px 0 8px}h2{font-size:20px;line-height:1.25;margin:12px 0 7px}h3{font-size:18px;line-height:1.3;margin:11px 0 6px}h4,h5,h6{line-height:1.32;margin:9px 0 5px}blockquote{margin:9px 0;padding:8px 11px;border-left:4px solid $accent;background:${if(dark)"#17272D" else "#FFF7DF"};border-radius:7px}pre{box-sizing:border-box;max-width:100%;padding:10px;overflow:auto;background:${if(dark)"#0D131A" else "#EEF1F3"};border-radius:9px;white-space:pre-wrap;overflow-wrap:anywhere}code{background:${if(dark)"#1B2530" else "#E9EDF0"};padding:1px 4px;border-radius:4px;overflow-wrap:anywhere}.table-wrap{touch-action:pan-x pan-y;box-sizing:border-box;width:100%;max-width:100%;overflow-x:auto;overflow-y:hidden;margin:11px 0;padding-bottom:2px;overscroll-behavior-x:contain;-webkit-overflow-scrolling:touch;scrollbar-gutter:stable}.table-wrap table{border-collapse:collapse;border-spacing:0;width:auto;min-width:100%;max-width:none;table-layout:auto;margin:0;background:${if(dark)"#101821" else "#FFFFFF"}}.table-wrap th,.table-wrap td{box-sizing:border-box;border:1px solid ${if(dark)"#385064" else "#CBD4DA"};padding:8px 9px;text-align:left;vertical-align:top;min-width:108px;max-width:300px;white-space:normal;overflow-wrap:anywhere;word-break:normal;line-height:1.45}.table-wrap th{background:${if(dark)"#1D3342" else "#EAF1F5"};color:${if(dark)"#B9F4EF" else "#155C79"};font-weight:750;white-space:normal}.table-wrap td:first-child,.table-wrap th:first-child{min-width:120px}.table-wrap td p,.table-wrap th p{margin:0}.table-wrap td strong,.table-wrap th strong{font-weight:750}.table-wrap::-webkit-scrollbar{height:7px}.table-wrap::-webkit-scrollbar-thumb{background:${if(dark)"#5A7284" else "#9AA9B3"};border-radius:8px}img{display:block;max-width:100%;height:auto;max-height:720px;object-fit:contain;border-radius:10px;margin:10px auto;background:#0B1014}a{color:${if(dark)"#8EDBFF" else "#126B9A"}!important}strong,b{color:${if(dark)"#FFF0C7" else "#17212B"}!important}.empty{padding:28px 12px;text-align:center;color:$muted}.empty span{font-size:12px}</style></head><body>$body</body></html>"""
        web.loadDataWithBaseURL(null,html,"text/html","UTF-8",null)
        web.postDelayed({ web.scrollTo(0,Int.MAX_VALUE) },80)
    }

    private fun addChatTurn(role:String,text:String){
        val safe=BenResponsePolicy.normalize(text).orEmpty().trim()
        if(safe.isBlank())return
        if (role == "BEN") lastBenReply = safe
        val display = if (safe.length > MAX_UI_MESSAGE_CHARS) safe.take(MAX_UI_MESSAGE_CHARS) + "\n\n[Display truncated for smooth scrolling; the full response remains available to SAVE.]" else safe
        chatTurns += role to display
        while(chatTurns.size>MAX_UI_CHAT_TURNS)chatTurns.removeAt(0)
        // Chat history is UI-session state only. Ben + AI/Frankenstein must not silently
        // persist prompts or answers into the durable Ren memory store.
        chatWeb?.let{renderChat(it)}
    }

    private fun saveLastBenReplyToNotes() {
        val text = lastBenReply.trim()
        if (text.isBlank()) { Toast.makeText(this, "No Ben reply to save yet", Toast.LENGTH_SHORT).show(); return }
        val repo = AiNoteRepository(this)
        repo.save("Frankenstein • ${System.currentTimeMillis()}", text)
        Toast.makeText(this, "Saved to My Notes", Toast.LENGTH_SHORT).show()
    }

    private fun currentPromptForContext(): String = promptInput?.text?.toString()?.trim().orEmpty()

    private fun showFrankensteinContext(query: String) {
        if (query.isBlank()) { Toast.makeText(this, "Enter a topic or question first", Toast.LENGTH_SHORT).show(); return }
        liveScope.launch(Dispatchers.IO) {
            val context = try {
                AppManagers.frankensteinContext.buildEnhanced(
                    Question(0L, "context", 0, null, query, query, null, null, null, null, null, emptyList(), emptyList(), emptyList())
                )
            } catch (t: CancellationException) {
                throw t
            } catch (_: Exception) { null }
            val concepts = context?.concepts.orEmpty()
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val message = buildString {
                    append("LOCAL CONTEXT\n\n")
                    append("Concepts: ").append(concepts.take(6).joinToString(", ").ifBlank { "not confidently mapped" }).append("\n")
                    append("Related questions: ").append(context?.relatedQuestions?.size ?: 0).append("\n")
                    append("Source clusters: ").append(context?.relatedSources?.joinToString(" • ").ifNullOrBlank("none found")).append("\n")
                    append("\nThis is the bounded context Ben can hand to the selected Free AI accelerator. Your QBank answer and study state remain authoritative.")
                }
                AlertDialog.Builder(this@RenActivity).setTitle("Frankenstein Context").setMessage(message).setPositiveButton("OK", null).rovexShow()
            }
        }
    }

    private fun String?.ifNullOrBlank(fallback: String): String = if (this.isNullOrBlank()) fallback else this

    private fun showWeaknessContext() {
        val text = currentPromptForContext()
        if (text.isBlank()) { Toast.makeText(this, "Ask Ben a topic first so I can inspect your weak concepts", Toast.LENGTH_SHORT).show(); return }
        liveScope.launch(Dispatchers.IO) {
            val local = runCatching { AppManagers.benBrain.answer(text) }.getOrNull()
            val concepts = local?.plan?.concepts.orEmpty()
            val model = AppManagers.benBrain.learner()
            val rows = concepts.map { it to model.stats(it) }.sortedBy { it.second.mastery }.take(5)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                AlertDialog.Builder(this@RenActivity)
                    .setTitle("Your local weakness map")
                    .setMessage(rows.joinToString("\n") { (c, s) -> "${s.mastery}% • $c • ${s.wrong} wrong / ${s.seen} seen" }.ifBlank { "No weakness data yet." })
                    .setPositiveButton("OK", null).rovexShow()
            }
        }
    }

    private fun modelStatus(): String {
        val m=BenNeuralModelManager(this)
        val e=m.installed(BenNeuralModelRegistry.embeddingGemma300m)!=null
        val g=m.installed(BenNeuralModelRegistry.gemma3_270m)!=null
        return when { e&&g -> "Neural: EmbeddingGemma + Gemma 3 270M ready"; e -> "Neural: EmbeddingGemma installed • generation fallback"; g -> "Neural: Gemma 3 270M installed • semantic fallback"; else -> "Neural: models not installed • deterministic Ben ready" }
    }

    private fun respond(input:EditText,answer:WebView,modelPill:TextView){
        val cmd=input.text?.toString().orEmpty().trim()
        val generation=++requestGeneration
        openMatchButton?.visibility=View.GONE
        if(cmd.isBlank()){addChatTurn("BEN","Ask Ben a question first.");return}
        // Ben + AI search is stateless by default. Do not persist the user's query as
        // hidden chat context; a storage failure must never kill the search UI.
        addChatTurn("YOU",cmd); liveStatus?.text="BEN • WORKING…"
        liveJob?.cancel()
        liveJob=liveScope.launch{
            while(isActive){
                val t=BenNeuralTelemetry.snapshot()
                val gov=BenAiResourceGovernor(this@RenActivity).snapshot(foreground=true)
                liveStatus?.text="BEN • ${t.stage.name.replace('_',' ')} • ${t.stageDetail}"
                modelPill.text="${t.activeModel} • RAM ${gov.availableMemoryMb} MB • thermal ${gov.thermalStatus}"
                if(t.stage==BenNeuralTelemetry.Stage.COMPLETE||t.stage==BenNeuralTelemetry.Stage.FALLBACK||t.stage==BenNeuralTelemetry.Stage.ERROR||t.stage==BenNeuralTelemetry.Stage.BLOCKED) break
                delay(180L)
            }
        }
        liveScope.launch(Dispatchers.Default) {
            try {
                AppManagers.frankensteinSupport.respond(cmd){ insight, ids ->
                    runOnUiThread{
                        if(generation!=requestGeneration || isFinishing || isDestroyed) return@runOnUiThread
                        try {
                        liveJob?.cancel()
                val t=BenNeuralTelemetry.snapshot()
                liveStatus?.text="BEN • ${if(t.lastGeneratorUsed||t.lastSemanticUsed) "NEURAL" else "DETERMINISTIC FALLBACK"} • ${t.lastElapsedMs} ms"
                modelPill.text="${t.activeModel} • evidence ${t.lastEvidenceCount} • verifier ${if(t.lastVerified) "PASS" else "REVIEW"}"
                if(isFinishing||isDestroyed)return@runOnUiThread
                addChatTurn("BEN",cleanAiAnswer(insight.body))
                if(ids.isNotEmpty()){
                    openMatchButton?.visibility=View.VISIBLE
                    val query=cmd.replace(Regex("(?i)\\b(find|search|show|give|open|questions?|qbank|topic|subject|about)\\b")," ").replace(Regex("\\s+")," ").trim()
                    openMatchButton?.setOnClickListener{startActivity(Intent(this@RenActivity,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Dr. Frankenstein • $query").putExtra("practiceMode",true).putExtra("title","Dr. Frankenstein • $query"))}
                }
                        } catch (t: StackOverflowError) {
                            if (!isFinishing && !isDestroyed) addChatTurn("BEN","Frankenstein generated an answer, but its formatting was too deeply nested to render safely. The plain answer is shown below.\n\n${insight.body}")
                            android.util.Log.e("Rovex.Frankenstein", "UI result stack overflow", t)
                        } catch (t: Exception) {
                            // Expected renderer/runtime exceptions are isolated to this response.
                            if (!isFinishing && !isDestroyed) addChatTurn("BEN","Frankenstein completed the request, but the answer renderer hit a recoverable error.\n\n${insight.body}")
                            android.util.Log.e("Rovex.Frankenstein", "UI result handling failed", t)
                        }
                    }
                }
            } catch (t: StackOverflowError) {
                liveJob?.cancel()
                if (!isFinishing && !isDestroyed && generation==requestGeneration) addChatTurn("BEN","Frankenstein hit an unsafe nesting depth and stopped this request safely. Try again.")
                android.util.Log.e("Rovex.Frankenstein", "Engine stack overflow", t)
            } catch (t: Exception) {
                liveJob?.cancel()
                if (!isFinishing && !isDestroyed && generation==requestGeneration) addChatTurn("BEN","Frankenstein could not start this request safely. Try again.")
                android.util.Log.e("Rovex.Frankenstein", "Engine invocation failed", t)
            }
        }
    }

    private fun runCombinedCore(input:EditText, answer:WebView, modelPill:TextView){
        val cmd=input.text?.toString().orEmpty().trim()
        if(cmd.isBlank()){addChatTurn("BEN","Ask a clinical/study question first.");return}
        cloudJob?.cancel()
        addChatTurn("YOU",cmd); liveStatus?.text="BEN • CONTEXT → FREE AI"
        liveStatus?.text="BEN • CONTEXT → FREE AI"
        cloudJob=liveScope.launch(Dispatchers.IO){
            val context=runCatching{
                AppManagers.frankensteinContext.buildEnhanced(
                    Question(0L,"context",0,null,cmd,cmd,null,null,null,null,null,emptyList(),emptyList(),emptyList())
                )
            }.getOrNull()
            val compact=buildString{
                append("BEN LOCAL CONTEXT — COMPACT HANDOFF\n")
                append("CONCEPTS: ").append(context?.concepts?.take(6)?.joinToString(", ").orEmpty().ifBlank{"none"}).append('\n')
                append("RELATED QUESTIONS: ").append(context?.relatedQuestions?.size ?: 0).append('\n')
                context?.relatedQuestions?.take(4)?.forEachIndexed{i,r->append("[Q${i+1}] ").append(r.exam).append(" / ").append(r.source).append(" • ").append(r.text.take(420)).append(" • KEY: ").append(r.answer.take(180)).append('\n')}
                append("REFERENCE PDF PAGES: ").append(context?.pdfEvidence?.size ?: 0).append('\n')
                context?.pdfEvidence?.take(3)?.forEachIndexed{i,h->append("[PDF${i+1}] page ").append(h.page).append(" • ").append(h.text.take(900)).append('\n')}
            }.take(7000)
            val prompt=buildString{
                append(benExamPromptContext(applicationContext)).append("\n\n")
                append("IN-SESSION CHAT (NOT PERSISTED):\n")
                chatTurns.takeLast(8).forEach { (role, text) -> append(role).append(": ").append(text.take(2400)).append("\n") }
                append("\nUSER REQUEST:\n").append(cmd).append("\n\n")
                append(compact)
                append("\nDo not repeat the user's request verbatim. Use the local evidence only as supporting context; do not invent PYQ provenance. If local evidence conflicts with a keyed QBank answer, explicitly flag the conflict instead of silently changing it.")
            }
            val result=runCatching{AppManagers.cloudAi.generate(prompt=prompt,system="You are the primary Free AI answerer inside Rovex. Ben is only a context collector in this mode. Answer the user's study request directly and with as much detail as the question warrants. Use local QBank/PDF context when supplied, but do not claim web search or invent provenance. Use readable Markdown and tables when useful. Never output CSS, <style> blocks, HTML document wrappers, or CSS selector source such as body{...}; return only the actual answer content.",maxTokens=8192,timeoutMs=30_000L)}.getOrNull()
            runOnUiThread{
                if(isFinishing||isDestroyed)return@runOnUiThread
                if(result!=null){
                    addChatTurn("BEN",cleanAiAnswer(result.text))
                    modelPill.text="${result.provider.label} • ${result.model}"
                    liveStatus?.text="FREE AI • BEN CONTEXT SUPPLIED"
                }else{
                    addChatTurn("BEN","No Free AI provider is connected. Tap FREE AI to connect a free provider.")
                    modelPill.text="FREE AI unavailable"
                    liveStatus?.text="BEN • CONTEXT READY • NO FREE AI"
                }
            }
        }
    }

    private fun showFreeAiMenu() { BenFreeAiDialog(this, liveScope).show() }

    private fun openWebSearch(query:String){
        val clean=query.trim().ifBlank{"medical study question"}
        val q="${currentBenExamProfile(this).label} medical exam context: $clean"
        startActivity(Intent(this,GoogleSearchActivity::class.java).putExtra("query",q))
    }

    override fun onDestroy(){
        chatWeb?.let{chatState.webScrollY=it.scrollY}
        if(!isChangingConfigurations){liveJob?.cancel();cloudJob?.cancel()}
        liveScope.cancel()
        chatWeb?.let { web ->
            runCatching { web.stopLoading() }
            runCatching { web.loadUrl("about:blank") }
            runCatching { (web.parent as? ViewGroup)?.removeView(web) }
            runCatching { web.removeAllViews() }
            runCatching { web.destroy() }
        }
        chatWeb = null
        super.onDestroy()
    }
}
