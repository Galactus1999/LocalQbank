package com.localqbank.library
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import kotlin.math.sin

/** Lightweight procedural atmosphere; no bitmaps, no I/O, theme-aware and offline. */
class ThemeAtmosphereDrawable(private val context:Context):Drawable(){
 private val p=Paint(Paint.ANTI_ALIAS_FLAG)
 private val stars=Array(96){i->Triple(((i*47)%101)/100f,((i*71+11)%101)/100f,.35f+((i*17)%10)/10f)}
 override fun draw(c:Canvas){val w=bounds.width().toFloat().coerceAtLeast(1f);val h=bounds.height().toFloat().coerceAtLeast(1f);val k=ThemeManager.get(context);when(k){ThemeManager.LIGHT->light(c,w,h,0xFFF7FAFF.toInt(),0xFFFFFFFF.toInt(),0xFF4D9CFF.toInt());ThemeManager.PASTEL->light(c,w,h,0xFFE8F2FF.toInt(),0xFFFFEFFA.toInt(),0xFF8D7CFF.toInt());ThemeManager.MINT->light(c,w,h,0xFFE5FFF8.toInt(),0xFFEAF5FF.toInt(),0xFF36D7B5.toInt());ThemeManager.SUNSET->light(c,w,h,0xFFFFF0DE.toInt(),0xFFFFE8F0.toInt(),0xFFFF8A58.toInt());ThemeManager.LAVENDER->light(c,w,h,0xFFF0EBFF.toInt(),0xFFE5F1FF.toInt(),0xFF9B70FF.toInt());ThemeManager.AMOLED->dark(c,w,h,0xFF39D9FF.toInt(),0xFF8B5CFF.toInt());ThemeManager.CYBER->dark(c,w,h,0xFF00F0FF.toInt(),0xFFFF3DBB.toInt());ThemeManager.OCEAN->dark(c,w,h,0xFF27D7FF.toInt(),0xFF39E6B0.toInt());ThemeManager.NEBULA->dark(c,w,h,0xFFB56CFF.toInt(),0xFF42A5FF.toInt())}}
 private fun light(c:Canvas,w:Float,h:Float,a:Int,b:Int,g:Int){p.shader=LinearGradient(0f,0f,w,h,a,b,Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p);val pts=arrayOf(floatArrayOf(w*.08f,h*.10f),floatArrayOf(w*.92f,h*.18f),floatArrayOf(w*.18f,h*.88f),floatArrayOf(w*.78f,h*.80f));pts.forEachIndexed{i,q->p.shader=RadialGradient(q[0],q[1],minOf(w,h)*.42f,intArrayOf(Color.argb(75-i*8,Color.red(g),Color.green(g),Color.blue(g)),Color.TRANSPARENT),floatArrayOf(0f,1f),Shader.TileMode.CLAMP);c.drawCircle(q[0],q[1],minOf(w,h)*.42f,p)}}
 private fun dark(c:Canvas,w:Float,h:Float,a:Int,b:Int){p.shader=LinearGradient(0f,0f,w,h,Color.rgb(0,2,8),Color.rgb(7,5,22),Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p);val pts=arrayOf(floatArrayOf(w*.18f,h*.18f),floatArrayOf(w*.82f,h*.16f),floatArrayOf(w*.72f,h*.82f),floatArrayOf(w*.12f,h*.78f));pts.forEachIndexed{i,q->{p.shader=RadialGradient(q[0],q[1],minOf(w,h)*.48f,intArrayOf(Color.argb(105-i*12,Color.red(if(i%2==0)a else b),Color.green(if(i%2==0)a else b),Color.blue(if(i%2==0)a else b)),Color.TRANSPARENT),floatArrayOf(0f,1f),Shader.TileMode.CLAMP);c.drawCircle(q[0],q[1],minOf(w,h)*.48f,p)}};p.shader=null;p.color=Color.argb(190,205,230,255);stars.forEachIndexed{i,s->c.drawCircle(s.first*w,s.second*h,s.third*(.5f+.2f*sin(i.toFloat())),p)}}
 override fun setAlpha(a:Int){p.alpha=a};override fun setColorFilter(f:ColorFilter?){p.colorFilter=f};override fun getOpacity()=PixelFormat.TRANSLUCENT
}
