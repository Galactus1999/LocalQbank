package com.localqbank.library
object RovexThemeAuditMarker {
 const val SYSTEM="ROVEX_VISUAL_REVOLUTION_304"
 const val THEMES="LIGHT,PASTEL,MINT,SUNSET,LAVENDER,AMOLED,CYBER,OCEAN,NEBULA"
 const val GLOBAL_ENGINE="RovexThemeEngine"
 const val HOME_ENGINE="RovexHomeRevolution"
}
