package com.localqbank.library

import android.content.Context
import java.util.Locale

/**
 * Read-only, preloaded medical curriculum taxonomy. The taxonomy is application knowledge,
 * not QBank data, so it lives in assets rather than QBankDb. This keeps the database schema
 * focused on user/imported data and prevents another god file.
 */
class MedicalTaxonomyRepository private constructor(context: Context) {
    private val nodes: List<MedicalTaxonomyNode> = load(context.applicationContext)
    private val aliases: List<Pair<String, MedicalTaxonomyNode>> = buildList {
        nodes.forEach { node ->
            val terms = listOf(node.subject, node.topic, node.subtopic) + node.deepTopics + node.aliases
            terms.map(::normalize).filter { it.length >= 2 }.distinct().forEach { add(it to node) }
        }
    }.sortedByDescending { it.first.length }

    fun subjects(): List<String> = nodes.map { it.subject }.distinct()
    fun nodesForSubject(subject: String): List<MedicalTaxonomyNode> =
        nodes.filter { it.subject.equals(subject, true) }

    fun classify(text: String, limit: Int = 5): List<MedicalTaxonomyMatch> {
        val hay = normalize(text)
        if (hay.length < 2) return emptyList()
        return nodes.asSequence().mapNotNull { node ->
            val terms = (listOf(node.subject, node.topic, node.subtopic) + node.deepTopics + node.aliases)
                .map(::normalize).filter { it.length >= 2 }.distinct()
            val matched = terms.filter { containsPhrase(hay, it) }
            if (matched.isEmpty()) return@mapNotNull null
            val score = matched.sumOf { term ->
                when {
                    normalize(node.subject) == term -> 80
                    normalize(node.subtopic) == term -> 70
                    normalize(node.topic) == term -> 45
                    node.deepTopics.any { normalize(it) == term } -> 55
                    else -> 35
                } + term.split(' ').size.coerceAtMost(4) * 3
            }
            MedicalTaxonomyMatch(node, score, matched.take(6))
        }.sortedWith(compareByDescending<MedicalTaxonomyMatch> { it.score }.thenBy { it.node.path })
            .take(limit.coerceIn(1, 20)).toList()
    }

    /** Returns bounded canonical/alias variants for deterministic local search expansion. */
    fun expandQuery(query: String, limit: Int = 8): List<String> {
        val normalized = normalize(query)
        if (normalized.length < 2) return emptyList()
        val direct = aliases.asSequence()
            .filter { containsPhrase(normalized, it.first) || containsPhrase(it.first, normalized) }
            .map { it.second }
            .distinctBy { it.path }
            .flatMap { node -> (node.aliases + node.deepTopics + listOf(node.subtopic, node.topic)).asSequence() }
            .map(::normalize)
            .filter { it.length >= 2 && it != normalized }
            .distinct()
            .take(limit.coerceIn(1, 16))
            .toList()
        return direct
    }

    fun describe(text: String): String? = classify(text, 1).firstOrNull()?.node?.path

    private fun containsPhrase(hay: String, term: String): Boolean {
        if (term.isBlank()) return false
        if (hay == term) return true
        return Regex("(?:^|\\s)${Regex.escape(term)}(?:\\s|$)").containsMatchIn(hay)
    }

    private fun load(context: Context): List<MedicalTaxonomyNode> {
        return runCatching {
            context.assets.open("medical_taxonomy.tsv").bufferedReader().useLines { lines ->
                lines.drop(1).mapNotNull { line ->
                    val p = line.split('\t')
                    if (p.size < 5) return@mapNotNull null
                    MedicalTaxonomyNode(
                        subject = p[0].trim(),
                        topic = p[1].trim(),
                        subtopic = p[2].trim(),
                        deepTopics = p[3].split('|').map(String::trim).filter(String::isNotBlank),
                        aliases = p[4].split('|').map(String::trim).filter(String::isNotBlank)
                    )
                }.toList()
            }
        }.getOrElse { emptyList() }
    }

    companion object {
        @Volatile private var instance: MedicalTaxonomyRepository? = null
        fun get(context: Context): MedicalTaxonomyRepository =
            instance ?: synchronized(this) {
                instance ?: MedicalTaxonomyRepository(context).also { instance = it }
            }

        internal fun normalize(value: String): String = value.lowercase(Locale.ROOT)
            .replace('&', ' ')
            .replace(Regex("[^a-z0-9]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
