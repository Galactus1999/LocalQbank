package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import android.os.SystemClock
import android.util.Log
import java.util.concurrent.atomic.AtomicLong

/**
 * Owns FTS schema/health/rebuild policy. Interactive callers never perform a full rebuild.
 * QBankDb exposes this through its compatibility façade.
 */
internal class QBankSearchIndexCoordinator(
    private val databaseProvider: () -> SQLiteDatabase
) {
    private val db: SQLiteDatabase get() = databaseProvider()
    private companion object { const val HEALTH_TTL_MS = 1_000L }
    private val healthLock = Any()
    private val mutationGeneration = AtomicLong(0L)
    @Volatile private var healthy = false
    @Volatile private var healthCheckedAt = 0L

/**
 * Search-index health check.
 *
 * IMPORTANT: this method is called from interactive search paths. It must never rebuild the
 * entire FTS corpus synchronously: a large QBank can contain hundreds of thousands of rows,
 * and doing the rebuild here can monopolize SQLite/CPU long enough to make the foreground
 * Activity appear hung. Interactive search therefore uses FTS opportunistically and falls back
 * only when necessary; repair is deferred to an idle-only WorkManager task.
 */
fun ensureSearchIndex(){
    // Interactive callers only verify the schema. They must never enqueue a full-corpus
    // repair merely because the index is dirty; search has a bounded FTS-first fallback and
    // maintenance is handled by WorkManager while the device is idle.
    ensureSearchIndexSchema()
}

/** Cached health signal for callers that must bound fallback fan-out while FTS is rebuilding. */
fun isReady(): Boolean = isSearchIndexComplete()

private fun ensureSearchIndexSchema(){
    runCatching {
        var schemaOk=false
        db.rawQuery("PRAGMA table_info(question_fts)", null).use { c ->
            var cols=0
            while(c.moveToNext()){
                if(c.getString(1)=="source_id") schemaOk=true
                cols++
            }
            if(cols < 4) schemaOk=false
        }
        if(!schemaOk){
            QBankWriteCoordinator.lock.lock()
            try {
                db.execSQL("DROP TABLE IF EXISTS question_fts")
                db.execSQL("CREATE VIRTUAL TABLE question_fts USING fts4(question_id UNINDEXED, test_id UNINDEXED, source_id UNINDEXED, content)")
                db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','1')")
            } finally {
                QBankWriteCoordinator.lock.unlock()
            }
        }
    }.onFailure { e ->
        android.util.Log.w("QBankDb", "Search index schema check deferred: ${e.message}")
        ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.search_index_schema_check_failed:${e.javaClass.simpleName}")
    }
}

/**
 * Rebuild only when requested by the background repair executor. Kept separate from the
 * interactive search path so an incomplete index can never turn typing into a long SQLite
 * write transaction.
 */
private fun rebuildSearchIndexIfNeeded(){
    try {
        ensureSearchIndexSchema()
        val dirty = db.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='dirty' LIMIT 1", null).use { c ->
            c.moveToFirst() && c.getString(0) != "0"
        }
        val garbagePending = db.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='garbage_pending' LIMIT 1", null).use { c ->
            c.moveToFirst() && c.getString(0) != "0"
        }
        if (!dirty && !garbagePending) return
        val repairGeneration = mutationGeneration.get()

        // Rebuild in small, independently committed batches. The previous implementation
        // held one transaction for the entire corpus; on a large QBank that monopolized the
        // SQLite writer and CPU and starved foreground navigation/Ben/Frankenstein.
        QBankWriteCoordinator.lock.lock()
        try {
            db.beginTransactionNonExclusive()
            try {
                db.delete("question_fts", null, null)
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        } finally {
            QBankWriteCoordinator.lock.unlock()
        }

        var lastId = 0L
        var inserted = 0L
        while (true) {
            val rows = db.rawQuery(
                "SELECT q.id,q.test_id,s.id,COALESCE(q.text,'')||' '||COALESCE(q.raw_text,'')||' '||COALESCE(q.correct_answer,'')||' '||COALESCE(q.explanation,'')||' '||COALESCE(q.bot,'')||' '||COALESCE(q.video,'')||' '||COALESCE(q.audio,'')||' '||COALESCE(t.title,'')||' '||COALESCE(t.path,'')||' '||COALESCE(s.display_name,s.file_name,'')||' '||COALESCE((SELECT group_concat(COALESCE(o.label,'')||' '||COALESCE(o.text,''),' ') FROM option_item o WHERE o.question_id=q.id),'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.id>? ORDER BY q.id LIMIT 100",
                arrayOf(lastId.toString())
            ).use { c ->
                buildList { while (c.moveToNext()) add(arrayOf(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3))) }
            }
            if (rows.isEmpty()) break
            QBankWriteCoordinator.lock.lock()
            try {
                db.beginTransactionNonExclusive()
                try {
                    val st = db.compileStatement("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)")
                    try {
                    rows.forEach { row ->
                        st.bindLong(1, row[0] as Long)
                        st.bindString(2, row[1] as String)
                        st.bindLong(3, row[2] as Long)
                        st.bindString(4, row[3] as String)
                        st.executeInsert()
                        st.clearBindings()
                    }
                    } finally { st.close() }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
            } finally {
                QBankWriteCoordinator.lock.unlock()
            }
            lastId = rows.last()[0] as Long
            inserted += rows.size
        }

        val indexed = db.rawQuery("SELECT COUNT(*) FROM question_fts", null).use { c -> c.moveToFirst(); c.getLong(0) }
        val questions = db.rawQuery(
            "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
            null
        ).use { c -> c.moveToFirst(); c.getLong(0) }
        if (indexed == questions && mutationGeneration.get() == repairGeneration) {
            db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")
            db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending','0')")
            synchronized(healthLock) {
                healthy = true
                healthCheckedAt = android.os.SystemClock.elapsedRealtime()
            }
        } else {
            markDirty()
        }
    } catch (e: Exception) {
        android.util.Log.w("QBankDb", "Search index maintenance deferred: ${e.message}")
        markDirty()
    }
}

/** Called only by idle WorkManager maintenance; never from an interactive search path. */
fun repairForMaintenance(): Boolean {
    rebuildSearchIndexIfNeeded()
    return isSearchIndexComplete()
}

private fun isSearchIndexComplete(): Boolean {
    val now = android.os.SystemClock.elapsedRealtime()
    synchronized(healthLock) {
        if (now - healthCheckedAt < HEALTH_TTL_MS) {
            return healthy
        }
        val computedHealthy = runCatching {
            val dirty = db.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='dirty' LIMIT 1", null).use { c ->
                c.moveToFirst() && c.getString(0) != "0"
            }
            if (dirty) false else {
                val live = db.rawQuery(
                    "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
                    null
                ).use { c -> c.moveToFirst(); c.getLong(0) }
                val indexedLive = db.rawQuery(
                    "SELECT COUNT(DISTINCT f.question_id) FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
                    null
                ).use { c -> c.moveToFirst(); c.getLong(0) }
                val duplicateLive = db.rawQuery(
                    "SELECT COUNT(*) FROM (SELECT f.question_id FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 GROUP BY f.question_id HAVING COUNT(*)<>1)",
                    null
                ).use { c -> c.moveToFirst(); c.getLong(0) }
                live == indexedLive && duplicateLive == 0L
            }
        }.getOrDefault(false)
        healthy = computedHealthy
        healthCheckedAt = now
        return computedHealthy
    }
}

fun scheduleRepair() {
    runCatching {
        QBankSearchIndexMaintenanceWorker.enqueue(RovexApplicationContextHolder.context)
    }.onFailure {
        ProductionCrashReporter.breadcrumb(
            RovexApplicationContextHolder.context,
            "QBankDb.search_index_maintenance_enqueue_failed:${it.javaClass.simpleName}"
        )
    }
}

fun markDirty() {
    mutationGeneration.incrementAndGet()
    QBankWriteCoordinator.lock.lock()
    try {
        runCatching { db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','1')") }
    } finally {
        QBankWriteCoordinator.lock.unlock()
    }
    synchronized(healthLock) {
        healthy = false
        healthCheckedAt = 0L
    }
}

/**
 * Records physical FTS garbage without declaring the live index incomplete.
 *
 * Source deletion removes the authoritative question/test/source rows first. The FTS4 rows
 * for those deleted questions are intentionally retained until bounded idle maintenance,
 * because synchronously scanning the full FTS corpus would defeat the deletion latency
 * contract. Live search joins the authoritative normalized tables, so the retained rows are
 * logically invisible. Invalidate cached health and the maintenance generation, but keep
 * `dirty=0`: `dirty` means live index coverage is incomplete; `garbage_pending` means only
 * obsolete physical rows remain.
 */
fun markGarbagePending() {
    mutationGeneration.incrementAndGet()
    QBankWriteCoordinator.lock.lock()
    try {
        runCatching {
            db.execSQL(
                "INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending','1')"
            )
        }
    } finally {
        QBankWriteCoordinator.lock.unlock()
    }
    synchronized(healthLock) {
        healthy = false
        healthCheckedAt = 0L
    }
}

/**
 * A matching row count is not sufficient proof that FTS content is current: one stale row
 * can replace one missing row and produce the same count. The live-index invariant therefore
 * checks authoritative live-question coverage and duplicate live rows; obsolete tombstone rows
 * are tracked separately as physical garbage and never make interactive search unhealthy.
 */
fun finalizeIncremental() {
    // Imports write normalized questions and FTS rows transactionally. A deleted source may
    // leave stale physical FTS rows until idle compaction, so global FTS cardinality is not a
    // live-index invariant. The invariant is: every live question has exactly one live FTS row.
    val published = runCatching {
        val liveQuestions = db.rawQuery(
            "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
            null
        ).use { c -> c.moveToFirst(); c.getLong(0) }
        val totalFtsRows = db.rawQuery("SELECT COUNT(*) FROM question_fts", null)
            .use { c -> c.moveToFirst(); c.getLong(0) }
        val indexedLiveQuestions = db.rawQuery(
            "SELECT COUNT(DISTINCT f.question_id) FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
            null
        ).use { c -> c.moveToFirst(); c.getLong(0) }
        val duplicateLiveRows = db.rawQuery(
            "SELECT COUNT(*) FROM (SELECT f.question_id FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 GROUP BY f.question_id HAVING COUNT(*)<>1)",
            null
        ).use { c -> c.moveToFirst(); c.getLong(0) }
        if (indexedLiveQuestions != liveQuestions || duplicateLiveRows != 0L) {
            false
        } else {
            // Stale rows belonging to deleted sources are legitimate garbage. Keep their
            // marker so idle maintenance knows cleanup is still required, but do not make
            // interactive search fall back merely because obsolete rows exist.
            db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")
            db.execSQL(
                "INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending',?)",
                arrayOf(if (totalFtsRows > liveQuestions) "1" else "0")
            )
            synchronized(healthLock) {
                healthy = true
                healthCheckedAt = android.os.SystemClock.elapsedRealtime()
            }
            true
        }
    }.getOrDefault(false)
    if (!published) {
        markDirty()
        scheduleRepair()
    }
}

}
