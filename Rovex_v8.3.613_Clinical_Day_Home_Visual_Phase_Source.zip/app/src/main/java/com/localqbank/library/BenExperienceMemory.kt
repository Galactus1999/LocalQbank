package com.localqbank.library

import android.content.Context

class BenExperienceMemory(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("ben_experience_memory", Context.MODE_PRIVATE)
    private val maxEntries = 32

    data class Entry(val intent: String, val specialist: String, val confidence: Int, val verified: Boolean, val timestamp: Long)

    fun record(query: String, plan: BenCognitiveArchitecture.Plan, result: BenCognitiveArchitecture.Result) {
        val compact = listOf(System.currentTimeMillis(), plan.intent ?: "general", plan.specialist, result.confidence, if (result.verified) 1 else 0, query.take(120).replace('\n', ' ')).joinToString("\t")
        val rows = recentRaw().toMutableList()
        rows += compact
        prefs.edit().putString("rows", rows.takeLast(maxEntries).joinToString("\n")).apply()
    }

    fun recent(limit: Int = 8): List<Entry> = recentRaw().takeLast(limit.coerceIn(1, maxEntries)).mapNotNull { row ->
        val p = row.split('\t')
        if (p.size < 5) null else Entry(p[1], p[2], p[3].toIntOrNull()?.coerceIn(0,100) ?: 0, p[4] == "1", p[0].toLongOrNull() ?: 0L)
    }

    fun summary(): String {
        val rows = recent()
        if (rows.isEmpty()) return "No episodic experience yet."
        val verified = rows.count { it.verified }
        val specialists = rows.groupingBy { it.specialist }.eachCount().entries.sortedByDescending { it.value }.take(3)
        return "Recent ${rows.size} decisions • ${verified}/${rows.size} verified • dominant routes: ${specialists.joinToString { it.key + "×" + it.value }}"
    }

    fun reset() = prefs.edit().clear().apply()
    private fun recentRaw(): List<String> = prefs.getString("rows", "").orEmpty().lineSequence().filter { it.isNotBlank() }.toList()
}
