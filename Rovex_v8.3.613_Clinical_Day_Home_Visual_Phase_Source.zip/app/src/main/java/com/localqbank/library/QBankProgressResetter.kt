package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabaseLockedException
import java.util.concurrent.locks.LockSupport

/**
 * Owns the transactional learner-state reset operations used by QBankDb.
 * Content and immutable study history are deliberately outside this component's scope.
 */
internal class QBankProgressResetter(
    private val dbProvider: () -> SQLiteDatabase,
    private val sourceNameForId: (Long) -> String?
) {
    private val db: SQLiteDatabase
        get() = dbProvider()
    fun resetTestProgress(testId: String): Boolean {
        val id = testId.trim()
        if (id.isBlank()) return false
        return runCatching {
            withWriteRetry("reset-test-progress") {
                QBankWriteCoordinator.lock.lock()
            try {
                db.beginTransactionNonExclusive()
                try {
                db.delete("progress_v2", "test_id=?", arrayOf(id))
                db.delete(
                    "progress",
                    "question_id IN (SELECT id FROM question WHERE test_id=?)",
                    arrayOf(id)
                )
                val keys = arrayOf("$id:position", "$id:completed")
                db.delete("progress_meta", "meta_key IN (?,?)", keys)
                listOf("last_resume_global", "last_solved_global").forEach { key ->
                    val raw = progressMeta(key)
                    val parts = raw?.split("|", limit = 4).orEmpty()
                    if (parts.getOrNull(0) == id) {
                        db.delete("progress_meta", "meta_key=?", arrayOf(key))
                    }
                }
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
                true
            } finally {
                QBankWriteCoordinator.lock.unlock()
            }
            }
        }.getOrElse { false }
    }

    fun resetSourceProgress(sourceId: Long): Boolean {
        if (sourceId <= 0L) return false
        return runCatching {
            withWriteRetry("reset-source-progress") {
                QBankWriteCoordinator.lock.lock()
            try {
                db.beginTransactionNonExclusive()
                try {
                db.delete(
                    "progress_v2",
                    "test_id IN (SELECT id FROM test WHERE source_id=?)",
                    arrayOf(sourceId.toString())
                )
                db.delete(
                    "progress",
                    "question_id IN (SELECT q.id FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?)",
                    arrayOf(sourceId.toString())
                )

                db.delete(
                    "progress_meta",
                    "meta_key=? OR meta_key=?",
                    arrayOf("source:$sourceId:resume", "sourceName:${sourceNameForId(sourceId)}:resume")
                )
                db.delete(
                    "progress_meta",
                    "meta_key IN (SELECT id || ':position' FROM test WHERE source_id=?) OR " +
                        "meta_key IN (SELECT id || ':completed' FROM test WHERE source_id=?)",
                    arrayOf(sourceId.toString(), sourceId.toString())
                )
                listOf("last_resume_global", "last_solved_global").forEach { key ->
                    val raw = progressMeta(key)
                    val parts = raw?.split("|", limit = 4).orEmpty()
                    if (parts.getOrNull(2)?.toLongOrNull() == sourceId) {
                        db.delete("progress_meta", "meta_key=?", arrayOf(key))
                    }
                }
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
                true
            } finally {
                QBankWriteCoordinator.lock.unlock()
            }
            }
        }.getOrElse { false }
    }

    private inline fun <T> withWriteRetry(label: String, attempts: Int = 4, block: () -> T): T {
        var last: SQLiteDatabaseLockedException? = null
        for (attempt in 0 until attempts) {
            try {
                return block()
            } catch (e: SQLiteDatabaseLockedException) {
                last = e
                if (attempt + 1 >= attempts) break
                LockSupport.parkNanos((20L shl attempt).coerceAtMost(160L) * 1_000_000L)
                if (Thread.currentThread().isInterrupted) throw InterruptedException("QBank progress reset interrupted")
            }
        }
        throw last ?: IllegalStateException("$label failed")
    }


    private fun progressMeta(key: String): String? =
        db.rawQuery("SELECT meta_value FROM progress_meta WHERE meta_key=? LIMIT 1", arrayOf(key)).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
}
