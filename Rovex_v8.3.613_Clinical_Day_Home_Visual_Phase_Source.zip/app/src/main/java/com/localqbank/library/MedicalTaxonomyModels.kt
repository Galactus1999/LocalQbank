package com.localqbank.library

data class MedicalTaxonomyNode(
    val subject: String,
    val topic: String,
    val subtopic: String,
    val deepTopics: List<String>,
    val aliases: List<String>
) {
    val path: String get() = listOf(subject, topic, subtopic).filter { it.isNotBlank() }.joinToString(" › ")
}

data class MedicalTaxonomyMatch(
    val node: MedicalTaxonomyNode,
    val score: Int,
    val matchedTerms: List<String>
)
