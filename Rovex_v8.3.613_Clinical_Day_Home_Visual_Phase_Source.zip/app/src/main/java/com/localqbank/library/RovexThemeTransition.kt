package com.localqbank.library

import android.app.Activity
import android.view.View

/** Lightweight theme-change transition; avoids an abrupt blank frame around Activity recreation. */
object RovexThemeTransition {
    fun apply(activity: Activity, view: View? = null) {
        RovexSoundFeedback.playThemeSwitch(activity)
        view?.let {
            it.alpha = 0.94f
            it.animate().alpha(1f).setDuration(180L).start()
        }
        activity.recreate()
        activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    fun prepareEntry(view: View?) {
        view ?: return
        view.alpha = 0.94f
        view.post { view.animate().alpha(1f).setDuration(220L).start() }
    }
}
