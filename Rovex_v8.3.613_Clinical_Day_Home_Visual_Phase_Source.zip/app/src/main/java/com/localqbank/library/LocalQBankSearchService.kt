package com.localqbank.library

import android.content.Context

/**
 * Single deterministic retrieval contract for every local-QBank consumer.
 *
 * This class deliberately owns retrieval composition, not ranking, UI, learner state or AI.
 * The authoritative corpus remains QBankDb. Every caller gets the same bounded terminology
 * expansion and the same literal+alias recall behavior, preventing Frankenstein, Search and
 * the neural evidence pipeline from silently implementing different search engines.
 */
class LocalQBankSearchService(context: Context) {
    private val app = context.applicationContext
    private val db = QBankDb(app)

    data class Result(
        val hits: List<SearchHit>,
        val variants: List<String>,
        val primaryCount: Int,
        val aliasCount: Int,
        /** Time spent preparing/validating the authoritative SQLite search index. */
        val indexSchemaMs: Long = 0L,
        /** Time spent in the primary literal QBank search. */
        val primarySearchMs: Long = 0L,
        /** Time spent executing bounded alias/variant searches. */
        val aliasSearchMs: Long = 0L
    )

    fun search(
        query: String,
        limit: Int = 100,
        extraVariants: Collection<String> = emptyList(),
        visualOnly: Boolean = false,
        shouldContinue: () -> Boolean = { true }
    ): Result = RovexPerformanceTrace.scoped("local-qbank-search") {
        searchInternal(query, limit, extraVariants, visualOnly, shouldContinue)
    }

    private fun searchInternal(
        query: String,
        limit: Int,
        extraVariants: Collection<String>,
        visualOnly: Boolean,
        shouldContinue: () -> Boolean
    ): Result {
        val safeLimit = limit.coerceIn(1, 1200)
        val normalized = ClinicalKnowledgeLayer.normalize(query)
        if (normalized.length < 2) return Result(emptyList(), emptyList(), 0, 0)

        val variants = linkedSetOf<String>().apply {
            add(normalized)
            ClinicalQueryExpansion.expand(normalized).forEach(::add)
            MedicalTaxonomyRepository.get(app).expandQuery(normalized).forEach(::add)
            extraVariants.forEach { value ->
                val v = ClinicalKnowledgeLayer.normalize(value)
                if (v.length >= 2) add(v)
            }
        }.filter { it.isNotBlank() }.take(16)

        val indexSchemaStarted = android.os.SystemClock.elapsedRealtime()
        runCatching { db.ensureSearchIndex() }
            .onFailure {
                ProductionCrashReporter.breadcrumb(
                    RovexApplicationContextHolder.context,
                    "LOCAL_SEARCH_INDEX_PREP_FAILED:${it.javaClass.simpleName}"
                )
            }
        val indexSchemaMs = (android.os.SystemClock.elapsedRealtime() - indexSchemaStarted).coerceAtLeast(0L)

        val primaryStarted = android.os.SystemClock.elapsedRealtime()
        val primary = runCatching {
            if (visualOnly) db.searchImageQuestions(normalized, safeLimit)
            else db.search(normalized, safeLimit)
        }.getOrElse {
            ProductionCrashReporter.breadcrumb(
                RovexApplicationContextHolder.context,
                "LOCAL_SEARCH_PRIMARY_FAILED:${it.javaClass.simpleName}"
            )
            emptyList()
        }
        val primarySearchMs = (android.os.SystemClock.elapsedRealtime() - primaryStarted).coerceAtLeast(0L)

        // Alias/semantic-language rescue is deliberately bounded. Search every alias only when
        // primary recall is sparse; this avoids turning ordinary typing into N full-table scans.
        val aliasVariants = variants.drop(1).take(if (primary.size >= minOf(8, safeLimit)) 0 else 8)
        val aliasStarted = android.os.SystemClock.elapsedRealtime()
        val aliases = if (aliasVariants.isEmpty() || !shouldContinue()) emptyList() else {
            aliasVariants.asSequence()
                .takeWhile { shouldContinue() }
                .flatMap { variant ->
                    if (!shouldContinue()) return@flatMap emptySequence()
                    runCatching {
                        if (visualOnly) db.searchImageQuestions(variant, safeLimit)
                        else db.search(variant, safeLimit)
                    }.getOrDefault(emptyList()).asSequence()
                }
                .distinctBy { it.id }
                .take(safeLimit)
                .toList()
        }
        val aliasSearchMs = (android.os.SystemClock.elapsedRealtime() - aliasStarted).coerceAtLeast(0L)

        val merged = (primary + aliases).distinctBy { it.id }.take(safeLimit)
        return Result(
            merged,
            variants,
            primary.size,
            aliases.size,
            indexSchemaMs,
            primarySearchMs,
            aliasSearchMs
        )
    }

    /** Hierarchy retrieval uses the same clinical variants as question retrieval. */
    fun searchSections(
        query: String,
        limit: Int = 40,
        extraVariants: Collection<String> = emptyList()
    ): List<SectionHit> = RovexPerformanceTrace.scoped("local-qbank-section-search") {
        searchSectionsInternal(query, limit, extraVariants)
    }

    private fun searchSectionsInternal(
        query: String,
        limit: Int,
        extraVariants: Collection<String>
    ): List<SectionHit> {
        val safeLimit = limit.coerceIn(1, 200)
        val normalized = ClinicalKnowledgeLayer.normalize(query)
        if (normalized.length < 2) return emptyList()
        val variants = linkedSetOf<String>().apply {
            add(normalized)
            ClinicalQueryExpansion.expand(normalized).forEach(::add)
            MedicalTaxonomyRepository.get(app).expandQuery(normalized).forEach(::add)
            extraVariants.forEach { value ->
                val v = ClinicalKnowledgeLayer.normalize(value)
                if (v.length >= 2) add(v)
            }
        }.filter { it.isNotBlank() }.take(12)
        return variants.asSequence()
            .flatMap { variant ->
                runCatching { db.searchSections(variant) }
                    .getOrDefault(emptyList())
                    .asSequence()
            }
            .distinctBy { it.testId }
            .take(safeLimit)
            .toList()
    }

    companion object {
        /** True when a short prompt is more naturally a local-corpus topic lookup than a generated explanation. */
        fun isLikelyTopicQuery(command: String): Boolean {
            val q = command.trim().lowercase()
            if (q.length < 3) return false
            val explicitInterrogative = Regex("\\b(what|which|why|how|when|where|who|explain|define|mechanism|management|treatment|diagnosis|investigation)\\b").containsMatchIn(q)
            if (explicitInterrogative) return false
            val words = q.split(Regex("\\s+")).filter { it.isNotBlank() }
            return words.size in 1..6
        }
    }

    fun ids(
        query: String,
        limit: Int = 100,
        extraVariants: Collection<String> = emptyList(),
        visualOnly: Boolean = false
    ): LongArray = search(query, limit, extraVariants, visualOnly).hits.map { it.id }.toLongArray()
}
