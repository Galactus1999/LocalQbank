package com.localqbank.library

import android.content.Context

class BenToolRegistry(private val context: Context) {
    data class Tool(val id: String, val description: String, val safeOffline: Boolean = true)

    fun tools(): List<Tool> = listOf(
        Tool("qbank_retrieval", "Search imported QBank question and explanation content"),
        Tool("clinical_retrieval", "Normalize medical concepts and expand related terminology"),
        Tool("learner_weakness", "Inspect local weak/wrong concept signals"),
        Tool("management_reasoner", "Prioritize treatment/management intent"),
        Tool("diagnostic_reasoner", "Prioritize diagnostic/investigation intent"),
        Tool("mechanism_reasoner", "Prioritize mechanism/pathophysiology intent"),
        Tool("study_planner", "Create a local adaptive study action"),
        Tool("flashcard_context", "Use existing flashcard/SRS context without auto-creating cards"),
        Tool("misconception_check", "Flag repeated local wrong-answer concept signals"),
        Tool("exam_trap_detector", "Detect common MCQ wording traps and negative stems"),
        Tool("evidence_caution", "Require source verification for dose, cutoff and guideline-sensitive claims"),
        Tool("association_reasoner", "Prioritize association/risk-factor reasoning"),
        Tool("epidemiology_reasoner", "Prioritize frequency, prevalence and commonest-pattern reasoning"),
        Tool("visual_question_retrieval", "Hard-filter QBank questions that contain actual imported images, then rank by subject/concept"),
        Tool("exam_terminology", "Interpret INI-CET/NEET-PG student shorthand, image-bank language and MCQ wording")
    )

    fun execute(toolId: String, query: String, limit: Int = 50): String? = runCatching {
        when (toolId) {
            "qbank_retrieval" -> {
                // Keep the planner/tool path on the same authoritative cognitive/search instance
                // used by visible Frankenstein and Ben+AI UI. Creating a second RenCognitiveEngine
                // here can otherwise give the impression that there are two search implementations
                // and can also duplicate terminology/index state. Tests/startup fallback may still
                // construct the deterministic engine through the outer architecture.
                val ids = if (AppManagers.isReady()) {
                    AppManagers.renCognitive.searchQuestionIds(query, limit)
                } else {
                    RenCognitiveEngine(context).searchQuestionIds(query, limit)
                }
                "Matched ${ids.size} local question(s)."
            }
            "learner_weakness" -> AppManagers.adaptive.studyStrategy()
            "study_planner" -> AppManagers.adaptive.studyStrategy()
            else -> null
        }
    }.getOrNull()
}
