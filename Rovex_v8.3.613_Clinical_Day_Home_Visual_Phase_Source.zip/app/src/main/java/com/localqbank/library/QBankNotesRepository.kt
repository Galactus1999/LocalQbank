package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import java.io.File

/** Database-backed Notes data source; QBankDb remains the compatibility facade. */
internal class QBankNotesRepository(
    private val databaseProvider: () -> SQLiteDatabase,
    private val onChanged: () -> Unit
) {
    private val db: SQLiteDatabase get() = databaseProvider()

    fun saveNote(questionId: Long, note: String) {
        val cleaned = note.trim()
        db.beginTransaction()
        try {
            if (cleaned.isBlank()) {
                val hasImages = db.rawQuery("SELECT 1 FROM question_note_image WHERE question_id=? LIMIT 1", arrayOf(questionId.toString())).use { it.moveToFirst() }
                if (hasImages) {
                    db.execSQL("INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)", arrayOf<Any?>(questionId, "", System.currentTimeMillis()))
                } else {
                    db.delete("question_note", "question_id=?", arrayOf(questionId.toString()))
                }
            } else {
                db.execSQL("INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)", arrayOf<Any?>(questionId, cleaned, System.currentTimeMillis()))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        onChanged()
    }

    fun deleteNote(questionId: Long) {
        val paths = noteImages(questionId)
        db.beginTransaction()
        try {
            db.delete("question_note", "question_id=?", arrayOf(questionId.toString()))
            db.delete("question_note_image", "question_id=?", arrayOf(questionId.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        paths.forEach { runCatching { File(it).delete() } }
        onChanged()
    }

    fun deleteNotes(questionIds: LongArray) {
        if (questionIds.isEmpty()) return
        val ids = questionIds.distinct()
        val paths = ids.flatMap { noteImages(it) }
        db.beginTransaction()
        try {
            ids.chunked(500).forEach { chunk ->
                val args = chunk.map { it.toString() }.toTypedArray()
                val placeholders = chunk.joinToString(",") { "?" }
                db.delete("question_note", "question_id IN ($placeholders)", args)
                db.delete("question_note_image", "question_id IN ($placeholders)", args)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        paths.forEach { runCatching { File(it).delete() } }
        onChanged()
    }

    fun note(questionId: Long): String? = db.rawQuery(
        "SELECT n.note FROM question_note n JOIN question q ON q.id=n.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE n.question_id=? LIMIT 1",
        arrayOf(questionId.toString())
    ).use { c -> if (c.moveToFirst()) c.getString(0) else null }

    fun notes(): List<Pair<Long, String>> = db.rawQuery(
        "SELECT n.question_id,n.note FROM question_note n JOIN question q ON q.id=n.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 ORDER BY n.updated_at DESC",
        null
    ).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0) to c.getString(1)) } }

    fun noteCount(): Int = db.rawQuery(
        "SELECT COUNT(*) FROM question_note n JOIN question q ON q.id=n.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
        null
    ).use { c -> c.moveToFirst(); c.getInt(0) }

    fun noteRecords(): List<QBankDb.NoteRecord> = db.rawQuery(
        "SELECT n.question_id,n.note,n.updated_at,COALESCE(t.id,''),COALESCE(t.path,''),COALESCE(t.title,''),COALESCE(s.display_name,s.file_name,''),q.position,COALESCE((SELECT group_concat(path, char(31)) FROM question_note_image ni WHERE ni.question_id=n.question_id), '') FROM question_note n JOIN question q ON q.id=n.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 ORDER BY n.updated_at DESC",
        null
    ).use { c -> buildList {
        while (c.moveToNext()) {
            val testId=c.getString(3).orEmpty()
            val path=c.getString(4).orEmpty()
            val title=c.getString(5).orEmpty().ifBlank { "Question ${c.getLong(0)}" }
            val sourceName=c.getString(6).orEmpty().ifBlank { "Unknown QBank" }
            val subject=path.split('/', '\\', '>', ':').map { it.trim() }.firstOrNull { it.isNotBlank() }
                ?: title.split(Regex("\\s*[-–—|:]\\s*"), limit=2).firstOrNull().orEmpty().trim().ifBlank { "General" }
            val images=c.getString(8).orEmpty().split(31.toChar()).map { it.trim() }.filter { it.isNotBlank() }
            add(QBankDb.NoteRecord(c.getLong(0),c.getString(1).orEmpty(),c.getLong(2),testId,subject,title,sourceName,c.getInt(7),images))
        }
    } }

    fun addNoteImage(questionId: Long, path: String) {
        if (path.isBlank()) return
        db.execSQL("INSERT INTO question_note_image(question_id,path,created_at) VALUES(?,?,?)", arrayOf<Any?>(questionId,path,System.currentTimeMillis()))
        onChanged()
    }

    fun noteImages(questionId: Long): List<String> = db.rawQuery(
        "SELECT ni.path FROM question_note_image ni JOIN question q ON q.id=ni.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE ni.question_id=? ORDER BY ni.created_at",
        arrayOf(questionId.toString())
    ).use { c -> buildList { while (c.moveToNext()) add(c.getString(0)) } }

    fun replaceNotes(notes: List<Pair<Long,String>>) {
        db.beginTransaction()
        try {
            db.delete("question_note", null, null)
            db.delete("question_note_image", null, null)
            val st=db.compileStatement("INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)")
            notes.forEach { (id,note) -> if(note.isNotBlank()){ st.bindLong(1,id); st.bindString(2,note); st.bindLong(3,System.currentTimeMillis()); st.executeInsert(); st.clearBindings() } }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        onChanged()
    }
}
