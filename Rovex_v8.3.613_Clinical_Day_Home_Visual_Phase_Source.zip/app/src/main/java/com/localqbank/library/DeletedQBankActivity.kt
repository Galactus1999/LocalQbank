package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Shows explicitly deleted QBanks whose physical cleanup has not completed yet. */
class DeletedQBankActivity : Activity() {
    private lateinit var list: LinearLayout
    private var loading = false
    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cardBg() = GradientDrawable().apply {
        setColor(ThemeManager.panel(this@DeletedQBankActivity)); cornerRadius = d(18).toFloat()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state); SystemUi.immersive(this); setContentView(build()); load()
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized && !loading) load() }

    private fun build(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(d(14), d(12), d(14), d(12))
        background = ThemeManager.backgroundDrawable(this@DeletedQBankActivity)
        val bar = LinearLayout(this@DeletedQBankActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(TextView(this@DeletedQBankActivity).apply {
            text = "←"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(ThemeManager.text(this@DeletedQBankActivity))
            background = GradientDrawable().apply { setColor(ThemeManager.elevated(this@DeletedQBankActivity)); cornerRadius = d(12).toFloat() }
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(d(48), d(48)))
        bar.addView(TextView(this@DeletedQBankActivity).apply {
            text = "Deleted QBanks"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@DeletedQBankActivity)); setPadding(d(12), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, d(48), 1f))
        addView(bar)
        addView(TextView(this@DeletedQBankActivity).apply {
            text = "Hidden from normal study screens while safe background cleanup is pending."
            textSize = 12.5f; setTextColor(ThemeManager.muted(this@DeletedQBankActivity)); setPadding(0, d(2), 0, d(12))
        })
        list = LinearLayout(this@DeletedQBankActivity).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this@DeletedQBankActivity).apply { addView(list); overScrollMode = View.OVER_SCROLL_NEVER }
        addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(TextView(this@DeletedQBankActivity).apply {
            text = "← BACK"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@DeletedQBankActivity)); background = GradientDrawable().apply { setColor(ThemeManager.elevated(this@DeletedQBankActivity)); cornerRadius = d(14).toFloat() }
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(-1, d(46)).apply { topMargin = d(10) })
    }

    private fun load() {
        loading = true; list.removeAllViews()
        list.addView(TextView(this).apply { text = "Checking pending cleanup…"; textSize = 14f; setTextColor(ThemeManager.muted(this@DeletedQBankActivity)); setPadding(d(8), d(20), d(8), d(20)) })
        PerformanceManager.submit {
            val rows = runCatching { MainRepository(applicationContext).use { it.pendingDeletedQBanks() } }.getOrDefault(emptyList())
            runOnUiThread { loading = false; if (!isFinishing && !isDestroyed) render(rows) }
        }
    }

    private fun render(rows: List<QBankDeletedSourceRepository.PendingDeletedQBank>) {
        list.removeAllViews()
        if (rows.isEmpty()) {
            list.addView(TextView(this).apply { text = "No deleted QBank is waiting for physical cleanup."; textSize = 15f; gravity = Gravity.CENTER; setTextColor(ThemeManager.muted(this@DeletedQBankActivity)); setPadding(d(20), d(50), d(20), d(50)) })
            return
        }
        rows.forEach { row ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(14), d(16), d(14)); background = cardBg() }
            box.addView(TextView(this).apply { text = row.name; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@DeletedQBankActivity)); maxLines = 2 })
            box.addView(TextView(this).apply { text = "${row.testCount} sections • ${row.questionCount} questions • ${row.provider.ifBlank { "Imported" }}\n${row.ageLabel} • cleanup pending"; textSize = 12f; setTextColor(ThemeManager.muted(this@DeletedQBankActivity)); setPadding(0, d(5), 0, d(10)) })
            val delete = TextView(this).apply {
                text = "DELETE PERMANENTLY NOW"; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = GradientDrawable().apply { setColor(ThemeManager.pastelRedText(this@DeletedQBankActivity)); cornerRadius = d(12).toFloat() }
                setOnClickListener { confirmPurge(row, this) }
            }
            box.addView(delete, LinearLayout.LayoutParams(-1, d(42)))
            list.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(10) })
        }
    }

    private fun confirmPurge(row: QBankDeletedSourceRepository.PendingDeletedQBank, button: TextView) {
        AlertDialog.Builder(this).setTitle("Delete permanently?")
            .setMessage("${row.name}\n\nThis permanently removes the remaining questions, sections and progress for this deleted QBank. This cannot be undone.")
            .setNegativeButton("CANCEL", null).setPositiveButton("DELETE") { _, _ ->
                button.isEnabled = false
                PerformanceManager.submitQBankDeletion {
                    val ok = runCatching { MainRepository(applicationContext).use { it.purgeDeletedQBank(row.id) } }.getOrDefault(false)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (ok) { Toast.makeText(this, "${row.name} permanently deleted.", Toast.LENGTH_SHORT).show(); AppManagers.qbankLoading.invalidate(row.id); PerformanceManager.invalidate(); load() }
                        else { button.isEnabled = true; Toast.makeText(this, "Cleanup could not finish. The QBank remains safe and hidden.", Toast.LENGTH_LONG).show() }
                    }
                }
            }.show()
    }
}
