package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.security.MessageDigest
import android.database.Cursor
import android.util.Log

private fun createQBankSchema(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS source(id INTEGER PRIMARY KEY AUTOINCREMENT, file_name TEXT UNIQUE NOT NULL, display_name TEXT, series_number TEXT, provider TEXT NOT NULL, imported_at INTEGER NOT NULL, deleting INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS test(id TEXT PRIMARY KEY, source_id INTEGER NOT NULL, title TEXT NOT NULL, path TEXT, num_questions INTEGER, total_marks REAL, duration_seconds INTEGER, time_per_question REAL, original_id TEXT, series_number TEXT, FOREIGN KEY(source_id) REFERENCES source(id) ON DELETE CASCADE)")
        ensureQBankColumn(db, "source", "display_name", "TEXT")
        ensureQBankColumn(db, "source", "series_number", "TEXT")
        ensureQBankColumn(db, "source", "deleting", "INTEGER NOT NULL DEFAULT 0")
        // `deleting` is a visibility/tombstone state. `delete_requested` records an explicit
        // user/import replacement intent so crash recovery can never mistake an old hidden
        // source for a QBank the user actually asked us to destroy.
        ensureQBankColumn(db, "source", "delete_requested", "INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_source_deleting ON source(deleting,id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_source_delete_requested ON source(delete_requested,deleting,id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_source_live_imported ON source(deleting,imported_at DESC,id)")
        ensureQBankColumn(db, "test", "series_number", "TEXT")
        db.execSQL("CREATE TABLE IF NOT EXISTS question(id INTEGER PRIMARY KEY AUTOINCREMENT, test_id TEXT NOT NULL, position INTEGER NOT NULL, source_question_id TEXT, text TEXT, raw_text TEXT, correct_answer TEXT, explanation TEXT, bot TEXT, video TEXT, audio TEXT, FOREIGN KEY(test_id) REFERENCES test(id) ON DELETE CASCADE, UNIQUE(test_id,position))")
        db.execSQL("CREATE TABLE IF NOT EXISTS option_item(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, position INTEGER NOT NULL, label TEXT, text TEXT, is_correct INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_image(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, kind TEXT NOT NULL, position INTEGER NOT NULL, uri TEXT NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_option_item_question ON option_item(question_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_image_question ON question_image(question_id,kind,position)")
        db.execSQL("CREATE TABLE IF NOT EXISTS progress(question_id INTEGER PRIMARY KEY, selected_answer TEXT, status TEXT, bookmark TEXT, review INTEGER DEFAULT 0, attempt_count INTEGER DEFAULT 0, last_attempted INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        // v2 progress store: stable-key based durable study state. The legacy `progress`
        // table is retained for backward compatibility, but all new quiz progress is written
        // transactionally here. This avoids coupling progress identity to mutable numeric IDs.
        db.execSQL("CREATE TABLE IF NOT EXISTS progress_v2(stable_key TEXT PRIMARY KEY NOT NULL, test_id TEXT, selected_answer TEXT, status TEXT, bookmark TEXT, review INTEGER DEFAULT 0, attempts INTEGER DEFAULT 0, last_attempted INTEGER DEFAULT 0, time_ms INTEGER DEFAULT 0, mistake_type TEXT, ease_factor REAL DEFAULT 2.5, repetitions INTEGER DEFAULT 0, interval_days REAL DEFAULT 0, next_due INTEGER DEFAULT 0)")
        // Durable per-attempt history. progress_v2 intentionally stores only current state; this
        // append-only ledger is the authoritative source for real daily/weekly/monthly/all-time
        // performance metrics and preserves repeated attempts instead of collapsing them.
        db.execSQL("CREATE TABLE IF NOT EXISTS study_attempt_history(id INTEGER PRIMARY KEY AUTOINCREMENT, stable_key TEXT NOT NULL, test_id TEXT NOT NULL, source_id INTEGER NOT NULL DEFAULT 0, attempted_at INTEGER NOT NULL, correct INTEGER NOT NULL, time_ms INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_study_attempt_history_key_time ON study_attempt_history(stable_key,attempted_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_study_attempt_history_time ON study_attempt_history(attempted_at)")
        db.execSQL("CREATE TABLE IF NOT EXISTS progress_meta(meta_key TEXT PRIMARY KEY NOT NULL, meta_value TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS search_index_meta(meta_key TEXT PRIMARY KEY NOT NULL, meta_value TEXT NOT NULL)")
        db.execSQL("INSERT OR IGNORE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")
        db.execSQL("INSERT OR IGNORE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending','0')")
        db.execSQL("CREATE TABLE IF NOT EXISTS study_streak(id INTEGER PRIMARY KEY CHECK(id=1), current_streak INTEGER NOT NULL DEFAULT 0, longest_streak INTEGER NOT NULL DEFAULT 0, total_study_days INTEGER NOT NULL DEFAULT 0, last_study_day TEXT, last_reminder_day TEXT, notification_prompted INTEGER NOT NULL DEFAULT 0)")
        ensureQBankColumn(db, "study_streak", "current_streak", "INTEGER NOT NULL DEFAULT 0")
        ensureQBankColumn(db, "study_streak", "longest_streak", "INTEGER NOT NULL DEFAULT 0")
        ensureQBankColumn(db, "study_streak", "total_study_days", "INTEGER NOT NULL DEFAULT 0")
        ensureQBankColumn(db, "study_streak", "last_study_day", "TEXT")
        ensureQBankColumn(db, "study_streak", "last_reminder_day", "TEXT")
        ensureQBankColumn(db, "study_streak", "notification_prompted", "INTEGER NOT NULL DEFAULT 0")
        db.execSQL("INSERT OR IGNORE INTO study_streak(id) VALUES(1)")
        ensureQBankColumn(db, "progress_v2", "test_id", "TEXT")
        val progressTestIdMigrated = db.rawQuery("SELECT meta_value FROM progress_meta WHERE meta_key='progress_v2_test_id_migrated' LIMIT 1", null).use { c -> c.moveToFirst() && c.getString(0) == "1" }
        if (!progressTestIdMigrated) {
            db.execSQL("UPDATE progress_v2 SET test_id=substr(stable_key,1,instr(stable_key,':')-1) WHERE (test_id IS NULL OR test_id='') AND instr(stable_key,':')>1")
            db.execSQL("INSERT OR REPLACE INTO progress_meta(meta_key,meta_value) VALUES('progress_v2_test_id_migrated','1')")
        }
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_progress_v2_test_status ON progress_v2(test_id,status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_progress_v2_due ON progress_v2(next_due,last_attempted)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_source ON test(source_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_test ON question(test_id,position)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_source ON question(source_question_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_note(question_id INTEGER PRIMARY KEY, note TEXT NOT NULL, updated_at INTEGER NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_note_image(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, path TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_note_image_question ON question_note_image(question_id,created_at)")
        // FTS4 keeps global search fast even for very large QBanks. Content is rebuilt lazily
        // from the normalized SQLite tables, so the 160 MB source HTML is never searched.
        try {
            db.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS question_fts USING fts4(question_id UNINDEXED, test_id UNINDEXED, source_id UNINDEXED, content)")
        } catch (_: Exception) { /* Some vendor SQLite builds may omit FTS; LIKE fallback remains available. */ }
    }
private fun ensureQBankColumn(db: SQLiteDatabase, table: String, column: String, definition: String) {
        val exists = db.rawQuery("PRAGMA table_info($table)", null).use { c ->
            var found = false
            while (c.moveToNext()) if (c.getString(1).equals(column, true)) { found = true; break }
            found
        }
        if (!exists) db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
    }
internal object QBankDatabaseProvider {
    private const val DB_NAME = "qbank.db"
    private const val DB_VERSION = 6
    @Volatile private var helper: Helper? = null
    fun resetForTest(context: Context) {
        synchronized(this) {
            runCatching { helper?.close() }
            helper = null
            context.applicationContext.deleteDatabase(DB_NAME)
        }
    }
    fun get(context: Context): SQLiteDatabase {
        val appContext = context.applicationContext
        // Only helper identity/filesystem reconciliation needs the provider monitor. Do not hold
        // the process-wide provider lock while SQLiteOpenHelper opens/configures the database:
        // SQLiteOpenHelper already serializes its own getWritableDatabase() path, and keeping the
        // outer lock across it makes unrelated QBank callers queue behind database initialization.
        val h = synchronized(this) {
            val databaseFile = appContext.getDatabasePath(DB_NAME)
            val existing = helper
            // If the database path was externally removed while SQLiteOpenHelper was still
            // open, the helper may retain an unlinked old inode. Reusing it would make a new
            // qbank.db path appear schema-less to other connections. Reconcile the helper with
            // the filesystem before handing out the shared database.
            if (existing != null && !databaseFile.exists()) {
                runCatching { existing.close() }
                helper = null
            }
            helper ?: Helper(appContext).also { helper = it }
        }
        return RovexPerformanceTrace.scoped("qbank-db-open") {
            h.writableDatabase
        }
    }
    private class Helper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onConfigure(db: SQLiteDatabase) {
            super.onConfigure(db)
            db.setForeignKeyConstraintsEnabled(true)
            db.enableWriteAheadLogging()
        }
        override fun onCreate(db: SQLiteDatabase) = createQBankSchema(db)
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = createQBankSchema(db)
    }
}

internal val qBankDatabaseProvider = QBankDatabaseProvider

