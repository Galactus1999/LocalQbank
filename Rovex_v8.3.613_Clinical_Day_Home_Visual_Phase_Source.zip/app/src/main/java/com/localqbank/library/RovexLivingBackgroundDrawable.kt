package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.SystemClock
import kotlin.math.cos
import kotlin.math.sin

/**
 * Lightweight animated atmosphere used behind the UI. It is entirely generated in-app: no
 * third-party animation/video assets are shipped. API 33+ uses an AGSL flow field; older devices
 * receive a cached Canvas fallback. Motion is intentionally subtle and pauses when detached.
 */
class RovexLivingBackgroundDrawable(
    context: Context,
    private val profile: RovexThemeProfile
) : Drawable() {
    private val app = context.applicationContext
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ribbon = Path()
    private var phase = 0f
    private var running = true
    private var shader: android.graphics.RuntimeShader? = null
    private val tick = Runnable { invalidateSelf() }
    private val particles = Array(42) { i ->
        floatArrayOf(
            ((i * 37 + 13) % 101) / 100f,
            ((i * 61 + 29) % 101) / 100f,
            .6f + ((i * 17) % 10) / 10f,
            ((i * 23) % 100) / 100f
        )
    }

    init {
        if (Build.VERSION.SDK_INT >= 33) {
            shader = runCatching { android.graphics.RuntimeShader(FLOW_SHADER) }.getOrNull()
        }
    }

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        val t = phase
        val s = shader
        if (s != null) {
            runCatching {
                s.setFloatUniform("resolution", w, h)
                s.setFloatUniform("time", t)
                s.setFloatUniform("mode", profile.scene.toFloat())
                s.setFloatUniform("motion", profile.motionAlpha)
                setShaderColor(s, "colorA", profile.backgroundA)
                setShaderColor(s, "colorB", profile.backgroundB)
                setShaderColor(s, "colorC", profile.backgroundC)
                paint.shader = s
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
            }.onFailure { drawCanvasFallback(canvas, w, h, t) }
        } else {
            drawCanvasFallback(canvas, w, h, t)
        }
        drawForeground(canvas, w, h, t)
        if (running && AnimationPolicy.enabled(app) && profile.motionAlpha > 0f) {
            phase = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f * profile.flowSpeed
            scheduleSelf(tick, SystemClock.uptimeMillis() + 33L)
        }
    }

    private fun setShaderColor(shader: android.graphics.RuntimeShader, name: String, color: Int) {
        shader.setFloatUniform(name, Color.red(color) / 255f, Color.green(color) / 255f, Color.blue(color) / 255f, Color.alpha(color) / 255f)
    }

    private fun drawCanvasFallback(canvas: Canvas, w: Float, h: Float, t: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, 0f, w, h, profile.backgroundA, profile.backgroundB, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
        val r = minOf(w, h)
        val x1 = w * (.18f + .08f * sin(t * 1.3f))
        val y1 = h * (.22f + .07f * cos(t * 1.1f))
        glow(canvas, x1, y1, r * .48f, profile.accent, 35)
        glow(canvas, w * (.78f + .06f * cos(t)), h * (.68f + .05f * sin(t * .8f)), r * .55f, profile.accentSecondary, 24)
        drawRibbons(canvas, w, h, t)
    }

    private fun drawForeground(canvas: Canvas, w: Float, h: Float, t: Float) {
        val r = minOf(w, h)
        when (profile.scene) {
            0 -> { // Clinical daylight: glassy sun halo + tiny motes.
                glow(canvas, w * (.82f + .025f * sin(t)), h * .13f, r * .16f, Color.rgb(255, 218, 130), 36)
                motes(canvas, w, h, t, 18, profile.accent, 34)
            }
            1 -> { // Pastel prism: iridescent bubbles and soft ribbons.
                bubbles(canvas, w, h, t, profile.accent, profile.accentSecondary)
                drawRibbons(canvas, w, h, t + 1.3f)
            }
            2 -> { // Mint: botanical glass / water particles.
                bubbles(canvas, w, h, t * .75f, Color.rgb(0, 190, 165), Color.rgb(75, 160, 255))
                leafVeins(canvas, w, h, t)
            }
            3 -> { // Sunset: low sun, warm haze, slow cloud bands.
                glow(canvas, w * (.78f + .02f * sin(t)), h * .28f, r * .24f, Color.rgb(255, 196, 92), 62)
                cloudBands(canvas, w, h, t)
            }
            4 -> { // Iris: aurora curtains.
                aurora(canvas, w, h, t, profile.accent, profile.accentSecondary)
                motes(canvas, w, h, t, 24, profile.accentSecondary, 40)
            }
            5 -> { // OLED: almost-black, sparse premium glow.
                motes(canvas, w, h, t, 18, profile.accent, 55)
                glow(canvas, w * .83f, h * .14f, r * .09f, profile.accent, 38)
            }
            6 -> { // Pandora: living bioluminescence.
                aurora(canvas, w, h, t, profile.accent, profile.accentSecondary)
                motes(canvas, w, h, t, 34, profile.accentSecondary, 80)
                leafVeins(canvas, w, h, t * .55f)
            }
            else -> { // Space: nebular glow + drifting stars + comet.
                motes(canvas, w, h, t, 54, Color.rgb(190, 220, 255), 90)
                planetGlow(canvas, w, h, t)
            }
        }
    }

    private fun drawRibbons(c: Canvas, w: Float, h: Float, t: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = minOf(w, h) * .018f
        paint.shader = LinearGradient(0f, 0f, w, h, profile.accent, profile.accentSecondary, Shader.TileMode.MIRROR)
        for (i in 0..2) {
            ribbon.reset()
            val y = h * (.25f + i * .23f)
            ribbon.moveTo(-w * .1f, y)
            ribbon.cubicTo(w * .18f, y - h * (.10f + .025f * sin(t + i)), w * .58f, y + h * (.12f * cos(t * .8f + i)), w * 1.08f, y - h * .04f)
            c.drawPath(ribbon, paint)
        }
        paint.shader = null
        paint.style = Paint.Style.FILL
    }

    private fun aurora(c: Canvas, w: Float, h: Float, t: Float, a: Int, b: Int) {
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = minOf(w, h) * .045f
        paint.shader = LinearGradient(0f, 0f, w, h, Color.argb(55, Color.red(a), Color.green(a), Color.blue(a)), Color.argb(0, Color.red(b), Color.green(b), Color.blue(b)), Shader.TileMode.CLAMP)
        for (i in 0..2) {
            ribbon.reset()
            val x = w * (.16f + i * .31f)
            ribbon.moveTo(x, h * .05f)
            ribbon.cubicTo(x - w * .12f, h * .34f, x + w * .14f, h * .55f, x - w * .04f, h * .96f)
            c.drawPath(ribbon, paint)
        }
        paint.shader = null
        paint.style = Paint.Style.FILL
    }

    private fun cloudBands(c: Canvas, w: Float, h: Float, t: Float) {
        paint.style = Paint.Style.FILL
        for (i in 0..3) {
            val y = h * (.40f + i * .10f) + sin(t * .7f + i) * h * .012f
            val alpha = 20 + i * 7
            paint.color = Color.argb(alpha, 255, 180, 135)
            c.drawOval(w * (-.15f + i * .22f), y, w * (.58f + i * .22f), y + h * .08f, paint)
        }
    }

    private fun leafVeins(c: Canvas, w: Float, h: Float, t: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = minOf(w, h) * .004f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.argb(35, Color.red(profile.accent), Color.green(profile.accent), Color.blue(profile.accent))
        for (i in 0..5) {
            val x = w * (.05f + i * .19f)
            c.drawArc(x - w * .08f, h * (.62f + .03f * sin(t + i)), x + w * .08f, h * (.88f + .02f * cos(t + i)), 195f, 150f, false, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun bubbles(c: Canvas, w: Float, h: Float, t: Float, a: Int, b: Int) {
        paint.style = Paint.Style.STROKE
        for (i in 0..13) {
            val x = ((i * 47) % 100) / 100f * w + sin(t * .5f + i) * w * .012f
            val y = (1f - ((t * .015f + i * .083f) % 1f)) * h
            val r = minOf(w, h) * (.008f + (i % 4) * .003f)
            paint.strokeWidth = r * .18f
            paint.color = Color.argb(32 + (i % 4) * 8, Color.red(a), Color.green(b), Color.blue(a))
            c.drawCircle(x, y, r, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun motes(c: Canvas, w: Float, h: Float, t: Float, count: Int, color: Int, alpha: Int) {
        paint.style = Paint.Style.FILL
        for (i in 0 until count) {
            val x = ((i * 47 + 11) % 101) / 100f * w + sin(t * .65f + i * 1.7f) * w * .006f
            val y = ((i * 71 + 17) % 101) / 100f * h + cos(t * .42f + i * .9f) * h * .004f
            val pulse = .35f + .65f * ((sin(t * 1.7f + i) + 1f) * .5f)
            paint.color = Color.argb((alpha * pulse).toInt().coerceIn(0,255), Color.red(color), Color.green(color), Color.blue(color))
            c.drawCircle(x, y, minOf(w,h) * (.0015f + .0018f * pulse), paint)
        }
    }

    private fun planetGlow(c: Canvas, w: Float, h: Float, t: Float) {
        val r = minOf(w,h) * .14f
        val x = w * (.72f + .015f * sin(t * .25f))
        val y = h * (.62f + .010f * cos(t * .22f))
        glow(c, x, y, r * 1.8f, profile.accent, 40)
        paint.shader = RadialGradient(x - r*.28f, y - r*.35f, r, Color.argb(235, 130, 185, 255), Color.argb(0, 12, 28, 100), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r * .035f
        paint.color = Color.argb(90, 180, 215, 255)
        c.drawOval(x-r*1.55f, y-r*.30f, x+r*1.55f, y+r*.30f, paint)
        paint.style = Paint.Style.FILL
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int, alpha: Int) {
        glowPaint.shader = RadialGradient(x, y, r,
            intArrayOf(Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)), Color.argb(alpha / 3, Color.red(color), Color.green(color), Color.blue(color)), Color.TRANSPARENT),
            floatArrayOf(0f, .42f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, glowPaint)
        glowPaint.shader = null
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter }
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        running = visible
        if (visible && restart) phase = 0f
        return super.setVisible(visible, restart)
    }
    override fun onBoundsChange(bounds: android.graphics.Rect) { super.onBoundsChange(bounds) }

    companion object {
        private const val FLOW_SHADER = """
            uniform float2 resolution;
            uniform float time;
            uniform float mode;
            uniform float motion;
            uniform float4 colorA;
            uniform float4 colorB;
            uniform float4 colorC;

            half noise(float2 p) {
                return fract(sin(dot(p, float2(127.1, 311.7))) * 43758.5453);
            }
            half4 main(float2 fragCoord) {
                float2 uv = fragCoord / resolution;
                float t = time * 0.12;
                float wave = sin((uv.x * 4.2 + sin(uv.y * 5.1 + t) * .45) + t * 2.1);
                float wave2 = sin((uv.y * 6.0 - t * 1.5) + sin(uv.x * 3.0 + t) * .7);
                float blend = smoothstep(-1.0, 1.0, .58 * wave + .42 * wave2);
                float haze = smoothstep(.05, .95, uv.y) * .18;
                float grain = (noise(uv * 18.0 + t) - .5) * .018;
                half3 base = mix(colorA.rgb, colorB.rgb, blend * (.42 + motion * .35));
                base = mix(base, colorC.rgb, smoothstep(.25, .95, uv.x + wave2 * .12) * (.16 + motion * .22));
                base += half3(grain + haze);
                if (mode >= 5.0) {
                    float edge = smoothstep(.0, .8, 1.0 - uv.y);
                    base *= (.82 + .18 * edge);
                }
                return half4(clamp(base, 0.0, 1.0), 1.0);
            }
        """
    }
}
