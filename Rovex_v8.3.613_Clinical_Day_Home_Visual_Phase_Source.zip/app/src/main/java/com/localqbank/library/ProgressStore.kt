package com.localqbank.library

import android.content.Context

class ProgressStore(context: Context) : ProgressRepository, AutoCloseable {
    private val appContext = context.applicationContext
    private val db = ProgressDbRegistry.get(appContext)
    private val legacyPrefs = appContext.getSharedPreferences("progress", Context.MODE_PRIVATE)
    private val migrationKey = "__sqlite_progress_v2_migrated"
    private val fields = setOf("answer", "status", "bookmark", "review", "attempts", "lastAttempted", "timeMs", "mistake", "ef", "reps", "intervalDays", "nextDue")

    init { synchronized(db) { migrateLegacyIfNeeded() } }

    private fun key(id:String,s:String)=id+":"+s
    private fun changed(cloud:Boolean=true){
        PerformanceManager.invalidateProgress()
        AppState.changed()
        BackupManager(appContext).onProgressChanged(cloud)
    }

    private fun stored(id: String): QBankDb.StoredProgress = db.readStoredProgress(id)
        ?: QBankDb.StoredProgress(null,null,null,false,0,0L,0L,null,2.5f,0,0f,0L)

    override fun selected(id:String)=stored(id).selected
    override fun status(id:String)=stored(id).status
    override fun bookmark(id:String)=stored(id).bookmark
    override fun review(id:String)=stored(id).review
    override fun position(testId:String):Int=db.getProgressMeta(key(testId,"position"))?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    override fun sourceResume(sourceId:Long):String?=db.getProgressMeta("source:$sourceId:resume")
    override fun sourceResumeByName(sourceName:String):String?=db.getProgressMeta("sourceName:${sourceName}:resume")

    override fun setPosition(testId:String,position:Int,sourceId:Long,sourceName:String?){
        val value=position.coerceAtLeast(0)
        db.beginProgressMetaTransaction(testId, value, sourceId, sourceName)
        changed(false)
    }

    override fun clearCompletion(testId:String){
        if(testId.isBlank()) return
        synchronized(db) { db.putProgressMeta("${testId}:completed", "0") }
    }

    override fun easeFactor(id:String)=stored(id).easeFactor
    override fun repetitions(id:String)=stored(id).repetitions
    override fun intervalDays(id:String)=stored(id).intervalDays
    override fun nextDue(id:String)=stored(id).nextDue
    override fun allProgressKeys():Set<String> = synchronized(db) { db.allStoredProgress().keys }

    override fun setAnswer(id:String,answer:String,status:String){
        synchronized(db) {
        val previous=stored(id)
        val result=SpacedRepetitionScheduler.schedule(
            SpacedRepetitionScheduler.ScheduleInput(
                correct=status=="correct", easeFactor=previous.easeFactor,
                repetitions=previous.repetitions, previousIntervalDays=previous.intervalDays
            ), now=System.currentTimeMillis()
        )
        val answeredAt = System.currentTimeMillis()
        db.writeStoredProgress(id, previous.copy(
            selected=answer, status=status, attempts=previous.attempts+1,
            lastAttempted=answeredAt, easeFactor=result.easeFactor,
            repetitions=result.repetitions, intervalDays=result.intervalDays, nextDue=result.nextDueAt
        ))
        val answerTestId = id.substringBefore(':').takeIf { it.isNotBlank() }.orEmpty()
        db.recordStudyAttempt(id, answerTestId, db.sourceIdForTest(answerTestId), answeredAt, status == "correct")
        // Every accepted answer is also a durable resume checkpoint. The resume cursor is the
        // NEXT question, not the question just answered. This closes the old half-solved-QBank
        // bug when the user answers Q42 and leaves before pressing Next.
        val first = id.indexOf(':')
        val second = id.indexOf(':', first + 1)
        if (first > 0 && second > first) {
            val resumeTestId = id.substring(0, first)
            val answeredPosition = id.substring(first + 1, second).toIntOrNull()
            if (!resumeTestId.isNullOrBlank() && answeredPosition != null) {
                val test = db.testById(resumeTestId)
                val nextPosition = if (test != null && test.count > 0) (answeredPosition + 1).coerceAtMost(test.count - 1) else answeredPosition
                val sourceId = db.sourceIdForTest(resumeTestId)
                val sourceName = db.sourceNameForTest(resumeTestId)
                val solvedAt = System.currentTimeMillis()
                db.beginProgressMetaTransaction(resumeTestId, nextPosition, sourceId, sourceName, resumeSavedAt = solvedAt)
                db.putProgressMeta("last_solved_global", "$resumeTestId|$answeredPosition|$sourceId|$solvedAt")
                if (test != null && answeredPosition >= test.count - 1) {
                    db.putProgressMeta("${resumeTestId}:completed", "1")
                } else {
                    db.putProgressMeta("${resumeTestId}:completed", "0")
                }
            }
        }
        changed()
        }
    }

    override fun isDue(id:String):Boolean{
        val x=stored(id); if(x.status==null)return true
        if(x.lastAttempted==0L)return true
        if(x.nextDue>0L)return System.currentTimeMillis()>=x.nextDue
        val day=86_400_000L
        return System.currentTimeMillis()-x.lastAttempted>=when(x.attempts){1->day;2->3*day;3->7*day;4->14*day;else->30*day}
    }
    override fun isScheduledDue(id:String):Boolean{
        val x=stored(id); if(x.status.isNullOrBlank())return false
        if(x.nextDue>0L)return System.currentTimeMillis()>=x.nextDue
        if(x.lastAttempted<=0L)return false
        val day=86_400_000L
        return System.currentTimeMillis()-x.lastAttempted>=when(x.attempts){1->day;2->3*day;3->7*day;4->14*day;else->30*day}
    }
    override fun attempts(id:String)=stored(id).attempts
    override fun lastAttempted(id:String)=stored(id).lastAttempted
    override fun timeMs(id:String)=stored(id).timeMs
    override fun mistakeType(id:String)=stored(id).mistake
    override fun setMistakeType(id:String,value:String?){ synchronized(db) { db.writeStoredProgress(id,stored(id).copy(mistake=value?.takeIf{it.isNotBlank()})) }; changed() }
    override fun addTime(id:String,elapsedMs:Long){
        if(elapsedMs<=0L)return
        synchronized(db) {
            val x=stored(id)
            db.writeStoredProgress(id,x.copy(timeMs=x.timeMs+elapsedMs))
            db.updateLatestStudyAttemptTime(id, elapsedMs)
        }
        changed(false)
    }
    override fun setBookmark(id:String,value:String?){
        synchronized(db) { db.writeStoredProgress(id,stored(id).copy(bookmark=value?.takeIf{it.isNotBlank()})) }
        changed()
    }
    override fun setReview(id:String,value:Boolean){
        synchronized(db) { db.writeStoredProgress(id,stored(id).copy(review=value)) }
        changed()
    }
    override fun clear(id:String){ synchronized(db) { db.deleteStoredProgress(id) }; changed() }

    /** Export-compatible view. Values retain the old key names so existing backup format stays stable. */
    override fun allEntries():Map<String,*> = synchronized(db) { buildMap {
        db.allStoredProgress().forEach { (id,x) ->
            x.selected?.let { put(key(id,"answer"),it) }; x.status?.let { put(key(id,"status"),it) }
            x.bookmark?.let { put(key(id,"bookmark"),it) }; if(x.review) put(key(id,"review"),true)
            if(x.attempts>0) put(key(id,"attempts"),x.attempts); if(x.lastAttempted>0) put(key(id,"lastAttempted"),x.lastAttempted)
            if(x.timeMs>0) put(key(id,"timeMs"),x.timeMs); x.mistake?.let { put(key(id,"mistake"),it) }
            put(key(id,"ef"),x.easeFactor); put(key(id,"reps"),x.repetitions); put(key(id,"intervalDays"),x.intervalDays); put(key(id,"nextDue"),x.nextDue)
        }
        putAll(db.allProgressMeta())
    } }

    override fun restore(entries:Map<String,*>){
        restoreInternal(entries, notify=true)
    }

    /** Backup restore uses this to avoid publishing an intermediate state before notes/UI/flashcards commit. */
    internal fun restoreSilently(entries:Map<String,*>) { restoreInternal(entries, notify=false) }

    private fun restoreInternal(entries:Map<String,*>, notify:Boolean){
        synchronized(db) {
            val grouped=HashMap<String,MutableMap<String,Any?>>()
            val meta=HashMap<String,String>()
            entries.forEach { (full,value) ->
                val suffix=full.substringAfterLast(":","")
                if(suffix in fields){ val id=full.substringBeforeLast(":"); grouped.getOrPut(id){HashMap()}[suffix]=value }
                else if(suffix=="position" || full.startsWith("source:") || full.startsWith("sourceName:") || full==migrationKey) meta[full]=value?.toString().orEmpty()
            }
            val out=grouped.mapValues { (_,m) ->
                fun str(k:String)=m[k] as? String
                fun long(k:String)=when(val v=m[k]){is Long->v;is Int->v.toLong();is Float->v.toLong();is Double->v.toLong();is Number->v.toLong();else->0L}
                fun int(k:String)=long(k).toInt()
                fun float(k:String,default:Float)=when(val v=m[k]){is Number->v.toFloat();else->default}
                QBankDb.StoredProgress(str("answer"),str("status"),str("bookmark"),m["review"]==true,int("attempts"),long("lastAttempted"),long("timeMs"),str("mistake"),float("ef",2.5f),int("reps"),float("intervalDays",0f),long("nextDue"))
            }
            db.replaceStoredProgress(out,meta)
        }
        if(notify) changed()
    }

    private fun migrateLegacyIfNeeded(){
        if(db.getProgressMeta(migrationKey)=="1") return
        val entries=legacyPrefs.all
        if(entries.isNotEmpty()) restoreInternal(entries, notify=false)
        db.putProgressMeta(migrationKey,"1")
        // Keep the legacy preferences intact for one release as a rollback/source-of-truth snapshot.
        // New writes never touch them. They can be removed in a later cleanup release after backup validation.
    }

    // The SQLite handle is process-scoped because ProgressStore is used by multiple authoritative
    // managers and Activities. Closing one repository instance must never invalidate another.
    override fun close() = Unit
}


