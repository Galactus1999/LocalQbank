package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Chat-first Dr. Frankenstein workspace. Detailed diagnostics live in Model Lab / Adaptive Engine. */
class RenActivity : Activity() {
    private var openMatchButton: TextView? = null
    private var liveStatus: TextView? = null
    private val liveScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var liveJob: Job? = null
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        setContentView(build())
    }

    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            setBackgroundColor(ThemeManager.bg(this@RenActivity))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(42), dp(48)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6),0,dp(6),0) }
        titleBox.addView(TextView(this).apply { text="Dr. Frankenstein"; textSize=22f; typeface=Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@RenActivity)) })
        titleBox.addView(TextView(this).apply { text="Local study intelligence"; textSize=11f; setTextColor(ThemeManager.muted(this@RenActivity)) })
        header.addView(titleBox, LinearLayout.LayoutParams(0,-2,1f))
        val lab = TextView(this).apply {
            text = "MODEL LAB"; textSize=10.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.text(this@RenActivity)); background=rounded(ThemeManager.elevated(this@RenActivity),12)
            setPadding(dp(10),0,dp(10),0); setOnClickListener { startActivity(Intent(this@RenActivity, BenModelLabActivity::class.java)) }
        }
        header.addView(lab, LinearLayout.LayoutParams(dp(88),dp(36)))
        root.addView(header)

        val modelPill = TextView(this).apply {
            text = modelStatus(); textSize=11f; gravity=Gravity.CENTER_VERTICAL
            setTextColor(ThemeManager.muted(this@RenActivity)); setPadding(dp(10),0,dp(10),0)
            background=rounded(ThemeManager.elevated(this@RenActivity),11)
        }
        root.addView(modelPill, LinearLayout.LayoutParams(-1,dp(34)).apply{setMargins(dp(4),dp(4),dp(4),dp(8))})

        val answerScroll = ScrollView(this).apply { isFillViewport=true; clipToPadding=false }
        val answer = TextView(this).apply {
            text="Ask anything about your QBank, a medical concept, an explanation, or your study plan."
            textSize=16f; setTextColor(ThemeManager.text(this@RenActivity)); setPadding(dp(16),dp(16),dp(16),dp(18))
            background=rounded(ThemeManager.elevated(this@RenActivity),18)
            gravity=Gravity.TOP
        }
        answerScroll.addView(answer, android.widget.FrameLayout.LayoutParams(-1,-2))
        root.addView(answerScroll, LinearLayout.LayoutParams(-1,0,1f))

        liveStatus = TextView(this).apply {
            text="BEN • READY"; textSize=10.5f; setTextColor(ThemeManager.muted(this@RenActivity)); setPadding(dp(4),dp(5),dp(4),dp(5))
        }
        root.addView(liveStatus, LinearLayout.LayoutParams(-1,dp(28)))

        val input = EditText(this).apply {
            hint="Ask Dr. Frankenstein…"; textSize=15f; setTextColor(ThemeManager.text(this@RenActivity)); setHintTextColor(ThemeManager.muted(this@RenActivity))
            setSingleLine(false); minLines=2; maxLines=5; gravity=Gravity.TOP; setPadding(dp(14),dp(12),dp(14),dp(12))
            background=rounded(ThemeManager.elevated(this@RenActivity),16)
        }
        root.addView(input, LinearLayout.LayoutParams(-1,dp(78)).apply{setMargins(0,dp(2),0,dp(8))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        openMatchButton=TextView(this).apply{ text="MATCH"; textSize=11f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); visibility=View.GONE; background=rounded(ThemeManager.accent(this@RenActivity),13) }
        row.addView(openMatchButton,LinearLayout.LayoutParams(dp(86),dp(46)).apply{setMargins(0,0,dp(8),0)})
        val ask=TextView(this).apply{ text="ASK BEN"; textSize=13f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=rounded(ThemeManager.accent(this@RenActivity),14); setOnClickListener{respond(input,answer,modelPill)} }
        row.addView(ask,LinearLayout.LayoutParams(0,dp(46),1f))
        root.addView(row)
        return root
    }

    private fun modelStatus(): String {
        val m=BenNeuralModelManager(this)
        val e=m.installed(BenNeuralModelRegistry.embeddingGemma300m)!=null
        val g=m.installed(BenNeuralModelRegistry.gemma3_270m)!=null
        return when { e&&g -> "Neural: EmbeddingGemma + Gemma 3 270M ready"; e -> "Neural: EmbeddingGemma installed • generation fallback"; g -> "Neural: Gemma 3 270M installed • semantic fallback"; else -> "Neural: models not installed • deterministic Ben ready" }
    }

    private fun respond(input:EditText,answer:TextView,modelPill:TextView){
        val cmd=input.text?.toString().orEmpty().trim()
        openMatchButton?.visibility=View.GONE
        if(cmd.isBlank()){answer.text="Ask Ben a question first.";return}
        AppManagers.renMemory.putWorking(cmd)
        answer.text="Ben is working…"
        liveJob?.cancel()
        liveJob=liveScope.launch{
            while(isActive){
                val t=BenNeuralTelemetry.snapshot()
                val gov=BenAiResourceGovernor(this@RenActivity).snapshot(foreground=true)
                liveStatus?.text="BEN • ${t.stage.name.replace('_',' ')} • ${t.stageDetail}"
                modelPill.text="${t.activeModel} • RAM ${gov.availableMemoryMb} MB • thermal ${gov.thermalStatus}"
                if(t.stage==BenNeuralTelemetry.Stage.COMPLETE||t.stage==BenNeuralTelemetry.Stage.FALLBACK||t.stage==BenNeuralTelemetry.Stage.ERROR||t.stage==BenNeuralTelemetry.Stage.BLOCKED) break
                delay(180L)
            }
        }
        AppManagers.frankensteinSupport.respond(cmd){ insight, ids ->
            runOnUiThread{
                liveJob?.cancel()
                val t=BenNeuralTelemetry.snapshot()
                liveStatus?.text="BEN • ${if(t.lastGeneratorUsed||t.lastSemanticUsed) "NEURAL" else "DETERMINISTIC FALLBACK"} • ${t.lastElapsedMs} ms"
                modelPill.text="${t.activeModel} • evidence ${t.lastEvidenceCount} • verifier ${if(t.lastVerified) "PASS" else "REVIEW"}"
                if(isFinishing||isDestroyed)return@runOnUiThread
                answer.text=insight.body
                if(insight.actions.contains("Open matching questions")&&ids.isNotEmpty()){
                    openMatchButton?.visibility=View.VISIBLE
                    val query=cmd.replace(Regex("(?i)\\b(find|search|show|give|open|questions?|qbank|topic|subject|about)\\b")," ").replace(Regex("\\s+")," ").trim()
                    openMatchButton?.setOnClickListener{startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Dr. Frankenstein • $query").putExtra("practiceMode",true).putExtra("title","Dr. Frankenstein • $query"))}
                }
                AppManagers.renMemory.putStudy(answer.text.toString())
            }
        }
    }

    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
    override fun onDestroy(){liveJob?.cancel();liveScope.cancel();super.onDestroy()}
}
