package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max

/**
 * Compact 28-day study history visual. Each column is a study day, height is solved volume,
 * the dot marks the day's accuracy, and the footer shows the date. It only renders data that
 * exists in the local progress snapshot; missing history is deliberately shown as an empty day.
 */
class Last28StudyDaysGraphView(context: Context) : View(context) {
    data class Day(val dayStart: Long, val solved: Int, val correct: Int)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private var days: List<Day> = emptyList()
    private var maxSolved = 1

    fun setDays(value: List<Day>) {
        days = value.takeLast(28)
        maxSolved = max(1, days.maxOfOrNull { it.solved } ?: 1)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val left = 14f*d
        val right = (width - 10f*d).coerceAtLeast(left + 1f)
        val top = 18f*d
        val bottom = (height - 26f*d).coerceAtLeast(top + 1f)
        val gap = 7f*d
        val slot = ((right-left) / 28f).coerceAtLeast(3f)
        val barW = (slot-gap).coerceAtLeast(2f)
        val accent = ThemeManager.accent(context)
        val dark = ThemeManager.isDark(context)

        line.color = Color.argb(if(dark)55 else 42, Color.red(accent), Color.green(accent), Color.blue(accent))
        c.drawLine(left, bottom, right, bottom, line)
        c.drawLine(left, top + (bottom-top)*.5f, right, top + (bottom-top)*.5f, line)

        days.forEachIndexed { i, day ->
            val x = left + i*slot + gap*.5f
            val h = (bottom-top) * (day.solved.toFloat()/maxSolved.toFloat())
            bar.color = if(day.solved==0) {
                Color.argb(if(dark)28 else 24, Color.red(accent), Color.green(accent), Color.blue(accent))
            } else {
                Color.argb(if(dark)115 else 75, Color.red(accent), Color.green(accent), Color.blue(accent))
            }
            c.drawRoundRect(x, bottom-h, x+barW, bottom, barW*.35f, barW*.35f, bar)
            if(day.solved>0) {
                val acc = (day.correct*100f/day.solved).coerceIn(0f,100f)
                val y = bottom - (bottom-top)*acc/100f
                dot.color = if(acc>=75f) Color.rgb(62,210,165) else if(acc>=50f) Color.rgb(255,193,73) else Color.rgb(255,102,137)
                c.drawCircle(x+barW/2f,y,3.2f*d,dot)
            } else {
                dot.color = Color.argb(if(dark)100 else 70, Color.red(accent), Color.green(accent), Color.blue(accent))
                c.drawCircle(x+barW/2f,bottom-2f*d,1.7f*d,dot)
            }
        }

        text.color = ThemeManager.muted(context)
        text.textSize = 8f*d
        text.textAlign = Paint.Align.CENTER
        val labels = listOf(0,6,13,20,27)
        labels.forEach { i ->
            if(i < days.size) {
                val cal = java.util.Calendar.getInstance().apply { timeInMillis = days[i].dayStart }
                val label = "${cal.get(java.util.Calendar.DAY_OF_MONTH)}"
                c.drawText(label, left+i*slot+slot/2f, height-8f*d, text)
            }
        }
        text.textAlign = Paint.Align.LEFT
        c.drawText("SOLVED", left, 10f*d, text)
        text.textAlign = Paint.Align.RIGHT
        c.drawText("DOT = ACCURACY", right, 10f*d, text)
    }
}
