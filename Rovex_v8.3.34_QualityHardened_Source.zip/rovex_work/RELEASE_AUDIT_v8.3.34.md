# Rovex v8.3.34 Release Audit

## Baseline
- Continuation source: v8.3.33 CI-compile-fix source supplied for this release.
- Update is in-place; applicationId unchanged.
- v8.3.33 remains a historical source-audited candidate; this release increments monotonically to versionCode 132.

## v8.3.34 quality hardening
- Added `SrsScheduler`, a pure deterministic policy component containing the existing SM-2-style scheduling calculation.
- `QBankDb.ProgressStore` remains authoritative for persistence and still owns the user progress keys.
- Rewired `ProgressStore.setAnswer()` to call `SrsScheduler`; behavior is intentionally preserved rather than redesigned.
- Added JVM unit tests for the scheduling boundary cases and invalid timestamp input.
- Added CI execution of `testDebugUnitTest` before APK assembly.
- Added CI source checks requiring the scheduler test file to exist.
- Corrected the previously reported `MainActivity.kt` `dp(...)` invocation conflict in the QBank long-press action sheet by using an explicit context-aware helper.
- Updated current README/release metadata to v8.3.34 / versionCode 132.

## Build identity
- applicationId: `com.localqbank.library`
- versionName: `8.3.34`
- versionCode: `132`
- compileSdk: `37`
- targetSdk: `36`
- JDK: `17`
- Gradle: `9.3.1`
- zstd dependency: `com.github.luben:zstd-jni:1.5.7-16@aar`

## Static/source audit
- XML parsing: PASS
- Duplicate IDs within individual XML layout: PASS
- `findViewById<T>()` ↔ XML widget compatibility: PASS
- Broad `Throwable` catch scan: PASS
- `Thread.sleep` / `runBlocking` / `GlobalScope`: PASS
- `killProcess`: PASS
- Native Android text autosizing regression: PASS
- Unsafe `execSQL("PRAGMA ...")`: PASS
- Automatic wrong-answer → flashcard regression: PASS
- Package/version identity: PASS
- Zstandard Android AAR requirement: PASS
- Persistent signing fingerprint assertion present in CI: PASS
- Private signing/provenance keys absent from source tree: PASS
- SRS scheduler source compilation with standalone Kotlin compiler: PASS
- SRS deterministic behavior smoke checks: PASS
- JVM test source present and wired to CI: PASS

## Runtime-risk audit
- Existing Activity startup paths were re-scanned.
- Newly touched `MainActivity` long-press code uses the explicit context-aware density helper.
- SRS persistence remains in `ProgressStore`; no new database or progress owner was introduced.
- No UI-thread blocking primitive was introduced.
- Existing authoritative managers/engines were preserved.
- Existing importer, flashcard, Notes, theme, bird, splash, and Dr. Frankenstein functionality was not replaced or duplicated.

## Compilation
A full Android Gradle build cannot be verified locally because the environment cannot resolve `services.gradle.org`. The pure Kotlin `SrsScheduler` source was compiled independently and its deterministic smoke checks passed. **This does not constitute Android APK build verification.** GitHub Actions remains authoritative.

## CI requirements
CI must successfully complete:
1. static/source audits;
2. `testDebugUnitTest`;
3. `assembleDebug`;
4. ARM64 zstd library assertion for `lib/arm64-v8a/libzstd-jni-1.5.7-16.so`;
5. actual APK certificate SHA-256 fingerprint validation against the persistent Rovex certificate;
6. artifact upload.

## Signing
The workflow retains the persistent certificate check:
`8D:EC:BE:AC:90:6A:40:54:6B:33:2F:35:62:93:13:EF:6B:A6:86:0D:10:06:AA:D0:7B:76:15:38:22:8C:01:53`

No private signing key is stored in the source.

## Provenance
A new Ed25519 provenance signature is not fabricated in this environment. The secure CI/release environment must regenerate/sign the v8.3.34 provenance record using the private provenance key held outside the source tree.

**Release status: source-audited candidate pending authoritative CI Android compilation, APK verification, and secure provenance signing.**
