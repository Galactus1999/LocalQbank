# Rovex v8.3.34

Android application: `com.localqbank.library`

This source is an in-place continuation of the audited Rovex v8.3.33 source. It preserves the existing database, SRS progress, notes, flashcards, settings, importer, adaptive engines, and local-first architecture.

Build identity: versionCode 132 / versionName 8.3.34.

## Quality hardening

This release adds a pure, deterministic `SrsScheduler` policy layer around the existing SM-2-style scheduling behavior. `QBankDb` remains the authoritative persistence layer; no second progress system was introduced. The scheduler now has JVM unit tests covering first review, six-day second review, interval/ease growth, miss reset, minimum ease, and invalid timestamps.

The previous v8.3.33 `MainActivity` long-press action-sheet Kotlin `dp(...)` compile error is also corrected.

GitHub Actions is the authoritative Android compiler because local Gradle distribution download is unavailable in the current environment. No APK build is claimed unless CI actually completes compilation and artifact verification.
