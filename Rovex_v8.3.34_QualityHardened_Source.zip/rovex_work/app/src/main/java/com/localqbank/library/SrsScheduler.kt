package com.localqbank.library

/**
 * Pure, deterministic SM-2-style scheduling policy used by Rovex progress storage.
 *
 * Keeping the policy independent from Android/SharedPreferences makes the core scheduling
 * behavior unit-testable without changing the persistence layer or introducing a second
 * progress system.
 */
object SrsScheduler {
    const val DAY_MS = 86_400_000L
    const val MIN_EASE = 1.3f

    data class State(
        val easeFactor: Float = 2.5f,
        val repetitions: Int = 0,
        val intervalDays: Float = 0f,
    )

    data class Result(
        val easeFactor: Float,
        val repetitions: Int,
        val intervalDays: Float,
        val nextDue: Long,
    )

    fun schedule(state: State, correct: Boolean, nowMs: Long): Result {
        require(nowMs >= 0L) { "nowMs must be non-negative" }
        val quality = if (correct) 5 else 2
        var ef = state.easeFactor
        var reps = state.repetitions
        val previousInterval = state.intervalDays
        val interval: Float

        if (quality < 3) {
            reps = 0
            interval = 1f
        } else {
            reps += 1
            interval = when (reps) {
                1 -> 1f
                2 -> 6f
                else -> (if (previousInterval > 0f) previousInterval else 6f) * ef
            }
        }

        ef = (ef + (0.1f - (5 - quality) * (0.08f + (5 - quality) * 0.02f)))
            .coerceAtLeast(MIN_EASE)

        return Result(
            easeFactor = ef,
            repetitions = reps,
            intervalDays = interval,
            nextDue = nowMs + (interval * DAY_MS).toLong(),
        )
    }
}
