package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SrsSchedulerTest {
    private val now = 1_000_000L

    @Test
    fun firstCorrectAnswerSchedulesOneDayAndIncreasesEase() {
        val r = SrsScheduler.schedule(SrsScheduler.State(), correct = true, nowMs = now)
        assertEquals(1, r.repetitions)
        assertEquals(1f, r.intervalDays, 0.0001f)
        assertEquals(2.6f, r.easeFactor, 0.0001f)
        assertEquals(now + SrsScheduler.DAY_MS, r.nextDue)
    }

    @Test
    fun secondCorrectAnswerSchedulesSixDays() {
        val state = SrsScheduler.State(easeFactor = 2.6f, repetitions = 1, intervalDays = 1f)
        val r = SrsScheduler.schedule(state, correct = true, nowMs = now)
        assertEquals(2, r.repetitions)
        assertEquals(6f, r.intervalDays, 0.0001f)
        assertEquals(2.7f, r.easeFactor, 0.0001f)
    }

    @Test
    fun laterCorrectAnswersMultiplyPreviousIntervalByEase() {
        val state = SrsScheduler.State(easeFactor = 2.7f, repetitions = 2, intervalDays = 6f)
        val r = SrsScheduler.schedule(state, correct = true, nowMs = now)
        assertEquals(3, r.repetitions)
        assertEquals(16.2f, r.intervalDays, 0.0001f)
        assertEquals(2.8f, r.easeFactor, 0.0001f)
        assertEquals(now + (16.2f * SrsScheduler.DAY_MS).toLong(), r.nextDue)
    }

    @Test
    fun incorrectAnswerResetsRepetitionsAndSchedulesTomorrow() {
        val state = SrsScheduler.State(easeFactor = 2.8f, repetitions = 8, intervalDays = 45f)
        val r = SrsScheduler.schedule(state, correct = false, nowMs = now)
        assertEquals(0, r.repetitions)
        assertEquals(1f, r.intervalDays, 0.0001f)
        assertEquals(2.48f, r.easeFactor, 0.0001f)
        assertEquals(now + SrsScheduler.DAY_MS, r.nextDue)
    }

    @Test
    fun easeFactorNeverFallsBelowMinimum() {
        val state = SrsScheduler.State(easeFactor = 1.3f, repetitions = 0, intervalDays = 0f)
        val r = SrsScheduler.schedule(state, correct = false, nowMs = now)
        assertEquals(SrsScheduler.MIN_EASE, r.easeFactor, 0.0001f)
        assertTrue(r.nextDue > now)
    }

    @Test(expected = IllegalArgumentException::class)
    fun negativeTimeIsRejected() {
        SrsScheduler.schedule(SrsScheduler.State(), correct = true, nowMs = -1L)
    }
}
