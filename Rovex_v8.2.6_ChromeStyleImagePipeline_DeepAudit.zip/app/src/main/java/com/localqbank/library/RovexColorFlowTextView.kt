package com.localqbank.library

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.LinearGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.TextView

/** Animated red -> orange -> yellow text used for key dashboard labels. */
class RovexColorFlowTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : TextView(context, attrs) {
    private var animator: ValueAnimator? = null
    private var phase = 0f

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startFlow()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel(); animator = null
        paint.shader = null
        super.onDetachedFromWindow()
    }

    private fun startFlow() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3000L
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { phase = it.animatedValue as Float; applyFlow(); invalidate() }
            start()
        }
    }

    private fun applyFlow() {
        if (width <= 0 || text.isNullOrBlank()) return
        val travel = width.toFloat() * 1.6f
        val start = -travel + phase * travel
        paint.shader = LinearGradient(
            start, 0f, start + travel, 0f,
            intArrayOf(0xFFFF3B30.toInt(), 0xFFFF7A00.toInt(), 0xFFFFD43B.toInt(), 0xFFFFF06A.toInt(), 0xFFFF3B30.toInt()),
            null, Shader.TileMode.MIRROR
        )
    }

    override fun onDraw(canvas: android.graphics.Canvas) { applyFlow(); super.onDraw(canvas) }
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { super.onSizeChanged(w,h,oldw,oldh); applyFlow() }
}
