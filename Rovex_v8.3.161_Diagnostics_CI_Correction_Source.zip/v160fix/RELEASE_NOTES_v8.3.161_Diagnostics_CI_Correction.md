# Rovex v8.3.161 — Diagnostics + CI Correction

## CI correction
- Fixed the malformed BenModelLabActivity compilation cascade reported by the v8.3.161 CI log.
- Restored explicit helper methods and correct Kotlin string/brace structure.
- Fixed the nullable diagnostics export map contract by using Map<String, String> values.

## Unified diagnostics
- Added RovexDiagnosticsDataCenter as the permanent Settings diagnostics/test surface.
- Restored one-tap EmbeddingGemma contract/NPU diagnostic access through the isolated Ben service.
- Added current runtime/resource telemetry and bounded share/export text.
- Settings routes point to the permanent diagnostics center rather than duplicating the model-lab destination.

## Validation
- XML parsing: 26/26 PASS.
- Duplicate IDs within individual layouts: 0.
- Production runBlocking/GlobalScope/Thread.sleep/catch(Throwable): 0.
- Kotlin source delimiter balance for changed files: PASS.
- Full Android/AGP compilation must be confirmed by CI; local Gradle distribution remains unavailable in this environment.
