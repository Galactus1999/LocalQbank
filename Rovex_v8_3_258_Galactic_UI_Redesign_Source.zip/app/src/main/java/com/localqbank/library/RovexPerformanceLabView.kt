package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.roundToInt
import kotlin.math.sin

/** Home Performance Lab mini-dashboard: animated health ring + readable metric scales. */
class RovexPerformanceLabView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG);private var health=0;private var resilience=0;private var ram=0;private var animated=FloatArray(3);private var running=false;private var started=0L
    fun setScores(health:Int,resilience:Int,ram:Int){this.health=health.coerceIn(0,100);this.resilience=resilience.coerceIn(0,100);this.ram=ram.coerceIn(0,100);invalidate()}
    override fun onAttachedToWindow(){super.onAttachedToWindow();running=true;started=SystemClock.uptimeMillis();postInvalidateOnAnimation()}
    override fun onDetachedFromWindow(){running=false;super.onDetachedFromWindow()}
    override fun onWindowVisibilityChanged(visibility:Int){super.onWindowVisibilityChanged(visibility);running=visibility==View.VISIBLE;if(running)postInvalidateOnAnimation()}
    override fun onDraw(c:Canvas){
        super.onDraw(c);val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0||!running)return;val d=resources.displayMetrics.density;val dark=ThemeManager.isDark(context);val target=floatArrayOf(health.toFloat(),resilience.toFloat(),ram.toFloat());for(i in 0..2)animated[i]+=(target[i]-animated[i])*.14f
        val score=animated.average().roundToInt().coerceIn(0,100);val cx=w*.30f;val cy=h*.43f;val r=minOf(w,h)*.26f
        p.style=Paint.Style.STROKE;p.strokeWidth=8*d;p.strokeCap=Paint.Cap.ROUND;p.color=if(dark)0xFF2C414E.toInt() else 0xFFD5E2E7.toInt();c.drawCircle(cx,cy,r,p);p.color=ThemeManager.accent(context);c.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,score*3.6f,false,p)
        p.style=Paint.Style.FILL;p.color=if(dark)0xFFEAF1F5.toInt() else 0xFF263C46.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=17*d;p.isFakeBoldText=true;c.drawText("$score%",cx,cy+5*d,p);p.textSize=6.5*d;p.isFakeBoldText=false;c.drawText("HEALTH",cx,cy+16*d,p);p.textAlign=Paint.Align.LEFT
        val labels=arrayOf("HEALTH" to animated[0],"RESILIENCE" to animated[1],"RAM" to animated[2]);val left=w*.55f;val right=w-8*d;val bw=right-left
        labels.forEachIndexed{idx,pair->val y=(13+idx*30)*d;val v=pair.second.roundToInt().coerceIn(0,100);p.color=if(dark)0xFF263945.toInt() else 0xFFD9E5E8.toInt();c.drawRoundRect(left,y,right,y+6*d,3*d,3*d,p);p.color=grade(v);c.drawRoundRect(left,y,left+bw*v/100f,y+6*d,3*d,3*d,p);p.color=if(dark)0xFFE8EFF3.toInt() else 0xFF33444D.toInt();p.textSize=7.2*d;p.isFakeBoldText=true;c.drawText(pair.first,left,y-2*d,p);p.textAlign=Paint.Align.RIGHT;c.drawText("$v%",right,y-2*d,p);p.textAlign=Paint.Align.LEFT}
        val pulse=((sin((SystemClock.uptimeMillis()-started)/700.0)+1)/2).toFloat();p.color=ThemeManager.accent(context);c.drawCircle(w-8*d,h-7*d,(2f+1.4f*pulse)*d,p);if(running)postInvalidateOnAnimation()
    }
    private fun grade(v:Int)=when{v>=85->0xFF36B77C.toInt();v>=70->0xFF4FA4D8.toInt();v>=50->0xFFE3AE45.toInt();else->0xFFD65F5F.toInt()}
}
