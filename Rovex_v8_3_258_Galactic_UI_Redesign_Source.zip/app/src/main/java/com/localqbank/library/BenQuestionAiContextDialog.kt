package com.localqbank.library

import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.lifecycle.lifecycleScope
import com.localqbank.library.ai.context.ContextPackBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Full-screen structured exam workspace. Local QBank truth is always shown before optional AI. */
class BenQuestionAiContextDialog {
    fun show(activity: QuizActivity, q: Question, selectedOption: String?) {
        ProductionCrashReporter.breadcrumb(activity, "AI_CONTEXT_OPENED")
        val dialog = Dialog(activity)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 14), dp(activity, 10), dp(activity, 14), dp(activity, 10))
            background = UiDrawableUtils.roundedDrawable(activity, ThemeManager.dialogBg(activity), 26f)
        }
        val header = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(activity).apply {
            text = "BEN + AI"
            textSize = 23f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(activity))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(activity).apply {
            text = "EXAM INTELLIGENCE"; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.accent(activity)); background = rounded(activity, ThemeManager.explanationBg(activity), 12f)
            setPadding(dp(activity, 10), dp(activity, 7), dp(activity, 10), dp(activity, 7))
        })
        root.addView(header)
        root.addView(TextView(activity).apply {
            text = "${currentBenExamProfile(activity).label}  •  Local QBank evidence first  •  Free AI / Google optional"
            textSize = 11.5f; setTextColor(ThemeManager.muted(activity)); setPadding(0, dp(activity, 2), 0, dp(activity, 9))
        })

        val modeRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        val modes = listOf(BenQuestionAiMode.PYQ_CONTEXT, BenQuestionAiMode.PYT_CONTEXT, BenQuestionAiMode.FUTURE_RELATED, BenQuestionAiMode.OTHER_OPTIONS)
        var activeMode = AppManagers.renMemory.questionAiContextMode()
        val chips = linkedMapOf<BenQuestionAiMode, TextView>()
        fun chip(mode: BenQuestionAiMode) = TextView(activity).apply {
            text = mode.label; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(activity, 4), 0, dp(activity, 4), 0); isClickable = true; isFocusable = true
        }
        modes.forEach { mode ->
            val c = chip(mode); chips[mode] = c
            modeRow.addView(c, LinearLayout.LayoutParams(0, dp(activity, 40), 1f).apply { setMargins(dp(activity, 2), 0, dp(activity, 2), 0) })
        }
        root.addView(modeRow)

        val status = TextView(activity).apply {
            text = "CURRENT QUESTION → local evidence → structured explanation"
            textSize = 10.5f; setTextColor(ThemeManager.muted(activity)); setPadding(dp(activity, 4), dp(activity, 8), dp(activity, 4), dp(activity, 4))
        }
        root.addView(status)

        val web = WebView(activity).apply {
            settings.javaScriptEnabled = false
            settings.domStorageEnabled = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val u = request.url.toString(); if (u.startsWith("https://")) activity.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, request.url)); return true
                }
            }
            setBackgroundColor(Color.TRANSPARENT)
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val actions = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(activity, 8), 0, 0) }
        fun action(label: String, click: () -> Unit) = TextView(activity).apply {
            text = label; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.text(activity)); background = rounded(activity, ThemeManager.elevated(activity), 13f); setOnClickListener { click() }
        }
        val save = action("SAVE CONTEXT") { AppManagers.renMemory.saveQuestionAiContext(activeMode, q.id); status.text = "SAVED ✓  •  ${activeMode.label}  •  Q${q.id}" }
        val free = action("RUN FREE AI") { renderFree(activity, web, activeMode, q, selectedOption) }
        val google = action("SEARCH") {
            val query = "${currentBenExamProfile(activity).label} ${q.text} ${activeMode.prompt} Options: ${q.options.joinToString(" | ") { it.label + " " + it.text.take(300) }}"
            activity.startActivity(android.content.Intent(activity, GoogleSearchActivity::class.java).putExtra("query", query))
        }
        val close = action("CLOSE") { dialog.dismiss() }
        listOf(save, free, google, close).forEachIndexed { i, v -> actions.addView(v, LinearLayout.LayoutParams(0, dp(activity, 44), 1f).apply { setMargins(if (i == 0) 0 else dp(activity, 4), 0, if (i == 3) 0 else dp(activity, 4), 0) }) }
        root.addView(actions)

        fun renderMode() { chips.forEach { (m, v) -> val on = m == activeMode; v.background = rounded(activity, if (on) ThemeManager.accent(activity) else ThemeManager.elevated(activity), 13f); v.setTextColor(if (on) Color.WHITE else ThemeManager.text(activity)) }; renderLocal(activity, web, status, activeMode, q) }
        chips.forEach { (m, v) -> v.setOnClickListener { activeMode = m; renderMode() } }

        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout(-1, -1)
        renderMode()
    }

    private fun renderLocal(activity: QuizActivity, web: WebView, status: TextView, mode: BenQuestionAiMode, q: Question) {
        status.text = "BUILDING CONTEXT  •  current question + answer + QBank explanation + related local questions"
        activity.lifecycleScope.launch(Dispatchers.IO) {
            val context = runCatching { AppManagers.frankensteinContext.buildEnhanced(q) }.getOrNull()
            val html = buildLocalHtml(activity, q, mode, context)
            activity.runOnUiThread { if (!activity.isFinishing && !activity.isDestroyed) { web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null); status.text = "LOCAL EVIDENCE READY  •  ${context?.relatedQuestions?.size ?: 0} related questions" } }
        }
    }

    private fun renderFree(activity: QuizActivity, web: WebView, mode: BenQuestionAiMode, q: Question, selectedOption: String?) {
        web.loadDataWithBaseURL(null, rovexMarkdownToHtml("## Ben is thinking…\n\nBuilding a bounded packet from the current question, its QBank explanation, and local evidence."), "text/html", "UTF-8", null)
        activity.lifecycleScope.launch(Dispatchers.IO) {
            val builder = ContextPackBuilder(activity)
            val packet = builder.forQuestion(q, selectedOption, learnerNote = mode.prompt).toPromptBlock() + "\n\n" + builder.questionAiEvidence(q, mode)
            val system = "You are Ben's exam-reasoning accelerator. Explain the CURRENT QUESTION directly. Use the supplied QBank key/explanation as authoritative local truth. Use local related questions as context, never invent PYQ provenance. Return structured Markdown with headings, short paragraphs, a comparison table when useful, highlighted key takeaways using **bold**, and image Markdown only when an actual relevant HTTPS image is available."
            val result = AppManagers.cloudAi.generate(packet, system, 2200)
            val answer = result?.let { "## Ben + ${it.provider.label}\n\n${it.text}\n\n*${it.model}*" } ?: "## Free AI unavailable\n\nNo Free AI provider is connected. Your local QBank explanation remains available above."
            activity.runOnUiThread { if (!activity.isFinishing && !activity.isDestroyed) web.loadDataWithBaseURL(null, rovexMarkdownToHtml(answer), "text/html", "UTF-8", null) }
        }
    }

    private fun buildLocalHtml(activity: QuizActivity, q: Question, mode: BenQuestionAiMode, context: FrankensteinContextEngine.ContextBundle?): String {
        val sb = StringBuilder()
        sb.append("<div class='card'><div class='label'>CURRENT QUESTION</div><h2>${esc(q.text)}</h2>")
        q.options.forEach { o -> sb.append("<div class='option'><b>${esc(o.label)}.</b> ${esc(o.text)}</div>") }
        sb.append("</div>")
        sb.append("<div class='card'><div class='label'>ANSWER</div><div class='answer'>${esc(q.correctAnswer ?: "Not available")}</div>")
        if (!q.explanation.isNullOrBlank()) sb.append("<h3>QBank explanation</h3><p>${esc(q.explanation!!).replace("\n", "<br>")}</p>")
        sb.append("</div>")
        if (q.questionImages.isNotEmpty() || q.explanationImages.isNotEmpty()) {
            sb.append("<div class='card'><div class='label'>QUESTION IMAGES</div>")
            (q.questionImages + q.explanationImages).distinct().take(6).forEach { u -> if (u.startsWith("https://")) sb.append("<img src='${esc(u)}'>") }
            sb.append("</div>")
        }
        sb.append("<div class='card'><div class='label'>LOCAL CONTEXT • ${esc(mode.label)}</div>")
        if (context != null) {
            sb.append("<p><b>${context.relatedQuestions.size}</b> related local questions found")
            if (context.concepts.isNotEmpty()) sb.append(" • concepts: ${esc(context.concepts.take(6).joinToString(", "))}")
            sb.append("</p>")
            context.weakestConcept?.let { sb.append("<p><b>Learner focus:</b> ${esc(it)} (${context.weakestMastery ?: 0}% local mastery estimate)</p>") }
            if (context.personalNote != null) sb.append("<blockquote>${esc(context.personalNote)}</blockquote>")
            if (context.relatedQuestions.isNotEmpty()) {
                sb.append("<h3>Related local evidence</h3><table><tr><th>Source</th><th>Question context</th><th>Key</th></tr>")
                context.relatedQuestions.take(10).forEach { r -> sb.append("<tr><td>${esc(r.exam)}<br>${esc(r.source)}</td><td>${esc(r.text.take(700))}</td><td>${esc(r.answer.take(250))}</td></tr>") }
                sb.append("</table>")
            }
        } else sb.append("<p>Local retrieval is unavailable for this render. Do not invent provenance.</p>")
        sb.append("</div>")
        sb.append("<div class='card'><div class='label'>EXAM TAKEAWAY</div><p><b>Use the current question's actual stem, options, keyed answer and QBank explanation first.</b> Related questions are contextual evidence, not proof of PYQ status unless their local provenance explicitly establishes it.</p></div>")
        return styledHtml(sb.toString(), activity)
    }

    private fun styledHtml(body: String, activity: QuizActivity): String {
        val dark = ThemeManager.isDark(activity)
        val bg = colorHex(ThemeManager.dialogBg(activity)); val text = colorHex(ThemeManager.text(activity)); val muted = colorHex(ThemeManager.muted(activity)); val accent = colorHex(ThemeManager.accent(activity))
        return """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{font-family:sans-serif;font-size:16px;line-height:1.52;margin:0;padding:4px 2px;color:$text;background:$bg}h2{font-size:22px;line-height:1.25;margin:8px 0 12px}h3{font-size:17px;margin:14px 0 6px}.card{background:${if(dark)"#14222D" else "#F6F1E7"};border:1px solid ${if(dark)"#304958" else "#DDD2BD"};border-radius:16px;padding:13px;margin:9px 0}.label{font-size:10px;color:$accent;font-weight:800;letter-spacing:.09em}.option{padding:8px 10px;margin:5px 0;background:${if(dark)"#1B2C38" else "#FFFDF7"};border-radius:9px}.answer{font-size:19px;font-weight:800;color:#36B77C}p{margin:7px 0}blockquote{margin:9px 0;padding:9px 11px;border-left:4px solid $accent;background:${if(dark)"#1B2B35" else "#FFF6D9"};border-radius:7px}table{width:100%;border-collapse:collapse;margin:10px 0}th,td{border:1px solid ${if(dark)"#38515F" else "#D6CCBA"};padding:7px;vertical-align:top;text-align:left}th{background:${if(dark)"#20394A" else "#EDE3D1"};color:$accent}img{max-width:100%;height:auto;border-radius:10px;margin:7px 0}small{color:$muted}</style></head><body>$body</body></html>"""
    }

    private fun esc(v: String): String = android.text.TextUtils.htmlEncode(v)
    private fun colorHex(c: Int): String = String.format("#%06X", 0xFFFFFF and c)
    private fun rounded(a: QuizActivity, color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius * a.resources.displayMetrics.density }
    private fun dp(a: QuizActivity, v: Int) = (v * a.resources.displayMetrics.density).toInt()
}
