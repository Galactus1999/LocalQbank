package com.localqbank.library

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Durable progress backup. The QBank HTML/database is never copied into these small backups. */
class BackupManager(private val context: Context) {
    companion object {
        const val PREFS = "backup_settings"
        const val TREE_URI = "backup_tree_uri"
        const val LAST_BACKUP = "last_backup"
        const val BACKUP_NAME = "Q_Progress_latest.qbackup"
        private const val LOCAL_DIR = "q_backups"
        private val io = Executors.newSingleThreadExecutor()
        private val snapshotQueued = AtomicBoolean(false)
        private val generation = AtomicLong(0)
    }
    private val app = context.applicationContext
    private val settings = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun onProgressChanged(cloud:Boolean=true) {
        // SharedPreferences is already committed synchronously by ProgressStore.
        // Coalesce rapid quiz navigation into one background snapshot; never block the UI.
        generation.incrementAndGet()
        if(snapshotQueued.compareAndSet(false,true)) io.submit {
            try { while(true){ val seen=generation.get(); writeLocalSnapshot(); if(generation.get()==seen) break } }
            finally { snapshotQueued.set(false) }
        }
        if(!cloud) return
        val uri = settings.getString(TREE_URI, null) ?: return
        val request = OneTimeWorkRequestBuilder<CloudBackupWorker>()
            .setInitialDelay(15, TimeUnit.MINUTES)
            .setInputData(workDataOf("treeUri" to uri))
            .addTag("q_cloud_backup")
            .build()
        WorkManager.getInstance(app).enqueueUniqueWork("q_cloud_backup_after_changes", ExistingWorkPolicy.REPLACE, request)
    }

    fun setTreeUri(uri: Uri) {
        try { app.contentResolver.takePersistableUriPermission(uri, IntentFlags.READ_WRITE) } catch (_: Throwable) {}
        settings.edit().putString(TREE_URI, uri.toString()).apply()
        schedulePeriodic()
    }

    fun clearTreeUri() { settings.edit().remove(TREE_URI).apply(); WorkManager.getInstance(app).cancelUniqueWork("q_cloud_backup_after_changes"); WorkManager.getInstance(app).cancelUniqueWork("q_cloud_backup_periodic") }
    fun treeUri(): Uri? = settings.getString(TREE_URI, null)?.let { Uri.parse(it) }
    fun lastBackup(): Long = settings.getLong(LAST_BACKUP, 0L)

    fun flushCloudBackup() {
        val uri=settings.getString(TREE_URI,null) ?: return
        val request=OneTimeWorkRequestBuilder<CloudBackupWorker>().setInputData(workDataOf("treeUri" to uri)).addTag("q_cloud_backup_flush").build()
        WorkManager.getInstance(app).enqueueUniqueWork("q_cloud_backup_flush",ExistingWorkPolicy.REPLACE,request)
    }

    fun backupNow(): Boolean {
        val file = writeLocalSnapshot() ?: return false
        val uri = treeUri() ?: return true
        return upload(file, uri)
    }

    fun exportFile(): File? = writeLocalSnapshot()

    private fun writeLocalSnapshot(): File? {
        return try {
            val dir = File(app.filesDir, LOCAL_DIR).apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val target = File(dir, "Q_Progress_$stamp.qbackup")
            val tmp = File(dir, ".tmp_${target.name}")
            val json = buildPayload()
            FileOutputStream(tmp).use { it.write(json.toString().toByteArray(Charsets.UTF_8)); it.fd.sync() }
            if (!tmp.renameTo(target)) { tmp.copyTo(target, true); tmp.delete() }
            File(dir, "Q_Progress_latest.qbackup").let { latest ->
                val ltmp=File(dir, ".latest.tmp")
                target.copyTo(ltmp, true); if(!ltmp.renameTo(latest)){ltmp.copyTo(latest,true);ltmp.delete()}
            }
            dir.listFiles { f -> f.name.startsWith("Q_Progress_") && f.name.endsWith(".qbackup") && f.name != "Q_Progress_latest.qbackup" }
                ?.sortedByDescending { it.lastModified() }?.drop(5)?.forEach { it.delete() }
            settings.edit().putLong(LAST_BACKUP, System.currentTimeMillis()).apply()
            target
        } catch (_: Throwable) { null }
    }

    private fun buildPayload(): JSONObject {
        val p = app.getSharedPreferences("progress", Context.MODE_PRIVATE)
        val ui = app.getSharedPreferences("ui", Context.MODE_PRIVATE)
        val progress = JSONObject()
        for ((k,v) in p.all) when(v) {
            is String -> progress.put(k,v); is Boolean -> progress.put(k,v); is Int -> progress.put(k,v)
            is Long -> progress.put(k,v); is Float -> progress.put(k,v.toDouble())
        }
        val uiJson=JSONObject()
        for ((k,v) in ui.all) when(v) { is String->uiJson.put(k,v); is Boolean->uiJson.put(k,v); is Int->uiJson.put(k,v); is Long->uiJson.put(k,v); is Float->uiJson.put(k,v.toDouble()) }
        val core=JSONObject().put("format",1).put("createdAt",System.currentTimeMillis()).put("progress",progress).put("ui",uiJson)
        val digest=sha256(core.toString())
        return JSONObject().put("qBackup",core).put("sha256",digest)
    }

    fun restoreFromFile(file: File): Boolean {
        return try {
            restorePayload(file.readText(Charsets.UTF_8))
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun restoreFromUri(uri: Uri): Boolean {
        return try {
            val input = app.contentResolver.openInputStream(uri) ?: return false
            input.use { restorePayload(it.readBytes().toString(Charsets.UTF_8)) }
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun restorePayload(text:String) {
        val wrapper=JSONObject(text); val core=wrapper.getJSONObject("qBackup")
        require(wrapper.optString("sha256") == sha256(core.toString())) { "Backup checksum failed" }
        require(core.optInt("format") == 1) { "Unsupported backup version" }
        val progress=core.getJSONObject("progress")
        val p=app.getSharedPreferences("progress", Context.MODE_PRIVATE); val e=p.edit().clear()
        val it=progress.keys(); while(it.hasNext()) { val k=it.next(); val v=progress.get(k); when(v){is Boolean->e.putBoolean(k,v);is Int->e.putInt(k,v);is Long->e.putLong(k,v);is Double->e.putFloat(k,v.toFloat());is String->e.putString(k,v.toString())} }
        e.commit()
        val ui=core.optJSONObject("ui"); if(ui!=null){val u=app.getSharedPreferences("ui",Context.MODE_PRIVATE).edit();val ks=ui.keys();while(ks.hasNext()){val k=ks.next();val v=ui.get(k);when(v){is Boolean->u.putBoolean(k,v);is Int->u.putInt(k,v);is Long->u.putLong(k,v);is Double->u.putFloat(k,v.toFloat());is String->u.putString(k,v.toString())}};u.commit()}
        writeLocalSnapshot()
    }

    fun backupToUri(tree: Uri): Boolean { val local=writeLocalSnapshot() ?: return false; return upload(local,tree) }

    private fun upload(local:File, tree:Uri): Boolean {
        return try {
            val root = DocumentFile.fromTreeUri(app, tree) ?: return false

            // Replace the rolling "latest" backup only after the versioned copy succeeds.
            val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val versioned = root.createFile("application/octet-stream", "Q_Progress_$stamp.qbackup") ?: return false
            val versionedOk = app.contentResolver.openOutputStream(versioned.uri)?.use { out ->
                local.inputStream().use { input -> input.copyTo(out, 1024 * 1024) }
                true
            } ?: false
            if (!versionedOk) { versioned.delete(); return false }

            root.findFile(BACKUP_NAME)?.delete()
            val latest = root.createFile("application/octet-stream", BACKUP_NAME) ?: return false
            val latestOk = app.contentResolver.openOutputStream(latest.uri)?.use { out ->
                local.inputStream().use { input -> input.copyTo(out, 1024 * 1024) }
                true
            } ?: false
            if (!latestOk) { latest.delete(); return false }

            root.listFiles()
                .filter { it.name?.startsWith("Q_Progress_") == true && it.name?.endsWith(".qbackup") == true && it.name != BACKUP_NAME }
                .sortedByDescending { it.lastModified() }
                .drop(5)
                .forEach { it.delete() }

            settings.edit().putLong(LAST_BACKUP, System.currentTimeMillis()).apply()
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun schedulePeriodic() {
        val request=PeriodicWorkRequestBuilder<CloudBackupWorker>(12,TimeUnit.HOURS)
            .setInputData(workDataOf("treeUri" to (treeUri()?.toString() ?: ""))).addTag("q_cloud_backup_periodic").build()
        WorkManager.getInstance(app).enqueueUniquePeriodicWork("q_cloud_backup_periodic",ExistingPeriodicWorkPolicy.UPDATE,request)
    }
    private fun sha256(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString(""){String.format("%02x",it)}

    object IntentFlags { const val READ_WRITE = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION }
}

class CloudBackupWorker(appContext: Context, params: WorkerParameters): Worker(appContext,params) {
    override fun doWork(): Result {
        val uri=inputData.getString("treeUri")?.let { Uri.parse(it) } ?: BackupManager(applicationContext).treeUri() ?: return Result.success()
        val ok=BackupManager(applicationContext).backupToUri(uri)
        return if(ok) Result.success() else Result.retry()
    }
}
