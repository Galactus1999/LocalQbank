package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File

class QBankDb(context: Context) {
    private val dbFile: File = context.getDatabasePath("qbank.db")
    private val db: SQLiteDatabase
    init {
        dbFile.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        db.execSQL("PRAGMA foreign_keys=ON")
        createSchema()
    }
    private fun createSchema() {
        db.execSQL("CREATE TABLE IF NOT EXISTS source(id INTEGER PRIMARY KEY AUTOINCREMENT, file_name TEXT UNIQUE NOT NULL, provider TEXT NOT NULL, imported_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS test(id TEXT PRIMARY KEY, source_id INTEGER NOT NULL, title TEXT NOT NULL, path TEXT, num_questions INTEGER, total_marks REAL, duration_seconds INTEGER, time_per_question REAL, original_id TEXT, FOREIGN KEY(source_id) REFERENCES source(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question(id INTEGER PRIMARY KEY AUTOINCREMENT, test_id TEXT NOT NULL, position INTEGER NOT NULL, source_question_id TEXT, text TEXT, raw_text TEXT, correct_answer TEXT, explanation TEXT, bot TEXT, video TEXT, audio TEXT, FOREIGN KEY(test_id) REFERENCES test(id) ON DELETE CASCADE, UNIQUE(test_id,position))")
        db.execSQL("CREATE TABLE IF NOT EXISTS option_item(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, position INTEGER NOT NULL, label TEXT, text TEXT, is_correct INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_image(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, kind TEXT NOT NULL, position INTEGER NOT NULL, uri TEXT NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS progress(question_id INTEGER PRIMARY KEY, selected_answer TEXT, status TEXT, bookmark TEXT, review INTEGER DEFAULT 0, attempt_count INTEGER DEFAULT 0, last_attempted INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_source ON test(source_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_test ON question(test_id,position)")
    }
    fun close(){db.close()}
    fun sources(): List<Source> = db.rawQuery("SELECT id,file_name,provider FROM source ORDER BY imported_at DESC",null).use{c->buildList{while(c.moveToNext())add(Source(c.getLong(0),c.getString(1),c.getString(2)))}}
    fun tests(sourceId:Long):List<Test> = db.rawQuery("SELECT id,title,path,num_questions,total_marks,duration_seconds,time_per_question FROM test WHERE source_id=? ORDER BY rowid",arrayOf(sourceId.toString())).use{c->buildList{while(c.moveToNext())add(Test(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getDouble(4),c.getInt(5),c.getDouble(6)))}}
    fun questions(testId:String):List<Question>{
        val out=mutableListOf<Question>()
        db.rawQuery("SELECT id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio FROM question WHERE test_id=? ORDER BY position",arrayOf(testId)).use{c->while(c.moveToNext()){
            val id=c.getLong(0); val opts=mutableListOf<Option>()
            db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position",arrayOf(id.toString())).use{o->while(o.moveToNext())opts.add(Option(o.getString(0),o.getString(1),o.getInt(2)!=0))}
            out.add(Question(id,"$testId:${c.getInt(1)}:${c.getString(2)}",c.getInt(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),opts,images(id,"question"),images(id,"explanation")))
        }}
        return out
    }
    private fun images(qid:Long,kind:String)=db.rawQuery("SELECT uri FROM question_image WHERE question_id=? AND kind=? ORDER BY position",arrayOf(qid.toString(),kind)).use{c->buildList{while(c.moveToNext())add(c.getString(0))}}
    fun search(query:String):List<SearchHit>{val like="%${query.replace("%","\\%").replace("_","\\_")}%";return db.rawQuery("SELECT q.id,t.title,q.position,q.text FROM question q JOIN test t ON t.id=q.test_id WHERE q.text LIKE ? ESCAPE '\\' LIMIT 100",arrayOf(like)).use{c->buildList{while(c.moveToNext())add(SearchHit(c.getLong(0),c.getString(1),c.getInt(2),c.getString(3)))}}}

    fun importBundle(fileName:String, provider:String, tests:List<ImportedTest>):Int {
        db.beginTransaction()
        try {
            db.delete("source","file_name=?",arrayOf(fileName))
            val s=db.compileStatement("INSERT INTO source(file_name,provider,imported_at) VALUES(?,?,?)")
            s.bindString(1,fileName);s.bindString(2,provider);s.bindLong(3,System.currentTimeMillis());val sourceId=s.executeInsert()
            var count=0
            for ((ti,t) in tests.withIndex()) {
                val testId=makeId(fileName,t.originalId ?: t.title,ti)
                db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions,total_marks,duration_seconds,time_per_question,original_id) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(testId,sourceId,t.title,t.path,t.questions.size,t.totalMarks,t.duration,t.timePerQuestion,t.originalId))
                for ((qi,q) in t.questions.withIndex()) {
                    val st=db.compileStatement("INSERT INTO question(test_id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio) VALUES(?,?,?,?,?,?,?,?,?,?)")
                    st.bindString(1,testId);st.bindLong(2,qi.toLong());bindNullable(st,3,q.sourceId);bindNullable(st,4,q.text);bindNullable(st,5,q.rawText);bindNullable(st,6,q.correctAnswer);bindNullable(st,7,q.explanation);bindNullable(st,8,q.bot);bindNullable(st,9,q.video);bindNullable(st,10,q.audio);val qid=st.executeInsert()
                    q.options.forEachIndexed{oi,o->db.execSQL("INSERT INTO option_item(question_id,position,label,text,is_correct) VALUES(?,?,?,?,?)",arrayOf(qid,oi,o.label,o.text,if(o.correct)1 else 0))}
                    q.questionImages.forEachIndexed{ii,u->db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)",arrayOf(qid,"question",ii,u))}
                    q.explanationImages.forEachIndexed{ii,u->db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)",arrayOf(qid,"explanation",ii,u))}
                    count++
                }
            }
            db.setTransactionSuccessful(); return count
        } finally {db.endTransaction()}
    }
    private fun bindNullable(st:android.database.sqlite.SQLiteStatement,i:Int,v:String?){if(v==null)st.bindNull(i) else st.bindString(i,v)}
    private fun makeId(file:String,original:String,index:Int):String{val raw="$file|$original|$index";return java.security.MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).joinToString(""){String.format("%02x",it)}.take(24)}
}

data class Source(val id:Long,val fileName:String,val provider:String)
data class Test(val id:String,val title:String,val path:String?,val count:Int,val marks:Double,val duration:Int,val timePerQuestion:Double)
data class Option(val label:String,val text:String,val correct:Boolean)
data class Question(val id:Long,val stableKey:String,val position:Int,val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<Option>,val questionImages:List<String>,val explanationImages:List<String>)
data class SearchHit(val id:Long,val testTitle:String,val position:Int,val text:String)

data class ImportedTest(val originalId:String?,val title:String,val path:String?,val totalMarks:Double,val duration:Int,val timePerQuestion:Double,val questions:List<ImportedQuestion>)
data class ImportedQuestion(val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<ImportedOption>,val questionImages:List<String>,val explanationImages:List<String>)
data class ImportedOption(val label:String,val text:String,val correct:Boolean)

class ProgressStore(context: Context) {
    private val p=context.getSharedPreferences("progress",Context.MODE_PRIVATE)
    private fun key(id:String,s:String)=id+":"+s
    fun selected(id:String)=p.getString(key(id,"answer"),null)
    fun status(id:String)=p.getString(key(id,"status"),null)
    fun bookmark(id:String)=p.getString(key(id,"bookmark"),null)
    fun review(id:String)=p.getBoolean(key(id,"review"),false)
    fun setAnswer(id:String,a:String,status:String){p.edit().putString(key(id,"answer"),a).putString(key(id,"status"),status).apply()}
    fun setBookmark(id:String,v:String?){p.edit().apply{if(v.isNullOrBlank())remove(key(id,"bookmark")) else putString(key(id,"bookmark"),v)}.apply()}
    fun setReview(id:String,v:Boolean)=p.edit().putBoolean(key(id,"review"),v).apply()
    fun clear(id:String){p.edit().apply{remove(key(id,"answer"));remove(key(id,"status"));remove(key(id,"bookmark"));remove(key(id,"review"))}.apply()}
}
