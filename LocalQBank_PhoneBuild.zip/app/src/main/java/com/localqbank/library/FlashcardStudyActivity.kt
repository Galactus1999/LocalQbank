package com.localqbank.library

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebView
import android.widget.*

class FlashcardStudyActivity:Activity(){
    private lateinit var db:FlashcardDb;private var deckId=0L;private var pos=0;private var showingBack=false;private lateinit var cardView:WebView;private lateinit var counter:TextView;private var count=0
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);db=FlashcardDb(this);deckId=intent.getLongExtra("deckId",0);count=db.cardCount(deckId);setContentView(build());show()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun build():LinearLayout{val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@FlashcardStudyActivity))};val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(7),dp(8),dp(7));setBackgroundColor(Color.rgb(42,76,99))};val back=TextView(this).apply{text="←";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{finish()}};bar.addView(back,LinearLayout.LayoutParams(dp(52),dp(50)));counter=TextView(this).apply{text="";textSize=14f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);gravity=Gravity.END};bar.addView(counter,LinearLayout.LayoutParams(0,-2,1f));root.addView(bar);cardView=WebView(this).apply{settings.javaScriptEnabled=false;settings.domStorageEnabled=false;settings.allowFileAccess=true;setBackgroundColor(ThemeManager.elevated(this@FlashcardStudyActivity));setOnClickListener{if(!showingBack){showingBack=true;show()}}};root.addView(cardView,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(dp(12),dp(12),dp(12),dp(8))});val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(4),dp(12),dp(12))};val reveal=TextView(this).apply{text="SHOW ANSWER";textSize=14f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.rgb(35,103,120));cornerRadius=16f};setOnClickListener{showingBack=true;show()}};actions.addView(reveal,LinearLayout.LayoutParams(0,dp(52),1f).apply{setMargins(0,0,dp(6),0)});val next=TextView(this).apply{text="NEXT  →";textSize=14f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.rgb(88,70,137));cornerRadius=16f};setOnClickListener{pos++;if(pos>=count)pos=0;showingBack=false;show()}};actions.addView(next,LinearLayout.LayoutParams(0,dp(52),1f).apply{setMargins(dp(6),0,0,0)});root.addView(actions);return root}
    private fun show(){val c=db.cardAt(deckId,pos);if(c==null){cardView.loadDataWithBaseURL(null,"<html><body>No cards</body></html>","text/html","UTF-8",null);return};counter.text="${pos+1} / $count";val html=if(showingBack)c.back else c.front;val doc="<html><head><meta name=viewport content=width=device-width,initial-scale=1><style>body{font-family:sans-serif;color:${if(ThemeManager.get(this)==ThemeManager.DARK)"#EDF2F7" else "#15263B"};font-size:19px;line-height:1.55;padding:22px}img{max-width:100%;height:auto}table{max-width:100%;border-collapse:collapse}td,th{padding:6px;border:1px solid #8a98a8}</style></head><body>$html</body></html>";cardView.loadDataWithBaseURL(null,doc,"text/html","UTF-8",null)}
    override fun onResume(){super.onResume();if(::db.isInitialized){count=db.cardCount(deckId);if(pos>=count)pos=0;if(::cardView.isInitialized)show()}}
    override fun onDestroy(){db.close();super.onDestroy()}
}
