package com.localqbank.library

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.*

class FlashcardStudyActivity:Activity(){
    private lateinit var db:FlashcardDb
    private var deckId=0L;private var pos=0;private var showingBack=false;private var bookmarksOnly=false;private var reviewMode=false
    private lateinit var cardView:WebView;private lateinit var counter:TextView;private lateinit var bookmark:TextView;private lateinit var reveal:TextView;private lateinit var ratingRow:LinearLayout
    private var count=0
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun button(text:String,fill:Int,click:()->Unit)=TextView(this).apply{text=text;textSize=12.5f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);background=android.graphics.drawable.GradientDrawable().apply{setColor(fill);cornerRadius=14f};setOnClickListener{click()}}
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);db=FlashcardDb(this);deckId=intent.getLongExtra("deckId",0);bookmarksOnly=intent.getBooleanExtra("bookmarksOnly",false);reviewMode=deckId<0L;count=currentCount();pos=getPreferences(0).getInt("pos_${deckId}_${bookmarksOnly}",0).coerceAtLeast(0);setContentView(build());show()}
    private fun currentCount()=when{bookmarksOnly->db.bookmarkCount();reviewMode->db.reviewCount();else->db.cardCount(deckId)}
    private fun currentCard():FlashcardDb.Card?=when{bookmarksOnly->db.bookmarkedCardAt(pos);reviewMode->db.reviewCardAt(pos);else->db.cardAt(deckId,pos)}
    private fun build():LinearLayout{val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@FlashcardStudyActivity))};val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(6),dp(8),dp(6));setBackgroundColor(Color.rgb(42,76,99))};val back=TextView(this).apply{text="←";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{finish()}};bar.addView(back,LinearLayout.LayoutParams(dp(52),dp(50)));counter=TextView(this).apply{text="";textSize=14f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);gravity=Gravity.CENTER};bar.addView(counter,LinearLayout.LayoutParams(0,-2,1f));bookmark=button("☆ BOOKMARK",Color.rgb(88,70,137)){currentCard()?.let{val v=db.toggleBookmarked(it.id);bookmark.text=if(v)"★ BOOKMARKED" else "☆ BOOKMARK"}};bar.addView(bookmark,LinearLayout.LayoutParams(dp(118),dp(40)));root.addView(bar)
        cardView=WebView(this).apply{settings.javaScriptEnabled=false;settings.domStorageEnabled=false;settings.allowFileAccess=true;settings.allowContentAccess=true;settings.cacheMode=WebSettings.LOAD_DEFAULT;setBackgroundColor(ThemeManager.elevated(this@FlashcardStudyActivity));setOnClickListener{if(!showingBack){showingBack=true;show()}}};root.addView(cardView,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(dp(10),dp(10),dp(10),dp(7))})
        reveal=button("SHOW ANSWER",Color.rgb(35,103,120)){showingBack=true;show()};root.addView(reveal,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(dp(12),dp(2),dp(12),dp(5))})
        ratingRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(2),dp(12),dp(12));visibility=android.view.View.GONE};val colors=intArrayOf(Color.rgb(160,65,65),Color.rgb(151,112,45),Color.rgb(35,103,120),Color.rgb(88,70,137));val labels=arrayOf("AGAIN","HARD","GOOD","EASY");for(i in 0..3){val r=button(labels[i],colors[i]){rateAndNext(i+1)};ratingRow.addView(r,LinearLayout.LayoutParams(0,dp(50),1f).apply{if(i>0)setMargins(dp(4),0,0,0)})};root.addView(ratingRow);return root}
    private fun rateAndNext(rating:Int){currentCard()?.let{db.review(it.id,rating)};pos++;count=currentCount();if(pos>=count)pos=0;showingBack=false;savePosition();show()}
    private fun savePosition(){getPreferences(0).edit().putInt("pos_${deckId}_${bookmarksOnly}",pos).apply()}
    private fun show(){count=currentCount();if(count<=0){counter.text="0 cards";cardView.loadDataWithBaseURL(null,"<html><body><h2>No cards are due here.</h2></body></html>","text/html","UTF-8",null);reveal.visibility=android.view.View.GONE;ratingRow.visibility=android.view.View.GONE;return};if(pos>=count)pos=0;val c=currentCard()?:return;counter.text="${pos+1} / $count";bookmark.text=if(c.bookmarked)"★ BOOKMARKED"else"☆ BOOKMARK";val html=if(showingBack)c.back else c.front;val fg=if(ThemeManager.get(this)==ThemeManager.DARK)"#EDF2F7"else"#15263B";val bg=if(ThemeManager.get(this)==ThemeManager.DARK)"#19212B"else"#FFFFFF";val doc="""<html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>html,body{background:$bg!important;color:$fg!important}body{font-family:sans-serif;font-size:19px;line-height:1.55;padding:20px;overflow-wrap:anywhere}img{display:block;max-width:100%;width:auto;height:auto;margin:12px auto;object-fit:contain}table{border-collapse:collapse;max-width:100%;width:auto;display:block;overflow-x:auto}td,th{padding:7px;border:1px solid #8a98a8}</style></head><body>$html</body></html>""";cardView.loadDataWithBaseURL("file:///android_asset/",doc,"text/html","UTF-8",null);reveal.visibility=if(showingBack)android.view.View.GONE else android.view.View.VISIBLE;ratingRow.visibility=if(showingBack)android.view.View.VISIBLE else android.view.View.GONE;savePosition()}
    override fun onPause(){savePosition();super.onPause()}
    override fun onResume(){super.onResume();if(::db.isInitialized&&::cardView.isInitialized){count=currentCount();if(pos>=count&&count>0)pos=0;show()}}
    override fun onDestroy(){db.close();super.onDestroy()}
}
