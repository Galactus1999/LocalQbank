package com.localqbank.library

import android.content.Context

/**
 * Adaptive agent loop. This is intentionally deterministic/local:
 * observe -> update memory/mesh -> score state -> recommend an action.
 */
class StudyAgent(context: Context) {
    private val app=context.applicationContext
    private val db=AgentDb(app)

    fun observeQuestion(questionId:Long, testId:String, topic:String?, correct:Boolean, timeMs:Long=0L) {
        val q=db.node("question:$questionId","Q $questionId","question")
        val test=db.node("test:$testId",testId.ifBlank{"QBank"},"test")
        db.connect(q,test,.05f)
        topic?.trim()?.takeIf{it.isNotBlank()}?.let{
            val n=db.node("topic:${it.lowercase()} ",it,"topic")
            db.connect(q,n,.12f)
            db.connect(n,test,.04f)
            db.learnNode(n,correct,if(correct).55f else .95f)
        }
        db.learnNode(q,correct,if(correct).45f else .9f)
        db.event(if(correct)"ANSWER_CORRECT" else "ANSWER_WRONG",questionId,testId,"timeMs=$timeMs")
    }

    fun observeOpen(questionId:Long,testId:String){
        val q=db.node("question:$questionId","Q $questionId","question")
        val t=db.node("test:$testId",testId.ifBlank{"QBank"},"test")
        db.connect(q,t,.02f); db.event("QUESTION_OPENED",questionId,testId,null)
    }

    fun observeEvent(type:String, questionId:Long?=null,testId:String?=null,payload:String?=null)=db.event(type,questionId,testId,payload)

    fun nodes()=db.nodes()
    fun edges()=db.edges()

    fun recommendation(total:Int, attempted:Int, wrong:Int):String {
        val accuracy=if(attempted==0)0f else (attempted-wrong).toFloat()/attempted
        val due=nodes().filter{it.kind=="topic" && it.confidence<.55f}.size
        return when {
            total==0 -> "Import a QBank. The agent will build its mesh automatically as you study."
            due>0 -> "I found $due weak concept${if(due==1)"" else "s"}. Start a targeted revision session."
            accuracy<.65f && attempted>=8 -> "Your recent accuracy is low. I recommend a short targeted practice set."
            attempted==0 -> "Start solving. I will learn from every answer without needing manual setup."
            else -> "Your current pattern looks stable. Keep solving; I will adapt the next recommendations."
        }
    }
    fun close(){db.close()}
}
