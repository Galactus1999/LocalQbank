package com.localqbank.library

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Lightweight background heartbeat. Android decides the exact execution window;
 * the agent never requires unrestricted background access.
 */
class AgentHeartbeatWorker(appContext:Context, params:WorkerParameters):CoroutineWorker(appContext,params){
    override suspend fun doWork():Result = try{
        val agent=StudyAgent(applicationContext)
        try {
            agent.observeEvent("AGENT_HEARTBEAT",payload="background=true;time=${System.currentTimeMillis()}")
        } finally { agent.close() }
        Result.success()
    }catch(_:Throwable){Result.retry()}
}
