package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.Executors

class FlashcardActivity: Activity() {
    private lateinit var db: FlashcardDb
    private val executor=Executors.newSingleThreadExecutor()
    private lateinit var list:LinearLayout
    private lateinit var reviewButton:TextView
    private lateinit var bookmarkButton:TextView
    private val expanded=mutableSetOf<String>()
    private val stateListener:()->Unit={if(!isFinishing && ::list.isInitialized)runOnUiThread{render()}}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun button(text:String,fill:Int,click:()->Unit)=TextView(this).apply{this.text=text;textSize=13.5f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE);background=GradientDrawable().apply{setColor(fill);cornerRadius=16f};setOnClickListener{click()}}

    override fun onCreate(b:Bundle?) {super.onCreate(b);SystemUi.immersive(this);db=FlashcardDb(this);setContentView(build());AppState.register(stateListener);render();intent.data?.let{importUri(it)}}
    override fun onResume(){super.onResume();if(::list.isInitialized)render()}

    private fun build():View {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@FlashcardActivity))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(7),dp(10),dp(7));setBackgroundColor(Color.rgb(42,76,99))}
        val back=TextView(this).apply{text="←";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{finish()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(52),dp(50)))
        val title=TextView(this).apply{text="Flashcards";textSize=21f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)};bar.addView(title,LinearLayout.LayoutParams(0,-2,1f));root.addView(bar)

        val review=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(12),dp(12),dp(6))}
        reviewButton=button("REVIEW DUE",Color.rgb(35,103,120)){startReview(false)}
        bookmarkButton=button("★ BOOKMARKED",Color.rgb(88,70,137)){startReview(true)}
        review.addView(reviewButton,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)});review.addView(bookmarkButton,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)});root.addView(review)
        val import=button("＋  IMPORT .APKG",Color.rgb(35,103,120)){pickApkg()};root.addView(import,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(dp(16),dp(5),dp(16),dp(10))})
        val section=TextView(this).apply{text="DECKS";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(16),dp(3),dp(16),dp(4))};root.addView(section)
        val scroll=ScrollView(this).apply{isFillViewport=true};list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(2),dp(12),dp(20))};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));return root
    }

    private fun refreshTop(){if(!::reviewButton.isInitialized)return;reviewButton.text="REVIEW DUE  •  ${db.reviewCount()}";bookmarkButton.text="★ BOOKMARKED  •  ${db.bookmarkCount()}"}
    private fun pickApkg(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE);putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/octet-stream","application/zip","application/x-zip-compressed"))},91)}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req==91&&res==RESULT_OK)data?.data?.let{importUri(it)}}
    private fun importUri(uri:android.net.Uri){try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Throwable){};val dialog=AlertDialog.Builder(this).setTitle("Importing flashcards").setMessage("Preparing APKG…\nLarge decks may take a while.").setCancelable(false).create();dialog.show();executor.execute{try{val r=ApkgImporter.importFile(this,uri){msg->runOnUiThread{if(!isFinishing)dialog.setMessage(msg)}};runOnUiThread{dialog.dismiss();Toast.makeText(this,"Imported ${r.cards} cards from ${r.decks} deck(s)",Toast.LENGTH_LONG).show();render()}}catch(e:Throwable){runOnUiThread{dialog.dismiss();Toast.makeText(this,"APKG import failed: ${e.message ?: "unsupported or damaged deck"}",Toast.LENGTH_LONG).show()}}}}

    private data class Node(val name:String,val full:String,val depth:Int,val deck:FlashcardDb.Deck?,val children:MutableList<Node>)
    private fun render(){if(!::list.isInitialized)return;list.removeAllViews();refreshTop();val decks=db.decks();if(decks.isEmpty()){list.addView(TextView(this).apply{text="No flashcard decks yet. Import an .apkg deck to begin.";textSize=15f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(12),dp(24),dp(12),dp(24))});return};val byFull=decks.associateBy{it.name};val roots=mutableListOf<Node>();val nodes=HashMap<String,Node>();fun nodeFor(path:String):Node{nodes[path]?.let{return it};val parts=path.split("::");val node=Node(parts.last(),parts.joinToString("::"),parts.size-1,byFull[parts.joinToString("::")],mutableListOf());nodes[node.full]=node;if(parts.size>1){val parent=nodeFor(parts.dropLast(1).joinToString("::"));parent.children.add(node)}else roots.add(node);return node};decks.forEach{nodeFor(it.name)}
        fun countTree(n:Node):Int=(n.deck?.count?:0)+n.children.sumOf{countTree(it)}
        fun addNode(n:Node){val own=n.deck;val has=n.children.isNotEmpty();val total=countTree(n);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10+n.depth*20),dp(9),dp(10),dp(9));background=GradientDrawable().apply{setColor(if(ThemeManager.get(this@FlashcardActivity)==ThemeManager.DARK)Color.rgb(25,33,43)else if(n.depth==0)Color.rgb(239,247,250)else ThemeManager.elevated(this@FlashcardActivity));cornerRadius=14f}};val arrow=TextView(this).apply{text=if(has){if(expanded.contains(n.full))"▼" else "▶"}else"•";textSize=14f;setTextColor(ThemeManager.accent(this@FlashcardActivity));gravity=Gravity.CENTER};row.addView(arrow,LinearLayout.LayoutParams(dp(28),dp(48)));val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL};body.addView(TextView(this).apply{text=n.name;textSize=if(n.depth==0)17f else 15.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@FlashcardActivity));maxLines=2});body.addView(TextView(this).apply{text=when{has&&own==null->"$total cards  •  subdecks";has->"${own!!.count} own  •  $total including subdecks";own!=null->"${own.count} cards  •  ${own.source ?: "Imported deck"}";else->"Category"};textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(2),0,0)});row.addView(body,LinearLayout.LayoutParams(0,-2,1f));if(own!=null&&own.count>0){val study=button("STUDY",Color.rgb(35,103,120)){startStudy(own.id)};row.addView(study,LinearLayout.LayoutParams(dp(62),dp(38)).apply{setMargins(dp(6),0,0,0)})};row.setOnClickListener{if(has){if(expanded.contains(n.full))expanded.remove(n.full)else expanded.add(n.full);render()}else if(own!=null)startStudy(own.id)};row.setOnLongClickListener{showDeckActions(n);true};list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(4),dp(4),dp(4),dp(4))});if(expanded.contains(n.full))n.children.sortedBy{it.name.lowercase()}.forEach{addNode(it)}};roots.sortedBy{it.name.lowercase()}.forEach{addNode(it)} }

    private fun startStudy(id:Long){startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",id))}
    private fun startReview(bookmarks:Boolean){startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",-1L).putExtra("bookmarksOnly",bookmarks))}
    private fun showDeckActions(n:Node){val own=n.deck;val options=if(n.children.isNotEmpty())arrayOf("Study deck","Delete this deck","Delete this deck + all subdecks")else arrayOf("Study deck","Delete deck");AlertDialog.Builder(this).setTitle(n.full).setItems(options){_,which->when(which){0->if(own!=null&&own.count>0)startStudy(own.id)else Toast.makeText(this,"This category has no cards of its own.",Toast.LENGTH_SHORT).show();1->if(own!=null)confirmDelete(n,false);2->if(own!=null)confirmDelete(n,true)}}.show()}
    private fun confirmDelete(n:Node,all:Boolean){val msg=if(all)"Delete ${n.full} and every subdeck? This removes their flashcards from this app."else"Delete ${n.full}? This removes its flashcards from this app.";AlertDialog.Builder(this).setTitle("Delete deck").setMessage(msg).setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->val removed=if(n.deck!=null)db.deleteDeck(n.deck.id,all)else 0;Toast.makeText(this,"Deleted $removed deck(s)",Toast.LENGTH_SHORT).show();render()}.show()}
    override fun onDestroy(){AppState.unregister(stateListener);executor.shutdownNow();db.close();super.onDestroy()}
}
