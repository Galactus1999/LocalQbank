package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.Executors

class FlashcardActivity: Activity() {
    private lateinit var db:FlashcardDb
    private val executor=Executors.newSingleThreadExecutor()
    private lateinit var list:LinearLayout
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);db=FlashcardDb(this);setContentView(build());render()}
    private fun build():View{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@FlashcardActivity))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8));setBackgroundColor(Color.rgb(42,76,99))}
        val back=TextView(this).apply{text="←";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{finish()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(52),dp(50)));val title=TextView(this).apply{text="Flashcards";textSize=21f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)};bar.addView(title,LinearLayout.LayoutParams(0,-2,1f));root.addView(bar)
        val intro=TextView(this).apply{text="Anki decks (.apkg) live separately from your QBank. Imports are stored in a dedicated database so your existing questions and progress stay untouched.";textSize=13f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(16),dp(14),dp(16),dp(8))};root.addView(intro)
        val import=TextView(this).apply{text="＋  IMPORT .APKG";textSize=14f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=GradientDrawable().apply{setColor(Color.rgb(35,103,120));cornerRadius=16f};setOnClickListener{pickApkg()}}
        root.addView(import,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(dp(16),dp(5),dp(16),dp(12))})
        val head=TextView(this).apply{text="YOUR DECKS";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@FlashcardActivity));setPadding(dp(16),dp(4),dp(16),dp(6))};root.addView(head)
        val scroll=ScrollView(this).apply{isFillViewport=true};list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(2),dp(16),dp(20))};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));return root
    }
    private fun pickApkg(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE);putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/octet-stream","application/zip","application/x-zip-compressed"))},91)}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req!=91||res!=RESULT_OK||data?.data==null)return;val uri=data.data!!;try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Throwable){};val dlg=ProgressDialog(this).apply{setMessage("Importing Anki deck…\nLarge files may take a while.");setCancelable(false)};dlg.show();executor.execute{try{val r=ApkgImporter.importFile(this,uri);runOnUiThread{dlg.dismiss();Toast.makeText(this,"Imported ${r.cards} flashcards from ${r.decks} deck(s)",Toast.LENGTH_LONG).show();render()}}catch(e:Throwable){runOnUiThread{dlg.dismiss();Toast.makeText(this,"APKG import failed: ${e.message ?: "unsupported deck"}",Toast.LENGTH_LONG).show()}}}}
    private fun render(){list.removeAllViews();val decks=db.decks();if(decks.isEmpty()){list.addView(TextView(this).apply{text="No flashcard decks yet. Import an .apkg file to begin.";textSize=15f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(10),dp(20),dp(10),dp(20))});return};for(d in decks){val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@FlashcardActivity));cornerRadius=18f*resources.displayMetrics.density};setOnClickListener{startActivity(Intent(this@FlashcardActivity,FlashcardStudyActivity::class.java).putExtra("deckId",d.id).putExtra("deckName",d.name))}};val n=TextView(this).apply{text=d.name;textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@FlashcardActivity))};val sub=TextView(this).apply{text="${d.count} cards${if(d.source.isNullOrBlank())"" else "  •  ${d.source}"}";textSize=12.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(4),0,0)};card.addView(n);card.addView(sub);list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(9))})}}
    override fun onDestroy(){executor.shutdownNow();db.close();super.onDestroy()}
}
