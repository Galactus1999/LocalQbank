package com.localqbank.library

import android.os.Bundle
import android.widget.*
import android.view.*
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity

class NotesActivity:AppCompatActivity(){
    private lateinit var db:QBankDb
    override fun onCreate(b:Bundle?){super.onCreate(b);db=QBankDb(this);val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);setBackgroundColor(ThemeManager.bg(this@NotesActivity))};val back=Button(this).apply{text="← Back";setOnClickListener{finish()}};root.addView(back,LinearLayout.LayoutParams(-1,52));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};db.notes().forEach{(id,n)->val q=db.questionById(id);val tv=TextView(this).apply{text="${q?.text?.replace(Regex("<[^>]+>"),"")?.take(160) ?: "Question #$id"}\n\n$n";textSize=15f;typeface=Typeface.DEFAULT;setTextColor(ThemeManager.text(this@NotesActivity));setPadding(12,14,12,14);setOnClickListener{if(q!=null)startActivity(android.content.Intent(this@NotesActivity,QuizActivity::class.java).putExtra("testId",q.stableKey.substringBefore(":" )).putExtra("questionId",q.id).putExtra("title","My Note").putExtra("practiceMode",true))}};list.addView(tv)};root.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f));setContentView(root)}
    override fun onDestroy(){db.close();super.onDestroy()}
}
