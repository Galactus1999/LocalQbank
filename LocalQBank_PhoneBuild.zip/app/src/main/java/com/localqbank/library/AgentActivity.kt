package com.localqbank.library

import android.app.Activity
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import kotlin.math.*

class AgentActivity: Activity() {
    private lateinit var agent:StudyAgent
    private lateinit var mesh:MeshView
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        SystemUi.immersive(this)
        agent=StudyAgent(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(10),dp(16),dp(12));setBackgroundColor(ThemeManager.bg(this@AgentActivity))}
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val back=Button(this).apply{text="←";textSize=20f;setOnClickListener{finish()};minHeight=dp(48)}
        val title=TextView(this).apply{text="AI Study Agent";textSize=24f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@AgentActivity));setPadding(dp(8),0,0,0)}
        top.addView(back,LinearLayout.LayoutParams(dp(52),dp(52)));top.addView(title,LinearLayout.LayoutParams(0,dp(52),1f));root.addView(top)
        val sub=TextView(this).apply{text="Self-organising local knowledge mesh";textSize=13f;setTextColor(ThemeManager.muted(this@AgentActivity));setPadding(dp(60),0,0,dp(8))}
        root.addView(sub)
        mesh=MeshView();root.addView(mesh,LinearLayout.LayoutParams(-1,0,1f))
        val insight=TextView(this).apply{text="Observing your study behaviour…";textSize=15f;setTextColor(ThemeManager.text(this@AgentActivity));setPadding(dp(14),dp(12),dp(14),dp(12));background=rounded(ThemeManager.elevated(this@AgentActivity),16f)}
        root.addView(insight)
        val refresh=Button(this).apply{text="↻  Refresh agent state";textAllCaps=false;setOnClickListener{refresh(insight)}};root.addView(refresh,LinearLayout.LayoutParams(-1,dp(50)))
        setContentView(root); refresh(insight)
    }
    private fun refresh(insight:TextView){
        val refs=QBankDb(this).allQuestionRefs()
        val store=ProgressStore(this)
        val attempted=refs.count{store.status(it.stableKey)!=null};val wrong=refs.count{store.status(it.stableKey)=="wrong"}
        insight.text="Agent insight\n\n${agent.recommendation(refs.size,attempted,wrong)}\n\n${agent.nodes().size} learned nodes • ${agent.edges().size} relationships"
        mesh.setData(agent.nodes(),agent.edges())
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).roundToInt()
    private fun rounded(c:Int,r:Float)=android.graphics.drawable.GradientDrawable().apply{setColor(c);cornerRadius=r*resources.displayMetrics.density}
    override fun onDestroy(){agent.close();super.onDestroy()}

    private inner class MeshView:View(this@AgentActivity){
        private var ns:List<AgentDb.Node> = emptyList();private var es:List<AgentDb.Edge> = emptyList()
        private val p=Paint(Paint.ANTI_ALIAS_FLAG);private val line=Paint(Paint.ANTI_ALIAS_FLAG)
        fun setData(n:List<AgentDb.Node>,e:List<AgentDb.Edge>){ns=n;es=e;invalidate()}
        override fun onDraw(c:Canvas){
            super.onDraw(c); if(ns.isEmpty()){p.color=ThemeManager.muted(context);p.textSize=dpf(15);c.drawText("Start solving questions to grow the mesh.",24f,height/2f,p);return}
            val cx=width/2f;val cy=height/2f;val radius=min(width,height)*.34f
            val pts=HashMap<Long,PointF>(); ns.forEachIndexed{i,n->
                val angle=(-Math.PI/2)+(2*Math.PI*i/ns.size);pts[n.id]=PointF(cx+cos(angle).toFloat()*radius,cy+sin(angle).toFloat()*radius)
            }
            line.strokeWidth=dpf(1.2f)
            for(e in es){val a=pts[e.a];val b=pts[e.b];if(a!=null&&b!=null){line.color=ThemeManager.muted(context);line.alpha=(35+e.weight*150).toInt().coerceIn(25,185);c.drawLine(a.x,a.y,b.x,b.y,line)}}
            p.textAlign=Paint.Align.CENTER
            ns.forEach{n->
                val pt=pts[n.id]?:return@forEach
                val weak=1f-n.confidence
                p.color=if(weak>.45f)Color.rgb(190,92,70) else ThemeManager.accent(context)
                val r=dpf(9f)+(weak*10f)
                c.drawCircle(pt.x,pt.y,r,p)
                p.color=ThemeManager.text(context);p.textSize=dpf(10.5f)
                c.drawText(n.label.take(20),pt.x,pt.y+r+dpf(14f),p)
            }
            p.color=ThemeManager.text(context);p.textSize=dpf(16f);c.drawText("YOU",cx,cy+6f,p)
        }
        private fun dpf(v:Float)=v*resources.displayMetrics.density
    }
}
