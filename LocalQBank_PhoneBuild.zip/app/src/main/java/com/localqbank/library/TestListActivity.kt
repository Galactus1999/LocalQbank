package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TestListActivity:AppCompatActivity(){
    private lateinit var db:QBankDb
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);setContentView(makeRoot());db=QBankDb(this);val store=ProgressStore(this);val sid=intent.getLongExtra("sourceId",0);findViewById<TextView>(1001).text=intent.getStringExtra("sourceName")?:"Sections";findViewById<RecyclerView>(1002).apply{layoutManager=LinearLayoutManager(this@TestListActivity);adapter=TestAdapter(db.tests(sid),db,store){t,pos->startActivity(Intent(this@TestListActivity,QuizActivity::class.java).putExtra("testId",t.id).putExtra("title",t.title).putExtra("position",pos))}}}
    private fun makeRoot():LinearLayout{val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setBackgroundColor(Color.rgb(246,248,252));val bar=LinearLayout(this);SystemUi.padTopInset(bar,18,14,18,18);bar.setBackgroundColor(Color.rgb(16,24,40));val tv=TextView(this);tv.id=1001;tv.setTextColor(Color.WHITE);tv.textSize=20f;tv.setTypeface(null,1);bar.addView(tv);root.addView(bar);val rv=RecyclerView(this);rv.id=1002;rv.setPadding(14,8,14,20);root.addView(rv,LinearLayout.LayoutParams(-1,0,1f));return root}
}
class TestAdapter(private val items:List<Test>,private val db:QBankDb,private val store:ProgressStore,private val click:(Test,Int)->Unit):RecyclerView.Adapter<TestAdapter.VH>(){
 class VH(v:LinearLayout):RecyclerView.ViewHolder(v){val t=TextView(v.context);val s=TextView(v.context);init{v.orientation=LinearLayout.VERTICAL;v.setPadding(16,13,16,13);t.textSize=16f;t.setTextColor(Color.rgb(23,32,51));t.setTypeface(null,1);s.textSize=12f;s.setTextColor(Color.rgb(82,98,117));s.setPadding(0,6,0,0);v.addView(t);v.addView(s)}}
 override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{val v=LinearLayout(p.context);v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)};return VH(v)}
 override fun onBindViewHolder(h:VH,i:Int){val x=items[i];val pr=db.progressSummaryForTest(x.id,store);h.t.text=x.title;val timing=if(x.duration>0)"  •  ${x.duration/60} min" else "";h.s.text=when{pr.total==0->"No questions";pr.solved==0->"Not started  •  ${pr.total} questions$timing";pr.solved>=pr.total->"✓ Completed  •  ${pr.solved}/${pr.total} solved$timing";else->"↻ In progress  •  ${pr.solved}/${pr.total} solved  •  Resume$timing"};val bg=when(i%5){0->Color.rgb(235,245,255);1->Color.rgb(238,249,242);2->Color.rgb(255,245,228);3->Color.rgb(246,239,255);else->Color.rgb(255,237,241)};h.itemView.background=android.graphics.drawable.GradientDrawable().apply{setColor(bg);cornerRadius=18f*p.context.resources.displayMetrics.density};h.itemView.setOnClickListener{click(x,pr.resumePosition)} }
 override fun getItemCount()=items.size
}
