package com.localqbank.library

import android.app.Activity
import android.os.Build
import android.view.View
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

object SystemUi {
    fun immersive(activity: Activity) {
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        val decor = activity.window.decorView
        val controller = WindowInsetsControllerCompat(activity.window, decor)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
        if (Build.VERSION.SDK_INT >= 30) decor.windowInsetsController?.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
        decor.post { controller.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars()) }
    }

    /** Adds the real system-bar inset without permanently hard-coding the device status-bar height. */
    fun padTopInset(view: View, baseTopDp: Int, baseBottomDp: Int, baseStartDp: Int, baseEndDp: Int) {
        val d = view.resources.displayMetrics.density
        val top = (baseTopDp * d).toInt()
        val bottom = (baseBottomDp * d).toInt()
        val start = (baseStartDp * d).toInt()
        val end = (baseEndDp * d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.statusBars())
            v.setPadding(start, top + bars.top, end, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(view)
    }

    fun padBottomInset(view: View, baseTopDp: Int, baseBottomDp: Int) {
        val d = view.resources.displayMetrics.density
        val top = (baseTopDp * d).toInt()
        val bottom = (baseBottomDp * d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            v.setPadding(v.paddingLeft, top, v.paddingRight, bottom + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(view)
    }
}
