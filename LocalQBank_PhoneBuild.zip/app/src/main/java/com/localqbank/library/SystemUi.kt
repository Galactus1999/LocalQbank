package com.localqbank.library

import android.app.Activity
import android.view.View
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Centralized system-bar policy. We deliberately keep navigation gestures visible so Android
 * never enters immersive confirmation / double-swipe mode when moving between app sections. */
object SystemUi {
    fun immersive(activity: Activity) {
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        WindowCompat.setDecorFitsSystemWindows(activity.window, true)
        WindowCompat.getInsetsController(activity.window, activity.window.decorView).show(
            WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars()
        )
    }

    fun padTopInset(view: View, baseTopDp: Int, baseBottomDp: Int, baseStartDp: Int, baseEndDp: Int) {
        val d = view.resources.displayMetrics.density
        val top = (baseTopDp * d).toInt()
        val bottom = (baseBottomDp * d).toInt()
        val start = (baseStartDp * d).toInt()
        val end = (baseEndDp * d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.statusBars())
            v.setPadding(start, top + bars.top, end, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(view)
    }

    fun padBottomInset(view: View, baseTopDp: Int, baseBottomDp: Int) {
        val d = view.resources.displayMetrics.density
        val top = (baseTopDp * d).toInt()
        val bottom = (baseBottomDp * d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            v.setPadding(v.paddingLeft, top, v.paddingRight, bottom + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(view)
    }
}
