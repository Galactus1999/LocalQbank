package com.localqbank.library

import android.app.Activity
import android.view.View
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Centralized system-bar policy. Keep system bars visible and let Android handle back gestures.
 * Content is laid out inside the system-bar-safe area; callers should not add the same inset twice. */
object SystemUi {
    fun immersive(activity: Activity) {
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        WindowCompat.setDecorFitsSystemWindows(activity.window, true)
        WindowCompat.getInsetsController(activity.window, activity.window.decorView).show(
            WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars()
        )
    }

    fun padTopInset(view: View, baseTopDp: Int, baseBottomDp: Int, baseStartDp: Int, baseEndDp: Int) {
        val d = view.resources.displayMetrics.density
        val top = (baseTopDp * d).toInt()
        val bottom = (baseBottomDp * d).toInt()
        val start = (baseStartDp * d).toInt()
        val end = (baseEndDp * d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            // With decorFitsSystemWindows=true the content root is already below the status bar.
            // Adding bars.top here used to double-inset headers and made the top app bar look cut.
            v.setPadding(start, top, end, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(view)
    }

    fun padBottomInset(view: View, baseTopDp: Int, baseBottomDp: Int) {
        val d = view.resources.displayMetrics.density
        val top = (baseTopDp * d).toInt()
        val bottom = (baseBottomDp * d).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            // The content root is already above the navigation bar when decorFitsSystemWindows=true.
            v.setPadding(v.paddingLeft, top, v.paddingRight, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(view)
    }
}
