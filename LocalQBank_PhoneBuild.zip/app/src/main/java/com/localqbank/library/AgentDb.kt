package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.util.Locale

/**
 * Local-first memory for the Study Agent.
 * It stores events and a self-organising concept mesh; no network is required.
 */
class AgentDb(context: Context) {
    private val db: SQLiteDatabase = context.applicationContext.openOrCreateDatabase("agent.db", Context.MODE_PRIVATE, null)
    init {
        db.enableWriteAheadLogging()
        db.execSQL("CREATE TABLE IF NOT EXISTS agent_node(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT UNIQUE NOT NULL, label TEXT NOT NULL, kind TEXT NOT NULL, strength REAL DEFAULT 0, confidence REAL DEFAULT 0.5, visits INTEGER DEFAULT 0, last_seen INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS agent_edge(id INTEGER PRIMARY KEY AUTOINCREMENT, a INTEGER NOT NULL, b INTEGER NOT NULL, weight REAL DEFAULT 0.1, hits INTEGER DEFAULT 0, last_seen INTEGER DEFAULT 0, UNIQUE(a,b), FOREIGN KEY(a) REFERENCES agent_node(id) ON DELETE CASCADE, FOREIGN KEY(b) REFERENCES agent_node(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS agent_event(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, question_id INTEGER, test_id TEXT, payload TEXT, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_agent_node_kind ON agent_node(kind)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_agent_edge_a ON agent_edge(a)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_agent_event_time ON agent_event(created_at)")
    }

    data class Node(val id:Long,val key:String,val label:String,val kind:String,val strength:Float,val confidence:Float,val visits:Int)
    data class Edge(val a:Long,val b:Long,val weight:Float)

    @Synchronized fun node(key:String,label:String,kind:String):Long {
        val now=System.currentTimeMillis()
        db.execSQL("INSERT OR IGNORE INTO agent_node(key,label,kind,last_seen) VALUES(?,?,?,?)",arrayOf(key,label,kind,now))
        db.execSQL("UPDATE agent_node SET visits=visits+1,last_seen=? WHERE key=?",arrayOf(now,key))
        return db.rawQuery("SELECT id FROM agent_node WHERE key=?",arrayOf(key)).use{c->c.moveToFirst();c.getLong(0)}
    }

    @Synchronized fun learnNode(id:Long, correct:Boolean, learningSignal:Float=1f) {
        val old=db.rawQuery("SELECT confidence,strength FROM agent_node WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())floatArrayOf(c.getFloat(0),c.getFloat(1)) else floatArrayOf(.5f,0f)}
        // Exponential update: recent evidence matters more than stale evidence.
        val target=if(correct) 1f else 0f
        val confidence=(old[0]*0.82f+target*0.18f).coerceIn(.02f,.98f)
        val strength=(old[1]*0.90f+learningSignal.coerceIn(0f,1f)*0.10f).coerceIn(0f,1f)
        db.execSQL("UPDATE agent_node SET confidence=?,strength=?,last_seen=? WHERE id=?",arrayOf(confidence,strength,System.currentTimeMillis(),id))
    }

    @Synchronized fun connect(a:Long,b:Long,delta:Float=0.08f) {
        if(a==b)return
        val x=minOf(a,b); val y=maxOf(a,b); val now=System.currentTimeMillis()
        db.execSQL("INSERT OR IGNORE INTO agent_edge(a,b,weight,hits,last_seen) VALUES(?,?,?,0,?)",arrayOf(x,y,delta.coerceIn(.01f,.5f),now))
        db.execSQL("UPDATE agent_edge SET weight=MIN(1.0,weight+?),hits=hits+1,last_seen=? WHERE a=? AND b=?",arrayOf(delta,now,x,y))
    }

    @Synchronized fun event(type:String,questionId:Long?,testId:String?,payload:String?){
        db.execSQL("INSERT INTO agent_event(type,question_id,test_id,payload,created_at) VALUES(?,?,?,?,?)",arrayOf(type,questionId,testId,payload,System.currentTimeMillis()))
    }

    fun nodes(limit:Int=80):List<Node> = db.rawQuery("SELECT id,key,label,kind,strength,confidence,visits FROM agent_node ORDER BY (strength*0.6 + (1-confidence)*0.8 + MIN(visits,20)*0.01) DESC,last_seen DESC LIMIT ?",arrayOf(limit.coerceIn(1,200).toString())).use{c->
        buildList{while(c.moveToNext())add(Node(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getFloat(4),c.getFloat(5),c.getInt(6)))}
    }
    fun edges(limit:Int=240):List<Edge> = db.rawQuery("SELECT a,b,weight FROM agent_edge ORDER BY weight DESC LIMIT ?",arrayOf(limit.coerceIn(1,500).toString())).use{c->
        buildList{while(c.moveToNext())add(Edge(c.getLong(0),c.getLong(1),c.getFloat(2)))}
    }
    fun close(){runCatching{db.close()}}
}
