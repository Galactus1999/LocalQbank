package com.localqbank.library

import android.content.Context
import android.graphics.Color

object ThemeManager {
    const val LIGHT = "light"
    const val DARK = "dark"
    const val SEPIA = "sepia"

    fun get(context: Context): String = context.getSharedPreferences("ui", Context.MODE_PRIVATE).getString("theme", LIGHT) ?: LIGHT
    fun set(context: Context, value: String) { context.getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putString("theme", value).apply() }

    // High-contrast dark palette: cool neutral surfaces + restrained blue accent.
    fun bg(context: Context): Int = when(get(context)) { DARK -> Color.rgb(9, 13, 18); SEPIA -> Color.rgb(246,239,218); else -> Color.rgb(247,249,246) }
    fun panel(context: Context): Int = when(get(context)) { DARK -> Color.rgb(17, 23, 30); SEPIA -> Color.rgb(251,245,227); else -> Color.rgb(251,253,250) }
    fun elevated(context: Context): Int = when(get(context)) { DARK -> Color.rgb(24, 32, 42); SEPIA -> Color.rgb(255,248,231); else -> Color.WHITE }
    fun text(context: Context): Int = when(get(context)) { DARK -> Color.rgb(235,240,247); SEPIA -> Color.rgb(70,57,39); else -> Color.rgb(21,38,59) }
    fun muted(context: Context): Int = when(get(context)) { DARK -> Color.rgb(176,188,202); SEPIA -> Color.rgb(111,94,69); else -> Color.rgb(80,94,110) }
    fun accent(context: Context): Int = when(get(context)) { DARK -> Color.rgb(157,194,255); SEPIA -> Color.rgb(91,74,45); else -> Color.rgb(24,91,130) }
    fun optionBg(context: Context): Int = when(get(context)) { DARK -> Color.rgb(27,37,49); SEPIA -> Color.rgb(250,243,223); else -> Color.rgb(232,242,251) }
    fun optionText(context: Context): Int = when(get(context)) { DARK -> Color.rgb(232,239,248); SEPIA -> Color.rgb(68,54,36); else -> Color.rgb(18,39,61) }
    fun correctBg(context: Context): Int = when(get(context)) { DARK -> Color.rgb(19,58,43); SEPIA -> Color.rgb(224,239,220); else -> Color.rgb(220,244,228) }
    fun correctText(context: Context): Int = when(get(context)) { DARK -> Color.rgb(177,246,207); SEPIA -> Color.rgb(35,91,54); else -> Color.rgb(17,91,54) }
    fun wrongBg(context: Context): Int = when(get(context)) { DARK -> Color.rgb(67,29,38); SEPIA -> Color.rgb(247,225,225); else -> Color.rgb(252,226,230) }
    fun wrongText(context: Context): Int = when(get(context)) { DARK -> Color.rgb(255,190,201); SEPIA -> Color.rgb(120,38,52); else -> Color.rgb(137,36,52) }
    fun explanationBg(context: Context): Int = when(get(context)) { DARK -> Color.rgb(24,33,44); SEPIA -> Color.rgb(237,225,199); else -> Color.rgb(232,244,252) }
    fun explanationTitle(context: Context): Int = when(get(context)) { DARK -> Color.rgb(164,207,255); SEPIA -> Color.rgb(76,62,42); else -> Color.rgb(35,91,125) }
    fun bookmarkFill(context: Context, type: String): Int = when(get(context)) {
        DARK -> when(type.lowercase()) {
            "important" -> Color.rgb(61,48,12)
            "revise" -> Color.rgb(18,48,78)
            "doubt" -> Color.rgb(42,47,55)
            "favorite", "favourite" -> Color.rgb(70,27,39)
            else -> Color.rgb(35,43,52)
        }
        else -> when(type.lowercase()) {
            "important" -> Color.rgb(255,238,184)
            "revise" -> Color.rgb(216,235,255)
            "doubt" -> Color.rgb(232,237,241)
            "favorite", "favourite" -> Color.rgb(255,221,229)
            else -> Color.rgb(232,239,244)
        }
    }
    fun bookmarkText(context: Context, type: String): Int = when(get(context)) {
        DARK -> when(type.lowercase()) {
            "important" -> Color.rgb(255,219,105)
            "revise" -> Color.rgb(151,211,255)
            "doubt" -> Color.rgb(210,218,228)
            "favorite", "favourite" -> Color.rgb(255,171,190)
            else -> Color.rgb(225,233,242)
        }
        else -> when(type.lowercase()) {
            "important" -> Color.rgb(105,72,0)
            "revise" -> Color.rgb(18,78,135)
            "doubt" -> Color.rgb(52,64,78)
            "favorite", "favourite" -> Color.rgb(139,38,65)
            else -> Color.rgb(35,52,70)
        }
    }
}
