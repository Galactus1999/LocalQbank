package com.localqbank.library

import android.content.Context
import android.graphics.Color

object ThemeManager {
    const val LIGHT = "light"
    const val DARK = "dark"
    const val SEPIA = "sepia"
    fun get(context: Context): String = context.getSharedPreferences("ui", Context.MODE_PRIVATE).getString("theme", LIGHT) ?: LIGHT
    fun set(context: Context, value: String) { context.getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putString("theme", value).apply() }
    fun bg(context: Context): Int = when(get(context)) { DARK -> Color.rgb(25,28,31); SEPIA -> Color.rgb(246,239,218); else -> Color.rgb(247,249,246) }
    fun panel(context: Context): Int = when(get(context)) { DARK -> Color.rgb(32,36,40); SEPIA -> Color.rgb(251,245,227); else -> Color.rgb(251,253,250) }
    fun text(context: Context): Int = when(get(context)) { DARK -> Color.rgb(232,236,239); SEPIA -> Color.rgb(70,57,39); else -> Color.rgb(21,38,59) }
    fun muted(context: Context): Int = when(get(context)) { DARK -> Color.rgb(170,180,188); SEPIA -> Color.rgb(111,94,69); else -> Color.rgb(80,94,110) }
}
