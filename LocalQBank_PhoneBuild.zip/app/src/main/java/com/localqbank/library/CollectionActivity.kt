package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CollectionActivity:AppCompatActivity(){
 private lateinit var db:QBankDb; private lateinit var store:ProgressStore
 override fun onCreate(b:Bundle?){super.onCreate(b);db=QBankDb(this);store=ProgressStore(this);val type=intent.getStringExtra("filterType")?:"status";val value=intent.getStringExtra("filterValue")?:"unsolved";val refs=db.allQuestionRefs().filter{when(type){"status"->if(value=="unsolved")store.status(it.stableKey)==null else store.status(it.stableKey)==value;"bookmark"->if(value=="all")!store.bookmark(it.stableKey).isNullOrBlank() else store.bookmark(it.stableKey)==value;else->false}};setContentView(makeRoot(title(type,value),refs))}
 private fun title(type:String,v:String)=if(type=="bookmark")if(v=="all")"All Bookmarked" else v.replaceFirstChar{it.uppercase()} else v.replaceFirstChar{it.uppercase()}
 private fun makeRoot(t:String,items:List<QuestionRef>):LinearLayout{val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setBackgroundColor(Color.rgb(246,248,252));val bar=TextView(this);bar.text="$t  •  ${items.size}";bar.textSize=20f;bar.setTextColor(Color.WHITE);bar.setTypeface(null,1);bar.setPadding(18,18,18,18);bar.setBackgroundColor(Color.rgb(18,43,78));root.addView(bar);val rv=RecyclerView(this);rv.layoutManager=LinearLayoutManager(this);rv.adapter=RefAdapter(items){r->startActivity(Intent(this,QuizActivity::class.java).putExtra("testId",r.testId).putExtra("title",r.testTitle).putExtra("position",r.position))};root.addView(rv,LinearLayout.LayoutParams(-1,0,1f));return root}
 override fun onDestroy(){db.close();super.onDestroy()}
}
class RefAdapter(private val items:List<QuestionRef>,private val click:(QuestionRef)->Unit):RecyclerView.Adapter<RefAdapter.VH>(){
 class VH(v:LinearLayout):RecyclerView.ViewHolder(v){val t=TextView(v.context);val s=TextView(v.context);init{v.orientation=LinearLayout.VERTICAL;v.setPadding(16,14,16,14);v.setBackgroundColor(Color.WHITE);t.textSize=15f;t.setTextColor(Color.rgb(23,32,51));s.textSize=12f;s.setTextColor(Color.rgb(102,112,133));s.setPadding(0,6,0,0);v.addView(t);v.addView(s)}}
 override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{val v=LinearLayout(p.context);v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(10,6,10,6)};return VH(v)}
 override fun onBindViewHolder(h:VH,i:Int){val x=items[i];h.t.text="Q${x.position+1}. ${android.text.Html.fromHtml(x.text,android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim().take(180)}";h.s.text="${x.testTitle} • ${x.sourceName}";h.itemView.setOnClickListener{click(x)}}
 override fun getItemCount()=items.size
}
