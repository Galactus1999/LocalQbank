package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CollectionActivity : AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var store: ProgressStore
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        db = QBankDb(this)
        store = ProgressStore(this)
        val type = intent.getStringExtra("filterType") ?: "status"
        val value = intent.getStringExtra("filterValue") ?: "unsolved"
        val refs = db.allQuestionRefs().filter {
            when (type) {
                "status" -> if (value == "unsolved") store.status(it.stableKey) == null else store.status(it.stableKey) == value
                "bookmark" -> if (value == "all") !store.bookmark(it.stableKey).isNullOrBlank() else store.bookmark(it.stableKey) == value
                else -> false
            }
        }
        setContentView(makeRoot(title(type, value), refs))
    }

    private fun title(type: String, v: String) = if (type == "bookmark") {
        if (v == "all") "All Bookmarked" else v.replaceFirstChar { it.uppercase() }
    } else v.replaceFirstChar { it.uppercase() }

    private fun makeRoot(t: String, items: List<QuestionRef>): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        val barRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=android.view.Gravity.CENTER_VERTICAL; setBackgroundColor(Color.rgb(22,72,112)) }
        val back = TextView(this).apply { text="‹"; textSize=34f; setTextColor(Color.WHITE); gravity=android.view.Gravity.CENTER; setOnClickListener{finish()} }
        barRow.addView(back, LinearLayout.LayoutParams(52, dp(60)))
        val bar = TextView(this).apply {
            text = "$t  •  ${items.size}"
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(22, 72, 112))
        }
        SystemUi.padTopInset(bar, 12, 12, 18, 18)
        barRow.addView(bar, LinearLayout.LayoutParams(0,-1,1f)); SystemUi.padTopInset(barRow, 12, 12, 0, 18); root.addView(barRow)
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@CollectionActivity)
            adapter = RefAdapter(grouped(items)) { r ->
                startActivity(Intent(this@CollectionActivity, QuizActivity::class.java)
                    .putExtra("testId", r.testId)
                    .putExtra("title", r.testTitle)
                    .putExtra("position", r.position)
                    .putExtra("sectionLabel", t))
            }
        }
        root.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun grouped(items: List<QuestionRef>): List<CollectionRow> {
        val out = mutableListOf<CollectionRow>()
        var last = ""
        items.forEach { item ->
            if (item.category != last) {
                last = item.category
                out.add(CollectionRow.Header(item.category))
            }
            out.add(CollectionRow.Question(item))
        }
        return out
    }

    override fun onDestroy() {
        db.close()
        super.onDestroy()
    }
}

sealed class CollectionRow {
    data class Header(val name: String) : CollectionRow()
    data class Question(val ref: QuestionRef) : CollectionRow()
}

class RefAdapter(private val items: List<CollectionRow>, private val click: (QuestionRef) -> Unit) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private companion object { const val HEADER = 0; const val QUESTION = 1 }

    override fun getItemViewType(position: Int) = if (items[position] is CollectionRow.Header) HEADER else QUESTION

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): RecyclerView.ViewHolder {
        if (type == HEADER) {
            val v = TextView(parent.context).apply {
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.rgb(33, 78, 116))
                setPadding(13, 8, 13, 8)
                background = GradientDrawable().apply {
                    setColor(Color.rgb(224, 237, 248))
                    cornerRadius = 18f
                }
            }
            return HeaderVH(v)
        }
        val v = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.WHITE)
        }
        val t = TextView(parent.context).apply { textSize = 15f; setTextColor(Color.rgb(23, 32, 51)) }
        val s = TextView(parent.context).apply { textSize = 12f; setTextColor(Color.rgb(102, 112, 133)); setPadding(0, 6, 0, 0) }
        v.addView(t); v.addView(s)
        return QuestionVH(v, t, s)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = items[position]) {
            is CollectionRow.Header -> (holder as HeaderVH).v.text = row.name
            is CollectionRow.Question -> {
                val h = holder as QuestionVH
                val x = row.ref
                h.t.text = "Q${x.position + 1}. ${android.text.Html.fromHtml(x.text, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim().take(180)}"
                h.s.text = "${x.testTitle} • ${x.sourceName}"
                h.itemView.setOnClickListener { click(x) }
            }
        }
    }

    override fun getItemCount() = items.size
    class HeaderVH(val v: TextView) : RecyclerView.ViewHolder(v)
    class QuestionVH(v: LinearLayout, val t: TextView, val s: TextView) : RecyclerView.ViewHolder(v) {
        init { v.layoutParams = RecyclerView.LayoutParams(-1, -2).apply { setMargins(10, 6, 10, 6) } }
    }
}
