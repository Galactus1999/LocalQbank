package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.roundToInt
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

private fun roundedDrawable(context: Context, color: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply {
    setColor(color)
    cornerRadius = radius * context.resources.displayMetrics.density
}

class MainActivity: AppCompatActivity(){
    private val stateListener:()->Unit={if(!isFinishing && !isDestroyed && hasWindowFocus())runOnUiThread{if(::db.isInitialized)render()}}
    private fun dp(value:Int):Int = (value * resources.displayMetrics.density).roundToInt()
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);setContentView(R.layout.activity_main);SystemUi.padTopInset(findViewById(R.id.mainHeader),0,0,14,10);db=QBankDb(this);store=ProgressStore(this); AppState.register(stateListener)
        styleHeaderControls()
        findViewById<Button>(R.id.themeButton)?.setOnClickListener{showThemeMenu(it)};findViewById<Button>(R.id.backupButton)?.setOnClickListener{startActivity(Intent(this,BackupActivity::class.java))};findViewById<Button>(R.id.searchNav)?.setOnClickListener{startActivity(Intent(this,SearchActivity::class.java).putExtra("focusSearch",true))};findViewById<Button>(R.id.dashboardNav)?.setOnClickListener{};render()}
    override fun onResume(){super.onResume(); if(::db.isInitialized) render()}
    override fun onStop(){ if(::db.isInitialized) BackupManager(this).flushCloudBackup(); super.onStop() }
    private fun styleHeaderControls(){
        val white=android.content.res.ColorStateList.valueOf(Color.WHITE)
        // Theme and Backup each get their own accent color now (previously both were
        // painted rgb(49,95,123), which is the exact same color as the header background
        // #315F7B, so the buttons barely read as tappable controls). Amber for Theme,
        // teal for Backup gives real separation from the header and from each other.
        listOf(
            R.id.themeButton to Triple(R.drawable.ic_theme_mode, Color.rgb(138,90,34), Color.argb(130,255,224,170)),
            R.id.backupButton to Triple(R.drawable.ic_backup_cloud, Color.rgb(27,110,99), Color.argb(130,180,255,235))
        ).forEach{(id,triple)->
            val(icon,fill,stroke)=triple
            findViewById<Button>(id)?.apply{
                setTextColor(Color.WHITE); backgroundTintList=null
                background=GradientDrawable().apply{setColor(fill);cornerRadius=12f*resources.displayMetrics.density;setStroke(dp(1),stroke)}
                compoundDrawableTintList=white
                textSize=11.5f; minHeight=dp(44); isAllCaps=false; gravity=Gravity.CENTER
                setPadding(dp(4),dp(2),dp(4),dp(2))
                setCompoundDrawablesWithIntrinsicBounds(null,getDrawable(icon),null,null)
                compoundDrawablePadding=dp(1)
            }
        }
        // Add QBank now lives beside the "Dashboard" heading on the light body background,
        // so it needs a solid dark pill instead of the white-on-header treatment it used to have.
        findViewById<Button>(R.id.addButton)?.apply{
            backgroundTintList=null
            background=GradientDrawable().apply{setColor(Color.rgb(18,48,79));cornerRadius=20f*resources.displayMetrics.density}
            setTextColor(Color.WHITE); minHeight=dp(40); isAllCaps=false
            setPadding(dp(16),dp(2),dp(16),dp(2))
            elevation=dp(2).toFloat()
        }
        findViewById<ImageView>(R.id.appLogoText)?.setColorFilter(Color.WHITE)
    }

    private fun render(){
        styleHeaderControls()
        findViewById<View>(R.id.dashboardRoot)?.setBackgroundColor(ThemeManager.bg(this@MainActivity))
        val refs=db.allQuestionRefs()
        val total=refs.size
        val solved=refs.count{store.status(it.stableKey)=="correct"}
        val wrong=refs.count{store.status(it.stableKey)=="wrong"}
        val attempted=solved+wrong
        val bookmarked=refs.count{!store.bookmark(it.stableKey).isNullOrBlank()}
        val accuracy=if(attempted==0)0 else (solved*100.0/attempted).roundToInt()
        val due=todaysRevisionCount(refs)
        findViewById<TextView>(R.id.dashboardOverview).text="${db.sources().size} QBanks • $total questions • $attempted attempted • $accuracy% accuracy"
        findViewById<TextView>(R.id.analyticsSub)?.text="$solved correct • $wrong wrong • $bookmarked bookmarked"
        findViewById<TextView>(R.id.analyticsAccuracy)?.text="$accuracy%"
        findViewById<TextView>(R.id.analyticsAttempted)?.text="$attempted"
        findViewById<TextView>(R.id.analyticsDue)?.text="$due"
        findViewById<ProgressBar>(R.id.analyticsProgress)?.apply { progress = accuracy; progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(34,125,143)); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(40,80,100,120)) }
        findViewById<TextView>(R.id.todaySolvedCount)?.apply{textSize=30f;text="${todaySolvedCount(refs)}"}
        findViewById<TextView>(R.id.studyMenuSub)?.text="Smart tools • tests • PYQ • notes"
        listOf(R.id.analyticsCard to R.id.analyticsCardAction).forEach{(card,action)->
            val bg=if(ThemeManager.get(this@MainActivity)==ThemeManager.DARK) ThemeManager.elevated(this@MainActivity) else Color.rgb(249,251,247)
            findViewById<View>(card)?.background=GradientDrawable().apply{setColor(bg);cornerRadius=16f*resources.displayMetrics.density;setStroke(dp(1),if(ThemeManager.get(this@MainActivity)==ThemeManager.DARK) Color.rgb(48,61,75) else Color.rgb(224,232,226))}
            findViewById<View>(action)?.background=GradientDrawable().apply{setColor(if(ThemeManager.get(this@MainActivity)==ThemeManager.DARK) Color.rgb(29,55,72) else Color.rgb(225,241,243));cornerRadius=10f*resources.displayMetrics.density}
        }
        findViewById<View>(R.id.analyticsCard)?.setOnClickListener{showInteractiveAnalytics(refs)}
        findViewById<View>(R.id.analyticsCardAction)?.setOnClickListener{showInteractiveAnalytics(refs)}
        findViewById<View>(R.id.todaySolvedCard)?.setOnClickListener{startTodaySolved(refs)}
        findViewById<View>(R.id.studyMenuCard)?.setOnClickListener{startActivity(Intent(this,StudyToolsActivity::class.java))}
        findViewById<View>(R.id.flashcardCard)?.apply{background=GradientDrawable().apply{setColor(if(ThemeManager.get(this@MainActivity)==ThemeManager.DARK)Color.rgb(23,48,52) else Color.rgb(231,248,245));cornerRadius=18f*resources.displayMetrics.density};setOnClickListener{startActivity(Intent(this@MainActivity,FlashcardActivity::class.java))}}
        applyDashboardTheme()
        setCollectionButton(R.id.importantButton,"★ Important",refs.count{store.bookmark(it.stableKey)=="important"},ThemeManager.bookmarkFill(this@MainActivity,"important"),ThemeManager.bookmarkText(this@MainActivity,"important"))
        setCollectionButton(R.id.reviseButton,"↻ Revise",refs.count{store.bookmark(it.stableKey)=="revise"},ThemeManager.bookmarkFill(this@MainActivity,"revise"),ThemeManager.bookmarkText(this@MainActivity,"revise"))
        setCollectionButton(R.id.doubtButton,"❔ Doubt",refs.count{store.bookmark(it.stableKey)=="doubt"},ThemeManager.bookmarkFill(this@MainActivity,"doubt"),ThemeManager.bookmarkText(this@MainActivity,"doubt"))
        setCollectionButton(R.id.favoriteButton,"♥ Favourite",refs.count{store.bookmark(it.stableKey)=="favorite"},ThemeManager.bookmarkFill(this@MainActivity,"favorite"),ThemeManager.bookmarkText(this@MainActivity,"favorite"))
        styleDashboardCards()
        findViewById<Button>(R.id.addButton).setOnClickListener{openImporter()}
        setupCollection(R.id.importantButton,"bookmark","important"); setupCollection(R.id.reviseButton,"bookmark","revise"); setupCollection(R.id.doubtButton,"bookmark","doubt"); setupCollection(R.id.favoriteButton,"bookmark","favorite")
        val list=findViewById<LinearLayout>(R.id.libraryList); list.removeAllViews(); db.sources().forEachIndexed{index,source->addSourceCard(list,source,index)}
    }
    private fun todaySolvedCount(refs:List<QuestionRef>):Int{
        val since=System.currentTimeMillis()-86_400_000L
        return refs.count{store.lastAttempted(it.stableKey)>=since && (store.status(it.stableKey)=="correct" || store.status(it.stableKey)=="wrong")}
    }
    private fun startTodaySolved(refs:List<QuestionRef>){
        val since=System.currentTimeMillis()-86_400_000L
        val ids=refs.filter{store.lastAttempted(it.stableKey)>=since && (store.status(it.stableKey)=="correct" || store.status(it.stableKey)=="wrong")}.map{it.id}.toLongArray()
        if(ids.isEmpty()){Toast.makeText(this,"No questions solved today",Toast.LENGTH_SHORT).show();return}
        startActivity(Intent(this,QuizActivity::class.java).putExtra("sessionIds",ids.joinToString(",")).putExtra("collectionMode",true).putExtra("title","Today’s Solved").putExtra("position",0).putExtra("practiceMode",true))
    }
    private fun todaysRevisionCount(refs:List<QuestionRef>):Int{
        val now=System.currentTimeMillis(); val day=86_400_000L
        return refs.count{val st=store.status(it.stableKey); val last=store.lastAttempted(it.stableKey); st==null || last==0L || now-last>=when(store.attempts(it.stableKey)){1->day;2->3*day;3->7*day;4->14*day;else->30*day}}
    }
    private fun startTodayRevision(refs:List<QuestionRef>){
        val now=System.currentTimeMillis(); val day=86_400_000L
        val ids=refs.filter{val st=store.status(it.stableKey);val last=store.lastAttempted(it.stableKey);st==null || last==0L || now-last>=when(store.attempts(it.stableKey)){1->day;2->3*day;3->7*day;4->14*day;else->30*day}}.take(100).map{it.id}.toLongArray()
        if(ids.isEmpty()){Toast.makeText(this,"No revision questions due today",Toast.LENGTH_SHORT).show();return}
        startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Today's Revision").putExtra("practiceMode",true).putExtra("title","Today's Revision"))
    }
    private fun showInteractiveAnalytics(allRefs:List<QuestionRef>,periodDays:Int=0){
        val refs=if(periodDays<=0) allRefs else { val since=System.currentTimeMillis()-periodDays*86_400_000L; allRefs.filter{store.lastAttempted(it.stableKey)>=since} }
        val solved=refs.count{store.status(it.stableKey)=="correct"}
        val wrong=refs.count{store.status(it.stableKey)=="wrong"}
        val attempted=solved+wrong
        val total=refs.size
        val accuracy=if(attempted==0)0 else (solved*100/attempted)
        val mastery=if(total==0)0 else (solved*100/total)
        val due=todaysRevisionCount(refs)
        val notes=db.notes().size
        val bookmarks=refs.count{!store.bookmark(it.stableKey).isNullOrBlank()}
        val avgMs=refs.mapNotNull{store.timeMs(it.stableKey).takeIf{v->v>0}}.let{if(it.isEmpty())0L else it.sum()/it.size}
        val todaySince=System.currentTimeMillis()-86_400_000L
        val today=refs.count{store.lastAttempted(it.stableKey)>=todaySince}
        val dark=ThemeManager.get(this)==ThemeManager.DARK
        val dialog=Dialog(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@MainActivity))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(18),dp(12),dp(10),dp(8));background=GradientDrawable().apply{setColor(if(dark)Color.rgb(18,43,57)else Color.rgb(24,84,108));cornerRadius=0f}}
        top.addView(TextView(this).apply{text="⚡ PERFORMANCE LAB";textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(TextView(this).apply{text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(dp(48),dp(48)))
        root.addView(top)
        val periods=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(10),dp(12),dp(2))}
        listOf(1 to "DAILY",7 to "WEEKLY",30 to "MONTHLY",0 to "ALL TIME").forEach{(days,label)->
            val selected=periodDays==days
            val chip=TextView(this).apply{text=label;textSize=10.5f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(if(selected)Color.WHITE else ThemeManager.text(this@MainActivity));background=roundedDrawable(this@MainActivity,if(selected)ThemeManager.accent(this@MainActivity) else ThemeManager.elevated(this@MainActivity),14f);setPadding(dp(8),dp(7),dp(8),dp(7));setOnClickListener{dialog.dismiss();showInteractiveAnalytics(allRefs,days)}}
            periods.addView(chip,LinearLayout.LayoutParams(0,dp(38),1f).apply{setMargins(dp(3),0,dp(3),0)})
        }
        root.addView(periods)
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(26))}

        val hero=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(16),dp(14),dp(16));background=GradientDrawable().apply{setColor(if(dark)Color.rgb(24,42,55)else Color.rgb(233,247,250));cornerRadius=24f}}
        hero.addView(PerformanceRing(this,accuracy,mastery,dark),LinearLayout.LayoutParams(dp(126),dp(126)))
        val heroText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(4),0)}
        heroText.addView(TextView(this).apply{text=when{attempted==0->"Ready to build your profile";accuracy>=85->"Elite accuracy zone";accuracy>=70->"Strong base — sharpen weak areas";else->"High-yield opportunity zone"};textSize=19f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity))})
        heroText.addView(TextView(this).apply{text="${accuracy}% accuracy  •  ${mastery}% mastery";textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@MainActivity));setPadding(0,dp(7),0,dp(5))})
        heroText.addView(TextView(this).apply{text="${today} questions in this period. ${if(due>0)"${due} questions are waiting for revision." else "No revision backlog is waiting."}";textSize=12.5f;setTextColor(ThemeManager.muted(this@MainActivity));setLineSpacing(0f,1.15f)})
        hero.addView(heroText,LinearLayout.LayoutParams(0,-2,1f));box.addView(hero)

        val section=TextView(this).apply{text="YOUR CONTROL PANEL";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@MainActivity));setPadding(dp(2),dp(18),dp(2),dp(8))};box.addView(section)
        val actionRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f}
        fun action(label:String,value:String,bg:Int,click:()->Unit){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(7),dp(11),dp(7),dp(10));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(27,35,45)else bg,18f);setOnClickListener{click()}};c.addView(TextView(this).apply{text=value;textSize=22f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@MainActivity))});c.addView(TextView(this).apply{text=label;textSize=10.5f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@MainActivity))});actionRow.addView(c,LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(3),0,dp(3),0)})}
        action("WRONG",wrong.toString(),Color.rgb(253,232,235)){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","status").putExtra("filterValue","wrong"))}
        action("DUE NOW",due.toString(),Color.rgb(255,243,214)){startTodayRevision(refs)}
        action("UNSOLVED",(total-attempted).coerceAtLeast(0).toString(),Color.rgb(230,241,248)){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","status").putExtra("filterValue","unsolved"))}
        box.addView(actionRow)

        val speed=if(avgMs>0)"${(avgMs/1000).coerceAtLeast(1)}s / question" else "—"
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f;setPadding(0,dp(10),0,0)}
        fun metric(label:String,value:String){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(11),dp(10),dp(8),dp(10));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(22,29,38)else Color.rgb(248,250,252),16f)};c.addView(TextView(this).apply{text=value;textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity))});c.addView(TextView(this).apply{text=label;textSize=10.5f;setTextColor(ThemeManager.muted(this@MainActivity));setPadding(0,dp(3),0,0)});stats.addView(c,LinearLayout.LayoutParams(0,dp(70),1f).apply{setMargins(dp(3),0,dp(3),0)})}
        metric("AVG TIME",speed);metric("BOOKMARKS",bookmarks.toString());metric("NOTES",notes.toString());box.addView(stats)

        box.addView(TextView(this).apply{text="QBANK FOCUS MAP";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@MainActivity));setPadding(dp(2),dp(18),dp(2),dp(7))})
        val sources=db.sources()
        sources.take(10).forEachIndexed{idx,src->
            val r=refs.filter{it.sourceName==src.fileName}; val a=r.count{store.status(it.stableKey)!=null}; val c=r.count{store.status(it.stableKey)=="correct"}; val pct=if(a==0)0 else c*100/a
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(9),dp(12),dp(9));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(22,29,38)else Color.rgb(248,250,247),16f)}
            val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            head.addView(TextView(this).apply{text=src.fileName;textSize=13.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity));maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,-2,1f))
            head.addView(TextView(this).apply{text="$a/${r.size}  •  $pct%";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@MainActivity));gravity=Gravity.END})
            row.addView(head)
            val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pct;progressTintList=android.content.res.ColorStateList.valueOf(if(pct>=80)Color.rgb(35,145,103)else if(pct>=60)Color.rgb(34,125,143)else Color.rgb(210,115,70));backgroundTintList=android.content.res.ColorStateList.valueOf(Color.argb(40,80,100,120))}
            row.addView(bar,LinearLayout.LayoutParams(-1,dp(6)).apply{setMargins(0,dp(8),0,0)})
            row.setOnClickListener{startActivity(Intent(this,TestListActivity::class.java).putExtra("sourceId",src.id).putExtra("sourceName",src.fileName))}
            box.addView(row,LinearLayout.LayoutParams(-1,dp(70)).apply{setMargins(0,dp(3),0,dp(3))})
        }
        box.addView(TextView(this).apply{text="INSIGHT  •  ${when{attempted==0->"Solve a few questions to unlock performance insights.";wrong>solved->"Your fastest score gain is likely in the wrong-question queue.";due>attempted/2->"Revision load is high — clear today's due set before adding new volume.";accuracy>=85->"Accuracy is excellent. Protect it with timed mixed practice.";else->"Build accuracy first, then use revision to convert weak areas into solved ones."}}";textSize=12.5f;setTextColor(ThemeManager.text(this@MainActivity));setPadding(dp(12),dp(12),dp(12),dp(12));background=roundedDrawable(this@MainActivity,if(dark)Color.rgb(53,45,31)else Color.rgb(255,247,225),16f)})
        box.addView(TextView(this).apply{text="Open Study Menu  →";textSize=14f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@MainActivity));setPadding(0,dp(16),0,dp(4));setOnClickListener{dialog.dismiss();startActivity(Intent(this@MainActivity,StudyToolsActivity::class.java))}})
        scroll.addView(box);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));dialog.setContentView(root);dialog.show();dialog.window?.setLayout(-1,(resources.displayMetrics.heightPixels*0.92f).toInt());dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private class PerformanceRing(context:Context,private val accuracy:Int,private val mastery:Int,private val dark:Boolean):View(context){
        private val density=context.resources.displayMetrics.density
        private val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{style=android.graphics.Paint.Style.STROKE;strokeWidth=14f*density;strokeCap=android.graphics.Paint.Cap.ROUND}
        private val t=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{textAlign=android.graphics.Paint.Align.CENTER;typeface=Typeface.DEFAULT_BOLD}
        override fun onDraw(c:android.graphics.Canvas){super.onDraw(c);val cx=width/2f;val cy=height/2f;val r=minOf(width,height)*.34f;p.color=if(dark)Color.rgb(55,70,84)else Color.rgb(207,224,231);c.drawCircle(cx,cy,r,p);p.color=if(accuracy>=80)Color.rgb(39,150,113)else Color.rgb(35,126,151);c.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,accuracy*3.6f,false,p);t.color=if(dark)Color.WHITE else Color.rgb(19,55,70);t.textSize=25f*density;c.drawText("$accuracy%",cx,cy+8f*density,t);t.textSize=9.5f*density;t.color=if(dark)Color.LTGRAY else Color.rgb(82,105,116);c.drawText("ACCURACY",cx,cy+25f*density,t)}
    }

    private fun addSourceCard(list: LinearLayout, source: Source, index: Int) {
        val density = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(10), dp(11))
        }
        val cardBg = GradientDrawable().apply {
            setColor(if(ThemeManager.get(this@MainActivity)==ThemeManager.DARK) Color.rgb(24,32,42) else when (index % 5) {
                0 -> Color.rgb(235, 245, 255)
                1 -> Color.rgb(238, 249, 242)
                2 -> Color.rgb(255, 245, 228)
                3 -> Color.rgb(246, 239, 255)
                else -> Color.rgb(255, 237, 241)
            })
            cornerRadius = 16f * density
        }
        card.background = cardBg

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = source.fileName
            textSize = 15f
            setTextColor(ThemeManager.text(this@MainActivity))
            setTypeface(null, 1)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val pr = db.progressSummaryForSource(source.id, store)
        val count = TextView(this).apply {
            text = "${pr.solved}/${pr.total}"
            textSize = 12f
            setTypeface(null, 1)
            setTextColor(ThemeManager.muted(this@MainActivity))
            gravity = Gravity.CENTER_VERTICAL
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = pr.total.coerceAtLeast(1)
            this.progress = pr.solved.coerceIn(0, max)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(34, 125, 143))
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(45, 80, 100, 120))
        }
        val progressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        progressRow.addView(progress, LinearLayout.LayoutParams(0, dp(7), 1f).apply { setMargins(0, dp(6), dp(8), 0) })
        progressRow.addView(count, LinearLayout.LayoutParams(dp(48), dp(24)).apply { setMargins(0, dp(1), 0, 0) })
        body.addView(title)
        body.addView(progressRow)
        card.addView(body, LinearLayout.LayoutParams(0, -2, 1f))

        val resumeData = (store.sourceResumeByName(source.fileName) ?: store.sourceResume(source.id))?.split("|", limit = 2)
        val rt = resumeData?.getOrNull(0)?.let { db.testById(it) }
        if (rt != null) {
            val rb = TextView(this).apply {
                text = "RESUME"
                textSize = 10f
                setTypeface(null, 1)
                setTextColor(ThemeManager.accent(this@MainActivity))
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    setColor(if(ThemeManager.get(this@MainActivity)==ThemeManager.DARK) Color.rgb(24,52,72) else Color.rgb(225,243,246))
                    cornerRadius = 11f * density
                }
                setPadding(dp(8), 0, dp(8), 0)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, QuizActivity::class.java)
                        .putExtra("testId", rt.id)
                        .putExtra("title", rt.title)
                        .putExtra("position", resumeData.getOrNull(1)?.toIntOrNull() ?: 0))
                }
            }
            card.addView(rb, LinearLayout.LayoutParams(dp(76), dp(38)).apply {
                gravity = Gravity.CENTER_VERTICAL
                setMargins(dp(8), 0, 0, 0)
            })
        }

        card.setOnClickListener {
            startActivity(Intent(this, TestListActivity::class.java)
                .putExtra("sourceId", source.id)
                .putExtra("sourceName", source.fileName))
        }
        card.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle("Delete QBank?")
                .setMessage("Remove ${source.fileName} and all its imported questions from LocalQBank?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ ->
                    db.deleteSource(source.id)
                    Toast.makeText(this, "QBank deleted", Toast.LENGTH_SHORT).show()
                    render()
                }.show()
            true
        }
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, dp(5), 0, dp(5))
        })
    }

    private fun setCollectionButton(id:Int,label:String,count:Int,bg:Int,fg:Int){
        val b=findViewById<Button>(id)
        val text=SpannableString("$label\n$count")
        text.setSpan(RelativeSizeSpan(1.0f),0,label.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        text.setSpan(RelativeSizeSpan(1.55f),label.length+1,text.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        b.text=text
        b.setTextColor(fg)
        // Android Button styles can apply a theme tint over a custom drawable. Clear it
        // so each bookmark collection keeps its own semantic color.
        b.backgroundTintList = null
        b.stateListAnimator = null
        b.elevation = 0f
        b.background=GradientDrawable().apply{setColor(bg);cornerRadius=18f*resources.displayMetrics.density;setStroke((1*resources.displayMetrics.density).toInt(),Color.argb(55,100,120,140))}
    }
    private fun applyDashboardTheme(){
        val root=findViewById<View>(R.id.dashboardRoot)
        fun walk(v:View){
            if(v.id==R.id.mainHeader) return
            if(v is TextView && v !is Button) v.setTextColor(ThemeManager.text(this@MainActivity))
            if(v is ViewGroup) for(i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(root)
    }
    private fun styleDashboardCards(){
        val dark=ThemeManager.get(this@MainActivity)==ThemeManager.DARK
        val ids=listOf(R.id.importantButton,R.id.reviseButton,R.id.doubtButton,R.id.favoriteButton)
        ids.forEach{findViewById<View>(it)?.let{v->v.background=v.background}}
        findViewById<View>(R.id.qbankSection)?.background=GradientDrawable().apply{setColor(if(dark)Color.rgb(17,23,30) else Color.rgb(248,250,247));cornerRadius=18f*resources.displayMetrics.density;setStroke(dp(1),if(dark)Color.rgb(48,61,75) else Color.rgb(224,232,226))}
        findViewById<View>(R.id.analyticsCard)?.background=GradientDrawable().apply{setColor(if(dark)Color.rgb(17,23,30) else Color.rgb(249,251,247));cornerRadius=18f*resources.displayMetrics.density;setStroke(dp(1),if(dark)Color.rgb(48,61,75) else Color.rgb(224,232,226))}
        findViewById<View>(R.id.todaySolvedCard)?.background=GradientDrawable().apply{setColor(if(dark)Color.rgb(22,55,52) else Color.rgb(225,246,239));cornerRadius=22f*resources.displayMetrics.density;setStroke(dp(1),if(dark)Color.rgb(52,89,83) else Color.rgb(194,226,216))}
        findViewById<View>(R.id.studyMenuCard)?.background=GradientDrawable().apply{setColor(if(dark)Color.rgb(48,37,68) else Color.rgb(243,236,255));cornerRadius=22f*resources.displayMetrics.density;setStroke(dp(1),if(dark)Color.rgb(79,65,101) else Color.rgb(220,205,246))}
    }
    private fun showThemeMenu(anchor: View) {
        AlertDialog.Builder(this).setTitle("Q settings")
            .setItems(arrayOf("Light", "Dark", "Sepia", "Backup & Restore")) { _, which ->
                if(which==3) startActivity(Intent(this,BackupActivity::class.java))
                else { ThemeManager.set(this, when(which){1->ThemeManager.DARK;2->ThemeManager.SEPIA;else->ThemeManager.LIGHT}); recreate() }
            }.show()
    }
    private fun setupCollection(id:Int,type:String,value:String){findViewById<View>(id).setOnClickListener{startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType",type).putExtra("filterValue",value))}}
    private fun openImporter(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/html","text/plain","application/xhtml+xml"));putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,42)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data);if(requestCode!=42||resultCode!=RESULT_OK||data==null)return
        val uris=ArrayList<android.net.Uri>();data.clipData?.let{c->for(i in 0 until c.itemCount)uris.add(c.getItemAt(i).uri)};if(uris.isEmpty())data.data?.let{uris.add(it)}
        if(uris.isNotEmpty())startActivity(Intent(this,HtmlImportActivity::class.java).putParcelableArrayListExtra("uris",uris))
    }
    override fun onDestroy(){AppState.unregister(stateListener);db.close();super.onDestroy()}
}

class SourceAdapter(
    private val items:List<Source>,
    private val store:ProgressStore,
    private val db:QBankDb,
    private val click:(Source)->Unit,
    private val delete:(Long)->Unit
):RecyclerView.Adapter<SourceAdapter.VH>(){
    private val cache=HashMap<Long,ProgressSummary>()
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val title=TextView(v.context); val sub=TextView(v.context); val resume=TextView(v.context)
        init{
            v.orientation=LinearLayout.HORIZONTAL;v.setPadding(16,11,12,11)
            val body=LinearLayout(v.context).apply{orientation=LinearLayout.VERTICAL}
            title.textSize=16f; title.setTextColor(Color.rgb(23,32,51)); title.setTypeface(null,1); title.maxLines=2; title.ellipsize=android.text.TextUtils.TruncateAt.END
            sub.textSize=12f; sub.setTextColor(Color.rgb(82,98,117)); sub.setPadding(0,5,0,0); body.addView(title); body.addView(sub)
            v.addView(body,LinearLayout.LayoutParams(0,-2,1f))
            resume.text="RESUME";resume.textSize=11f;resume.setTypeface(null,1);resume.setTextColor(Color.rgb(25,91,111));resume.gravity=Gravity.CENTER;resume.background=GradientDrawable().apply{setColor(Color.rgb(225,243,246));cornerRadius=12f*v.resources.displayMetrics.density};resume.setPadding(10,0,10,0);v.addView(resume,LinearLayout.LayoutParams(82,42).apply{gravity=Gravity.CENTER_VERTICAL;setMargins(8,0,0,0)})
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{
        val v=LinearLayout(p.context);
        v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)}
        return VH(v)
    }
    override fun onBindViewHolder(h:VH,i:Int){
        val x=items[i]; val pr=cache.getOrPut(x.id){db.progressSummaryForSource(x.id,store)}
        h.title.text=x.fileName
        h.sub.text=when {
            pr.total==0 -> "No questions"
            pr.solved==0 -> "Not started  •  ${pr.total} questions"
            pr.solved>=pr.total -> "✓ Completed  •  ${pr.solved}/${pr.total} solved"
            else -> "↻ In progress  •  ${pr.solved}/${pr.total} solved"
        }
        val resumeTarget=store.sourceResume(x.id)?.split("|",limit=2)
        val rt=resumeTarget?.getOrNull(0)?.let{db.testById(it)}
        h.resume.visibility=if(rt!=null)View.VISIBLE else View.GONE
        h.resume.setOnClickListener{ if(rt!=null) clickSourceResume(h.itemView.context,rt,store.sourceResume(x.id)?.split("|")?.getOrNull(1)?.toIntOrNull()?:0) }
        val bg=when(i%5){0->Color.rgb(235,245,255);1->Color.rgb(238,249,242);2->Color.rgb(255,245,228);3->Color.rgb(246,239,255);else->Color.rgb(255,237,241)}
        h.itemView.background=roundedDrawable(h.itemView.context,bg,18f)
        h.itemView.setOnClickListener{click(x)}
        h.itemView.setOnLongClickListener{
            AlertDialog.Builder(h.itemView.context).setTitle("Delete QBank?").setMessage("Remove ${x.fileName} and all its imported questions from LocalQBank?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->delete(x.id)}.show(); true
        }
    }
    private fun clickSourceResume(c:android.content.Context,t:Test,pos:Int){c.startActivity(Intent(c,QuizActivity::class.java).putExtra("testId",t.id).putExtra("title",t.title).putExtra("position",pos))}
    fun refresh(){cache.clear();notifyDataSetChanged()}
    override fun getItemCount()=items.size
}
