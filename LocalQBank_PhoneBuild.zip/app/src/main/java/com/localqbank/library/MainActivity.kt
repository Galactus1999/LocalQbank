package com.localqbank.library

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity: AppCompatActivity(){
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);setContentView(R.layout.activity_main);SystemUi.padTopInset(findViewById(R.id.mainHeader),16,16,18,18);db=QBankDb(this);store=ProgressStore(this);render()}
    override fun onResume(){super.onResume();SystemUi.immersive(this); if(::db.isInitialized) render()}
    override fun onWindowFocusChanged(hasFocus:Boolean){super.onWindowFocusChanged(hasFocus);if(hasFocus)SystemUi.immersive(this)}
    private fun render(){
        val refs=db.allQuestionRefs()
        val solved=refs.count{store.status(it.stableKey)=="correct"}; val wrong=refs.count{store.status(it.stableKey)=="wrong"}; val unsolved=refs.size-solved-wrong
        val bookmarked=refs.count{!store.bookmark(it.stableKey).isNullOrBlank()}
        findViewById<TextView>(R.id.qbankCount).text=db.sources().size.toString()
        findViewById<TextView>(R.id.totalQuestions).text=refs.size.toString()
        findViewById<TextView>(R.id.solvedCount).text=solved.toString()
        findViewById<TextView>(R.id.wrongCount).text=wrong.toString()
        findViewById<TextView>(R.id.unsolvedCount).text=unsolved.toString()
        findViewById<TextView>(R.id.bookmarkedCount).text=bookmarked.toString()
        findViewById<TextView>(R.id.stats).text="${db.sources().size} QBanks • ${refs.size} questions"
        setCollectionButton(R.id.importantButton,"★ Important",refs.count{store.bookmark(it.stableKey)=="important"},Color.rgb(253,226,228))
        setCollectionButton(R.id.reviseButton,"↻ Revise",refs.count{store.bookmark(it.stableKey)=="revise"},Color.rgb(220,238,255))
        setCollectionButton(R.id.doubtButton,"❔ Doubt",refs.count{store.bookmark(it.stableKey)=="doubt"},Color.rgb(234,242,245))
        setCollectionButton(R.id.favoriteButton,"♥ Favourite",refs.count{store.bookmark(it.stableKey)=="favorite"},Color.rgb(255,243,191))
        styleDashboardCards()
        findViewById<Button>(R.id.addButton).setOnClickListener{openImporter()}
        setupCollection(R.id.importantButton,"bookmark","important")
        setupCollection(R.id.reviseButton,"bookmark","revise")
        setupCollection(R.id.doubtButton,"bookmark","doubt")
        setupCollection(R.id.favoriteButton,"bookmark","favorite")
        setupCollection(R.id.solvedCard,"status","correct")
        setupCollection(R.id.wrongCard,"status","wrong")
        setupCollection(R.id.unsolvedCard,"status","unsolved")
        setupCollection(R.id.bookmarkedCard,"bookmark","all")
        val list=findViewById<RecyclerView>(R.id.libraryList)
        list.layoutManager=LinearLayoutManager(this)
        list.adapter=SourceAdapter(db.sources(), store, db, {s->startActivity(Intent(this,TestListActivity::class.java).putExtra("sourceId",s.id).putExtra("sourceName",s.fileName))},{id->{db.deleteSource(id);Toast.makeText(this,"QBank deleted",Toast.LENGTH_SHORT).show();render()}})
    }
    private fun setCollectionButton(id:Int,label:String,count:Int,bg:Int){
        val b=findViewById<Button>(id)
        val text=SpannableString("$label\n$count")
        text.setSpan(RelativeSizeSpan(1.0f),0,label.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        text.setSpan(RelativeSizeSpan(1.55f),label.length+1,text.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        b.text=text
        b.setTextColor(Color.rgb(37,54,74))
        b.background=GradientDrawable().apply{setColor(bg);cornerRadius=18f*resources.displayMetrics.density;setStroke((1*resources.displayMetrics.density).toInt(),Color.argb(55,100,120,140))}
    }
    private fun styleDashboardCards(){
        val colors=mapOf(
            R.id.solvedCard to Color.rgb(232,247,239),
            R.id.wrongCard to Color.rgb(253,235,236),
            R.id.unsolvedCard to Color.rgb(255,244,220),
            R.id.bookmarkedCard to Color.rgb(225,243,245)
        )
        colors.forEach{(id,c)->findViewById<View>(id).background=GradientDrawable().apply{setColor(c);cornerRadius=16f*resources.displayMetrics.density}}
        listOf(R.id.qbankCount,R.id.totalQuestions).forEach{ id ->
            val parent=findViewById<TextView>(id).parent as View
            parent.background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=14f*resources.displayMetrics.density;setStroke((1*resources.displayMetrics.density).toInt(),Color.rgb(230,235,241))}
        }
    }
    private fun setupCollection(id:Int,type:String,value:String){findViewById<View>(id).setOnClickListener{startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType",type).putExtra("filterValue",value))}}
    private fun openImporter(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/html","text/plain","application/xhtml+xml","application/octet-stream"));putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,42)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data);if(requestCode!=42||resultCode!=RESULT_OK||data==null)return
        val uris=ArrayList<android.net.Uri>();data.clipData?.let{c->for(i in 0 until c.itemCount)uris.add(c.getItemAt(i).uri)};if(uris.isEmpty())data.data?.let{uris.add(it)}
        if(uris.isNotEmpty())startActivity(Intent(this,HtmlImportActivity::class.java).putParcelableArrayListExtra("uris",uris))
    }
    override fun onDestroy(){db.close();super.onDestroy()}
}

class SourceAdapter(
    private val items:List<Source>,
    private val store:ProgressStore,
    private val db:QBankDb,
    private val click:(Source)->Unit,
    private val delete:(Long)->Unit
):RecyclerView.Adapter<SourceAdapter.VH>(){
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val title=TextView(v.context); val sub=TextView(v.context)
        init{
            v.orientation=LinearLayout.VERTICAL; v.setPadding(16,12,16,12)
            title.textSize=16f; title.setTextColor(Color.rgb(23,32,51)); title.setTypeface(null,1)
            sub.textSize=12f; sub.setTextColor(Color.rgb(82,98,117)); sub.setPadding(0,5,0,0)
            v.addView(title); v.addView(sub)
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{
        val v=LinearLayout(p.context);
        v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)}
        return VH(v)
    }
    override fun onBindViewHolder(h:VH,i:Int){
        val x=items[i]; val pr=db.progressSummaryForSource(x.id,store)
        h.title.text=x.fileName
        h.sub.text=when {
            pr.total==0 -> "No questions"
            pr.solved==0 -> "Not started  •  ${pr.total} questions"
            pr.solved>=pr.total -> "✓ Completed  •  ${pr.solved}/${pr.total} solved"
            else -> "↻ In progress  •  ${pr.solved}/${pr.total} solved  •  Resume"
        }
        val bg=when(i%5){0->Color.rgb(235,245,255);1->Color.rgb(238,249,242);2->Color.rgb(255,245,228);3->Color.rgb(246,239,255);else->Color.rgb(255,237,241)}
        h.itemView.background=rounded(bg,18f,h.itemView.context)
        h.itemView.setOnClickListener{click(x)}
        h.itemView.setOnLongClickListener{
            AlertDialog.Builder(h.itemView.context).setTitle("Delete QBank?").setMessage("Remove ${x.fileName} and all its imported questions from LocalQBank?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->delete(x.id)}.show(); true
        }
    }
    override fun getItemCount()=items.size
    private fun rounded(color:Int,radius:Float,c:android.content.Context)=android.graphics.drawable.GradientDrawable().apply{setColor(color);cornerRadius=radius*c.resources.displayMetrics.density}
}
