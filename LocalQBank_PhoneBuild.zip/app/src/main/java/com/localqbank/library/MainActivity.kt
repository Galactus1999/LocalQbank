package com.localqbank.library

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class QBank(val id:String,val name:String,val uri:String,val sizeBytes:Long,val addedAt:Long)

class MainActivity: AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("library", MODE_PRIVATE) }
    private val banks = mutableListOf<QBank>()
    private lateinit var adapter: QBankAdapter
    private lateinit var stats: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_:Exception){}
        val id = sha256(uri.toString()).take(24)
        val name = getName(uri) ?: "QBank"
        banks.removeAll { it.id == id }
        banks.add(QBank(id,name,uri.toString(),getSize(uri),System.currentTimeMillis()))
        save(); adapter.notifyDataSetChanged(); updateStats()
    }

    override fun onCreate(b:Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        stats=findViewById(R.id.stats)
        adapter=QBankAdapter(banks,{open(it)},{remove(it)},{rename(it)})
        findViewById<RecyclerView>(R.id.libraryList).apply {
            layoutManager=LinearLayoutManager(this@MainActivity); adapter=this@MainActivity.adapter
        }
        findViewById<Button>(R.id.addButton).setOnClickListener {
            picker.launch(arrayOf("text/html","application/xhtml+xml"))
        }
        load(); updateStats()
    }

    private fun open(x:QBank)=startActivity(Intent(this,ViewerActivity::class.java).apply {
        putExtra("id",x.id); putExtra("name",x.name); putExtra("uri",x.uri)
    })

    private fun remove(x:QBank) {
        AlertDialog.Builder(this).setTitle("Remove QBank?")
            .setMessage("The HTML file will NOT be deleted.")
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Remove"){_,_-> banks.removeAll{it.id==x.id}; save(); adapter.notifyDataSetChanged(); updateStats()}
            .show()
    }

    private fun rename(x:QBank) {
        val e=EditText(this); e.setText(x.name)
        AlertDialog.Builder(this).setTitle("Rename QBank").setView(e)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save"){_,_-> val i=banks.indexOfFirst{it.id==x.id}; if(i>=0){banks[i]=x.copy(name=e.text.toString().ifBlank{x.name});save();adapter.notifyDataSetChanged()}}
            .show()
    }

    private fun save(){
        val a=JSONArray(); banks.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("uri",x.uri);put("size",x.sizeBytes);put("addedAt",x.addedAt)})}
        prefs.edit().putString("banks",a.toString()).apply()
    }
    private fun load(){
        banks.clear(); val a=JSONArray(prefs.getString("banks","[]"))
        for(i in 0 until a.length()){val o=a.getJSONObject(i);banks.add(QBank(o.getString("id"),o.getString("name"),o.getString("uri"),o.optLong("size"),o.optLong("addedAt")))}
        adapter.notifyDataSetChanged()
    }
    private fun updateStats(){stats.text="${banks.size} QBank(s) • HTML files stay in phone storage • progress stored locally"}
    private fun getName(u:Uri)=contentResolver.query(u,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())it.getString(0)else null}
    private fun getSize(u:Uri)=contentResolver.query(u,arrayOf(OpenableColumns.SIZE),null,null,null)?.use{if(it.moveToFirst()&&!it.isNull(0))it.getLong(0)else 0L}?:0L
    private fun sha256(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
}

class QBankAdapter(
    private val items:List<QBank>, private val open:(QBank)->Unit,
    private val remove:(QBank)->Unit, private val rename:(QBank)->Unit
):RecyclerView.Adapter<QBankAdapter.VH>(){
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val n=TextView(v.context).apply{textSize=18f;setTypeface(null,1)}
        val s=TextView(v.context).apply{textSize=13f}
        init{v.orientation=LinearLayout.VERTICAL;v.setPadding(28,24,28,24);v.addView(n);v.addView(s)}
    }
    override fun onCreateViewHolder(p:android.view.ViewGroup,t:Int)=VH(LinearLayout(p.context))
    override fun onBindViewHolder(h:VH,i:Int){val x=items[i];h.n.text=x.name;h.s.text="${"%.1f".format(x.sizeBytes/1048576.0)} MB • Tap to open • Long press for options";h.itemView.setOnClickListener{open(x)};h.itemView.setOnLongClickListener{AlertDialog.Builder(h.itemView.context).setItems(arrayOf("Rename","Remove from library")){_,w->if(w==0)rename(x)else remove(x)}.show();true}}
    override fun getItemCount()=items.size
}
