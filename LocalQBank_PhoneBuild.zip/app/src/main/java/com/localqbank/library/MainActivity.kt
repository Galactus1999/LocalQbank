package com.localqbank.library

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.roundToInt
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity: AppCompatActivity(){
    private fun dp(value:Int):Int = (value * resources.displayMetrics.density).roundToInt()
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);setContentView(R.layout.activity_main);SystemUi.padTopInset(findViewById(R.id.mainHeader),16,16,18,18);db=QBankDb(this);store=ProgressStore(this);findViewById<Button>(R.id.themeButton)?.setOnClickListener{showThemeMenu(it)};render()}
    override fun onResume(){super.onResume();SystemUi.immersive(this); if(::db.isInitialized) render()}
    override fun onWindowFocusChanged(hasFocus:Boolean){super.onWindowFocusChanged(hasFocus);if(hasFocus && ::db.isInitialized) render()}
    override fun onWindowFocusChanged(hasFocus:Boolean){super.onWindowFocusChanged(hasFocus);if(hasFocus)SystemUi.immersive(this)}
    private fun render(){
        findViewById<View>(R.id.dashboardRoot)?.setBackgroundColor(ThemeManager.bg(this))
        val keys=db.allStableKeys()
        val solved=keys.count{store.status(it)=="correct"}; val wrong=keys.count{store.status(it)=="wrong"}; val unsolved=keys.size-solved-wrong
        val bookmarked=keys.count{!store.bookmark(it).isNullOrBlank()}
        findViewById<TextView>(R.id.solvedCount).text=solved.toString()
        findViewById<TextView>(R.id.wrongCount).text=wrong.toString()
        findViewById<TextView>(R.id.unsolvedCount).text=unsolved.toString()
        findViewById<TextView>(R.id.bookmarkedCount).text=bookmarked.toString()
        val total = keys.size.coerceAtLeast(1)
        listOf(
            R.id.solvedProgress to solved,
            R.id.wrongProgress to wrong,
            R.id.unsolvedProgress to unsolved,
            R.id.bookmarkedProgress to bookmarked
        ).forEach { (id, value) ->
            findViewById<ProgressBar>(id).apply { max = total; progress = value.coerceIn(0, total) }
        }
        findViewById<TextView>(R.id.stats).text="${db.sources().size} QBanks • ${keys.size} questions"
        setCollectionButton(R.id.importantButton,"★ Important",keys.count{store.bookmark(it)=="important"},Color.rgb(253,226,228))
        setCollectionButton(R.id.reviseButton,"↻ Revise",keys.count{store.bookmark(it)=="revise"},Color.rgb(220,238,255))
        setCollectionButton(R.id.doubtButton,"❔ Doubt",keys.count{store.bookmark(it)=="doubt"},Color.rgb(234,242,245))
        setCollectionButton(R.id.favoriteButton,"♥ Favourite",keys.count{store.bookmark(it)=="favorite"},Color.rgb(255,243,191))
        styleDashboardCards()
        findViewById<Button>(R.id.addButton).setOnClickListener{openImporter()}
        setupCollection(R.id.importantButton,"bookmark","important")
        setupCollection(R.id.reviseButton,"bookmark","revise")
        setupCollection(R.id.doubtButton,"bookmark","doubt")
        setupCollection(R.id.favoriteButton,"bookmark","favorite")
        setupCollection(R.id.solvedCard,"status","correct")
        setupCollection(R.id.wrongCard,"status","wrong")
        setupCollection(R.id.unsolvedCard,"status","unsolved")
        setupCollection(R.id.bookmarkedCard,"bookmark","all")
        val list=findViewById<LinearLayout>(R.id.libraryList)
        list.removeAllViews()
        db.sources().forEachIndexed { index, source -> addSourceCard(list, source, index) }
    }
    private fun addSourceCard(list: LinearLayout, source: Source, index: Int) {
        val density = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(10), dp(11))
        }
        val cardBg = GradientDrawable().apply {
            setColor(when (index % 5) {
                0 -> Color.rgb(235, 245, 255)
                1 -> Color.rgb(238, 249, 242)
                2 -> Color.rgb(255, 245, 228)
                3 -> Color.rgb(246, 239, 255)
                else -> Color.rgb(255, 237, 241)
            })
            cornerRadius = 16f * density
        }
        card.background = cardBg

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = source.fileName
            textSize = 15f
            setTextColor(Color.rgb(23, 32, 51))
            setTypeface(null, 1)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val pr = db.progressSummaryForSource(source.id, store)
        val count = TextView(this).apply {
            text = "${pr.solved}/${pr.total}"
            textSize = 12f
            setTypeface(null, 1)
            setTextColor(Color.rgb(45, 66, 86))
            gravity = Gravity.CENTER_VERTICAL
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = pr.total.coerceAtLeast(1)
            this.progress = pr.solved.coerceIn(0, max)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(34, 125, 143))
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(45, 80, 100, 120))
        }
        val progressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        progressRow.addView(progress, LinearLayout.LayoutParams(0, dp(7), 1f).apply { setMargins(0, dp(6), dp(8), 0) })
        progressRow.addView(count, LinearLayout.LayoutParams(dp(48), dp(24)).apply { setMargins(0, dp(1), 0, 0) })
        body.addView(title)
        body.addView(progressRow)
        card.addView(body, LinearLayout.LayoutParams(0, -2, 1f))

        val resumeData = store.sourceResume(source.id)?.split("|", limit = 2)
        val rt = resumeData?.getOrNull(0)?.let { db.testById(it) }
        if (rt != null) {
            val rb = TextView(this).apply {
                text = "RESUME"
                textSize = 10f
                setTypeface(null, 1)
                setTextColor(Color.rgb(25, 91, 111))
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    setColor(Color.rgb(225, 243, 246))
                    cornerRadius = 11f * density
                }
                setPadding(dp(8), 0, dp(8), 0)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, QuizActivity::class.java)
                        .putExtra("testId", rt.id)
                        .putExtra("title", rt.title)
                        .putExtra("position", resumeData.getOrNull(1)?.toIntOrNull() ?: 0))
                }
            }
            card.addView(rb, LinearLayout.LayoutParams(dp(76), dp(38)).apply {
                gravity = Gravity.CENTER_VERTICAL
                setMargins(dp(8), 0, 0, 0)
            })
        }

        card.setOnClickListener {
            startActivity(Intent(this, TestListActivity::class.java)
                .putExtra("sourceId", source.id)
                .putExtra("sourceName", source.fileName))
        }
        card.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle("Delete QBank?")
                .setMessage("Remove ${source.fileName} and all its imported questions from LocalQBank?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ ->
                    db.deleteSource(source.id)
                    Toast.makeText(this, "QBank deleted", Toast.LENGTH_SHORT).show()
                    render()
                }.show()
            true
        }
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, dp(5), 0, dp(5))
        })
    }

    private fun setCollectionButton(id:Int,label:String,count:Int,bg:Int){
        val b=findViewById<Button>(id)
        val text=SpannableString("$label\n$count")
        text.setSpan(RelativeSizeSpan(1.0f),0,label.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        text.setSpan(RelativeSizeSpan(1.55f),label.length+1,text.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        b.text=text
        b.setTextColor(Color.rgb(37,54,74))
        b.background=GradientDrawable().apply{setColor(bg);cornerRadius=18f*resources.displayMetrics.density;setStroke((1*resources.displayMetrics.density).toInt(),Color.argb(55,100,120,140))}
    }
    private fun styleDashboardCards(){
        val colors=mapOf(
            R.id.solvedCard to Color.rgb(232,247,239),
            R.id.wrongCard to Color.rgb(253,235,236),
            R.id.unsolvedCard to Color.rgb(255,244,220),
            R.id.bookmarkedCard to Color.rgb(225,243,245)
        )
        colors.forEach{(id,c)->findViewById<View>(id).background=GradientDrawable().apply{setColor(c);cornerRadius=16f*resources.displayMetrics.density}}
        findViewById<View>(R.id.statsScroll).background=GradientDrawable().apply{
            setColor(Color.rgb(249,251,247))
            cornerRadius=18f*resources.displayMetrics.density
            setStroke(dp(1),Color.rgb(224,232,226))
        }
        findViewById<View>(R.id.qbankSection).background=GradientDrawable().apply{
            setColor(Color.rgb(248,250,247))
            cornerRadius=18f*resources.displayMetrics.density
            setStroke(dp(1),Color.rgb(224,232,226))
        }
    }
    private fun showThemeMenu(anchor: View) {
        AlertDialog.Builder(this).setTitle("Appearance")
            .setItems(arrayOf("Light", "Dark", "Sepia")) { _, which ->
                ThemeManager.set(this, when(which){1->ThemeManager.DARK;2->ThemeManager.SEPIA;else->ThemeManager.LIGHT}); recreate()
            }.show()
    }
    private fun setupCollection(id:Int,type:String,value:String){findViewById<View>(id).setOnClickListener{startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType",type).putExtra("filterValue",value))}}
    private fun openImporter(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/html","text/plain","application/xhtml+xml","application/octet-stream"));putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,42)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data);if(requestCode!=42||resultCode!=RESULT_OK||data==null)return
        val uris=ArrayList<android.net.Uri>();data.clipData?.let{c->for(i in 0 until c.itemCount)uris.add(c.getItemAt(i).uri)};if(uris.isEmpty())data.data?.let{uris.add(it)}
        if(uris.isNotEmpty())startActivity(Intent(this,HtmlImportActivity::class.java).putParcelableArrayListExtra("uris",uris))
    }
    override fun onDestroy(){db.close();super.onDestroy()}
}

class SourceAdapter(
    private val items:List<Source>,
    private val store:ProgressStore,
    private val db:QBankDb,
    private val click:(Source)->Unit,
    private val delete:(Long)->Unit
):RecyclerView.Adapter<SourceAdapter.VH>(){
    private val cache=HashMap<Long,ProgressSummary>()
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val title=TextView(v.context); val sub=TextView(v.context); val resume=TextView(v.context)
        init{
            v.orientation=LinearLayout.HORIZONTAL;v.setPadding(16,11,12,11)
            val body=LinearLayout(v.context).apply{orientation=LinearLayout.VERTICAL}
            title.textSize=16f; title.setTextColor(Color.rgb(23,32,51)); title.setTypeface(null,1); title.maxLines=2; title.ellipsize=android.text.TextUtils.TruncateAt.END
            sub.textSize=12f; sub.setTextColor(Color.rgb(82,98,117)); sub.setPadding(0,5,0,0); body.addView(title); body.addView(sub)
            v.addView(body,LinearLayout.LayoutParams(0,-2,1f))
            resume.text="RESUME";resume.textSize=11f;resume.setTypeface(null,1);resume.setTextColor(Color.rgb(25,91,111));resume.gravity=Gravity.CENTER;resume.background=GradientDrawable().apply{setColor(Color.rgb(225,243,246));cornerRadius=12f*v.resources.displayMetrics.density};resume.setPadding(10,0,10,0);v.addView(resume,LinearLayout.LayoutParams(82,42).apply{gravity=Gravity.CENTER_VERTICAL;setMargins(8,0,0,0)})
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{
        val v=LinearLayout(p.context);
        v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)}
        return VH(v)
    }
    override fun onBindViewHolder(h:VH,i:Int){
        val x=items[i]; val pr=cache.getOrPut(x.id){db.progressSummaryForSource(x.id,store)}
        h.title.text=x.fileName
        h.sub.text=when {
            pr.total==0 -> "No questions"
            pr.solved==0 -> "Not started  •  ${pr.total} questions"
            pr.solved>=pr.total -> "✓ Completed  •  ${pr.solved}/${pr.total} solved"
            else -> "↻ In progress  •  ${pr.solved}/${pr.total} solved"
        }
        val resumeTarget=store.sourceResume(x.id)?.split("|",limit=2)
        val rt=resumeTarget?.getOrNull(0)?.let{db.testById(it)}
        h.resume.visibility=if(rt!=null)View.VISIBLE else View.GONE
        h.resume.setOnClickListener{ if(rt!=null) clickSourceResume(h.itemView.context,rt,store.sourceResume(x.id)?.split("|")?.getOrNull(1)?.toIntOrNull()?:0) }
        val bg=when(i%5){0->Color.rgb(235,245,255);1->Color.rgb(238,249,242);2->Color.rgb(255,245,228);3->Color.rgb(246,239,255);else->Color.rgb(255,237,241)}
        h.itemView.background=rounded(bg,18f,h.itemView.context)
        h.itemView.setOnClickListener{click(x)}
        h.itemView.setOnLongClickListener{
            AlertDialog.Builder(h.itemView.context).setTitle("Delete QBank?").setMessage("Remove ${x.fileName} and all its imported questions from LocalQBank?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->delete(x.id)}.show(); true
        }
    }
    private fun clickSourceResume(c:android.content.Context,t:Test,pos:Int){c.startActivity(Intent(c,QuizActivity::class.java).putExtra("testId",t.id).putExtra("title",t.title).putExtra("position",pos))}
    fun refresh(){cache.clear();notifyDataSetChanged()}
    override fun getItemCount()=items.size
    private fun rounded(color:Int,radius:Float,c:android.content.Context)=android.graphics.drawable.GradientDrawable().apply{setColor(color);cornerRadius=radius*c.resources.displayMetrics.density}
}
