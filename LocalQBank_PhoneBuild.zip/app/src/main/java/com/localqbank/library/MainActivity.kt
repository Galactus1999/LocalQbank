package com.localqbank.library

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity: AppCompatActivity(){
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);setContentView(R.layout.activity_main);db=QBankDb(this);store=ProgressStore(this);render()}
    override fun onResume(){super.onResume();SystemUi.immersive(this); if(::db.isInitialized) render()}
    override fun onWindowFocusChanged(hasFocus:Boolean){super.onWindowFocusChanged(hasFocus);if(hasFocus)SystemUi.immersive(this)}
    private fun render(){
        val refs=db.allQuestionRefs()
        val solved=refs.count{store.status(it.stableKey)=="correct"}; val wrong=refs.count{store.status(it.stableKey)=="wrong"}; val unsolved=refs.size-solved-wrong
        val bookmarked=refs.count{!store.bookmark(it.stableKey).isNullOrBlank()}
        findViewById<TextView>(R.id.qbankCount).text=db.sources().size.toString()
        findViewById<TextView>(R.id.totalQuestions).text=refs.size.toString()
        findViewById<TextView>(R.id.solvedCount).text=solved.toString()
        findViewById<TextView>(R.id.wrongCount).text=wrong.toString()
        findViewById<TextView>(R.id.unsolvedCount).text=unsolved.toString()
        findViewById<TextView>(R.id.bookmarkedCount).text=bookmarked.toString()
        findViewById<TextView>(R.id.stats).text="${db.sources().size} QBanks • ${refs.size} questions"
        findViewById<Button>(R.id.importantButton).text="★ Important\n${refs.count{store.bookmark(it.stableKey)=="important"}} questions"
        findViewById<Button>(R.id.reviseButton).text="↻ Revise\n${refs.count{store.bookmark(it.stableKey)=="revise"}} questions"
        findViewById<Button>(R.id.doubtButton).text="❔ Doubt\n${refs.count{store.bookmark(it.stableKey)=="doubt"}} questions"
        findViewById<Button>(R.id.favoriteButton).text="♥ Favourite\n${refs.count{store.bookmark(it.stableKey)=="favorite"}} questions"
        findViewById<Button>(R.id.addButton).setOnClickListener{openImporter()}
        setupCollection(R.id.importantButton,"bookmark","important")
        setupCollection(R.id.reviseButton,"bookmark","revise")
        setupCollection(R.id.doubtButton,"bookmark","doubt")
        setupCollection(R.id.favoriteButton,"bookmark","favorite")
        setupCollection(R.id.solvedCard,"status","correct")
        setupCollection(R.id.wrongCard,"status","wrong")
        setupCollection(R.id.unsolvedCard,"status","unsolved")
        setupCollection(R.id.bookmarkedCard,"bookmark","all")
        val list=findViewById<RecyclerView>(R.id.libraryList)
        list.layoutManager=LinearLayoutManager(this)
        list.adapter=SourceAdapter(db.sources(),{s->startActivity(Intent(this,TestListActivity::class.java).putExtra("sourceId",s.id).putExtra("sourceName",s.fileName))},{id->{db.deleteSource(id);Toast.makeText(this,"QBank deleted",Toast.LENGTH_SHORT).show();render()}})
    }
    private fun setupCollection(id:Int,type:String,value:String){findViewById<View>(id).setOnClickListener{startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType",type).putExtra("filterValue",value))}}
    private fun openImporter(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/html","text/plain","application/xhtml+xml","application/octet-stream"));putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,42)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data);if(requestCode!=42||resultCode!=RESULT_OK||data==null)return
        val uris=ArrayList<android.net.Uri>();data.clipData?.let{c->for(i in 0 until c.itemCount)uris.add(c.getItemAt(i).uri)};if(uris.isEmpty())data.data?.let{uris.add(it)}
        if(uris.isNotEmpty())startActivity(Intent(this,HtmlImportActivity::class.java).putParcelableArrayListExtra("uris",uris))
    }
    override fun onDestroy(){db.close();super.onDestroy()}
}

class SourceAdapter(private val items:List<Source>,private val click:(Source)->Unit,private val delete:(Long)->Unit):RecyclerView.Adapter<SourceAdapter.VH>(){
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val title=TextView(v.context); val sub=TextView(v.context)
        init{
            v.orientation=LinearLayout.VERTICAL; v.setPadding(16,15,16,15); v.setBackgroundColor(Color.WHITE)
            title.textSize=17f; title.setTextColor(Color.rgb(23,32,51)); title.setTypeface(null,1)
            sub.textSize=12f; sub.setTextColor(Color.rgb(102,112,133)); sub.setPadding(0,5,0,0)
            v.addView(title); v.addView(sub)
        }
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{val v=LinearLayout(p.context);v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)};return VH(v)}
    override fun onBindViewHolder(h:VH,i:Int){
        val x=items[i]; h.title.text=x.fileName; h.sub.text="${x.provider}  •  Tap to open  •  Long-press to delete"
        h.itemView.setOnClickListener{click(x)}
        h.itemView.setOnLongClickListener{
            AlertDialog.Builder(h.itemView.context).setTitle("Delete QBank?").setMessage("Remove ${x.fileName} and all its imported questions from LocalQBank?").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->delete(x.id)}.show(); true
        }
    }
    override fun getItemCount()=items.size
}

