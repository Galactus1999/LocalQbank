package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity: AppCompatActivity(){
    private lateinit var db:QBankDb
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main); db=QBankDb(this); render()}
    override fun onResume(){super.onResume(); if(::db.isInitialized) render()}
    private fun render(){
        val list=findViewById<RecyclerView>(R.id.libraryList); val sources=db.sources()
        findViewById<TextView>(R.id.qbankCount).text=sources.size.toString()
        findViewById<TextView>(R.id.storageInfo).text="On-device"
        findViewById<TextView>(R.id.stats).text="${sources.sumOf{db.tests(it.id).size}} sections/tests • Questions are stored in the APK database"
        list.layoutManager=LinearLayoutManager(this); list.adapter=SourceAdapter(sources){s->startActivity(Intent(this,TestListActivity::class.java).putExtra("sourceId",s.id).putExtra("sourceName",s.fileName))}
        findViewById<Button>(R.id.addButton).setOnClickListener{openImporter()}
    }
    private fun openImporter(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="text/html";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(i,42)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=42 || resultCode!=RESULT_OK || data==null) return
        val uris=ArrayList<android.net.Uri>()
        data.clipData?.let{clip->for(i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)}
        if(uris.isEmpty()) data.data?.let{uris.add(it)}
        if(uris.isNotEmpty()) startActivity(Intent(this,HtmlImportActivity::class.java).putParcelableArrayListExtra("uris",uris))
    }

    override fun onDestroy(){db.close();super.onDestroy()}
}
class SourceAdapter(private val items:List<Source>,private val click:(Source)->Unit):RecyclerView.Adapter<SourceAdapter.VH>(){
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){val title=TextView(v.context);val sub=TextView(v.context);init{v.orientation=LinearLayout.VERTICAL;v.setPadding(18,18,18,18);v.setBackgroundColor(Color.WHITE);title.textSize=17f;title.setTextColor(Color.rgb(23,32,51));title.setTypeface(null,1);sub.textSize=12f;sub.setTextColor(Color.rgb(102,112,133));sub.setPadding(0,6,0,0);v.addView(title);v.addView(sub)}}
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{val v=LinearLayout(p.context);v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,8,0,8)};return VH(v)}
    override fun onBindViewHolder(h:VH,i:Int){val x=items[i];h.title.text=x.fileName;h.sub.text="${x.provider}  •  Tap to open sections";h.itemView.setOnClickListener{click(x)}}
    override fun getItemCount()=items.size
}
