package com.localqbank.library

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class QBank(val id:String,val name:String,val uri:String,val sizeBytes:Long,val addedAt:Long)

class MainActivity: AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("library", MODE_PRIVATE) }
    private val banks = mutableListOf<QBank>()
    private lateinit var adapter: QBankAdapter
    private lateinit var stats: TextView
    private lateinit var qbankCount: TextView
    private lateinit var storageInfo: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_:Exception){}
        val id = sha256(uri.toString()).take(24)
        val name = getName(uri) ?: "QBank"
        banks.removeAll { it.id == id }
        banks.add(QBank(id,name,uri.toString(),getSize(uri),System.currentTimeMillis()))
        save(); adapter.notifyDataSetChanged(); updateStats()
    }

    override fun onCreate(b:Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        window.statusBarColor = Color.rgb(16,24,40)
        stats=findViewById(R.id.stats)
        qbankCount=findViewById(R.id.qbankCount)
        storageInfo=findViewById(R.id.storageInfo)
        adapter=QBankAdapter(banks,{open(it)},{remove(it)},{rename(it)})
        findViewById<RecyclerView>(R.id.libraryList).apply {
            layoutManager=LinearLayoutManager(this@MainActivity); adapter=this@MainActivity.adapter
        }
        findViewById<Button>(R.id.addButton).setOnClickListener {
            picker.launch(arrayOf("text/html","application/xhtml+xml"))
        }
        load(); updateStats()
    }

    private fun open(x:QBank)=startActivity(Intent(this,ViewerActivity::class.java).apply {
        putExtra("id",x.id); putExtra("name",x.name); putExtra("uri",x.uri)
    })

    private fun remove(x:QBank) {
        AlertDialog.Builder(this).setTitle("Remove QBank?")
            .setMessage("The HTML file will NOT be deleted.")
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Remove"){_,_-> banks.removeAll{it.id==x.id}; save(); adapter.notifyDataSetChanged(); updateStats()}
            .show()
    }

    private fun rename(x:QBank) {
        val e=EditText(this); e.setText(x.name)
        AlertDialog.Builder(this).setTitle("Rename QBank").setView(e)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save"){_,_-> val i=banks.indexOfFirst{it.id==x.id}; if(i>=0){banks[i]=x.copy(name=e.text.toString().ifBlank{x.name});save();adapter.notifyDataSetChanged()}}
            .show()
    }

    private fun save(){
        val a=JSONArray(); banks.forEach{x->a.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("uri",x.uri);put("size",x.sizeBytes);put("addedAt",x.addedAt)})}
        prefs.edit().putString("banks",a.toString()).apply()
    }
    private fun load(){
        banks.clear(); val a=JSONArray(prefs.getString("banks","[]"))
        for(i in 0 until a.length()){val o=a.getJSONObject(i);banks.add(QBank(o.getString("id"),o.getString("name"),o.getString("uri"),o.optLong("size"),o.optLong("addedAt")))}
        adapter.notifyDataSetChanged()
    }
    private fun updateStats(){
        val totalBytes=banks.sumOf { it.sizeBytes }
        val mb=totalBytes/1048576.0
        qbankCount.text=banks.size.toString()
        storageInfo.text=if(mb>0) String.format("%.1f MB",mb) else "Local"
        stats.text=if(banks.isEmpty()) "No QBanks added yet • Add your first HTML QBank above" else "${banks.size} QBank(s) • Files remain on your phone • Progress is saved locally"
    }
    private fun getName(u:Uri)=contentResolver.query(u,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())it.getString(0)else null}
    private fun getSize(u:Uri)=contentResolver.query(u,arrayOf(OpenableColumns.SIZE),null,null,null)?.use{if(it.moveToFirst()&&!it.isNull(0))it.getLong(0)else 0L}?:0L
    private fun sha256(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
}

class QBankAdapter(
    private val items:List<QBank>, private val open:(QBank)->Unit,
    private val remove:(QBank)->Unit, private val rename:(QBank)->Unit
):RecyclerView.Adapter<QBankAdapter.VH>(){
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val icon=TextView(v.context).apply{ text="Q"; textSize=17f; setTypeface(null,1); setTextColor(Color.WHITE); gravity=Gravity.CENTER }
        val n=TextView(v.context).apply{textSize=16f;setTypeface(null,1);setTextColor(Color.rgb(23,32,51))}
        val s=TextView(v.context).apply{textSize=12f;setTextColor(Color.rgb(102,112,133))}
        init{
            v.orientation=LinearLayout.HORIZONTAL;v.setPadding(14,14,12,14);v.gravity=Gravity.CENTER_VERTICAL
            val bg=GradientDrawable();bg.setColor(Color.WHITE);bg.cornerRadius=24f;bg.setStroke(1,Color.rgb(227,232,239));v.background=bg
            val ibg=GradientDrawable();ibg.setColor(Color.rgb(49,95,189));ibg.cornerRadius=18f;icon.background=ibg
            v.addView(icon,LinearLayout.LayoutParams(46,46))
            val textBox=LinearLayout(v.context).apply{orientation=LinearLayout.VERTICAL;setPadding(12,0,6,0)}
            textBox.addView(n);textBox.addView(s);v.addView(textBox,LinearLayout.LayoutParams(0,-2,1f))
            val more=TextView(v.context).apply{text="⋮";textSize=24f;setTextColor(Color.rgb(102,112,133));gravity=Gravity.CENTER}
            v.addView(more,LinearLayout.LayoutParams(36,48))
            more.setOnClickListener{showMenu(v.context,adapterPosition)}
        }
        private fun showMenu(c:android.content.Context,pos:Int){
            if(pos<0)return; val x=items[pos]
            AlertDialog.Builder(c).setItems(arrayOf("Open QBank","Rename","Remove from library")){_,w->when(w){0->open(x);1->rename(x);2->remove(x)}}.show()
        }
    }
    override fun onCreateViewHolder(p:android.view.ViewGroup,t:Int):VH{
        val v=LinearLayout(p.context);val lp=RecyclerView.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);v.layoutParams=lp;return VH(v)
    }
    override fun onBindViewHolder(h:VH,i:Int){
        val x=items[i];h.n.text=x.name
        val mb=x.sizeBytes/1048576.0
        h.s.text=if(mb>0) String.format("%.1f MB  •  HTML QBank  •  Tap to study",mb) else "HTML QBank  •  Tap to study"
        h.itemView.setOnClickListener{open(x)}
    }
    override fun getItemCount()=items.size
}
