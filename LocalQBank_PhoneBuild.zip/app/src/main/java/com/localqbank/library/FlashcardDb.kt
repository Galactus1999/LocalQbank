package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import kotlin.math.roundToInt

/** Dedicated flashcard store. QBank data never shares this database. */
class FlashcardDb(context: Context) {
    private val dbFile: File = context.getDatabasePath("flashcards.db")
    private val db: SQLiteDatabase

    init {
        dbFile.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        db.execSQL("PRAGMA foreign_keys=ON")
        runCatching { db.execSQL("PRAGMA journal_mode=WAL") }
        runCatching { db.execSQL("PRAGMA synchronous=NORMAL") }
        db.execSQL("CREATE TABLE IF NOT EXISTS deck(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, source_file TEXT, imported_at INTEGER NOT NULL, card_count INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS card(id INTEGER PRIMARY KEY AUTOINCREMENT, deck_id INTEGER NOT NULL, front TEXT NOT NULL, back TEXT NOT NULL, tags TEXT, position INTEGER NOT NULL, due INTEGER DEFAULT 0, interval INTEGER DEFAULT 0, ease REAL DEFAULT 2.5, reps INTEGER DEFAULT 0, lapses INTEGER DEFAULT 0, bookmarked INTEGER DEFAULT 0, last_reviewed INTEGER DEFAULT 0, FOREIGN KEY(deck_id) REFERENCES deck(id) ON DELETE CASCADE, UNIQUE(deck_id,position))")
        ensureColumn("card", "bookmarked", "INTEGER DEFAULT 0")
        ensureColumn("card", "last_reviewed", "INTEGER DEFAULT 0")
        ensureColumn("card", "due", "INTEGER DEFAULT 0")
        ensureColumn("card", "interval", "INTEGER DEFAULT 0")
        ensureColumn("card", "ease", "REAL DEFAULT 2.5")
        ensureColumn("card", "reps", "INTEGER DEFAULT 0")
        ensureColumn("card", "lapses", "INTEGER DEFAULT 0")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_flash_deck ON card(deck_id,position)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_flash_due ON card(due,deck_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_flash_bookmarked ON card(bookmarked,deck_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_flash_deck_name ON deck(name COLLATE NOCASE)")
    }

    private fun ensureColumn(table:String,column:String,definition:String) {
        val exists = db.rawQuery("PRAGMA table_info($table)",null).use { c ->
            var found=false; while(c.moveToNext()) if(c.getString(1).equals(column,true)){found=true;break}; found
        }
        if(!exists) runCatching { db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition") }
    }

    data class Deck(val id:Long,val name:String,val count:Int,val source:String?,val depth:Int,val parentName:String?)
    data class Card(val id:Long,val deckId:Long,val front:String,val back:String,val tags:String?,val position:Int,val bookmarked:Boolean,val due:Long,val interval:Int,val ease:Float,val reps:Int)

    fun normalizeDeckName(raw:String):String {
        val n=raw.replace('／','/').replace('›','>').replace('»','>')
            .replace(Regex("\\s*::\\s*"),"::").trim(':',' ','\t','\n')
        val parts=n.split("::").map{it.trim()}.filter{it.isNotBlank()}
        return if(parts.isEmpty())"Uncategorized" else parts.joinToString("::")
    }

    fun upsertDeck(rawName:String,source:String,count:Int):Long {
        val name=normalizeDeckName(rawName)
        db.beginTransaction(); try {
            val id=upsertDeckInternal(name,source,count,true)
            db.setTransactionSuccessful(); AppState.changed(); return id
        } finally { db.endTransaction() }
    }

    /** Import-only transaction: one SQLite transaction for the complete APKG. */
    fun beginImport(){ db.beginTransaction() }
    fun finishImport(success:Boolean, notify:Boolean=true){
        if(success) db.setTransactionSuccessful()
        db.endTransaction()
        if(success && notify) AppState.changed()
    }
    fun upsertDeckForImport(rawName:String,source:String):Long {
        val name=normalizeDeckName(rawName)
        return upsertDeckInternal(name,source,0,true)
    }
    private fun upsertDeckInternal(name:String,source:String,count:Int,replaceCards:Boolean):Long {
        db.execSQL("INSERT OR IGNORE INTO deck(name,source_file,imported_at,card_count) VALUES(?,?,?,?)",arrayOf(name,source,System.currentTimeMillis(),count))
        val id=db.rawQuery("SELECT id FROM deck WHERE name=?",arrayOf(name)).use{c->if(c.moveToFirst())c.getLong(0) else throw IllegalStateException("Unable to create deck")}
        db.execSQL("UPDATE deck SET source_file=?, imported_at=?, card_count=? WHERE id=?",arrayOf(source,System.currentTimeMillis(),count,id))
        if(replaceCards) db.delete("card","deck_id=?",arrayOf(id.toString()))
        return id
    }
    /** Fast import path: caller wraps the whole import in one transaction. */
    fun insertCard(deckId:Long,front:String,back:String,tags:String?,position:Int){
        db.execSQL("INSERT OR REPLACE INTO card(deck_id,front,back,tags,position,due) VALUES(?,?,?,?,?,?)",arrayOf(deckId,front,back,tags ?: "",position,0L))
    }
    fun setDeckCount(deckId:Long,count:Int){db.execSQL("UPDATE deck SET card_count=? WHERE id=?",arrayOf(count,deckId))}

    fun decks():List<Deck> = db.rawQuery("SELECT id,name,card_count,source_file FROM deck ORDER BY name COLLATE NOCASE",null).use{c->buildList{while(c.moveToNext()){val name=c.getString(1);val parts=name.split("::");add(Deck(c.getLong(0),name,c.getInt(2),c.getString(3),parts.size-1,parts.dropLast(1).joinToString("::").ifBlank{null}))}}}
    fun cardCount(deckId:Long):Int=db.rawQuery("SELECT COUNT(*) FROM card WHERE deck_id=?",arrayOf(deckId.toString())).use{c->c.moveToFirst();c.getInt(0)}
    fun reviewCount():Int=db.rawQuery("SELECT COUNT(*) FROM card WHERE due<=?",arrayOf(System.currentTimeMillis().toString())).use{c->c.moveToFirst();c.getInt(0)}
    fun bookmarkCount():Int=db.rawQuery("SELECT COUNT(*) FROM card WHERE bookmarked=1",null).use{c->c.moveToFirst();c.getInt(0)}
    fun bookmarkedCount(deckId:Long):Int=db.rawQuery("SELECT COUNT(*) FROM card WHERE deck_id=? AND bookmarked=1",arrayOf(deckId.toString())).use{c->c.moveToFirst();c.getInt(0)}

    private fun readCard(sql:String,args:Array<String>):Card?=db.rawQuery(sql,args).use{c->if(c.moveToFirst())Card(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getString(4),c.getInt(5),c.getInt(6)!=0,c.getLong(7),c.getInt(8),c.getFloat(9),c.getInt(10))else null}
    fun cardAt(deckId:Long,pos:Int):Card?=readCard("SELECT id,deck_id,front,back,tags,position,bookmarked,due,interval,ease,reps FROM card WHERE deck_id=? AND position=?",arrayOf(deckId.toString(),pos.toString()))
    fun reviewCardAt(pos:Int):Card?=readCard("SELECT id,deck_id,front,back,tags,position,bookmarked,due,interval,ease,reps FROM card WHERE due<=? ORDER BY due,id LIMIT 1 OFFSET ?",arrayOf(System.currentTimeMillis().toString(),pos.toString()))
    fun bookmarkedCardAt(pos:Int):Card?=readCard("SELECT id,deck_id,front,back,tags,position,bookmarked,due,interval,ease,reps FROM card WHERE bookmarked=1 ORDER BY id LIMIT 1 OFFSET ?",arrayOf(pos.toString()))

    fun setBookmarked(cardId:Long,value:Boolean){db.execSQL("UPDATE card SET bookmarked=? WHERE id=?",arrayOf(if(value)1 else 0,cardId));AppState.changed()}
    fun toggleBookmarked(cardId:Long):Boolean{val now=!isBookmarked(cardId);setBookmarked(cardId,now);return now}
    fun isBookmarked(cardId:Long):Boolean=db.rawQuery("SELECT bookmarked FROM card WHERE id=?",arrayOf(cardId.toString())).use{c->c.moveToFirst()&&c.getInt(0)!=0}

    /** Simple SM-2-style scheduling, persisted immediately after every rating. */
    fun review(cardId:Long,rating:Int){
        val c=db.rawQuery("SELECT interval,ease,reps,lapses FROM card WHERE id=?",arrayOf(cardId.toString())).use{cur->if(cur.moveToFirst())longArrayOf(cur.getLong(0),cur.getDouble(1).toBits(),cur.getLong(2),cur.getLong(3)) else null} ?: return
        var interval=c[0].toInt(); var ease=Double.fromBits(c[1]); var reps=c[2].toInt(); var lapses=c[3].toInt()
        when(rating){
            1->{interval=0;lapses++;reps=0;ease=maxOf(1.3,ease-0.20)} // Again
            2->{interval=if(interval<=0)1 else maxOf(1,(interval*1.2).roundToInt());ease=maxOf(1.3,ease-0.15);reps++} // Hard
            3->{interval=when{interval<=0->1;interval==1->3;else->maxOf(2,(interval*ease).roundToInt())};reps++;} // Good
            else->{interval=when{interval<=0->4;interval==1->6;else->maxOf(3,(interval*ease*1.3).roundToInt())};ease+=0.15;reps++}
        }
        val due=System.currentTimeMillis()+interval*24L*60L*60L*1000L
        db.execSQL("UPDATE card SET interval=?,ease=?,reps=?,lapses=?,due=?,last_reviewed=? WHERE id=?",arrayOf(interval,ease,reps,lapses,due,System.currentTimeMillis(),cardId));AppState.changed()
    }

    fun deleteDeck(deckId:Long,includeSubdecks:Boolean=false):Int{
        val target=db.rawQuery("SELECT name FROM deck WHERE id=?",arrayOf(deckId.toString())).use{c->if(c.moveToFirst())c.getString(0)else null}?:return 0
        val ids=mutableListOf<String>(); db.rawQuery(if(includeSubdecks)"SELECT id FROM deck WHERE name=? OR name LIKE ?" else "SELECT id FROM deck WHERE id=?",if(includeSubdecks)arrayOf(target,target+"::%")else arrayOf(deckId.toString())).use{c->while(c.moveToNext())ids.add(c.getLong(0).toString())}
        if(ids.isEmpty())return 0
        db.beginTransaction();try{ids.forEach{db.delete("deck","id=?",arrayOf(it))};db.setTransactionSuccessful()}finally{db.endTransaction()};AppState.changed();return ids.size
    }
    fun deleteSource(sourceFile:String):Int{val ids=mutableListOf<String>();db.rawQuery("SELECT id FROM deck WHERE source_file=?",arrayOf(sourceFile)).use{c->while(c.moveToNext())ids.add(c.getLong(0).toString())};if(ids.isEmpty())return 0;db.beginTransaction();try{ids.forEach{db.delete("deck","id=?",arrayOf(it))};db.setTransactionSuccessful()}finally{db.endTransaction()};AppState.changed();return ids.size}
    fun sourceNames(): List<String> = db.rawQuery("SELECT DISTINCT source_file FROM deck WHERE source_file IS NOT NULL AND source_file<>'' ORDER BY source_file COLLATE NOCASE",null).use{c->buildList{while(c.moveToNext())add(c.getString(0))}}
    fun close(){db.close()}
}
