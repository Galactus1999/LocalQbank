package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File

class FlashcardDb(context: Context) {
    private val dbFile: File = context.getDatabasePath("flashcards.db")
    private val db: SQLiteDatabase
    init {
        dbFile.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS deck(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, source_file TEXT, imported_at INTEGER NOT NULL, card_count INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS card(id INTEGER PRIMARY KEY AUTOINCREMENT, deck_id INTEGER NOT NULL, front TEXT NOT NULL, back TEXT NOT NULL, tags TEXT, position INTEGER NOT NULL, due INTEGER DEFAULT 0, interval INTEGER DEFAULT 0, ease REAL DEFAULT 2.5, reps INTEGER DEFAULT 0, lapses INTEGER DEFAULT 0, FOREIGN KEY(deck_id) REFERENCES deck(id) ON DELETE CASCADE, UNIQUE(deck_id,position))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_flash_deck ON card(deck_id,position)")
    }
    data class Deck(val id:Long,val name:String,val count:Int,val source:String?)
    data class Card(val id:Long,val deckId:Long,val front:String,val back:String,val tags:String?,val position:Int)
    fun upsertDeck(name:String,source:String,count:Int):Long {
        db.beginTransaction(); try {
            db.execSQL("INSERT OR IGNORE INTO deck(name,source_file,imported_at,card_count) VALUES(?,?,?,?)",arrayOf(name,source,System.currentTimeMillis(),count))
            db.execSQL("UPDATE deck SET source_file=?, imported_at=?, card_count=? WHERE name=?",arrayOf(source,System.currentTimeMillis(),count,name))
            val id=db.rawQuery("SELECT id FROM deck WHERE name=?",arrayOf(name)).use{c->c.moveToFirst();c.getLong(0)}
            db.delete("card","deck_id=?",arrayOf(id.toString()))
            db.setTransactionSuccessful(); return id
        } finally { db.endTransaction() }
    }
    fun insertCard(deckId:Long,front:String,back:String,tags:String?,position:Int){db.execSQL("INSERT INTO card(deck_id,front,back,tags,position) VALUES(?,?,?,?,?)",arrayOf(deckId,front,back,tags ?: "",position))}
    fun setDeckCount(deckId:Long,count:Int){db.execSQL("UPDATE deck SET card_count=? WHERE id=?",arrayOf(count,deckId))}
    fun decks():List<Deck> = db.rawQuery("SELECT id,name,card_count,source_file FROM deck ORDER BY name COLLATE NOCASE",null).use{c->buildList{while(c.moveToNext())add(Deck(c.getLong(0),c.getString(1),c.getInt(2),c.getString(3)))}}
    fun cardCount(deckId:Long):Int=db.rawQuery("SELECT COUNT(*) FROM card WHERE deck_id=?",arrayOf(deckId.toString())).use{c->c.moveToFirst();c.getInt(0)}
    fun cardAt(deckId:Long,pos:Int):Card?=db.rawQuery("SELECT id,deck_id,front,back,tags,position FROM card WHERE deck_id=? AND position=?",arrayOf(deckId.toString(),pos.toString())).use{c->if(c.moveToFirst())Card(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getString(4),c.getInt(5)) else null}
    fun close(){db.close()}
}
