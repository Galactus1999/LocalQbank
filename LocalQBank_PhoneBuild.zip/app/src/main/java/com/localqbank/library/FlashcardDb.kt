package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File

/**
 * Dedicated Anki/flashcard store. QBank data never shares this database.
 * Deck names retain Anki's standard PARENT::CHILD::SUBCHILD convention.
 */
class FlashcardDb(context: Context) {
    private val dbFile: File = context.getDatabasePath("flashcards.db")
    private val db: SQLiteDatabase

    init {
        dbFile.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        db.execSQL("PRAGMA foreign_keys=ON")
        db.enableWriteAheadLogging()
        db.execSQL("CREATE TABLE IF NOT EXISTS deck(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, source_file TEXT, imported_at INTEGER NOT NULL, card_count INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS card(id INTEGER PRIMARY KEY AUTOINCREMENT, deck_id INTEGER NOT NULL, front TEXT NOT NULL, back TEXT NOT NULL, tags TEXT, position INTEGER NOT NULL, due INTEGER DEFAULT 0, interval INTEGER DEFAULT 0, ease REAL DEFAULT 2.5, reps INTEGER DEFAULT 0, lapses INTEGER DEFAULT 0, FOREIGN KEY(deck_id) REFERENCES deck(id) ON DELETE CASCADE, UNIQUE(deck_id,position))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_flash_deck ON card(deck_id,position)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_flash_deck_name ON deck(name COLLATE NOCASE)")
    }

    data class Deck(
        val id: Long,
        val name: String,
        val count: Int,
        val source: String?,
        val depth: Int,
        val parentName: String?
    )
    data class Card(val id:Long,val deckId:Long,val front:String,val back:String,val tags:String?,val position:Int)

    /** Normalize without destroying Anki hierarchy semantics. */
    fun normalizeDeckName(raw: String): String {
        val n = raw.replace('／','/').replace('›','>').replace('»','>')
            .replace(Regex("\\s*::\\s*"), "::")
            .trim(':', ' ', '\t', '\n')
        val parts = n.split("::").map { it.trim() }.filter { it.isNotBlank() }
        return if (parts.isEmpty()) "Uncategorized" else parts.joinToString("::")
    }

    fun upsertDeck(rawName:String,source:String,count:Int):Long {
        val name=normalizeDeckName(rawName)
        db.beginTransaction()
        try {
            db.execSQL("INSERT OR IGNORE INTO deck(name,source_file,imported_at,card_count) VALUES(?,?,?,?)",arrayOf(name,source,System.currentTimeMillis(),count))
            val id=db.rawQuery("SELECT id FROM deck WHERE name=?",arrayOf(name)).use{c->if(c.moveToFirst())c.getLong(0) else throw IllegalStateException("Unable to create deck")}
            // Re-importing the same Anki deck replaces its cards while preserving the deck identity.
            db.execSQL("UPDATE deck SET source_file=?, imported_at=?, card_count=? WHERE id=?",arrayOf(source,System.currentTimeMillis(),count,id))
            db.delete("card","deck_id=?",arrayOf(id.toString()))
            db.setTransactionSuccessful()
            return id
        } finally { db.endTransaction() }
    }

    fun insertCard(deckId:Long,front:String,back:String,tags:String?,position:Int){
        db.execSQL("INSERT INTO card(deck_id,front,back,tags,position) VALUES(?,?,?,?,?)",arrayOf(deckId,front,back,tags ?: "",position))
    }
    fun setDeckCount(deckId:Long,count:Int){db.execSQL("UPDATE deck SET card_count=? WHERE id=?",arrayOf(count,deckId))}

    fun decks():List<Deck> = db.rawQuery("SELECT id,name,card_count,source_file FROM deck ORDER BY name COLLATE NOCASE",null).use{c->
        buildList {
            while(c.moveToNext()) {
                val name=c.getString(1)
                val parts=name.split("::")
                add(Deck(c.getLong(0),name,c.getInt(2),c.getString(3),parts.size-1,parts.dropLast(1).joinToString("::").ifBlank{null}))
            }
        }
    }

    fun cardCount(deckId:Long):Int=db.rawQuery("SELECT COUNT(*) FROM card WHERE deck_id=?",arrayOf(deckId.toString())).use{c->c.moveToFirst();c.getInt(0)}
    fun cardAt(deckId:Long,pos:Int):Card?=db.rawQuery("SELECT id,deck_id,front,back,tags,position FROM card WHERE deck_id=? AND position=?",arrayOf(deckId.toString(),pos.toString())).use{c->if(c.moveToFirst())Card(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getString(4),c.getInt(5)) else null}

    fun deleteDeck(deckId:Long, includeSubdecks:Boolean=false):Int {
        val target = db.rawQuery("SELECT name FROM deck WHERE id=?",arrayOf(deckId.toString())).use { c ->
            if(c.moveToFirst()) c.getString(0) else null
        } ?: return 0
        val ids=mutableListOf<String>()
        db.rawQuery(if(includeSubdecks) "SELECT id FROM deck WHERE name=? OR name LIKE ?" else "SELECT id FROM deck WHERE id=?",if(includeSubdecks) arrayOf(target,target+"::%") else arrayOf(deckId.toString())).use{c->while(c.moveToNext())ids.add(c.getLong(0).toString())}
        if(ids.isEmpty())return 0
        db.beginTransaction()
        try {
            ids.forEach{db.delete("card","deck_id=?",arrayOf(it))}
            ids.forEach{db.delete("deck","id=?",arrayOf(it))}
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return ids.size
    }

    fun deleteSource(sourceFile:String):Int {
        val ids=mutableListOf<String>()
        db.rawQuery("SELECT id FROM deck WHERE source_file=?",arrayOf(sourceFile)).use{c->while(c.moveToNext())ids.add(c.getLong(0).toString())}
        if(ids.isEmpty())return 0
        db.beginTransaction()
        try { ids.forEach{db.delete("card","deck_id=?",arrayOf(it));db.delete("deck","id=?",arrayOf(it))};db.setTransactionSuccessful() }
        finally { db.endTransaction() }
        return ids.size
    }

    fun sourceNames():List<String> = db.rawQuery("SELECT DISTINCT source_file FROM deck WHERE source_file IS NOT NULL AND source_file<>'' ORDER BY source_file COLLATE NOCASE",null).use{c->buildList{while(c.moveToNext())add(c.getString(0))}}
    fun close(){db.close()}
}
