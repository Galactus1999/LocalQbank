package com.localqbank.library

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import android.content.pm.ActivityInfo

class ViewerActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var id: String
    private val prefs by lazy { getSharedPreferences("native_reader_state", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        id = intent.getStringExtra("id") ?: "unknown"
        val uri = intent.getStringExtra("uri") ?: return finish()

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.loadsImagesAutomatically = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        web.settings.setSupportZoom(false)
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "LocalQBank")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                injectUniversalReader()
            }
        }
        web.loadUrl(uri)
    }

    private fun injectUniversalReader() {
        val saved = prefs.getString("${id}_state", "") ?: ""
        val escaped = org.json.JSONObject.quote(saved)
        val js = READER_JS
            .replace("__NATIVE_STATE__", escaped)
            .replace("__BANK_ID__", org.json.JSONObject.quote(id))
        web.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveState(json: String) {
            prefs.edit().putString("${id}_state", json).apply()
        }
        @JavascriptInterface
        fun getState(): String = prefs.getString("${id}_state", "") ?: ""
    }

    override fun onBackPressed() {
        web.evaluateJavascript("window.__localQbankGoBack ? window.__localQbankGoBack() : false") { result ->
            if (result != "true") finish()
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        private val READER_JS = """
(function(){
  if(window.__localQbankReaderInstalled) return;
  window.__localQbankReaderInstalled = true;

  var nativeStateRaw = __NATIVE_STATE__;
  var BANK_ID = __BANK_ID__;
  var state = {};
  try { state = nativeStateRaw ? JSON.parse(nativeStateRaw) : {}; } catch(e){ state = {}; }
  state.bookmarks = state.bookmarks || {};
  state.status = state.status || {};
  state.selected = state.selected || {};
  state.position = state.position || {};
  state.times = state.times || {};
  state.settings = state.settings || {};
  state.filter = state.filter || 'all';
  state.bookmarkFilter = state.bookmarkFilter || 'all';
  Object.keys(state.bookmarks).forEach(function(k){ if(state.bookmarks[k]===true) state.bookmarks[k]='favorite'; });

  function save(){
    try { if(window.LocalQBank) LocalQBank.saveState(JSON.stringify(state)); } catch(e){}
  }

  function esc(s){
    return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function html(s){ return String(s==null?'':s); }
  function optionArray(q){
    if(Array.isArray(q.options)) return q.options.map(function(o,i){
      if(typeof o==='string') return {label:String.fromCharCode(65+i),text:o};
      return {label:o.label||String.fromCharCode(65+i),text:o.text||o.option||o.html||''};
    });
    if(q.options && typeof q.options==='object') return Object.keys(q.options).map(function(k){return {label:k,text:q.options[k]};});
    return [];
  }
  function qId(q, fallback){ return String(q && (q.id||q.qid||q.question_id) || fallback); }
  function qText(q){ return q && (q.raw_text||q.text_html||q.text||q.question||q.stem||q.question_text||q.questionHtml||''); }
  function qImg(q){
    var a=[]; if(q && q.img) a.push(q.img);
    if(q && Array.isArray(q.question_images)) a=a.concat(q.question_images);
    if(q && Array.isArray(q.images)) a=a.concat(q.images);
    return a.filter(Boolean);
  }
  function qExp(q){ return q && (q.explanation||q.exp_html||q.explain||q.solution||q.answer_detail||q.explanation_html||q.expl||''); }
  function qExpImgs(q){ return q && (q.explanation_images||q.explanationImages||q.exp_images||[]); }
  function correct(q){
    var a=q && (q.ans||q.answer||q.correct_answer||q.correctAnswer||q.correct);
    if(typeof a==='string'){ var m=a.trim().toUpperCase().match(/^([A-Z])/); if(m) return m[1]; }
    var opts=optionArray(q); for(var i=0;i<opts.length;i++) if(opts[i].correct||opts[i].isCorrect) return String(opts[i].label).toUpperCase();
    return '';
  }

  var mode='unknown', collections=[], currentCollection=0, currentIndex=0, timer=null, remaining=0, started=false;

  // DAMS: TESTS_LIST / ALL_TESTS -> each test becomes a selectable collection.
  try {
    var dams=[];
    if(typeof TESTS_LIST!=='undefined' && Array.isArray(TESTS_LIST)) dams=TESTS_LIST;
    else if(typeof ALL_TESTS!=='undefined' && ALL_TESTS) dams=Object.keys(ALL_TESTS).map(function(k){return ALL_TESTS[k];});
    dams=dams.filter(function(t){return t && Array.isArray(t.questions) && t.questions.length;});
    if(dams.length){
      mode='dams';
      collections=dams.map(function(t,i){return {
        id:String(t.id||('test_'+i)), title:String(t.title||('Test '+(i+1))),
        duration:Number(t.duration||0), questions:t.questions
      };});
    }
  } catch(e){}

  // CoreBTR: APP_DATA -> Subject > Lesson > Questions.
  if(mode==='unknown'){
    try {
      if(typeof APP_DATA!=='undefined' && Array.isArray(APP_DATA)){
        mode='corebtr';
        APP_DATA.forEach(function(sub,si){
          (sub.lessons||[]).forEach(function(les,li){
            if(Array.isArray(les.questions) && les.questions.length) collections.push({
              id:'s'+si+'_l'+li, title:String(sub.title||'Subject')+' • '+String(les.title||'Lesson'),
              subject:String(sub.title||'Subject'), lesson:String(les.title||'Lesson'), duration:0, questions:les.questions
            });
          });
        });
      }
    } catch(e){}
  }

  // Generic fallback: use existing global questions if a third format resembles the DAMS schema.
  if(mode==='unknown'){
    try { if(typeof questions!=='undefined' && Array.isArray(questions) && questions.length){mode='generic';collections=[{id:'default',title:document.title||'QBank',duration:0,questions:questions}];} } catch(e){}
  }

  var root=document.createElement('div'); root.id='local-reader-root'; document.documentElement.style.background='#f4f6fa';
  document.body.innerHTML=''; document.body.style.cssText='margin:0;padding:0;background:#f4f6fa;color:#172033;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;';
  document.body.appendChild(root);

  var css=document.createElement('style'); css.textContent='''
    #local-reader-root{min-height:100vh;background:#f4f6fa;color:#172033}
    *{box-sizing:border-box}.lr-top{position:sticky;top:0;z-index:30;padding-top:env(safe-area-inset-top);background:#101828;color:white;box-shadow:0 4px 18px rgba(16,24,40,.18)}
    .lr-bar{min-height:64px;display:flex;align-items:center;gap:10px;padding:10px 14px}.lr-back{border:0;background:rgba(255,255,255,.10);color:white;border-radius:12px;padding:10px 13px;font-size:18px}.lr-title{font-weight:800;font-size:17px;line-height:1.2;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.lr-sub{font-size:12px;color:#b8c3d6;margin-top:3px}
    .lr-wrap{max-width:920px;margin:0 auto;padding:16px 12px 34px}.lr-card{background:white;border:1px solid #e5e9f0;border-radius:18px;box-shadow:0 5px 22px rgba(16,24,40,.07);padding:17px}.lr-section-title{font-size:18px;font-weight:800;margin:2px 0 10px}.lr-section-sub{font-size:12px;color:#667085;margin-bottom:13px}
    .lr-list{display:grid;gap:10px}.lr-list button{width:100%;text-align:left;border:1px solid #e1e7ef;background:white;border-radius:15px;padding:15px;box-shadow:0 1px 4px rgba(16,24,40,.04)}.lr-list button:active{transform:scale(.99)}
    .lr-meta{font-size:12px;color:#667085;margin-top:5px}.lr-stat{display:flex;gap:7px;flex-wrap:wrap;margin:4px 0 15px}.lr-chip{background:#f0f3f8;border:1px solid #e3e8ef;border-radius:999px;padding:7px 10px;font-size:11px;color:#475467}
    .lr-progress{height:7px;background:#e8edf3;border-radius:99px;overflow:hidden}.lr-progress>i{display:block;height:100%;background:#315fbd;width:0;border-radius:99px}
    .lr-qhead{display:flex;align-items:center;gap:8px;margin-bottom:13px}.lr-qnum{font-size:12px;font-weight:800;color:#667085;flex:1}.lr-book{border:1px solid #d8dee8;background:white;border-radius:11px;padding:8px 11px;font-size:19px}
    .lr-question{font-size:18px;line-height:1.55;font-weight:650;margin:15px 0}.lr-question img,.lr-exp img{max-width:100%;height:auto;display:block;margin:12px auto;border-radius:12px}
    .lr-options{display:grid;gap:9px}.lr-opt{border:1px solid #d9e0e8;background:white;border-radius:13px;padding:14px;text-align:left;font-size:15px;line-height:1.45}.lr-opt:active{transform:scale(.995)}
    .lr-opt.correct{border-color:#16a34a;background:#ecfdf3}.lr-opt.wrong{border-color:#dc2626;background:#fef2f2}.lr-opt.selected{box-shadow:0 0 0 2px #315fbd inset}
    .lr-result{margin-top:14px;padding:12px;border-radius:12px;font-weight:750}.lr-result.ok{background:#ecfdf3;color:#166534}.lr-result.bad{background:#fef2f2;color:#991b1b}.lr-exp{margin-top:14px;border:1px solid #e4e8ee;border-radius:13px;padding:13px;font-size:14px;line-height:1.58}.lr-exp-title{font-weight:800;margin-bottom:7px}.lr-hidden{display:none}
    .lr-nav{display:grid;grid-template-columns:1fr 1.3fr 1fr;gap:8px;margin-top:16px}.lr-nav button,.lr-primary{border:0;border-radius:12px;padding:12px;font-weight:750}.lr-prev{background:#edf1f5}.lr-next,.lr-primary{background:#315fbd;color:white}.lr-nav button:disabled{opacity:.4}
    .lr-tools{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}.lr-tools button{border:1px solid #d8dee8;background:white;border-radius:11px;padding:10px 12px;font-weight:650}.lr-timer{font-variant-numeric:tabular-nums;font-weight:850;padding:8px 10px;border-radius:10px;background:#fff3cd;color:#7a5200}
    .lr-settings{display:grid;grid-template-columns:1fr auto;gap:9px;align-items:center}.lr-settings input{width:90px;padding:9px;border:1px solid #ccd5e0;border-radius:9px}.lr-muted{color:#667085;font-size:13px}.lr-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:7px;margin-top:10px}.lr-grid button{border:1px solid #d8dee8;background:white;border-radius:9px;padding:9px 2px}.lr-grid .done{background:#dcfce7;border-color:#86efac}.lr-grid .bm{box-shadow:0 0 0 2px #facc15 inset}.lr-empty{text-align:center;padding:36px 18px;color:#667085}
    @media(max-width:600px){.lr-wrap{padding:10px 9px 24px}.lr-card{padding:14px;border-radius:16px}.lr-question{font-size:17px}.lr-grid{grid-template-columns:repeat(5,1fr)}.lr-dashboard{grid-template-columns:repeat(2,1fr)}}
    @media(prefers-color-scheme:dark){#local-reader-root{background:#0b1220;color:#e5e7eb}.lr-card,.lr-list button,.lr-opt,.lr-book,.lr-tools button,.lr-grid button{background:#111b2e;border-color:#26344a;color:#e5e7eb}.lr-meta,.lr-muted,.lr-qnum,.lr-section-sub{color:#94a3b8}.lr-progress{background:#26344a}.lr-prev{background:#26344a;color:#e5e7eb}.lr-exp{border-color:#26344a}.lr-chip{background:#1e293b;border-color:#334155;color:#cbd5e1}.lr-dashboard button,.lr-bookmarks button,.lr-filterbar button,.lr-listbtn{background:#111b2e;border-color:#26344a;color:#e5e7eb}.lr-opt.correct{background:#052e1b}.lr-opt.wrong{background:#3b1111}}
  '''.replace(/'''/g,''); document.head.appendChild(css);

  function snapshotKey(){return mode+'|'+(collections[currentCollection]&&collections[currentCollection].id||'default');}
  function answeredCount(c){var n=0;(c.questions||[]).forEach(function(q){if(state.status[qId(q,n)] )n++;});return n;}
  function collectionStats(c){var done=0,wrong=0,bm=0,imp=0,rev=0,doubt=0,fav=0;(c.questions||[]).forEach(function(q,i){var id=qId(q,i),b=state.bookmarks[id];if(state.status[id])done++;if(state.status[id]==='wrong')wrong++;if(b){bm++;if(b==='important')imp++;if(b==='revise')rev++;if(b==='doubt')doubt++;if(b==='favorite')fav++;}});return {done:done,wrong:wrong,bm:bm,imp:imp,rev:rev,doubt:doubt,fav:fav,total:(c.questions||[]).length};}
  function totals(){var t={total:0,done:0,wrong:0,bm:0,imp:0,rev:0,doubt:0,fav:0};collections.forEach(function(c){var x=collectionStats(c);t.total+=x.total;t.done+=x.done;t.wrong+=x.wrong;t.bm+=x.bm;t.imp+=x.imp;t.rev+=x.rev;t.doubt+=x.doubt;t.fav+=x.fav;});return t;}
  function filteredIndices(c){var out=[];(c.questions||[]).forEach(function(q,i){var id=qId(q,i),st=state.status[id]||'',b=state.bookmarks[id]||'';var ok=state.filter==='all'||(state.filter==='solved'&&st)|| (state.filter==='unsolved'&&!st)||(state.filter==='wrong'&&st==='wrong')||(state.filter==='bookmarked'&&b);if(state.filter==='bookmarked'&&state.bookmarkFilter!=='all'&&b!==state.bookmarkFilter)ok=false;if(ok)out.push(i);});return out;}
  function formatTime(s){s=Math.max(0,Math.floor(s||0));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
  function header(title,sub,back){return '<div class="lr-top"><div class="lr-bar"><button class="lr-back" onclick="window.__localQbankGoBack()">←</button><div class="lr-title">'+esc(title)+'<div class="lr-sub">'+esc(sub||'')+'</div></div></div></div>';}
  function home(){
    stopTimer();
    var title=mode==='dams'?'DAMS Quiz QBank':mode==='corebtr'?'CoreBTR QBank':'Local QBank';
    var t=totals(), pct=t.total?Math.round(t.done*100/t.total):0;
    var cards='';
    collections.forEach(function(c,i){var st=collectionStats(c), p=st.total?Math.round(st.done*100/st.total):0, matches=filteredIndices(c).length;if(state.filter!=='all'&&matches===0)return;var matchText=state.filter==='all'?'':(' • '+matches+' match'+(matches===1?'':'es'));cards+='<button onclick="window.__lrOpen('+i+')"><b>'+esc(c.title)+'</b><div class="lr-meta">'+st.total+' questions • '+st.done+' solved • '+st.wrong+' wrong • '+st.bm+' bookmarked'+matchText+'</div><div class="lr-progress" style="margin-top:9px"><i style="width:'+p+'%"></i></div><div class="lr-meta">'+p+'% completed</div></button>';});
    root.innerHTML=header(title,t.total+' questions • '+pct+'% overall',false)+'<div class="lr-wrap">'+
      '<div class="lr-card"><div class="lr-section-title">Study Dashboard</div><div class="lr-section-sub">Track your progress and jump directly to the questions that need attention.</div>'+ 
      '<div class="lr-dashboard"><button onclick="window.__lrFilter('all')"><b>'+t.total+'</b><span>All</span></button><button onclick="window.__lrFilter('solved')"><b>'+t.done+'</b><span>Solved</span></button><button onclick="window.__lrFilter('unsolved')"><b>'+(t.total-t.done)+'</b><span>Unsolved</span></button><button onclick="window.__lrFilter('wrong')"><b>'+t.wrong+'</b><span>Wrong</span></button></div>'+ 
      '<div class="lr-section-title" style="font-size:15px;margin-top:18px">Bookmarks</div><div class="lr-bookmarks"><button onclick="window.__lrBookmarkFilter('all')">★ '+t.bm+' All</button><button onclick="window.__lrBookmarkFilter('important')">🔴 '+t.imp+' Important</button><button onclick="window.__lrBookmarkFilter('revise')">🔵 '+t.rev+' Revise</button><button onclick="window.__lrBookmarkFilter('doubt')">🟠 '+t.doubt+' Doubt</button><button onclick="window.__lrBookmarkFilter('favorite')">⭐ '+t.fav+' Favorite</button></div>'+ 
      '<div class="lr-section-title" style="font-size:15px;margin-top:18px">Available QBanks</div><div class="lr-list">'+(cards||'<div class="lr-empty">No supported questions detected.</div>')+'</div></div></div>';
  }
  window.__lrFilter=function(f){state.filter=f;state.bookmarkFilter='all';save();home();};
  window.__lrBookmarkFilter=function(b){state.filter='bookmarked';state.bookmarkFilter=b;save();home();};

  window.__lrOpen=function(i){currentCollection=i; var a=filteredIndices(collections[i]); currentIndex=Number(state.position[snapshotKey()]||0); if(state.filter!=='all' && a.indexOf(currentIndex)<0)currentIndex=a.length?a[0]:0; if(currentIndex<0||currentIndex>=collections[i].questions.length)currentIndex=0; showQuestion();};
  window.__localQbankGoBack=function(){
    if(started){stopTimer(); started=false; save(); home(); return true;}
    if(root.querySelector('.lr-card') && root.querySelector('.lr-question')===null){home();return true;}
    home(); return true;
  };

  function showQuestion(){
    var c=collections[currentCollection]; var q=c.questions[currentIndex]; if(!q)return home();
    var id=qId(q,currentIndex), opts=optionArray(q), sel=state.selected[id], status=state.status[id], bm=state.bookmarks[id]||'', cor=correct(q), indices=filteredIndices(c), pos=indices.indexOf(currentIndex);
    if(state.filter!=='all' && pos<0){if(indices.length){currentIndex=indices[0];q=c.questions[currentIndex];id=qId(q,currentIndex);sel=state.selected[id];status=state.status[id];bm=state.bookmarks[id]||'';cor=correct(q);pos=0;}else{return emptyFilter(c);}}
    var pct=Math.round((pos+1)*100/Math.max(1,indices.length));
    var optHtml=opts.map(function(o){var lab=String(o.label||'').toUpperCase();var cls='lr-opt';if(sel===lab)cls+=' selected';if(status && lab===cor)cls+=' correct';if(status && sel===lab && lab!==cor)cls+=' wrong';return '<button class="'+cls+'" onclick="window.__lrAnswer(\''+esc(id).replace(/'/g,"\\'")+"\',\'"+esc(lab).replace(/'/g,"\\'")+"\')" '+(status?'disabled':'')+'><b>'+esc(lab)+'.</b> '+html(o.text)+'</button>';}).join('');
    var imgs=qImg(q).map(function(u){return '<img src="'+esc(u)+'" loading="lazy">';}).join('');
    var result=status?'<div class="lr-result '+(status==='correct'?'ok':'bad')+'">'+(status==='correct'?'✓ Correct':'✗ Wrong')+' • Correct answer: '+esc(cor||'Not specified')+'</div>':'';
    var exp=status?'<div class="lr-exp"><div class="lr-exp-title">Explanation</div>'+html(qExp(q)||'No explanation available')+(qExpImgs(q)||[]).map(function(u){return '<img src="'+esc(u)+'">';}).join('')+'</div>':'';
    var timerHtml=c.duration?'<span class="lr-timer" id="lr-timer">'+formatTime(remaining)+'</span>':'';
    var bmLabel=bm==='important'?'🔴 Important':bm==='revise'?'🔵 Revise':bm==='doubt'?'🟠 Doubt':bm==='favorite'?'⭐ Favorite':'☆ Bookmark';
    root.innerHTML=header(c.title,(pos+1)+' / '+indices.length+' • '+filterLabel(),false)+'<div class="lr-wrap"><div class="lr-card"><div class="lr-filterbar"><button onclick="window.__lrShowDashboard()">Dashboard</button><button class="lr-filter-active" onclick="window.__lrNav()">Questions</button><span class="lr-spacer"></span><button class="lr-book" onclick="window.__lrBookmark()">'+bmLabel+'</button></div><div class="lr-qhead"><div class="lr-qnum">Question '+(currentIndex+1)+' of '+c.questions.length+' • '+esc(id)+'</div>'+timerHtml+'</div><div class="lr-progress"><i style="width:'+pct+'%"></i></div><div class="lr-question" style="margin-top:14px">'+html(qText(q))+'</div><div>'+imgs+'</div><div class="lr-options">'+optHtml+'</div>'+result+exp+'<div class="lr-tools"><button onclick="window.__lrNav()">Question List</button><button onclick="window.__lrTimerSettings()">Timer</button></div><div class="lr-nav"><button class="lr-prev" onclick="window.__lrPrev()" '+(pos<=0?'disabled':'')+'>Previous</button><button class="lr-next" onclick="window.__lrNext()" '+(pos===indices.length-1?'disabled':'')+'>Next</button><button class="lr-primary" onclick="window.__localQbankGoBack()">Back</button></div></div></div>';
    if(c.duration && !started){ remaining=Number(state.times[snapshotKey()]!=null?state.times[snapshotKey()]:c.duration*60); started=true; startTimer(); }
  }
  function filterLabel(){return state.filter==='solved'?'Solved':state.filter==='unsolved'?'Unsolved':state.filter==='wrong'?'Wrong':state.filter==='bookmarked'?'Bookmarked':'All Questions';}
  function emptyFilter(c){root.innerHTML=header(c.title,filterLabel(),false)+'<div class="lr-wrap"><div class="lr-card lr-empty"><div style="font-size:34px">✓</div><b>No questions in this category</b><div class="lr-section-sub">Try another filter from the dashboard.</div><div class="lr-tools"><button class="lr-primary" onclick="window.__lrShowDashboard()">Open Dashboard</button></div></div></div>';}
  window.__lrShowDashboard=function(){home();};

  window.__lrAnswer=function(id,lab){
    if(state.status[id])return; var q=collections[currentCollection].questions[currentIndex], cor=correct(q); state.selected[id]=lab; state.status[id]=(lab===cor?'correct':'wrong'); save(); showQuestion();
  };
  window.__lrBookmark=function(){var q=collections[currentCollection].questions[currentIndex],id=qId(q,currentIndex),old=state.bookmarks[id]||'';var choices=['important','revise','doubt','favorite'];var labels=['🔴 Important','🔵 Revise','🟠 Doubt','⭐ Favorite'];var card=document.createElement('div');card.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:50;display:flex;align-items:center;justify-content:center;padding:18px;';var buttons=choices.map(function(x,i){return '<button class="lr-listbtn" onclick="window.__lrSetBookmark(\''+x+'\')">'+labels[i]+'</button>';}).join('');buttons+='<button class="lr-listbtn" onclick="window.__lrSetBookmark(\'\')">☆ Remove bookmark</button>';card.innerHTML='<div class="lr-card" style="max-width:360px;width:100%"><h3 style="margin-top:0">Bookmark this question</h3><div class="lr-section-sub">Choose a category. You can change it anytime.</div><div class="lr-list" style="margin-top:12px">'+buttons+'</div></div>';document.body.appendChild(card);};
  window.__lrSetBookmark=function(cat){var q=collections[currentCollection].questions[currentIndex],id=qId(q,currentIndex);if(cat)state.bookmarks[id]=cat;else delete state.bookmarks[id];save();document.querySelector('div[style*="fixed"]')?.remove();showQuestion();};
  window.__lrPrev=function(){var a=filteredIndices(collections[currentCollection]),p=a.indexOf(currentIndex);if(p>0){currentIndex=a[p-1];state.position[snapshotKey()]=currentIndex;save();showQuestion();}};
  window.__lrNext=function(){var a=filteredIndices(collections[currentCollection]),p=a.indexOf(currentIndex);if(p<a.length-1){currentIndex=a[p+1];state.position[snapshotKey()]=currentIndex;save();showQuestion();}};
  window.__lrNav=function(){
    var c=collections[currentCollection], a=filteredIndices(c), g=''; a.forEach(function(i){var q=c.questions[i],id=qId(q,i),cl='';if(state.status[id])cl+=' done';if(state.status[id]==='wrong')cl+=' wrong';if(state.bookmarks[id])cl+=' bm';g+='<button class="'+cl+'" onclick="window.__lrJump('+i+')">'+(i+1)+'</button>';});
    root.innerHTML=header(c.title,a.length+' questions • '+filterLabel(),false)+'<div class="lr-wrap"><div class="lr-card"><div class="lr-filterbar"><button onclick="window.__lrShowDashboard()">Dashboard</button><span class="lr-spacer"></span><span class="lr-muted">Green = solved • Red = wrong • ★ = bookmarked</span></div><div class="lr-grid">'+(g||'<div class="lr-empty">No questions match this filter.</div>')+'</div></div></div>';
  };
  window.__lrJump=function(i){currentIndex=i;state.position[snapshotKey()]=i;save();showQuestion();};

  function stopTimer(){if(timer){clearInterval(timer);timer=null;}}
  function startTimer(){stopTimer();if(!collections[currentCollection].duration)return;timer=setInterval(function(){remaining--;state.times[snapshotKey()]=remaining;save();var el=document.getElementById('lr-timer');if(el)el.textContent=formatTime(remaining);if(remaining<=0){stopTimer();started=false;alert('Time is up. You can continue reviewing your answers.');showQuestion();}},1000);}
  window.__lrTimerSettings=function(){
    stopTimer(); var c=collections[currentCollection], old=c.duration?Math.ceil((remaining||c.duration*60)/60):0;
    var card=document.createElement('div');card.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:50;display:flex;align-items:center;justify-content:center;padding:18px;';
    card.innerHTML='<div class="lr-card" style="max-width:360px;width:100%"><h3 style="margin-top:0">Timer settings</h3><div class="lr-settings"><span>Minutes</span><input id="lr-min" type="number" min="0" max="999" value="'+old+'"></div><div class="lr-muted" style="margin-top:8px">Set 0 for no timer.</div><div class="lr-tools" style="justify-content:flex-end"><button onclick="this.closest(\'div[style*=fixed]\').remove();startTimer()">Cancel</button><button class="lr-primary" onclick="window.__lrSetTimer()">Apply</button></div></div>';
    document.body.appendChild(card);
  };
  window.__lrSetTimer=function(){var v=Math.max(0,Number(document.getElementById('lr-min').value||0));var c=collections[currentCollection];c.duration=v;remaining=v*60;state.times[snapshotKey()]=remaining;save();document.querySelector('div[style*="fixed"]')?.remove();started=false;showQuestion();};

  if(mode==='unknown' || !collections.length){root.innerHTML=header('Unsupported QBank','This HTML format was not recognized',false)+'<div class="lr-wrap"><div class="lr-card lr-empty">The file loaded, but its question data format was not recognized. This app can be extended with another adapter for this HTML format.</div></div>';} else home();
})();
"""
    }
}
