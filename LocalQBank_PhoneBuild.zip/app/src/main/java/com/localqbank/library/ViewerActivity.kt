package com.localqbank.library

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class ViewerActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var id: String
    private val prefs by lazy { getSharedPreferences("native_reader_state", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        id = intent.getStringExtra("id") ?: "unknown"
        val uri = intent.getStringExtra("uri") ?: return finish()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = android.graphics.Color.rgb(16, 24, 40)
        window.navigationBarColor = android.graphics.Color.rgb(16, 24, 40)
        web = WebView(this)
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.loadsImagesAutomatically = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        web.settings.setSupportZoom(false)
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "LocalQBank")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = false
            override fun onPageFinished(view: WebView, url: String?) { injectUniversalReader() }
        }
        web.loadUrl(uri)
    }

    private fun injectUniversalReader() {
        val saved = prefs.getString("${id}_state", "") ?: ""
        val js = READER_JS.replace("__NATIVE_STATE__", org.json.JSONObject.quote(saved))
            .replace("__BANK_ID__", org.json.JSONObject.quote(id))
        web.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @android.webkit.JavascriptInterface fun saveState(json: String) {
            prefs.edit().putString("${id}_state", json).apply()
            try {
                val o = org.json.JSONObject(json)
                val s = org.json.JSONObject().apply {
                    put("today", o.optInt("todayCount", 0))
                    put("solved", o.optInt("solvedCount", 0))
                    put("wrong", o.optInt("wrongCount", 0))
                    put("bookmarked", o.optInt("bookmarkCount", 0))
                    put("updated", System.currentTimeMillis())
                }
                prefs.edit().putString("${id}_summary", s.toString()).apply()
            } catch (_: Exception) {}
        }
        @android.webkit.JavascriptInterface fun getState(): String = prefs.getString("${id}_state", "") ?: ""
    }

    override fun onBackPressed() {
        web.evaluateJavascript("window.__localQbankGoBack ? window.__localQbankGoBack() : false") { result ->
            if (result != "true") finish()
        }
    }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    companion object {
        private val READER_JS = """
(function(){
 if(window.__localQbankReaderInstalled)return; window.__localQbankReaderInstalled=true;
 var raw=__NATIVE_STATE__, BANK=__BANK_ID__, state={};
 try{state=raw?JSON.parse(raw):{};}catch(e){state={};}
 state.bookmarks=state.bookmarks||{};state.status=state.status||{};state.selected=state.selected||{};state.position=state.position||{};state.times=state.times||{};state.lastAnswerDate=state.lastAnswerDate||{};state.filter=state.filter||'all';state.todayCount=state.todayCount||0;
 function save(){try{state.solvedCount=Object.keys(state.status).length;state.wrongCount=Object.keys(state.status).filter(function(k){return state.status[k]==='wrong';}).length;state.bookmarkCount=Object.keys(state.bookmarks).length;if(window.LocalQBank)LocalQBank.saveState(JSON.stringify(state));}catch(e){}}
 function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
 function html(s){return String(s==null?'':s);}
 function opts(q){if(Array.isArray(q.options))return q.options.map(function(o,i){if(typeof o==='string')return{label:String.fromCharCode(65+i),text:o};return{label:o.label||String.fromCharCode(65+i),text:o.text||o.option||o.html||'',correct:o.correct||o.isCorrect};});if(q.options&&typeof q.options==='object')return Object.keys(q.options).map(function(k){var v=q.options[k];return{label:k,text:typeof v==='object'?(v.text||v.option||''):v,correct:typeof v==='object'&&(v.correct||v.isCorrect)};});return[];}
 function qid(q,i){return String(q&&(q.id||q.qid||q.question_id||q.questionId)||('q_'+i));}
 function qtext(q){return q&&(q.raw_text||q.text_html||q.text||q.question||q.stem||q.question_text||q.questionHtml||q.prompt||'');}
 function qimgs(q){var a=[];if(q&&q.img)a.push(q.img);if(q&&Array.isArray(q.question_images))a=a.concat(q.question_images);if(q&&Array.isArray(q.images))a=a.concat(q.images);return a.filter(Boolean);}
 function exp(q){return q&&(q.explanation||q.exp_html||q.explain||q.solution||q.answer_detail||q.explanation_html||q.expl||'');}
 function expimgs(q){return q&&(q.explanation_images||q.explanationImages||q.exp_images||[])||[];}
 function correct(q){var a=q&&(q.ans||q.answer||q.correct_answer||q.correctAnswer||q.correct||q.correct_option||q.correctOption);if(typeof a==='string'){var m=a.trim().toUpperCase().match(/^([A-Z])/);if(m)return m[1];}var os=opts(q);for(var i=0;i<os.length;i++)if(os[i].correct)return String(os[i].label).toUpperCase();return'';}
 function looks(q){return q&&typeof q==='object'&&!Array.isArray(q)&&String(qtext(q)).trim().length>8&&q.options&&(Array.isArray(q.options)||typeof q.options==='object');}
 function norm(q,i){return{id:q.id||q.qid||q.question_id||('q_'+i),text:qtext(q),options:q.options||q.choices||q.answers||[],ans:q.ans||q.answer||q.correct_answer||q.correctAnswer||q.correct||'',expl:exp(q),img:q.img||q.image||'',question_images:q.question_images||q.images||[],explanation_images:expimgs(q),audio:q.audio,video:q.video};}
 function qarr(a){if(!Array.isArray(a)||!a.length)return[];var sm=a.slice(0,Math.min(10,a.length)),hit=sm.filter(looks).length;if(hit>=Math.max(1,Math.ceil(sm.length*.34)))return a.map(norm).filter(function(x){return String(x.text).trim();});return[];}
 function balanced(src,start){var d=0,quote='',escp=false;for(var i=start;i<src.length;i++){var c=src[i];if(quote){if(escp)escp=false;else if(c==='\\')escp=true;else if(c===quote)quote='';continue;}if(c==='"'||c==="'")quote=c;else if(c==='[')d++;else if(c===']'){d--;if(d===0)return src.slice(start,i+1);}}return'';}
 function parseSrcdoc(src){var best=[];var re=/(?:var|let|const)?\s*questions\s*=\s*\[/g,m;while((m=re.exec(src))){var a=balanced(src,src.indexOf('[',m.index));if(!a)continue;try{var j=JSON.parse(a);var qa=qarr(j);if(qa.length>best.length)best=qa;}catch(e){try{var fixed=a.replace(/,\s*([}\\]])/g,'$1');var j2=JSON.parse(fixed);var qa2=qarr(j2);if(qa2.length>best.length)best=qa2;}catch(x){}}}return best;}
 function extractIframe(){var out=[];try{document.querySelectorAll('iframe[srcdoc]').forEach(function(fr,i){var src=fr.getAttribute('srcdoc')||fr.srcdoc||'',qa=parseSrcdoc(src);if(qa.length){var box=fr.closest('.iframe-container');var title=(box&&box.querySelector('h2')&&box.querySelector('h2').innerText)||'';if(!title){try{var doc=new DOMParser().parseFromString(src,'text/html');title=(doc.title||'').trim();}catch(e){}}out.push({id:'iframe_'+i,title:title||('Embedded Test '+(i+1)),duration:0,questions:qa});}});}catch(e){}return out;}
 function gv(n){try{if(n==='TESTS_LIST'&&typeof TESTS_LIST!=='undefined')return TESTS_LIST;if(n==='ALL_TESTS'&&typeof ALL_TESTS!=='undefined')return ALL_TESTS;if(n==='APP_DATA'&&typeof APP_DATA!=='undefined')return APP_DATA;if(n==='questions'&&typeof questions!=='undefined')return questions;if(n==='testData'&&typeof testData!=='undefined')return testData;if(n==='quizData'&&typeof quizData!=='undefined')return quizData;}catch(e){}try{return window[n];}catch(e){return null;}}
 function structured(){var out=[];var names=['TESTS_LIST','ALL_TESTS','TESTS','testData','quizData'];names.forEach(function(n){try{var v=gv(n);if(Array.isArray(v)){v.forEach(function(t,i){if(t&&Array.isArray(t.questions)&&t.questions.length)out.push({id:String(t.id||n+'_'+i),title:String((Array.isArray(t.path)&&t.path.length?t.path.join(' • ')+' • ':'')+(t.title||'Test '+(i+1))),duration:Number(t.duration||0),path:Array.isArray(t.path)?t.path:[],questions:t.questions.map(norm)});});}else if(v&&typeof v==='object'){Object.keys(v).forEach(function(k){var t=v[k];if(t&&Array.isArray(t.questions)&&t.questions.length)out.push({id:String(t.id||k),title:String((Array.isArray(t.path)&&t.path.length?t.path.join(' • ')+' • ':'')+(t.title||k)),duration:Number(t.duration||0),path:Array.isArray(t.path)?t.path:[],questions:t.questions.map(norm)});});}}catch(e){}});return out;}
 function walk(v,path,seen,out,depth){if(depth>6||!v||typeof v!=='object'||seen.indexOf(v)>=0)return;seen.push(v);if(Array.isArray(v)){var a=qarr(v);if(a.length)out.push({path:path,questions:a});v.slice(0,60).forEach(function(x,i){walk(x,path+'['+i+']',seen,out,depth+1);});}else Object.keys(v).slice(0,100).forEach(function(k){try{walk(v[k],path+'.'+k,seen,out,depth+1);}catch(e){}});}
 function generic(){var out=[],seen=[],names=['questions','questionData','questionsData','quizData','testData','qbankData','QBANK_DATA','DATA','data','quiz','qbank'];names.forEach(function(n){try{var v=gv(n);if(v)walk(v,n,seen,out,0);}catch(e){}});var u={};out.forEach(function(x){var k=x.questions.length+'|'+x.questions.slice(0,2).map(function(q){return q.id+'|'+q.text;}).join('~');u[k]=x;});return Object.keys(u).map(function(k,i){var x=u[k];return{id:'generic_'+i,title:(document.title||'Imported QBank')+' • '+x.path,duration:0,questions:x.questions};}).sort(function(a,b){return b.questions.length-a.questions.length;}).slice(0,40);}
 var mode='unknown',collections=[];
 try{if(typeof TESTS_LIST!=='undefined'||typeof ALL_TESTS!=='undefined'){collections=structured();if(collections.length)mode='structured';}}catch(e){}
 if(mode==='unknown')try{if(typeof APP_DATA!=='undefined'&&Array.isArray(APP_DATA)){APP_DATA.forEach(function(s,si){(s.lessons||[]).forEach(function(l,li){if(l.questions&&l.questions.length)collections.push({id:'s'+si+'l'+li,title:String(s.title||'Subject')+' • '+String(l.title||'Lesson'),path:[s.title,l.title],duration:0,questions:l.questions.map(norm)});});});if(collections.length)mode='corebtr';}}catch(e){}
 if(mode==='unknown'){collections=extractIframe();if(collections.length)mode='iframe';}
 if(mode==='unknown'){collections=generic();if(collections.length)mode='generic';}
 var current=0,index=0,screen='home',timer=null,remaining=0,test=null;
 document.documentElement.style.background='#f4f6fa';document.body.innerHTML='';document.body.style.cssText='margin:0;background:#f4f6fa;color:#172033;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;';var root=document.createElement('div');root.id='lr';document.body.appendChild(root);
 var style=document.createElement('style');style.textContent='*{box-sizing:border-box}#lr{min-height:100vh}.top{position:sticky;top:0;z-index:20;background:#101828;color:#fff;box-shadow:0 4px 16px #10182822}.bar{min-height:64px;padding:10px 14px;display:flex;align-items:center;gap:10px}.back,.iconbtn{border:0;border-radius:11px;padding:9px 11px;background:#ffffff18;color:#fff;font-size:18px}.title{font-size:17px;font-weight:800;flex:1}.sub{font-size:11px;color:#b8c3d6;margin-top:2px}.wrap{max-width:900px;margin:auto;padding:12px 10px 34px}.card{background:#fff;border:1px solid #e5e9f0;border-radius:18px;padding:15px;box-shadow:0 5px 20px #10182810;margin-bottom:12px}.h{font-size:19px;font-weight:850;margin-bottom:5px}.muted{font-size:12px;color:#667085}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:9px}.stat{border:1px solid #e1e7ef;border-radius:14px;background:#fff;padding:14px;text-align:left}.stat b{display:block;font-size:24px}.stat span{font-size:12px;color:#667085}.actions{display:grid;grid-template-columns:1fr 1fr;gap:9px}.primary,.secondary,.choice{border:0;border-radius:13px;padding:13px;font-weight:800}.primary{background:#315fbd;color:#fff}.secondary{background:#edf1f6;color:#172033}.list{display:grid;gap:9px}.item{text-align:left;border:1px solid #e1e7ef;background:#fff;border-radius:14px;padding:14px}.meta{font-size:12px;color:#667085;margin-top:5px}.barline{height:7px;background:#e9edf3;border-radius:99px;overflow:hidden;margin-top:9px}.barline i{display:block;height:100%;background:#315fbd}.filters{display:flex;gap:7px;overflow:auto;padding-bottom:3px}.filters button{white-space:nowrap;border:1px solid #d8dee8;background:#fff;border-radius:999px;padding:8px 11px}.q{font-size:18px;line-height:1.55;font-weight:650;margin:14px 0}.q img,.exp img{max-width:100%;height:auto;display:block;margin:11px auto;border-radius:11px}.options{display:grid;gap:8px}.opt{text-align:left;border:1px solid #d9e0e8;background:#fff;border-radius:13px;padding:13px;line-height:1.45}.correct{background:#ecfdf3!important;border-color:#22c55e!important}.wrong{background:#fef2f2!important;border-color:#ef4444!important}.selected{box-shadow:inset 0 0 0 2px #315fbd}.result{margin-top:12px;padding:11px;border-radius:11px;font-weight:800}.ok{background:#ecfdf3;color:#166534}.bad{background:#fef2f2;color:#991b1b}.exp{margin-top:12px;border:1px solid #e2e8f0;border-radius:13px;padding:12px;font-size:14px;line-height:1.6}.nav{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:14px}.bm{border:1px solid #d8dee8;background:#fff;border-radius:10px;padding:8px}.nums{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}.nums button{padding:8px 2px;border:1px solid #d8dee8;border-radius:8px;background:#fff}.done{background:#dcfce7!important}.review{box-shadow:inset 0 0 0 2px #f59e0b}.testbar{display:flex;justify-content:space-between;align-items:center;font-weight:800}.timer{font-variant-numeric:tabular-nums;background:#fff3cd;color:#7a5200;padding:7px 9px;border-radius:9px}.pill{display:inline-block;padding:6px 9px;border-radius:999px;background:#eef2f7;font-size:11px;margin:2px}.modal{position:fixed;inset:0;background:#0008;z-index:50;display:flex;align-items:center;justify-content:center;padding:18px}.modal .card{max-width:390px;width:100%;margin:0}.select{width:100%;padding:11px;border:1px solid #ccd5e0;border-radius:10px;margin:6px 0 10px} @media(max-width:600px){.q{font-size:17px}.nums{grid-template-columns:repeat(6,1fr)}}';document.head.appendChild(style);
 function header(t,s,back){return'<div class="top"><div class="bar">'+(back?'<button class="back" onclick="goBack()">←</button>':'')+'<div class="title">'+esc(t)+'<div class="sub">'+esc(s||'')+'</div></div></div></div>';}
 function allQs(){var a=[];collections.forEach(function(c,ci){c.questions.forEach(function(q,qi){a.push({c:ci,i:qi,q:q});});});return a;}
 function stat(){var a=allQs(),sol=0,w=0,b=0; a.forEach(function(x){var id=qid(x.q,x.i);if(state.status[id])sol++;if(state.status[id]==='wrong')w++;if(state.bookmarks[id])b++;});return{total:a.length,solved:sol,wrong:w,bm:b,uns:a.length-sol};}
 function today(){var d=new Date().toISOString().slice(0,10);return state.todayDate===d?(state.todayCount||0):0;}
 function sourceTitle(){return document.title||'QBank';}
 function home(){stop();screen='home';var s=stat(),t=today(),pct=s.total?Math.round(s.solved*100/s.total):0;var list=collections.map(function(c,i){var done=c.questions.filter(function(q,j){return state.status[qid(q,j)]}).length;return"<button class='item' onclick='openCollection("+i+")'><b>"+esc(c.title)+"</b><div class='meta'>"+c.questions.length+" questions • "+done+" solved</div><div class='barline'><i style='width:"+Math.round(done*100/c.questions.length)+"%'></i></div></button>";}).join('');root.innerHTML=header(sourceTitle(),s.total+' questions in this QBank',false)+"<div class='wrap'><div class='card'><div class='h'>Today</div><div class='grid'><button class='stat' onclick='practice(\"today\")'><b>"+t+"</b><span>Questions solved</span></button><button class='stat'><b>"+((today()&&state.todayCorrect)||0)+"</b><span>Correct today</span></button></div></div><div class='card'><div class='h'>Your progress</div><div class='grid'><button class='stat' onclick='practice(\"solved\")'><b>"+s.solved+"</b><span>Solved</span></button><button class='stat' onclick='practice(\"unsolved\")'><b>"+s.uns+"</b><span>Unsolved</span></button><button class='stat' onclick='practice(\"wrong\")'><b>"+s.wrong+"</b><span>Wrong</span></button><button class='stat' onclick='practice(\"bookmarked\")'><b>"+s.bm+"</b><span>Bookmarked</span></button></div><div class='muted' style='margin-top:10px'>Overall completion: "+pct+"%</div><div class='barline'><i style='width:"+pct+"%'></i></div></div><div class='card'><div class='h'>Start studying</div><div class='muted' style='margin-bottom:10px'>The source QBank's original test UI is ignored. You control how you study.</div><div class='actions'><button class='primary' onclick='openPracticeSetup()'>Practice</button><button class='secondary' onclick='openTestSetup()'>Create Test</button></div></div><div class='card'><div class='h'>Smart Practice</div><div class='muted'>Mix unsolved, wrong and bookmarked questions automatically.</div><button class='primary' style='width:100%;margin-top:10px' onclick='smartPractice()'>Start 50-question Smart Session</button></div><div class='card'><div class='h'>Question sources</div><div class='list'>"+(list||"<div class='muted'>No questions detected.</div>")+"</div></div></div>";}
 function openCollection(i){current=i;screen='collection';root.innerHTML=header(collections[i].title,collections[i].questions.length+' questions',true)+'<div class="wrap"><div class="card"><div class="h">How do you want to study?</div><div class="actions"><button class="primary" onclick="startPracticeForCollection()">Practice</button><button class="secondary" onclick="startTestForCollection()">Test</button></div></div><div class="card"><div class="h">Quick filters</div><div class="list"><button class="item" onclick="practice(&quot;unsolved&quot;)">Unsolved <span class="pill">'+countFilter('unsolved')+'</span></button><button class="item" onclick="practice(&quot;wrong&quot;)">Wrong <span class="pill">'+countFilter('wrong')+'</span></button><button class="item" onclick="practice(&quot;bookmarked&quot;)">Bookmarked <span class="pill">'+countFilter('bookmarked')+'</span></button></div></div></div>';}
 function countFilter(f){var n=0,c=collections[current];c.questions.forEach(function(q,i){var id=qid(q,i);if(f==='unsolved'&&!state.status[id])n++;if(f==='wrong'&&state.status[id]==='wrong')n++;if(f==='bookmarked'&&state.bookmarks[id])n++;});return n;}
 function modal(title,body){var d=document.createElement('div');d.className='modal';d.innerHTML='<div class="card"><div class="h">'+title+'</div>'+body+'</div>';document.body.appendChild(d);return d;}
 function openPracticeSetup(){var m=modal('Practice session','<label class="muted">Question pool</label><select id="pool" class="select"><option value="all">All questions</option><option value="unsolved">Unsolved</option><option value="wrong">Wrong</option><option value="bookmarked">Bookmarked</option></select><label class="muted">Number of questions</label><select id="num" class="select"><option>10</option><option>25</option><option>50</option><option>100</option><option>200</option><option>9999</option></select><label><input id="random" type="checkbox" checked> Randomize questions</label><br><label><input id="instant" type="checkbox" checked> Show explanation after answer</label><div class="actions" style="margin-top:14px"><button class="secondary" onclick="this.closest(\'.modal\').remove()">Cancel</button><button class="primary" onclick="launchPractice()">Start Practice</button></div>');}
 function launchPractice(){var pool=document.getElementById('pool').value,n=Number(document.getElementById('num').value),arr=buildPool(pool);if(!arr.length){alert('No questions match this filter.');return;}if(document.getElementById('random').checked)shuffle(arr);arr=arr.slice(0,n);var m=document.querySelector('.modal');if(m)m.remove();startSession(arr,'practice',document.getElementById('instant').checked);}
 function buildPool(pool){var a=[];collections.forEach(function(c,ci){c.questions.forEach(function(q,qi){var id=qid(q,qi),ok=pool==='all'||(pool==='unsolved'&&!state.status[id])||(pool==='wrong'&&state.status[id]==='wrong')||(pool==='bookmarked'&&state.bookmarks[id]);if(ok)a.push({c:ci,i:qi,q:q});});});return a;}
 function smartPractice(){var a=buildPool('wrong').concat(buildPool('bookmarked')).concat(buildPool('unsolved'));var seen={};a=a.filter(function(x){var id=qid(x.q,x.i);if(seen[id])return false;seen[id]=1;return true;});shuffle(a);startSession(a.slice(0,50),'practice',true);}
 function startPracticeForCollection(){var a=collections[current].questions.map(function(q,i){return{c:current,i:i,q:q};});shuffle(a);startSession(a,'practice',true);}
 function openTestSetup(){var m=modal('Create Test','<label class="muted">Questions</label><select id="tnum" class="select"><option>25</option><option>50</option><option>100</option><option>150</option><option>200</option></select><label class="muted">Pool</label><select id="tpool" class="select"><option value="all">All</option><option value="unsolved">Unsolved</option><option value="wrong">Wrong</option><option value="bookmarked">Bookmarked</option></select><label class="muted">Time (minutes)</label><input id="tmin" class="select" type="number" value="60" min="1"><label><input id="neg" type="checkbox"> Negative marking (−1/4)</label><div class="actions" style="margin-top:14px"><button class="secondary" onclick="this.closest(\'.modal\').remove()">Cancel</button><button class="primary" onclick="launchTest()">Start Test</button></div>');}
 function launchTest(){var a=buildPool(document.getElementById('tpool').value);if(!a.length){alert('No questions match this filter.');return;}shuffle(a);a=a.slice(0,Number(document.getElementById('tnum').value));var mins=Math.max(1,Number(document.getElementById('tmin').value)||60),neg=document.getElementById('neg').checked;document.querySelector('.modal').remove();startSession(a,'test',false,mins*60,neg);}
 function startTestForCollection(){var a=collections[current].questions.map(function(q,i){return{c:current,i:i,q:q};});shuffle(a);var mins=Number(collections[current].duration||60);startSession(a,'test',false,mins*60,false);}
 function shuffle(a){for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),x=a[i];a[i]=a[j];a[j]=x;}}
 function startSession(arr,type,instant,secs,neg){if(!arr.length)return;test={arr:arr,type:type,instant:instant,neg:!!neg,answers:{},review:{},start:Date.now()};index=0;remaining=secs||0;screen=type;renderSession();if(type==='test')startTimer();}
 function renderSession(){var x=test.arr[index],q=x.q,id=qid(q,x.i),sel=test.answers[id],cor=correct(q),os=opts(q),answered=sel!=null,show=test.type==='practice'&&answered&&test.instant;var optsHtml=os.map(function(o){var l=String(o.label).toUpperCase(),cl='opt';if(sel===l)cl+=' selected';if(show&&l===cor)cl+=' correct';if(show&&sel===l&&l!==cor)cl+=' wrong';var safeId=esc(id).replace(/'/g,"\\'");var safeL=esc(l).replace(/'/g,"\\'");return"<button class='"+cl+"' "+(answered?'disabled':'')+" onclick='answerSession(\\\""+safeId+"\\\",\\\""+safeL+"\\\")'><b>"+esc(l)+".</b> "+html(o.text)+"</button>";}).join('');var imgs=qimgs(q).map(function(u){return'<img src="'+esc(u)+'" loading="lazy">';}).join('');var expHtml=show?'<div class="exp"><b>Explanation</b><div>'+html(exp(q)||'No explanation available')+'</div>'+expimgs(q).map(function(u){return'<img src="'+esc(u)+'">';}).join('')+'</div>':'';root.innerHTML=header(test.type==='test'?'Test Mode':'Practice Mode',(index+1)+' / '+test.arr.length,true)+'<div class="wrap"><div class="card"><div class="testbar"><span>'+esc(collections[x.c].title)+'</span>'+(test.type==='test'?'<span class="timer" id="timer">'+fmt(remaining)+'</span>':'<span class="pill">'+(answered?'Answered':'Choose one')+'</span>')+'</div><div class="q">'+html(qtext(q))+'</div>'+imgs+'<div class="options">'+optsHtml+'</div>'+(answered&&test.type==='practice'&&!test.instant?'<div class="result '+(sel===cor?'ok':'bad')+'">'+(sel===cor?'✓ Correct':'✗ Wrong')+' • Correct answer: '+esc(cor||'Not specified')+'</div>':'')+expHtml+'<div class="actions" style="margin-top:14px"><button class="secondary" onclick="prevSession()">Previous</button><button class="secondary" onclick="toggleReview()">'+(test.review[id]?'★ Reviewed':'Mark for review')+'</button></div><div class="nav"><button class="secondary" onclick="nextSession()">'+(index===test.arr.length-1?(test.type==='test'?'Submit Test':'Finish'):'Next')+'</button><button class="secondary" onclick="sessionMap()">Question Map</button><button class="primary" onclick="finishSession()">End</button></div></div></div>';
 }
 function answerSession(id,l){if(test.answers[id]!=null)return;test.answers[id]=l;record(id,l===correct(test.arr[index].q));renderSession();}
 function record(id,isCorrect){var d=new Date(),day=d.toISOString().slice(0,10);state.selected[id]=test.answers[id];state.status[id]=isCorrect?'correct':'wrong';if(state.todayDate!==day){state.todayDate=day;state.todayCount=0;state.todayCorrect=0;}state.todayCount++;if(isCorrect)state.todayCorrect=(state.todayCorrect||0)+1;state.lastAnswerDate[id]=day;save();}
 function prevSession(){if(index>0){index--;renderSession();}}
 function nextSession(){if(index===test.arr.length-1){finishSession();return;}index++;renderSession();}
 function toggleReview(){var id=qid(test.arr[index].q,test.arr[index].i);test.review[id]=!test.review[id];renderSession();}
 function sessionMap(){var m=modal('Question Map','<div class="nums">'+test.arr.map(function(x,i){var id=qid(x.q,x.i),cl='';if(test.answers[id]!=null)cl+=' done';if(test.review[id])cl+=' review';return'<button class="'+cl+'" onclick="jumpSession('+i+');this.closest(\'.modal\').remove()">'+(i+1)+'</button>';}).join('')+'</div><button class="primary" style="width:100%;margin-top:14px" onclick="this.closest(\'.modal\').remove()">Close</button>');}
 function jumpSession(i){index=i;renderSession();}
 function finishSession(){stop();if(!test)return;var total=test.arr.length,answered=Object.keys(test.answers).length,correctN=0;test.arr.forEach(function(x){var id=qid(x.q,x.i);if(test.answers[id]===correct(x.q))correctN++;});var wrong=answered-correctN,un=total-answered,score=test.type==='test'?(test.neg?correctN-wrong*.25:correctN):correctN;var old=test;test=null;screen='result';root.innerHTML=header('Session Result',total+' questions',true)+'<div class="wrap"><div class="card"><div class="h">'+(old.type==='test'?'Test Result':'Practice Complete')+'</div><div class="grid"><div class="stat"><b>'+score+'</b><span>Score</span></div><div class="stat"><b>'+correctN+'</b><span>Correct</span></div><div class="stat"><b>'+wrong+'</b><span>Wrong</span></div><div class="stat"><b>'+un+'</b><span>Unattempted</span></div></div><div class="muted" style="margin-top:12px">Accuracy: '+(answered?Math.round(correctN*100/answered):0)+'%</div><div class="actions" style="margin-top:14px"><button class="secondary" onclick="home()">Home</button><button class="primary" onclick="reviewResult()">Review Questions</button></div></div></div>';window._lastSession=old;}
 function reviewResult(){var old=window._lastSession;if(!old)return;test=old;index=0;test.type='practice';test.instant=true;renderSession();}
 function fmt(s){s=Math.max(0,Math.floor(s||0));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
 function startTimer(){stop();timer=setInterval(function(){remaining--;var e=document.getElementById('timer');if(e)e.textContent=fmt(remaining);if(remaining<=0){alert('Time is up. Submitting the test.');finishSession();}},1000);}
 function stop(){if(timer){clearInterval(timer);timer=null;}}
 function goBack(){stop();if(test){test=null;home();}else home();return true;}window.__localQbankGoBack=goBack;
 if(mode==='unknown'||!collections.length){root.innerHTML=header('QBank Pro','No question data detected',false)+'<div class="wrap"><div class="card">This HTML format was not recognized. The adaptive importer can be extended without changing the app UI.</div></div>';}else home();
})();
"""
    }
}
