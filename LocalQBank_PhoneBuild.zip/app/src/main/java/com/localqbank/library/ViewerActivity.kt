package com.localqbank.library

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class ViewerActivity:AppCompatActivity(){
    private lateinit var web:WebView
    private lateinit var id:String
    private val db by lazy{getSharedPreferences("native_progress",MODE_PRIVATE)}
    private val prefix="corebtr_neetpg_"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        id=intent.getStringExtra("id")?:"unknown"
        val uri=intent.getStringExtra("uri")?:return
        web=WebView(this);setContentView(web)

        web.settings.javaScriptEnabled=true
        web.settings.domStorageEnabled=true
        web.settings.databaseEnabled=true
        web.settings.allowFileAccess=true
        web.settings.allowContentAccess=true
        web.settings.loadsImagesAutomatically=true
        web.settings.builtInZoomControls=false
        web.settings.displayZoomControls=false
        web.webChromeClient=WebChromeClient()
        web.addJavascriptInterface(Bridge(),"LocalQBank")

        web.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest)=false
            override fun onPageFinished(v:WebView,url:String?){
                super.onPageFinished(v,url)
                syncCoreBtrFromNative()
                installAutoSync()
            }
        }
        web.loadUrl(uri)
    }

    // The supplied CoreBTR HTML uses:
    // corebtr_neetpg_prog, corebtr_neetpg_bm and corebtr_neetpg_mistakes.
    // We mirror these JSON blobs into Android SharedPreferences, namespaced by QBank id.
    private fun syncCoreBtrFromNative(){
        val keys=arrayOf("prog","bm","mistakes","theme")
        val js="""(function(){
            var r={};
            ${keys.joinToString("\n"){ "r['$it']=localStorage.getItem('${prefix}$it')||'';" }}
            return JSON.stringify(r);
        })();"""
        web.evaluateJavascript(js){raw->
            val json=decodeJsString(raw) ?: return@evaluateJavascript
            try{
                val o=JSONObject(json)
                for(k in keys) if(o.has(k) && o.getString(k).isNotEmpty())
                    db.edit().putString("${id}_$k",o.getString(k)).apply()
            }catch(_:Exception){}
        }
    }

    private fun installAutoSync(){
        val js="""(function(){
            if(window.__localQbankSyncInstalled)return;
            window.__localQbankSyncInstalled=true;
            setInterval(function(){
                try{
                    var r={prog:localStorage.getItem('${prefix}prog')||'',
                           bm:localStorage.getItem('${prefix}bm')||'',
                           mistakes:localStorage.getItem('${prefix}mistakes')||'',
                           theme:localStorage.getItem('${prefix}theme')||''};
                    if(window.LocalQBank) LocalQBank.saveSnapshot(JSON.stringify(r));
                }catch(e){}
            },3000);
        })();"""
        web.evaluateJavascript(js,null)
    }

    private fun decodeJsString(raw:String):String?{
        if(raw=="null")return null
        return try{
            // evaluateJavascript returns a JSON-quoted JS string.
            val t=raw.removePrefix("\"").removeSuffix("\"")
                .replace("\\\"","\"").replace("\\\\","\\")
                .replace("\\n","\n").replace("\\r","\r")
            t
        }catch(_:Exception){null}
    }

    inner class Bridge{
        @JavascriptInterface fun saveSnapshot(json:String){db.edit().putString("${id}_snapshot",json).apply()}
        @JavascriptInterface fun getSnapshot():String=db.getString("${id}_snapshot","")?:""
    }

    override fun onDestroy(){
        try{syncCoreBtrFromNative()}catch(_:Exception){}
        web.destroy();super.onDestroy()
    }
    override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}
}
