package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class SearchActivity: AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var searchBox: EditText
    private lateinit var results: RecyclerView
    private lateinit var empty: TextView
    private val rows=mutableListOf<SearchRow>()
    private val executor=Executors.newSingleThreadExecutor()
    private var searchSerial=0L
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(b:Bundle?) { super.onCreate(b); SystemUi.immersive(this); db=QBankDb(this); setContentView(build()); searchBox.requestFocus(); searchBox.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox,InputMethodManager.SHOW_IMPLICIT) } }
    private fun build():View {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@SearchActivity))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(8),dp(12),dp(8));setBackgroundColor(if(ThemeManager.get(this@SearchActivity)==ThemeManager.DARK)Color.rgb(18,31,45) else Color.rgb(22,72,112))}
        val back=TextView(this).apply{text="←";textSize=23f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(if(ThemeManager.get(this@SearchActivity)==ThemeManager.DARK)Color.rgb(31,43,58) else Color.rgb(28,70,103));cornerRadius=12f*resources.displayMetrics.density};setOnClickListener{finish()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(56),dp(56)).apply{setMargins(0,0,dp(8),0)})
        val title=TextView(this).apply{text="Search QBank";textSize=20f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)}
        bar.addView(title,LinearLayout.LayoutParams(0,-2,1f)); root.addView(bar)
        val input=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(6))}
        searchBox=EditText(this).apply{hint="Questions, options, sections, subsections…";textSize=16f;setSingleLine(true);setTextColor(ThemeManager.text(this@SearchActivity));setHintTextColor(ThemeManager.muted(this@SearchActivity));setBackground(rounded(ThemeManager.elevated(this@SearchActivity),16f));setPadding(dp(14),0,dp(10),0)}
        input.addView(searchBox,LinearLayout.LayoutParams(0,dp(52),1f));root.addView(input)
        val hint=TextView(this).apply{text="Searches QBank names, headlines/subsections, question text, options and explanations";textSize=12f;setTextColor(ThemeManager.muted(this@SearchActivity));setPadding(dp(16),0,dp(16),dp(8))};root.addView(hint)
        results=RecyclerView(this).apply{layoutManager=LinearLayoutManager(this@SearchActivity);adapter=SearchAdapter(rows){row->open(row)};itemAnimator=null}
        root.addView(results,LinearLayout.LayoutParams(-1,0,1f))
        empty=TextView(this).apply{text="Start typing to search your QBanks";textSize=16f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@SearchActivity))};root.addView(empty,LinearLayout.LayoutParams(-1,0,1f));results.visibility=View.GONE
        searchBox.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){runSearch(s?.toString() ?: "")};override fun afterTextChanged(e:android.text.Editable?) {}})
        return root
    }
    private fun rounded(c:Int,r:Float)=android.graphics.drawable.GradientDrawable().apply{setColor(c);cornerRadius=r*resources.displayMetrics.density}
    private fun runSearch(q:String){
        val text=q.trim(); val serial=++searchSerial
        if(text.isBlank()){rows.clear();results.visibility=View.GONE;empty.visibility=View.VISIBLE;empty.text="Start typing to search your QBanks";return}
        executor.execute {
            val found=mutableListOf<SearchRow>()
            db.searchSections(text).forEach{found.add(SearchRow.Section(it))}
            db.search(text).forEach{found.add(SearchRow.Question(it))}
            runOnUiThread {
                if(isFinishing || serial!=searchSerial) return@runOnUiThread
                rows.clear();rows.addAll(found);results.visibility=View.VISIBLE;empty.visibility=if(rows.isEmpty())View.VISIBLE else View.GONE;empty.text=if(rows.isEmpty())"No matching sections or questions" else "";results.adapter?.notifyDataSetChanged()
            }
        }
    }
    private fun open(row:SearchRow){when(row){is SearchRow.Section->{startActivity(Intent(this,QuizActivity::class.java).putExtra("testId",row.x.testId).putExtra("title",row.x.title).putExtra("position",0).putExtra("sectionLabel",row.x.title).putExtra("practiceMode",true))};is SearchRow.Question->{startActivity(Intent(this,QuizActivity::class.java).putExtra("testId",row.x.testId).putExtra("title",row.x.testTitle).putExtra("position",row.x.position).putExtra("sectionLabel",row.x.path ?: row.x.testTitle))}}}
    override fun onDestroy(){executor.shutdownNow();db.close();super.onDestroy()}
}

sealed class SearchRow { data class Section(val x:SectionHit):SearchRow(); data class Question(val x:SearchHit):SearchRow() }

class SearchAdapter(private val items:List<SearchRow>,private val click:(SearchRow)->Unit):RecyclerView.Adapter<SearchAdapter.VH>(){
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){val tag=TextView(v.context);val title=TextView(v.context);val sub=TextView(v.context);init{v.orientation=LinearLayout.VERTICAL;v.setPadding(16,14,16,14);v.addView(tag);v.addView(title);v.addView(sub)}}
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{val v=LinearLayout(p.context);v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(10,5,10,5)};return VH(v)}
    override fun onBindViewHolder(h:VH,i:Int){val row=items[i];val dark=ThemeManager.get(h.itemView.context)==ThemeManager.DARK;h.itemView.background=GradientDrawable().apply{setColor(if(dark)ThemeManager.elevated(h.itemView.context) else Color.rgb(247,250,253));cornerRadius=16f*h.itemView.context.resources.displayMetrics.density};when(row){is SearchRow.Section->{h.tag.text="SECTION / SUBSECTION";h.title.text=row.x.title;h.sub.text="${row.x.sourceName}  •  ${row.x.count} questions${if(row.x.path.isBlank())"" else "  •  "+row.x.path}"};is SearchRow.Question->{h.tag.text="QUESTION";h.title.text="Q${row.x.position+1}. "+Html.fromHtml(row.x.text,Html.FROM_HTML_MODE_LEGACY).toString().trim().take(220);h.sub.text="${row.x.sourceName}  •  ${row.x.testTitle}${if(row.x.path.isNullOrBlank())"" else "  •  "+row.x.path}"}};h.tag.textSize=11f;h.tag.setTypeface(null,Typeface.BOLD);h.tag.setTextColor(ThemeManager.accent(h.itemView.context));h.title.textSize=15f;h.title.setTextColor(ThemeManager.text(h.itemView.context));h.sub.textSize=12f;h.sub.setTextColor(ThemeManager.muted(h.itemView.context));h.title.setPadding(0,4,0,0);h.sub.setPadding(0,5,0,0);h.itemView.setOnClickListener{click(row)}}
    override fun getItemCount()=items.size
}
