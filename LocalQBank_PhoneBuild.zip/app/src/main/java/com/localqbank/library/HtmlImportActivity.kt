package com.localqbank.library

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.View
import java.io.*
import java.nio.charset.Charset
import java.util.LinkedHashMap
import java.util.regex.Pattern

class HtmlImportActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var web: WebView
    private val files = mutableListOf<Uri>()
    private var index = 0
    private lateinit var db: QBankDb

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        db = QBankDb(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        val title = TextView(this).apply { text = "Import HTML QBank"; textSize = 22f }
        SystemUi.padTopInset(title, 18, 8, 0, 0)
        root.addView(title)
        status = TextView(this).apply { setPadding(0, 12, 0, 12) }
        root.addView(status)
        val frame = FrameLayout(this)
        web = WebView(this).apply { layoutParams = FrameLayout.LayoutParams(1, 1) }
        frame.addView(web)
        progress = ProgressBar(this).apply { isIndeterminate = true }
        frame.addView(progress, FrameLayout.LayoutParams(56, 56, Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val incoming = intent.getParcelableArrayListExtra<Uri>("uris")
        if (incoming != null) files.addAll(incoming)
        if (files.isEmpty()) { finish(); return }
        configureWeb()
        processNext()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWeb() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.addJavascriptInterface(Bridge(), "AndroidImport")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { v?.evaluateJavascript(EXTRACT_JS, null) }
        }
    }

    private fun processNext() {
        if (index >= files.size) {
            progress.visibility = View.GONE
            status.text = "Import complete"
            Toast.makeText(this, "Imported ${files.size} HTML file(s)", Toast.LENGTH_LONG).show()
            setResult(RESULT_OK)
            finish()
            return
        }
        val uri = files[index]
        val size = fileSize(uri)
        progress.visibility = View.VISIBLE
        status.text = "Preparing ${index + 1}/${files.size}…"
        Thread {
            try {
                if (size >= LARGE_FILE_LIMIT) {
                    importLargeFile(uri, size)
                } else {
                    // Do not copy a normal file into a giant String on the UI thread.
                    val text = readSmall(uri)
                    runOnUiThread {
                        if (!isFinishing) {
                            status.text = "Extracting ${index + 1}/${files.size}…"
                            web.loadDataWithBaseURL(uri.toString(), text, "text/html", "UTF-8", null)
                        }
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.text = "Import failed: ${e.message ?: "unknown error"}"
                    Toast.makeText(this, e.message ?: "Import failed", Toast.LENGTH_LONG).show()
                    index++
                    processNext()
                }
            }
        }.start()
    }

    private fun importLargeFile(uri: Uri, size: Long) {
        runOnUiThread { status.text = "Large file (${formatMb(size)} MB) — importing without loading it into memory…" }
        val tmp = File(cacheDir, "q_import_${System.currentTimeMillis()}.html")
        copyToFile(uri, tmp) { done -> runOnUiThread { if (!isFinishing) status.text = "Reading large file… ${done}%" } }
        val session = db.beginStreamingImport(displayName(uri), "HTML QBank")
        var imported = 0
        try {
            LargeHtmlScanner(tmp) { section, q ->
                session.addQuestion(section, q)
                imported++
                if (imported % 50 == 0) runOnUiThread { if (!isFinishing) status.text = "Imported $imported questions…" }
            }.scan()
            session.finish(true)
            runOnUiThread {
                status.text = "Imported $imported questions"
                index++
                processNext()
            }
        } catch (t: Throwable) {
            session.finish(false)
            throw t
        } finally {
            tmp.delete()
        }
    }

    private fun fileSize(uri: Uri): Long {
        try { contentResolver.openFileDescriptor(uri, "r")?.use { if (it.statSize > 0) return it.statSize } } catch (_: Throwable) {}
        return 0L
    }

    private fun displayName(uri: Uri): String {
        var name: String? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        return name ?: uri.lastPathSegment ?: "Imported QBank.html"
    }

    private fun readSmall(uri: Uri): String {
        contentResolver.openInputStream(uri)?.use { input ->
            val out = StringBuilder()
            val reader = InputStreamReader(input, Charsets.UTF_8)
            val buf = CharArray(32768)
            while (true) { val n = reader.read(buf); if (n < 0) break; out.append(buf, 0, n) }
            return out.toString()
        } ?: error("Cannot open $uri")
    }

    private fun copyToFile(uri: Uri, dest: File, onProgress: (Int) -> Unit) {
        val total = fileSize(uri)
        var done = 0L
        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    if (total > 0) onProgress(((done * 100) / total).toInt().coerceIn(0, 100))
                }
                out.fd.sync()
            }
        } ?: error("Cannot open $uri")
    }

    private fun formatMb(v: Long) = String.format(java.util.Locale.US, "%.0f", v / 1048576.0)

    inner class Bridge {
        @JavascriptInterface
        fun receive(json: String) {
            runOnUiThread {
                try {
                    val root = org.json.JSONObject(json)
                    val tests = parseTests(root.optJSONArray("tests") ?: org.json.JSONArray())
                    val name = root.optString("fileName", "Imported QBank.html")
                    val provider = detectProvider(tests)
                    if (tests.isEmpty()) throw IllegalArgumentException("No QBank sections/questions detected in $name.")
                    val n = db.importBundle(name, provider, tests)
                    status.text = "Imported $n questions"
                    index++
                    web.stopLoading()
                    processNext()
                } catch (e: Exception) {
                    status.text = "Import failed: ${e.message}"
                    Toast.makeText(this@HtmlImportActivity, e.message ?: "Import failed", Toast.LENGTH_LONG).show()
                    index++
                    processNext()
                }
            }
        }
    }

    private fun detectProvider(t: List<ImportedTest>) = when {
        t.any { it.title.contains("DAMS", true) } -> "DAMS"
        t.any { it.title.contains("BTR", true) } -> "BTR"
        t.any { it.title.contains("Mini Tests", true) } -> "DocTutorials"
        else -> "HTML QBank"
    }

    private fun parseTests(a: org.json.JSONArray): List<ImportedTest> {
        val out = mutableListOf<ImportedTest>()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i)
            val qa = t.optJSONArray("questions") ?: org.json.JSONArray()
            val qs = mutableListOf<ImportedQuestion>()
            for (j in 0 until qa.length()) {
                val q = qa.getJSONObject(j)
                val oa = q.optJSONArray("options") ?: org.json.JSONArray()
                val opts = mutableListOf<ImportedOption>()
                for (k in 0 until oa.length()) {
                    val o = oa.getJSONObject(k)
                    opts.add(ImportedOption(o.optString("label", "${'A'.code + k}"), o.optString("text", ""), o.optBoolean("correct", false)))
                }
                qs.add(ImportedQuestion(q.optStringOrNull("id"), q.optString("text", q.optString("raw_text", "")), q.optStringOrNull("raw_text"), q.optStringOrNull("correct_answer"), q.optStringOrNull("explanation"), q.optStringOrNull("bot"), q.optStringOrNull("video"), q.optStringOrNull("audio"), opts, jsonArray(q, "question_images"), jsonArray(q, "explanation_images")))
            }
            out.add(ImportedTest(t.optStringOrNull("id"), t.optString("title", "Section ${i + 1}"), t.optStringOrNull("path"), t.optDouble("total_marks", 0.0), t.optInt("duration", 0), t.optDouble("time_per_question", 0.0), qs))
        }
        return out
    }

    private fun jsonArray(o: org.json.JSONObject, k: String): List<String> { val a = o.optJSONArray(k) ?: return emptyList(); return buildList { for (i in 0 until a.length()) add(a.optString(i)) } }
    private fun org.json.JSONObject.optStringOrNull(k: String): String? = if (!has(k) || isNull(k)) null else optString(k, null)

    private class LargeHtmlScanner(private val file: File, private val onQuestion: (String, ImportedQuestion) -> Unit) {
        private val keys = listOf("\"question\"", "\"question_text\"", "\"questionText\"", "\"stem\"")
        private val charset: Charset = Charsets.UTF_8
        private val maxObject = 1024 * 1024
        private val seen = HashSet<String>()

        fun scan() {
            RandomAccessFile(file, "r").use { raf ->
                val buf = ByteArray(256 * 1024)
                var base = 0L
                var carry = ""
                while (true) {
                    val n = raf.read(buf); if (n <= 0) break
                    val text = carry + String(buf, 0, n, charset)
                    var from = 0
                    while (true) {
                        val hit = findKey(text, from)
                        if (hit < 0) break
                        val brace = text.lastIndexOf('{', hit)
                        if (brace >= 0) {
                            val absolute = base - carry.toByteArray(charset).size + brace
                            if (absolute >= 0) {
                                val obj = readBalanced(raf, absolute)
                                if (obj != null && obj.length <= maxObject) parseCandidate(obj)
                            }
                        }
                        from = hit + 8
                    }
                    carry = text.takeLast(256 * 1024)
                    base += n
                }
            }
        }

        private fun findKey(s: String, from: Int): Int = keys.map { s.indexOf(it, from, true) }.filter { it >= 0 }.minOrNull() ?: -1
        private fun readBalanced(raf: RandomAccessFile, start: Long): String? {
            raf.seek(start)
            val out = ByteArrayOutputStream()
            var depth = 0; var quote = 0; var escape = false; var started = false
            while (out.size() < maxObject) {
                val b = raf.read(); if (b < 0) return null
                out.write(b)
                val c = b.toChar()
                if (quote != 0) { if (escape) escape = false else if (c == '\\') escape = true else if (c.code == quote) quote = 0; continue }
                if (c == '"' || c == '\'') { quote = c.code; continue }
                if (c == '{') { depth++; started = true }
                else if (c == '}') { depth--; if (started && depth == 0) return out.toString("UTF-8") }
            }
            return null
        }

        private fun parseCandidate(src: String) {
            try {
                val o = org.json.JSONObject(src)
                val q = normalize(o) ?: return
                val key = (q.sourceId ?: "") + "|" + q.text.take(160)
                if (seen.add(key)) onQuestion(section(o), q)
            } catch (_: Throwable) { }
        }

        private fun section(o: org.json.JSONObject): String {
            val candidates = arrayOf("section", "topic", "subject", "chapter", "lesson", "category", "title")
            for (k in candidates) { val v = o.optString(k, "").trim(); if (v.isNotBlank() && v.length < 100) return v }
            return "DAMS PYQ"
        }

        private fun normalize(q: org.json.JSONObject): ImportedQuestion? {
            val text = clean(q.opt("text") ?: q.opt("question") ?: q.opt("stem") ?: q.opt("question_text") ?: "")
            val options = q.opt("options") ?: q.opt("choices") ?: q.opt("answers")
            val opts = mutableListOf<ImportedOption>()
            if (options is org.json.JSONArray) for (i in 0 until options.length()) {
                val x = options.opt(i)
                if (x is org.json.JSONObject) opts.add(ImportedOption(x.optString("label", "${'A'.code + i}"), clean(x.opt("text") ?: x.opt("value") ?: x.opt("option") ?: ""), x.optBoolean("correct", false) || x.optBoolean("is_correct", false)))
                else opts.add(ImportedOption("${'A'.code + i}", clean(x), false))
            } else if (options is org.json.JSONObject) {
                for (k in options.keys()) opts.add(ImportedOption(k, clean(options.opt(k)), false))
            }
            val ans = q.optString("correct_answer", q.optString("answer", q.optString("ans", ""))).ifBlank { null }
            val ex = clean(q.opt("explanation") ?: q.opt("solution") ?: q.opt("expl") ?: "")
            val imgs = extractImages(text + " " + clean(q.opt("image") ?: q.opt("images") ?: q.opt("questionImage") ?: ""))
            val exImgs = extractImages(ex + " " + clean(q.opt("explanation_images") ?: ""))
            if (text.isBlank() || opts.isEmpty()) return null
            return ImportedQuestion(q.optString("id", q.optString("question_id", null)), text, text, ans, ex.ifBlank { null }, q.optString("bot", null), q.optString("video", null), q.optString("audio", null), opts, imgs, exImgs)
        }

        private fun clean(v: Any?): String = when (v) { null -> ""; is String -> v; else -> v.toString() }
        private fun extractImages(s: String): List<String> {
            val out = LinkedHashMap<String, Boolean>()
            val p = Pattern.compile("<img[^>]+(?:src|data-src|data-original)=[\\\"']([^\\\"']+)[\\\"']", Pattern.CASE_INSENSITIVE)
            val m = p.matcher(s); while (m.find()) out[m.group(1)] = true
            if (s.trim().startsWith("data:image")) out[s.trim()] = true
            return out.keys.toList()
        }
    }

    companion object {
        private const val LARGE_FILE_LIMIT = 40L * 1024L * 1024L
        const val EXTRACT_JS = """
(function(){
 function balanced(s,start){let d=0,q=null,e=false;for(let i=start;i<s.length;i++){let c=s[i];if(q){if(e)e=false;else if(c==='\\\\')e=true;else if(c===q)q=null;continue;}if(c==='"'||c==="'")q=c;else if(c==='['||c==='{')d++;else if(c===']'||c==='}')if(--d===0)return s.slice(start,i+1);}return null;}
 function clean(v){if(v==null)return '';if(typeof v==='string')return v;try{return JSON.stringify(v)}catch(e){return String(v)}}
 function img(v){let x=clean(v).trim();if(!x)return '';if(x.startsWith('data:image'))return x;try{return new URL(x,document.baseURI).href}catch(e){return x}}
 function imgs(v){let out=[];if(Array.isArray(v))v.forEach(x=>{let u=img(x);if(u)out.push(u)});else if(typeof v==='string'){let re=/<img[^>]+(?:src|data-src|data-original)=["']([^"']+)["']/ig,m;while((m=re.exec(v)))out.push(img(m[1]));}return [...new Set(out)]}
 function qlike(o){return o&&typeof o==='object'&&(o.text!=null||o.question!=null||o.stem!=null)&&(o.options!=null||o.choices!=null||o.answer!=null||o.ans!=null||o.explanation!=null||o.expl!=null)}
 function normQ(q){let src=clean(q.text??q.question??q.stem??q.question_text??'');let opts=[];let os=q.options??q.choices??q.answers??{};if(Array.isArray(os))os.forEach((o,i)=>opts.push({label:o.label??o.key??String.fromCharCode(65+i),text:clean(o.text??o.value??o.option??o),correct:!!(o.correct??o.is_correct)}));else if(os&&typeof os==='object')Object.keys(os).forEach(k=>opts.push({label:k,text:clean(os[k]),correct:false}));let ans=q.correct_answer??q.answer??q.ans??q.correct??null;if(typeof ans==='object')ans=null;let ex=clean(q.explanation??q.solution??q.expl??q.exp??'');return{id:q.id??q.question_id??null,text:src,raw_text:src,correct_answer:ans,explanation:ex,bot:clean(q.bot??''),video:clean(q.video??''),audio:clean(q.audio??''),options:opts,question_images:imgs(q.question_images??q.images??q.img??q.image??q.questionImage??'').concat(imgs(src)),explanation_images:imgs(q.explanation_images??q.explanationImage??'').concat(imgs(ex))}}
 let found=[],seen=new Set();function walk(v,path){if(!v)return;if(Array.isArray(v)){let qs=v.filter(qlike);if(qs.length){let title=(path.filter(Boolean).slice(-1)[0]||'Imported Section');let key=title+'|'+qs.map(x=>x.id||x.text).join('|').slice(0,200);if(!seen.has(key)){seen.add(key);found.push({title:title,questions:qs.map(normQ)})}}v.forEach(x=>walk(x,path));return}if(typeof v==='object'){let title=v.title??v.name??v.subject??v.lesson??v.section??null;let next=title?[...path,String(title)]:path;Object.keys(v).forEach(k=>{if(!['options','choices','answers'].includes(k))walk(v[k],next)})}}
 function extract(src){let re=/(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*/g,m;while((m=re.exec(src))){let ex=balanced(src,m.index+m[0].length);if(!ex)continue;try{let v=Function('return ('+ex+')')();walk(v,[m[1]])}catch(e){}}}
 document.querySelectorAll('script').forEach(s=>extract(s.textContent||''));document.querySelectorAll('iframe').forEach(f=>{let h=f.getAttribute('srcdoc');if(h){let d=new DOMParser().parseFromString(h,'text/html');d.querySelectorAll('script').forEach(s=>extract(s.textContent||''))}});AndroidImport.receive(JSON.stringify({fileName:(document.title||'Imported QBank.html').trim(),tests:found.filter(t=>t.questions.length)}));
})();"""
    }
}
