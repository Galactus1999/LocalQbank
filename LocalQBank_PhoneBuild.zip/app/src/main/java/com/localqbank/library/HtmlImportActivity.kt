package com.localqbank.library

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class HtmlImportActivity:Activity(){
    private lateinit var status:TextView
    private lateinit var web:WebView
    private val files=mutableListOf<Uri>(); private var index=0; private lateinit var db:QBankDb
    override fun onCreate(b:Bundle?){super.onCreate(b);db=QBankDb(this);val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(18,18,18,18);val title=TextView(this);title.text="Import HTML QBank";title.textSize=22f;root.addView(title);status=TextView(this);status.text="Preparing…";status.setPadding(0,12,0,12);root.addView(status);web=WebView(this);web.layoutParams=LinearLayout.LayoutParams(1,1);root.addView(web);setContentView(root);val incoming=intent.getParcelableArrayListExtra<Uri>("uris");if(incoming!=null)files.addAll(incoming); if(files.isEmpty()){finish();return};configureWeb();processNext()}
    @SuppressLint("SetJavaScriptEnabled") private fun configureWeb(){web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.allowFileAccess=true;web.settings.allowContentAccess=true;web.addJavascriptInterface(Bridge(),"AndroidImport");web.webViewClient=object:WebViewClient(){override fun onPageFinished(v:WebView?,url:String?){v?.evaluateJavascript(EXTRACT_JS,null)}}}
    private fun processNext(){if(index>=files.size){status.text="Import complete";Toast.makeText(this,"Imported ${files.size} HTML file(s)",Toast.LENGTH_LONG).show();setResult(RESULT_OK);finish();return};val uri=files[index];status.text="Importing ${index+1}/${files.size}: ${uri.lastPathSegment ?: "HTML file"}";val html=read(uri);val base=uri.toString();web.loadDataWithBaseURL(base,html,"text/html","UTF-8",null)}
    private fun read(uri:Uri):String{val input=contentResolver.openInputStream(uri) ?: error("Cannot open $uri");return input.use{val out=ByteArrayOutputStream();it.copyTo(out);out.toString(Charsets.UTF_8.name())}}
    inner class Bridge{@JavascriptInterface fun receive(json:String){runOnUiThread{try{val root=JSONObject(json);val tests=parseTests(root.optJSONArray("tests")?:JSONArray());val name=root.optString("fileName","Imported QBank.html");val provider=detectProvider(tests);val n=db.importBundle(name,provider,tests);status.text="Imported $n questions";index++;web.stopLoading();processNext()}catch(e:Exception){status.text="Import failed: ${e.message}";Toast.makeText(this@HtmlImportActivity,e.message ?: "Import failed",Toast.LENGTH_LONG).show();index++;processNext()}}}}
    private fun detectProvider(t:List<ImportedTest>)=when{t.any{it.title.contains("Mini Tests",true)}->"DocTutorials";t.any{it.title.contains("DAMS",true)}->"DAMS";else->"HTML QBank"}
    private fun parseTests(a:JSONArray):List<ImportedTest>{val out=mutableListOf<ImportedTest>();for(i in 0 until a.length()){val t=a.getJSONObject(i);val qa=t.optJSONArray("questions")?:JSONArray();val qs=mutableListOf<ImportedQuestion>();for(j in 0 until qa.length()){val q=qa.getJSONObject(j);val oa=q.optJSONArray("options")?:JSONArray();val opts=mutableListOf<ImportedOption>();for(k in 0 until oa.length()){val o=oa.getJSONObject(k);opts.add(ImportedOption(o.optString("label","${'A'.code+k}"),o.optString("text",""),o.optBoolean("correct",false)))};qs.add(ImportedQuestion(q.optStringOrNull("id"),q.optString("text",q.optString("raw_text","")),q.optStringOrNull("raw_text"),q.optStringOrNull("correct_answer"),q.optStringOrNull("explanation"),q.optStringOrNull("bot"),q.optStringOrNull("video"),q.optStringOrNull("audio"),opts,jsonArray(q,"question_images"),jsonArray(q,"explanation_images")))};out.add(ImportedTest(t.optStringOrNull("id"),t.optString("title","Section ${i+1}"),t.optStringOrNull("path"),t.optDouble("total_marks",0.0),t.optInt("duration",0),t.optDouble("time_per_question",0.0),qs))};return out}
    private fun jsonArray(o:JSONObject,k:String):List<String>{val a=o.optJSONArray(k)?:return emptyList();return buildList{for(i in 0 until a.length())add(a.optString(i))}}
    private fun JSONObject.optStringOrNull(k:String):String?=if(!has(k)||isNull(k))null else optString(k,null)
    companion object{const val EXTRACT_JS="""
(function(){
 function balanced(s,start){let d=0,q=null,e=false;for(let i=start;i<s.length;i++){let c=s[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q=null;continue;}if(c==='\"'||c==="'")q=c;else if(c==='['||c==='{')d++;else if(c===']'||c==='}')if(--d===0)return s.slice(start,i+1);}return null;}
 function clean(v){if(v==null)return '';if(typeof v==='string')return v;try{return JSON.stringify(v)}catch(e){return String(v)}}
 function extract(src){let tests=[];let re=/(?:const|let|var)\\s+(TESTS_LIST|questions|questionData|testsData)\\s*=\\s*/g,m;while((m=re.exec(src))){let st=m.index+m[0].length;let ex=balanced(src,st);if(!ex)continue;try{let v=Function('return ('+ex+')')();if(Array.isArray(v)){if(m[1]==='TESTS_LIST'||m[1]==='testsData')tests.push(...v);else tests.push({title:'Imported Section',questions:v});}}catch(e){}}
 return tests;}
 function scan(doc){let all=[];doc.querySelectorAll('script').forEach(s=>all.push(...extract(s.textContent||'')));doc.querySelectorAll('iframe').forEach(f=>{let h=f.getAttribute('srcdoc');if(h){let d=new DOMParser().parseFromString(h,'text/html');all.push(...scan(d));}});return all;}
 let tests=scan(document);let fileName=(document.title||'Imported QBank.html').trim();let normalized=tests.map((t,i)=>{let qs=(t.questions||[]).map((q,j)=>{let opts=(q.options||[]).map((o,k)=>({label:o.label||String.fromCharCode(65+k),text:clean(o.text),correct:!!o.correct}));return {id:q.id??q.question_id??null,text:clean(q.text??q.question??q.stem??''),raw_text:clean(q.raw_text??q.text??''),correct_answer:q.correct_answer??q.answer??null,explanation:clean(q.explanation??q.solution??''),bot:clean(q.bot??''),video:clean(q.video??''),audio:clean(q.audio??''),options:opts,question_images:(q.question_images||q.images||[]).map(clean),explanation_images:(q.explanation_images||[]).map(clean)};});return {id:t.id??null,title:clean(t.title??t.name??('Section '+(i+1))),path:clean(t.path??''),total_marks:Number(t.total_marks||t.totalMarks||0),duration:Number(t.duration||t.duration_seconds||0),time_per_question:Number(t.time_per_question||0),questions:qs};}).filter(t=>t.questions.length);AndroidImport.receive(JSON.stringify({fileName:fileName,tests:normalized}));
})();"""
    }
}
