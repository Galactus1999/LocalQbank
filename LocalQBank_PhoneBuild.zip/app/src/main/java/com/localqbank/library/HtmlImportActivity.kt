package com.localqbank.library

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.View
import java.io.*
import java.nio.charset.Charset
import java.util.LinkedHashMap
import java.util.regex.Pattern

class HtmlImportActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var web: WebView
    private val files = mutableListOf<Uri>()
    private var index = 0
    private lateinit var db: QBankDb

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        db = QBankDb(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        val title = TextView(this).apply { text = "Import HTML QBank"; textSize = 22f }
        SystemUi.padTopInset(title, 18, 8, 0, 0)
        root.addView(title)
        status = TextView(this).apply { setPadding(0, 12, 0, 12) }
        root.addView(status)
        val frame = FrameLayout(this)
        web = WebView(this).apply { layoutParams = FrameLayout.LayoutParams(1, 1) }
        frame.addView(web)
        progress = ProgressBar(this).apply { isIndeterminate = true }
        frame.addView(progress, FrameLayout.LayoutParams(56, 56, Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val incoming = intent.getParcelableArrayListExtra<Uri>("uris")
        if (incoming != null) files.addAll(incoming)
        // Also accept HTML files opened directly from a file manager/browser via ACTION_VIEW.
        intent.data?.let { if (!files.contains(it)) files.add(it) }
        intent.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) {
                val u = clip.getItemAt(i).uri
                if (!files.contains(u)) files.add(u)
            }
        }
        if (files.isEmpty()) { finish(); return }
        configureWeb()
        processNext()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWeb() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.addJavascriptInterface(Bridge(), "AndroidImport")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { v?.evaluateJavascript(EXTRACT_JS, null) }
        }
    }

    private fun processNext() {
        if (index >= files.size) {
            progress.visibility = View.GONE
            status.text = "Import complete"
            Toast.makeText(this, "Imported ${files.size} HTML file(s)", Toast.LENGTH_LONG).show()
            setResult(RESULT_OK)
            finish()
            return
        }
        val uri = files[index]
        val size = fileSize(uri)
        progress.visibility = View.VISIBLE
        status.text = "Preparing ${index + 1}/${files.size}…"
        Thread {
            try {
                if (size >= LARGE_FILE_LIMIT) {
                    importLargeFile(uri, size)
                } else {
                    // Do not copy a normal file into a giant String on the UI thread.
                    val text = readSmall(uri)
                    runOnUiThread {
                        if (!isFinishing) {
                            status.text = "Extracting ${index + 1}/${files.size}…"
                            web.loadDataWithBaseURL(uri.toString(), text, "text/html", "UTF-8", null)
                        }
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.text = "Import failed: ${e.message ?: "unknown error"}"
                    Toast.makeText(this, e.message ?: "Import failed", Toast.LENGTH_LONG).show()
                    index++
                    processNext()
                }
            }
        }.start()
    }

    private fun importLargeFile(uri: Uri, size: Long) {
        runOnUiThread { status.text = "Large file (${formatMb(size)} MB) — importing without loading it into memory…" }
        val tmp = File(cacheDir, "q_import_${System.currentTimeMillis()}.html")
        copyToFile(uri, tmp) { done -> runOnUiThread { if (!isFinishing) status.text = "Reading large file… ${done}%" } }
        val session = db.beginStreamingImport(displayName(uri), "HTML QBank")
        var imported = 0
        var currentSection: String? = null
        try {
            LargeHtmlScanner(tmp) { section, q ->
                if (currentSection != null && currentSection != section) session.commitSection()
                currentSection = section
                session.addQuestion(section, q)
                imported++
                if (imported % 50 == 0) runOnUiThread { if (!isFinishing) status.text = "Imported $imported questions…" }
            }.scan()
            session.finish(true)
            runOnUiThread {
                status.text = "Imported $imported questions"
                index++
                processNext()
            }
        } catch (t: Throwable) {
            session.abort()
            throw t
        } finally {
            tmp.delete()
        }
    }

    private fun fileSize(uri: Uri): Long {
        try { contentResolver.openFileDescriptor(uri, "r")?.use { if (it.statSize > 0) return it.statSize } } catch (_: Throwable) {}
        return 0L
    }

    private fun displayName(uri: Uri): String {
        var name: String? = null
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        return name ?: uri.lastPathSegment ?: "Imported QBank.html"
    }

    private fun readSmall(uri: Uri): String {
        contentResolver.openInputStream(uri)?.use { input ->
            val bytes = input.readBytes()
            if (bytes.size >= 3 && bytes[0].toInt()==0xEF && bytes[1].toInt()==0xBB && bytes[2].toInt()==0xBF)
                return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
            if (bytes.size >= 2 && bytes[0].toInt()==0xFF && bytes[1].toInt()==0xFE)
                return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            if (bytes.size >= 2 && bytes[0].toInt()==0xFE && bytes[1].toInt()==0xFF)
                return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
            // Most QBank exports are UTF-8; WebView can then resolve relative image URLs
            // against the selected document URI through loadDataWithBaseURL().
            return String(bytes, Charsets.UTF_8)
        } ?: error("Cannot open $uri")
    }

    private fun copyToFile(uri: Uri, dest: File, onProgress: (Int) -> Unit) {
        val total = fileSize(uri)
        var done = 0L
        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    if (total > 0) onProgress(((done * 100) / total).toInt().coerceIn(0, 100))
                }
                out.fd.sync()
            }
        } ?: error("Cannot open $uri")
    }

    private fun formatMb(v: Long) = String.format(java.util.Locale.US, "%.0f", v / 1048576.0)

    inner class Bridge {
        @JavascriptInterface
        fun receive(json: String) {
            runOnUiThread {
                try {
                    val root = org.json.JSONObject(json)
                    val tests = parseTests(root.optJSONArray("tests") ?: org.json.JSONArray())
                    val name = root.optString("fileName", "Imported QBank.html")
                    val provider = detectProvider(tests)
                    if (tests.isEmpty()) throw IllegalArgumentException("No QBank sections/questions detected in $name.")
                    val n = db.importBundle(name, provider, tests)
                    status.text = "Imported $n questions"
                    index++
                    web.stopLoading()
                    processNext()
                } catch (e: Exception) {
                    status.text = "Import failed: ${e.message}"
                    Toast.makeText(this@HtmlImportActivity, e.message ?: "Import failed", Toast.LENGTH_LONG).show()
                    index++
                    processNext()
                }
            }
        }
    }

    private fun detectProvider(t: List<ImportedTest>) = when {
        t.any { it.title.contains("DAMS", true) } -> "DAMS"
        t.any { it.title.contains("BTR", true) } -> "BTR"
        t.any { it.title.contains("Mini Tests", true) } -> "DocTutorials"
        else -> "HTML QBank"
    }

    private fun parseTests(a: org.json.JSONArray): List<ImportedTest> {
        val out = mutableListOf<ImportedTest>()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i)
            val qa = t.optJSONArray("questions") ?: org.json.JSONArray()
            val qs = mutableListOf<ImportedQuestion>()
            for (j in 0 until qa.length()) {
                val q = qa.getJSONObject(j)
                val oa = q.optJSONArray("options") ?: org.json.JSONArray()
                val opts = mutableListOf<ImportedOption>()
                for (k in 0 until oa.length()) {
                    val o = oa.getJSONObject(k)
                    opts.add(ImportedOption(o.optString("label", "${'A'.code + k}"), o.optString("text", ""), o.optBoolean("correct", false)))
                }
                qs.add(ImportedQuestion(q.optStringOrNull("id"), q.optString("text", q.optString("raw_text", "")), q.optStringOrNull("raw_text"), q.optStringOrNull("correct_answer"), q.optStringOrNull("explanation"), q.optStringOrNull("bot"), q.optStringOrNull("video"), q.optStringOrNull("audio"), opts, jsonArray(q, "question_images"), jsonArray(q, "explanation_images")))
            }
            out.add(ImportedTest(t.optStringOrNull("id"), t.optString("title", "Section ${i + 1}"), t.optStringOrNull("path"), t.optDouble("total_marks", 0.0), t.optInt("duration", 0), t.optDouble("time_per_question", 0.0), qs))
        }
        return out
    }

    private fun jsonArray(o: org.json.JSONObject, k: String): List<String> { val a = o.optJSONArray(k) ?: return emptyList(); return buildList { for (i in 0 until a.length()) add(a.optString(i)) } }
    private fun org.json.JSONObject.optStringOrNull(k: String): String? = if (!has(k) || isNull(k)) null else optString(k, null)

    /**
     * Streaming importer for very large combined DAMS/BTR-style HTML files.
     *
     * The old implementation searched for every occurrence of "question" and then
     * re-read objects with RandomAccessFile. That is fragile for 100+ MB files and
     * especially bad when questions contain large base64 images. This parser instead
     * finds the TESTS_LIST/APP_DATA JSON array and walks it as a stream. It never
     * materializes the complete array or a complete test; only one question object is
     * held in memory at a time.
     */
    private class LargeHtmlScanner(private val file: File, private val onQuestion: (String, ImportedQuestion) -> Unit) {
        private val seen = HashSet<String>()
        private val maxQuestionChars = 16 * 1024 * 1024
        private var rootQuestionMode = false

        fun scan() {
            BufferedReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8), 256 * 1024).use { r ->
                // seekToDataArray() consumes the opening '[' so the parser starts exactly
                // at the first element of the real data array.
                if (!seekToDataArray(r)) throw IllegalArgumentException("No supported QBank data array found")
                while (true) {
                    skipWs(r)
                    val c = peek(r)
                    if (c == -1 || c == ']'.code) break
                    if (c == ','.code) { r.read(); continue }
                    if (c != '{'.code) { skipValue(r); continue }
                    if (rootQuestionMode) parseRootQuestion(r) else parseTestObject(r)
                    skipWs(r)
                    if (peek(r) == ','.code) r.read()
                }
            }
        }

        private fun seekToDataArray(r: BufferedReader): Boolean {
            // Do not merely search for the word TESTS_LIST: it also appears in comments
            // inside some generated QBanks. Match an actual JavaScript assignment such as
            //   const TESTS_LIST = [ ... ]
            //   let APP_DATA = [ ... ]
            // and consume the opening '['. This fixes the false match that caused
            // "Expected '[' in QBank data" / empty imports on DAMS files.
            val window = StringBuilder()
            val assignment = Pattern.compile(
                "(?:const\\s+|let\\s+|var\\s+)?(?:window\\.)?(TESTS_LIST|APP_DATA|QUESTIONS_DATA|questions_json|questionData|questions|question_list|items)\\s*=\\s*\\[",
                Pattern.CASE_INSENSITIVE
            )
            while (true) {
                val c = r.read()
                if (c < 0) return false
                window.append(c.toChar())
                if (window.length > 320) window.delete(0, window.length - 320)
                val m = assignment.matcher(window)
                if (m.find()) {
                    val name=m.group(1) ?: ""
                    rootQuestionMode=name.contains("question", true) || name.equals("items", true)
                    return true
                }
            }
        }

        private fun parseRootQuestion(r: BufferedReader) {
            try {
                val raw=readObject(r)
                if (raw.length > maxQuestionChars) return
                val o=org.json.JSONObject(raw)
                val q=normalize(o) ?: return
                val key=(q.sourceId ?: "")+"|"+q.text.take(180)
                if(seen.add(key)) onQuestion("Imported Section",q)
            } catch (_: Throwable) { }
        }

        private fun parseTestObject(r: BufferedReader) {
            expect(r, '{')
            var title = "DAMS PYQ"
            while (true) {
                skipWs(r)
                val c = peek(r)
                if (c == '}'.code) { r.read(); return }
                if (c == ','.code) { r.read(); continue }
                if (c != '"'.code) { skipValue(r); continue }
                val key = readString(r)
                skipWs(r); expect(r, ':'); skipWs(r)
                when (key.lowercase()) {
                    "title", "name", "subject", "section" -> {
                        val v = readSimpleStringOrValue(r)
                        if (v.isNotBlank() && v.length < 150) title = v
                    }
                    "questions" -> parseQuestionsArray(r, title)
                    else -> skipValue(r)
                }
            }
        }

        private fun parseQuestionsArray(r: BufferedReader, section: String) {
            skipWs(r)
            if (peek(r) != '['.code) { skipValue(r); return }
            r.read()
            while (true) {
                skipWs(r)
                val c = peek(r)
                if (c == -1 || c == ']'.code) { if (c == ']'.code) r.read(); return }
                if (c == ','.code) { r.read(); continue }
                if (c != '{'.code) { skipValue(r); continue }
                val raw = readObject(r)
                if (raw.length <= maxQuestionChars) parseCandidate(raw, section)
            }
        }

        private fun parseCandidate(src: String, section: String) {
            try {
                val o = org.json.JSONObject(src)
                val q = normalize(o) ?: return
                val key = (q.sourceId ?: "") + "|" + q.text.take(180)
                if (seen.add(key)) onQuestion(section, q)
            } catch (_: Throwable) {
                // A malformed/non-JSON object is skipped without aborting the whole import.
            }
        }

        private fun normalize(q: org.json.JSONObject): ImportedQuestion? {
            val text = clean(q.opt("raw_text") ?: q.opt("text") ?: q.opt("question") ?: q.opt("stem") ?: q.opt("question_text") ?: "")
            val options = q.opt("options") ?: q.opt("choices") ?: q.opt("answers")
            val opts = mutableListOf<ImportedOption>()
            if (options is org.json.JSONArray) for (i in 0 until options.length()) {
                val x = options.opt(i)
                if (x is org.json.JSONObject) opts.add(ImportedOption(x.optString("label", "${'A'.code + i}"), clean(x.opt("text") ?: x.opt("value") ?: x.opt("option") ?: ""), x.optBoolean("correct", false) || x.optBoolean("is_correct", false)))
                else opts.add(ImportedOption("${'A'.code + i}", clean(x), false))
            } else if (options is org.json.JSONObject) {
                for (k in options.keys()) opts.add(ImportedOption(k, clean(options.opt(k)), false))
            }
            val ans = q.optString("correct_answer", q.optString("answer", q.optString("ans", ""))).ifBlank { null }
            val ex = clean(q.opt("explanation") ?: q.opt("solution") ?: q.opt("expl") ?: "")
            val imgs = extractImages(text + " " + clean(q.opt("question_images") ?: q.opt("images") ?: q.opt("img") ?: q.opt("image") ?: q.opt("questionImage") ?: ""))
            val exImgs = extractImages(ex + " " + clean(q.opt("explanation_images") ?: q.opt("explanationImage") ?: ""))
            if (text.isBlank() || opts.isEmpty()) return null
            return ImportedQuestion(q.optString("id", q.optString("question_id", null)), text, text, ans, ex.ifBlank { null }, q.optString("bot", null), q.optString("video", null), q.optString("audio", null), opts, imgs, exImgs)
        }

        private fun clean(v: Any?): String = when (v) { null -> ""; is String -> v; else -> v.toString() }

        private fun extractImages(s: String): List<String> {
            val out = LinkedHashMap<String, Boolean>()
            val p = Pattern.compile("<img[^>]+(?:src|data-src|data-original)=[\\\"']([^\\\"']+)[\\\"']", Pattern.CASE_INSENSITIVE)
            val m = p.matcher(s)
            while (m.find()) out[m.group(1)] = true
            if (s.trim().startsWith("data:image")) out[s.trim()] = true
            return out.keys.toList()
        }

        private fun readObject(r: BufferedReader): String {
            val out = StringBuilder()
            var depth = 0
            var quote = false
            var escape = false
            while (true) {
                val c = r.read()
                if (c < 0) throw EOFException("Unexpected end of QBank JSON")
                out.append(c.toChar())
                if (out.length > maxQuestionChars) throw IllegalArgumentException("Question object is too large")
                if (quote) {
                    if (escape) escape = false else if (c == '\\'.code) escape = true else if (c == '"'.code) quote = false
                } else {
                    when (c) {
                        '"'.code -> quote = true
                        '{'.code -> depth++
                        '}'.code -> { depth--; if (depth == 0) return out.toString() }
                    }
                }
            }
        }

        private fun readSimpleStringOrValue(r: BufferedReader): String {
            skipWs(r)
            return if (peek(r) == '"'.code) readString(r) else {
                val b = StringBuilder()
                while (true) {
                    val c = peek(r)
                    if (c < 0 || c == ','.code || c == '}'.code) break
                    b.append(r.read().toChar())
                }
                b.toString().trim()
            }
        }

        private fun readString(r: BufferedReader): String {
            expect(r, '"')
            val out = StringBuilder()
            var escape = false
            while (true) {
                val c = r.read()
                if (c < 0) throw EOFException("Unterminated JSON string")
                if (escape) {
                    out.append(when (c) { 'n'.code -> '\n'; 'r'.code -> '\r'; 't'.code -> '\t'; 'b'.code -> '\b'; 'f'.code -> '\u000C'; else -> c.toChar() })
                    escape = false
                } else if (c == '\\'.code) escape = true
                else if (c == '"'.code) return out.toString()
                else out.append(c.toChar())
            }
        }

        private fun skipValue(r: BufferedReader) {
            skipWs(r)
            when (peek(r)) {
                '"'.code -> readString(r)
                '{'.code -> { readContainer(r, '{'.code, '}'.code) }
                '['.code -> { readContainer(r, '['.code, ']'.code) }
                else -> while (true) { val c = peek(r); if (c < 0 || c == ','.code || c == '}'.code || c == ']'.code) break; r.read() }
            }
        }

        private fun readContainer(r: BufferedReader, open: Int, close: Int) {
            var depth = 0; var quote = false; var escape = false
            while (true) {
                val c = r.read(); if (c < 0) throw EOFException("Unexpected end of JSON")
                if (quote) { if (escape) escape = false else if (c == '\\'.code) escape = true else if (c == '"'.code) quote = false; continue }
                if (c == '"'.code) quote = true else if (c == open) depth++ else if (c == close && --depth == 0) return
            }
        }

        private fun skipWs(r: BufferedReader) { while (true) { val c = peek(r); if (c < 0 || !c.toChar().isWhitespace()) return; r.read() } }
        private fun peek(r: BufferedReader): Int { r.mark(1); val c = r.read(); r.reset(); return c }
        private fun expect(r: BufferedReader, ch: Char) { val c = r.read(); if (c != ch.code) throw IllegalArgumentException("Expected '$ch' in QBank data") }
    }

    companion object {
        private const val LARGE_FILE_LIMIT = 40L * 1024L * 1024L
        const val EXTRACT_JS = """
(function(){
 function clean(v){if(v==null)return '';if(typeof v==='string')return v;try{return JSON.stringify(v)}catch(e){return String(v)}}
 function img(v,base){let x=clean(v).trim();if(!x)return '';if(x.startsWith('data:image'))return x;try{return new URL(x,(base&&base.baseURI)||document.baseURI).href}catch(e){return x}}
 function imgs(v,base){let out=[];if(Array.isArray(v))v.forEach(x=>{let u=img(x,base);if(u)out.push(u)});else if(typeof v==='string'){let re=/<img[^>]+(?:src|data-src|data-original)=['\"]([^'\"]+)['\"]/ig,m;while((m=re.exec(v)))out.push(img(m[1],base));}return [...new Set(out)]}
 function balanced(s,start){let d=0,q=null,e=false;for(let i=start;i<s.length;i++){let c=s[i];if(q){if(e)e=false;else if(c==='\\')e=true;else if(c===q)q=null;continue;}if(c==='"'||c==="'")q=c;else if(c==='['||c==='{')d++;else if(c===']'||c==='}')if(--d===0)return s.slice(start,i+1);}return null;}
 function qlike(o){return o&&typeof o==='object'&&(o.text!=null||o.question!=null||o.stem!=null||o.question_text!=null||o.questionText!=null)&&(o.options!=null||o.choices!=null||o.answers!=null||o.option_list!=null||o.answer!=null||o.ans!=null||o.correct_answer!=null||o.correctAnswer!=null||o.explanation!=null||o.solution!=null||o.expl!=null)}
 function normQ(q,base){
   let src=clean(q.text??q.question??q.stem??q.question_text??q.questionText??q.raw_text??q.title??'');
   let opts=[];let os=q.options??q.choices??q.answers??q.option_list??q.optionList??{};
   if(Array.isArray(os))os.forEach((o,i)=>opts.push({label:o&&typeof o==='object'?(o.label??o.key??o.id??String.fromCharCode(65+i)):String.fromCharCode(65+i),text:clean(o&&typeof o==='object'?(o.text??o.value??o.option??o.html??o.label??''):o),correct:!!(o&&typeof o==='object'&&(o.correct??o.is_correct??o.isCorrect??o.correct_option))}));
   else if(os&&typeof os==='object')Object.keys(os).forEach(k=>{let v=os[k];opts.push({label:k,text:clean(v&&typeof v==='object'?(v.text??v.value??v.option??v.html??''):v),correct:!!(v&&typeof v==='object'&&(v.correct??v.is_correct??v.isCorrect))})});
   let ans=q.correct_answer??q.correctAnswer??q.answer??q.ans??q.correct_option??q.correctOption??q.correct??null;
   if(typeof ans==='object')ans=null;
   let ansText=clean(ans).trim();
   // Many QBanks store the answer as "B" or "B. Wood's lamp" rather than a per-option flag.
   if(ansText)opts=opts.map(o=>{let l=String(o.label||'').trim();let hit=ansText.replace(/\s+/g,' ').toLowerCase()===l.toLowerCase()||ansText.toLowerCase().startsWith(l.toLowerCase()+'.')||ansText.toLowerCase().startsWith(l.toLowerCase()+')');return {...o,correct:o.correct||hit}});
   let ex=clean(q.explanation??q.solution??q.expl??q.exp??q.rationale??q.answer_explanation??'');
   return{id:q.id??q.question_id??q.questionId??q.uid??null,text:src,raw_text:clean(q.raw_text??src),correct_answer:ans,explanation:ex,bot:clean(q.bot??''),video:clean(q.video??q.video_url??q.videoUrl??''),audio:clean(q.audio??q.audio_url??q.audioUrl??''),options:opts,question_images:imgs(q.question_images??q.images??q.img??q.image??q.questionImage??q.question_image??'',base).concat(imgs(src,base)),explanation_images:imgs(q.explanation_images??q.explanationImage??q.explanation_images_urls??'',base).concat(imgs(ex,base))}
 }
 let found=[],seenTests=new Set(),seenQuestions=new Set();
 function addTest(title,questions,path,base){
   let cleanTitle=(title||'Imported Section').trim().replace(/\s+/g,' ').slice(0,150)||'Imported Section';
   let qs=[];
   questions.forEach(q0=>{let q=normQ(q0,base);if(!q.text.trim()||q.options.length<2)return;let key=q.id?('id:'+String(q.id)):('txt:'+cleanTitle+'|'+q.text.trim().toLowerCase().slice(0,500));if(seenQuestions.has(key))return;seenQuestions.add(key);qs.push(q)});
   if(!qs.length)return;
   let key=cleanTitle+'|'+qs.map(x=>x.id||x.text).join('|').slice(0,400);if(seenTests.has(key))return;seenTests.add(key);found.push({title:cleanTitle,path:path||'',questions:qs});
 }
 function walk(v,path,base){
   if(v==null)return;
   if(Array.isArray(v)){let qs=v.filter(qlike);if(qs.length)addTest(path.filter(Boolean).slice(-1)[0]||'Imported Section',qs,'',base);v.forEach(x=>walk(x,path,base));return}
   if(typeof v==='object'){
     let title=v.title??v.name??v.subject??v.lesson??v.section??v.chapter??null;let next=title?[...path,String(title)]:path;
     Object.keys(v).forEach(k=>{if(!['options','choices','answers','option_list','optionList'].includes(k))walk(v[k],next,base)})
   }
 }
 function extractValue(v,path,base){try{if(v&&typeof v==='object')walk(v,path,base)}catch(e){}}
 function decodeEntities(s){try{let ta=document.createElement('textarea');ta.innerHTML=s;return ta.value}catch(e){return s}}
 function extractScripts(doc,prefix){
   if(!doc)return;
   let re=/(?:(?:const|let|var)\s+)?(?:window\.)?([A-Za-z_$][\w$]*)\s*=\s*/g;
   doc.querySelectorAll('script').forEach(s=>{
     let src=s.textContent||'';re.lastIndex=0;let m;
     while((m=re.exec(src))){
       let p=m.index+m[0].length;while(p<src.length&&/\s/.test(src[p]))p++;
       if(src[p]!=='['&&src[p]!=='{')continue;
       let ex=balanced(src,p);if(!ex)continue;
       try{let value;try{value=JSON.parse(ex)}catch(_e){value=Function('return ('+ex+')')()};extractValue(value,[prefix||m[1]],doc)}catch(e){}
     }
     let typ=(s.type||'').toLowerCase();
     if(typ.includes('json')){try{extractValue(JSON.parse(src),[prefix||s.id||'Imported JSON'],doc)}catch(e){}}
   });
 }
 function textOf(el){return (el?.innerText||el?.textContent||'').replace(/\s+/g,' ').trim()}
 function firstText(root,selectors){for(let sel of selectors){let e=root.querySelector(sel);if(e){let t=textOf(e);if(t)return t}}return ''}
 function domFallback(doc,prefix){
   if(!doc)return;
   let selectors=['[data-question]','.question-card','.mcq-question','.quiz-question','.question-container','.question-block','.question-item','li.question','article.question'];
   let containers=[];selectors.forEach(sel=>doc.querySelectorAll(sel).forEach(e=>containers.push(e)));
   let unique=[...new Set(containers)];let qs=[];
   unique.forEach((el,idx)=>{
     let stem=el.getAttribute('data-question-text')||firstText(el,['[data-question-text]','.question-text','.question-title','.stem','.question-stem','.q-text']);
     if(!stem){let h=el.querySelector('h1,h2,h3,h4,h5');if(h)stem=textOf(h)}
     if(!stem){let clone=el.cloneNode(true);clone.querySelectorAll('label,.option,.choice,button,input,select,textarea,.answer,.explanation,.solution').forEach(x=>x.remove());stem=textOf(clone)}
     let options=[];let labels=el.querySelectorAll('label');
     if(labels.length){labels.forEach((lab,i)=>{let input=lab.querySelector('input');let txt=textOf(lab);if(txt)options.push({label:String.fromCharCode(65+i),text:txt,correct:!!(lab.matches('.correct,[data-correct="true"]')||input?.getAttribute('data-correct')==='true')})})}
     if(!options.length){el.querySelectorAll('[data-option],.option,.choice,.answer-option,.mcq-option,.option-item').forEach((o,i)=>{let txt=textOf(o);if(txt)options.push({label:o.getAttribute('data-label')||String.fromCharCode(65+i),text:txt,correct:o.matches('.correct,[data-correct="true"]')||o.getAttribute('data-correct')==='true'})})}
     if(!options.length){let lis=el.querySelectorAll('li');lis.forEach((o,i)=>{let txt=textOf(o);if(txt&&txt.length<500)options.push({label:String.fromCharCode(65+i),text:txt,correct:o.matches('.correct,[data-correct="true"]')})})}
     let ans=el.getAttribute('data-correct')||el.getAttribute('data-answer')||null;
     let ex=firstText(el,['.explanation','.solution','.answer-explanation','[data-explanation]']);
     let section=firstText(doc,['h1','h2','h3','[data-section-title]'])||prefix||'Imported Section';
     if(stem&&options.length>=2)qs.push({id:el.getAttribute('data-id')||el.id||String(idx+1),text:stem,correct_answer:ans,explanation:ex,options:options,question_images:[...el.querySelectorAll('img')].map(x=>img(x.getAttribute('src')||x.getAttribute('data-src')||'',doc))});
   });
   if(qs.length)addTest(section,qs,'dom',doc);
 }
 let processedDocs=new Set();
 function processDocument(doc,prefix){
   if(!doc||processedDocs.has(doc))return;processedDocs.add(doc);
   let before=found.length;
   extractScripts(doc,prefix);
   if(found.length===before)domFallback(doc,prefix);
   doc.querySelectorAll('iframe').forEach((f,i)=>{
     try{
       let child=f.contentDocument;
       let label=(prefix?prefix+' / ':'')+(f.title||f.getAttribute('title')||child?.title||('Section '+(i+1)));
       if(child)processDocument(child,label);
       let raw=f.getAttribute('srcdoc')||f.srcdoc||'';
       if(raw){
         // Combined QBank exports store the embedded quiz as HTML-entity encoded srcdoc.
         // Decode it before parsing so the nested `questions = [...]` data becomes visible.
         let decoded=(raw.indexOf('&lt;')>=0||raw.indexOf('&quot;')>=0||raw.indexOf('&#')>=0)?decodeEntities(raw):raw;
         let parsed=new DOMParser().parseFromString(decoded,'text/html');
         processDocument(parsed,label);
       }
     }catch(e){
       try{
         let raw=f.getAttribute('srcdoc')||f.srcdoc||'';
         if(raw){let decoded=(raw.indexOf('&lt;')>=0||raw.indexOf('&quot;')>=0||raw.indexOf('&#')>=0)?decodeEntities(raw):raw;let parsed=new DOMParser().parseFromString(decoded,'text/html');processDocument(parsed,prefix||'Imported Section')}
       }catch(_e){}
     }
   });
 }
 processDocument(document,document.title||'Imported Section');
 // Give srcdoc iframes one extra chance to become available on Android WebView.
 setTimeout(function(){processDocument(document,document.title||'Imported Section');AndroidImport.receive(JSON.stringify({fileName:(document.title||'Imported QBank.html').trim(),tests:found.filter(t=>t.questions.length)}));},250);
})();"""
    }
}
