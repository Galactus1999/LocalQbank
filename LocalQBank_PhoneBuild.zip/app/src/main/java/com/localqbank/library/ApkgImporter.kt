package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile
import java.util.regex.Pattern

/**
 * Fast, transactional Anki .apkg importer.
 * Heavy ZIP/SQLite/media work stays off the UI thread (caller responsibility).
 * Media is extracted once and HTML is rewritten once per card instead of scanning
 * the complete media manifest repeatedly.
 */
object ApkgImporter {
    data class Result(val decks:Int,val cards:Int)
    private const val SEP = "\u001f"

    fun importFile(context:Context, uri:android.net.Uri, progress:(String)->Unit = {}):Result {
        val work=File(context.cacheDir,"apkg_import_${System.currentTimeMillis()}.apkg")
        try {
            progress("Copying APKG… 0 MB")
            context.contentResolver.openInputStream(uri).use{input->
                requireNotNull(input){"Cannot open APKG"}
                FileOutputStream(work).use{out->
                    val buf=ByteArray(1024*1024); var n=0L; var next=16L*1024*1024
                    while(true){val r=input.read(buf);if(r<0)break;out.write(buf,0,r);n+=r;if(n>=next){progress("Copying APKG… ${n/1048576} MB");next+=16L*1024*1024}}
                }
            }
            return importZip(context,work,progress)
        } finally { work.delete() }
    }

    private fun importZip(context:Context, apkg:File, progress:(String)->Unit):Result {
        ZipFile(apkg).use{zip->
            val collection=zip.getEntry("collection.anki21") ?: zip.getEntry("collection.anki2")
                ?: throw IllegalArgumentException("This APKG has no Anki collection database")
            val dbFile=File(context.cacheDir,"anki_collection_${System.currentTimeMillis()}.anki2")
            try {
                zip.getInputStream(collection).use{input->FileOutputStream(dbFile).use{out->input.copyTo(out,1024*1024)}}
                val anki=SQLiteDatabase.openDatabase(dbFile.path,null,SQLiteDatabase.OPEN_READONLY)
                try {
                    val modelsRoot=JSONObject(readJsonColumn(anki,"SELECT models FROM col LIMIT 1") ?: "{}")
                    val deckNames=readDeckNames(anki)
                    val media=readMedia(zip)
                    val mediaDir=File(context.filesDir,"flashcard_media").apply{mkdirs()}
                    // Extract media once. Numeric Anki media keys and filename keys are both supported.
                    val mediaFiles=extractMedia(zip,media,mediaDir,progress)
                    val flash=FlashcardDb(context)
                    var deckCount=0; var cardCount=0; var currentDid=Long.MIN_VALUE
                    var currentDeckId=0L; var currentPosition=0
                    val modelCache=HashMap<Long,JSONObject>()
                    val fieldNameCache=HashMap<Long,List<String>>()
                    val templateCache=HashMap<Pair<Long,Int>,JSONObject>()
                    flash.beginImport()
                    var success=false
                    try {
                        val sql="SELECT c.id,c.did,c.ord,n.flds,n.tags,n.mid FROM cards c JOIN notes n ON n.id=c.nid ORDER BY c.did,c.id"
                        anki.rawQuery(sql,null).use{c->
                            while(c.moveToNext()){
                                val did=c.getLong(1); val ord=c.getInt(2); val fields=c.getString(3).split(SEP); val tags=c.getString(4); val mid=c.getLong(5)
                                if(did!=currentDid){
                                    if(currentDid!=Long.MIN_VALUE) flash.setDeckCount(currentDeckId,currentPosition)
                                    currentDid=did; currentPosition=0
                                    val name=deckNames[did] ?: "Deck $did"
                                    currentDeckId=flash.upsertDeckForImport(name,apkg.name)
                                    deckCount++
                                }
                                val model=modelCache.getOrPut(mid){modelsRoot.optJSONObject(mid.toString()) ?: JSONObject()}
                                val fieldNames=fieldNameCache.getOrPut(mid){
                                    val a=model.optJSONArray("flds"); buildList { if(a!=null) for(i in 0 until a.length()) add(a.getJSONObject(i).optString("name")) }
                                }
                                val names=HashMap<String,String>(fieldNames.size)
                                fieldNames.forEachIndexed{i,fn->if(i<fields.size)names[fn]=fields[i]}
                                val tpl=templateCache.getOrPut(mid to ord){
                                    val a=model.optJSONArray("tmpls"); findTemplate(a ?: org.json.JSONArray(),ord)
                                }
                                var front=renderTemplate(tpl.optString("qfmt","{{Front}}"),names,null,ord+1)
                                var back=renderTemplate(tpl.optString("afmt","{{FrontSide}}<hr id=answer>{{Back}}"),names,front,ord+1)
                                front=rewriteMedia(front,mediaFiles); back=rewriteMedia(back,mediaFiles)
                                flash.insertCard(currentDeckId,front,back,tags,currentPosition++)
                                cardCount++
                                if(cardCount%500==0)progress("Imported $cardCount flashcards…")
                            }
                        }
                        flash.setDeckCount(currentDeckId,currentPosition)
                        success=true
                    } finally {
                        flash.finishImport(success)
                        flash.close()
                    }
                    progress("Imported $cardCount flashcards")
                    return Result(deckCount,cardCount)
                } finally { anki.close() }
            } finally { dbFile.delete() }
        }
    }

    private fun readDeckNames(db:SQLiteDatabase):HashMap<Long,String>{
        val out=HashMap<Long,String>()
        val raw=readJsonColumn(db,"SELECT decks FROM col LIMIT 1") ?: return out
        runCatching{val o=JSONObject(raw);for(k in o.keys()){val d=o.optJSONObject(k);if(d!=null)out[k.toLongOrNull() ?: 0L]=d.optString("name","Deck $k")}}
        return out
    }
    private fun readJsonColumn(db:SQLiteDatabase,sql:String):String?=try{db.rawQuery(sql,null).use{c->if(c.moveToFirst())c.getString(0)else null}}catch(_:Throwable){null}
    private fun findTemplate(a:org.json.JSONArray,ord:Int):JSONObject { for(i in 0 until a.length()){val t=a.optJSONObject(i) ?: continue;if(t.optInt("ord",i)==ord)return t};return a.optJSONObject(0) ?: JSONObject() }

    private fun renderTemplate(template:String,fields:Map<String,String>,front:String?,cloze:Int):String {
        var s=template
        val cond=Pattern.compile("\\{\\{([#^])([^}]+)\\}\\}(.*?)\\{\\{/\\2\\}\\}",Pattern.DOTALL).matcher(s); val sb=StringBuffer()
        while(cond.find()){val value=fields[cond.group(2).trim()].orEmpty();val keep=if(cond.group(1)=="#")value.isNotBlank() else value.isBlank();cond.appendReplacement(sb,java.util.regex.Matcher.quoteReplacement(if(keep)cond.group(3) else ""))};cond.appendTail(sb);s=sb.toString()
        s=s.replace("{{FrontSide}}",front ?: "")
        s=Regex("\\{\\{cloze:([^}]+)\\}\\}").replace(s){m->clozeField(fields[m.groupValues[1]].orEmpty(),cloze)}
        s=Regex("\\{\\{(?:text:)?([^}:]+)\\}\\}").replace(s){m->fields[m.groupValues[1].trim()].orEmpty()}
        s=s.replace(Regex("\\{\\{[^}]+\\}\\}"),"")
        return s
    }
    private fun clozeField(value:String,n:Int):String { val re=Regex("\\{\\{c(\\d+)::(.*?)(?:::(.*?))?\\}\\}");return re.replace(value){m->if(m.groupValues[1].toIntOrNull()==n){"<b>[${m.groupValues[3].ifBlank{"…"}}]</b>"}else m.groupValues[2]}}
    private fun readMedia(zip:ZipFile):Map<String,String>{val e=zip.getEntry("media") ?: return emptyMap();val text=zip.getInputStream(e).bufferedReader().use{it.readText()};val o=JSONObject(text);return buildMap{for(k in o.keys())put(k,o.optString(k))}}

    private fun extractMedia(zip:ZipFile,media:Map<String,String>,dir:File,progress:(String)->Unit):Map<String,String>{
        if(media.isEmpty())return emptyMap()
        val out=HashMap<String,String>()
        var done=0
        for((key,name) in media){
            if(name.isBlank())continue
            val safeName=name.substringAfterLast('/').replace("..","_")
            val safe=File(dir,safeName)
            if(!safe.exists()){
                val entry=zip.getEntry(key) ?: zip.getEntry(name)
                if(entry!=null)runCatching{zip.getInputStream(entry).use{input->FileOutputStream(safe).use{output->input.copyTo(output,256*1024)}}}
            }
            if(safe.exists()){out[key]="file://${safe.absolutePath}";out[name]="file://${safe.absolutePath}"}
            done++;if(done%100==0)progress("Preparing media… $done/${media.size}")
        }
        return out
    }
    private fun rewriteMedia(html:String,map:Map<String,String>):String{
        if(map.isEmpty())return html
        var out=html
        for((name,path) in map){
            if(name.length<2)continue
            out=out.replace(Regex("(?i)(src|href)=(\'|\")"+Pattern.quote(name)+"\\2")){m->m.groupValues[1]+"="+m.groupValues[2]+path+m.groupValues[2]}
            out=out.replace(Regex("(?i)url\\((\'|\")"+Pattern.quote(name)+"\\1\\)")){m->"url("+m.groupValues[1]+path+m.groupValues[1]+")"}
        }
        return out
    }
}
