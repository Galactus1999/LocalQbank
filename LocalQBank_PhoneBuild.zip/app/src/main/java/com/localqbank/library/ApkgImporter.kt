package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile
import java.util.regex.Pattern

/**
 * Resumable, batch-transactional Anki .apkg importer.
 *
 * Design goals for phone-sized devices:
 * - never hold the complete deck/media set in RAM
 * - commit cards in small batches so one late failure cannot roll back 9,000 cards
 * - checkpoint after every batch so interrupted imports can resume
 * - tolerate individual bad cards/media files
 * - rewrite media references in one regex pass instead of N*M string scans
 */
object ApkgImporter {
    data class Result(val decks:Int,val cards:Int,val skipped:Int=0)
    class Control { @Volatile var cancelled=false }
    private class ImportCancelled: RuntimeException()
    private const val SEP = "\u001f"
    private const val BATCH_SIZE = 200
    private const val STATE_NAME = "flashcard_import_state.json"
    private const val APKG_NAME = "flashcard_import_current.apkg"

    private fun importDir(context:Context)=File(context.filesDir,"flashcard_imports").apply{mkdirs()}
    private fun stateFile(context:Context)=File(importDir(context),STATE_NAME)
    private fun apkgFile(context:Context)=File(importDir(context),APKG_NAME)

    fun hasPending(context:Context):Boolean=stateFile(context).exists() && apkgFile(context).exists()

    fun pendingDescription(context:Context):String? = runCatching {
        val o=JSONObject(stateFile(context).readText())
        "${o.optInt("cardIndex",0)} / ${o.optInt("totalCards",0)} cards"
    }.getOrNull()

    /** Starts a fresh import and leaves a durable source copy for crash recovery. */
    fun importFile(context:Context, uri:android.net.Uri, progress:(String)->Unit = {}, control:Control=Control()):Result {
        val dir=importDir(context); val work=apkgFile(context); val state=stateFile(context)
        state.delete(); work.delete()
        progress("Copying APKG… 0 MB")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open APKG" }
            FileOutputStream(work).use { out ->
                val buf = ByteArray(1024 * 1024)
                var n = 0L
                var next = 16L * 1024 * 1024
                while (true) {
                    checkCancelled(control)
                    val r = input.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                    n += r
                    if (n >= next) {
                        progress("Copying APKG… ${n / 1048576} MB")
                        next += 16L * 1024 * 1024
                    }
                }
                out.fd.sync()
            }
        }
        writeState(state,uri.toString(),uri.lastPathSegment ?: "Imported APKG",0,0,0,0)
        return runImport(context,work,state,progress,control)
    }

    /** Resumes the last interrupted import from its last committed card batch. */
    fun resume(context:Context, progress:(String)->Unit = {}, control:Control=Control()):Result {
        val work=apkgFile(context); val state=stateFile(context)
        require(work.exists() && state.exists()){"No interrupted flashcard import is available."}
        return runImport(context,work,state,progress,control)
    }

    fun discardPending(context:Context){ stateFile(context).delete(); apkgFile(context).delete() }

    private fun runImport(context:Context,apkg:File,state:File,progress:(String)->Unit,control:Control):Result {
        val saved=runCatching{JSONObject(state.readText())}.getOrDefault(JSONObject())
        val resumeCards=saved.optInt("cardIndex",0).coerceAtLeast(0)
        return try { importZip(context,apkg,state,saved,resumeCards,progress,control).also { state.delete(); apkg.delete() } }
        catch(e:ImportCancelled){ throw e }
        catch(e:Throwable){ throw e }
    }

    private fun importZip(context:Context,apkg:File,state:File,saved:JSONObject,resumeCards:Int,progress:(String)->Unit,control:Control):Result {
        ZipFile(apkg).use{zip->
            val collection=zip.getEntry("collection.anki21") ?: zip.getEntry("collection.anki2")
                ?: throw IllegalArgumentException("This APKG has no Anki collection database")
            val dbFile=File(context.cacheDir,"anki_collection_${System.currentTimeMillis()}.anki2")
            try {
                zip.getInputStream(collection).use{input->FileOutputStream(dbFile).use{out->input.copyTo(out,1024*1024)}}
                val anki=SQLiteDatabase.openDatabase(dbFile.path,null,SQLiteDatabase.OPEN_READONLY)
                try {
                    val modelsRoot=JSONObject(readJsonColumn(anki,"SELECT models FROM col LIMIT 1") ?: "{}")
                    val deckNames=readDeckNames(anki)
                    val media=readMedia(zip)
                    val mediaDir=File(context.filesDir,"flashcard_media").apply{mkdirs()}
                    val mediaFiles=extractMedia(zip,media,mediaDir,progress,control)
                    val totalCards=anki.rawQuery("SELECT COUNT(*) FROM cards",null).use{it.moveToFirst();it.getInt(0)}
                    val flash=FlashcardDb(context)
                    val sourceName=saved.optString("sourceName",apkg.name)
                    val isResume=resumeCards>0 || saved.optInt("totalCards",0)>0
                    if(!isResume) flash.deleteSource(sourceName)
                    var deckCount=0; var skipped=saved.optInt("skipped",0).coerceAtLeast(0); var imported=saved.optInt("imported",0).coerceAtLeast(0); var cursorIndex=0
                    var currentDid=Long.MIN_VALUE; var currentDeckId=0L; var currentPosition=0
                    var batch=0; var transactionOpen=false
                    val modelCache=HashMap<Long,JSONObject>(); val fieldNameCache=HashMap<Long,List<String>>(); val templateCache=HashMap<Pair<Long,Int>,JSONObject>()
                    fun beginBatch(){ if(!transactionOpen){flash.beginImport();transactionOpen=true;batch=0} }
                    fun commitBatch(){ if(transactionOpen){flash.finishImport(true,false);transactionOpen=false;writeState(state,saved.optString("uri",""),sourceName,cursorIndex,totalCards,skipped,imported)} }
                    try {
                        progress("Importing cards… $imported/$totalCards")
                        val sql="SELECT c.id,c.did,c.ord,n.flds,n.tags,n.mid FROM cards c JOIN notes n ON n.id=c.nid ORDER BY c.did,c.id"
                        anki.rawQuery(sql,null).use{c->
                            while(c.moveToNext()){
                                checkCancelled(control)
                                val did=c.getLong(1); val ord=c.getInt(2)
                                if(cursorIndex++ < resumeCards){
                                    // Reconstruct deck/position cheaply for the first skipped row.
                                    if(did!=currentDid){
                                        currentDid=did
                                        val name=deckNames[did] ?: "Deck $did"
                                        currentDeckId=flash.upsertDeckForImport(name,sourceName)
                                        currentPosition=flash.cardCount(currentDeckId)
                                        deckCount++
                                    }
                                    continue
                                }
                                if(did!=currentDid){
                                    commitBatch(); currentDid=did; currentPosition=0
                                    val name=deckNames[did] ?: "Deck $did"
                                    currentDeckId=flash.upsertDeckForImport(name,sourceName)
                                    deckCount++
                                }
                                beginBatch()
                                try {
                                    val fields=c.getString(3).split(SEP); val tags=c.getString(4); val mid=c.getLong(5)
                                    val model=modelCache.getOrPut(mid){modelsRoot.optJSONObject(mid.toString()) ?: JSONObject()}
                                    val fieldNames=fieldNameCache.getOrPut(mid){
                                        val a=model.optJSONArray("flds"); buildList { if(a!=null) for(i in 0 until a.length()) add(a.getJSONObject(i).optString("name")) }
                                    }
                                    val names=HashMap<String,String>(fieldNames.size)
                                    fieldNames.forEachIndexed{i,fn->if(i<fields.size)names[fn]=fields[i]}
                                    val tpl=templateCache.getOrPut(mid to ord){findTemplate(model.optJSONArray("tmpls") ?: org.json.JSONArray(),ord)}
                                    var front=renderTemplate(tpl.optString("qfmt","{{Front}}"),names,null,ord+1)
                                    var back=renderTemplate(tpl.optString("afmt","{{FrontSide}}<hr id=answer>{{Back}}"),names,front,ord+1)
                                    front=rewriteMedia(front,mediaFiles); back=rewriteMedia(back,mediaFiles)
                                    flash.insertCard(currentDeckId,front,back,tags,currentPosition++)
                                    imported++; batch++
                                } catch(_:Throwable){ skipped++; batch++ }
                                if(batch>=BATCH_SIZE){
                                    flash.setDeckCount(currentDeckId,currentPosition); commitBatch()
                                    progress("Imported $imported/$totalCards • skipped $skipped")
                                }
                            }
                        }
                        flash.setDeckCount(currentDeckId,currentPosition); commitBatch()
                        progress("Imported $imported/$totalCards • skipped $skipped")
                        return Result(deckCount,imported,skipped)
                    } finally {
                        if(transactionOpen) flash.finishImport(false,false)
                        flash.close()
                    }
                } finally { anki.close() }
            } finally { dbFile.delete() }
        }
    }

    private fun checkCancelled(control:Control){if(control.cancelled)throw ImportCancelled()}
    private fun writeState(file:File,uri:String,sourceName:String,cardIndex:Int,totalCards:Int,skipped:Int,imported:Int=0){
        runCatching{file.writeText(JSONObject().put("uri",uri).put("sourceName",sourceName).put("cardIndex",cardIndex).put("totalCards",totalCards).put("skipped",skipped).put("imported",imported).put("updatedAt",System.currentTimeMillis()).toString())}
    }

    private fun readDeckNames(db:SQLiteDatabase):HashMap<Long,String>{
        val out=HashMap<Long,String>(); val raw=readJsonColumn(db,"SELECT decks FROM col LIMIT 1") ?: return out
        runCatching{val o=JSONObject(raw);for(k in o.keys()){val d=o.optJSONObject(k);if(d!=null)out[k.toLongOrNull() ?: 0L]=d.optString("name","Deck $k")}}
        return out
    }
    private fun readJsonColumn(db:SQLiteDatabase,sql:String):String?=try{db.rawQuery(sql,null).use{c->if(c.moveToFirst())c.getString(0)else null}}catch(_:Throwable){null}
    private fun findTemplate(a:org.json.JSONArray,ord:Int):JSONObject { for(i in 0 until a.length()){val t=a.optJSONObject(i) ?: continue;if(t.optInt("ord",i)==ord)return t};return a.optJSONObject(0) ?: JSONObject() }

    private fun renderTemplate(template:String,fields:Map<String,String>,front:String?,cloze:Int):String {
        var s=template
        val cond=Pattern.compile("\\{\\{([#^])([^}]+)\\}\\}(.*?)\\{\\{/\\2\\}\\}",Pattern.DOTALL).matcher(s); val sb=StringBuffer()
        while(cond.find()){val value=fields[cond.group(2).trim()].orEmpty();val keep=if(cond.group(1)=="#")value.isNotBlank() else value.isBlank();cond.appendReplacement(sb,java.util.regex.Matcher.quoteReplacement(if(keep)cond.group(3) else ""))};cond.appendTail(sb);s=sb.toString()
        s=s.replace("{{FrontSide}}",front ?: "")
        s=Regex("\\{\\{cloze:([^}]+)\\}\\}").replace(s){m->clozeField(fields[m.groupValues[1]].orEmpty(),cloze,front!=null)}
        s=Regex("\\{\\{(?:text:)?([^}:]+)\\}\\}").replace(s){m->fields[m.groupValues[1].trim()].orEmpty()}
        return s.replace(Regex("\\{\\{[^}]+\\}\\}"),"")
    }
    private fun clozeField(value:String,n:Int,reveal:Boolean):String {
        val re=Regex("\\{\\{c(\\d+)::(.*?)(?:::(.*?))?\\}\\}")
        return re.replace(value){m->if(m.groupValues[1].toIntOrNull()==n){if(reveal)"<b><mark>${m.groupValues[2]}</mark></b>" else "<b>[${m.groupValues[3].ifBlank{"…"}}]</b>"}else m.groupValues[2]}
    }
    private fun readMedia(zip:ZipFile):Map<String,String>{val e=zip.getEntry("media") ?: return emptyMap();val text=zip.getInputStream(e).bufferedReader().use{it.readText()};val o=JSONObject(text);return buildMap{for(k in o.keys())put(k,o.optString(k))}}

    private fun extractMedia(zip:ZipFile,media:Map<String,String>,dir:File,progress:(String)->Unit,control:Control):Map<String,String>{
        if(media.isEmpty())return emptyMap()
        val out=HashMap<String,String>(media.size*2); var done=0
        for((key,name) in media){
            checkCancelled(control)
            if(name.isBlank()){done++;continue}
            val safeName=name.substringAfterLast('/').replace("..","_")
            val safe=File(dir,safeName)
            if(!safe.exists()){
                val entry=zip.getEntry(key) ?: zip.getEntry(name)
                if(entry!=null)runCatching{zip.getInputStream(entry).use{input->FileOutputStream(safe).use{output->input.copyTo(output,512*1024)}}}.onFailure{safe.delete()}
            }
            if(safe.exists()){
                val path="file://${safe.absolutePath}"
                out[key]=path;out[name]=path;out[name.substringAfterLast('/').trim()]=path
                runCatching{out[java.net.URLDecoder.decode(name,"UTF-8")]=path;out[java.net.URLDecoder.decode(name.substringAfterLast('/'),"UTF-8")]=path}
            }
            done++;if(done%50==0 || done==media.size)progress("Preparing media… $done/${media.size}")
        }
        return out
    }

    /** One pass over each HTML fragment; avoids the previous O(cards × media) replacement loop. */
    private fun rewriteMedia(html:String,map:Map<String,String>):String{
        if(map.isEmpty() || html.isEmpty()) return html
        val srcRx=Pattern.compile("""(?i)(src|href)\s*=\s*(["'])([^"']+)\2""")
        val m=srcRx.matcher(html); val sb=StringBuffer()
        while(m.find()){
            val raw=m.group(3)
            val path=map[raw] ?: map[raw.trim()] ?: map[raw.substringAfterLast('/').trim()] ?: runCatching{map[java.net.URLDecoder.decode(raw,"UTF-8")]} .getOrNull()
            if(path==null) m.appendReplacement(sb,java.util.regex.Matcher.quoteReplacement(m.group()))
            else m.appendReplacement(sb,java.util.regex.Matcher.quoteReplacement(m.group(1)+"="+m.group(2)+path+m.group(2)))
        }
        m.appendTail(sb)
        val css=Pattern.compile("""(?i)url\(\s*(["']?)([^"')]+)\1\s*\)""")
        val c=css.matcher(sb.toString()); val out=StringBuffer()
        while(c.find()){
            val raw=c.group(2)
            val path=map[raw] ?: map[raw.trim()] ?: map[raw.substringAfterLast('/').trim()] ?: runCatching{map[java.net.URLDecoder.decode(raw,"UTF-8")]} .getOrNull()
            if(path==null) c.appendReplacement(out,java.util.regex.Matcher.quoteReplacement(c.group()))
            else c.appendReplacement(out,java.util.regex.Matcher.quoteReplacement("url("+c.group(1)+path+c.group(1)+")"))
        }
        c.appendTail(out)
        return out.toString()
    }

}


