package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile
import java.util.regex.Pattern

object ApkgImporter {
    data class Result(val decks:Int,val cards:Int)
    private const val SEP = "\u001f"

    fun importFile(context:Context, uri:android.net.Uri, progress:(String)->Unit = {}):Result {
        val work=File(context.cacheDir,"apkg_import_${System.currentTimeMillis()}.apkg")
        context.contentResolver.openInputStream(uri).use{input->requireNotNull(input){"Cannot open APKG"}; FileOutputStream(work).use{out->val buf=ByteArray(1024*1024);var n:Long=0;while(true){val r=input.read(buf);if(r<0)break;out.write(buf,0,r);n+=r;if(n%(16L*1024*1024)<1024*1024)progress("Copying APKG… ${n/1048576} MB")}}}
        return try { importZip(context,work,progress) } finally { work.delete() }
    }

    private fun importZip(context:Context, apkg:File, progress:(String)->Unit):Result {
        ZipFile(apkg).use{zip->
            val collection=zip.getEntry("collection.anki21") ?: zip.getEntry("collection.anki2") ?: throw IllegalArgumentException("This APKG has no Anki collection database")
            val dbFile=File(context.cacheDir,"anki_collection_${System.currentTimeMillis()}.anki2")
            zip.getInputStream(collection).use{input->FileOutputStream(dbFile).use{out->input.copyTo(out,1024*1024)}}
            val anki=SQLiteDatabase.openDatabase(dbFile.path,null,SQLiteDatabase.OPEN_READONLY)
            try {
                val models=readJsonColumn(anki,"SELECT models FROM col LIMIT 1")
                val modelsRoot=try { JSONObject(models ?: "{}") } catch (_:Throwable) { JSONObject() }
                val decks=readJsonColumn(anki,"SELECT decks FROM col LIMIT 1")
                val deckNames=HashMap<Long,String>(); if(decks!=null){val o=JSONObject(decks);for(k in o.keys()){val d=o.optJSONObject(k);if(d!=null)deckNames[k.toLongOrNull() ?: 0L]=d.optString("name","Deck $k")}}
                val media=readMedia(zip)
                val flash=FlashcardDb(context)
                val modelCache=HashMap<Long,JSONObject>()
                var deckCount=0; var cardCount=0
                val sql="SELECT c.id,c.did,c.ord,n.flds,n.tags,n.mid FROM cards c JOIN notes n ON n.id=c.nid ORDER BY c.did,c.id"
                var currentDid=-1L
                var currentDeckId=0L
                var currentPosition=0
                anki.rawQuery(sql,null).use{c->
                    while(c.moveToNext()){
                        val did=c.getLong(1); val ord=c.getInt(2); val fields=c.getString(3).split(SEP); val tags=c.getString(4); val mid=c.getLong(5)
                        if(did!=currentDid){
                            if(currentDid!=-1L) flash.setDeckCount(currentDeckId,currentPosition)
                            currentDid=did
                            currentPosition=0
                            val name=deckNames[did] ?: "Deck $did"
                            currentDeckId=flash.upsertDeck(name,apkg.name,0)
                            deckCount++
                        }
                        val model=modelCache.getOrPut(mid){modelsRoot.optJSONObject(mid.toString()) ?: JSONObject()}
                        val templates=model.optJSONArray("tmpls")
                        val tpl=templates?.let{findTemplate(it,ord)} ?: JSONObject().put("qfmt","{{Front}}" ).put("afmt","{{FrontSide}}<hr id=answer>{{Back}}")
                        val names=mutableMapOf<String,String>(); val flds=model.optJSONArray("flds"); if(flds!=null)for(i in 0 until flds.length()){val fn=flds.getJSONObject(i).optString("name");if(i<fields.size)names[fn]=fields[i]}
                        var front=renderTemplate(tpl.optString("qfmt"),names,null,ord+1); var back=renderTemplate(tpl.optString("afmt"),names,front,ord+1)
                        front=decorateMedia(front,media,zip,context); back=decorateMedia(back,media,zip,context)
                        flash.insertCard(currentDeckId,front,back,tags,currentPosition++); cardCount++
                        if(cardCount%250==0)progress("Imported $cardCount flashcards…")
                    }
                }
                if(currentDid!=-1L) flash.setDeckCount(currentDeckId, currentPosition)
                flash.close(); progress("Imported $cardCount flashcards"); return Result(deckCount,cardCount)
            } finally { anki.close(); dbFile.delete() }
        }
    }
    private fun readJsonColumn(db:SQLiteDatabase,sql:String):String?=try{db.rawQuery(sql,null).use{c->if(c.moveToFirst())c.getString(0) else null}}catch(_:Throwable){null}
    private fun findTemplate(a:org.json.JSONArray,ord:Int):JSONObject { for(i in 0 until a.length()){val t=a.getJSONObject(i);if(t.optInt("ord",i)==ord)return t};return a.optJSONObject(0) ?: JSONObject() }
    private fun renderTemplate(template:String,fields:Map<String,String>,front:String?,cloze:Int):String {
        var s=template
        val cond=Pattern.compile("\\{\\{([#^])([^}]+)\\}\\}(.*?)\\{\\{/\\2\\}\\}",Pattern.DOTALL).matcher(s); val sb=StringBuffer()
        while(cond.find()){val value=fields[cond.group(2).trim()].orEmpty();val keep=if(cond.group(1)=="#")value.isNotBlank() else value.isBlank();cond.appendReplacement(sb,java.util.regex.Matcher.quoteReplacement(if(keep)cond.group(3) else ""))};cond.appendTail(sb);s=sb.toString()
        s=s.replace("{{FrontSide}}",front ?: "")
        s=Regex("\\{\\{cloze:([^}]+)\\}\\}").replace(s){m->clozeField(fields[m.groupValues[1]].orEmpty(),cloze)}
        s=Regex("\\{\\{(?:text:)?([^}:]+)\\}\\}").replace(s){m->fields[m.groupValues[1].trim()].orEmpty()}
        s=s.replace(Regex("\\{\\{[^}]+\\}\\}"),"")
        return s
    }
    private fun clozeField(value:String,n:Int):String { val re=Regex("\\{\\{c(\\d+)::(.*?)(?:::(.*?))?\\}\\}");return re.replace(value){m->if(m.groupValues[1].toIntOrNull()==n){"<b>[${m.groupValues[3].ifBlank{"…"}}]</b>"}else m.groupValues[2]}}
    private fun readMedia(zip:ZipFile):Map<String,String>{val e=zip.getEntry("media") ?: return emptyMap();val text=zip.getInputStream(e).bufferedReader().use{it.readText()};val o=JSONObject(text);return buildMap{for(k in o.keys())put(k,o.optString(k))}}
    private fun decorateMedia(html:String,media:Map<String,String>,zip:ZipFile,context:Context):String {
        if(media.isEmpty()) return html
        val dir=File(context.filesDir,"flashcard_media").apply{mkdirs()}
        val used=media.values.filter{it.isNotBlank()}.toSet()
        for(name in used){
            val safeName=name.substringAfterLast('/').replace("..","_")
            val safe=File(dir,safeName)
            if(!safe.exists()){
                val key=media.entries.firstOrNull{it.value==name}?.key
                val entry=key?.let{zip.getEntry(it)} ?: zip.getEntry(name)
                if(entry!=null) runCatching{zip.getInputStream(entry).use{input->FileOutputStream(safe).use{out->input.copyTo(out,256*1024)}}}
            }
        }
        var out=html
        for(name in used){
            val safeName=name.substringAfterLast('/').replace("..","_")
            val safe=File(dir,safeName)
            if(safe.exists()){
                out=out.replace(Regex("(?i)(src|href)=(['\"])"+Pattern.quote(name)+"\\2")){m->m.groupValues[1]+"="+m.groupValues[2]+"file://"+safe.absolutePath+m.groupValues[2]}
            }
        }
        // Anki cards sometimes place media in CSS, e.g. background-image:url("photo.jpg").
        for(name in used){
            val safeName=name.substringAfterLast('/').replace("..","_")
            val safe=File(dir,safeName)
            if(safe.exists()){
                out=out.replace(Regex("(?i)url\\((['\"])"+Pattern.quote(name)+"\\1\\)")){m->"url("+m.groupValues[1]+"file://"+safe.absolutePath+m.groupValues[1]+")"}
            }
        }
        val numeric=Regex("(?i)(src|href)=(['\"])(\\d+)\\2")
        for(m in numeric.findAll(out)){
            val name=media[m.groupValues[3]] ?: continue
            val safe=File(dir,name.substringAfterLast('/').replace("..","_")); if(safe.exists()) out=out.replace(m.value,m.groupValues[1]+"="+m.groupValues[2]+"file://"+safe.absolutePath+m.groupValues[2])
        }
        return out
    }

}
