package com.localqbank.library

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var store: ProgressStore
    private lateinit var qs: List<Question>
    private var pos = 0
    private lateinit var title: String
    private lateinit var content: LinearLayout
    private lateinit var counter: TextView
    private lateinit var result: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        db = QBankDb(this)
        store = ProgressStore(this)
        title = intent.getStringExtra("title") ?: "QBank"
        qs = db.questions(intent.getStringExtra("testId") ?: "")
        pos = intent.getIntExtra("position", 0).coerceIn(0, (qs.size - 1).coerceAtLeast(0))
        setContentView(build())
        show()
    }

    private fun build(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 251))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 8, 10, 8)
            setBackgroundColor(Color.rgb(22, 72, 112))
        }
        val tv = TextView(this).apply {
            text = title
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 2
        }
        top.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        val back = actionButton("Back", Color.rgb(48, 105, 151)) { finish() }
        top.addView(back, LinearLayout.LayoutParams(78, 44))
        root.addView(top)

        counter = TextView(this).apply {
            setPadding(16, 9, 16, 7)
            textSize = 13f
            setTextColor(Color.rgb(54, 76, 101))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(counter)

        scroll = ScrollView(this).apply {
            fillViewport = true
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setBackgroundColor(Color.WHITE)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 18)
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(content, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        result = TextView(this).apply {
            setPadding(16, 8, 16, 8)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setBackgroundColor(Color.rgb(238, 246, 251))
            setTextColor(Color.rgb(31, 96, 69))
            visibility = View.GONE
        }
        root.addView(result)

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 6, 8, 7)
            setBackgroundColor(Color.rgb(248, 250, 252))
        }
        val prev = actionButton("‹ Previous", Color.rgb(77, 96, 117)) {
            if (pos > 0) {
                pos--
                show()
            }
        }
        val next = actionButton("Next ›", Color.rgb(29, 132, 91)) {
            if (pos < qs.lastIndex) {
                pos++
                show()
            }
        }
        lateinit var bm: Button
        bm = actionButton("🔖 Bookmark", Color.rgb(82, 67, 137)) {
            showBookmarkMenu(bm)
        }
        val rev = actionButton("Review", Color.rgb(45, 96, 143)) {
            val q = qs[pos]
            store.setReview(q.stableKey, !store.review(q.stableKey))
            show()
        }
        nav.addView(prev, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        nav.addView(next, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        nav.addView(bm, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        nav.addView(rev, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        root.addView(nav)
        return root
    }

    private fun actionButton(label: String, color: Int, click: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(color)
            minHeight = 44
            setPadding(7, 0, 7, 0)
            setOnClickListener { click() }
        }

    private fun bookmarkColor(v: String) = when (v) {
        "important" -> Color.rgb(138, 90, 0)
        "revise" -> Color.rgb(37, 99, 166)
        "doubt" -> Color.rgb(122, 63, 145)
        else -> Color.rgb(177, 58, 84)
    }

    private fun addHtmlText(html: String?, size: Float, bold: Boolean = false, color: Int = Color.rgb(21, 38, 59)) {
        val t = TextView(this).apply {
            text = toSpanned(html ?: "")
            textSize = size
            setTextColor(color)
            setPadding(0, 0, 0, 8)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun toSpanned(value: String): Spanned =
        Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)

    private fun showBookmarkMenu(anchor: View) {
        if (qs.isEmpty()) return
        val popup = PopupWindow(this).apply {
            width = (resources.displayMetrics.density * 190).toInt()
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            isOutsideTouchable = true
            elevation = resources.displayMetrics.density * 8
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.WHITE))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.WHITE)
        }
        val options = listOf(
            "important" to "★  Important",
            "revise" to "↻  Revise",
            "doubt" to "❔  Doubt",
            "favorite" to "♥  Favourite"
        )
        options.forEach { (value, label) ->
            val b = actionButton(label, bookmarkColor(value)) {
                store.setBookmark(qs[pos].stableKey, value)
                popup.dismiss()
                show()
            }
            box.addView(b, LinearLayout.LayoutParams(-1, 46).apply { setMargins(0, 3, 0, 3) })
        }
        popup.contentView = box
        popup.showAsDropDown(anchor, -150, -((options.size * 52) + anchor.height + 8))
    }

    private fun show() {
        if (qs.isEmpty()) {
            counter.text = "No questions imported"
            content.removeAllViews()
            addHtmlText("<h2>No questions</h2><p>Import a QBank HTML file first.</p>", 18f)
            result.visibility = View.GONE
            return
        }

        val q = qs[pos]
        val status = store.status(q.stableKey)
        counter.text = "Question ${pos + 1} / ${qs.size}"
        content.removeAllViews()
        content.alpha = 0.94f

        addHtmlText(q.text, 18f, true)
        q.questionImages.forEach { addImage(it) }

        q.options.forEach { option ->
            val correct = option.correct ||
                q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
                q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
            val selected = store.selected(q.stableKey)?.equals(option.label, true) == true
            val b = Button(this).apply {
                text = "${option.label}   ${stripHtml(option.text)}"
                isAllCaps = false
                textSize = 15f
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setPadding(14, 10, 14, 10)
                minHeight = 58
                stateListAnimator = null
                setTextColor(Color.rgb(20, 38, 58))
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(232, 242, 250))
                setOnClickListener {
                    if (store.status(q.stableKey) == null) {
                        val isCorrect = option.correct ||
                            q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
                            q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
                        store.setAnswer(q.stableKey, option.label, if (isCorrect) "correct" else "wrong")
                        show()
                    }
                }
            }
            if (status != null) {
                b.isEnabled = false
                when {
                    correct -> {
                        b.setTextColor(Color.rgb(17, 91, 54))
                        b.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(218, 243, 226))
                    }
                    selected -> {
                        b.setTextColor(Color.rgb(137, 36, 52))
                        b.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(250, 220, 225))
                    }
                    else -> {
                        b.setTextColor(Color.rgb(91, 105, 121))
                        b.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(240, 243, 247))
                    }
                }
            }
            content.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) })
        }

        if (status != null) {
            result.visibility = View.VISIBLE
            result.text = if (status == "correct") {
                "✓ Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}"
            } else {
                "✗ Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}"
            }
            result.setTextColor(if (status == "wrong") Color.rgb(150, 38, 55) else Color.rgb(31, 96, 69))
            addHtmlText("<h2>Explanation</h2>${q.explanation ?: "<p>No explanation available.</p>"}", 16f)
            q.explanationImages.forEach { addImage(it) }
        } else {
            result.visibility = View.GONE
            addHtmlText("<p>Select an option to reveal the answer and full explanation.</p>", 13f, false, Color.rgb(86, 101, 121))
        }
        scroll.post { scroll.scrollTo(0, 0); content.animate().alpha(1f).setDuration(150).start() }
    }

    private fun stripHtml(value: String): String =
        toSpanned(value).toString().replace("\u00A0", " ").trim()

    private fun addImage(uri: String) {
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, 6, 0, 10)
        }
        try {
            val parsed = android.net.Uri.parse(uri)
            if (parsed.scheme == "data") {
                val comma = uri.indexOf(',')
                if (comma > 0) {
                    val data = android.util.Base64.decode(uri.substring(comma + 1), android.util.Base64.DEFAULT)
                    image.setImageBitmap(android.graphics.BitmapFactory.decodeByteArray(data, 0, data.size))
                }
            } else {
                image.setImageURI(parsed)
            }
        } catch (_: Exception) {
            image.visibility = View.GONE
        }
        content.addView(image, LinearLayout.LayoutParams(-1, -2))
    }
}
