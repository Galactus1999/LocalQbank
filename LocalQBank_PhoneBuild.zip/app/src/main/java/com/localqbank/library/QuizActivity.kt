package com.localqbank.library

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var store: ProgressStore
    private lateinit var qs: List<Question>
    private var pos = 0
    private lateinit var title: String
    private lateinit var content: LinearLayout
    private lateinit var counter: TextView
    private lateinit var result: TextView
    private lateinit var scroll: LockedScrollView
    private lateinit var bookmarkButton: TextView
    private lateinit var settingsButton: TextView
    private lateinit var sectionChip: TextView
    private lateinit var jumpButton: TextView
    private var fontScale = 1f
    private var headerMm = 10f
    private var sectionLabel: String? = null
    private var bankName: String = "QBank"
    private lateinit var bankNameView: TextView
    private var gestureDownX = 0f
    private var gestureDownY = 0f

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = QBankDb(this)
        store = ProgressStore(this)
        title = intent.getStringExtra("title") ?: "QBank"
        qs = db.questions(intent.getStringExtra("testId") ?: "")
        pos = intent.getIntExtra("position", 0).coerceIn(0, (qs.size - 1).coerceAtLeast(0))
        val ui = getSharedPreferences("ui", MODE_PRIVATE)
        fontScale = ui.getFloat("quiz_font_scale", 1f).coerceIn(.85f, 1.25f)
        headerMm = ui.getFloat("quiz_header_mm", 10f).coerceIn(7f, 13f)
        sectionLabel = intent.getStringExtra("sectionLabel")
        bankName = db.sourceNameForTest(intent.getStringExtra("testId") ?: "") ?: "QBank"
        setContentView(build())
        SystemUi.immersive(this)
        show()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { gestureDownX = ev.rawX; gestureDownY = ev.rawY }
            MotionEvent.ACTION_UP -> {
                val dx = ev.rawX - gestureDownX
                val dy = ev.rawY - gestureDownY
                if (kotlin.math.abs(dx) > dp(72) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                    if (dx < 0 && pos < qs.lastIndex) { pos++; show(); return true }
                    if (dx > 0 && pos > 0) { pos--; show(); return true }
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) SystemUi.immersive(this)
    }

    private fun build(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(18, 55, 86))
            clipToPadding = false
        }
        SystemUi.padTopInset(top, 8, 8, 12, 12)

        val back = headerButton("‹", 34f) { finish() }
        top.addView(back, LinearLayout.LayoutParams(dp(50), dp(50)).apply { setMargins(0, 0, dp(6), 0) })

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply {
            text = title
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, dp(4), 0)
        }
        titleBox.addView(tv, LinearLayout.LayoutParams(-1, dp(26)))
        val subRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bankNameView = TextView(this).apply {
            text = bankName
            textSize = 11f
            setTextColor(Color.rgb(210, 231, 242))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        subRow.addView(bankNameView, LinearLayout.LayoutParams(0, dp(24), 1f))
        sectionChip = TextView(this).apply {
            textSize = 10f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(25, 74, 94))
            gravity = Gravity.CENTER
            setPadding(dp(9), 0, dp(9), 0)
        }
        subRow.addView(sectionChip, LinearLayout.LayoutParams(-2, dp(22)).apply { setMargins(dp(6), 0, 0, 0) })
        titleBox.addView(subRow, LinearLayout.LayoutParams(-1, dp(24)))
        top.addView(titleBox, LinearLayout.LayoutParams(0, -1, 1f))

        settingsButton = headerButton("⚙", 20f) { showSettingsMenu(settingsButton) }
        top.addView(settingsButton, LinearLayout.LayoutParams(dp(50), dp(50)).apply { setMargins(dp(4), 0, 0, 0) })
        top.minimumHeight = headerHeightPx()
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val infoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        counter = TextView(this).apply {
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(54, 76, 101))
            gravity = Gravity.CENTER_VERTICAL
        }
        infoRow.addView(counter, LinearLayout.LayoutParams(0, dp(42), 1f))
        jumpButton = TextView(this).apply {
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(18, 72, 94))
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(220, 241, 244), 10f)
            elevation = dp(2).toFloat()
            setOnClickListener { showQuestionJumpMenu(this) }
            contentDescription = "Jump to question"
        }
        infoRow.addView(jumpButton, LinearLayout.LayoutParams(dp(48), dp(42)).apply { setMargins(dp(16), 0, 0, 0) })
        root.addView(infoRow)

        scroll = LockedScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setBackgroundColor(Color.WHITE)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(30))
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        result = TextView(this).apply {
            setPadding(dp(20), dp(10), dp(20), dp(10))
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setBackgroundColor(Color.rgb(238, 246, 251))
            visibility = View.GONE
        }
        root.addView(result)
        return root
    }

    private fun headerButton(label: String, size: Float, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.rgb(28, 70, 103), 16f)
        setOnClickListener { click() }
        isClickable = true
        isFocusable = true
    }

    private fun actionButton(label: String, color: Int, size: Float = 13f, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.rgb(35, 52, 70))
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = bookmarkPopupDrawable(color)
        elevation = dp(3).toFloat()
        setPadding(dp(8), 0, dp(8), 0)
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun optionCard(q: Question, option: Option, answered: Boolean) {
        val correct = option.correct ||
            q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
        val selected = store.selected(q.stableKey)?.equals(option.label, true) == true
        val bg = when {
            !answered -> Color.rgb(232, 242, 251)
            correct -> Color.rgb(220, 244, 228)
            selected -> Color.rgb(252, 226, 230)
            else -> Color.rgb(241, 244, 248)
        }
        val fg = when {
            !answered -> Color.rgb(18, 39, 61)
            correct -> Color.rgb(17, 91, 54)
            selected -> Color.rgb(137, 36, 52)
            else -> Color.rgb(91, 105, 121)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = if (answered) dp(72) else dp(86)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(bg, 20f)
            isClickable = !answered
            isFocusable = !answered
            if (!answered) setOnClickListener { answer(option.label) }
        }
        val letter = TextView(this).apply {
            text = option.label
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(if (!answered) Color.rgb(207, 224, 240) else bg, 50f)
        }
        row.addView(letter, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(0, 0, dp(14), 0) })
        val text = TextView(this).apply {
            this.text = toSpanned(option.text)
            textSize = 17.5f * fontScale
            setTextColor(fg)
            gravity = Gravity.CENTER_VERTICAL
            setLineSpacing(0f, 1.16f)
        }
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(7), 0, dp(7)) })
    }

    private fun answer(label: String) {
        if (qs.isEmpty()) return
        val q = qs[pos]
        if (store.status(q.stableKey) != null) return
        val selected = q.options.firstOrNull { it.label.equals(label, true) }
        val correct = selected?.correct == true ||
            q.correctAnswer?.trim()?.equals(label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(label.trim() + ".", true) == true
        store.setAnswer(q.stableKey, label, if (correct) "correct" else "wrong")
        show()
        scroll.post { scroll.smoothScrollTo(0, 0) }
    }

    private fun show() {
        content.removeAllViews()
        if (qs.isEmpty()) {
            counter.text = "No questions imported"
            addHtmlText("<h2>No questions</h2><p>Import a QBank HTML file first.</p>", 20f)
            result.visibility = View.GONE
            scroll.locked = true
            return
        }
        val q = qs[pos]
        val status = store.status(q.stableKey)
        val answered = status != null
        counter.text = "Question ${pos + 1} / ${qs.size}"
        jumpButton.text = (pos + 1).toString()
        // The question area must remain scrollable even before answering, especially for image-based questions.
        // Explanations are only added after an answer, so there is nothing to reveal prematurely.
        scroll.locked = false
        scroll.isVerticalScrollBarEnabled = answered
        updateSectionChip(q, status)

        val bm = TextView(this).apply {
            textSize = 13.5f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            elevation = dp(5).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            background = bookmarkGradient()
            setOnClickListener { showBookmarkMenu(this) }
        }
        updateBookmarkButton(q, bm)
        bookmarkButton = bm

        addHtmlText(q.text, 20f * fontScale, true)
        q.questionImages.forEach { addImage(it) }
        q.options.forEach { optionCard(q, it, answered) }

        // Keep bookmarking near the lower-left of the question content, after the options.
        // This avoids competing with the question counter/jump control at the top.
        content.addView(bm, LinearLayout.LayoutParams(-2, dp(46)).apply {
            gravity = Gravity.END
            setMargins(0, dp(8), dp(4), dp(14))
        })

        if (answered) {
            result.visibility = View.VISIBLE
            result.text = if (status == "correct") "✓  Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}"
            else "✗  Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}"
            result.setTextColor(if (status == "wrong") Color.rgb(150, 38, 55) else Color.rgb(31, 96, 69))
            addHtmlText("<h2>Explanation</h2>${q.explanation ?: "<p>No explanation available.</p>"}", 17f * fontScale)
            q.explanationImages.forEach { addImage(it) }
        } else {
            result.visibility = View.GONE
        }
        scroll.post { scroll.scrollTo(0, 0) }
    }

    private fun updateSectionChip(q: Question, status: String?) {
        val raw = sectionLabel?.trim()?.takeIf { it.isNotBlank() && !it.equals("practice", true) } ?: when {
            store.bookmark(q.stableKey) != null -> bookmarkLabel(store.bookmark(q.stableKey)!!)
            status == "wrong" -> "Wrong"
            status == "correct" -> "Solved"
            else -> "Unsolved"
        }
        sectionChip.text = raw.uppercase()
        val bg = when (raw.lowercase()) {
            "important" -> Color.rgb(246, 235, 199)
            "revise" -> Color.rgb(222, 237, 251)
            "doubt" -> Color.rgb(237, 224, 247)
            "favourite", "favorite" -> Color.rgb(249, 222, 232)
            "wrong" -> Color.rgb(252, 224, 228)
            "solved" -> Color.rgb(221, 243, 230)
            else -> Color.rgb(226, 239, 244)
        }
        sectionChip.background = rounded(bg, 12f)
    }

    private fun headerHeightPx(): Int {
        val dpi = resources.displayMetrics.densityDpi.toFloat()
        val px = dpi * (headerMm / 25.4f)
        return px.toInt().coerceIn(dp(56), dp(104))
    }

    private fun showQuestionJumpMenu(anchor: View) {
        if (qs.isEmpty()) return
        val popup = PopupWindow(this).apply {
            width = dp(290)
            height = dp(190)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.rgb(210, 223, 231)) }
        }
        val heading = TextView(this).apply {
            text = "Jump to question"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(25, 43, 61))
        }
        box.addView(heading, LinearLayout.LayoutParams(-1, dp(28)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 17f
            gravity = Gravity.CENTER
            setSingleLine(true)
            setSelectAllOnFocus(true)
            hint = "1 – ${qs.size}"
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(Color.rgb(242, 247, 250), 12f)
        }
        input.setText((pos + 1).toString())
        row.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val go = actionButton("GO", Color.rgb(27, 128, 91), 14f) {
            val n = input.text.toString().toIntOrNull()
            if (n != null && n in 1..qs.size) {
                pos = n - 1
                popup.dismiss()
                show()
            } else input.error = "Enter 1–${qs.size}"
        }
        row.addView(go, LinearLayout.LayoutParams(dp(78), dp(52)).apply { setMargins(dp(10), 0, 0, 0) })
        box.addView(row, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(8), 0, 0) })
        val hint = TextView(this).apply {
            text = "Swipe left/right to move one question"
            textSize = 12f
            setTextColor(Color.rgb(103, 115, 129))
            gravity = Gravity.CENTER
        }
        box.addView(hint, LinearLayout.LayoutParams(-1, dp(28)).apply { setMargins(0, dp(5), 0, 0) })
        popup.contentView = box
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(12), (loc[1] + dp(48)).coerceAtLeast(dp(50)))
        box.startAnimation(ScaleAnimation(.94f, 1f, .94f, 1f, 1f, 0f).apply { duration = 160 })
        input.requestFocus()
        input.post { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun showSettingsMenu(anchor: View) {
        val popup = PopupWindow(this).apply {
            width = dp(320)
            height = dp(430)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(210, 223, 231))
            }
        }
        val heading = TextView(this).apply {
            text = "Reading settings"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(25, 43, 61))
        }
        box.addView(heading, LinearLayout.LayoutParams(-1, dp(30)))

        val fs = TextView(this).apply {
            text = "Font size"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(80, 94, 110))
            setPadding(0, dp(10), 0, dp(2))
        }
        box.addView(fs)
        val fsValue = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(37, 103, 166))
            gravity = Gravity.CENTER_VERTICAL
        }
        box.addView(fsValue, LinearLayout.LayoutParams(-1, dp(24)))
        val seek = SeekBar(this).apply {
            max = 30
            progress = ((fontScale.coerceIn(.85f, 1.15f) - .85f) * 100f).toInt()
            setPadding(dp(4), 0, dp(4), 0)
        }
        fun fontText(p: Int) = "${85 + p}%  •  ${when { p < 10 -> "Small"; p < 18 -> "Medium"; p < 27 -> "Large"; else -> "Extra large" }}"
        fsValue.text = fontText(seek.progress)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { fsValue.text = fontText(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                fontScale = (.85f + seek.progress / 100f).coerceIn(.85f, 1.15f)
                getSharedPreferences("ui", MODE_PRIVATE).edit().putFloat("quiz_font_scale", fontScale).apply()
                show()
            }
        })
        box.addView(seek, LinearLayout.LayoutParams(-1, dp(46)))

        val hs = TextView(this).apply {
            text = "Header height"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(80, 94, 110))
            setPadding(0, dp(10), 0, dp(4))
        }
        box.addView(hs)
        val heights = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(8f, 10f, 12f, 13f).forEach { mm ->
            val b = TextView(this).apply {
                text = "${mm.toInt()} mm"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(28,57,80))
                background = rounded(if (kotlin.math.abs(headerMm-mm)<.01f) Color.rgb(222,242,236) else Color.rgb(244,247,250), 12f)
                setOnClickListener {
                    headerMm = mm
                    getSharedPreferences("ui", MODE_PRIVATE).edit().putFloat("quiz_header_mm", mm).apply()
                    popup.dismiss()
                    recreate()
                }
            }
            heights.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(if (mm == 8f) 0 else dp(4), 0, 0, 0) })
        }
        box.addView(heights, LinearLayout.LayoutParams(-1, dp(46)))

        val note = TextView(this).apply {
            text = "Font size is continuous (85–115%) so larger text remains usable with scrolling."
            textSize = 11.5f
            setTextColor(Color.rgb(103, 115, 129))
            setPadding(0, dp(12), 0, 0)
        }
        box.addView(note, LinearLayout.LayoutParams(-1, dp(42)))

        popup.contentView = box
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(10), (loc[1] + dp(54)).coerceAtLeast(dp(40)))
        box.startAnimation(ScaleAnimation(.94f,1f,.94f,1f,1f,0f).apply{duration=160})
    }

    private fun updateBookmarkButton(q: Question, button: TextView) {
        val value = store.bookmark(q.stableKey)
        button.text = if (value.isNullOrBlank()) "🔖  Bookmark" else "🔖  ${bookmarkLabel(value)}"
    }

    private fun bookmarkLabel(value: String) = when (value) {
        "important" -> "Important"
        "revise" -> "Revise"
        "doubt" -> "Doubt"
        "favorite" -> "Favourite"
        else -> "Bookmark"
    }

    private fun addHtmlText(html: String?, size: Float, bold: Boolean = false, color: Int = Color.rgb(21, 38, 59)) {
        val t = TextView(this).apply {
            text = toSpanned(html ?: "")
            textSize = size
            setTextColor(color)
            setLineSpacing(0f, 1.25f)
            setPadding(0, 0, 0, dp(14))
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun toSpanned(value: String): Spanned = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)

    private fun addImage(uri: String) {
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, dp(6), 0, dp(10))
        }
        try {
            val parsed = android.net.Uri.parse(uri)
            if (parsed.scheme == "data") {
                val comma = uri.indexOf(',')
                if (comma > 0) {
                    val data = android.util.Base64.decode(uri.substring(comma + 1), android.util.Base64.DEFAULT)
                    image.setImageBitmap(android.graphics.BitmapFactory.decodeByteArray(data, 0, data.size))
                }
            } else image.setImageURI(parsed)
            content.addView(image, LinearLayout.LayoutParams(-1, -2))
        } catch (_: Exception) { }
    }

    private fun showBookmarkMenu(anchor: View) {
        if (qs.isEmpty()) return
        val popup = PopupWindow(this).apply {
            width = dp(336)
            height = dp(276)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.rgb(205, 220, 231))
            }
            elevation = dp(8).toFloat()
        }
        val titleView = TextView(this).apply {
            text = "Bookmark category"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(30, 43, 60))
            setPadding(dp(6), dp(2), dp(6), dp(10))
        }
        box.addView(titleView)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val values = listOf(
            "important" to "★  Important",
            "revise" to "↻  Revise",
            "doubt" to "❔  Doubt",
            "favorite" to "♥  Favourite"
        )
        for (r in 0..1) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..1) {
                val pair = values[r * 2 + c]
                val b = actionButton(pair.second, bookmarkColor(pair.first), 14.5f) {
                    store.setBookmark(qs[pos].stableKey, pair.first)
                    popup.dismiss()
                    show()
                }
                row.addView(b, LinearLayout.LayoutParams(0, dp(82), 1f).apply {
                    setMargins(if (c == 0) 0 else dp(6), dp(4), if (c == 0) dp(6) else 0, dp(4))
                })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, dp(90)))
        }
        box.addView(grid)
        popup.contentView = box
        popup.setOnDismissListener { }
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(10), popupTopY(anchor))
        val anim = AnimationSet(true).apply {
            addAnimation(ScaleAnimation(.92f, 1f, .92f, 1f, 1f, .5f).apply { duration = 170 })
            addAnimation(AlphaAnimation(.25f, 1f).apply { duration = 170 })
        }
        box.startAnimation(anim)
    }

    private fun popupTopY(anchor: View): Int {
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        return (loc[1] + dp(8)).coerceAtLeast(dp(44))
    }

    private fun bookmarkGradient() = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(19, 111, 151), Color.rgb(27, 157, 117))).apply { cornerRadius = dp(24).toFloat() }

    private fun bookmarkColor(v: String) = when (v) {
        "important" -> Color.rgb(253, 226, 228)
        "revise" -> Color.rgb(220, 238, 255)
        "doubt" -> Color.rgb(234, 242, 245)
        "favorite", "favourite" -> Color.rgb(255, 243, 191)
        else -> Color.rgb(234, 242, 245)
    }

    private fun bookmarkPopupDrawable(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), if (color == Color.rgb(234, 242, 245)) Color.WHITE else Color.argb(90, 255, 255, 255))
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius * resources.displayMetrics.density
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

/** Prevents accidental vertical scrolling while the user is still answering. */
private class LockedScrollView(context: android.content.Context) : ScrollView(context) {
    var locked: Boolean = false
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onInterceptTouchEvent(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onTouchEvent(ev)
}
