package com.localqbank.library

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class QuizActivity:AppCompatActivity(){
 private lateinit var db:QBankDb; private lateinit var store:ProgressStore; private lateinit var qs:List<Question>
 private var pos=0; private lateinit var title:String; private lateinit var content:WebView; private lateinit var counter:TextView; private lateinit var result:TextView; private lateinit var bookmarkPanel:LinearLayout

 override fun onCreate(b:Bundle?){super.onCreate(b);db=QBankDb(this);store=ProgressStore(this);title=intent.getStringExtra("title")?:"QBank";qs=db.questions(intent.getStringExtra("testId")?:"");pos=intent.getIntExtra("position",0).coerceIn(0,(qs.size-1).coerceAtLeast(0));setContentView(build());show()}

 @SuppressLint("SetJavaScriptEnabled") private fun build():LinearLayout{
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(245,247,251))}
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(14,10,10,10);setBackgroundColor(Color.rgb(18,48,79))}
  val tv=TextView(this).apply{text=title;textSize=18f;setTypeface(null,1);setTextColor(Color.WHITE)};top.addView(tv,LinearLayout.LayoutParams(0,-2,1f))
  val back=Button(this).apply{text="Back";isAllCaps=false;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(45,82,119));setOnClickListener{finish()}};top.addView(back)
  root.addView(top)
  counter=TextView(this).apply{setPadding(16,10,16,5);textSize=13f;setTextColor(Color.rgb(71,84,103));setBackgroundColor(Color.WHITE)};root.addView(counter)
  content=WebView(this).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.loadsImagesAutomatically=true;setBackgroundColor(Color.WHITE);webViewClient=WebViewClient();addJavascriptInterface(QuizBridge(),"AndroidQuiz")}
  root.addView(content,LinearLayout.LayoutParams(-1,0,1f))
  result=TextView(this).apply{setPadding(16,7,16,7);textSize=14f;setTypeface(null,1);setBackgroundColor(Color.WHITE)};root.addView(result)
  bookmarkPanel=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(8,5,8,5);setBackgroundColor(Color.rgb(235,240,247));visibility=View.GONE}
  listOf("important" to "★ Important","revise" to "↻ Revise","doubt" to "? Doubt","favorite" to "♥ Favourite").forEach{(v,label)->val b=Button(this).apply{text=label;isAllCaps=false;textSize=11f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(bookmarkColor(v));setOnClickListener{store.setBookmark(qs[pos].stableKey,v);bookmarkPanel.visibility=View.GONE;show()}};bookmarkPanel.addView(b,LinearLayout.LayoutParams(0,44,1f).apply{setMargins(3,0,3,0)})}
  root.addView(bookmarkPanel)
  val nav=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(7,5,7,5);setBackgroundColor(Color.WHITE)}
  fun navButton(text:String,color:Int,click:()->Unit)=Button(this).apply{text=text;isAllCaps=false;textSize=12f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(color);setOnClickListener{click()}}
  val prev=navButton("‹ Previous",Color.rgb(77,96,117)){if(pos>0){pos--;show()}}
  val next=navButton("Next ›",Color.rgb(34,116,91)){if(pos<qs.lastIndex){pos++;show()}}
  val bm=navButton("🔖 Bookmark",Color.rgb(82,67,137)){bookmarkPanel.visibility=if(bookmarkPanel.visibility==View.VISIBLE)View.GONE else View.VISIBLE}
  val rev=navButton("Review",Color.rgb(45,96,143)){val q=qs[pos];store.setReview(q.stableKey,!store.review(q.stableKey));show()}
  nav.addView(prev,LinearLayout.LayoutParams(0,48,1f).apply{setMargins(2,0,2,0)});nav.addView(next,LinearLayout.LayoutParams(0,48,1f).apply{setMargins(2,0,2,0)});nav.addView(bm,LinearLayout.LayoutParams(0,48,1f).apply{setMargins(2,0,2,0)});nav.addView(rev,LinearLayout.LayoutParams(0,48,1f).apply{setMargins(2,0,2,0)});root.addView(nav)
  return root
 }
 private fun bookmarkColor(v:String)=when(v){"important"->Color.rgb(138,90,0);"revise"->Color.rgb(37,99,166);"doubt"->Color.rgb(122,63,145);else->Color.rgb(177,58,84)}
 private fun html(s:String)=s.ifBlank{""}
 private fun imgBlock(list:List<String>)=list.joinToString(""){u->"<div class='imageBox'><img src=\"${u.replace("\"","&quot;")}\"></div>"}
 private fun optionHtml(q:Question,status:String?):String=q.options.joinToString(""){o->
  val correct=o.correct || q.correctAnswer?.trim()?.equals(o.label.trim(),true)==true || q.correctAnswer?.trim()?.equals(o.label.trim()+".",true)==true
  val selected=store.selected(q.stableKey)==o.label
  val cls=if(status==null)"opt" else if(correct)"opt correct" else if(selected)"opt wrong" else "opt dim"
  val disabled=if(status==null)"" else "disabled"
  val label=JSONObject.quote(o.label)
  "<button class='$cls' $disabled onclick=\"AndroidQuiz.answer($label)\"><span class='letter'>${o.label}</span><span>${o.text}</span></button>"
 }
 private fun page(q:Question,status:String?):String{
  val answered=status!=null
  val explanation=if(answered)"<section class='explain'><h2>Explanation</h2>${html(q.explanation)}${imgBlock(q.explanationImages)}</section>" else "<div class='hint'>Select an option to reveal the answer and full explanation.</div>"
  return """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1'><style>
  *{box-sizing:border-box}body{margin:0;padding:16px;background:#fff;font-family:sans-serif;color:#15263B;font-size:17px;line-height:1.55}h1,h2,h3{color:#10243A} .question{font-size:18px;font-weight:600;margin-bottom:14px}.imageBox{margin:12px 0;text-align:center;overflow-x:auto}.imageBox img{max-width:100%;height:auto}.opt{display:flex;width:100%;text-align:left;align-items:flex-start;gap:11px;margin:9px 0;padding:14px 13px;border:1px solid #C9D3E0;border-radius:12px;background:#EAF2FA;color:#14263A;font-size:16px;line-height:1.4}.opt .letter{min-width:30px;height:30px;border-radius:50%;background:#D3E2F0;display:inline-flex;align-items:center;justify-content:center;font-weight:700}.opt.correct{background:#E7F6EC;border-color:#66A97E;color:#155B36}.opt.correct .letter{background:#BFE4CB}.opt.wrong{background:#FCEBEC;border-color:#D17B88;color:#8A2637}.opt.wrong .letter{background:#F2C7CE}.opt.dim{opacity:.72}.hint{margin:15px 0;padding:12px;border-radius:10px;background:#F0F4F8;color:#566579;font-size:14px}.explain{margin-top:22px;padding-top:12px;border-top:3px solid #2E6EA5}.explain h2{font-size:20px;margin:4px 0 10px}table{display:block;max-width:100%;overflow-x:auto;border-collapse:collapse}td,th{padding:7px;border:1px solid #CBD5E1}a{color:#1F5F95}</style></head><body><div class='question'>${html(q.text)}</div>${imgBlock(q.questionImages)}${optionHtml(q,status)}$explanation</body></html>"""
 }
 private fun show(){if(qs.isEmpty()){counter.text="No questions imported";content.loadDataWithBaseURL(null,"<html><body><h2>No questions</h2></body></html>","text/html","UTF-8",null);return};val q=qs[pos];val status=store.status(q.stableKey);counter.text="Question ${pos+1} / ${qs.size}";result.text=when(status){"correct"->"✓ Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}";"wrong"->"✗ Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}";else->""};result.setTextColor(if(status=="wrong")Color.rgb(150,38,55) else Color.rgb(31,96,69));content.loadDataWithBaseURL("file:///android_asset/",page(q,status),"text/html","UTF-8",null);content.scrollTo(0,0);bookmarkPanel.visibility=View.GONE}
 inner class QuizBridge{@JavascriptInterface fun answer(label:String){runOnUiThread{val q=qs[pos];if(store.status(q.stableKey)!=null)return@runOnUiThread;val correct=q.options.firstOrNull{it.label.equals(label,true)}?.correct==true || q.correctAnswer?.trim()?.equals(label.trim(),true)==true || q.correctAnswer?.trim()?.equals(label.trim()+".",true)==true;store.setAnswer(q.stableKey,label,if(correct)"correct" else "wrong");show()}}}
}
