package com.localqbank.library

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.net.Uri
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var store: ProgressStore
    private lateinit var testId: String
    private var questionCount = 0
    private var currentQuestion: Question? = null
    private var sourceId = 0L
    private var pos = 0
    private lateinit var title: String
    private lateinit var content: LinearLayout
    private lateinit var counter: TextView
    private lateinit var result: TextView
    private lateinit var scroll: LockedScrollView
    private lateinit var bookmarkButton: TextView
    private lateinit var settingsButton: TextView
    private lateinit var sectionChip: TextView
    private lateinit var jumpButton: TextView
    private var fontScale = 1f
    private var fontFamily = "sans-serif"
    private var headerMm = 10f
    private var sectionLabel: String? = null
    // Practice mode hides previously saved answers so a question can be actively recalled again.
    private var practiceMode = false
    private var practiceAnsweredKey: String? = null
    private var bankName: String = "QBank"
    private lateinit var bankNameView: TextView
    private var gestureDownX = 0f
    private var gestureDownY = 0f

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = QBankDb(this)
        store = ProgressStore(this)
        title = intent.getStringExtra("title") ?: "QBank"
        testId = intent.getStringExtra("testId") ?: ""
        questionCount = db.questionCount(testId)
        sourceId = db.sourceIdForTest(testId)
        val requested = intent.getIntExtra("position", -1)
        pos = (if (requested >= 0) requested else store.position(testId)).coerceIn(0, (questionCount - 1).coerceAtLeast(0))
        val ui = getSharedPreferences("ui", MODE_PRIVATE)
        fontScale = ui.getFloat("quiz_font_scale", 1f).coerceIn(.85f, 1.25f)
        fontFamily = ui.getString("quiz_font_family", "sans-serif") ?: "sans-serif"
        headerMm = ui.getFloat("quiz_header_mm", 10f).coerceIn(7f, 13f)
        sectionLabel = intent.getStringExtra("sectionLabel")
        practiceMode = intent.getBooleanExtra("practiceMode", false)
        bankName = db.sourceNameForTest(intent.getStringExtra("testId") ?: "") ?: "QBank"
        setContentView(build())
        SystemUi.immersive(this)
        show()
    }

    override fun onStop(){ BackupManager(this).flushCloudBackup(); super.onStop() }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { gestureDownX = ev.rawX; gestureDownY = ev.rawY }
            MotionEvent.ACTION_UP -> {
                val dx = ev.rawX - gestureDownX
                val dy = ev.rawY - gestureDownY
                if (kotlin.math.abs(dx) > dp(72) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                    if (dx < 0 && pos < questionCount - 1) { pos++; savePosition(); show(); return true }
                    if (dx > 0 && pos > 0) { pos--; savePosition(); show(); return true }
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onPause() {
        savePosition()
        super.onPause()
    }

    private fun savePosition() {
        if (::store.isInitialized && testId.isNotBlank()) store.setPosition(testId, pos, sourceId, bankName)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) SystemUi.immersive(this)
    }

    private fun build(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ThemeManager.bg(this@QuizActivity))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(18, 55, 86))
            clipToPadding = false
        }
        SystemUi.padTopInset(top, 8, 8, 12, 12)

        val back = headerButton("←", 24f) { finish() }
        top.addView(back, LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(0, 0, dp(8), 0) })

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply {
            text = title
            textSize = 18f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, dp(4), 0)
        }
        titleBox.addView(tv, LinearLayout.LayoutParams(-1, dp(26)))
        val subRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bankNameView = TextView(this).apply {
            text = bankName
            textSize = 11f
            setTextColor(Color.rgb(210, 231, 242))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        subRow.addView(bankNameView, LinearLayout.LayoutParams(0, dp(24), 1f))
        sectionChip = TextView(this).apply {
            textSize = 10f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(25, 74, 94))
            gravity = Gravity.CENTER
            setPadding(dp(9), 0, dp(9), 0)
        }
        subRow.addView(sectionChip, LinearLayout.LayoutParams(-2, dp(22)).apply { setMargins(dp(6), 0, 0, 0) })
        titleBox.addView(subRow, LinearLayout.LayoutParams(-1, dp(24)))
        top.addView(titleBox, LinearLayout.LayoutParams(0, -1, 1f))

        settingsButton = headerButton("⚙", 20f) { showSettingsMenu(settingsButton) }
        top.addView(settingsButton, LinearLayout.LayoutParams(dp(50), dp(50)).apply { setMargins(dp(4), 0, 0, 0) })
        top.minimumHeight = headerHeightPx()
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val infoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(1), dp(18), dp(1))
            setBackgroundColor(ThemeManager.elevated(this@QuizActivity))
        }
        counter = TextView(this).apply {
            textSize = 14f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.text(this@QuizActivity))
            gravity = Gravity.CENTER_VERTICAL
        }
        infoRow.addView(counter, LinearLayout.LayoutParams(0, dp(22), 1f))
        jumpButton = TextView(this).apply {
            textSize = 14f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.accent(this@QuizActivity))
            gravity = Gravity.CENTER
            background = rounded(if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) Color.rgb(31,55,76) else Color.rgb(220,241,244), 10f)
            elevation = dp(2).toFloat()
            setOnClickListener { showQuestionJumpMenu(this) }
            contentDescription = "Jump to question"
        }
        infoRow.addView(jumpButton, LinearLayout.LayoutParams(dp(34), dp(22)).apply { setMargins(dp(16), 0, 0, 0) })
        root.addView(infoRow)

        scroll = LockedScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setBackgroundColor(ThemeManager.panel(this@QuizActivity))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(30))
            setBackgroundColor(ThemeManager.panel(this@QuizActivity))
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        result = TextView(this).apply {
            setPadding(dp(20), dp(10), dp(20), dp(10))
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setBackgroundColor(Color.rgb(238, 246, 251))
            visibility = View.GONE
        }
        root.addView(result)
        return root
    }

    private fun headerButton(label: String, size: Float, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(31,43,58) else Color.rgb(28,70,103), 12f)
        setOnClickListener { click() }
        isClickable = true
        isFocusable = true
    }

    private fun actionButton(label: String, color: Int, size: Float = 13f, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(ThemeManager.text(this@QuizActivity))
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = bookmarkPopupDrawable(color)
        elevation = dp(3).toFloat()
        setPadding(dp(8), 0, dp(8), 0)
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun optionCard(q: Question, option: Option, answered: Boolean) {
        val correct = option.correct ||
            q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
        val selected = answered && store.selected(q.stableKey)?.equals(option.label, true) == true
        val bg = when {
            !answered -> ThemeManager.optionBg(this@QuizActivity)
            correct -> ThemeManager.correctBg(this@QuizActivity)
            selected -> ThemeManager.wrongBg(this@QuizActivity)
            else -> ThemeManager.elevated(this@QuizActivity)
        }
        val fg = when {
            !answered -> ThemeManager.optionText(this@QuizActivity)
            correct -> ThemeManager.correctText(this@QuizActivity)
            selected -> ThemeManager.wrongText(this@QuizActivity)
            else -> ThemeManager.muted(this@QuizActivity)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = if (answered) dp(72) else dp(86)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(bg, 20f)
            isClickable = !answered
            isFocusable = !answered
            if (!answered) setOnClickListener { answer(option.label) }
        }
        val letter = TextView(this).apply {
            text = option.label
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(if (!answered) (if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) Color.rgb(43,60,79) else Color.rgb(207,224,240)) else bg, 50f)
        }
        row.addView(letter, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(0, 0, dp(14), 0) })
        val text = TextView(this).apply {
            this.text = toSpanned(option.text)
            textSize = 17.5f * fontScale
            setTypeface(Typeface.create(fontFamily, Typeface.NORMAL))
            setTextColor(fg)
            gravity = Gravity.CENTER_VERTICAL
            setLineSpacing(0f, 1.16f)
        }
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(7), 0, dp(7)) })
    }

    private fun answer(label: String) {
        val q = currentQuestion ?: return
        if (!practiceMode && store.status(q.stableKey) != null) return
        val selected = q.options.firstOrNull { it.label.equals(label, true) }
        val correct = selected?.correct == true ||
            q.correctAnswer?.trim()?.equals(label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(label.trim() + ".", true) == true
        store.setAnswer(q.stableKey, label, if (correct) "correct" else "wrong")
        practiceAnsweredKey = if (practiceMode) q.stableKey else null
        show()
        scroll.post { scroll.smoothScrollTo(0, 0) }
    }

    private fun show() {
        content.removeAllViews()
        if (questionCount == 0) {
            counter.text = "No questions imported"
            addHtmlText("<h2>No questions</h2><p>Import a QBank HTML file first.</p>", 20f)
            result.visibility = View.GONE
            scroll.locked = true
            return
        }
        val q = db.questionAt(testId, pos)
        if (q == null) { counter.text = "Question unavailable"; return }
        currentQuestion = q
        savePosition()
        val status = store.status(q.stableKey)
        val answered = if (practiceMode) practiceAnsweredKey == q.stableKey else status != null
        counter.text = "Question ${pos + 1} / ${questionCount}"
        jumpButton.text = (pos + 1).toString()
        // The question area must remain scrollable even before answering, especially for image-based questions.
        // Explanations are only added after an answer, so there is nothing to reveal prematurely.
        scroll.locked = false
        scroll.isVerticalScrollBarEnabled = answered
        updateSectionChip(q, status)

        val bm = TextView(this).apply {
            textSize = 13.5f
            setTextColor(ThemeManager.text(this@QuizActivity))
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            elevation = dp(5).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            background = bookmarkGradient()
            setOnClickListener { showBookmarkMenu(this) }
        }
        updateBookmarkButton(q, bm)
        bookmarkButton = bm

        addHtmlText(q.text, 20f * fontScale, true)
        q.questionImages.forEach { addImage(it) }
        q.options.forEach { optionCard(q, it, answered) }

        // Keep bookmarking near the lower-left of the question content, after the options.
        // This avoids competing with the question counter/jump control at the top.
        content.addView(bm, LinearLayout.LayoutParams(-2, dp(46)).apply {
            gravity = Gravity.END
            setMargins(0, dp(8), dp(4), dp(14))
        })

        if (answered) {
            result.visibility = View.VISIBLE
            result.text = if (status == "correct") "✓  Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}"
            else "✗  Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}"
            result.setTextColor(if (status == "wrong") ThemeManager.wrongText(this@QuizActivity) else ThemeManager.correctText(this@QuizActivity))
            result.setBackgroundColor(if (status == "wrong") ThemeManager.wrongBg(this@QuizActivity) else ThemeManager.correctBg(this@QuizActivity))
            val explanationPanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(8))
                background = rounded(ThemeManager.explanationBg(this@QuizActivity), 16f)
            }
            val explanationTitle = TextView(this).apply {
                text = "EXPLANATION"
                textSize = 13f * fontScale
                setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
                setTextColor(ThemeManager.explanationTitle(this@QuizActivity))
            }
            explanationPanel.addView(explanationTitle, LinearLayout.LayoutParams(-1, dp(28)))
            content.addView(explanationPanel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(4)) })
            addHtmlText(q.explanation ?: "<p>No explanation available.</p>", 17f * fontScale, false, ThemeManager.text(this@QuizActivity))
            q.explanationImages.forEach { addImage(it) }
        } else {
            result.visibility = View.GONE
        }
        scroll.post { scroll.scrollTo(0, 0) }
    }

    private fun updateSectionChip(q: Question, status: String?) {
        val raw = sectionLabel?.trim()?.takeIf { it.isNotBlank() && !it.equals("practice", true) } ?: when {
            store.bookmark(q.stableKey) != null -> bookmarkLabel(store.bookmark(q.stableKey)!!)
            status == "wrong" -> "Wrong"
            status == "correct" -> "Solved"
            else -> "Unsolved"
        }
        sectionChip.text = raw.uppercase()
        val bg = when (raw.lowercase()) {
            "important" -> Color.rgb(246, 235, 199)
            "revise" -> Color.rgb(222, 237, 251)
            "doubt" -> Color.rgb(237, 224, 247)
            "favourite", "favorite" -> Color.rgb(249, 222, 232)
            "wrong" -> Color.rgb(252, 224, 228)
            "solved" -> Color.rgb(221, 243, 230)
            else -> Color.rgb(226, 239, 244)
        }
        sectionChip.background = rounded(bg, 12f)
    }

    private fun applyHeaderHeight() {
        val root = window.decorView.findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0) as? ViewGroup
        root?.getChildAt(0)?.minimumHeight = headerHeightPx()
    }

    private fun headerHeightPx(): Int {
        val dpi = resources.displayMetrics.densityDpi.toFloat()
        val px = dpi * (headerMm / 25.4f)
        return px.toInt().coerceIn(dp(56), dp(104))
    }

    private fun showQuestionJumpMenu(anchor: View) {
        if (questionCount == 0) return
        val popup = PopupWindow(this).apply {
            width = dp(290)
            height = dp(190)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(ThemeManager.elevated(this@QuizActivity)); cornerRadius = dp(20).toFloat(); setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(55,69,86) else Color.rgb(210,223,231)) }
        }
        val heading = TextView(this).apply {
            text = "Jump to question"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.text(this@QuizActivity))
        }
        box.addView(heading, LinearLayout.LayoutParams(-1, dp(28)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 17f
            gravity = Gravity.CENTER
            setSingleLine(true)
            setSelectAllOnFocus(true)
            hint = "1 – ${questionCount}"
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(ThemeManager.optionBg(this@QuizActivity), 12f)
        }
        input.setText((pos + 1).toString())
        row.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val go = actionButton("GO", Color.rgb(27, 128, 91), 14f) {
            val n = input.text.toString().toIntOrNull()
            if (n != null && n in 1..questionCount) {
                pos = n - 1
                savePosition()
                popup.dismiss()
                show()
            } else input.error = "Enter 1–${questionCount}"
        }
        row.addView(go, LinearLayout.LayoutParams(dp(78), dp(52)).apply { setMargins(dp(10), 0, 0, 0) })
        box.addView(row, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(8), 0, 0) })
        val hint = TextView(this).apply {
            text = "Swipe left/right to move one question"
            textSize = 12f
            setTextColor(ThemeManager.muted(this@QuizActivity))
            gravity = Gravity.CENTER
        }
        box.addView(hint, LinearLayout.LayoutParams(-1, dp(28)).apply { setMargins(0, dp(5), 0, 0) })
        popup.contentView = box
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(12), (loc[1] + dp(48)).coerceAtLeast(dp(50)))
        box.startAnimation(ScaleAnimation(.94f, 1f, .94f, 1f, 1f, 0f).apply { duration = 160 })
        input.requestFocus()
        input.post { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun showSettingsMenu(anchor: View) {
        val popup = PopupWindow(this).apply {
            width = dp(320)
            height = dp(485)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(this@QuizActivity))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(55,69,86) else Color.rgb(210,223,231))
            }
        }
        val heading = TextView(this).apply {
            text = "Reading settings"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.text(this@QuizActivity))
        }
        box.addView(heading, LinearLayout.LayoutParams(-1, dp(30)))

        val fs = TextView(this).apply {
            text = "Font size"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(10), 0, dp(2))
        }
        box.addView(fs)
        val fsValue = TextView(this).apply {
            textSize = 13f
            setTextColor(ThemeManager.accent(this@QuizActivity))
            gravity = Gravity.CENTER_VERTICAL
        }
        box.addView(fsValue, LinearLayout.LayoutParams(-1, dp(24)))
        val seek = SeekBar(this).apply {
            max = 30
            progress = ((fontScale.coerceIn(.85f, 1.15f) - .85f) * 100f).toInt()
            setPadding(dp(4), 0, dp(4), 0)
        }
        fun fontText(p: Int) = "${85 + p}%  •  ${when { p < 10 -> "Small"; p < 18 -> "Medium"; p < 27 -> "Large"; else -> "Extra large" }}"
        fsValue.text = fontText(seek.progress)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { fsValue.text = fontText(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                fontScale = (.85f + seek.progress / 100f).coerceIn(.85f, 1.15f)
                getSharedPreferences("ui", MODE_PRIVATE).edit().putFloat("quiz_font_scale", fontScale).apply()
                show()
            }
        })
        box.addView(seek, LinearLayout.LayoutParams(-1, dp(46)))

        val ft = TextView(this).apply {
            text = "Font type"
            textSize = 14f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(8), 0, dp(4))
        }
        box.addView(ft)
        val fonts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("sans-serif" to "Sans", "serif" to "Serif", "monospace" to "Mono").forEach { pair ->
            val b = TextView(this).apply {
                text = pair.second
                textSize = 12.5f
                gravity = Gravity.CENTER
                setTextColor(ThemeManager.text(this@QuizActivity))
                background = rounded(if (fontFamily == pair.first) ThemeManager.explanationBg(this@QuizActivity) else ThemeManager.elevated(this@QuizActivity), 12f)
                setOnClickListener {
                    fontFamily = pair.first
                    getSharedPreferences("ui", MODE_PRIVATE).edit().putString("quiz_font_family", fontFamily).apply()
                    popup.dismiss()
                    show()
                }
            }
            fonts.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply { if (pair.first != "sans-serif") setMargins(dp(5),0,0,0) })
        }
        box.addView(fonts, LinearLayout.LayoutParams(-1, dp(42)))

        val hs = TextView(this).apply {
            text = "Header height"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(10), 0, dp(4))
        }
        box.addView(hs)
        val heights = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(8f, 10f, 12f, 13f).forEach { mm ->
            val b = TextView(this).apply {
                text = "${mm.toInt()} mm"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(ThemeManager.text(this@QuizActivity))
                background = rounded(if (kotlin.math.abs(headerMm-mm)<.01f) ThemeManager.explanationBg(this@QuizActivity) else ThemeManager.elevated(this@QuizActivity), 12f)
                setOnClickListener {
                    headerMm = mm
                    getSharedPreferences("ui", MODE_PRIVATE).edit().putFloat("quiz_header_mm", mm).apply()
                    popup.dismiss()
                    savePosition()
                    applyHeaderHeight()
                    // Keep the exact current question; changing UI settings must never reset position.
                    pos = store.position(testId).coerceIn(0, (questionCount - 1).coerceAtLeast(0))
                }
            }
            heights.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(if (mm == 8f) 0 else dp(4), 0, 0, 0) })
        }
        box.addView(heights, LinearLayout.LayoutParams(-1, dp(46)))

        val ap = TextView(this).apply { text = "Appearance"; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(Color.rgb(80,94,110)); setPadding(0, dp(10), 0, dp(4)) }
        box.addView(ap)
        val themes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(ThemeManager.LIGHT to "Light", ThemeManager.DARK to "Dark", ThemeManager.SEPIA to "Sepia").forEach { pair ->
            val b = TextView(this).apply { text = pair.second; textSize = 12f; gravity = Gravity.CENTER; setTextColor(ThemeManager.text(this@QuizActivity)); background = rounded(if (ThemeManager.get(this@QuizActivity)==pair.first) ThemeManager.explanationBg(this@QuizActivity) else ThemeManager.elevated(this@QuizActivity), 12f); setOnClickListener { ThemeManager.set(this@QuizActivity,pair.first); popup.dismiss(); recreate() } }
            themes.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply { if (pair.first != ThemeManager.LIGHT) setMargins(dp(5),0,0,0) })
        }
        box.addView(themes, LinearLayout.LayoutParams(-1, dp(42)))

        val note = TextView(this).apply {
            text = "Font size is continuous (85–115%) so larger text remains usable with scrolling."
            textSize = 11.5f
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(12), 0, 0)
        }
        box.addView(note, LinearLayout.LayoutParams(-1, dp(42)))

        popup.contentView = box
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(10), (loc[1] + dp(54)).coerceAtLeast(dp(40)))
        box.startAnimation(ScaleAnimation(.94f,1f,.94f,1f,1f,0f).apply{duration=160})
    }

    private fun updateBookmarkButton(q: Question, button: TextView) {
        val value = store.bookmark(q.stableKey)
        if (value.isNullOrBlank()) {
            button.text = "🔖  Bookmark"
            button.setTextColor(ThemeManager.text(this@QuizActivity))
        } else {
            button.text = "🔖  ${bookmarkLabel(value)}"
            button.setTextColor(ThemeManager.bookmarkText(this, value))
            button.background = rounded(ThemeManager.bookmarkFill(this, value), 20f)
        }
    }

    private fun bookmarkLabel(value: String) = when (value) {
        "important" -> "Important"
        "revise" -> "Revise"
        "doubt" -> "Doubt"
        "favorite" -> "Favourite"
        else -> "Bookmark"
    }

    private fun addHtmlText(html: String?, size: Float, bold: Boolean = false, color: Int? = null) {
        val raw = html ?: ""
        val imageSrcs = Regex("<img\\s+[^>]*src\\s*=\\s*[\"']([^\"']+)[^>]*>", RegexOption.IGNORE_CASE)
            .findAll(raw).map { it.groupValues[1] }.toList()
        val cleaned = raw.replace(Regex("<img\\s+[^>]*>", RegexOption.IGNORE_CASE), "<p></p>")
        val t = TextView(this).apply {
            text = toSpanned(cleaned)
            textSize = size
            setTextColor(color ?: ThemeManager.text(this@QuizActivity))
            setLineSpacing(0f, 1.25f)
            setPadding(0, 0, 0, dp(14))
            setTypeface(Typeface.create(fontFamily, if (bold) Typeface.BOLD else Typeface.NORMAL), if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
        imageSrcs.forEach { addImage(it) }
    }

    private fun toSpanned(value: String): Spanned {
        val html = if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) {
            value
                .replace(Regex("<font\\b[^>]*>", RegexOption.IGNORE_CASE), "")
                .replace(Regex("</font>", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\s+(?:color|bgcolor)\\s*=\\s*['\"][^'\"]*['\"]", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\s+style\\s*=\\s*['\"][^'\"]*(?:color|background-color)[^'\"]*['\"]", RegexOption.IGNORE_CASE), "")
        } else value
        return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
    }

    private fun addImage(uri: String) {
        val raw = uri.trim()
        if (raw.isBlank()) return
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, dp(6), 0, dp(10))
            minimumHeight = dp(28)
            contentDescription = "Question image"
        }
        content.addView(image, LinearLayout.LayoutParams(-1, -2))
        Thread {
            try {
                val bitmap = decodeScaledImage(raw, dp(1000), dp(1600))
                if (bitmap != null) runOnUiThread { if (!isFinishing && !isDestroyed) image.setImageBitmap(bitmap) }
            } catch (_: Throwable) { }
        }.start()
    }

    private fun decodeScaledImage(value: String, maxW: Int, maxH: Int): android.graphics.Bitmap? {
        var uri = value.trim().replace("\\/", "/")
        if (uri.startsWith("url(", true)) uri = uri.substringAfter('(').substringBeforeLast(')').trim().trim('"', '\'')
        if (uri.startsWith("data:image", true)) {
            val comma = uri.indexOf(',')
            if (comma < 0) return null
            val payload = uri.substring(comma + 1)
            val data = android.util.Base64.decode(payload, android.util.Base64.DEFAULT)
            return decodeBytes(data, maxW, maxH)
        }
        val parsed = Uri.parse(uri)
        fun open(): java.io.InputStream? {
            return when (parsed.scheme?.lowercase()) {
                "http", "https" -> java.net.URL(uri).openConnection().let { c -> c.connectTimeout=10000; c.readTimeout=15000; c.getInputStream() }
                "content", "file" -> contentResolver.openInputStream(parsed)
                else -> null
            }
        }
        open()?.use { input ->
            val bytes = input.readBytes()
            return decodeBytes(bytes, maxW, maxH)
        }
        return null
    }

    private fun decodeBytes(data: ByteArray, maxW: Int, maxH: Int): android.graphics.Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxW || bounds.outHeight / sample > maxH) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize=sample; inPreferredConfig=android.graphics.Bitmap.Config.RGB_565; inScaled=true }
        return BitmapFactory.decodeByteArray(data, 0, data.size, opts)
    }

    private fun showBookmarkMenu(anchor: View) {
        if (questionCount == 0) return
        val popup = PopupWindow(this).apply {
            width = dp(336)
            height = dp(276)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(this@QuizActivity))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(55,69,86) else Color.rgb(205,220,231))
            }
            elevation = dp(8).toFloat()
        }
        val titleView = TextView(this).apply {
            text = "Bookmark category"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.text(this@QuizActivity))
            setPadding(dp(6), dp(2), dp(6), dp(10))
        }
        box.addView(titleView)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val values = listOf(
            "important" to "★  Important",
            "revise" to "↻  Revise",
            "doubt" to "❔  Doubt",
            "favorite" to "♥  Favourite"
        )
        for (r in 0..1) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..1) {
                val pair = values[r * 2 + c]
                val b = actionButton(pair.second, bookmarkColor(pair.first), 14.5f) {
                    currentQuestion?.let { q -> store.setBookmark(q.stableKey, pair.first) }
                    savePosition()
                    popup.dismiss()
                    show()
                }
                b.setTextColor(ThemeManager.bookmarkText(this@QuizActivity, pair.first))
                row.addView(b, LinearLayout.LayoutParams(0, dp(82), 1f).apply {
                    setMargins(if (c == 0) 0 else dp(6), dp(4), if (c == 0) dp(6) else 0, dp(4))
                })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, dp(90)))
        }
        box.addView(grid)
        popup.contentView = box
        popup.setOnDismissListener { }
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(10), popupTopY(anchor))
        val anim = AnimationSet(true).apply {
            addAnimation(ScaleAnimation(.92f, 1f, .92f, 1f, 1f, .5f).apply { duration = 170 })
            addAnimation(AlphaAnimation(.25f, 1f).apply { duration = 170 })
        }
        box.startAnimation(anim)
    }

    private fun popupTopY(anchor: View): Int {
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        return (loc[1] + dp(8)).coerceAtLeast(dp(44))
    }

    private fun bookmarkGradient() = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(19, 111, 151), Color.rgb(27, 157, 117))).apply { cornerRadius = dp(24).toFloat() }

    private fun bookmarkColor(v: String) = ThemeManager.bookmarkFill(this@QuizActivity, v)

    private fun bookmarkPopupDrawable(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(75,88,105) else Color.rgb(205,215,225))
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius * resources.displayMetrics.density
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

/** Prevents accidental vertical scrolling while the user is still answering. */
private class LockedScrollView(context: android.content.Context) : ScrollView(context) {
    var locked: Boolean = false
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onInterceptTouchEvent(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onTouchEvent(ev)
}
