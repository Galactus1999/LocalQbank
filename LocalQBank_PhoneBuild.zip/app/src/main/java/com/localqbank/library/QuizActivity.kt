package com.localqbank.library

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var store: ProgressStore
    private lateinit var qs: List<Question>
    private var pos = 0
    private lateinit var title: String
    private lateinit var content: LinearLayout
    private lateinit var counter: TextView
    private lateinit var result: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = QBankDb(this)
        store = ProgressStore(this)
        title = intent.getStringExtra("title") ?: "QBank"
        qs = db.questions(intent.getStringExtra("testId") ?: "")
        pos = intent.getIntExtra("position", 0).coerceIn(0, (qs.size - 1).coerceAtLeast(0))
        setContentView(build())
        SystemUi.immersive(this)
        show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) SystemUi.immersive(this)
    }

    private fun build(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 252))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 7, 8, 7)
            setBackgroundColor(Color.rgb(22, 72, 112))
        }
        val tv = TextView(this).apply {
            text = title
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 2
        }
        top.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton("Back", Color.rgb(48, 105, 151)) { finish() }, LinearLayout.LayoutParams(82, 44))
        root.addView(top)

        counter = TextView(this).apply {
            setPadding(14, 8, 14, 8)
            textSize = 13f
            setTextColor(Color.rgb(54, 76, 101))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(counter)

        scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setBackgroundColor(Color.WHITE)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 22)
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(content, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        result = TextView(this).apply {
            setPadding(14, 8, 14, 8)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setBackgroundColor(Color.rgb(238, 246, 251))
            visibility = View.GONE
        }
        root.addView(result)

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(7, 5, 7, 6)
            setBackgroundColor(Color.WHITE)
        }
        nav.addView(actionButton("‹ Previous", Color.rgb(77, 96, 117)) { if (pos > 0) { pos--; show() } }, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        nav.addView(actionButton("Next ›", Color.rgb(29, 132, 91)) { if (pos < qs.lastIndex) { pos++; show() } }, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        lateinit var bm: Button
        bm = actionButton("🔖 Bookmark", Color.rgb(82, 67, 137)) { showBookmarkMenu(bm) }
        nav.addView(bm, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        nav.addView(actionButton("Review", Color.rgb(45, 96, 143)) {
            if (qs.isNotEmpty()) { val q = qs[pos]; store.setReview(q.stableKey, !store.review(q.stableKey)); show() }
        }, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(2, 0, 2, 0) })
        root.addView(nav)
        return root
    }

    private fun actionButton(label: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        setTextColor(Color.WHITE)
        background = rounded(color, 12f)
        stateListAnimator = null
        minHeight = 44
        minimumHeight = 44
        setPadding(6, 0, 6, 0)
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun optionCard(q: Question, option: Option, answered: Boolean) {
        val correct = option.correct ||
            q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
        val selected = store.selected(q.stableKey)?.equals(option.label, true) == true

        val bg = when {
            !answered -> Color.rgb(231, 241, 250)
            correct -> Color.rgb(220, 244, 228)
            selected -> Color.rgb(252, 226, 230)
            else -> Color.rgb(241, 244, 248)
        }
        val fg = when {
            !answered -> Color.rgb(18, 39, 61)
            correct -> Color.rgb(17, 91, 54)
            selected -> Color.rgb(137, 36, 52)
            else -> Color.rgb(91, 105, 121)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = 62
            setPadding(12, 8, 12, 8)
            background = rounded(bg, 18f)
            isClickable = !answered
            isFocusable = !answered
            if (!answered) setOnClickListener { answer(option.label) }
        }

        val letter = TextView(this).apply {
            text = option.label
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(if (!answered) Color.rgb(207, 224, 240) else bg, 50f)
        }
        row.addView(letter, LinearLayout.LayoutParams(48, 48).apply { setMargins(0, 0, 12, 0) })

        val text = TextView(this).apply {
            this.text = toSpanned(option.text)
            textSize = 16f
            setTextColor(fg)
            gravity = Gravity.CENTER_VERTICAL
            setLineSpacing(0f, 1.1f)
        }
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))

        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 7, 0, 7) })
    }

    private fun answer(label: String) {
        if (qs.isEmpty()) return
        val q = qs[pos]
        if (store.status(q.stableKey) != null) return
        val selected = q.options.firstOrNull { it.label.equals(label, true) }
        val correct = selected?.correct == true ||
            q.correctAnswer?.trim()?.equals(label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(label.trim() + ".", true) == true
        store.setAnswer(q.stableKey, label, if (correct) "correct" else "wrong")
        show()
        scroll.post { scroll.smoothScrollTo(0, 0) }
    }

    private fun show() {
        content.removeAllViews()
        if (qs.isEmpty()) {
            counter.text = "No questions imported"
            addHtmlText("<h2>No questions</h2><p>Import a QBank HTML file first.</p>", 18f)
            result.visibility = View.GONE
            return
        }
        val q = qs[pos]
        val status = store.status(q.stableKey)
        val answered = status != null
        counter.text = "Question ${pos + 1} / ${qs.size}"
        addHtmlText(q.text, 18f, true)
        q.questionImages.forEach { addImage(it) }
        q.options.forEach { optionCard(q, it, answered) }

        if (answered) {
            result.visibility = View.VISIBLE
            result.text = if (status == "correct") "✓ Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}" else "✗ Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}"
            result.setTextColor(if (status == "wrong") Color.rgb(150, 38, 55) else Color.rgb(31, 96, 69))
            addHtmlText("<h2>Explanation</h2>${q.explanation ?: "<p>No explanation available.</p>"}", 16f)
            q.explanationImages.forEach { addImage(it) }
        } else {
            result.visibility = View.GONE
            val hint = TextView(this).apply {
                text = "Select an option to reveal the answer and full explanation."
                textSize = 13f
                setTextColor(Color.rgb(86, 101, 121))
                setPadding(14, 14, 14, 14)
                background = rounded(Color.rgb(242, 245, 249), 16f)
            }
            content.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 10) })
        }
        scroll.post { scroll.scrollTo(0, 0) }
    }

    private fun addHtmlText(html: String?, size: Float, bold: Boolean = false, color: Int = Color.rgb(21, 38, 59)) {
        val t = TextView(this).apply {
            text = toSpanned(html ?: "")
            textSize = size
            setTextColor(color)
            setLineSpacing(0f, 1.18f)
            setPadding(0, 0, 0, 9)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun toSpanned(value: String): Spanned = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)

    private fun addImage(uri: String) {
        val image = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(0, 6, 0, 10) }
        try {
            val parsed = android.net.Uri.parse(uri)
            if (parsed.scheme == "data") {
                val comma = uri.indexOf(',')
                if (comma > 0) {
                    val data = android.util.Base64.decode(uri.substring(comma + 1), android.util.Base64.DEFAULT)
                    image.setImageBitmap(android.graphics.BitmapFactory.decodeByteArray(data, 0, data.size))
                }
            } else image.setImageURI(parsed)
            content.addView(image, LinearLayout.LayoutParams(-1, -2))
        } catch (_: Exception) { }
    }

    private fun showBookmarkMenu(anchor: View) {
        if (qs.isEmpty()) return
        val popup = PopupWindow(this).apply {
            width = (resources.displayMetrics.density * 200).toInt()
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            isOutsideTouchable = true
            elevation = resources.displayMetrics.density * 8
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.WHITE))
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8); background = rounded(Color.WHITE, 14f) }
        listOf("important" to "★  Important", "revise" to "↻  Revise", "doubt" to "❔  Doubt", "favorite" to "♥  Favourite").forEach { (value, label) ->
            val b = actionButton(label, bookmarkColor(value)) { store.setBookmark(qs[pos].stableKey, value); popup.dismiss(); show() }
            box.addView(b, LinearLayout.LayoutParams(-1, 46).apply { setMargins(0, 3, 0, 3) })
        }
        popup.contentView = box
        popup.showAsDropDown(anchor, -155, -240)
    }

    private fun bookmarkColor(v: String) = when (v) {
        "important" -> Color.rgb(138, 90, 0)
        "revise" -> Color.rgb(37, 99, 166)
        "doubt" -> Color.rgb(122, 63, 145)
        else -> Color.rgb(177, 58, 84)
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius * resources.displayMetrics.density }
}
