# Build the APK using only your Android phone

1. Create/sign in to a GitHub account.
2. On GitHub, create a new repository, e.g. `LocalQBank`.
3. Extract this ZIP on your phone. Upload all project files/folders to the repository. Make sure `.github/workflows/build-apk.yml` is uploaded too.
4. Open the repository → **Actions** → **Build Android APK**.
5. Tap **Run workflow** (or push to `main` to trigger it automatically).
6. Wait for the workflow to finish with a green check.
7. Open the completed workflow run → **Artifacts** → `LocalQBank-debug-apk` → download the ZIP.
8. Extract it and install `app-debug.apk` on your phone.

The build uses GitHub's hosted Linux runner, JDK 17 and Gradle 8.9. Android's official documentation confirms that Gradle/Android Gradle Plugin are the build system used to compile and package APKs.
