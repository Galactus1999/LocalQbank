# LocalQBank PhoneBuild v6

Import-only Android QBank app.

- No QBank HTML files bundled.
- No preloaded QBank database.
- Import HTML QBanks from the phone.
- Adaptive extraction for TESTS_LIST, questions/questionData/testsData, and nested iframe/srcdoc structures.
- Native question solving and scrolling explanation view.
- Global dashboard: solved, wrong, unsolved, bookmarked.
- Global bookmark collections: Important, Revise, Doubt, Favourite.
- Delete imported QBanks from the app.
- GitHub Actions builds `app-debug.apk`.

Expected repository ZIP name: `LocalQBank_PhoneBuild.zip`.
