# LocalQBank PhoneBuild v6.2

Phone-first Android QBank app for importing and solving local HTML question banks.

- No QBank HTML files bundled.
- No preloaded QBank database.
- Import HTML QBanks from the phone.
- Adaptive extraction for TESTS_LIST, questions/questionData/testsData and nested iframe/srcdoc structures.
- Native question solving with large question/options cards.
- Before answering, the question view is locked at the top so the answer choices fill the usable screen.
- After answering, the explanation is revealed and the question view becomes vertically scrollable.
- Bottom navigation is exactly Previous | Bookmark | Next, with Next at the far right.
- Bookmark selector is a large 2×2 grid: Important, Revise, Doubt, Favourite.
- Immersive fullscreen mode is applied to all activities.
- QBank deletion is available only through a long press followed by confirmation.
- Global solved/wrong/unsolved and bookmark tracking across imported QBanks.
- GitHub Actions builds `app-debug.apk`.

GitHub Actions uses Gradle 8.9 and Java 17.


## v6.2 UI update
- Fixed system-bar/header cutout across sections with inset-aware headers.
- Quiz bottom bar is Previous | Next; bookmark is a distinct blue-green floating action.
- Larger navigation controls and bookmark selector with animated right-side popup.
- Added persistent Small/Medium/Large/Extra-large quiz font-size control via Aa in the header.
- Long question/explanation text uses wider, consistent margins.


## v6.8 dashboard and progress refinements
- Bookmark category colors aligned across dashboard and quiz popup.
- Reduced dashboard card heights.
- Solved count is explicitly rendered on the dashboard.

## v6.4 quiz navigation
- Swipe left/right to move between questions.
- Tap the square question-number control to jump directly to any question.
- Quiz header includes a light section/category chip.
- Reading settings support font size and 7–13 mm header height presets.


## v6.8 performance/safety
- Quiz questions are loaded one at a time instead of loading an entire test into memory.
- Images are decoded off the UI thread at a bounded sample size.
- Test-list progress summaries are cached per row.
- Position, answer, bookmark and review state use synchronous SharedPreferences commits for crash-resistant persistence.
- Source/test Resume buttons reopen the last saved position.
- Dashboard QBank list is rendered inside the parent vertical ScrollView to avoid nested RecyclerView scrolling conflicts.
- SQLite WAL is enabled and Android largeHeap is requested for large imports.

## Q 7.5
- Global QBank search for sections/subsections, question text, options and explanations.
- Direct opening of a searched section or question.
- Immediate local progress commits remain the primary source of truth.
- Background versioned progress snapshots with rotating local copies.
- Optional Google Drive/cloud folder backup through Android's Storage Access Framework.
- Automatic delayed cloud backup after answer/bookmark/review changes plus periodic backup.
- Portable `.qbackup` export/restore with SHA-256 integrity verification.
- Android cloud/device-transfer backup includes progress/UI preferences but intentionally excludes the potentially huge QBank database.


## Q 7.11 Study System
- Smart spaced revision queue (1d / 3d / 7d / 14d / 30d)
- Weakest 50 questions
- Custom question-pool tests
- Timed exam mode
- Performance analytics
- PYQ-labelled question pool
- Per-question personal notes
- Collection sessions remain restricted to their selected pool while swiping
- Large-file importer and existing backup/search/theme systems preserved
