# Local QBank Library v3

This version treats the HTML as a **content source**, not as the user interface.

## Supported formats
- **DAMS Quiz Club**: detects `TESTS_LIST` / `ALL_TESTS`; each test becomes a collection.
- **CoreBTR**: detects `APP_DATA`; Subject > Lesson questions are flattened into selectable lessons.
- Generic fallback for HTML files exposing a `questions` array.

## Reader behavior
- One question at a time.
- Answers remain hidden until the user taps an option.
- Correct/wrong status is saved per question.
- Bookmark/star button on every question, even when the source HTML has no bookmark feature.
- Previous / Next / Back.
- Question navigation grid.
- Local progress per QBank.
- Last position restored.
- DAMS timer can be edited; set minutes to 0 for no timer.
- Images and HTML explanations are preserved where available.
- Original HTML dashboard/test UI is replaced by the app's reader UI.
- Android status-bar/safe-area handling is included so the header does not overlap the notification area.

## Important
The source files are **not bundled into the APK**. Add HTML files through Android's file picker. This keeps the APK small and allows additional QBanks later.

## Current limitation
The adapter currently recognizes the two structures analyzed in this project. Other HTML formats can be added with another adapter without changing the reader UI.
