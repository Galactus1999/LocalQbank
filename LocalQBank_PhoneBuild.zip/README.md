# QBank Pro 4.0

Adaptive Android HTML QBank reader and MCQ practice engine.

## What changed
- Professional home dashboard with **Solved / Unsolved / Wrong / Bookmarked** counters.
- **Questions solved today** and correct-today counter.
- Practice mode: choose All, Unsolved, Wrong or Bookmarked; choose session size; randomize; instant explanations.
- Test mode: create a timed test with a selectable question count, pool and optional -1/4 negative marking.
- Test question map and mark-for-review.
- Test result screen with score, correct, wrong and unattempted counts.
- Smart Practice: automatically mixes wrong + bookmarked + unsolved questions.
- Source HTML's original UI is ignored; the app renders its own UI.
- Adaptive importers for CoreBTR `APP_DATA`, DAMS/DocTutorials-style `TESTS_LIST`/`ALL_TESTS`, embedded `iframe[srcdoc]` quizzes, and generic question arrays.
- Rich question/explanation HTML and images are preserved where supplied by the source.
- Progress remains local to the phone.

## Build APK on GitHub
1. Replace the files in your existing repository with this project.
2. Commit and push to the `main` branch.
3. GitHub Actions will run **Build Android APK**.
4. Open the workflow run → **Artifacts** → download `QBank-Pro-v4.0`.

The included workflow uses Gradle 8.9 and Java 17 and builds a debug APK.
