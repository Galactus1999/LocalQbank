# LocalQBank PhoneBuild v6.2

Phone-first Android QBank app for importing and solving local HTML question banks.

- No QBank HTML files bundled.
- No preloaded QBank database.
- Import HTML QBanks from the phone.
- Adaptive extraction for TESTS_LIST, questions/questionData/testsData and nested iframe/srcdoc structures.
- Native question solving with large question/options cards.
- Before answering, the question view is locked at the top so the answer choices fill the usable screen.
- After answering, the explanation is revealed and the question view becomes vertically scrollable.
- Bottom navigation is exactly Previous | Bookmark | Next, with Next at the far right.
- Bookmark selector is a large 2×2 grid: Important, Revise, Doubt, Favourite.
- Immersive fullscreen mode is applied to all activities.
- QBank deletion is available only through a long press followed by confirmation.
- Global solved/wrong/unsolved and bookmark tracking across imported QBanks.
- GitHub Actions builds `app-debug.apk`.

GitHub Actions uses Gradle 8.9 and Java 17.


## v6.2 UI update
- Fixed system-bar/header cutout across sections with inset-aware headers.
- Quiz bottom bar is Previous | Next; bookmark is a distinct blue-green floating action.
- Larger navigation controls and bookmark selector with animated right-side popup.
- Added persistent Small/Medium/Large/Extra-large quiz font-size control via Aa in the header.
- Long question/explanation text uses wider, consistent margins.


## v6.3 quiz navigation
- Swipe left/right to move between questions.
- Tap the square question-number control to jump directly to any question.
- Quiz header includes a light section/category chip.
- Reading settings support font size and 7–13 mm header height presets.
