# LocalQBank PhoneBuild v6.2

Phone-first Android QBank app for importing and solving local HTML question banks.

- No QBank HTML files bundled.
- No preloaded QBank database.
- Import HTML QBanks from the phone.
- Adaptive extraction for TESTS_LIST, questions/questionData/testsData and nested iframe/srcdoc structures.
- Native question solving with large question/options cards.
- Before answering, the question view is locked at the top so the answer choices fill the usable screen.
- After answering, the explanation is revealed and the question view becomes vertically scrollable.
- Bottom navigation is exactly Previous | Bookmark | Next, with Next at the far right.
- Bookmark selector is a large 2×2 grid: Important, Revise, Doubt, Favourite.
- Immersive fullscreen mode is applied to all activities.
- QBank deletion is available only through a long press followed by confirmation.
- Global solved/wrong/unsolved and bookmark tracking across imported QBanks.
- GitHub Actions builds `app-debug.apk`.

GitHub Actions uses Gradle 8.9 and Java 17.


## v6.2 UI update
- Fixed system-bar/header cutout across sections with inset-aware headers.
- Quiz bottom bar is Previous | Next; bookmark is a distinct blue-green floating action.
- Larger navigation controls and bookmark selector with animated right-side popup.
- Added persistent Small/Medium/Large/Extra-large quiz font-size control via Aa in the header.
- Long question/explanation text uses wider, consistent margins.


## v6.8 dashboard and progress refinements
- Bookmark category colors aligned across dashboard and quiz popup.
- Reduced dashboard card heights.
- Solved count is explicitly rendered on the dashboard.

## v6.4 quiz navigation
- Swipe left/right to move between questions.
- Tap the square question-number control to jump directly to any question.
- Quiz header includes a light section/category chip.
- Reading settings support font size and 7–13 mm header height presets.


## v6.8 performance/safety
- Quiz questions are loaded one at a time instead of loading an entire test into memory.
- Images are decoded off the UI thread at a bounded sample size.
- Test-list progress summaries are cached per row.
- Position, answer, bookmark and review state use synchronous SharedPreferences commits for crash-resistant persistence.
- Source/test Resume buttons reopen the last saved position.
- Dashboard QBank list is rendered inside the parent vertical ScrollView to avoid nested RecyclerView scrolling conflicts.
- SQLite WAL is enabled and Android largeHeap is requested for large imports.

## Q 7.13.0

### Import compatibility update
- Supports combined HTML QBanks that wrap individual tests in `<iframe srcdoc>` documents.
- Supports QBank arrays assigned with either declared variables (`const APP_DATA = [...]`) or later assignments (`questions = [...]`).
- Traverses nested `APP_DATA -> folders -> lessons -> questions` structures such as CoreBTR-style exports.
- Recovers correct-option flags from answers stored as `A`, `B. option text`, or `C) option text`.
- Preserves question/explanation image URLs and falls back to DOM extraction per embedded document when structured data is unavailable.

## Q 7.12.2
- Dashboard app bar is compact and fixed-height; the previous oversized navy header is removed.
- Study is now a primary dashboard action instead of a header control.
- Today’s Revision and Study are thumb-friendly side-by-side square cards with dedicated icons and contrasting visual themes.
- Analytics is a larger interactive dashboard card with accuracy progress, attempted count and today’s revision queue.
- HTML importer has a broader DOM/script extraction fallback; additional unsupported HTML layouts can be adapted from sample files without changing the native quiz engine.

## Q 7.5
- Global QBank search for sections/subsections, question text, options and explanations.
- Direct opening of a searched section or question.
- Immediate local progress commits remain the primary source of truth.
- Background versioned progress snapshots with rotating local copies.
- Optional Google Drive/cloud folder backup through Android's Storage Access Framework.
- Automatic delayed cloud backup after answer/bookmark/review changes plus periodic backup.
- Portable `.qbackup` export/restore with SHA-256 integrity verification.
- Android cloud/device-transfer backup includes progress/UI preferences but intentionally excludes the potentially huge QBank database.


## Q 7.11 Study System
- Smart spaced revision queue (1d / 3d / 7d / 14d / 30d)
- Weakest 50 questions
- Custom question-pool tests
- Timed exam mode
- Performance analytics
- PYQ-labelled question pool
- Per-question personal notes
- Collection sessions remain restricted to their selected pool while swiping
- Large-file importer and existing backup/search/theme systems preserved

## v7.16.0 — Stability & Performance
- Prevent background AppState refreshes from rebuilding the dashboard while a quiz is active.
- Answer selection updates the existing question UI instead of rebuilding the entire question.
- Prefetches the next question and caches parsed HTML spans for smoother navigation.
- Flashcard APKG import uses checkpointed batch transactions, cancellation, crash recovery, per-item fault tolerance, and resumable imports.
- Flashcard media reference rewriting is linear per HTML fragment rather than repeatedly scanning the entire media map.
- Analytics redesigned as an interactive Performance Lab with actionable study queues and QBank focus mapping.


## v7.17.0 Flashcard overhaul
- High-speed reviewer with reverse, shuffle, swipe, custom study sets, session sizes, undo rating, bury, suspend and card information.
- Configurable local SRS settings and review statistics.
- Safer flashcard database migrations: failed column migrations now surface as errors instead of silently leaving a broken schema.
- Review history and previous-card state are persisted for reliable undo and statistics.
- Existing QBank database remains separate from flashcard storage.


## v7.18.0 — Local Adaptive Study Agent

Added a local-first Study Agent layer:
- `AgentDb.kt`: persistent SQLite memory for nodes, relationships and events.
- `StudyAgent.kt`: observe → learn → update mesh → recommend loop.
- `AgentActivity.kt`: interactive circular knowledge-mesh screen.
- `AgentHeartbeatWorker.kt`: Android/WorkManager background heartbeat within OS scheduling limits.
- Dashboard now exposes **AI Study Agent**.
- Opening and answering questions automatically feed the agent.
- The agent builds concept/question/test relationships and updates confidence from correct/wrong outcomes.
- No network or remote AI service is required for the agent core.

The current release is the adaptive-agent foundation. A local LLM/RAG layer can be added on top without replacing the mesh or memory layer.
