# Local QBank Library v2

## Goal

A standalone Android app for multiple large local HTML QBanks.

### Architecture

The APK contains only the app. Future HTML QBanks are NOT bundled.

Each HTML is registered with Android Storage Access Framework and opened from its original phone-storage URI.

This means adding a 200 MB / 500 MB / 1 GB HTML does not require rebuilding or enlarging the APK by that amount.

## QBank library

- Add QBank
- Open QBank
- Rename QBank
- Remove from library (does not delete source HTML)
- Persistent URI permission
- Independent QBank IDs

## Native progress mirror

A native SharedPreferences namespace is created per QBank.

For CoreBTR, the supplied HTML uses the localStorage prefix `corebtr_neetpg_` and stores:
- `prog`
- `bm`
- `mistakes`
- `theme`

The app mirrors these CoreBTR state blobs into Android storage every few seconds and again when the viewer is destroyed.

This gives a native backup copy of the CoreBTR progress without rewriting the original HTML.

## Important compatibility note

The CoreBTR HTML already performs its own saveState() to localStorage. Therefore the app does not need to modify the HTML to track normal CoreBTR answers/bookmarks/mistakes.

For other QBank formats, question/status synchronization needs a small adapter because HTML QBanks do not have a universal DOM/data format.

## Production version recommended

Next upgrades:
- SQLite/Room normalized question records
- Native dashboard showing exact counts
- Restore CoreBTR localStorage from native backup if browser/WebView storage is cleared
- Generic adapter detection
- Wrong/Bookmark/Unsolved revision generator
- Backup/restore all QBanks as one JSON file
- Last question per QBank
- Search/index
- Per-subject statistics
- Timed test engine
