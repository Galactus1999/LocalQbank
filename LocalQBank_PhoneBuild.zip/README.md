# Local QBank Library — Import Edition

This Android project does **not bundle any QBank HTML files**.

The app starts with an empty local SQLite database and lets you import HTML QBank files directly from an Android phone using **＋ Add QBank**.

## Supported import model

The importer is adaptive for the HTML structures currently supported by the project:

- `TESTS_LIST = [...]` style QBanks
- embedded `iframe` / `srcdoc` sections containing `questions = [...]`
- question objects containing text, options, correct answer, explanations, question images and explanation images

The original HTML quiz JavaScript is **not used to run the quiz**. It is only inspected during import to extract the question data. After import, the Android app stores normalized data in SQLite and the native quiz screen handles answering and progress.

## GitHub workflow

1. Upload this entire project to GitHub.
2. Build with `.github/workflows/build-apk.yml`.
3. Install the generated APK.
4. On the phone tap **＋ Add QBank** and select one or more `.html` files.
5. The imported QBank is stored locally in the app database.

No HTML files need to be placed in `app/src/main/assets`.

## Future QBanks

The Android project remains the same. New HTML files can be imported from the phone. If a future QBank uses a genuinely different JavaScript data model, update the importer adapter rather than replacing the Android quiz UI.


## v5.1 correction
- No QBank HTML files or preloaded question database are bundled.
- The app starts empty and imports HTML files selected from the Android file picker.
- Fixed the Android picker-to-import handoff.
- Fixed nullable `correctAnswer` Kotlin compilation errors.
- Improved JavaScript array extraction for `TESTS_LIST`, `questions`, `questionData`, and `testsData`, including `window.`/`globalThis.` assignments.
