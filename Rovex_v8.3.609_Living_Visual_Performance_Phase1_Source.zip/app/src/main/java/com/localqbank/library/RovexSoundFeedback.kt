package com.localqbank.library

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log

/** Reliable low-latency UI sound feedback. Loads asynchronously and plays only after the sample is ready. */
object RovexSoundFeedback {
    private const val PREFS = "ui"
    private const val KEY_ENABLED = "sound_feedback_enabled"
    private const val TAG = "RovexSound"
    private var pool: SoundPool? = null
    private var correctId = 0
    private var milestoneId = 0
    private var clickId = 0
    private var deepTouchId = 0
    private var themeSwitchId = 0
    private var correctReady = false
    private var milestoneReady = false
    private var clickReady = false
    private var deepTouchReady = false
    private var themeSwitchReady = false
    private var pending: Cue? = null
    private var fallbackPlayer: android.media.MediaPlayer? = null
    private enum class Cue { CORRECT, MILESTONE, CLICK, DEEP_TOUCH, THEME_SWITCH }
    fun isEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (!enabled) release() else ensurePool(context)
    }
    fun playCorrect(context: Context) = play(context, Cue.CORRECT)
    fun playMilestone(context: Context) = play(context, Cue.MILESTONE)
    fun preload(context: Context) {
        if (isEnabled(context)) synchronized(this) { ensurePool(context) }
    }
    fun playTest(context: Context): Boolean = play(context, Cue.CLICK)
    fun playClick(context: Context) { play(context, Cue.CLICK) }
    fun playDeepTouch(context: Context) { play(context, Cue.DEEP_TOUCH) }
    fun playThemeSwitch(context: Context) { play(context, Cue.THEME_SWITCH) }
    private fun play(context: Context, cue: Cue): Boolean {
        if (!isEnabled(context)) return false
        synchronized(this) {
            ensurePool(context)
            val ready = when(cue) {
                Cue.CORRECT -> correctReady
                Cue.MILESTONE -> milestoneReady
                Cue.CLICK -> clickReady
                Cue.DEEP_TOUCH -> deepTouchReady
                Cue.THEME_SWITCH -> themeSwitchReady
            }
            val id = when(cue) {
                Cue.CORRECT -> correctId
                Cue.MILESTONE -> milestoneId
                Cue.CLICK -> clickId
                Cue.DEEP_TOUCH -> deepTouchId
                Cue.THEME_SWITCH -> themeSwitchId
            }
            if (!ready || id == 0) {
                if (cue == Cue.CLICK) {
                    // SoundPool loads asynchronously. A short UI cue must still work on the
                    // very first tap, so use the same PCM asset through MediaPlayer while the
                    // pool finishes loading. Do not queue a second click or the user can hear
                    // two sounds when onLoadComplete fires.
                    return playDirectFallback(context)
                }
                pending = cue
                return false
            }
            val gain = when (cue) { Cue.CLICK -> 0.72f; Cue.DEEP_TOUCH -> 0.46f; Cue.THEME_SWITCH -> 0.38f; else -> 0.85f }
            val stream = pool?.play(id, gain, gain, 2, 0, 1f) ?: 0
            if (stream == 0 && cue == Cue.CLICK) return playDirectFallback(context)
            return stream != 0
        }
    }
    private fun ensurePool(context: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        // Answer feedback is an exclusive cue channel: a new cue replaces the previous one
        // instead of allowing overlapping answer/milestone streams.
        val p = SoundPool.Builder().setMaxStreams(1).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { soundPool, sampleId, status ->
            synchronized(this) {
                if (status != 0) { Log.w(TAG, "Sound sample failed to load: $sampleId status=$status"); return@synchronized }
                if (sampleId == correctId) correctReady = true
                if (sampleId == milestoneId) milestoneReady = true
                if (sampleId == clickId) clickReady = true
                if (sampleId == deepTouchId) deepTouchReady = true
                if (sampleId == themeSwitchId) themeSwitchReady = true
                val next = pending; pending = null
                if (next != null) {
                    val nextId = when(next) {
                        Cue.CORRECT -> correctId
                        Cue.MILESTONE -> milestoneId
                        Cue.CLICK -> clickId
                        Cue.DEEP_TOUCH -> deepTouchId
                        Cue.THEME_SWITCH -> themeSwitchId
                    }
                    val nextReady = when(next) {
                        Cue.CORRECT -> correctReady
                        Cue.MILESTONE -> milestoneReady
                        Cue.CLICK -> clickReady
                        Cue.DEEP_TOUCH -> deepTouchReady
                        Cue.THEME_SWITCH -> themeSwitchReady
                    }
                    if (nextReady && nextId != 0) {
                        stopFallbackPlayerLocked()
                        val gain = when (next) { Cue.CLICK -> 0.72f; Cue.DEEP_TOUCH -> 0.46f; Cue.THEME_SWITCH -> 0.38f; else -> 0.85f }
                        soundPool.play(nextId, gain, gain, 2, 0, 1f)
                    }
                }
            }
        }
        pool = p; correctReady = false; milestoneReady = false; clickReady = false; deepTouchReady = false; themeSwitchReady = false
        correctId = p.load(context.applicationContext, R.raw.rover_correct, 1)
        milestoneId = p.load(context.applicationContext, R.raw.rover_milestone, 1)
        clickId = p.load(context.applicationContext, R.raw.rovex_button_click, 1)
        deepTouchId = p.load(context.applicationContext, R.raw.rovex_deep_touch, 1)
        themeSwitchId = p.load(context.applicationContext, R.raw.rovex_theme_switch, 1)
    }

    private fun playDirectFallback(context: Context): Boolean {
        return runCatching {
            stopFallbackPlayerLocked()
            val player = android.media.MediaPlayer.create(context.applicationContext, R.raw.rovex_button_click)
                ?: return@runCatching false
            fallbackPlayer = player
            player.setOnCompletionListener {
                synchronized(this) {
                    if (fallbackPlayer === it) fallbackPlayer = null
                    it.release()
                }
            }
            player.setOnErrorListener { mp, _, _ ->
                synchronized(this) {
                    if (fallbackPlayer === mp) fallbackPlayer = null
                    mp.release()
                }
                true
            }
            player.setVolume(0.9f, 0.9f)
            player.start()
            true
        }.onFailure { Log.w(TAG, "Direct click fallback failed", it) }.getOrDefault(false)
    }

    private fun stopFallbackPlayerLocked() {
        val player = fallbackPlayer ?: return
        fallbackPlayer = null
        runCatching { player.stop() }
        runCatching { player.release() }
    }

    private fun release() {
        synchronized(this) {
            stopFallbackPlayerLocked()
            runCatching { pool?.release() }
            pool = null
            correctId = 0
            milestoneId = 0
            clickId = 0
            deepTouchId = 0
            themeSwitchId = 0
            correctReady = false
            milestoneReady = false
            clickReady = false
            deepTouchReady = false
            themeSwitchReady = false
            pending = null
        }
    }
}
