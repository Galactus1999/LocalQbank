package com.localqbank.library

import android.graphics.Color

/** Immutable visual profile. Colors are deliberately distinct per theme; no theme is only a tint swap. */
data class RovexThemeProfile(
    val key: String,
    val name: String,
    val backgroundA: Int,
    val backgroundB: Int,
    val backgroundC: Int,
    val panel: Int,
    val elevated: Int,
    val accent: Int,
    val accentSecondary: Int,
    val text: Int,
    val muted: Int,
    val scene: Int,
    val flowSpeed: Float,
    val motionAlpha: Float,
    val cornerDp: Int
) {
    companion object {
        fun forKey(key: String): RovexThemeProfile = when (key) {
            ThemeManager.PASTEL -> RovexThemeProfile(
                key, "Pastel Prism", Color.rgb(244, 248, 255), Color.rgb(255, 239, 249), Color.rgb(235, 239, 255),
                Color.rgb(252, 253, 255), Color.WHITE, Color.rgb(74, 91, 255), Color.rgb(226, 92, 184),
                Color.rgb(25, 34, 70), Color.rgb(91, 102, 133), 1, .34f, .22f, 24
            )
            ThemeManager.MINT -> RovexThemeProfile(
                key, "Living Mint", Color.rgb(232, 255, 248), Color.rgb(225, 243, 255), Color.rgb(238, 255, 241),
                Color.rgb(248, 255, 252), Color.WHITE, Color.rgb(0, 176, 154), Color.rgb(45, 125, 225),
                Color.rgb(13, 48, 51), Color.rgb(70, 105, 104), 2, .42f, .25f, 24
            )
            ThemeManager.SUNSET -> RovexThemeProfile(
                key, "Solar Ember", Color.rgb(255, 247, 232), Color.rgb(255, 224, 211), Color.rgb(255, 239, 224),
                Color.rgb(255, 251, 246), Color.WHITE, Color.rgb(245, 93, 48), Color.rgb(255, 178, 66),
                Color.rgb(67, 39, 30), Color.rgb(119, 91, 76), 3, .30f, .22f, 24
            )
            ThemeManager.LAVENDER -> RovexThemeProfile(
                key, "Iris Aurora", Color.rgb(246, 242, 255), Color.rgb(225, 238, 255), Color.rgb(255, 235, 249),
                Color.rgb(252, 250, 255), Color.WHITE, Color.rgb(112, 72, 255), Color.rgb(216, 79, 181),
                Color.rgb(42, 30, 76), Color.rgb(100, 87, 126), 4, .38f, .24f, 26
            )
            ThemeManager.AMOLED -> RovexThemeProfile(
                key, "OLED Aurora", Color.BLACK, Color.rgb(1, 7, 15), Color.rgb(0, 14, 19),
                Color.rgb(5, 10, 16), Color.rgb(9, 15, 23), Color.rgb(52, 189, 255), Color.rgb(90, 255, 204),
                Color.rgb(241, 247, 255), Color.rgb(150, 177, 208), 5, .28f, .16f, 22
            )
            ThemeManager.PANDORA -> RovexThemeProfile(
                key, "Pandora Living World", Color.rgb(2, 7, 23), Color.rgb(7, 26, 47), Color.rgb(25, 8, 43),
                Color.rgb(7, 23, 39), Color.rgb(11, 33, 48), Color.rgb(70, 235, 255), Color.rgb(205, 82, 255),
                Color.rgb(241, 247, 255), Color.rgb(151, 183, 213), 6, .22f, .24f, 26
            )
            ThemeManager.SPACE -> RovexThemeProfile(
                key, "Deep Cosmos", Color.rgb(1, 4, 16), Color.rgb(9, 11, 40), Color.rgb(30, 7, 49),
                Color.rgb(8, 13, 31), Color.rgb(13, 18, 42), Color.rgb(120, 174, 255), Color.rgb(189, 98, 255),
                Color.rgb(242, 247, 255), Color.rgb(151, 174, 211), 7, .16f, .20f, 24
            )
            else -> RovexThemeProfile(
                key, "Clinical Day", Color.rgb(247, 250, 255), Color.rgb(232, 242, 255), Color.rgb(255, 246, 237),
                Color.rgb(252, 253, 255), Color.WHITE, Color.rgb(45, 91, 230), Color.rgb(0, 164, 190),
                Color.rgb(18, 32, 72), Color.rgb(77, 94, 125), 0, .26f, .18f, 22
            )
        }
    }
}
