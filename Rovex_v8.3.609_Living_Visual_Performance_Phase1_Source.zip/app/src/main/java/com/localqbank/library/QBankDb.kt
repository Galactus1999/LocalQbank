package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.security.MessageDigest
import android.util.Log

class QBankDb(context: Context) {
    data class StoredProgress(
        val selected: String?, val status: String?, val bookmark: String?, val review: Boolean,
        val attempts: Int, val lastAttempted: Long, val timeMs: Long, val mistake: String?,
        val easeFactor: Float, val repetitions: Int, val intervalDays: Float, val nextDue: Long
    )

    data class HomeStudyStats(
        val todayRecords: List<Pair<Long, Boolean>>,
        val today: Int,
        val attempted: Int,
        val correct: Int,
        val wrong: Int,
        val week: Int,
        val bookmarks: Int,
        val days: List<Pair<Long, Pair<Int, Int>>>
    )

    data class StudyAttemptHistoryRow(
        val stableKey: String, val attemptedAt: Long, val correct: Boolean, val timeMs: Long
    )

    private val appContext = context.applicationContext

    /**
     * Resolve the current provider-owned database for every operation. The test/reset lifecycle
     * may close and replace the shared SQLiteOpenHelper; retaining a SQLiteDatabase reference
     * here would leave long-lived managers pointing at a permanently closed handle.
     */
    private val db: SQLiteDatabase
        get() = qBankDatabaseProvider.get(appContext)

    private val questionRepository by lazy { QBankQuestionRepository { db } }
    private val notesRepository by lazy { QBankNotesRepository({ db }) { AppState.changed() } }
    private val searchRepository by lazy { QBankSearchRepository { db } }
    private val searchIndexCoordinator by lazy { QBankSearchIndexCoordinator { db } }
    private val dashboardRepository by lazy { QBankDashboardRepository { db } }
    private val deletedSourceRepository by lazy { QBankDeletedSourceRepository { db } }

    /** Reset implementation is extracted, but resolves the provider-owned DB per operation. */
    private val progressResetter by lazy {
        QBankProgressResetter(
            dbProvider = { db },
            sourceNameForId = { id -> sourceNameForId(id) }
        )
    }

    /** Resolve a source display name for progress-reset compatibility. */
    private fun sourceNameForId(sourceId: Long): String = db.rawQuery(
        "SELECT COALESCE(display_name,file_name,'') FROM source WHERE id=? LIMIT 1",
        arrayOf(sourceId.toString())
    ).use { c -> if (c.moveToFirst()) c.getString(0).orEmpty() else "" }

    /** Physical source deletion is extracted and wired here; QBankDb remains its facade. */
    private val sourceDeletionManager by lazy {
        QBankSourceDeletionManager(
            dbProvider = { db },
            appContext = appContext,
            scheduleSearchIndexRepair = { searchIndexCoordinator.scheduleRepair() },
            markSearchIndexGarbagePending = { searchIndexCoordinator.markGarbagePending() }
        )
    }

    /** Durable learner state is extracted behind the QBankDb compatibility facade. */
    private val studyStateStore by lazy {
        QBankStudyStateStore(
            dbProvider = { db },
            sourceIdForTest = { id -> sourceIdForTest(id) },
            lock = qBankDatabaseProvider
        )
    }


    fun ensureSearchIndex(){ searchIndexCoordinator.ensureSearchIndex() }
    fun isSearchIndexReady(): Boolean = searchIndexCoordinator.isReady()
    fun repairSearchIndexForMaintenance(): Boolean = searchIndexCoordinator.repairForMaintenance()

    internal fun hasLegacyTombstonedSources(): Boolean = db.rawQuery(
        "SELECT 1 FROM source WHERE deleting=1 AND COALESCE(delete_requested,0)=0 LIMIT 1", null
    ).use { it.moveToFirst() }

    fun questionExists(questionId: Long): Boolean = questionRepository.questionExists(questionId)
    /**
     * Lightweight keyset-paginated corpus access for offline AI indexing. This returns only
     * bounded text/context rows and never materializes the whole QBank in memory.
     */
    fun aiIndexQuestionCount(): Int = questionRepository.aiIndexQuestionCount()

    fun aiIndexBatch(afterQuestionId: Long = 0L, limit: Int = 64): List<AiIndexRow> = questionRepository.aiIndexBatch(afterQuestionId, limit)

    fun existingQuestionIds(ids: LongArray): LongArray = questionRepository.existingQuestionIds(ids)

    fun readStoredProgress(stableKey: String): StoredProgress? = studyStateStore.readStoredProgress(stableKey)
    fun writeStoredProgress(stableKey: String, value: StoredProgress) = studyStateStore.writeStoredProgress(stableKey, value)
    fun deleteStoredProgress(stableKey: String) = studyStateStore.deleteStoredProgress(stableKey)
    fun allStoredProgress(): Map<String, StoredProgress> = studyStateStore.allStoredProgress()
    fun getProgressMeta(key: String): String? = studyStateStore.getProgressMeta(key)
    fun putProgressMeta(key: String, value: String?) = studyStateStore.putProgressMeta(key, value)
    fun allProgressMeta(): Map<String,String> = studyStateStore.allProgressMeta()
    fun recordStudyStreakDay(timestamp: Long = System.currentTimeMillis()): StreakManager.Snapshot = studyStateStore.recordStudyStreakDay(timestamp)
    fun readStudyStreak(): StreakManager.Snapshot = studyStateStore.readStudyStreak()
    fun studyReminderAlreadySent(day: String): Boolean = studyStateStore.studyReminderAlreadySent(day)
    fun markStudyReminderSent(day: String) = studyStateStore.markStudyReminderSent(day)
    fun notificationPermissionPrompted(): Boolean = studyStateStore.notificationPermissionPrompted()
    fun markNotificationPermissionPrompted() = studyStateStore.markNotificationPermissionPrompted()
    fun replaceStoredProgress(entries: Map<String, StoredProgress>, meta: Map<String,String>) = studyStateStore.replaceStoredProgress(entries, meta)
    fun beginProgressMetaTransaction(testId:String, position:Int, sourceId:Long, sourceName:String?, resumeSavedAt:Long? = null) = studyStateStore.beginProgressMetaTransaction(testId, position, sourceId, sourceName, resumeSavedAt)

    internal fun snapshotTo(destination: File) {
        destination.parentFile?.mkdirs()
        if (destination.exists()) destination.delete()
        db.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { }
        val escaped = destination.absolutePath.replace("'", "''")
        db.rawQuery("VACUUM INTO '$escaped'", null).use { }
        check(destination.isFile && destination.length() > 0L) { "Database snapshot failed: ${destination.name}" }
    }
    fun close(){ /* shared process-scoped database */ }

    fun sources(): List<Source> = questionRepository.sources()
    internal fun pendingDeletedQBanks(): List<QBankDeletedSourceRepository.PendingDeletedQBank> = deletedSourceRepository.list()
    internal fun isPendingDeletedQBank(sourceId: Long): Boolean = deletedSourceRepository.isPending(sourceId)

    /**
     * Records an explicit user deletion intent and hides the QBank immediately.
     *
     * This is deliberately separate from [deleteSource]. The latter performs the potentially
     * large physical cleanup and is still used by import replacement and recovery. Interactive
     * UI must never wait for that cleanup before refreshing its catalog. The tombstone is the
     * durable hand-off between the UI and the resumable deletion worker.
     */
    fun requestSourceDeletion(sourceId: Long): Boolean {
        if (sourceId <= 0L) return false
        return runCatching {
            withWriteRetry("request-source-deletion") {
                QBankWriteCoordinator.lock.lock()
            try {
                var transactionStarted = false
                try {
                    db.beginTransactionNonExclusive()
                    transactionStarted = true
                    val exists = db.rawQuery(
                        "SELECT 1 FROM source WHERE id=? LIMIT 1",
                        arrayOf(sourceId.toString())
                    ).use { it.moveToFirst() }
                    if (!exists) {
                        db.setTransactionSuccessful()
                        return@withWriteRetry false
                    }
                    db.execSQL(
                        "UPDATE source SET deleting=1,delete_requested=1 WHERE id=?",
                        arrayOf(sourceId.toString())
                    )
                    db.setTransactionSuccessful()
                    true
                } finally {
                    if (transactionStarted) db.endTransaction()
                }
            } finally {
                QBankWriteCoordinator.lock.unlock()
            }
            }.also { accepted ->
                if (accepted) {
                    // This is the durable admission boundary for crash/process-death recovery.
                    // Startup only consults this tiny marker; it does not open SQLite merely to
                    // discover whether there is work to recover.
                    QBankDeletionRecoveryWorker.markRecoveryNeeded(appContext)
                    // The DB API owns the durable hand-off: callers must not be required to
                    // remember a second enqueue call after successfully tombstoning a source.
                    // Existing UI callers may still enqueue explicitly; unique-work KEEP makes
                    // that harmless and preserves the single recovery chain.
                    QBankDeletionRecoveryWorker.enqueueIfNeeded(appContext)
                    AppState.changed("qbank_delete_requested")
                    PerformanceManager.invalidate()
                }
            }
        }.getOrElse { e ->
            Log.e("QBankDb", "QBank deletion request failed for source=$sourceId", e)
            ProductionCrashReporter.recordNonFatal(e, "QBANK_DELETE_REQUEST", mapOf("source_id" to sourceId.toString()))
            false
        }
    }
    fun sourceById(sourceId: Long): Source? = questionRepository.sourceById(sourceId)
    fun sourceNameForTest(testId:String):String? = questionRepository.sourceNameForTest(testId)
    fun testById(testId:String):Test? = questionRepository.testById(testId)
    fun tests(sourceId:Long):List<Test> = questionRepository.tests(sourceId)
    fun questionContext(questionId:Long):Pair<String,String> = questionRepository.questionContext(questionId)
    fun questionCount(testId:String):Int = questionRepository.questionCount(testId)
    fun questionByStableKey(stableKey:String):Question? = questionRepository.questionByStableKey(stableKey)
    fun rawQuestionPosition(testId:String, questionId:Long):Int? = questionRepository.rawQuestionPosition(testId, questionId)
    fun questionAt(testId:String, position:Int):Question? = questionRepository.questionAt(testId, position)
    fun questionById(questionId:Long):Question? = questionRepository.questionById(questionId)
    fun sourceIdForTest(testId:String):Long = questionRepository.sourceIdForTest(testId)
    fun testIdForQuestion(questionId:Long):String? = questionRepository.testIdForQuestion(questionId)
    fun questions(testId:String):List<Question> = questionRepository.questions(testId)
    fun allStableKeys():List<String> = questionRepository.allStableKeys()
    fun dashboardTestRows(): List<DashboardTestRow> = dashboardRepository.dashboardTestRows()

    fun bookmarkCounts(): Map<String, Int> = studyStateStore.bookmarkCounts()
    fun homeStudyStats(todayStart: Long, weekStart: Long, graphStart: Long): HomeStudyStats =
        studyStateStore.homeStudyStats(todayStart, weekStart, graphStart)
    fun studyAttemptHistory(stableKeys: Set<String>, since: Long): List<StudyAttemptHistoryRow> =
        studyStateStore.studyAttemptHistory(stableKeys, since)
    fun recordStudyAttempt(stableKey: String, testId: String, sourceId: Long, attemptedAt: Long, correct: Boolean) =
        studyStateStore.recordStudyAttempt(stableKey, testId, sourceId, attemptedAt, correct)
    fun updateLatestStudyAttemptTime(stableKey: String, elapsedMs: Long) =
        studyStateStore.updateLatestStudyAttemptTime(stableKey, elapsedMs)
    fun seedStudyAttemptHistoryIfNeeded() = studyStateStore.seedStudyAttemptHistoryIfNeeded()

    fun allQuestionRefs(lightweight:Boolean=false):List<QuestionRef> = questionRepository.allQuestionRefs(lightweight)
    fun questionRefsForStableKeys(keys:Collection<String>):List<QuestionRef> = questionRepository.questionRefsForStableKeys(keys)
    fun questionRefsForIdsBounded(ids:LongArray):List<QuestionRef> = questionRepository.questionRefsForIdsBounded(ids)
    fun questionRefsForIds(ids:LongArray):List<QuestionRef> = questionRepository.questionRefsForIds(ids)
    fun questionRefsByKeyword(keyword:String):List<QuestionRef> = questionRepository.questionRefsByKeyword(keyword)
    fun sourceQuestionCount(sourceId:Long):Int = questionRepository.sourceQuestionCount(sourceId)
    fun testQuestionRefs(testId:String):List<QuestionRef> = questionRepository.testQuestionRefs(testId)

    fun updateSourceMetadata(sourceId:Long, displayName:String, seriesNumber:String):Boolean {
        val name = displayName.trim().take(180)
        if (name.isBlank()) return false
        return try {
            db.execSQL("UPDATE source SET display_name=?,series_number=? WHERE id=?", arrayOf<Any?>(name, seriesNumber.trim().take(80), sourceId))
            AppState.changed()
            true
        } catch (_: android.database.sqlite.SQLiteConstraintException) { false }
    }

    fun updateTestMetadata(testId:String, title:String, seriesNumber:String):Boolean {
        val name = title.trim().take(180)
        if (name.isBlank()) return false
        return try {
            db.execSQL("UPDATE test SET title=?,series_number=? WHERE id=?", arrayOf(name, seriesNumber.trim().take(80), testId))
            searchIndexCoordinator.markDirty()
            AppState.changed()
            true
        } catch (_: Exception) { false }
    }

    /**
     * Resets the learner state for exactly one imported QBank while preserving its questions,
     * tests, media and immutable study-attempt history. This is intentionally a source-scoped
     * operation so another QBank can never be reset as a side effect.
     */
    /**
     * Resets learner state for exactly one imported sub-QBank/test. Questions and the parent
     * source remain intact; immutable study-attempt history is retained.
     */
    fun resetTestProgress(testId: String): Boolean {
        val reset = progressResetter.resetTestProgress(testId)
        if (reset) AppState.changed()
        return reset
    }

    fun resetSourceProgress(sourceId: Long): Boolean {
        val reset = progressResetter.resetSourceProgress(sourceId)
        if (reset) {
            PerformanceManager.invalidateProgress()
            AppState.changed()
        }
        return reset
    }


    /**
     * Deletes an imported QBank without monopolizing the database connection.
     *
     * The old implementation performed several deletes once per test while holding one
     * long write transaction. On large QBanks that made foreground readers wait long enough
     * to trigger an Android input ANR. This implementation uses set-based SQL, WAL-friendly
     * non-exclusive transactions, and a separate low-priority deletion executor at the caller.
     * FTS cleanup is intentionally a separate transaction so the normalized question/test
     * database is released quickly; search-index cleanup cannot make deleted questions visible
     * because all searches join the normalized tables.
     */
    /**
     * One-time safety reconciliation for the pre-v8.3.434 tombstone bug. Before import identity
     * was separated from the human filename, importing a second same-named QBank could mark the
     * existing source deleting and then fail on SQLite locking/replace. A complete source with
     * all expected questions is not a partially-deleted source, so it is safe to restore it.
     * Partially deleted sources remain tombstoned for normal resumable deletion.
     */
    /**
     * Recovers legacy hidden sources created before the deletion-intent split. These rows are
     * never auto-deleted: they are data-recovery candidates, not proof of a user delete. A
     * source with any surviving test/question content is restored so existing user data remains
     * reachable. Explicit deletes in the current schema set delete_requested=1 and are handled
     * separately by the resumable deletion worker.
     */
    fun restoreLegacyTombstonedSources(): Int {
        var restored = 0
        db.rawQuery(
            "SELECT s.id FROM source s WHERE s.deleting=1 AND COALESCE(s.delete_requested,0)=0 ORDER BY s.imported_at,s.id", null
        ).use { c ->
            val ids = buildList { while (c.moveToNext()) add(c.getLong(0)) }
            ids.forEach { sourceId ->
                val hasContent = runCatching {
                    db.rawQuery(
                        "SELECT EXISTS(SELECT 1 FROM test WHERE source_id=?) OR EXISTS(SELECT 1 FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?)",
                        arrayOf(sourceId.toString(), sourceId.toString())
                    ).use { x -> x.moveToFirst() && x.getInt(0) == 1 }
                }.getOrDefault(false)
                if (hasContent) {
                    runCatching {
                        QBankWriteCoordinator.lock.lock()
                        try {
                            var transactionStarted = false
                            try {
                                db.beginTransactionNonExclusive()
                                transactionStarted = true
                                db.execSQL("UPDATE source SET deleting=0 WHERE id=? AND delete_requested=0", arrayOf(sourceId))
                                db.setTransactionSuccessful()
                                restored++
                            } finally { if (transactionStarted) db.endTransaction() }
                        } finally {
                            QBankWriteCoordinator.lock.unlock()
                        }
                    }
                }
            }
        }
        if (restored > 0) {
            PerformanceManager.invalidate()
            AppState.changed("qbank_legacy_tombstones_recovered")
        }
        return restored
    }

    /** Returns only explicit deletion intents; legacy hidden sources are never destroyed by recovery. */
    fun pendingDeletingSourceIds(): List<Long> =
        db.rawQuery("SELECT id FROM source WHERE deleting=1 AND delete_requested=1 ORDER BY imported_at,id", null).use { c ->
            buildList { while(c.moveToNext()) add(c.getLong(0)) }
        }

    /**
     * Root-safe, resumable QBank deletion facade. Physical cleanup is owned by
     * [QBankSourceDeletionManager]; QBankDb remains the database-facing compatibility API.
     */
    fun deleteSource(
        sourceId:Long,
        repairSearchIndex:Boolean = true,
        maxQuestionBatches:Int = Int.MAX_VALUE,
        shouldPause: (() -> Boolean)? = null
    ): Boolean = sourceDeletionManager.deleteSource(
        sourceId = sourceId,
        repairSearchIndex = repairSearchIndex,
        maxQuestionBatches = maxQuestionBatches,
        shouldPause = shouldPause
    )

    private inline fun <T> withWriteRetry(label: String, attempts: Int = 4, block: () -> T): T {
        var last: Throwable? = null
        for (attempt in 0 until attempts) {
            try { return block() } catch (t: android.database.sqlite.SQLiteDatabaseLockedException) {
                last = t
                if (attempt + 1 >= attempts) break
                java.util.concurrent.locks.LockSupport.parkNanos((20L shl attempt).coerceAtMost(160L) * 1_000_000L)
                if (Thread.currentThread().isInterrupted) throw InterruptedException("QBank delete interrupted")
            }
        }
        throw last ?: IllegalStateException("$label failed")
    }

    fun saveNote(questionId:Long,note:String) = notesRepository.saveNote(questionId,note)
    fun deleteNote(questionId:Long) = notesRepository.deleteNote(questionId)
    fun deleteNotes(questionIds:LongArray) = notesRepository.deleteNotes(questionIds)
    fun note(questionId: Long): String? = notesRepository.note(questionId)
    fun notes(): List<Pair<Long,String>> = notesRepository.notes()
    data class NoteRecord(
        val questionId: Long, val note: String, val updatedAt: Long,
        val testId: String, val subject: String, val testTitle: String, val sourceName: String, val position: Int,
        val imagePaths: List<String> = emptyList()
    )
    fun noteCount(): Int = notesRepository.noteCount()
    fun noteRecords(): List<NoteRecord> = notesRepository.noteRecords()
    fun addNoteImage(questionId: Long, path: String) = notesRepository.addNoteImage(questionId,path)
    fun noteImages(questionId: Long): List<String> = notesRepository.noteImages(questionId)
    fun replaceNotes(notes:List<Pair<Long,String>>) = notesRepository.replaceNotes(notes)
    fun progressSummaryForTest(testId:String, store:ProgressStore):ProgressSummary {
        var total=0; var solved=0; var correct=0; var resume=0; var foundResume=false
        db.rawQuery("SELECT q.position,q.source_question_id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.test_id=? ORDER BY q.position",arrayOf(testId)).use { c ->
            while(c.moveToNext()) {
                total++
                val key="$testId:${c.getInt(0)}:${c.getString(1)}"
                val st=store.status(key)
                if(st!=null){ solved++; if(st=="correct") correct++ } else if(!foundResume){ resume=c.getInt(0); foundResume=true }
            }
        }
        return ProgressSummary(total,solved,correct,resume)
    }
    fun progressSummaryForSource(sourceId:Long, store:ProgressStore):ProgressSummary {
        var total=0; var solved=0; var correct=0
        db.rawQuery("SELECT q.test_id,q.position,q.source_question_id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.source_id=? ORDER BY t.rowid,q.position",arrayOf(sourceId.toString())).use { c ->
            while(c.moveToNext()){ total++; val key="${c.getString(0)}:${c.getInt(1)}:${c.getString(2)}"; val st=store.status(key); if(st!=null){solved++;if(st=="correct")correct++} }
        }
        return ProgressSummary(total,solved,correct,0)
    }
    fun testProgressSummaries(sourceId:Long):Map<String,ProgressSummary> {
        // Opening a sub-QBank is a navigation operation, not a request to walk every question.
        // The old implementation materialized one Kotlin stable-key lookup per question, so a
        // 50k-question source could consume the shared qbank worker immediately after navigation.
        // Aggregate the same information in SQLite using the indexed progress_v2.test_id field
        // and the authoritative test.num_questions value.
        val sql = """
            SELECT t.id,
                   COALESCE(t.num_questions,0),
                   COALESCE(p.solved,0),
                   COALESCE(p.correct,0),
                   COALESCE(CAST(m.meta_value AS INTEGER),0)
            FROM test t
            JOIN source s ON s.id=t.source_id AND s.deleting=0
            LEFT JOIN (
                SELECT test_id,
                       SUM(CASE WHEN status IS NOT NULL AND status <> '' THEN 1 ELSE 0 END) AS solved,
                       SUM(CASE WHEN status = 'correct' THEN 1 ELSE 0 END) AS correct
                FROM progress_v2
                WHERE test_id IN (SELECT id FROM test WHERE source_id=?)
                GROUP BY test_id
            ) p ON p.test_id=t.id
            LEFT JOIN progress_meta m ON m.meta_key=(t.id || ':position')
            WHERE t.source_id=?
            ORDER BY t.rowid
        """.trimIndent()
        return db.rawQuery(sql, arrayOf(sourceId.toString(), sourceId.toString())).use { c ->
            buildMap {
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val total = c.getInt(1).coerceAtLeast(0)
                    val solved = c.getInt(2).coerceAtLeast(0).coerceAtMost(total)
                    val correct = c.getInt(3).coerceAtLeast(0).coerceAtMost(solved)
                    val resume = c.getInt(4).coerceIn(0, (total - 1).coerceAtLeast(0))
                    put(id, ProgressSummary(total, solved, correct, resume))
                }
            }
        }
    }

    fun questionIdsMatchingText(token:String):LongArray = searchRepository.search(token).map{it.id}.toLongArray()
    fun search(query:String, resultLimit:Int = 400):List<SearchHit> = searchRepository.search(query, resultLimit)
    fun searchImageQuestions(query:String, resultLimit:Int = 400):List<SearchHit> = searchRepository.searchImageQuestions(query, resultLimit)
    fun searchSections(query:String):List<SectionHit> = searchRepository.searchSections(query)

    private fun safeImportKey(importKey: String): String {
        val key = importKey.trim()
        if (key.startsWith("rvx-uri-") && key.length >= 20) return key
        val digest = MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return "rvx-legacy-$digest"
    }

    /**
     * Reclaims an existing import identity in bounded foreground-safe passes.
     *
     * A deleted QBank is intentionally tombstoned first and its physical cleanup may be deferred
     * to DeviceIdle maintenance. Re-importing that same document identity is an explicit user
     * action, however, and cannot be allowed to sit at the import UI's 28% database boundary while
     * an unbounded deletion pass runs. Resume the tombstoned cleanup in small batches, report its
     * progress to the caller, and only create the replacement source after the old row is gone.
     */
    private fun removeExistingImportSource(
        stableImportKey: String,
        onProgress: ((deleted: Int, total: Int) -> Unit)? = null
    ) {
        val existingSourceId = db.rawQuery(
            "SELECT id FROM source WHERE file_name=? LIMIT 1",
            arrayOf(stableImportKey)
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
        if (existingSourceId <= 0L) return

        // The import replacement is itself an explicit destructive request. Persist the same
        // recovery admission boundary used by user deletion so process death between bounded
        // passes cannot strand a tombstoned source without a recovery signal.
        QBankDeletionRecoveryWorker.markRecoveryNeeded(appContext)

        val total = db.rawQuery(
            "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?",
            arrayOf(existingSourceId.toString())
        ).use { c -> c.moveToFirst(); c.getInt(0) }
        var previousRemaining = total
        onProgress?.invoke(0, total)

        while (true) {
            val deleted = deleteSource(
                existingSourceId,
                repairSearchIndex = false,
                maxQuestionBatches = 8,
                shouldPause = null
            )
            val remaining = db.rawQuery(
                "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?",
                arrayOf(existingSourceId.toString())
            ).use { c -> c.moveToFirst(); c.getInt(0) }
            onProgress?.invoke((total - remaining).coerceIn(0, total), total)
            if (deleted) return
            check(remaining < previousRemaining) {
                "Previous import is still being removed and made no progress; retry import after recovery completes"
            }
            previousRemaining = remaining
            Thread.yield()
        }
    }

    fun beginStreamingImport(
        importKey:String,
        displayName:String,
        provider:String,
        onReplacementProgress: ((deleted: Int, total: Int) -> Unit)? = null
    ): StreamingImportSession {
        val stableImportKey = safeImportKey(importKey)
        removeExistingImportSource(stableImportKey, onReplacementProgress)
        searchIndexCoordinator.markDirty()
        var sourceId = 0L
        QBankWriteCoordinator.lock.lock()
        try {
            var transactionStarted = false
            try {
                db.beginTransactionNonExclusive()
                transactionStarted = true
                val st=db.compileStatement("INSERT INTO source(file_name,display_name,series_number,provider,imported_at) VALUES(?,?,?,?,?)")
            st.bindString(1,stableImportKey); st.bindString(2,displayName); st.bindString(3,""); st.bindString(4,provider); st.bindLong(5,System.currentTimeMillis())
            sourceId=st.executeInsert()
                db.setTransactionSuccessful()
            } finally {
                if (transactionStarted) db.endTransaction()
            }
        } finally {
            QBankWriteCoordinator.lock.unlock()
        }
        return StreamingImportSession(QBankStreamingImportSession(db, sourceId, stableImportKey) { searchIndexCoordinator.finalizeIncremental() })
    }

    /** Compatibility façade preserving the historical nested streaming-session type. */
    class StreamingImportSession internal constructor(
        private val delegate: QBankStreamingImportSession
    ) {
        fun commitSection() = delegate.commitSection()
        fun addQuestion(section:String, q:ImportedQuestion) = delegate.addQuestion(section, q)
        fun abort() = delegate.abort()
        fun finish(success:Boolean) = delegate.finish(success)
    }

    /**
     * Imports a parsed HTML QBank without holding the entire corpus in one SQLite transaction.
     *
     * A single giant transaction is attractive for atomicity, but on large QBanks it can hold the
     * WAL/write lock for a very long time and defer the expensive commit/fsync until the very end.
     * That made imports appear frozen at the database-writing stage even though parsing had already
     * completed. We therefore commit bounded batches while keeping the source itself recoverable:
     * a failure cleans the partially-created source so callers never observe a half-imported QBank.
     *
     * FTS rows are still written transactionally with their normalized question rows. The index is
     * marked dirty until the complete source import finishes, so interactive search can safely fall
     * back to normalized-table retrieval during the import.
     */
    /** Compatibility overload for internal tests/legacy callers. */
    fun importBundle(fileName:String, provider:String, tests:List<ImportedTest>, onProgress:(done:Int,total:Int)->Unit = {_,_->}):Int =
        importBundle(importKey = fileName, displayName = fileName, provider = provider, tests = tests, onProgress = onProgress)

    /**
     * Explicit five-argument progress overload. A trailing lambda on this overload is
     * unambiguously the question-import progress callback, not replacement-deletion progress.
     */
    fun importBundle(
        importKey:String,
        displayName:String,
        provider:String,
        tests:List<ImportedTest>,
        onProgress:(done:Int,total:Int)->Unit
    ):Int = importBundle(
        importKey = importKey,
        displayName = displayName,
        provider = provider,
        tests = tests,
        onProgress = onProgress,
        onReplacementProgress = null
    )

    fun importBundle(
        importKey:String,
        displayName:String,
        provider:String,
        tests:List<ImportedTest>,
        onProgress:(done:Int,total:Int)->Unit = {_,_->},
        onReplacementProgress: ((deleted: Int, total: Int) -> Unit)? = null
    ):Int {
        val stableImportKey = safeImportKey(importKey)
        removeExistingImportSource(stableImportKey, onReplacementProgress)
        searchIndexCoordinator.markDirty()
        return QBankImportWriter(db,
            deleteSource = { sourceId -> deleteSource(sourceId, repairSearchIndex = false) },
            markSearchIndexDirty = { searchIndexCoordinator.markDirty() },
            finalizeSearchIndex = { searchIndexCoordinator.finalizeIncremental() }
        ).import(stableImportKey, displayName, provider, tests, onProgress)
            .also { AppState.changed("import_completed") }
    }

    companion object {
        /** Test-only reset of the authoritative shared database provider. */
        internal fun resetDatabaseForTest(context: Context) =
            qBankDatabaseProvider.resetForTest(context)

        /** Compatibility alias retained for existing internal test callers. */
        internal fun resetForTest(context: Context) =
            qBankDatabaseProvider.resetForTest(context)

    }
}


data class Source(val id:Long,val fileName:String,val provider:String,val seriesNumber:String="")
data class Test(val id:String,val title:String,val path:String?,val count:Int,val marks:Double,val duration:Int,val timePerQuestion:Double,val seriesNumber:String="")
data class Option(val label:String,val text:String,val correct:Boolean)
data class Question(val id:Long,val stableKey:String,val position:Int,val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<Option>,val questionImages:List<String>,val explanationImages:List<String>)

data class AiIndexRow(val id:Long,val text:String,val explanation:String,val testTitle:String,val path:String,val sourceName:String)
data class DashboardTestRow(
    val testId:String, val name:String, val path:String, val source:String,
    val total:Int, val sourceTotal:Int=total, val solved:Int, val correct:Int, val position:Int
)

data class QuestionRef(val id:Long,val stableKey:String,val testId:String,val position:Int,val text:String,val testTitle:String,val sourceId:Long,val sourceName:String,val category:String)
data class SearchHit(val id:Long,val testId:String,val testTitle:String,val position:Int,val text:String,val path:String?,val sourceName:String,val stableKey:String)
data class SectionHit(val testId:String,val title:String,val path:String,val sourceName:String,val count:Int)
data class ProgressSummary(val total:Int,val solved:Int,val correct:Int,val resumePosition:Int)
data class ImportedTest(val originalId:String?,val title:String,val path:String?,val totalMarks:Double,val duration:Int,val timePerQuestion:Double,val questions:List<ImportedQuestion>,val seriesNumber:String?=null)
data class ImportedQuestion(val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<ImportedOption>,val questionImages:List<String>,val explanationImages:List<String>)
data class ImportedOption(val label:String,val text:String,val correct:Boolean)
