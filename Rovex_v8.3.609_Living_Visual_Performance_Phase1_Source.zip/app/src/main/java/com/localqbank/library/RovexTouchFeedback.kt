package com.localqbank.library

import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/** Centralized restrained touch feedback. One cue per physical press, never on scroll/move. */
object RovexTouchFeedback {
    fun bind(view: View) {
        if (view.getTag(R.id.rovex_touch_feedback_bound) == true) return
        view.setTag(R.id.rovex_touch_feedback_bound, true)
        view.setOnTouchListener { v, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN && AnimationPolicy.enabled(v.context)) {
                RovexSoundFeedback.playDeepTouch(v.context)
                runCatching { v.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK) }
            }
            false
        }
    }
}
