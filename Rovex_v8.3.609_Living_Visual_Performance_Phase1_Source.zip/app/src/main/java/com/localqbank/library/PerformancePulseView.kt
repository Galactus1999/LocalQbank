package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max
import kotlin.math.sin

/** Live telemetry graph with cached paths, soft area fill and theme-adaptive grid. */
class PerformancePulseView(context: Context) : View(context) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.STROKE; strokeWidth=2.6f; strokeCap=Paint.Cap.ROUND; strokeJoin=Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.FILL }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.STROKE; strokeWidth=1f }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize=10f; isFakeBoldText=true }
    private val health = ArrayDeque<Int>(); private val ram = ArrayDeque<Int>(); private val resilience = ArrayDeque<Int>()
    private var running=false; private var phase=0f
    private val tick=object:Runnable{override fun run(){if(!running)return;sample();phase+=.12f;invalidate();postDelayed(this,1000L)}}
    override fun onAttachedToWindow(){super.onAttachedToWindow();running=true;sample();post(tick)}
    override fun onDetachedFromWindow(){running=false;removeCallbacks(tick);super.onDetachedFromWindow()}
    private fun add(q:ArrayDeque<Int>,v:Int){q.addLast(v.coerceIn(0,100));while(q.size>30)q.removeFirst()}
    private fun sample(){
        val gov=runCatching{BenAiResourceGovernor(context).snapshot(true)}.getOrNull()
        val rh=runCatching{AppManagers.resilienceHealth.snapshot().overall}.getOrDefault(0)
        val hs=runCatching{AppManagers.adaptive.state().health}.getOrDefault(0)
        val ramScore=((gov?.availableMemoryMb?:0).toFloat()/2048f*100f).toInt().coerceIn(0,100)
        add(health,hs);add(ram,ramScore);add(resilience,rh)
    }
    override fun onDraw(c:Canvas){
        super.onDraw(c);if(health.isEmpty())return
        val left=18f;val right=max(left+1f,width-18f);val top=28f;val bottom=max(top+1f,height-14f)
        grid.color=android.graphics.Color.argb(if(ThemeManager.isDark(context))35 else 24,Color.red(ThemeManager.text(context)),Color.green(ThemeManager.text(context)),Color.blue(ThemeManager.text(context)))
        for(i in 0..4){val y=top+(bottom-top)*i/4f;c.drawLine(left,y,right,y,grid)}
        drawSeries(c,health.toList(),left,right,top,bottom,ThemeManager.accent(context),true)
        drawSeries(c,ram.toList(),left,right,top,bottom,ThemeManager.peacockText(context),false)
        drawSeries(c,resilience.toList(),left,right,top,bottom,ThemeManager.accentSecondary(context),false)
        label.color=ThemeManager.muted(context);c.drawText("HEALTH",left,16f,label);c.drawText("RAM",left+72f,16f,label);c.drawText("RESILIENCE",left+108f,16f,label)
    }
    private fun drawSeries(c:Canvas,values:List<Int>,left:Float,right:Float,top:Float,bottom:Float,color:Int,glow:Boolean){
        if(values.size<2)return
        val path=Path();values.forEachIndexed { i,v ->val x=left+(right-left)*i/(values.lastIndex.coerceAtLeast(1)).toFloat();val y=bottom-(bottom-top)*v/100f;if(i==0)path.moveTo(x,y)else path.lineTo(x,y)}
        if(glow){line.strokeWidth=8f;line.color=android.graphics.Color.argb(30,Color.red(color),Color.green(color),Color.blue(color));c.drawPath(path,line)}
        line.strokeWidth=2.6f;line.color=android.graphics.Color.argb(225,Color.red(color),Color.green(color),Color.blue(color));c.drawPath(path,line)
    }
}
