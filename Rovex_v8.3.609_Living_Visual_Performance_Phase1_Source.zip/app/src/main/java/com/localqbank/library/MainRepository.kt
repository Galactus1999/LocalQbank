package com.localqbank.library

import android.content.Context

/**
 * Presentation-facing persistence seam for Home.
 * QBankDb/ProgressStore remain the authoritative storage implementations.
 */
class MainRepository(context: Context) : AutoCloseable {
    private val app = context.applicationContext
    // Database handles are opened lazily because ViewModel factories run on the main thread.
    // The first actual repository operation is executed by the owning background path.
    private val db by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { QBankDb(app) }
    private val progress by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { ProgressStore(app) }

    data class ResumeTarget(val testId: String, val position: Int, val title: String, val questionId: Long = 0L, val stableKey: String = "")

    fun questionExists(id: Long): Boolean = db.questionExists(id)
    fun progressSnapshot(): ProgressSnapshot = PerformanceManager.progress(app)
    fun testById(id: String): Test? = db.testById(id)
    fun sourceResume(sourceId: Long): String? = progress.sourceResume(sourceId)
    fun flushBackup() = BackupManager(app).flushCloudBackup()
    fun sourceResumeByName(sourceName: String): String? = progress.sourceResumeByName(sourceName)
    fun dailyGoal(): Int = db.getProgressMeta("rovex:goal:daily")?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    fun weeklyGoal(): Int = db.getProgressMeta("rovex:goal:weekly")?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    fun setDailyGoal(value: Int) = db.putProgressMeta("rovex:goal:daily", value.coerceIn(0,10000).toString())
    fun setWeeklyGoal(value: Int) = db.putProgressMeta("rovex:goal:weekly", value.coerceIn(0,50000).toString())
    fun qbankLibraryOrder(): List<Long> = db.getProgressMeta("rovex:qbank:order").orEmpty().split(',').mapNotNull{it.toLongOrNull()}
    fun setQBankLibraryOrder(ids: List<Long>) = db.putProgressMeta("rovex:qbank:order", ids.distinct().joinToString(","))
    fun latestResumeTarget(sources: List<Source>): ResumeTarget? {
        // There are two durable cursor stores for compatibility: the current session
        // SharedPreferences cursor and the transactional progress_meta cursor. Choose the
        // newest valid cursor instead of blindly preferring one store. This prevents an older
        // session cursor at Q1 from overriding a newer saved position such as Q25.
        // Transactional SQLite cursors are the durable source of truth for Home Continue.
        // StudySessionStore is retained as a compatibility/crash-resume fallback, but it can be
        // stale after Activity recreation and must never override a valid durable study cursor.
        val durableCandidates = mutableListOf<ResumeCursorCandidate<ResumeTarget>>()

        val solvedRaw = db.getProgressMeta("last_solved_global")
        if (!solvedRaw.isNullOrBlank()) {
            val parts = solvedRaw.split("|", limit = 4)
            val testId = parts.getOrNull(0).orEmpty()
            val pos = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val savedAt = parts.getOrNull(3)?.toLongOrNull() ?: 0L
            val test = testId.takeIf { it.isNotBlank() }?.let { db.testById(it) }
            if (test != null && db.getProgressMeta("${test.id}:completed") != "1") {
                val safePos = pos.coerceIn(0, (test.count - 1).coerceAtLeast(0))
                val question = runCatching { db.questionAt(test.id, safePos) }.getOrNull()
                durableCandidates += ResumeCursorCandidate(
                    ResumeTarget(test.id, question?.position ?: safePos, test.title, question?.id ?: 0L, question?.stableKey.orEmpty()),
                    savedAt, 3
                )
            }
        }

        val raw = db.getProgressMeta("last_resume_global")
        if (!raw.isNullOrBlank()) {
            val parts = raw.split("|", limit = 4)
            val testId = parts.getOrNull(0).orEmpty()
            val pos = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val savedAt = parts.getOrNull(3)?.toLongOrNull() ?: 0L
            val test = testId.takeIf { it.isNotBlank() }?.let { db.testById(it) }
            if (test != null && db.getProgressMeta("${test.id}:completed") != "1") {
                val safePos = pos.coerceIn(0, (test.count - 1).coerceAtLeast(0))
                val question = runCatching { db.questionAt(test.id, safePos) }.getOrNull()
                durableCandidates += ResumeCursorCandidate(
                    ResumeTarget(test.id, question?.position ?: safePos, test.title, question?.id ?: 0L, question?.stableKey.orEmpty()),
                    savedAt, 2
                )
            }
        }

        val sessionFallback = runCatching { StudySessionStore(app).current() }.getOrNull()?.let { session ->
            if (session.testId.isNotBlank() && !session.id.endsWith(":collection", true)) {
                db.testById(session.testId)?.let { test ->
                    if (db.getProgressMeta("${test.id}:completed") != "1") {
                        val safePos = session.position.coerceIn(0, (test.count - 1).coerceAtLeast(0))
                        val question = runCatching { db.questionAt(test.id, safePos) }.getOrNull()
                        if (question != null || safePos == 0) {
                            ResumeTarget(
                                test.id,
                                question?.position ?: safePos,
                                test.title,
                                question?.id ?: 0L,
                                question?.stableKey.orEmpty()
                            )
                        } else null
                    } else null
                }
            } else null
        }

        ResumeCursorPolicy.durableOrFallback(durableCandidates, sessionFallback)?.let { return it }
        return resumeTargets(sources).values.firstOrNull()
    }

    fun resumeTarget(source: Source): ResumeTarget? {
        // The global cursor is the authoritative most-recent study target. Prefer it when its
        // source matches this card; otherwise fall back to source-scoped legacy cursors. This
        // prevents an older sourceName cursor from sending Continue back to Q1.
        val global = db.getProgressMeta("last_resume_global")
        val globalParts = global?.split("|", limit = 4).orEmpty()
        val globalSourceId = globalParts.getOrNull(2)?.toLongOrNull() ?: 0L
        val raw = if (globalSourceId == source.id && globalParts.size >= 2) {
            "${globalParts[0]}|${globalParts[1]}"
        } else {
            sourceResumeByName(source.fileName) ?: sourceResume(source.id)
        } ?: return null
        val parts = raw.split("|", limit = 2)
        val testId = parts.getOrNull(0).orEmpty()
        if (testId.isBlank()) return null
        val test = db.testById(testId) ?: return null
        if (db.getProgressMeta("${test.id}:completed") == "1") return null
        val safePos = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, (test.count - 1).coerceAtLeast(0)) ?: 0
        val question = runCatching { db.questionAt(test.id, safePos) }.getOrNull()
        return ResumeTarget(test.id, question?.position ?: safePos, test.title, question?.id ?: 0L, question?.stableKey.orEmpty())
    }

    fun resumeTargets(sources: List<Source>): Map<Long, ResumeTarget> = buildMap {
        sources.forEach { source -> resumeTarget(source)?.let { put(source.id, it) } }
    }

    fun requestSourceDeletion(sourceId: Long): Boolean = db.requestSourceDeletion(sourceId)
    internal fun pendingDeletedQBanks(): List<QBankDeletedSourceRepository.PendingDeletedQBank> = db.pendingDeletedQBanks()

    fun purgeDeletedQBank(sourceId: Long): Boolean {
        if (!db.isPendingDeletedQBank(sourceId)) return false
        return db.deleteSource(sourceId, repairSearchIndex = true)
    }

    fun resetSourceProgress(sourceId: Long): Boolean {
        val currentTest = runCatching { StudySessionStore(app).current() }.getOrNull()?.testId
        val reset = db.resetSourceProgress(sourceId)
        if (reset) {
            if (!currentTest.isNullOrBlank() && db.sourceIdForTest(currentTest) == sourceId) {
                StudySessionStore(app).clear()
            }
            BackupManager(app).onProgressChanged(true)
            PerformanceManager.invalidateProgress()
            AppState.changed()
        }
        return reset
    }

    fun deleteSource(sourceId: Long): Boolean = db.deleteSource(sourceId)

    fun updateSourceMetadata(sourceId: Long, name: String, series: String): Boolean =
        db.updateSourceMetadata(sourceId, name, series)

    override fun close() {
        runCatching { db.close() }
    }
}
