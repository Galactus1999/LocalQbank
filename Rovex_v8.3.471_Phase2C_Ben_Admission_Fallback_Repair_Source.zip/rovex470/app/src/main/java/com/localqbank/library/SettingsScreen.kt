package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.isActive
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle

/** Presentation-only renderer for Settings. It does not own application engines or persistence. */
class SettingsScreen(private val activity: SettingsActivity, private val viewModel: SettingsViewModel) {
    private val lifecycleScope get() = activity.lifecycleScope
    private val neuralModelManager get() = activity.neuralModelManager
    private val section: String get() = activity.intent.getStringExtra("section") ?: "all"
    private val embeddingModelRequestCode = SettingsActivity.REQUEST_EMBEDDING_MODEL
    private val generativeModelRequestCode = SettingsActivity.REQUEST_GENERATIVE_MODEL
    private val embeddingTokenizerRequestCode = SettingsActivity.REQUEST_EMBEDDING_TOKENIZER
    private fun dp(v:Int)= (v*activity.resources.displayMetrics.density).toInt()
    /** Class-level helper: safe from Kotlin local-function scope leakage across SettingsScreen methods. */
    private fun mutedText(t:String,size:Float=11.5f)=TextView(activity).apply{
        text=t; textSize=size; setTextColor(ThemeManager.muted(activity))
    }

    fun buildRoot():ScrollView = build()

    private fun build():ScrollView{
        if(section=="all") return buildSettingsMenu()
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(12),dp(18),dp(28));background=ThemeManager.backgroundDrawable(activity)}
        root.addView(TextView(activity).apply{
            text="←  Settings";textSize=14f;gravity=Gravity.CENTER_VERTICAL;setTextColor(ThemeManager.accent(activity));setPadding(0,0,0,dp(8));setOnClickListener{activity.finish()}
        },LinearLayout.LayoutParams(-1,dp(38)))
        val titleText=when(section){
            "adaptive"->"Adaptive Engines"
            "adaptive_study"->"Adaptive Study"
            "performance"->"Performance & Resources"
            "ben_safety"->"Ben Safety"
            "privacy"->"Privacy & Security"
            "diagnostics"->"Test & Diagnostics Center"
            "appearance"->"Appearance & Themes"
            "fonts"->"Quiz Typography"
            else->"Settings"
        }
        root.addView(TextView(activity).apply{text=titleText;textSize=27f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));setPadding(0,0,0,dp(6))})
        when(section){
            "appearance"->addAppearance(root)
            "fonts"->addFonts(root)
            "adaptive"->addAdaptiveEngine(root)
            "adaptive_study"->addAdaptiveStudy(root)
            "performance"->addPerformance(root)
            "ben_safety"->addBenSafetyPage(root)
            "privacy"->addPrivacyPage(root)
            "diagnostics"->addDiagnosticsPage(root)
        }
        return ScrollView(activity).apply{addView(root);isFillViewport=true}
    }

    private fun buildSettingsMenu():ScrollView{
        val state = AppManagers.adaptive.state()
        val root=LinearLayout(activity).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(18),dp(18),dp(30))
            background=ThemeManager.backgroundDrawable(activity)
        }

        fun card(background:Int = Color.TRANSPARENT, radius:Int = 18):LinearLayout =
            LinearLayout(activity).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(dp(14),dp(13),dp(14),dp(13))
                this.background=if(background==Color.TRANSPARENT) ThemeManager.transparentSectionDrawable(activity) else rounded(background,radius)
            }
        fun heading(t:String,size:Float=18f)=TextView(activity).apply{
            text=t; textSize=size; typeface=Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(activity))
        }
        fun metric(value:String,label:String,tint:Int):LinearLayout = LinearLayout(activity).apply{
            orientation=LinearLayout.VERTICAL; setPadding(dp(11),dp(10),dp(11),dp(9))
            background=rounded(if(ThemeManager.isDark(activity))Color.rgb(20,28,37) else Color.rgb(248,249,249),13)
            addView(TextView(activity).apply{text=value;textSize=20f;typeface=Typeface.DEFAULT_BOLD;setTextColor(tint)},LinearLayout.LayoutParams(-1,dp(26)))
            addView(TextView(activity).apply{text=label;textSize=10.5f;setTextColor(ThemeManager.muted(activity))})
        }
        // v2 row: bigger 46dp icon tile with a two-tone fill (soft base + solid glyph disc)
        // so it reads as an icon rather than a coloured letter, subtitle now visible (the
        // old row dropped it entirely, which is why every row read as "just a title"),
        // and the chevron sits in its own faint chip instead of floating loose text.
        fun category(title:String,subtitle:String,icon:String,tint:Int,click:()->Unit)=LinearLayout(activity).apply{
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(14),dp(14),dp(12),dp(14))
            val dark=ThemeManager.isDark(activity)
            background=GradientDrawable().apply{setColor(ThemeManager.elevated(activity));cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.argb(if(dark)70 else 45,Color.red(tint),Color.green(tint),Color.blue(tint)))}
            val iconTile=FrameLayout(activity).apply{background=GradientDrawable().apply{setColor(Color.argb(if(dark)50 else 26,Color.red(tint),Color.green(tint),Color.blue(tint)));cornerRadius=dp(14).toFloat()}}
            iconTile.addView(TextView(activity).apply{text=icon;textSize=19f;gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD;setTextColor(tint)},FrameLayout.LayoutParams(-1,-1))
            addView(iconTile,LinearLayout.LayoutParams(dp(46),dp(46)).apply{setMargins(0,0,dp(12),0)})
            val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
            copy.addView(TextView(activity).apply{text=title;textSize=15.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
            copy.addView(TextView(activity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(activity));maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setLineSpacing(0f,1.1f);setPadding(0,dp(2),0,0)})
            addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            val chevron=FrameLayout(activity).apply{background=rounded(if(dark)Color.rgb(24,32,41) else Color.rgb(240,242,244),13)}
            chevron.addView(TextView(activity).apply{text="›";textSize=18f;gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.muted(activity))},FrameLayout.LayoutParams(-1,-1))
            addView(chevron,LinearLayout.LayoutParams(dp(26),dp(26)).apply{setMargins(dp(8),0,0,0)})
            setOnClickListener{click()}
        }
        fun sectionLabel(t:String,sub:String){
            root.addView(TextView(activity).apply{text=t.uppercase();textSize=11f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity));letterSpacing=0.06f;setPadding(dp(2),dp(22),dp(2),dp(6))})
        }

        // Header / overview hero.
        val header=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        header.addView(TextView(activity).apply{text="←";textSize=25f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(activity));background=rounded(ThemeManager.elevated(activity),16);setOnClickListener{activity.finish()}},LinearLayout.LayoutParams(dp(50),dp(50)))
        val headerCopy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),0,0,0)}
        headerCopy.addView(heading("Settings",28f))
        headerCopy.addView(mutedText("Rovex • Smarter Study. Brighter Tomorrow.",11.5f))
        header.addView(headerCopy,LinearLayout.LayoutParams(0,-2,1f))
        header.addView(RovexHeaderCosmicView(activity).apply{
            contentDescription = "Rovex cosmic header"
        },LinearLayout.LayoutParams(dp(96),dp(46)))
        root.addView(header)

        root.addView(card().apply{
            setPadding(dp(16),dp(15),dp(16),dp(15))
            addView(heading("Settings Control Center",19f))
            addView(mutedText("Organized by what you want to control—not by implementation detail.",11.5f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,dp(10))})
            val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL}
            row.addView(metric("${state.learningScore}%","learning",ThemeManager.accent(activity)),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(0,0,dp(5),0)})
            row.addView(metric("${state.confidence}%","confidence",ThemeManager.text(activity)),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(dp(3),0,dp(3),0)})
            row.addView(metric("${state.health}%","engine health",if(state.safeMode)Color.rgb(255,170,80) else Color.rgb(70,210,130)),LinearLayout.LayoutParams(0,dp(68),1f).apply{setMargins(dp(5),0,0,0)})
            addView(row)
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(7))})

        // Main Settings is intentionally an index, not a duplicate of any detail dashboard.
        // Detailed Adaptive/Performance/Safety dashboards live behind their own routes.
        sectionLabel("Appearance & UI","Visual identity and readability are intentionally separated from adaptive intelligence.")
        // Compact, bounded control: never allow a weighted child to make this row consume the
        // remaining Settings viewport. The previous nested weight could produce the enormous
        // empty card seen on-device.
        root.addView(card().apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(10), dp(10))
            minimumHeight = dp(68)
            addView(LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                addView(heading("Sound feedback", 15.5f), LinearLayout.LayoutParams(-1, dp(24)))
                addView(mutedText("Short cues for answers and milestones.", 10.5f), LinearLayout.LayoutParams(-1, dp(20)).apply { topMargin = dp(1) })
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
            val soundToggle = FrameLayout(activity).apply {
                contentDescription = "Sound feedback toggle"
                isClickable = true; isFocusable = true
                val track = GradientDrawable().apply { cornerRadius = dp(14).toFloat() }
                val knob = TextView(activity).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL } }
                addView(knob, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER_VERTICAL or Gravity.START))
                fun refresh(on: Boolean) {
                    track.setColor(if (on) ThemeManager.accent(activity) else ThemeManager.muted(activity))
                    track.alpha = if (on) 220 else 95
                    background = track
                    (knob.background as? GradientDrawable)?.setColor(if (on) ThemeManager.onAccent(activity) else ThemeManager.elevated(activity))
                    knob.translationX = if (on) dp(22).toFloat() else dp(2).toFloat()
                    contentDescription = if (on) "Sound feedback enabled" else "Sound feedback disabled"
                }
                refresh(RovexSoundFeedback.isEnabled(activity))
                setOnClickListener {
                    val next = !RovexSoundFeedback.isEnabled(activity)
                    RovexSoundFeedback.setEnabled(activity, next)
                    refresh(next)
                }
            }
            addView(TextView(activity).apply {
                text = "TEST"; textSize = 9f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setTextColor(ThemeManager.text(activity)); background = rounded(ThemeManager.elevated(activity), 9)
                setOnClickListener {
                    RovexSoundFeedback.setEnabled(activity, true)
                    val played = RovexSoundFeedback.playTest(activity)
                    if (!played) Toast.makeText(activity, "Audio sample is still loading; tap TEST again.", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(dp(48), dp(30)).apply { gravity = Gravity.CENTER_VERTICAL; rightMargin = dp(6) })
            addView(soundToggle, LinearLayout.LayoutParams(dp(44), dp(26)).apply { gravity = Gravity.CENTER_VERTICAL })
        }, LinearLayout.LayoutParams(-1, dp(68)).apply { setMargins(0, dp(8), 0, dp(6)) })
        sectionLabel("Appearance & Study","Core presentation, reading, sound and notification controls.")
        root.addView(category("Themes","Light, Pastel, Mint, Sunset, Lavender, AMOLED, Pandora and Space","●",Color.rgb(255,180,70)){showThemeDialog()})
        root.addView(category("Typography","Quiz font family and reading density","Aa",Color.rgb(100,180,255)){showFontDialog()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("Colour flow","Flow colors, greeting panel and normal-text mode","≈",Color.rgb(230,100,180)){showColourFlowDialog()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("AI Chat Display","Prefer readable sections instead of tables in AI + Search and Frankenstein","▤",Color.rgb(110,180,255)){showAiChatDisplayDialog()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("Settings Search","Search only Rovex settings — never questions or QBanks","⌕",ThemeManager.accent(activity)){showSettingsSearch()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("Reference PDFs for Ben","Import local PDFs for bounded offline retrieval and AI context","▤",Color.rgb(80,180,210)){activity.startActivity(Intent(activity,BenPdfImportActivity::class.java))},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})

        sectionLabel("Intelligence & Automation","Adaptive learning and Ben controls are separated so each screen has one clear purpose.")
        root.addView(category("Adaptive Study","Learning signals, study strategy and contextual SRS","✦",Color.rgb(170,100,255)){openSection("adaptive_study")})
        root.addView(category("Adaptive Engines","Ben edge, cognitive core, neural lab and runtime policy","🧠",Color.rgb(175,110,255)){openSection("adaptive")},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("Ben Safety","Kill switch, model guardrails and emergency stop","◆",Color.rgb(90,205,150)){openSection("ben_safety")},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("Cloud AI & Gemini","Optional user-controlled cloud fallback and encrypted API-key settings","G",Color.rgb(90,165,235)){showCloudAiProvidersDialog()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("Rovex Online","Google login, private friends and synced study progress","☁",Color.rgb(80,190,235)){activity.startActivity(Intent(activity,RovexOnlineActivity::class.java))},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})

        sectionLabel("Data & Continuity","Progress protection, import/export and recovery are kept independent from cognition.")
        root.addView(category("Backups & Restore","Protect study progress and restore local backups","☁",Color.rgb(75,160,245)){activity.startActivity(Intent(activity,BackupActivity::class.java))})
        root.addView(category("Study & Notifications","Sound feedback, streak reminders and notification permission","♢",Color.rgb(235,150,75)){showStudyNotificationSettings()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})
        root.addView(category("Question banks & content","Imported QBank/APKG/HTML content remains local and authoritative","▤",Color.rgb(70,205,190)){Toast.makeText(activity,"QBank/content management remains in the main study modules.",Toast.LENGTH_SHORT).show()},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})

        sectionLabel("System & Data","Device policy, recovery and protected data are separate from Ben cognition.")
        root.addView(category("Performance & Resources","RAM, thermal, battery, runtime and resilience","◈",Color.rgb(245,175,65)){openSection("performance")})
        root.addView(category("Privacy & Security","Data boundaries, permissions and local-storage policy","✓",Color.rgb(85,210,135)){openSection("privacy")},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})

        sectionLabel("Advanced","Only genuinely advanced controls live here.")
        root.addView(category("Test & Diagnostics Center","Full EmbeddingGemma test, Ben IPC telemetry and exportable runtime reports","⌁",Color.rgb(120,145,255)){openSection("diagnostics")})
        root.addView(category("About Rovex","Product identity, runtime architecture and safety boundary","ⓘ",Color.rgb(120,200,230)){
            val versionInfo=resultOf {activity.packageManager.getPackageInfo(activity.packageName,0)}.getOrNull()
            val version=versionInfo?.versionName ?: "unknown"
            val code=versionInfo?.longVersionCode?.toString() ?: "unknown"
            val about=LinearLayout(activity).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(dp(16),dp(12),dp(16),dp(8))
                setBackgroundResource(ThemeManager.dialogBg(activity))
            }
            fun label(text:String)=TextView(activity).apply{
                this.text=text; textSize=10.5f; typeface=Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.accent(activity)); setPadding(0,dp(9),0,dp(3))
            }
            fun value(text:String)=TextView(activity).apply{
                this.text=text; textSize=12f; setTextColor(ThemeManager.text(activity))
                setLineSpacing(0f,1.08f); setPadding(0,0,0,dp(4))
            }
            about.addView(TextView(activity).apply{text="Rovex";textSize=25f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
            about.addView(TextView(activity).apply{text="Offline-first medical study workspace";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(2),0,dp(8))})
            val metrics=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL}
            fun metric(v:String,k:String)=LinearLayout(activity).apply{
                orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(8),dp(8))
                background=ThemeManager.transparentSectionDrawable(activity)
                addView(TextView(activity).apply{text=v;textSize=15f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
                addView(TextView(activity).apply{text=k;textSize=9.5f;setTextColor(ThemeManager.muted(activity))})
            }
            metrics.addView(metric(version,"version"),LinearLayout.LayoutParams(0,dp(56),1f).apply{setMargins(0,0,dp(4),0)})
            metrics.addView(metric(code,"version code"),LinearLayout.LayoutParams(0,dp(56),1f).apply{setMargins(dp(4),0,0,0)})
            about.addView(metrics)
            about.addView(TextView(activity).apply{text="Application ID  •  ${activity.packageName}";textSize=10.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(7),0,dp(2));setTypeface(Typeface.MONOSPACE)})
            about.addView(label("CORE")); about.addView(value("Deterministic local QBank, progress, collections, SRS, import/export and recovery remain authoritative."))
            about.addView(label("BEN / FRANKENSTEIN")); about.addView(value("Adaptive routing, local retrieval, cognitive tools, verifier-first grounding and optional neural accelerators. Neural inference is isolated, resource-governed and has deterministic fallback."))
            about.addView(label("DATA BOUNDARY")); about.addView(value("Study content and progress are local-first. Optional external AI providers are user-controlled integrations; API keys are stored locally through Android Keystore-backed encryption."))
            about.addView(label("SAFETY")); about.addView(value("Startup checks structural readiness without network calls or cold neural inference. Runtime health, thermal state, cancellation and process failures are guarded before neural work is admitted."))
            about.addView(label("UI SYSTEM")); about.addView(value("Theme atmosphere, transparent sections, compact analytics, semantic colour, accessibility labels and responsive layouts are shared across the study surfaces."))
            about.addView(TextView(activity).apply{text="Deterministic verification remains the final authority.";textSize=11f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(8),0,dp(6))})
            AlertDialog.Builder(activity).setView(about).setPositiveButton("DONE",null).show()
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,0)})

        root.addView(card().apply{
            setPadding(dp(15),dp(14),dp(15),dp(14))
            addView(TextView(activity).apply{text="Safety boundary";textSize=15f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
            addView(mutedText("Adaptive and Ben systems may tune safe runtime policy only. They cannot modify executable code, source QBank content, or bypass the deterministic verifier.",11f),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,0)})
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(16),0,dp(6))})
        root.addView(TextView(activity).apply{text="Settings are applied locally. Detailed engine controls remain under Adaptive Engines.";textSize=10.5f;setTextColor(ThemeManager.muted(activity));setPadding(dp(3),dp(4),dp(3),0)})

        return ScrollView(activity).apply{addView(root);isFillViewport=true}
    }

    private fun showSettingsSearch(){
        data class SettingHit(val title:String,val description:String,val keywords:String,val action:()->Unit)
        val entries=listOf(
            SettingHit("Themes","Light, Pastel, Mint, Sunset, Lavender, AMOLED, Pandora and Space","theme themes dark mode light amoled black midnight blue colour color appearance background"){showThemeDialog()},
            SettingHit("Typography","Quiz font family and reading density","font fonts text typeface typography size reading serif sans condensed"){showFontDialog()},
            SettingHit("Colour flow","Flow colours, greeting panel and normal-text mode","colour color flow gradient greeting panel labels rainbow animation"){showColourFlowDialog()},
            SettingHit("AI Chat Display","Control whether AI chat tables are shown as grids or readable sections","ai chat tables table display show hide grid sections markdown renderer formatting"){showAiChatDisplayDialog()},
            SettingHit("Sound feedback","Enable or disable study interaction sounds","sound audio click feedback mp3 haptic vibration"){Toast.makeText(activity,if(RovexSoundFeedback.isEnabled(activity))"Sound feedback is enabled" else "Sound feedback is disabled",Toast.LENGTH_SHORT).show()},
            SettingHit("Reference PDFs for Ben","Import local PDFs for bounded offline retrieval","pdf pdfs documents reference ben knowledge retrieval offline"){activity.startActivity(Intent(activity,BenPdfImportActivity::class.java))},
            SettingHit("Adaptive Study","Learning signals, study strategy and contextual SRS","adaptive study learning srs strategy retention scheduling personalization"){openSection("adaptive_study")},
            SettingHit("Adaptive Engines","Ben cognition, RAG, specialists, verifier and neural runtime controls","adaptive engine ben brain cognitive core rag retrieval specialist planner verifier neural gemma embedding inference model"){openSection("adaptive")},
            SettingHit("Ben Safety","Kill switch, memory guard and emergency stop","ben safety stop kill switch emergency model memory guard ram resource governor"){openSection("ben_safety")},
            SettingHit("Performance & Resources","RAM, thermal, battery, runtime and resilience","performance ram memory thermal battery power save speed resource resilience background workers"){openSection("performance")},
            SettingHit("Privacy & Security","Data boundaries, permissions and local-storage policy","privacy security permissions storage data local network internet keys keystore"){openSection("privacy")},
            SettingHit("Test & Diagnostics Center","EmbeddingGemma, Ben IPC telemetry and runtime reports","diagnostic diagnostics test embeddinggemma gemma ipc binder qnn qairt crash report telemetry"){openSection("diagnostics")},
            SettingHit("Backups & Restore","Protect and restore local study data","backup backups restore recovery export import progress safety"){activity.startActivity(Intent(activity,BackupActivity::class.java))},
            SettingHit("Study & Notifications","Sound feedback, streak reminders and notification permission","study notifications reminder streak alerts permission daily"){showStudyNotificationSettings()},
            SettingHit("Cloud AI & Gemini","Optional cloud providers and encrypted API keys","cloud ai gemini groq openrouter deepseek provider api key key internet online fallback"){showCloudAiProvidersDialog()},
            SettingHit("Rovex Online","Google login, private friends and synced study progress","online friends google login account sync leaderboard competition progress cloud firebase"){activity.startActivity(Intent(activity,RovexOnlineActivity::class.java))},
            SettingHit("Question banks & content","Imported QBank/APKG/HTML content","qbank qbanks question bank content apkg html import delete source"){Toast.makeText(activity,"QBank/content management remains in the main study modules.",Toast.LENGTH_SHORT).show()},
            SettingHit("About Rovex","Version, architecture and safety boundary","about version app architecture identity safety"){Toast.makeText(activity,"Rovex settings and architecture information are shown in About Rovex.",Toast.LENGTH_SHORT).show()}
        )
        fun score(hit:SettingHit,query:String):Int{
            val q=query.trim().lowercase(); if(q.isBlank())return 0
            val title=hit.title.lowercase(); val desc=hit.description.lowercase(); val keys=hit.keywords.lowercase(); val words=q.split(Regex("\\s+")).filter{it.isNotBlank()}; var score=0
            if(title==q)score+=100; if(title.contains(q))score+=60
            words.forEach{w->if(title.contains(w))score+=30;if(keys.contains(w))score+=18;if(desc.contains(w))score+=10}
            return score
        }
        showSettingsSheet("Settings Search","Search only Rovex settings — never questions or QBank content.") { body, _ ->
            val searchBox=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(13),0,dp(8),0);background=rounded(ThemeManager.elevated(activity),16)}
            searchBox.addView(TextView(activity).apply{text="⌕";textSize=22f;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity))},LinearLayout.LayoutParams(dp(30),dp(52)))
            val input=EditText(activity).apply{hint="Search settings…  theme, AI, Gemma, RAM";setSingleLine(true);textSize=14f;setTextColor(ThemeManager.text(activity));setHintTextColor(ThemeManager.muted(activity));background=null;imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH}
            searchBox.addView(input,LinearLayout.LayoutParams(0,dp(52),1f))
            val clear=TextView(activity).apply{text="×";textSize=20f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(activity));setOnClickListener{input.text.clear()}}
            searchBox.addView(clear,LinearLayout.LayoutParams(dp(36),dp(52)))
            body.addView(searchBox,LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(10)})
            val resultList=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
            body.addView(resultList)
            fun refresh(q:String){
                resultList.removeAllViews()
                val results=entries.map{it to score(it,q)}.filter{q.isBlank()||it.second>0}.sortedWith(compareByDescending<Pair<SettingHit,Int>>{it.second}.thenBy{it.first.title}).take(30)
                results.forEach{(hit,_)->
                    val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(13),dp(11),dp(10),dp(11));background=rounded(ThemeManager.elevated(activity),16);setOnClickListener{hit.action()}}
                    val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
                    copy.addView(TextView(activity).apply{text=hit.title;textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
                    copy.addView(TextView(activity).apply{text=hit.description;textSize=10.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(2),0,0);maxLines=2})
                    row.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
                    row.addView(TextView(activity).apply{text="›";textSize=20f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(activity))},LinearLayout.LayoutParams(dp(28),dp(28)))
                    resultList.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})
                }
                if(results.isEmpty()) resultList.addView(TextView(activity).apply{text="No matching setting. Try theme, AI, Ben, study, backup, security or performance.";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(dp(12),dp(16),dp(12),dp(16))})
            }
            input.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){refresh(s?.toString().orEmpty())};override fun afterTextChanged(e:android.text.Editable?){}})
            refresh("")
        }
    }

    private fun openSection(target:String){
        activity.startActivity(Intent(activity,SettingsActivity::class.java).putExtra("section",target))
    }

    private fun showEmbeddingDiagnosticReport(report: String){
        val dialog=Dialog(activity)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(12));background=rounded(ThemeManager.dialogBg(activity),22)}
        root.addView(TextView(activity).apply{text="Ben / EmbeddingGemma Diagnostic";textSize=21f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        val scroll=ScrollView(activity)
        scroll.addView(TextView(activity).apply{text=report;textSize=11f;setTextColor(ThemeManager.text(activity));setPadding(0,dp(10),0,dp(10));setTypeface(Typeface.MONOSPACE)})
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val actions=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        actions.addView(TextView(activity).apply{text="SHARE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{
            activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"Rovex Ben EmbeddingGemma Diagnostic");putExtra(Intent.EXTRA_TEXT,report)},"Share diagnostic report"))
        }},LinearLayout.LayoutParams(0,dp(44),1f))
        actions.addView(TextView(activity).apply{text="CLOSE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(0,dp(44),1f))
        root.addView(actions)
        dialog.setContentView(root);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.94f).toInt(),(activity.resources.displayMetrics.heightPixels*0.82f).toInt())
    }

    private fun showBenAiSafetyDialog(){
        val policy = BenAiRuntimePolicy(activity)
        val dialog=Dialog(activity)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Ben AI Safety";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Control Ben local neural execution before it can consume significant memory or native resources.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(14))})
        val enabled=android.widget.Switch(activity).apply{text="AI Accelerator • Allow Ben local model";isChecked=policy.enabled;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,checked->policy.setEnabled(checked)}}
        root.addView(enabled)
        val conservative=android.widget.Switch(activity).apply{text="Conservative memory guard";isChecked=policy.conservativeMode;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,checked->policy.setConservativeMode(checked)}}
        root.addView(conservative)
        root.addView(TextView(activity).apply{text="When enabled, future model backends must pass the conservative 1.2 GB model-size gate before loading. Turning off the model switch is a persistent kill switch.";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(8),0,dp(12))})
        root.addView(TextView(activity).apply{text="STOP BEN MODEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(8));setOnClickListener{policy.forceStop();enabled.isChecked=false}})
        root.addView(TextView(activity).apply{text="DONE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show()
    }

    private fun showThemeDialog(){
        val keys=arrayOf(ThemeManager.LIGHT,ThemeManager.PASTEL,ThemeManager.MINT,ThemeManager.SUNSET,ThemeManager.LAVENDER,ThemeManager.AMOLED,ThemeManager.PANDORA,ThemeManager.SPACE)
        val labels=arrayOf("Light","Pastel","Mint","Sunset","Lavender","AMOLED • Cosmos","Pandora • Living World","Space • Deep Cosmos")
        val descriptions=arrayOf("Clean airy daylight","Glossy blue-violet study UI","Fresh mint clinical UI","Warm orange-coral energy UI","Purple-blue focused study UI","Pure-black OLED with a sparse cosmic sky","Bioluminescent living world with wildlife, flora and fireflies","Deep-space starfield with nebulae, planets and rings")
        val dialog=Dialog(activity)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Theme";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Choose the reading environment that feels right.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(12))})
        val current=ThemeManager.get(activity)
        keys.forEachIndexed{index,key->
            val selected=current==key
            val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(10),dp(10));background=rounded(if(selected)ThemeManager.optionBg(activity) else ThemeManager.elevated(activity),16)}
            val swatch=TextView(activity).apply{text="  ";background=rounded(themeSwatch(key),10);setPadding(dp(5),dp(5),dp(5),dp(5))}
            row.addView(swatch,LinearLayout.LayoutParams(dp(38),dp(38)))
            val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(6),0)}
            copy.addView(TextView(activity).apply{text=labels[index];textSize=15.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
            copy.addView(TextView(activity).apply{text=descriptions[index];textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(2),0,0)})
            row.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(activity).apply{text=if(selected)"✓" else "";textSize=20f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity))},LinearLayout.LayoutParams(dp(28),dp(38)))
            row.setOnClickListener{viewModel.setTheme(key);dialog.dismiss();activity.recreate()}
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        root.addView(TextView(activity).apply{text="CANCEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root)
        dialog.setOnShowListener{_ -> dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showFontDialog(){
        val keys=arrayOf("sans-serif","serif","sans-serif-condensed","monospace")
        val labels=arrayOf("Modern Sans","Textbook Serif","Compact Sans","Monospace")
        val samples=arrayOf("A  B  C  •  123","Question • Explanation","Rapid revision text","A = B + C")
        val current=viewModel.quizFont()
        val dialog=Dialog(activity)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(16));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Fonts";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Preview how question text will feel before applying it.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(12))})
        keys.forEachIndexed{index,key->
            val selected=current==key
            val row=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(11),dp(12),dp(11));background=rounded(if(selected)ThemeManager.optionBg(activity) else ThemeManager.elevated(activity),16)}
            val top=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            top.addView(TextView(activity).apply{text=labels[index];textSize=15.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));typeface=Typeface.create(key,Typeface.BOLD)},LinearLayout.LayoutParams(0,-2,1f))
            top.addView(TextView(activity).apply{text=if(selected)"✓" else "";textSize=20f;setTextColor(ThemeManager.accent(activity));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(30)))
            row.addView(top)
            row.addView(TextView(activity).apply{text=samples[index];textSize=15f;typeface=Typeface.create(key,Typeface.NORMAL);setTextColor(ThemeManager.text(activity));setPadding(0,dp(5),0,0)})
            row.setOnClickListener{viewModel.setQuizFont(key);dialog.dismiss();activity.recreate()}
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        root.addView(TextView(activity).apply{text="CANCEL";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(10),0,dp(4));setOnClickListener{dialog.dismiss()}})
        dialog.setContentView(root)
        dialog.setOnShowListener{_ -> dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*0.90f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showColourFlowDialog(){
        var c1=viewModel.flowColorOne()
        var c2=viewModel.flowColorTwo()
        var panel=viewModel.flowGreetingColor()
        var flow=viewModel.flowTextEnabled()
        val dialog=Dialog(activity)
        val root=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));background=rounded(ThemeManager.dialogBg(activity),24)}
        root.addView(TextView(activity).apply{text="Colour flow";textSize=23f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        root.addView(TextView(activity).apply{text="Choose two colours. They blend and travel across the flow labels.";textSize=12.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(4),0,dp(12))})
        val preview=TextView(activity).apply{text="Performance  •  Flashcards  •  Solved";textSize=16f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(dp(8),dp(10),dp(8),dp(10))}
        root.addView(preview,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(10))})
        fun refresh(){
            preview.background=GradientDrawable().apply{cornerRadius=dp(12).toFloat();setColor(if(ThemeManager.get(activity)==ThemeManager.AMOLED)ThemeManager.panel(activity) else ThemeManager.elevated(activity));setStroke(dp(1),RovexColorFlowTextView.mix(c1,c2,.5f))}
            preview.paint.shader=android.graphics.LinearGradient(0f,0f,preview.width.coerceAtLeast(dp(220)).toFloat(),0f,intArrayOf(c1,RovexColorFlowTextView.mix(c1,c2,.5f),c2),null,android.graphics.Shader.TileMode.CLAMP)
            preview.invalidate()
        }
        fun addSpectrum(label:String,initial:Int,onChange:(Int)->Unit){
            root.addView(TextView(activity).apply{text=label;textSize=12f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.muted(activity));setPadding(dp(2),dp(3),0,dp(1))})
            val bar=RovexColorSpectrumView(activity).apply{color=initial;this.onColorChanged={onChange(it);refresh()}}
            root.addView(bar,LinearLayout.LayoutParams(-1,dp(88)).apply{setMargins(0,0,0,dp(4))})
        }
        addSpectrum("FLOW COLOUR 1",c1){c1=it;refresh()}
        addSpectrum("FLOW COLOUR 2",c2){c2=it;refresh()}
        val normal=CheckBox(activity).apply{text="Keep colour-flow labels as normal text";textSize=13f;isChecked=!flow;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,checked->flow=!checked}}
        root.addView(normal)
        root.addView(TextView(activity).apply{text="Greeting panel colour";textSize=13f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));setPadding(dp(2),dp(12),0,dp(2))})
        val panelBar=RovexColorSpectrumView(activity).apply{color=if(panel==0)Color.rgb(35,101,126) else panel;onColorChanged={panel=it}}
        root.addView(panelBar,LinearLayout.LayoutParams(-1,dp(88)).apply{setMargins(0,0,0,dp(4))})
        root.addView(TextView(activity).apply{text="The panel behind Good morning / afternoon / evening uses this colour.";textSize=11f;setTextColor(ThemeManager.muted(activity));setPadding(dp(2),0,0,dp(8))})
        val buttons=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        buttons.addView(TextView(activity).apply{text="RESET";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setOnClickListener{viewModel.resetColourFlow();dialog.dismiss();activity.recreate()}},LinearLayout.LayoutParams(0,dp(46),1f))
        buttons.addView(TextView(activity).apply{text="SAVE";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setOnClickListener{viewModel.saveColourFlow(c1,c2,flow,panel);dialog.dismiss();activity.recreate()}},LinearLayout.LayoutParams(0,dp(46),1f))
        root.addView(buttons)
        refresh()
        dialog.setContentView(root);dialog.setOnShowListener{dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)};dialog.show();dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showAiChatDisplayDialog(){
        val enabled = RovexTableDisplayPrefs.showTables(activity)
        val dialog = Dialog(activity)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            background = rounded(ThemeManager.dialogBg(activity), 24)
        }
        root.addView(TextView(activity).apply {
            text = "AI Chat Display"; textSize = 23f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(activity))
        })
        root.addView(TextView(activity).apply {
            text = "Normal AI explanations use sections and lists. Enable this only if you want genuine Markdown tables rendered as tables in chat."
            textSize = 12.5f; setTextColor(ThemeManager.muted(activity)); setPadding(0, dp(4), 0, dp(12))
        })
        val toggle = android.widget.Switch(activity).apply {
            text = "Show tables in AI chat"; textSize = 14f; isChecked = enabled
            setTextColor(ThemeManager.text(activity))
            setOnCheckedChangeListener { _, checked -> RovexTableDisplayPrefs.setShowTables(activity, checked) }
        }
        root.addView(toggle)
        root.addView(TextView(activity).apply {
            text = "OFF (default): tables are explained as readable sections. A direct request such as “make a table” can still be honored."
            textSize = 11f; setTextColor(ThemeManager.muted(activity)); setPadding(0, dp(7), 0, dp(10))
        })
        root.addView(TextView(activity).apply {
            text = "DONE"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.accent(activity)); setPadding(0, dp(10), 0, dp(4))
            setOnClickListener { dialog.dismiss() }
        })
        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setOnShowListener { dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels * .92f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT) }
        dialog.show()
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels * .92f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showExamProfileDialog(){
        val choices=enumValues<BenExamProfile>()
        val current=currentBenExamProfile(activity)
        val labels=choices.map{it.label}.toTypedArray()
        val checked=choices.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(activity)
            .setTitle("Exam Profile")
            .setSingleChoiceItems(labels,checked){dialog,which->
                setBenExamProfile(activity,choices[which])
                dialog.dismiss()
                Toast.makeText(activity,"Exam profile: ${choices[which].label}",Toast.LENGTH_SHORT).show()
                activity.recreate()
            }.setNegativeButton("CANCEL",null).show()
    }

    private fun themeSwatch(key:String):Int=when(key){
        ThemeManager.LIGHT->Color.rgb(247,249,255)
        ThemeManager.PASTEL->Color.rgb(226,238,255)
        ThemeManager.MINT->Color.rgb(214,250,240)
        ThemeManager.SUNSET->Color.rgb(255,230,210)
        ThemeManager.LAVENDER->Color.rgb(235,225,255)
        ThemeManager.AMOLED->Color.BLACK
        ThemeManager.PANDORA->Color.rgb(10,72,60)
        ThemeManager.SPACE->Color.rgb(16,28,82)
        else->Color.rgb(247,249,255)
    }

    private fun addAppearance(root:LinearLayout){
        section(root,"APPEARANCE")
        val themes=linkedMapOf(ThemeManager.LIGHT to "Light",ThemeManager.PASTEL to "Pastel",ThemeManager.MINT to "Mint",ThemeManager.SUNSET to "Sunset",ThemeManager.LAVENDER to "Lavender",ThemeManager.AMOLED to "AMOLED",ThemeManager.PANDORA to "Pandora • Living World",ThemeManager.SPACE to "Space • Deep Cosmos")
        themes.forEach{(key,label)-> root.addView(button(if(ThemeManager.get(activity)==key)"✓  $label" else label){viewModel.setTheme(key);activity.recreate()},lp())}
    }

    private fun addFonts(root:LinearLayout){
        section(root,"QUIZ TYPOGRAPHY")
        val fonts=linkedMapOf("sans-serif" to "Modern Sans","serif" to "Serif / textbook","monospace" to "Monospace / coding","sans-serif-condensed" to "Condensed Sans","sans-serif-light" to "Light Sans")
        val current=viewModel.quizFont()
        fonts.forEach{(key,label)->root.addView(button(if(current==key)"✓  $label" else label){viewModel.setQuizFont(key);activity.recreate()},lp())}
    }

    private fun visualCard(root:LinearLayout, titleText:String, subtitle:String, body:LinearLayout.()->Unit){
        val dark=ThemeManager.isDark(activity)
        val card=LinearLayout(activity).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(13),dp(14),dp(13))
            background=GradientDrawable().apply{setColor(Color.TRANSPARENT);cornerRadius=dp(16).toFloat();val a=ThemeManager.accent(activity);setStroke(dp(1),Color.argb(if(dark)95 else 65,Color.red(a),Color.green(a),Color.blue(a)))}
        }
        card.addView(TextView(activity).apply{text=titleText;textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        body(card)
        root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(9))})
    }
    private fun tableRow(parent:LinearLayout, key:String, value:String, strong:Boolean=false){
        val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(7),dp(8),dp(7))}
        row.addView(TextView(activity).apply{text=key;textSize=10f;setTextColor(ThemeManager.muted(activity))},LinearLayout.LayoutParams(0,-2,.43f))
        row.addView(TextView(activity).apply{text=value;textSize=10.5f;typeface=if(strong)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;setTextColor(if(strong)ThemeManager.accent(activity)else ThemeManager.text(activity));gravity=Gravity.RIGHT},LinearLayout.LayoutParams(0,-2,.57f))
        parent.addView(row)
        parent.addView(View(activity).apply{setBackgroundColor(if(ThemeManager.isDark(activity))Color.rgb(48,60,73)else Color.rgb(225,229,232))},LinearLayout.LayoutParams(-1,dp(1)))
    }
    private fun miniBar(parent:LinearLayout,labelText:String,value:Int){
        parent.addView(TextView(activity).apply{text="$labelText  ${value.coerceIn(0,100)}%";textSize=10.5f;setTextColor(ThemeManager.text(activity));setPadding(dp(8),dp(5),dp(8),dp(2))})
        parent.addView(ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal).apply{
            max=100;progress=value.coerceIn(0,100);progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(activity));backgroundTintList=android.content.res.ColorStateList.valueOf(if(ThemeManager.isDark(activity))Color.rgb(42,52,64)else Color.rgb(231,235,238))
        },LinearLayout.LayoutParams(-1,dp(7)).apply{setMargins(dp(8),0,dp(8),dp(4))})
    }
    private fun sectionBanner(root:LinearLayout, titleText:String, subtitle:String){
        root.addView(TextView(activity).apply{text=titleText.uppercase();textSize=11f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity));setPadding(dp(2),dp(7),dp(2),dp(6))})
    }

    private fun addAdaptiveEngine(root:LinearLayout){
        val state=AppManagers.adaptive.state();val telemetry=BenNeuralTelemetry.snapshot()
        sectionBanner(root,"Engine overview","One screen for Ben cognition, neural acceleration, runtime policy and adaptive orchestration.")
        visualCard(root,"Engine health","Current state from the authoritative AdaptiveEngineManager"){
            miniBar(this,"System health",state.health)
            miniBar(this,"Learning",state.learningScore)
            miniBar(this,"Confidence",state.confidence)
            tableRow(this,"Autonomy",if(AppManagers.adaptive.isAutonomyEnabled())"Enabled" else "Paused",true)
            tableRow(this,"Safety",if(state.safeMode)"Protective mode" else "Normal")
        }
        addAttentionParameters(root,listOf(
            "System health" to (state.health to "Open Performance Lab to inspect thermal, RAM and resilience signals."),
            "Learning" to (state.learningScore to "Open Adaptive Study to inspect observations, exploration and strategy."),
            "Confidence" to (state.confidence to "Low confidence increases conservative exploration and verification."),
            "Resilience" to (PerformanceManager.healthScore() to "Review Performance Lab if runtime health is falling.")
        ))
        visualCard(root,"Engine topology","Deterministic core → retrieval → specialists → verifier → optional neural accelerators"){
            val flow=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            listOf("Core","RAG","Specialists","Verifier","Neural").forEachIndexed{index,name->
                val box=TextView(activity).apply{text=name;textSize=9.5f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(activity));background=rounded(if(index==4)ThemeManager.explanationBg(activity)else ThemeManager.panel(activity),10);setPadding(dp(4),dp(10),dp(4),dp(10))}
                flow.addView(box,LinearLayout.LayoutParams(0,dp(42),1f).apply{if(index>0)setMargins(dp(2),0,0,0)})
            }
            addView(flow)
            tableRow(this,"Model",telemetry.activeModel.ifBlank{"Deterministic Ben"})
            tableRow(this,"Last stage",telemetry.stage.name.replace('_',' '))
            tableRow(this,"Evidence",telemetry.lastEvidenceCount.toString())
            tableRow(this,"Last latency","${telemetry.lastElapsedMs} ms")
        }
        visualCard(root,"Ben edge efficiency","Measured/controlled optimizations—not speculative runtime switches"){
            val eff=BenInferenceEfficiencyPolicy.snapshot()
            tableRow(this,"Prompt window","${eff.promptWindowChars} chars")
            tableRow(this,"KV cache","LiteRT-LM owned")
            tableRow(this,"Speculative/MTP",if(eff.speculativeDecoding)"Enabled" else "Capability-gated")
            tableRow(this,"Zero-copy tensor IPC",if(eff.zeroCopyTensorIpc)"Enabled" else "Off")
            tableRow(this,"IPC","Single-flight + latest-request-wins")
            tableRow(this,"Thermal policy",AppManagers.resilienceHealth.snapshot().thermalStatus.toString())
        }
        visualCard(root,"Local QBank AI index","Persistent bounded retrieval substrate. Query-time recall stays on QBank FTS; this index only adds local concept/edge reranking."){
            val index=BenLocalKnowledgeIndex(activity)
            val stats=index.stats()
            val build=BenKnowledgeBuildCoordinator.status(activity)
            tableRow(this,"Indexed concepts",stats.concepts.toString())
            tableRow(this,"Graph edges",stats.edges.toString())
            tableRow(this,"Observations",stats.observations.toString())
            tableRow(this,"Build status","${build.state} • ${build.progress}%")
            tableRow(this,"Processed",build.processed.toString())
            val semantic=BenSemanticIndexWorker.status(activity)
            tableRow(this,"Semantic vector cache", "${semantic.state} • ${semantic.progress}%")
            tableRow(this,"Semantic vectors prepared", semantic.processed.toString())
            tableRow(this,"Semantic build policy", "Charging + device idle")
            addView(button("BUILD / CONTINUE INDEX"){
                BenKnowledgeBuildCoordinator.start(activity,false)
                BenSemanticIndexWorker.enqueue(activity,false)
                Toast.makeText(activity,"Ben local + semantic index queued",Toast.LENGTH_SHORT).show()
                activity.recreate()
            },LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(6),dp(8),dp(2))})
            addView(button("REBUILD FROM ALL QBANKS"){
                BenKnowledgeBuildCoordinator.start(activity,true)
                BenSemanticIndexWorker.enqueue(activity,true)
                Toast.makeText(activity,"Ben local + semantic rebuild queued",Toast.LENGTH_SHORT).show()
                activity.recreate()
            },LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(4),dp(8),dp(2))})
        }
        visualCard(root,"Ben brain","Cognitive switches, specialist routing, knowledge and verification"){
            val bc=BenCognitiveControl(activity)
            listOf("Cognitive Core" to bc.cognitiveCoreEnabled,"Medical Knowledge Graph" to bc.knowledgeGraphEnabled,"Planner / Reasoner" to bc.plannerEnabled,"Local RAG / QBank Retrieval" to bc.retrievalEnabled,"Specialist Routing" to bc.specialistRoutingEnabled,"Learner Memory" to bc.learnerMemoryEnabled,"Answer Verifier" to bc.verifierEnabled).forEach{(name,enabled)->tableRow(this,name,if(enabled)"ON" else "OFF",enabled)}
            val fr=AppManagers.benBrain.frankenstein().stats();tableRow(this,"Routed requests","${fr.observations}");tableRow(this,"Verification rate","${fr.verificationRate}%",true);tableRow(this,"Specialist routes",BenSpecialistRegistry.entries().size.toString())
        }
        visualCard(root,"Cloud AI & Gemini","Optional network AI. OFF by default; local Ben/RAG remains authoritative. User-entered provider keys are encrypted with Android Keystore and are never bundled in the APK."){
            val gateway=AppManagers.cloudAi
            val cloudAllowed=Switch(activity).apply{
                text="Allow cloud AI fallback"; textSize=12f; setTextColor(ThemeManager.text(activity));
                isChecked=gateway.isCloudFallbackAllowed();
                setOnCheckedChangeListener{_,checked->gateway.setCloudFallbackAllowed(checked)}
            }
            addView(cloudAllowed,LinearLayout.LayoutParams(-1,dp(42)))
            val cfgs=gateway.configs()
            if(cfgs.none{it.hasKey}) tableRow(this,"Status","No external provider connected")
            cfgs.forEach { cfg ->
                tableRow(this,cfg.provider.label,if(cfg.hasKey && cfg.enabled) "Connected • ${cfg.model}" else if(cfg.hasKey) "Key saved • OFF" else "Not connected",cfg.hasKey && cfg.enabled)
            }
            addView(button("Manage Cloud AI Providers"){showCloudAiProvidersDialog() },LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(6),dp(8),dp(2))})
        }
        visualCard(root,"Exam profile","Used by Ben, retrieval, neural prompts and cloud AI context"){
            val profile=currentBenExamProfile(activity)
            tableRow(this,"Current profile",profile.label,true)
            addView(button("Change Exam Profile"){showExamProfileDialog()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(6),dp(8),dp(2))})
        }
        visualCard(root,"Neural lab","EmbeddingGemma retrieval + Gemma 3 270M generation; both remain governor-controlled"){
            val policy=BenAiRuntimePolicy(activity);val em=neuralModelManager.installed(BenNeuralModelRegistry.embeddingGemma300m);val tok=neuralModelManager.installedEmbeddingGemmaTokenizer();val gm=neuralModelManager.installed(BenNeuralModelRegistry.gemma3_270m)
            tableRow(this,"Policy",if(policy.circuitOpen)"Circuit open" else if(policy.enabled)"Armed / governor" else "Off",true)
            tableRow(this,"EmbeddingGemma",if(em!=null)"Installed • ${em.bytes/(1024*1024)} MB" else "Missing")
            tableRow(this,"Tokenizer",if(tok!=null)"Installed" else "Missing")
            tableRow(this,"Gemma 3 270M",if(gm!=null)"Installed" else "Missing")
            tableRow(this,"Pipeline","QBank/FTS → EmbeddingGemma → RRF/contrastive → Gemma → deterministic verifier",true)
            tableRow(this,"Integration","Grounded pipeline wired into FrankensteinSupportEngine",true)
        }
        visualCard(root,"Runtime policy","Adaptive cache, prefetch and safe execution policy"){
            tableRow(this,"Prefetch depth",state.preferredPrefetch.toString());tableRow(this,"Cache TTL","${PerformanceManager.adaptiveCacheTtlMs()/1000}s");tableRow(this,"Last action",state.lastAction);tableRow(this,"Outcome",state.lastOutcome);tableRow(this,"Rollback count",state.rollbackCount.toString())
        }
        visualCard(root,"Orchestration activity","Recent decisions and multi-engine control plane"){
            tableRow(this,"Observations",state.observations.toString());tableRow(this,"Answers","${state.answers} • correct ${state.correct} • wrong ${state.wrong}");tableRow(this,"Recent action count",state.recentActions.size.toString());tableRow(this,"Safety boundary","Adaptive policy only",true)
            addView(button("Open Ben Safety"){openSection("ben_safety")},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(6),dp(8),dp(2))})
        }
        root.addView(button("Reset Adaptive Learning History"){viewModel.resetAdaptiveLearning();Toast.makeText(activity,"Adaptive history reset",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(3),0,dp(18))})
    }

    /** Shared Material-style settings sheet used for secondary settings flows. */
    private fun showSettingsSheet(title: String, subtitle: String, fill: (LinearLayout, BottomSheetDialog) -> Unit) {
        val dialog = BottomSheetDialog(activity)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(10))
            background = rounded(ThemeManager.dialogBg(activity), 28)
        }
        root.addView(View(activity).apply {
            background = rounded(ThemeManager.muted(activity), 4)
            alpha = .55f
        }, LinearLayout.LayoutParams(dp(38), dp(4)).apply { gravity = Gravity.CENTER; bottomMargin = dp(12) })
        val header = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val copy = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(TextView(activity).apply {
            text = title; textSize = 21f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(activity))
        })
        copy.addView(TextView(activity).apply {
            text = subtitle; textSize = 11.5f; setTextColor(ThemeManager.muted(activity)); setPadding(0, dp(3), 0, 0)
        })
        header.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(activity).apply {
            text = "×"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(ThemeManager.text(activity))
            background = rounded(ThemeManager.elevated(activity), 15)
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { leftMargin = dp(8) })
        root.addView(header)

        val scroll = ScrollView(activity).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setPadding(0, dp(10), 0, dp(6))
        }
        val content = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fill(content, dialog)

        root.addView(TextView(activity).apply {
            text = "DONE"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(ThemeManager.accent(activity)); background = rounded(ThemeManager.elevated(activity), 14)
            setPadding(0, dp(10), 0, dp(10)); setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(4) })

        dialog.setContentView(root)
        dialog.setOnShowListener {
            dialog.behavior.skipCollapsed = true
            dialog.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
            dialog.behavior.isDraggable = true
            dialog.window?.setDimAmount(.48f)
            dialog.window?.setLayout(-1, (activity.resources.displayMetrics.heightPixels * .90f).toInt())
        }
        dialog.show()
        dialog.window?.setLayout(-1, (activity.resources.displayMetrics.heightPixels * .90f).toInt())
    }

    private fun settingsOptionCard(title: String, subtitle: String, checked: Boolean, enabled: Boolean, onChanged: (Boolean) -> Unit): LinearLayout {
        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(10), dp(11))
            background = rounded(ThemeManager.elevated(activity), 16)
        }
        val copy = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(TextView(activity).apply { text = title; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(activity)) })
        copy.addView(TextView(activity).apply { text = subtitle; textSize = 10.5f; setTextColor(ThemeManager.muted(activity)); setPadding(0, dp(2), 0, 0) })
        card.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(Switch(activity).apply {
            isChecked = checked; isEnabled = enabled; setOnCheckedChangeListener { _, value -> onChanged(value) }
        }, LinearLayout.LayoutParams(dp(56), dp(44)))
        return card
    }

    private fun showStudyNotificationSettings(){
        showSettingsSheet(
            "Study & Notifications",
            "Control reminders without changing your study data."
        ) { body, _ ->
            val enabled = AppManagers.streak.notificationsEnabled()
            body.addView(TextView(activity).apply {
                text = "Rovex can send a motivation quote, daily-target reminder and streak reminder. Delivery may be delayed by Android battery/Doze policy."
                textSize = 11.5f; setTextColor(ThemeManager.muted(activity)); setPadding(dp(2), 0, dp(2), dp(10))
            })
            val masterCard = settingsOptionCard("Study notifications", "Allow Rovex to schedule study reminders.", enabled, true) { checked ->
                AppManagers.streak.setNotificationsEnabled(checked)
                if (checked) maybeRequestStudyNotificationPermission(activity)
            }
            body.addView(masterCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            body.addView(TextView(activity).apply { text = "REMINDER TYPES"; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(activity)); setPadding(dp(2), dp(10), 0, dp(5)) })
            body.addView(settingsOptionCard("Daily motivational quote", "A short study-focused reminder.", AppManagers.streak.dailyQuoteEnabled(), enabled) { AppManagers.streak.setDailyQuoteEnabled(it) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            body.addView(settingsOptionCard("Daily target reminder", "Remind you about the saved daily question target.", AppManagers.streak.dailyTargetEnabled(), enabled) { AppManagers.streak.setDailyTargetEnabled(it) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })

            fun timeCard(label: String, hour: Int, minute: Int, onSet: (Int, Int) -> Unit): View = TextView(activity).apply {
                text = "$label\n${String.format("%02d:%02d", hour, minute)}"
                textSize = 12f; setTextColor(ThemeManager.text(activity)); background = rounded(ThemeManager.elevated(activity), 15)
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)); isEnabled = enabled
                setOnClickListener {
                    android.app.TimePickerDialog(activity, { _, h, m -> onSet(h, m); text = "$label\n${String.format("%02d:%02d", h, m)}" }, hour, minute, true).show()
                }
            }
            val times = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
            times.addView(timeCard("Motivation time", AppManagers.streak.dailyQuoteHour(), AppManagers.streak.dailyQuoteMinute()) { h, m -> AppManagers.streak.setDailyQuoteTime(h, m) }, LinearLayout.LayoutParams(0, dp(56), 1f).apply { rightMargin = dp(5) })
            times.addView(timeCard("Target reminder", AppManagers.streak.dailyTargetHour(), AppManagers.streak.dailyTargetMinute()) { h, m -> AppManagers.streak.setDailyTargetTime(h, m) }, LinearLayout.LayoutParams(0, dp(56), 1f).apply { leftMargin = dp(5) })
            body.addView(TextView(activity).apply { text = "SCHEDULE"; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(activity)); setPadding(dp(2), dp(7), 0, dp(5)) })
            body.addView(times)
            body.addView(TextView(activity).apply { text = "Default times: 08:00 motivation • 20:00 target. Android 13+ may request notification permission when enabled."; textSize = 10.5f; setTextColor(ThemeManager.muted(activity)); setPadding(dp(2), dp(9), dp(2), dp(2)) })
        }
    }

    private fun showCloudAiProvidersDialog(){
        val gateway = AppManagers.cloudAi
        showSettingsSheet(
            "Cloud AI & Gemini",
            "Optional network fallback. Ben/local retrieval remains authoritative."
        ) { body, _ ->
            body.addView(settingsOptionCard("Allow cloud AI fallback", "OFF is the safe default. Enable only when you want external providers.", gateway.isCloudFallbackAllowed(), true) { gateway.setCloudFallbackAllowed(it) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            body.addView(TextView(activity).apply {
                text = "PROVIDERS"; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(activity)); setPadding(dp(2), dp(4), 0, dp(6))
            })
            BenCloudAiGateway.Provider.values().forEach { provider ->
                val cfg = gateway.configs().first { it.provider == provider }
                val card = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)); background = rounded(ThemeManager.elevated(activity), 17) }
                val top = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val copy = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
                copy.addView(TextView(activity).apply { text = provider.label; textSize = 14.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(activity)) })
                copy.addView(TextView(activity).apply { text = if (cfg.hasKey) "Connected • ${cfg.model}" else "Not connected • API key required"; textSize = 10.5f; setTextColor(if (cfg.hasKey) ThemeManager.accent(activity) else ThemeManager.muted(activity)); setPadding(0, dp(2), 0, 0) })
                top.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
                top.addView(Switch(activity).apply { text = "Use"; isChecked = cfg.enabled && cfg.hasKey; setTextColor(ThemeManager.text(activity)); setOnCheckedChangeListener { _, checked -> gateway.setEnabled(provider, checked) } }, LinearLayout.LayoutParams(dp(66), dp(42)))
                card.addView(top)
                val actions = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, 0) }
                fun action(label: String, filled: Boolean = false, click: () -> Unit) = TextView(activity).apply {
                    text = label; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(ThemeManager.text(activity)); background = rounded(if (filled) ThemeManager.explanationBg(activity) else ThemeManager.elevated(activity), 11); setOnClickListener { click() }
                }
                actions.addView(action(if (cfg.hasKey) "UPDATE KEY" else "CONNECT", true) { showProviderKeyDialog(provider) }, LinearLayout.LayoutParams(0, dp(38), 1f))
                actions.addView(action("OFFICIAL KEY PAGE") { runCatching { gateway.openKeyPage(activity, provider) }.onFailure { Toast.makeText(activity, "Could not open ${provider.label} key page", Toast.LENGTH_SHORT).show() } }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(6) })
                actions.addView(action("TEST") {
                    lifecycleScope.launch {
                        val result = resultOf { gateway.test(provider) }
                        if (result.isSuccess) Toast.makeText(activity, "${provider.label}: connection OK", Toast.LENGTH_SHORT).show()
                        else {
                            val message = result.exceptionOrNull()?.message ?: "connection test failed"
                            ProductionCrashReporter.recordNonFatal(result.exceptionOrNull() ?: IllegalStateException(message), "CLOUD_PROVIDER_TEST", mapOf("provider" to provider.id))
                            RovexUndoSnackbar.show(body, "${provider.label}: $message", "RETRY") { lifecycleScope.launch { resultOf { gateway.test(provider) } } }
                        }
                    }
                }, LinearLayout.LayoutParams(dp(64), dp(38)).apply { leftMargin = dp(6) })
                card.addView(actions)
                body.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
            body.addView(TextView(activity).apply {
                text = "Fallback order: Groq → OpenRouter → DeepSeek → Google Gemini. Keys are stored locally through the existing protected key store and are not shown in diagnostics."
                textSize = 10.5f; setTextColor(ThemeManager.muted(activity)); setPadding(dp(2), dp(7), dp(2), dp(2))
            })
        }
    }

    private fun showProviderKeyDialog(provider:BenCloudAiGateway.Provider){
        val gateway=AppManagers.cloudAi
        val layout=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(4),dp(20),0)}
        layout.addView(TextView(activity).apply{text="${provider.label} API key";textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity));setPadding(0,0,0,dp(5))})
        layout.addView(TextView(activity).apply{text="Use the official provider page to obtain your key. Rovex stores it encrypted locally.";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,0,0,dp(8))})
        layout.addView(TextView(activity).apply{text="OPEN OFFICIAL KEY PAGE  →";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));background=rounded(ThemeManager.explanationBg(activity),11);setPadding(dp(8),0,dp(8),0);setOnClickListener{runCatching{gateway.openKeyPage(activity,provider)}.onFailure{Toast.makeText(activity,"Could not open key page",Toast.LENGTH_SHORT).show()}}},LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(0,0,0,dp(7))})
        val key=EditText(activity).apply{hint="Paste API key";inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD;setSingleLine(true)}
        layout.addView(key,LinearLayout.LayoutParams(-1,dp(52)))
        val model=EditText(activity).apply{hint="Model (default: ${provider.defaultModel})";setSingleLine(true);setText(gateway.configs().first{it.provider==provider}.model)}
        layout.addView(model,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(5),0,0)})
        val dialog=AlertDialog.Builder(activity).setTitle("Connect ${provider.label}").setView(layout).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create()
        dialog.setOnShowListener{
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ThemeManager.text(activity))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(ThemeManager.accent(activity))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val value=key.text.toString().trim()
                if(value.isBlank()){key.error="API key required";return@setOnClickListener}
                resultOf {
                    gateway.saveKey(provider,value);gateway.setModel(provider,model.text.toString());gateway.setEnabled(provider,true)
                }.onSuccess{
                    Toast.makeText(activity,"${provider.label} connected and enabled",Toast.LENGTH_SHORT).show();dialog.dismiss();activity.recreate()
                }.onFailure{e->
                    ProductionCrashReporter.recordNonFatal(e,"CLOUD_PROVIDER_KEY_SAVE",mapOf("provider" to provider.id))
                    key.error=e.message ?: "Could not securely save this API key"
                }
            }
        }
        dialog.show()
    }

    private fun addAdaptiveStudy(root:LinearLayout){
        val state=AppManagers.adaptive.state()
        sectionBanner(root,"Learning dashboard","Study behaviour is separated from engine implementation and device policy.")
        visualCard(root,"Learning snapshot","Three signals that summarize the current adaptive learner model"){
            miniBar(this,"Learning",state.learningScore);miniBar(this,"Confidence",state.confidence);miniBar(this,"Uncertainty",state.uncertainty)
            tableRow(this,"Exploration","${state.exploration}%");tableRow(this,"User model",state.userModel);tableRow(this,"System model",state.systemModel)
        }
        visualCard(root,"Learning signals","Confidence, uncertainty and exploration presented as a decision table"){
            tableRow(this,"Confidence","${state.confidence}%",true);tableRow(this,"Uncertainty","${state.uncertainty}%");tableRow(this,"Exploration","${state.exploration}%");tableRow(this,"Answers","${state.answers}");tableRow(this,"Correct","${state.correct}");tableRow(this,"Wrong","${state.wrong}")
        }
        visualCard(root,"Study strategy","Current recommendation and the next policy action"){
            tableRow(this,"Recommendation",AppManagers.adaptive.studyStrategy(),true);val proposal=AppManagers.adaptive.currentProposal();tableRow(this,"Next action",proposal.action.key);tableRow(this,"Reason",proposal.reason);tableRow(this,"Explainability",AdaptiveExplainability.explain(state))
        }
        visualCard(root,"Contextual SRS shadow","Experimental recommendation only; authoritative scheduler is unchanged"){
            tableRow(this,"Mode","Advisory / shadow",true);tableRow(this,"Minimum observations","30");tableRow(this,"Scheduler mutation","None");tableRow(this,"Current policy","Contextual recommendation only")
        }
        visualCard(root,"Learning history","Recent observations and adaptive changes"){
            tableRow(this,"Observations",state.observations.toString());tableRow(this,"Autonomous changes",state.autonomousChanges.toString());tableRow(this,"Last action",state.lastAction);tableRow(this,"Last outcome",state.lastOutcome);tableRow(this,"Rollbacks",state.rollbackCount.toString())
            addView(button("Reset Adaptive Learning History"){viewModel.resetAdaptiveLearning();Toast.makeText(activity,"Adaptive history reset",Toast.LENGTH_SHORT).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(6),dp(8),dp(2))})
        }
    }

    private fun addCircularMetricRow(parent: LinearLayout, metrics: List<Triple<String, Int, String>>) {
        val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        metrics.forEachIndexed { index, metric ->
            val view = CircularMetricView(activity).apply {
                setMetric(metric.second, metric.first, metric.third)
                contentDescription = "${metric.first}: ${metric.second} percent. ${metric.third}"
                setOnClickListener { showPerformanceMetric(metric.first, metric.second, metric.third) }
            }
            row.addView(view, LinearLayout.LayoutParams(0, dp(132), 1f).apply {
                if (index > 0) setMargins(dp(3), 0, 0, 0)
            })
        }
        parent.addView(row, LinearLayout.LayoutParams(-1, dp(140)).apply { setMargins(0, dp(4), 0, dp(5)) })
    }

    private fun showPerformanceMetric(title: String, value: Int, detail: String) {
        val state = when {
            value >= 90 -> "Healthy"
            value >= 75 -> "Watch"
            else -> "Needs attention"
        }
        AlertDialog.Builder(activity)
            .setTitle("$title • $value%")
            .setMessage("$state\n\n$detail\n\nTap outside or press Back to return to the Performance Lab.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun addAttentionParameters(root: LinearLayout, parameters: List<Pair<String, Pair<Int, String>>>) {
        val weak = parameters.filter { it.second.first < 90 }.sortedBy { it.second.first }
        if (weak.isEmpty()) {
            visualCard(root, "Parameter health", "All tracked parameters are currently at or above 90%") {
                addView(TextView(activity).apply { text="✓  ALL PARAMETERS STABLE"; textSize=12f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(ThemeManager.text(activity)); setPadding(dp(8),dp(12),dp(8),dp(12)) })
            }
            return
        }
        visualCard(root, "Parameters < 90%", "Ben turns weak signals into a prioritized action queue. Lower scores rise to the top.") {
            weak.forEach { (name, data) ->
                val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(3),dp(4),dp(3),dp(4));isClickable=true;setOnClickListener{showParameterAction(name,data.first,data.second)}}
                val ring=CircularMetricView(activity).apply{setMetric(data.first,name.take(9),data.second);contentDescription="$name ${data.first} percent. Tap for recommended action"}
                row.addView(ring,LinearLayout.LayoutParams(dp(82),dp(82)))
                val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),0,dp(5),0)}
                copy.addView(TextView(activity).apply{text=if(data.first<60)"URGENT • $name" else if(data.first<75)"FOCUS • $name" else "WATCH • $name";textSize=12.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
                copy.addView(TextView(activity).apply{text=data.second;textSize=10.8f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(3),0,0);setLineSpacing(0f,1.08f)})
                copy.addView(TextView(activity).apply{text="TAP FOR ACTION  ›";textSize=9.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(5),0,0)})
                row.addView(copy,LinearLayout.LayoutParams(0,-2,1f));addView(row)
            }
        }
    }

    private fun showParameterAction(name:String,value:Int,detail:String){
        val action=when{name.contains("RAM",true)->"Reduce neural/prefetch pressure and keep foreground study protected.";name.contains("Confidence",true)->"Ask Ben for a targeted weak-concept explanation and complete a short focused question set.";name.contains("Learning",true)->"Use the current adaptive recommendation and reinforce the weakest concepts before broad exploration.";name.contains("Resilience",true)->"Keep protective recovery enabled and avoid stressing neural inference while the score is low.";else->"Open the relevant study tool and use a focused intervention before returning to normal load."}
        AlertDialog.Builder(activity).setTitle("$name • $value%")
            .setMessage("WHY IT IS BELOW 90%\n$detail\n\nBEN ACTION\n$action\n\nThe intervention is advisory unless an existing governor explicitly permits an automatic safety change.")
            .setPositiveButton("OPEN BEN"){_,_->activity.startActivity(Intent(activity,RenActivity::class.java).putExtra("prompt","Improve $name: $detail"))}
            .setNegativeButton("CLOSE",null).show()
    }

    private fun addPerformance(root:LinearLayout){
        // Performance is a diagnostic surface, not part of the foreground interaction path.
        // The authoritative progress index and device telemetry can touch SQLite/system state,
        // so prepare the immutable view model off the UI thread and render only the result here.
        val loading = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(16))
            background = ThemeManager.transparentSectionDrawable(activity)
            addView(TextView(activity).apply {
                text = "Preparing Performance Lab…"
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(ThemeManager.text(activity))
            })
            addView(mutedText("Reading local study telemetry without blocking the foreground.", 11f),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
            addView(ProgressBar(activity).apply { isIndeterminate = true },
                LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(12) })
        }
        root.addView(loading, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) {
                runCatching {
                    val studyRefs = PerformanceManager.lightRefs(activity.applicationContext)
                    val studyProgress = PerformanceManager.progress(activity.applicationContext)
                    val savedAnswers = studyRefs.count { studyProgress.record(it.stableKey)?.status != null }
                    val correctAnswers = studyRefs.count { studyProgress.record(it.stableKey)?.status == "correct" }
                    val wrongAnswers = studyRefs.count { studyProgress.record(it.stableKey)?.status == "wrong" }
                    val indexedMatches = studyRefs.count { studyProgress.record(it.stableKey) != null }
                    val studyAccuracy = if (savedAnswers == 0) 0 else correctAnswers * 100 / savedAnswers
                    val snap = BenAiResourceGovernor(activity).snapshot(true)
                    val bs = AppManagers.battery.snapshot()
                    val bp = AppManagers.battery.policy(RovexBatteryManager.WorkClass.INTERACTIVE)
                    val rh = AppManagers.resilienceHealth.snapshot()
                    val telemetry = BenNeuralTelemetry.snapshot()
                    PerformancePageData(
                        savedAnswers, correctAnswers, wrongAnswers, indexedMatches, studyRefs.size, studyAccuracy,
                        snap, bs, bp, rh, telemetry,
                        AppManagers.adaptive.state()
                    )
                }
            }.getOrNull()

            if (!activity.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED) || data == null) return@launch
            root.removeView(loading)
            renderPerformance(root, data)
        }
    }

    private data class PerformancePageData(
        val savedAnswers:Int,
        val correctAnswers:Int,
        val wrongAnswers:Int,
        val indexedMatches:Int,
        val indexedTotal:Int,
        val studyAccuracy:Int,
        val resource:BenAiResourceGovernor.Snapshot,
        val battery:RovexBatteryManager.Snapshot,
        val batteryPolicy:RovexBatteryManager.Policy,
        val resilience:EngineHealthManager.Snapshot,
        val telemetry:BenNeuralTelemetry.Snapshot,
        val adaptive:AdaptiveEngineManager.State
    )

    private fun renderPerformance(root:LinearLayout, data:PerformancePageData){
        visualCard(root,"Study data integrity","Authoritative QBank progress visible to Performance Lab"){
            tableRow(this,"Saved answers","${data.savedAnswers} • ${data.correctAnswers} correct • ${data.wrongAnswers} wrong")
            tableRow(this,"Accuracy","${data.studyAccuracy}%")
            tableRow(this,"Indexed progress","${data.indexedMatches} / ${data.indexedTotal} QBank records matched")
            addView(button("REFRESH STUDY DATA"){ PerformanceManager.invalidateProgress(); Toast.makeText(activity,"Study data cache refreshed",Toast.LENGTH_SHORT).show() },LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(dp(8),dp(7),dp(8),dp(2))})
        }
        val ramScore=(data.resource.availableMemoryMb.toFloat()/2048f*100f).toInt().coerceIn(0,100)
        sectionBanner(root,"Performance Lab","Live device health, resilience and Ben runtime signals — tap a circle for the simple explanation.")
        visualCard(root,"Live health","Progressive rings + a live signal trace. Tap a ring for the simple explanation."){
            val panelColor=viewModel.flowGreetingColor()
            if(panelColor!=0) this.background=rounded(panelColor,16)
            addView(button("CONTINUE STUDY  →"){continueStudyFromPerformance()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(4),0,dp(4),dp(8))})
            addCircularMetricRow(this,listOf(
                Triple("RAM",ramScore,"${data.resource.availableMemoryMb} MB available headroom"),
                Triple("Resilience",data.resilience.overall,"${data.resilience.crashCount} process interruptions"),
                Triple("Health",data.adaptive.health,"Adaptive/system health score")
            ))
            addView(PerformancePulseView(activity), LinearLayout.LayoutParams(-1, dp(108)).apply { setMargins(dp(4), dp(2), dp(4), dp(8)) })
            addView(TextView(activity).apply { text="THERMAL ${data.resource.thermalStatus}  •  ${if(data.resource.powerSave) "POWER SAVE" else "NORMAL POWER"}  •  ${if(data.resource.foreground) "FOREGROUND" else "BACKGROUND"}"; textSize=10.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(ThemeManager.muted(activity)); setPadding(dp(6),dp(4),dp(6),dp(4)) })
        }
        addAttentionParameters(root,listOf(
            "System health" to (data.adaptive.health to "Protective mode or runtime pressure may be affecting the study path."),
            "Learning" to (data.adaptive.learningScore to "Adaptive learner needs more observations or stronger outcomes."),
            "Confidence" to (data.adaptive.confidence to "Ben is intentionally more conservative when confidence is low."),
            "Resilience" to (data.resilience.overall to "Review process interruptions and recovery telemetry."),
            "RAM headroom" to (ramScore to "Low headroom can block neural work to protect foreground study.")
        ))
        visualCard(root,"Battery policy","Foreground study is protected; bulk work is governor-controlled"){
            tableRow(this,"Battery","${data.battery.level.name} • ${AppManagers.battery.statusLine()}",true)
            tableRow(this,"Prefetch depth",data.batteryPolicy.prefetchDepth.toString())
            tableRow(this,"Image concurrency",data.batteryPolicy.imageConcurrency.toString())
            tableRow(this,"Import batch",data.batteryPolicy.importBatchSize.toString())
        }
        visualCard(root,"Runtime telemetry","One glance first; details stay available on demand."){
            val quick=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
            listOf("${data.telemetry.lastElapsedMs} ms" to "LAST","${data.telemetry.lastSemanticMs} ms" to "SEMANTIC","${data.telemetry.totalRequests}" to "REQUESTS").forEachIndexed{i,pair->
                quick.addView(TextView(activity).apply{text="${pair.first}\n${pair.second}";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(activity));background=rounded(ThemeManager.elevated(activity),16);setPadding(dp(7),dp(8),dp(7),dp(8))},LinearLayout.LayoutParams(0,dp(54),1f).apply{if(i>0)setMargins(dp(5),0,0,0)})
            }
            addView(quick)
            addView(button("DETAILS / FALLBACKS"){showPerformanceMetric("Runtime telemetry",data.telemetry.lastElapsedMs.coerceIn(0L,100L).toInt(),"Stage: ${data.telemetry.stage.name.replace('_',' ')}\nModel: ${data.telemetry.activeModel.ifBlank{"None"}}\nSemantic: ${data.telemetry.lastSemanticMs} ms\nGeneration: ${data.telemetry.lastGenerationMs} ms")},LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(dp(8),dp(7),dp(8),dp(2))})
        }
    }

    private fun continueStudyFromPerformance(){
        resultOf {
            val session=AppManagers.sessionStore.current()
            if(session!=null && session.testId.isNotBlank() && !session.id.contains("collection",true)){
                activity.startActivity(Intent(activity,QuizActivity::class.java).apply{
                    putExtra("testId",session.testId);putExtra("position",session.position);putExtra("sessionLabel",session.id)
                })
                return
            }
            Toast.makeText(activity,"No active question session to continue",Toast.LENGTH_SHORT).show()
        }.onFailure{e->ProductionCrashReporter.recordNonFatal(e,"PERFORMANCE_CONTINUE_SESSION");RovexUndoSnackbar.show(activity.window.decorView,"Could not continue the study session","RETRY"){continueStudyFromPerformance()}}
    }

    private fun addBenSafetyPage(root:LinearLayout){
        val policy=BenAiRuntimePolicy(activity);sectionBanner(root,"Ben safety","Independent from Adaptive Engine cognition. These controls govern whether neural resources may run.")
        visualCard(root,"Safety status","Current model permission and circuit breaker"){
            tableRow(this,"Neural model access",if(policy.enabled)"Allowed" else "STOPPED",policy.enabled);tableRow(this,"Conservative guard",if(policy.conservativeMode)"ON" else "OFF");tableRow(this,"Circuit breaker",if(policy.circuitOpen)"OPEN" else "Closed",!policy.circuitOpen);tableRow(this,"Consecutive failures","${policy.consecutiveFailures}/${BenAiRuntimePolicy.MAX_CONSECUTIVE_FAILURES}")
            miniBar(this,"Safety margin",if(policy.circuitOpen)0 else 100)
        }
        visualCard(root,"Allowed / forbidden operations","Ben can tune safe runtime policy but cannot rewrite study truth"){
            tableRow(this,"May modify","Neural runtime policy");tableRow(this,"May modify","Cache/prefetch policy");tableRow(this,"May NOT modify","Question content / answers",true);tableRow(this,"May NOT modify","Progress records / backups",true);tableRow(this,"May NOT modify","Executable code / schema",true);tableRow(this,"Verifier authority","Deterministic verifier",true)
        }
        visualCard(root,"Emergency controls","Use only when you want neural execution stopped immediately"){
            val sw=Switch(activity).apply{text="AI Accelerator • Allow Ben local model";isChecked=policy.enabled;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,v->policy.setEnabled(v)}};addView(sw)
            val conservative=Switch(activity).apply{text="Conservative memory guard";isChecked=policy.conservativeMode;setTextColor(ThemeManager.text(activity));setOnCheckedChangeListener{_,v->policy.setConservativeMode(v)}};addView(conservative)
            addView(button("STOP BEN MODEL / RESET CIRCUIT"){policy.forceStop();policy.resetCircuit();sw.isChecked=false;Toast.makeText(activity,"Ben neural execution stopped",Toast.LENGTH_LONG).show();activity.recreate()},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(8),dp(8),dp(8),dp(2))})
        }
    }

    private fun addPrivacyPage(root:LinearLayout){
        sectionBanner(root,"Privacy & security","This screen covers data boundaries—not Ben's neural safety controls.")
        visualCard(root,"Data boundary","What stays under Rovex's local study authority"){
            tableRow(this,"Study data","Local application storage",true);tableRow(this,"QBank content","Imported/local content");tableRow(this,"Backups","User-controlled local backup/restore");tableRow(this,"Ben memory","Local learner/experience memory");tableRow(this,"Online research","User initiated • Google account gated")
        }
        visualCard(root,"Capability boundaries","Network and imported-content capabilities are explicitly separated"){
            tableRow(this,"Online research","Google web search • explicit user action");tableRow(this,"Imported HTML network","Not granted by default");tableRow(this,"External model access","User-selected local model files");tableRow(this,"Executable modification","Forbidden",true);tableRow(this,"Question truth mutation","Forbidden",true)
        }
        visualCard(root,"Permission recap","Only active capabilities are declared in AndroidManifest.xml"){
            tableRow(this,"Internet",if(AppManagers.cloudAi.isCloudFallbackAllowed()) "Enabled by user • cloud AI / web research" else "Declared • cloud AI fallback currently OFF")
            tableRow(this,"Calendar read", "Daily Study Hub • requested only when Calendar is opened")
            tableRow(this,"Notifications",if(android.os.Build.VERSION.SDK_INT<33 || activity.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED) "Allowed / not required" else "Not granted")
            tableRow(this,"Wake lock", "Bounded user-initiated on-device Ben inference")
            tableRow(this,"Foreground service", "Durable import and on-device inference")
        }
        visualCard(root,"Safety architecture","Privacy is not the same control plane as Ben AI Safety"){
            tableRow(this,"Privacy owner","Rovex data/storage policy",true);tableRow(this,"AI safety owner","Ben AI Runtime Policy");tableRow(this,"Study truth owner","Deterministic QBank/verifier");tableRow(this,"Emergency neural stop","Available in Ben Safety")
            addView(button("Open Ben Safety"){openSection("ben_safety")},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(8),dp(6),dp(8),dp(2))})
        }
    }

    private fun addDiagnosticsPage(root:LinearLayout){
        val t=BenNeuralTelemetry.snapshot();sectionBanner(root,"Test & Diagnostics Center","One permanent window for reproducible model tests, runtime telemetry and exportable reports.")
        visualCard(root,"Neural runtime","Current diagnostic snapshot"){
            tableRow(this,"Stage",t.stage.name.replace('_',' '));tableRow(this,"Stage detail",t.stageDetail);tableRow(this,"Active model",t.activeModel.ifBlank{"None"});tableRow(this,"Model kind",t.modelKind);tableRow(this,"Last latency","${t.lastElapsedMs} ms");tableRow(this,"Evidence count",t.lastEvidenceCount.toString());tableRow(this,"Verified",if(t.lastVerified)"YES" else "—",t.lastVerified);tableRow(this,"Citation",if(t.lastCitationValid)"VALID" else "—",t.lastCitationValid)
        }
        visualCard(root,"Startup integrity gate","Runs once during the splash animation; no network or cold neural inference"){
            val startup=StartupHealthStore(activity).snapshot()
            tableRow(this,"Last result",if(startup.healthy)"PASS" else "REVIEW",startup.healthy)
            tableRow(this,"Checks failed",startup.failed.toString(),startup.failed==0)
            tableRow(this,"Health-check duration","${startup.durationMs} ms")
            tableRow(this,"Last cold launch → interactive",if(startup.launchToInteractiveMs>0) "${startup.launchToInteractiveMs} ms" else "Not recorded")
            tableRow(this,"Debug init budget","1200 ms after intentional ${RovexSplashView.DURATION_MS} ms splash")
        }
        visualCard(root,"Failure/fallback telemetry","Neural failures never stop deterministic study"){
            tableRow(this,"Total requests",t.totalRequests.toString());tableRow(this,"Neural requests",t.neuralRequests.toString());tableRow(this,"Fallback requests",t.fallbackRequests.toString());tableRow(this,"Blocked requests",t.blockedRequests.toString());tableRow(this,"Last error",t.lastError ?: "None")
        }
        root.addView(button("Open Rovex Test & Diagnostics Center"){activity.startActivity(Intent(activity,RovexDiagnosticsDataCenter::class.java))},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(2),0,dp(8))})
    }

    // Legacy monolithic Adaptive renderer intentionally removed: each domain now owns a separate
    // dashboard so Adaptive Study, Adaptive Engines, Performance, Ben Safety and Privacy cannot
    // accidentally collapse into one window again.

    private fun sectionView(title:String, subtitle:String):View = LinearLayout(activity).apply{
        orientation=LinearLayout.VERTICAL; setPadding(dp(2),dp(10),dp(2),dp(5))
        addView(TextView(activity).apply{text=title;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity))})
        addView(TextView(activity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(3),0,dp(4))})
    }
    private fun labelBlock(t:String)=TextView(activity).apply{text=t;textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(dp(12),dp(4),dp(12),dp(6))}
    private fun engineCard(title:String, subtitle:String, action:String, click:()->Unit)=LinearLayout(activity).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(10),dp(12))
        background=GradientDrawable().apply{setColor(ThemeManager.elevated(activity));cornerRadius=dp(16).toFloat();setStroke(dp(1),if(ThemeManager.isDark(activity))Color.rgb(48,61,75)else Color.rgb(220,226,230))}
        val copy=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
        copy.addView(TextView(activity).apply{text=title;textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        copy.addView(TextView(activity).apply{text=subtitle;textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(3),0,0)})
        addView(copy,LinearLayout.LayoutParams(0,-2,1f))
        addView(TextView(activity).apply{text="OPEN";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));background=rounded(ThemeManager.explanationBg(activity),11);setPadding(dp(10),0,dp(10),0);setOnClickListener{click()}},LinearLayout.LayoutParams(dp(78),dp(38)))
    }
    private fun section(root:LinearLayout,t:String){root.addView(TextView(activity).apply{text=t;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(16),0,dp(8))})}
    private fun lp()=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}
    private fun button(t:String,click:()->Unit)=TextView(activity).apply{
        text=t;textSize=13f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(14),0)
        val dark=ThemeManager.isDark(activity);val accent=ThemeManager.accent(activity)
        setTextColor(ThemeManager.text(activity))
        background=GradientDrawable().apply{
            setColor(ThemeManager.elevated(activity));cornerRadius=dp(13).toFloat()
            setStroke(dp(1),Color.argb(if(dark)95 else 65,Color.red(accent),Color.green(accent),Color.blue(accent)))
        }
        minimumHeight=dp(40);setOnClickListener{click()}
    }
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
}
