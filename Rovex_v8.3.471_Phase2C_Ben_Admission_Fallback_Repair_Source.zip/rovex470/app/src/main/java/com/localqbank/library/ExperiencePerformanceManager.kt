package com.localqbank.library

import android.content.Context
import android.os.Process
import java.util.concurrent.ExecutorService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive

import kotlinx.coroutines.CancellationException
/**
 * Foreground-experience coordinator. Heavy derived work is isolated from the main thread
 * and stale work is prevented from publishing after a newer screen state exists.
 * It deliberately does not own study/database business logic.
 */
class ExperiencePerformanceManager(context: Context) {
    private val generation = AtomicLong(0)
    private val executor: ThreadPoolExecutor = ThreadPoolExecutor(
        1, 2, 15L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>()
    ).apply {
        threadFactory = java.util.concurrent.ThreadFactory { r ->
            Thread(r, "rovex-experience").apply { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
        }
    }

    private fun adaptBudget() {
        val workers = if (AppManagers.isReady()) AppManagers.runtime.recommendedBackgroundWorkers() else 1
        executor.corePoolSize = workers.coerceIn(1, 2)
    }

    fun newGeneration(): Long = generation.incrementAndGet()
    fun currentGeneration(): Long = generation.get()

    fun submitHome(task: () -> Unit): Future<*> {
        adaptBudget()
        return executor.submit {
            Process.setThreadPriority(if (AppManagers.runtime.framePressure() >= 2) Process.THREAD_PRIORITY_BACKGROUND + 1 else Process.THREAD_PRIORITY_BACKGROUND)
            task()
        }
    }
    fun submitFrankenstein(task: () -> Unit): Future<*> {
        adaptBudget()
        return executor.submit {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            task()
        }
    }

    /** Suspend-aware lane for LiteRT/MediaPipe neural work without blocking a worker on a synchronous coroutine bridge. */
    private val coroutineScope by lazy { CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher()) }

    fun submitFrankensteinSuspend(task: suspend () -> Unit): Job {
        adaptBudget()
        return coroutineScope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            task()
        }
    }

    fun shutdown() { coroutineScope.cancel(); executor.shutdownNow() }
}

/**
 * Supporting engine for Dr. Frankenstein. It moves cognition/search off the UI thread,
 * coalesces identical commands and keeps a very small result cache.
 */
class FrankensteinSupportEngine(context: Context) {
    private val app = context.applicationContext
    private data class Cached(val insight: RenCognitiveEngine.Insight, val ids: LongArray, val at: Long)
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Cached>()
    private val inFlight = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val runningJobs = java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.Job>()
    private val ttlMs = 20_000L
    private val neuralPipeline by lazy { BenGroundedNeuralPipeline(app) }
    private val neuralPolicy by lazy { BenAiRuntimePolicy(app) }
    private val neuralModels by lazy { BenNeuralModelManager(app) }
    private val localSearch by lazy { LocalQBankSearchService(app) }

    fun respond(command: String, currentQuestion: Question? = null, onResult: (RenCognitiveEngine.Insight, LongArray) -> Unit): kotlinx.coroutines.Job {
        val key = command.trim().lowercase() + "\u0000" + (currentQuestion?.stableKey.orEmpty())
        val now = System.currentTimeMillis()
        cache[key]?.let { cached ->
            if (now - cached.at < ttlMs) {
                return AppManagers.experience.submitFrankensteinSuspend { onResult(cached.insight, cached.ids.copyOf()) }
            }
        }
        // Reserve the key before launching the coroutine. A Job can complete before launch()
        // returns, so storing the Job after launch used to race with finally/remove and could
        // leave a dead key permanently suppressing later identical requests.
        if (!inFlight.add(key)) return runningJobs[key] ?: AppManagers.experience.submitFrankensteinSuspend { }

        val job = AppManagers.experience.submitFrankensteinSuspend {
            val requestStarted = android.os.SystemClock.elapsedRealtime()
            BenNeuralTelemetry.begin("Frankenstein Ben query")
            try {
                val actionCommand = isActionCommand(command)
                val localSearchCommand = isLocalSearchCommand(command)
                val embeddingInstalled = neuralModels.installed(BenNeuralModelRegistry.embeddingGemma300m) != null
                val generatorInstalled = neuralModels.installed(BenNeuralModelRegistry.gemma3_270m) != null
                val neuralArtifactsReady = embeddingInstalled && generatorInstalled
                // The grounded production pipeline requires BOTH models: EmbeddingGemma for
                // semantic evidence retrieval and Gemma 3 270M for grounded generation. The
                // previous OR check could admit a half-installed pipeline and silently fall back.
                val admissionReason = if (!actionCommand && !localSearchCommand && neuralArtifactsReady &&
                    neuralPolicy.enabled && !neuralPolicy.circuitOpen) {
                    neuralPolicy.blockReason(
                        BenNeuralModelRegistry.gemma3_270m.estimatedModelMb,
                        BenNeuralModelRegistry.embeddingGemma300m.estimatedRuntimeMb + BenNeuralModelRegistry.gemma3_270m.estimatedRuntimeMb,
                        BenAiResourceGovernor(app).snapshot(foreground = true)
                    )
                } else null
                // Search remains deterministic, but ordinary clinical questions should enter the
                // grounded neural pipeline automatically when both installed models pass admission.
                val useNeural = !actionCommand && !localSearchCommand && neuralArtifactsReady &&
                    neuralPolicy.enabled && !neuralPolicy.circuitOpen && admissionReason == null
                if (!actionCommand && !localSearchCommand && !useNeural) {
                    val reason = when {
                        !embeddingInstalled -> "Neural Ben unavailable: EmbeddingGemma 300M is not installed"
                        !generatorInstalled -> "Neural Ben unavailable: Gemma 3 270M is not installed"
                        !neuralPolicy.enabled -> "AI accelerator is OFF"
                        neuralPolicy.circuitOpen -> "failure circuit is open after repeated backend failures"
                        admissionReason != null -> admissionReason
                        else -> "Neural Ben route was not admitted"
                    }
                    BenNeuralTelemetry.blocked(reason)
                }

                // SEARCH CONTRACT: explicit local-search/topic requests bypass every optional
                // ontology, ranking, and neural layer. The authoritative corpus is the SQLite
                // QBank, so a ranking/model failure must never become a false "no result".
                if (localSearchCommand) {
                    val requestContext = kotlinx.coroutines.currentCoroutineContext()
                    val result = localSearch.search(command, 100, shouldContinue = { requestContext.isActive })
                    val ids = result.hits.map { it.id }.distinct().take(100).toLongArray()
                    val examples = result.hits.take(6).map { "Q${it.position + 1} • ${it.testTitle}" }
                    val body = if (ids.isNotEmpty()) {
                        "Found ${ids.size} relevant local question${if (ids.size == 1) "" else "s"}.\n\n" +
                            examples.joinToString("\n") +
                            "\n\nSearch is grounded in the local QBank content."
                    } else {
                        "I could not find a matching local QBank question for that request. Try the main clinical term, disease, drug, investigation, or QBank name."
                    }
                    val insight = RenCognitiveEngine.Insight(
                        "Dr. Frankenstein local search", body,
                        if (ids.isNotEmpty()) listOf("Open matching questions") else emptyList()
                    )
                    if (ids.isNotEmpty()) cache[key] = Cached(insight, ids.copyOf(), System.currentTimeMillis())
                    trimCache()
                    BenNeuralTelemetry.completeDeterministic(ids.size, (android.os.SystemClock.elapsedRealtime() - requestStarted).coerceAtLeast(0L))
                    runCatching { onResult(insight, ids) }
                        .onFailure { android.util.Log.e("Rovex.Frankenstein", "Local-search result callback failed", it) }
                    return@submitFrankensteinSuspend
                }

                if (useNeural) {
                    val result = try {
                        neuralPipeline.run(command)
                    } catch (cancel: CancellationException) {
                        throw cancel
                    } catch (_: Exception) {
                        null
                    }
                    if (result != null && BenResponsePolicy.normalize(result.answer).orEmpty().isNotBlank()) {
                        kotlinx.coroutines.currentCoroutineContext().ensureActive()
                        val visual = runCatching { AppManagers.renCognitive.understand(command).visualIntent }.getOrDefault(false)
                        val ids = runCatching {
                            AppManagers.renCognitive.searchQuestionIds(command, if (visual) 500 else 100)
                        }.getOrDefault(longArrayOf())
                        val actions = if (ids.isNotEmpty()) listOf("Open matching questions") else emptyList()
                        val insight = RenCognitiveEngine.Insight(
                            if (result.modelUsed) "Dr. Frankenstein • grounded neural response" else "Dr. Frankenstein • deterministic fallback",
                            BenResponsePolicy.normalize(result.answer).orEmpty().trim(),
                            actions
                        )
                        cache[key] = Cached(insight, ids.copyOf(), System.currentTimeMillis())
                        trimCache()
                        runCatching { onResult(insight, ids) }
                            .onFailure { android.util.Log.e("Rovex.Frankenstein", "Result callback failed", it) }
                        return@submitFrankensteinSuspend
                    }
                }

                // Action-oriented commands stay on the deterministic command router.
                // Deterministic fallback must stay responsive even when the heavier Ren ranking
                // lane is contending with QBank/index maintenance. The local-search service is the
                // authoritative bounded retrieval contract and avoids repeating ontology + SQLite
                // ranking work merely to render the fallback response. Ren remains the final
                // recovery path if this fast lane itself fails.
                val fallback = runCatching { fastDeterministicFallback(command) }.getOrElse { t ->
                    android.util.Log.e("Rovex.Frankenstein", "Fast deterministic fallback failed", t)
                    ProductionCrashReporter.breadcrumb(
                        RovexApplicationContextHolder.context,
                        "BEN_FAST_FALLBACK_FAILED:${t.javaClass.simpleName}"
                    )
                    runCatching {
                        val recovery = AppManagers.renCognitive.answer(command, currentQuestion)
                        val recoveryIds = if (recovery.actions.contains("Open matching questions")) {
                            runCatching { AppManagers.renCognitive.searchQuestionIds(command, 100) }.getOrDefault(longArrayOf())
                        } else longArrayOf()
                        recovery to recoveryIds
                    }.getOrElse { recoveryError ->
                        android.util.Log.e("Rovex.Frankenstein", "Deterministic recovery failed", recoveryError)
                        RenCognitiveEngine.Insight(
                            "Dr. Frankenstein",
                            "The local study engine is temporarily unavailable for this request. Your QBank data is unchanged; try the request again."
                        ) to longArrayOf()
                    }
                }
                val insight = fallback.first
                val ids = fallback.second
                val deterministicElapsed = (android.os.SystemClock.elapsedRealtime() - requestStarted).coerceAtLeast(0L)
                BenNeuralTelemetry.completeDeterministic(ids.size, deterministicElapsed)
                cache[key] = Cached(insight, ids.copyOf(), System.currentTimeMillis())
                trimCache()
                runCatching { onResult(insight, ids) }
                    .onFailure { android.util.Log.e("Rovex.Frankenstein", "Result callback failed", it) }
            } finally {
                inFlight.remove(key)
                runningJobs.remove(key)
            }
        }
        runningJobs[key] = job
        return job
    }

    fun invalidate() { cache.clear() }
    fun trimNeuralResources() { runCatching { neuralPipeline.trim() } }
    fun shutdown() {
        cache.clear()
        runningJobs.values.forEach { it.cancel() }
        runningJobs.clear()
        inFlight.clear()
        runCatching { neuralPipeline.close() }
    }


    private fun fastDeterministicFallback(command: String): Pair<RenCognitiveEngine.Insight, LongArray> {
        val understanding = AppManagers.renCognitive.understand(command)
        val result = localSearch.search(
            command,
            100,
            understanding.expansions.take(8),
            visualOnly = understanding.visualIntent
        )
        val ids = result.hits.map { it.id }.distinct().take(100).toLongArray()
        val concepts = understanding.concepts.take(4).joinToString(", ") { it.canonical }
        val intent = understanding.intent?.replace('_', ' ')
        val interpretation = buildString {
            if (concepts.isNotBlank()) append("Clinical concepts: $concepts. ")
            if (!intent.isNullOrBlank()) append("Question intent: $intent. ")
            if (understanding.visualIntent) append("Visual filter: actual imported question/explanation image required. ")
            if (understanding.domains.isNotEmpty()) append("Dr. Frankenstein prioritised clinical subject/context before QBank provenance labels.")
        }.trim()
        val examples = result.hits.take(5).map { "Q${it.position + 1} • ${it.testTitle}" }
        val body = if (ids.isNotEmpty()) {
            "Found ${ids.size} relevant local question${if (ids.size == 1) "" else "s"}.\n\n" +
                interpretation + "\n\n" + examples.joinToString("\n") +
                "\n\nSearch is grounded in the actual local question/explanation content; unrelated subject or QBank labels are deliberately down-weighted."
        } else {
            "I could not find a matching local QBank result for that request. Try the main clinical term or topic name."
        }
        return RenCognitiveEngine.Insight(
            "Dr. Frankenstein clinical search",
            body,
            if (ids.isNotEmpty()) listOf("Open matching questions") else emptyList()
        ) to ids
    }

    private fun isLocalSearchCommand(command: String): Boolean {
        val q = command.trim().lowercase()
        val explicitSearch = listOf(
            "find", "search", "related question", "related questions",
            "similar question", "similar questions", "matching question",
            "matching questions", "show questions", "give me questions",
            "qbank questions", "previous question", "pyq"
        ).any { q.contains(it) }
        if (explicitSearch) return true

        // A bare medical topic is a retrieval request in Frankenstein. Previously a short noun
        // phrase such as "cervical cancer" was routed into the neural answer pipeline because it
        // lacked the words "find/search/questions". That pipeline can legitimately answer the
        // topic, but it is not the authoritative QBank retrieval path and could therefore surface
        // the generic no-result fallback even when an equivalent local term exists. Keep topic-only
        // prompts deterministic so the local corpus is searched before any optional generation.
        // Keep this decision in the shared local-search contract so Frankenstein and other
        // consumers cannot diverge on punctuation/topic routing.
        return LocalQBankSearchService.isLikelyTopicQuery(q)
    }

    private fun isActionCommand(command: String): Boolean {
        val q = command.lowercase()
        return listOf("flashcard", "flash card", "create note", "save note", "what should i study", "study plan", "wrong questions", "make a note", "start quiz", "open study tools").any { q.contains(it) }
    }

    private fun trimCache() {
        if (cache.size <= 24) return
        val oldest = cache.entries.minByOrNull { it.value.at }?.key ?: return
        cache.remove(oldest)
    }
}

