# Rovex v8.3.304 — UI6 offline repair audit

Baseline: user-supplied `Rovex_v8.3.304_Corrected_Source.zip`, inner `Rovex_v8.3.304_Final_Source.zip` project.

## Six requested corrections
1. Home Settings button: top-right gear now launches `SettingsActivity`.
2. Light-theme lower navigation: navigation capsule uses a light background in non-dark themes and theme-aware text colors.
3. Home QBank: QBank card and lower QBank navigation open `RovexSectionDashboardActivity` with `section=qbank`.
4. Home QBank Library: Browse QBanks opens the main QBank dashboard; Import QBank calls the existing HTML/text importer through a public `MainActivity.openQBankImporterFromHome()` bridge.
5. More: lower navigation More launches `StudyToolsActivity`.
6. Plan My Day / Calendar: Daily Study Hub now has `VIEW CALENDAR`, which opens the device calendar provider (including synced Google Calendar when available), while the existing planner export continues to create a calendar event through `ACTION_INSERT` without requesting calendar-account permission.

## Compile-risk repairs
- Removed the fragile generated calendar permission/read-query implementation that previously introduced `dp(ctx, ...)` Kotlin errors.
- Calendar integration uses Android's intent contracts and the existing local `dp(Context, Int)` helper.
- Added the required `android.content.Intent` import to `RovexHomeRevolution.kt`.
- Added a public importer bridge in `MainActivity` without changing importer ownership.

## Static audits
- XML parsing: PASS (0 XML parse errors found).
- Duplicate IDs: PASS (no duplicate IDs within individual layout files found).
- `READ_CALENDAR`: not added; calendar access is not required for the requested open-calendar/export flow.
- Required UI6 symbols and navigation targets: present.

## Build limitation
A local Android Gradle compilation attempt was made with `./gradlew :app:compileReleaseKotlin --offline --no-daemon`, but the project wrapper attempted to download Gradle 9.3.1 and the environment could not resolve `downloads.gradle.org`. Therefore Android compilation is **not claimed green** offline. GitHub Actions remains the authoritative Android build gate.
