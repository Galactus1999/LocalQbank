package com.localqbank.library

import android.content.Context
import android.os.Process
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicLong

/**
 * Foreground-experience coordinator. Heavy derived work is isolated from the main thread
 * and stale work is prevented from publishing after a newer screen state exists.
 * It deliberately does not own study/database business logic.
 */
class ExperiencePerformanceManager(context: Context) {
    private val generation = AtomicLong(0)
    private val executor: ExecutorService = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "rovex-experience").apply { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
    }

    fun newGeneration(): Long = generation.incrementAndGet()
    fun currentGeneration(): Long = generation.get()

    fun submitHome(task: () -> Unit): Future<*> = executor.submit {
        Process.setThreadPriority(if (AppManagers.runtime.framePressure() >= 2) Process.THREAD_PRIORITY_BACKGROUND + 1 else Process.THREAD_PRIORITY_BACKGROUND)
        task()
    }
    fun submitFrankenstein(task: () -> Unit): Future<*> = executor.submit {
        Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
        task()
    }

    fun shutdown() { executor.shutdownNow() }
}

/**
 * Supporting engine for Dr. Frankenstein. It moves cognition/search off the UI thread,
 * coalesces identical commands and keeps a very small result cache.
 */
class FrankensteinSupportEngine(context: Context) {
    private val app = context.applicationContext
    private data class Cached(val insight: RenCognitiveEngine.Insight, val ids: LongArray, val at: Long)
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Cached>()
    private val inFlight = java.util.concurrent.ConcurrentHashMap<String, Future<*>>()
    private val ttlMs = 20_000L

    fun respond(command: String, currentQuestion: Question? = null, onResult: (RenCognitiveEngine.Insight, LongArray) -> Unit) {
        val key = command.trim().lowercase() + "\u0000" + (currentQuestion?.stableKey.orEmpty())
        val now = System.currentTimeMillis()
        cache[key]?.let { cached ->
            if (now - cached.at < ttlMs) {
                AppManagers.experience.submitFrankenstein { onResult(cached.insight, cached.ids.copyOf()) }
                return
            }
        }
        if (inFlight.containsKey(key)) return
        val future = AppManagers.experience.submitFrankenstein {
            try {
                val cognitive = AppManagers.renCognitive
                val insight = runCatching { cognitive.answer(command, currentQuestion) }
                    .getOrElse { RenCognitiveEngine.Insight("Dr. Frankenstein", "I could not complete that request safely. Try a simpler command.") }
                val ids = if (insight.actions.contains("Open matching questions")) {
                    runCatching { cognitive.searchQuestionIds(command, 100) }.getOrDefault(longArrayOf())
                } else longArrayOf()
                cache[key] = Cached(insight, ids.copyOf(), System.currentTimeMillis())
                trimCache()
                onResult(insight, ids)
            } finally {
                inFlight.remove(key)
            }
        }
        inFlight[key] = future
    }

    fun invalidate() { cache.clear() }
    fun shutdown() { cache.clear(); inFlight.values.forEach { it.cancel(true) }; inFlight.clear() }

    private fun trimCache() {
        if (cache.size <= 24) return
        val oldest = cache.entries.minByOrNull { it.value.at }?.key ?: return
        cache.remove(oldest)
    }
}
