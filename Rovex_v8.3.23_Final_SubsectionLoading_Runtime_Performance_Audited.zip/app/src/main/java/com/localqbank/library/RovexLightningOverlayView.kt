package com.localqbank.library

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.sin

/** Long, sparse energy bolt that can chase from the Rovex mark toward settings/search. */
class RovexLightningOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val path = Path()
    private val redPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private var progress = 0f
    private var phase = 0
    private var animator: ValueAnimator? = null
    private var attached = false
    private val nextStrike = Runnable { if (attached) fire() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); attached = true; scheduleNext(850L)
    }

    override fun onDetachedFromWindow() {
        attached = false
        animator?.cancel(); animator = null
        removeCallbacks(nextStrike)
        super.onDetachedFromWindow()
    }

    private fun scheduleNext(delay: Long) {
        removeCallbacks(nextStrike)
        postDelayed(nextStrike, delay)
    }

    private fun fire() {
        phase = (phase + 1) % 8
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = 1050L
            interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
        scheduleNext(3900L + (phase * 180L))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0 || progress <= 0f) return
        val w = width.toFloat(); val h = height.toFloat()
        val route = phase % 4
        val startX = w * (0.23f + (phase % 3) * 0.035f)
        val startY = h * (0.34f + ((phase * 17) % 9) * 0.025f)
        val endX = when (route) {
            0 -> w * .95f       // chase the settings control
            1 -> w * .78f       // chase the search side
            2 -> w * .98f       // full-width sideways strike
            else -> w * .64f    // shorter diagonal, but still long
        }
        val endY = when (route) {
            0 -> h * .28f
            1 -> h * .82f       // reaches into search
            2 -> h * .55f
            else -> h * .06f    // shoots upward
        }

        val points = 15
        val visible = (progress * points).coerceIn(0f, points.toFloat())
        path.reset()
        for (i in 0..points) {
            if (i > visible.toInt()) break
            val u = i / points.toFloat()
            val baseX = startX + (endX - startX) * u
            val baseY = startY + (endY - startY) * u
            val jitter = if (i == 0 || i == points) 0f else {
                val envelope = sin(Math.PI * u).toFloat()
                ((phase * 13 + i * 29) % 11 - 5) * (1.8f + 2.4f * envelope)
            }
            val x = baseX + jitter
            val y = baseY + ((i % 3) - 1) * 4.5f + jitter * .35f
            if (i == 0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        val fade = (1f - progress * .12f).coerceIn(.45f,1f)
        redPaint.strokeWidth = 2.4f + 1.4f * (1f-progress)
        redPaint.color = Color.argb((190f*fade).toInt(),255,58,44)
        canvas.drawPath(path, redPaint)
        goldPaint.strokeWidth = 1.05f + .75f * (1f-progress)
        goldPaint.color = Color.argb((235f*fade).toInt(),255,221,82)
        canvas.drawPath(path, goldPaint)
    }
}
