package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.security.MessageDigest
import android.database.Cursor

class QBankDb(context: Context) {
    private val dbFile: File = context.getDatabasePath("qbank.db")
    private val db: SQLiteDatabase
    init {
        dbFile.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        db.setForeignKeyConstraintsEnabled(true)
        // Enable WAL through the Android API. Do not execute PRAGMA journal_mode=WAL
        // with execSQL because journal_mode returns a result row and can crash on startup.
        db.enableWriteAheadLogging()
        createSchema()
    }
    private fun createSchema() {
        db.execSQL("CREATE TABLE IF NOT EXISTS source(id INTEGER PRIMARY KEY AUTOINCREMENT, file_name TEXT UNIQUE NOT NULL, display_name TEXT, series_number TEXT, provider TEXT NOT NULL, imported_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS test(id TEXT PRIMARY KEY, source_id INTEGER NOT NULL, title TEXT NOT NULL, path TEXT, num_questions INTEGER, total_marks REAL, duration_seconds INTEGER, time_per_question REAL, original_id TEXT, series_number TEXT, FOREIGN KEY(source_id) REFERENCES source(id) ON DELETE CASCADE)")
        ensureColumn("source", "display_name", "TEXT")
        ensureColumn("source", "series_number", "TEXT")
        ensureColumn("test", "series_number", "TEXT")
        db.execSQL("CREATE TABLE IF NOT EXISTS question(id INTEGER PRIMARY KEY AUTOINCREMENT, test_id TEXT NOT NULL, position INTEGER NOT NULL, source_question_id TEXT, text TEXT, raw_text TEXT, correct_answer TEXT, explanation TEXT, bot TEXT, video TEXT, audio TEXT, FOREIGN KEY(test_id) REFERENCES test(id) ON DELETE CASCADE, UNIQUE(test_id,position))")
        db.execSQL("CREATE TABLE IF NOT EXISTS option_item(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, position INTEGER NOT NULL, label TEXT, text TEXT, is_correct INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_image(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, kind TEXT NOT NULL, position INTEGER NOT NULL, uri TEXT NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS progress(question_id INTEGER PRIMARY KEY, selected_answer TEXT, status TEXT, bookmark TEXT, review INTEGER DEFAULT 0, attempt_count INTEGER DEFAULT 0, last_attempted INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_source ON test(source_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_test ON question(test_id,position)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_question_source ON question(source_question_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS question_note(question_id INTEGER PRIMARY KEY, note TEXT NOT NULL, updated_at INTEGER NOT NULL, FOREIGN KEY(question_id) REFERENCES question(id) ON DELETE CASCADE)")
        // FTS4 keeps global search fast even for very large QBanks. Content is rebuilt lazily
        // from the normalized SQLite tables, so the 160 MB source HTML is never searched.
        try {
            db.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS question_fts USING fts4(question_id UNINDEXED, test_id UNINDEXED, source_id UNINDEXED, content)")
        } catch (_: Exception) { /* Some vendor SQLite builds may omit FTS; LIKE fallback remains available. */ }
    }
    private fun ensureColumn(table: String, column: String, definition: String) {
        val exists = db.rawQuery("PRAGMA table_info($table)", null).use { c ->
            var found = false
            while (c.moveToNext()) if (c.getString(1).equals(column, true)) { found = true; break }
            found
        }
        if (!exists) db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
    }

    fun ensureSearchIndex(){ rebuildSearchIndexIfNeeded() }
    private fun rebuildSearchIndexIfNeeded(){
        try {
            var schemaOk=false
            db.rawQuery("PRAGMA table_info(question_fts)", null).use { c ->
                var cols=0; while(c.moveToNext()){ if(c.getString(1)=="source_id") schemaOk=true; cols++ }
                if(cols < 4) schemaOk=false
            }
            if(!schemaOk){ db.execSQL("DROP TABLE IF EXISTS question_fts"); db.execSQL("CREATE VIRTUAL TABLE question_fts USING fts4(question_id UNINDEXED, test_id UNINDEXED, source_id UNINDEXED, content)") }
            val indexed = db.rawQuery("SELECT COUNT(*) FROM question_fts", null).use { c -> c.moveToFirst(); c.getLong(0) }
            val questions = db.rawQuery("SELECT COUNT(*) FROM question", null).use { c -> c.moveToFirst(); c.getLong(0) }
            if (indexed == questions) return
            db.beginTransaction()
            try {
                db.delete("question_fts", null, null)
                db.rawQuery("SELECT q.id,q.test_id,s.id,COALESCE(q.text,'')||' '||COALESCE(q.raw_text,'')||' '||COALESCE(q.explanation,'')||' '||COALESCE(t.title,'')||' '||COALESCE(t.path,'')||' '||COALESCE(s.display_name,s.file_name,'')||' '||COALESCE((SELECT group_concat(o.text,' ') FROM option_item o WHERE o.question_id=q.id),'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id", null).use { c ->
                    val st=db.compileStatement("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)")
                    while(c.moveToNext()){ st.bindLong(1,c.getLong(0)); st.bindString(2,c.getString(1)); st.bindLong(3,c.getLong(2)); st.bindString(4,c.getString(3)); st.executeInsert(); st.clearBindings() }
                }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        } catch (_: Exception) { }
    }

    fun questionExists(questionId:Long):Boolean = db.rawQuery("SELECT 1 FROM question WHERE id=? LIMIT 1", arrayOf(questionId.toString())).use { it.moveToFirst() }

    /** Bulk existence check used by collection/backup flows. Avoids one SQLite query per ID. */
    fun existingQuestionIds(ids: LongArray): LongArray {
        if (ids.isEmpty()) return longArrayOf()
        val out = ArrayList<Long>(ids.size)
        ids.distinct().chunked(500).forEach { chunk ->
            val placeholders = chunk.joinToString(",") { "?" }
            db.rawQuery("SELECT id FROM question WHERE id IN ($placeholders)", chunk.map { it.toString() }.toTypedArray()).use { c ->
                while (c.moveToNext()) out.add(c.getLong(0))
            }
        }
        return out.toLongArray()
    }

    fun close(){db.close()}
    fun sources(): List<Source> = db.rawQuery("SELECT id,COALESCE(display_name,file_name),provider,COALESCE(series_number,'') FROM source ORDER BY imported_at DESC",null).use{c->buildList{while(c.moveToNext())add(Source(c.getLong(0),c.getString(1),c.getString(2),c.getString(3)))}}
    fun sourceNameForTest(testId:String):String? = db.rawQuery("SELECT COALESCE(s.display_name,s.file_name) FROM source s JOIN test t ON t.source_id=s.id WHERE t.id=? LIMIT 1", arrayOf(testId)).use { c -> if (c.moveToFirst()) c.getString(0) else null }
    fun testById(testId:String):Test? = db.rawQuery("SELECT id,title,path,num_questions,total_marks,duration_seconds,time_per_question,COALESCE(series_number,'') FROM test WHERE id=? LIMIT 1",arrayOf(testId)).use { c -> if(c.moveToFirst()) Test(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getDouble(4),c.getInt(5),c.getDouble(6),c.getString(7)) else null }
    fun tests(sourceId:Long):List<Test> = db.rawQuery("SELECT id,title,path,num_questions,total_marks,duration_seconds,time_per_question,COALESCE(series_number,'') FROM test WHERE source_id=? ORDER BY rowid",arrayOf(sourceId.toString())).use{c->buildList{while(c.moveToNext())add(Test(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getDouble(4),c.getInt(5),c.getDouble(6),c.getString(7)))}}
    fun questionContext(questionId:Long):Pair<String,String> = db.rawQuery("SELECT COALESCE(t.title,''), COALESCE(t.path,'') FROM question q JOIN test t ON t.id=q.test_id WHERE q.id=? LIMIT 1",arrayOf(questionId.toString())).use { c ->
        if(c.moveToFirst()){ val title=c.getString(0).orEmpty(); val path=c.getString(1).orEmpty(); val subject=(path.split("/","\\",">","::").map{it.trim()}.filter{it.isNotBlank()}.firstOrNull() ?: title.substringBefore("-").trim()).ifBlank{"General"}; subject to title.ifBlank{"Question $questionId"} } else "Unlinked" to "Question $questionId"
    }

    fun questionCount(testId:String):Int = db.rawQuery("SELECT COUNT(*) FROM question WHERE test_id=?", arrayOf(testId)).use { c -> c.moveToFirst(); c.getInt(0) }

    fun rawQuestionPosition(testId:String, questionId:Long):Int? = db.rawQuery("SELECT position FROM question WHERE test_id=? AND id=? LIMIT 1", arrayOf(testId, questionId.toString())).use { c -> if (c.moveToFirst()) c.getInt(0) else null }

    fun questionAt(testId:String, position:Int):Question? {
        return db.rawQuery("SELECT id,position,source_question_id,COALESCE(text,''),raw_text,correct_answer,explanation,bot,video,audio FROM question WHERE test_id=? AND position=? LIMIT 1", arrayOf(testId, position.toString())).use { c ->
            if (!c.moveToFirst()) return@use null
            val id=c.getLong(0); val opts=mutableListOf<Option>()
            db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position",arrayOf(id.toString())).use{o->while(o.moveToNext())opts.add(Option(o.getString(0) ?: "",o.getString(1) ?: "",o.getInt(2)!=0))}
            Question(id,stableKey(testId,c.getInt(1),c.getString(2)),c.getInt(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),opts,images(id,"question"),images(id,"explanation"))
        }
    }

    fun questionById(questionId:Long):Question? {
        return db.rawQuery("SELECT test_id,position FROM question WHERE id=? LIMIT 1", arrayOf(questionId.toString())).use { c ->
            if (!c.moveToFirst()) return@use null
            questionAt(c.getString(0), c.getInt(1))
        }
    }

    fun sourceIdForTest(testId:String):Long = db.rawQuery("SELECT source_id FROM test WHERE id=? LIMIT 1",arrayOf(testId)).use { c -> if(c.moveToFirst()) c.getLong(0) else 0L }
    fun testIdForQuestion(questionId:Long):String? = db.rawQuery("SELECT test_id FROM question WHERE id=? LIMIT 1", arrayOf(questionId.toString())).use { c -> if(c.moveToFirst()) c.getString(0) else null }

    fun questions(testId:String):List<Question>{
        val out=mutableListOf<Question>()
        db.rawQuery("SELECT id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio FROM question WHERE test_id=? ORDER BY position",arrayOf(testId)).use{c->while(c.moveToNext()){
            val id=c.getLong(0); val opts=mutableListOf<Option>()
            db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position",arrayOf(id.toString())).use{o->while(o.moveToNext())opts.add(Option(o.getString(0) ?: "",o.getString(1) ?: "",o.getInt(2)!=0))}
            out.add(Question(id,stableKey(testId,c.getInt(1),c.getString(2)),c.getInt(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),opts,images(id,"question"),images(id,"explanation")))
        }}
        return out
    }
    private fun images(qid:Long,kind:String)=db.rawQuery("SELECT uri FROM question_image WHERE question_id=? AND kind=? ORDER BY position",arrayOf(qid.toString(),kind)).use{c->buildList{while(c.moveToNext())add(c.getString(0))}}
    private fun stableKey(testId:String, position:Int, sourceQuestionId:String?):String = "$testId:$position:${sourceQuestionId.orEmpty()}"

    fun allStableKeys():List<String> = db.rawQuery("SELECT test_id,position,source_question_id FROM question ORDER BY rowid",null).use { c -> buildList { while(c.moveToNext()) add(stableKey(c.getString(0), c.getInt(1), c.getString(2))) } }

    /**
     * Question-reference index. Dashboard paths use lightweight=true so opening Rovex never
     * materializes every question's HTML/text just to count or route questions.
     */
    fun allQuestionRefs(lightweight: Boolean = false):List<QuestionRef> {
        val textExpr = if (lightweight) "''" else "COALESCE(q.text,'')"
        val sql = "SELECT q.id,q.test_id,q.position,q.source_question_id,$textExpr,t.title,t.path,s.id,COALESCE(s.display_name,s.file_name) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id ORDER BY s.imported_at DESC,t.rowid,q.position"
        return db.rawQuery(sql,null).use{c->buildList{while(c.moveToNext()){
            val id=c.getLong(0); val testId=c.getString(1); val pos=c.getInt(2); val sid=c.getString(3)
            add(QuestionRef(id,"$testId:$pos:${sid ?: ""}",testId,pos,c.getString(4) ?: "",c.getString(5),c.getLong(7),c.getString(8),categoryFor(c.getString(6), c.getString(5), c.getString(8))))
        }}}
    }
    private fun categoryFor(path:String?, title:String, sourceName:String):String {
        fun useful(v:String):Boolean {
            val x=v.trim().lowercase()
            return x.isNotBlank() && x !in setOf("test","tests","section","sections","qbank","question bank","quiz","quizzes","practice")
        }
        val raw=(path ?: "").trim().trim('/').replace("\\", "/")
        val parts=raw.split('/').map{it.trim()}.filter{useful(it)}
        if(parts.isNotEmpty()) return parts.last().take(48)
        val titleParts=title.split(Regex("\\s*[-–—|:]\\s*"), limit=2).map{it.trim()}
        if(titleParts.isNotEmpty() && useful(titleParts.first())) return titleParts.first().take(48)
        val file=sourceName.substringBeforeLast('.', sourceName).trim()
        return if(useful(file)) file.take(48) else "General"
    }

    fun updateSourceMetadata(sourceId:Long, displayName:String, seriesNumber:String):Boolean {
        val name = displayName.trim().take(180)
        if (name.isBlank()) return false
        return try {
            db.execSQL("UPDATE source SET display_name=?,series_number=? WHERE id=?", arrayOf(name, seriesNumber.trim().take(80), sourceId))
            AppState.changed()
            true
        } catch (_: android.database.sqlite.SQLiteConstraintException) { false }
    }

    fun updateTestMetadata(testId:String, title:String, seriesNumber:String):Boolean {
        val name = title.trim().take(180)
        if (name.isBlank()) return false
        return try {
            db.execSQL("UPDATE test SET title=?,series_number=? WHERE id=?", arrayOf(name, seriesNumber.trim().take(80), testId))
            AppState.changed()
            true
        } catch (_: Exception) { false }
    }

    fun deleteSource(sourceId:Long){db.beginTransaction();try{db.delete("source","id=?",arrayOf(sourceId.toString()));db.setTransactionSuccessful()}finally{db.endTransaction()}}
    fun questionRefsForIds(ids:LongArray):List<QuestionRef>{
        if(ids.isEmpty()) return emptyList()
        val wanted=ids.toSet(); return allQuestionRefs().filter{it.id in wanted}
    }
    fun questionIdsMatchingText(token:String):LongArray = search(token).map{it.id}.toLongArray()
    fun saveNote(questionId:Long,note:String){
        if(note.isBlank()) db.delete("question_note","question_id=?",arrayOf(questionId.toString()))
        else db.execSQL("INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)",arrayOf(questionId,note,System.currentTimeMillis()))
        AppState.changed()
    }
    fun deleteNote(questionId:Long){ db.delete("question_note","question_id=?",arrayOf(questionId.toString())); AppState.changed() }
    fun deleteNotes(questionIds:LongArray){
        if(questionIds.isEmpty()) return
        db.beginTransaction()
        try {
            questionIds.distinct().chunked(500).forEach { chunk ->
                val args=chunk.map{it.toString()}.toTypedArray()
                val placeholders=chunk.joinToString(","){ "?" }
                db.delete("question_note","question_id IN ($placeholders)",args)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        AppState.changed()
    }
    fun note(questionId:Long):String? = db.rawQuery("SELECT note FROM question_note WHERE question_id=?",arrayOf(questionId.toString())).use{c->if(c.moveToFirst())c.getString(0) else null}
    fun notes():List<Pair<Long,String>> = db.rawQuery("SELECT question_id,note FROM question_note ORDER BY updated_at DESC",null).use{c->buildList{while(c.moveToNext())add(c.getLong(0) to c.getString(1))}}
    data class NoteRecord(
        val questionId: Long, val note: String, val updatedAt: Long,
        val subject: String, val testTitle: String, val sourceName: String, val position: Int
    )

    fun noteCount(): Int = db.rawQuery("SELECT COUNT(*) FROM question_note", null).use { c -> c.moveToFirst(); c.getInt(0) }

    fun noteRecords(): List<NoteRecord> = db.rawQuery(
        "SELECT n.question_id,n.note,n.updated_at,COALESCE(t.path,''),COALESCE(t.title,''),COALESCE(s.display_name,s.file_name,''),q.position FROM question_note n LEFT JOIN question q ON q.id=n.question_id LEFT JOIN test t ON t.id=q.test_id LEFT JOIN source s ON s.id=t.source_id ORDER BY n.updated_at DESC", null
    ).use { c -> buildList {
        while (c.moveToNext()) {
            val path = c.getString(3).orEmpty()
            val title = c.getString(4).orEmpty().ifBlank { "Question ${c.getLong(0)}" }
            val sourceName = c.getString(5).orEmpty().ifBlank { "Unknown QBank" }
            val subject = path.split('/', '\\', '>', ':').map { it.trim() }.firstOrNull { it.isNotBlank() }
                ?: title.split(Regex("\\s*[-–—|:]\\s*"), limit = 2).firstOrNull().orEmpty().trim().ifBlank { "General" }
            add(NoteRecord(c.getLong(0), c.getString(1).orEmpty(), c.getLong(2), subject, title, sourceName, c.getInt(6)))
        }
    } }
    fun replaceNotes(notes:List<Pair<Long,String>>){
        db.beginTransaction()
        try {
            db.delete("question_note", null, null)
            val st=db.compileStatement("INSERT OR REPLACE INTO question_note(question_id,note,updated_at) VALUES(?,?,?)")
            notes.forEach { (id,note) -> if(note.isNotBlank()){ st.bindLong(1,id); st.bindString(2,note); st.bindLong(3,System.currentTimeMillis()); st.executeInsert(); st.clearBindings() } }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        AppState.changed()
    }
    fun questionRefsByKeyword(keyword:String):List<QuestionRef>{
        val k=keyword.trim(); if(k.isBlank()) return emptyList()
        return allQuestionRefs().filter{it.testTitle.contains(k,true)||it.category.contains(k,true)||it.sourceName.contains(k,true)}
    }
    fun sourceQuestionCount(sourceId:Long):Int=db.rawQuery("SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?",arrayOf(sourceId.toString())).use{c->c.moveToFirst();c.getInt(0)}
    fun testQuestionRefs(testId:String):List<QuestionRef> = allQuestionRefs().filter { it.testId == testId }
    fun progressSummaryForTest(testId:String, store:ProgressStore):ProgressSummary {
        var total=0; var solved=0; var correct=0; var resume=0; var foundResume=false
        db.rawQuery("SELECT position,source_question_id FROM question WHERE test_id=? ORDER BY position",arrayOf(testId)).use { c ->
            while(c.moveToNext()) {
                total++
                val key="$testId:${c.getInt(0)}:${c.getString(1)}"
                val st=store.status(key)
                if(st!=null){ solved++; if(st=="correct") correct++ } else if(!foundResume){ resume=c.getInt(0); foundResume=true }
            }
        }
        return ProgressSummary(total,solved,correct,resume)
    }
    fun progressSummaryForSource(sourceId:Long, store:ProgressStore):ProgressSummary {
        var total=0; var solved=0; var correct=0
        db.rawQuery("SELECT q.test_id,q.position,q.source_question_id FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=? ORDER BY t.rowid,q.position",arrayOf(sourceId.toString())).use { c ->
            while(c.moveToNext()){ total++; val key="${c.getString(0)}:${c.getInt(1)}:${c.getString(2)}"; val st=store.status(key); if(st!=null){solved++;if(st=="correct")correct++} }
        }
        return ProgressSummary(total,solved,correct,0)
    }
    fun testProgressSummaries(sourceId:Long, progress:ProgressSnapshot):Map<String,ProgressSummary> {
        val out = LinkedHashMap<String, ProgressSummary>()
        db.rawQuery("SELECT test_id,position,source_question_id FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=? ORDER BY t.rowid,q.position", arrayOf(sourceId.toString())).use { c ->
            var current: String? = null
            var total = 0; var solved = 0; var correct = 0; var resume = 0; var foundResume = false
            fun flush() {
                val id = current ?: return
                out[id] = ProgressSummary(total, solved, correct, resume)
            }
            while (c.moveToNext()) {
                val id = c.getString(0)
                if (current != null && current != id) { flush(); total = 0; solved = 0; correct = 0; resume = 0; foundResume = false }
                current = id
                total++
                val key = stableKey(id, c.getInt(1), c.getString(2))
                val state = progress.record(key)
                if (state?.status != null) { solved++; if (state.status == "correct") correct++ }
                else if (!foundResume) { resume = c.getInt(1); foundResume = true }
            }
            flush()
        }
        return out
    }

    private fun escapeLike(value:String):String = value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    fun search(query:String, resultLimit:Int = 400):List<SearchHit>{
        val tokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
        if(tokens.isEmpty()) return emptyList()
        // Prefer FTS4. Every token must occur somewhere in the indexed QBank/question metadata.
        try {
            val match=tokens.joinToString(" AND "){ it.replace(Regex("[^\\p{L}\\p{N}_]"), "") + "*" }
            return db.rawQuery("SELECT q.id,q.test_id,t.title,q.position,q.source_question_id,q.text,t.path,COALESCE(s.display_name,s.file_name) FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE question_fts MATCH ? ORDER BY s.imported_at DESC,t.rowid,q.position LIMIT ${resultLimit.coerceIn(1, 1200)}", arrayOf(match)).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
        } catch (_: Exception) { }
        // Safe fallback for SQLite builds without FTS4. Tokenized AND semantics avoid huge unbounded scans.
        val clauses=mutableListOf<String>(); val args=mutableListOf<String>()
        for(token in tokens){
            val like="%${escapeLike(token)}%"
            clauses += "(q.text LIKE ? ESCAPE '\\' OR q.raw_text LIKE ? ESCAPE '\\' OR q.explanation LIKE ? ESCAPE '\\' OR t.title LIKE ? ESCAPE '\\' OR COALESCE(t.path,'') LIKE ? ESCAPE '\\' OR COALESCE(s.display_name,s.file_name) LIKE ? ESCAPE '\\' OR EXISTS(SELECT 1 FROM option_item o WHERE o.question_id=q.id AND o.text LIKE ? ESCAPE '\\'))"
            repeat(7){args += like}
        }
        return db.rawQuery("SELECT q.id,q.test_id,t.title,q.position,q.source_question_id,q.text,t.path,COALESCE(s.display_name,s.file_name) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE ${clauses.joinToString(" AND ")} ORDER BY s.imported_at DESC,t.rowid,q.position LIMIT ${resultLimit.coerceIn(1, 1200)}",args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
    }

    fun searchSections(query:String):List<SectionHit>{
        val tokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
        if(tokens.isEmpty()) return emptyList()
        val clauses=tokens.map{ "(t.title LIKE ? ESCAPE '\\' OR COALESCE(t.path,'') LIKE ? ESCAPE '\\' OR COALESCE(s.display_name,s.file_name) LIKE ? ESCAPE '\\')" }
        val args=tokens.flatMap{ val like="%${escapeLike(it)}%"; listOf(like,like,like) }
        return db.rawQuery("SELECT t.id,t.title,COALESCE(t.path,''),COALESCE(s.display_name,s.file_name),t.num_questions FROM test t JOIN source s ON s.id=t.source_id WHERE ${clauses.joinToString(" AND ")} ORDER BY s.imported_at DESC,t.rowid LIMIT 200",args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SectionHit(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4)))}}
    }

    fun beginStreamingImport(fileName:String, provider:String): StreamingImportSession {
        var sourceId = 0L
        db.beginTransaction()
        try {
            db.delete("source", "file_name=?", arrayOf(fileName))
            val st=db.compileStatement("INSERT INTO source(file_name,display_name,series_number,provider,imported_at) VALUES(?,?,?,?,?)")
            st.bindString(1,fileName); st.bindString(2,fileName); st.bindString(3,""); st.bindString(4,provider); st.bindLong(5,System.currentTimeMillis())
            sourceId=st.executeInsert()
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return StreamingImportSession(sourceId, fileName)
    }

    inner class StreamingImportSession(private val sourceId:Long, private val fileName:String) {
        private val tests=LinkedHashMap<String,Pair<String,Int>>()
        private var total=0
        private var closed=false
        private var inTransaction=false

        init { beginTransaction() }

        private fun beginTransaction() {
            if (!inTransaction && !closed) {
                db.beginTransaction()
                inTransaction=true
            }
        }

        /** Commit the questions accumulated for the current HTML section, then start a fresh transaction. */
        fun commitSection() {
            if (closed || !inTransaction) return
            try {
                for ((_,pair) in tests) db.execSQL("UPDATE test SET num_questions=? WHERE id=?", arrayOf(pair.second,pair.first))
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
                inTransaction=false
            }
            beginTransaction()
        }

        fun addQuestion(section:String, q:ImportedQuestion) {
            check(!closed) { "Import session is closed" }
            beginTransaction()
            val title=section.trim().ifBlank { "Imported Section" }.take(120)
            val test=tests.getOrPut(title) {
                val original=title
                val id=makeId(fileName, original, tests.size)
                db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions,total_marks,duration_seconds,time_per_question,original_id,series_number) VALUES(?,?,?,?,?,?,?,?,?,?)", arrayOf(id,sourceId,title,null,0,0.0,0,0.0,original,""))
                id to 0
            }
            val testId=test.first
            val pos=test.second
            val qst=db.compileStatement("INSERT INTO question(test_id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio) VALUES(?,?,?,?,?,?,?,?,?,?)")
            qst.bindString(1,testId); qst.bindLong(2,pos.toLong()); bindNullable(qst,3,q.sourceId); bindNullable(qst,4,q.text); bindNullable(qst,5,q.rawText); bindNullable(qst,6,q.correctAnswer); bindNullable(qst,7,q.explanation); bindNullable(qst,8,q.bot); bindNullable(qst,9,q.video); bindNullable(qst,10,q.audio)
            val qid=qst.executeInsert()
            q.options.forEachIndexed { i,o -> db.execSQL("INSERT INTO option_item(question_id,position,label,text,is_correct) VALUES(?,?,?,?,?)", arrayOf(qid,i,o.label,o.text,if(o.correct)1 else 0)) }
            q.questionImages.forEachIndexed { i,u -> db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)", arrayOf(qid,"question",i,u)) }
            q.explanationImages.forEachIndexed { i,u -> db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)", arrayOf(qid,"explanation",i,u)) }
            try { db.execSQL("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)", arrayOf(qid,testId,sourceId, q.text+" "+(q.rawText ?: "")+" "+(q.explanation ?: "")+" "+title+" "+q.options.joinToString(" "){it.text}+" "+fileName)) } catch (_: Exception) {}
            tests[title]=testId to (pos+1)
            total++
            // Keep very large single-section QBanks from holding one SQLite transaction for hours.
            if(total % 250 == 0) commitSection()
        }

        /** Roll back only the active transaction and remove any already-committed partial import. */
        fun abort() {
            if (closed) return
            try {
                if (inTransaction) {
                    db.endTransaction()
                    inTransaction=false
                }
                db.beginTransaction()
                db.delete("source", "id=?", arrayOf(sourceId.toString()))
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
                closed=true
            }
        }

        fun finish(success:Boolean) {
            if(closed) return
            if (!success) { abort(); return }
            try {
                for ((_,pair) in tests) db.execSQL("UPDATE test SET num_questions=? WHERE id=?", arrayOf(pair.second,pair.first))
                if(inTransaction) db.setTransactionSuccessful()
            } finally {
                if(inTransaction) db.endTransaction()
                inTransaction=false
                closed=true
            }
        }
    }

    fun importBundle(fileName:String, provider:String, tests:List<ImportedTest>, onProgress:(done:Int,total:Int)->Unit = {_,_->}):Int {
        db.beginTransaction()
        try {
            db.delete("source","file_name=?",arrayOf(fileName))
            val s=db.compileStatement("INSERT INTO source(file_name,display_name,series_number,provider,imported_at) VALUES(?,?,?,?,?)")
            s.bindString(1,fileName);s.bindString(2,fileName);s.bindString(3,"");s.bindString(4,provider);s.bindLong(5,System.currentTimeMillis());val sourceId=s.executeInsert()
            var count=0
            val totalQuestions = tests.sumOf { it.questions.size }.coerceAtLeast(1)
            for ((ti,t) in tests.withIndex()) {
                val testId=makeId(fileName,t.originalId ?: t.title,ti)
                db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions,total_marks,duration_seconds,time_per_question,original_id,series_number) VALUES(?,?,?,?,?,?,?,?,?,?)",arrayOf(testId,sourceId,t.title,t.path,t.questions.size,t.totalMarks,t.duration,t.timePerQuestion,t.originalId,t.seriesNumber ?: ""))
                for ((qi,q) in t.questions.withIndex()) {
                    val st=db.compileStatement("INSERT INTO question(test_id,position,source_question_id,text,raw_text,correct_answer,explanation,bot,video,audio) VALUES(?,?,?,?,?,?,?,?,?,?)")
                    st.bindString(1,testId);st.bindLong(2,qi.toLong());bindNullable(st,3,q.sourceId);bindNullable(st,4,q.text);bindNullable(st,5,q.rawText);bindNullable(st,6,q.correctAnswer);bindNullable(st,7,q.explanation);bindNullable(st,8,q.bot);bindNullable(st,9,q.video);bindNullable(st,10,q.audio);val qid=st.executeInsert()
                    q.options.forEachIndexed{oi,o->db.execSQL("INSERT INTO option_item(question_id,position,label,text,is_correct) VALUES(?,?,?,?,?)",arrayOf(qid,oi,o.label,o.text,if(o.correct)1 else 0))}
                    q.questionImages.forEachIndexed{ii,u->db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)",arrayOf(qid,"question",ii,u))}
                    q.explanationImages.forEachIndexed{ii,u->db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(?,?,?,?)",arrayOf(qid,"explanation",ii,u))}
                    try { db.execSQL("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(?,?,?,?)",arrayOf(qid,testId,sourceId,q.text+" "+(q.rawText ?: "")+" "+(q.explanation ?: "")+" "+t.title+" "+q.options.joinToString(" "){it.text}+" "+t.title)) } catch (_: Exception) {}
                    count++
                    if (count == 1 || count % 25 == 0 || count == totalQuestions) onProgress(count, totalQuestions)
                }
            }
            db.setTransactionSuccessful(); AppState.changed(); return count
        } finally {db.endTransaction()}
    }
    private fun bindNullable(st:android.database.sqlite.SQLiteStatement,i:Int,v:String?){if(v==null)st.bindNull(i) else st.bindString(i,v)}
    private fun makeId(file:String,original:String,index:Int):String{val raw="$file|$original|$index";return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).joinToString(""){String.format("%02x",it)}.take(24)}
}

data class Source(val id:Long,val fileName:String,val provider:String,val seriesNumber:String="")
data class Test(val id:String,val title:String,val path:String?,val count:Int,val marks:Double,val duration:Int,val timePerQuestion:Double,val seriesNumber:String="")
data class Option(val label:String,val text:String,val correct:Boolean)
data class Question(val id:Long,val stableKey:String,val position:Int,val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<Option>,val questionImages:List<String>,val explanationImages:List<String>)
data class QuestionRef(val id:Long,val stableKey:String,val testId:String,val position:Int,val text:String,val testTitle:String,val sourceId:Long,val sourceName:String,val category:String)
data class SearchHit(val id:Long,val testId:String,val testTitle:String,val position:Int,val text:String,val path:String?,val sourceName:String,val stableKey:String)
data class SectionHit(val testId:String,val title:String,val path:String,val sourceName:String,val count:Int)
data class ProgressSummary(val total:Int,val solved:Int,val correct:Int,val resumePosition:Int)
data class ImportedTest(val originalId:String?,val title:String,val path:String?,val totalMarks:Double,val duration:Int,val timePerQuestion:Double,val questions:List<ImportedQuestion>,val seriesNumber:String?=null)
data class ImportedQuestion(val sourceId:String?,val text:String,val rawText:String?,val correctAnswer:String?,val explanation:String?,val bot:String?,val video:String?,val audio:String?,val options:List<ImportedOption>,val questionImages:List<String>,val explanationImages:List<String>)
data class ImportedOption(val label:String,val text:String,val correct:Boolean)

class ProgressStore(context: Context) {
    private val appContext=context.applicationContext
    private val p=appContext.getSharedPreferences("progress",Context.MODE_PRIVATE)
    private fun key(id:String,s:String)=id+":"+s
    fun selected(id:String)=p.getString(key(id,"answer"),null)
    fun status(id:String)=p.getString(key(id,"status"),null)
    fun bookmark(id:String)=p.getString(key(id,"bookmark"),null)
    fun review(id:String)=p.getBoolean(key(id,"review"),false)
    fun position(testId:String):Int=p.getInt(key(testId,"position"),0)
    fun sourceResume(sourceId:Long):String?=p.getString("source:$sourceId:resume",null)
    fun sourceResumeByName(sourceName:String):String?=p.getString("sourceName:${sourceName}:resume",null)
    private fun changed(cloud:Boolean=true){ AppState.changed(); BackupManager(appContext).onProgressChanged(cloud) }
    fun setPosition(testId:String,position:Int,sourceId:Long=0L,sourceName:String?=null){
        val e=p.edit().putInt(key(testId,"position"),position.coerceAtLeast(0))
        if(sourceId>0) e.putString("source:$sourceId:resume", "$testId|${position.coerceAtLeast(0)}")
        if(!sourceName.isNullOrBlank()) e.putString("sourceName:${sourceName}:resume", "$testId|${position.coerceAtLeast(0)}")
        e.apply(); changed(false)
    }
    // --- Spaced repetition (SM-2 style) ---
    // easeFactor: how quickly the interval grows for a question you keep getting right (min 1.3).
    // repetitions: consecutive correct answers since the last miss.
    // intervalDays: the gap just scheduled, in days.
    // nextDue: the actual timestamp used to decide if a question is due; 0 means "never scheduled",
    // which happens for progress written before this feature existed (legacy fallback applies).
    fun easeFactor(id:String)=PrefsCompat.float(p,key(id,"ef"),2.5f)
    fun repetitions(id:String)=p.getInt(key(id,"reps"),0)
    fun intervalDays(id:String)=PrefsCompat.float(p,key(id,"intervalDays"),0f)
    fun nextDue(id:String)=PrefsCompat.long(p,key(id,"nextDue"),0L)
    fun setAnswer(id:String,a:String,status:String){
        val attempts=p.getInt(key(id,"attempts"),0)+1
        val now=System.currentTimeMillis()
        val day=86_400_000L
        val correct=status=="correct"
        // Binary quality signal (SM-2 normally uses 0-5 recall grades; correct/wrong is what
        // this app's UI actually captures, so we map to the two grades that matter most:
        // "remembered it" vs "didn't").
        val quality=if(correct)5 else 2
        var ef=easeFactor(id)
        var reps=repetitions(id)
        val prevInterval=intervalDays(id)
        val intervalDays:Float
        if(quality<3){
            // A miss resets the streak and brings it back tomorrow, regardless of how well it
            // was doing before - that's the whole point of spaced repetition catching weak spots.
            reps=0
            intervalDays=1f
        } else {
            reps+=1
            intervalDays=when(reps){1->1f;2->6f;else->(if(prevInterval>0f)prevInterval else 6f)*ef}
        }
        ef=(ef+(0.1f-(5-quality)*(0.08f+(5-quality)*0.02f))).coerceAtLeast(1.3f)
        val nextDue=now+(intervalDays*day).toLong()
        p.edit().putString(key(id,"answer"),a).putString(key(id,"status"),status).putInt(key(id,"attempts"),attempts)
            .putLong(key(id,"lastAttempted"),now).putFloat(key(id,"ef"),ef).putInt(key(id,"reps"),reps)
            .putFloat(key(id,"intervalDays"),intervalDays).putLong(key(id,"nextDue"),nextDue).apply()
        changed()
    }
    /** True if a question should show up in the revision queue right now. Unattempted questions
     *  are always due (they're the backlog); attempted ones follow the SM-2 schedule once one
     *  exists, or the old fixed ladder for progress recorded before this feature shipped. */
    fun isDue(id:String):Boolean{
        val status=status(id) ?: return true
        val last=lastAttempted(id)
        if(last==0L) return true
        val next=nextDue(id)
        if(next>0L) return System.currentTimeMillis()>=next
        val day=86_400_000L
        return System.currentTimeMillis()-last>=when(attempts(id)){1->day;2->3*day;3->7*day;4->14*day;else->30*day}
    }

    /** Scheduled-due semantics: unseen questions are NEW, not part of the due-review queue. */
    fun isScheduledDue(id:String):Boolean {
        if (status(id).isNullOrBlank()) return false
        val next=nextDue(id)
        if(next>0L) return System.currentTimeMillis()>=next
        val last=lastAttempted(id)
        if(last<=0L) return false
        val day=86_400_000L
        return System.currentTimeMillis()-last>=when(attempts(id)){1->day;2->3*day;3->7*day;4->14*day;else->30*day}
    }
    fun attempts(id:String)=p.getInt(key(id,"attempts"),0)
    fun lastAttempted(id:String)=PrefsCompat.long(p,key(id,"lastAttempted"),0L)
    fun timeMs(id:String)=PrefsCompat.long(p,key(id,"timeMs"),0L)
    fun mistakeType(id:String)=p.getString(key(id,"mistake"),null)
    fun setMistakeType(id:String,value:String?){ val e=p.edit(); if(value.isNullOrBlank()) e.remove(key(id,"mistake")) else e.putString(key(id,"mistake"),value); e.apply(); changed() }
    fun addTime(id:String,elapsedMs:Long){ if(elapsedMs<=0L)return; p.edit().putLong(key(id,"timeMs"),timeMs(id)+elapsedMs).apply(); changed(false) }
    fun allProgressKeys():Set<String> = p.all.keys
    fun setBookmark(id:String,v:String?){val e=p.edit();if(v.isNullOrBlank())e.remove(key(id,"bookmark")) else e.putString(key(id,"bookmark"),v);e.apply(); changed()}
    fun setReview(id:String,v:Boolean){p.edit().putBoolean(key(id,"review"),v).apply(); changed()}
    fun clear(id:String){p.edit().apply{remove(key(id,"answer"));remove(key(id,"status"));remove(key(id,"bookmark"));remove(key(id,"review"));remove(key(id,"mistake"));remove(key(id,"ef"));remove(key(id,"reps"));remove(key(id,"intervalDays"));remove(key(id,"nextDue"))}.apply(); changed()}
    fun allEntries():Map<String,*> = p.all.toMap()
    fun restore(entries:Map<String,*>){
        val e=p.edit().clear()
        for((k,v) in entries){when(v){is Boolean->e.putBoolean(k,v);is Int->e.putInt(k,v);is Long->e.putLong(k,v);is Float->e.putFloat(k,v);is String->e.putString(k,v)}}
        e.commit()
    }
}

