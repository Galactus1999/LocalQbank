package com.localqbank.library

import android.content.Context

/** Small read-only health facade for the intelligence console. */
class EngineHealthManager(context: Context) {
    private val app = context.applicationContext
    data class Snapshot(val overall: Int, val safeMode: Boolean, val crashCount: Int, val lastError: String?, val recovery: ResilienceManager.RecoveryState?)
    fun snapshot(): Snapshot {
        val p = app.getSharedPreferences("resilience", Context.MODE_PRIVATE)
        return Snapshot(
            overall = PerformanceManager.healthScore(),
            safeMode = PerformanceManager.isSafeMode(),
            crashCount = p.getInt("crash_count", 0),
            lastError = p.getString("last_error", null),
            recovery = ResilienceManager.recovery(app)
        )
    }
}
