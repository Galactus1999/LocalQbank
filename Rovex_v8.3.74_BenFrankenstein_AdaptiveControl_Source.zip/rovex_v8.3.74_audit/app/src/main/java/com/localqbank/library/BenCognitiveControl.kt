package com.localqbank.library

import android.content.Context

/** User-visible switches for Ben's cognitive subsystems. Policy only; no runtime ownership. */
class BenCognitiveControl(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val cognitiveCoreEnabled get() = prefs.getBoolean(KEY_CORE, true)
    val knowledgeGraphEnabled get() = prefs.getBoolean(KEY_GRAPH, true)
    val learnerMemoryEnabled get() = prefs.getBoolean(KEY_LEARNER, true)
    val verifierEnabled get() = prefs.getBoolean(KEY_VERIFIER, true)
    val neuralAcceleratorEnabled get() = BenAiRuntimePolicy(context).enabled

    fun setCognitiveCoreEnabled(v:Boolean) = prefs.edit().putBoolean(KEY_CORE,v).apply()
    fun setKnowledgeGraphEnabled(v:Boolean) = prefs.edit().putBoolean(KEY_GRAPH,v).apply()
    fun setLearnerMemoryEnabled(v:Boolean) = prefs.edit().putBoolean(KEY_LEARNER,v).apply()
    fun setVerifierEnabled(v:Boolean) = prefs.edit().putBoolean(KEY_VERIFIER,v).apply()

    fun resetToSafeDefaults() {
        prefs.edit().putBoolean(KEY_CORE,true).putBoolean(KEY_GRAPH,true).putBoolean(KEY_LEARNER,true).putBoolean(KEY_VERIFIER,true).apply()
        BenAiRuntimePolicy(context).forceStop()
    }

    companion object {
        private const val PREFS = "ben_cognitive_control"
        private const val KEY_CORE = "core"
        private const val KEY_GRAPH = "knowledge_graph"
        private const val KEY_LEARNER = "learner_memory"
        private const val KEY_VERIFIER = "verifier"
    }
}
