package com.localqbank.library

import android.content.Context
import kotlin.math.min

/**
 * Small, offline cognitive layer for Ben. It is deliberately deterministic and bounded:
 * intent detection, question summarisation, key-point extraction and study planning are
 * performed locally without pretending to be a remote LLM. A future on-device model can
 * implement the same contract without changing the specialist engines.
 */
class BenCognitiveEngine(context: Context) {
    private val app = context.applicationContext

    data class Insight(val title: String, val body: String, val actions: List<String> = emptyList())

    fun answer(command: String, currentQuestion: Question? = null): Insight {
        val text = command.trim()
        if (text.isBlank()) return Insight("Ben", "Tell me what you want to study, save, summarise or practise.")
        val lower = text.lowercase()
        return when {
            currentQuestion != null && ("summar" in lower || "explain" in lower || "key point" in lower || "high yield" in lower) ->
                summarise(currentQuestion)
            "flashcard" in lower || "flash card" in lower ->
                Insight("Flashcards", "I can build a local, deduplicated deck from your highest-priority questions.", listOf("Generate adaptive cards"))
            "note" in lower || "summary" in lower ->
                Insight("Knowledge", "I can turn a question into a structured local note and extract tables/images without changing the source QBank.", listOf("Create auto-note"))
            "wrong" in lower || "mistake" in lower -> {
                val ids = AppManagers.studyIntelligence.smartMix(30)
                Insight("Weakness review", "I prepared a local adaptive pool of ${ids.size} questions, prioritising due and weak items.", listOf("Start adaptive mix"))
            }
            "subject" in lower || "topic" in lower -> {
                val match = AppManagers.studyIntelligence.matchSubject(text, 50)
                Insight("Subject focus", AppManagers.studyIntelligence.explain(text, match.matched), listOf("Build saved set"))
            }
            "what should i study" in lower || "what should i revise" in lower || "study plan" in lower ->
                Insight("Study plan", AppManagers.adaptive.studyStrategy(), listOf("Open Study Tools"))
            else -> Insight("Ben", "I can work locally with your QBank: find weak questions, build adaptive sets, create flashcards, and organise knowledge. Try “make flashcards from my wrong questions”.")
        }
    }

    fun summarise(q: Question): Insight {
        val answer = plain(q.correctAnswer ?: q.options.firstOrNull { it.correct }?.label.orEmpty())
        val exp = plain(q.explanation.orEmpty())
        val points = extractKeyPoints(exp)
        val body = buildString {
            if (answer.isNotBlank()) append("Answer: ").append(answer.take(260)).append("\n\n")
            append("Key points\n")
            if (points.isEmpty()) append("Review the original explanation for the full context.")
            else points.forEach { append("• ").append(it).append('\n') }
        }.trim()
        return Insight("Ben's local summary", body, listOf("Save as note", "Create flashcard"))
    }

    fun extractKeyPoints(text: String): List<String> {
        val clean = plain(text)
        if (clean.isBlank()) return emptyList()
        val sentences = clean.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.length >= 35 }
        val markers = listOf("most common", "important", "first line", "gold standard", "diagnosis", "treatment", "management", "contraindication", "adverse", "associated", "classically", "hallmark", "preferred")
        return sentences.sortedWith(compareByDescending<String> { s -> markers.count { s.contains(it, true) } }.thenByDescending { s -> min(s.length, 220) })
            .distinct().take(5).map { it.take(220) }
    }

    fun capabilities(): List<String> = listOf("Local intent detection", "Question summarisation", "Key-point extraction", "Adaptive study planning", "Engine action suggestions")

    private fun plain(html: String): String = android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()
}
