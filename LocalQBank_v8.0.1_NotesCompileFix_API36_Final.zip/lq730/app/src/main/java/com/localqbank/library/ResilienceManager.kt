package com.localqbank.library

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local safety layer. It never attempts to kill/restart a frozen process: Android
 * remains authoritative for ANRs/process lifecycle. We persist tiny recovery state,
 * detect stale UI heartbeats from a background thread, and enter conservative safe mode.
 */
object ResilienceManager {
    private const val PREFS = "resilience"
    private const val KEY_RUNNING = "process_running"
    private const val KEY_CRASH_COUNT = "crash_count"
    private const val KEY_LAST_CRASH = "last_crash"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEY_ACTIVITY = "active_activity"
    private const val KEY_HEARTBEAT = "heartbeat_elapsed"
    private const val KEY_TEST = "quiz_test"
    private const val KEY_POS = "quiz_pos"
    private const val KEY_QKEY = "quiz_key"
    private const val KEY_SESSION = "quiz_session"
    private const val KEY_OFFER_RECOVERY = "offer_recovery"
    private const val KEY_STALLS = "suspected_stalls"

    private val installed = AtomicBoolean(false)
    private val monitor = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "qbank-resilience") }
    private val mainHandler = Handler(Looper.getMainLooper())
    private val heartbeatRunnable = object : Runnable {
        override fun run() {
            if (activeActivity) {
                heartbeatHolder?.let { heartbeat(it) }
                mainHandler.postDelayed(this, 4000L)
            }
        }
    }
    @Volatile private var activeActivity = false
    @Volatile private var heartbeatHolder: Context? = null
    private var previousHandler: Thread.UncaughtExceptionHandler? = null

    fun install(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        val app = context.applicationContext
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previousRunUnclean = p.getBoolean(KEY_RUNNING, false)
        if (previousRunUnclean) {
            val crashes = (p.getInt(KEY_CRASH_COUNT, 0) + 1).coerceAtMost(20)
            p.edit().putInt(KEY_CRASH_COUNT, crashes).putBoolean(KEY_RUNNING, false).putBoolean(KEY_OFFER_RECOVERY, true).apply()
            if (crashes >= 2) PerformanceManager.setSafeMode(true)
            AppEventBus.publish(AppEventBus.Event(AppEventBus.Type.SYSTEM_RECOVERED, successful = false))
        }
        p.edit().putBoolean(KEY_RUNNING, true).putLong(KEY_HEARTBEAT, SystemClock.elapsedRealtime()).apply()
        monitor.scheduleAtFixedRate({
            if (!activeActivity) return@scheduleAtFixedRate
            runCatching {
                val sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val last = sp.getLong(KEY_HEARTBEAT, 0L)
                if (last > 0L && SystemClock.elapsedRealtime() - last > 12000L) {
                    sp.edit().putInt(KEY_STALLS, sp.getInt(KEY_STALLS, 0) + 1).putBoolean(KEY_OFFER_RECOVERY, true).apply()
                    PerformanceManager.setSafeMode(true)
                }
            }
        }, 5, 5, TimeUnit.SECONDS)

        previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean(KEY_RUNNING, false)
                    .putLong(KEY_LAST_CRASH, System.currentTimeMillis())
                    .putString(KEY_LAST_ERROR, "${error.javaClass.simpleName}: ${error.message ?: ""}\n${sw.toString().take(6000)}")
                    .apply()
                PerformanceManager.setSafeMode(true)
            }
            previousHandler?.uncaughtException(thread, error)
        }
    }

    fun heartbeat(context: Context) {
        runCatching { context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_HEARTBEAT, SystemClock.elapsedRealtime()).apply() }
    }

    fun activityStarted(context: Context, activity: Activity) {
        activeActivity = true
        heartbeatHolder = activity.applicationContext
        mainHandler.removeCallbacks(heartbeatRunnable)
        mainHandler.post(heartbeatRunnable)
        runCatching { context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ACTIVITY, activity.javaClass.simpleName).putLong(KEY_HEARTBEAT, SystemClock.elapsedRealtime()).apply() }
    }

    fun activityStopped(context: Context, activity: Activity) {
        activeActivity = false
        heartbeatHolder = null
        mainHandler.removeCallbacks(heartbeatRunnable)
        runCatching {
            val app = context.applicationContext
            val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (p.getString(KEY_ACTIVITY, null) == activity.javaClass.simpleName) p.edit().putLong(KEY_HEARTBEAT, SystemClock.elapsedRealtime()).apply()
            // Once the app has genuinely left the foreground, treat the process as a clean
            // background lifecycle so a later Android process recreation is not mislabelled as a crash.
            mainHandler.postDelayed({
                if (!activeActivity) app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
            }, 2500L)
        }
    }

    fun checkpointQuiz(context: Context, testId: String, position: Int, stableKey: String?, session: String?) {
        if (testId.isBlank() && stableKey.isNullOrBlank()) return
        runCatching {
            context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_TEST, testId).putInt(KEY_POS, position.coerceAtLeast(0))
                .putString(KEY_QKEY, stableKey ?: "").putString(KEY_SESSION, session ?: "")
                .putLong(KEY_HEARTBEAT, SystemClock.elapsedRealtime()).apply()
        }
    }

    fun recovery(context: Context): RecoveryState? = runCatching {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val test = p.getString(KEY_TEST, null).orEmpty()
        val key = p.getString(KEY_QKEY, null).orEmpty()
        if (test.isBlank() && key.isBlank()) null else RecoveryState(test, p.getInt(KEY_POS, 0), key, p.getString(KEY_SESSION, null).orEmpty())
    }.getOrNull()

    fun clearQuizRecovery(context: Context) {
        runCatching { context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_TEST).remove(KEY_POS).remove(KEY_QKEY).remove(KEY_SESSION).apply() }
    }

    fun shouldOfferRecovery(context: Context): Boolean = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_OFFER_RECOVERY, false) && recovery(context) != null
    fun dismissRecoveryOffer(context: Context) { context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_OFFER_RECOVERY, false).apply() }
    fun crashCount(context: Context): Int = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_CRASH_COUNT, 0)
    fun suspectedStalls(context: Context): Int = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_STALLS, 0)

    fun markHealthy(context: Context) {
        runCatching {
            val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            p.edit().putBoolean(KEY_RUNNING, true).putLong(KEY_HEARTBEAT, SystemClock.elapsedRealtime()).apply()
            if (PerformanceManager.healthScore() >= 85) PerformanceManager.setSafeMode(false)
            AppEventBus.publish(AppEventBus.Event(AppEventBus.Type.SYSTEM_RECOVERED))
        }
    }

    data class RecoveryState(val testId: String, val position: Int, val stableKey: String, val session: String)
}

class LocalQBankApplication : android.app.Application() {
    override fun onCreate() {
        super.onCreate()
        StartupCoordinator.initialize(this)
        ResilienceManager.install(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) { ResilienceManager.activityStarted(this@LocalQBankApplication, activity) }
            override fun onActivityPaused(activity: Activity) { ResilienceManager.activityStopped(this@LocalQBankApplication, activity) }
            override fun onActivityCreated(a: Activity, b: android.os.Bundle?) = Unit
            override fun onActivityStarted(a: Activity) = Unit
            override fun onActivitySaveInstanceState(a: Activity, b: android.os.Bundle) = Unit
            override fun onActivityStopped(a: Activity) = Unit
            override fun onActivityDestroyed(a: Activity) = Unit
        })
    }
}
