package com.localqbank.library

import android.content.Context

enum class BenExamProfile(val label: String, val promptHint: String) {
    NEET_PG("NEET-PG", "Indian postgraduate medical entrance exam; emphasize high-yield concepts, common distractors and NEET-PG-style recall/application."),
    INI_CET("INI-CET", "INI-CET; emphasize integrated multi-system reasoning, image/PYQ interpretation and close distractors."),
    FMGE("FMGE", "FMGE; emphasize broad clinical coverage, core facts, practical clinical reasoning and common distractors."),
    GENERAL("General Medical", "General medical learning; explain clearly without assuming a specific entrance-exam pattern.")
}

private const val BEN_EXAM_PROFILE_PREFS = "ben_exam_profile"
private const val BEN_EXAM_PROFILE_KEY = "profile"

fun currentBenExamProfile(context: Context): BenExamProfile = runCatching {
    val raw=context.applicationContext.getSharedPreferences(BEN_EXAM_PROFILE_PREFS,Context.MODE_PRIVATE)
        .getString(BEN_EXAM_PROFILE_KEY,BenExamProfile.NEET_PG.name) ?: BenExamProfile.NEET_PG.name
    BenExamProfile.valueOf(raw)
}.getOrDefault(BenExamProfile.NEET_PG)

fun setBenExamProfile(context: Context, profile: BenExamProfile) {
    context.applicationContext.getSharedPreferences(BEN_EXAM_PROFILE_PREFS,Context.MODE_PRIVATE)
        .edit().putString(BEN_EXAM_PROFILE_KEY,profile.name).apply()
}

fun benExamPromptContext(context: Context): String {
    val profile=currentBenExamProfile(context)
    return "EXAM PROFILE: ${profile.label}\n${profile.promptHint}"
}
