package com.localqbank.library

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/**
 * Provider-neutral cloud text gateway. It is an accelerator only: deterministic Ben/RAG/verifier
 * remain authoritative. User-owned API keys are encrypted with Android Keystore and never logged.
 *
 * Current provider defaults are deliberately free-first:
 * OpenRouter free router -> Groq GPT-OSS 20B -> DeepSeek when the user supplies a key.
 * Proprietary model providers are intentionally kept outside this provider layer.
 */
class BenCloudAiGateway(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    enum class Provider(val id: String, val label: String, val endpoint: String, val defaultModel: String, val keyUrl: String) {
        OPENROUTER("openrouter", "OpenRouter • Free", "https://openrouter.ai/api/v1/chat/completions", "openrouter/free", "https://openrouter.ai/settings/keys"),
        GROQ("groq", "Groq • Free", "https://api.groq.com/openai/v1/chat/completions", "openai/gpt-oss-20b", "https://console.groq.com/keys"),
        DEEPSEEK("deepseek", "DeepSeek • Low-cost", "https://api.deepseek.com/chat/completions", "deepseek-flash", "https://platform.deepseek.com/api_keys")
    }

    data class Config(val provider: Provider, val enabled: Boolean, val model: String, val hasKey: Boolean)
    data class Result(val text: String, val provider: Provider, val model: String, val fallbackUsed: Boolean)

    fun configs(): List<Config> = Provider.values().map { p ->
        Config(p, prefs.getBoolean(enabledKey(p), false), prefs.getString(modelKey(p), p.defaultModel).orEmpty().ifBlank { p.defaultModel }, keyStore.get(p) != null)
    }

    fun setEnabled(provider: Provider, enabled: Boolean) { prefs.edit().putBoolean(enabledKey(provider), enabled).apply() }
    fun setModel(provider: Provider, model: String) { prefs.edit().putString(modelKey(provider), model.trim().ifBlank { provider.defaultModel }).apply() }
    fun saveKey(provider: Provider, key: String) { keyStore.put(provider, key.trim()) }
    fun clearKey(provider: Provider) { keyStore.remove(provider); setEnabled(provider, false) }
    fun keyUrl(provider: Provider): String = provider.keyUrl

    fun openKeyPage(context: Context, provider: Provider) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(provider.keyUrl)))
    }

    suspend fun generate(prompt: String, system: String = DEFAULT_SYSTEM, maxTokens: Int = 1200, timeoutMs: Long = 35_000L): Result? = withContext(Dispatchers.IO) {
        val ordered = configs().filter { it.enabled && it.hasKey }
        if (ordered.isEmpty()) return@withContext null
        var fallback = false
        for (cfg in ordered) {
            val key = keyStore.get(cfg.provider) ?: continue
            try {
                val text = withTimeout(timeoutMs) { call(cfg.provider, cfg.model, key, system, prompt, maxTokens) }
                return@withContext Result(text, cfg.provider, cfg.model, fallback)
            } catch (t: Throwable) {
                fallback = true
                Log.w(TAG, "Cloud provider ${cfg.provider.id} failed: ${t.message}")
            }
        }
        null
    }

    suspend fun test(provider: Provider): Result = withContext(Dispatchers.IO) {
        val cfg = configs().first { it.provider == provider }
        val key = keyStore.get(provider) ?: throw IllegalStateException("No API key saved for ${provider.label}.")
        val text = withTimeout(20_000L) { call(provider, cfg.model, key, "You are a connectivity test. Answer exactly: BEN CLOUD OK", "Connectivity test.", 24) }
        Result(text, provider, cfg.model, false)
    }

    private fun call(provider: Provider, model: String, apiKey: String, system: String, prompt: String, maxTokens: Int): String {
        val conn = (URL(provider.endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            if (provider == Provider.OPENROUTER) {
                setRequestProperty("HTTP-Referer", "https://github.com/Galactus1999/LocalQbank")
                setRequestProperty("X-Title", "Rovex")
                setRequestProperty("X-OpenRouter-Cache", "true")
            }
        }
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", system))
                put(JSONObject().put("role", "user").put("content", prompt))
            })
            put("max_tokens", maxTokens.coerceIn(64, 8192))
            put("temperature", 0.2)
        }.toString()
        conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = BufferedReader(InputStreamReader(stream ?: conn.inputStream, StandardCharsets.UTF_8)).use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("${provider.label} HTTP $code: ${extractError(raw)}")
        val json = JSONObject(raw)
        val choices = json.optJSONArray("choices") ?: throw IllegalStateException("${provider.label} returned no choices.")
        val message = choices.optJSONObject(0)?.optJSONObject("message")
        val text = message?.optString("content").orEmpty().trim()
        if (text.isBlank()) throw IllegalStateException("${provider.label} returned empty text.")
        return text
    }

    private fun extractError(raw: String): String = runCatching {
        val o = JSONObject(raw)
        o.optJSONObject("error")?.optString("message")?.ifBlank { raw.take(500) } ?: raw.take(500)
    }.getOrDefault(raw.take(500))

    private fun enabledKey(p: Provider) = "enabled_${p.id}"
    private fun modelKey(p: Provider) = "model_${p.id}"

    private val keyStore = SecretKeyStore(app)

    companion object {
        private const val TAG = "BenCloudAi"
        private const val PREFS = "ben_cloud_ai"
        private const val DEFAULT_SYSTEM = "You are a concise cloud reasoning collaborator inside Ben. Never override deterministic QBank truth. Distinguish uncertainty and avoid inventing medical evidence."
    }
}

/** Small Android Keystore-backed AES/GCM secret store for user-supplied provider API keys. */
private class SecretKeyStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("ben_cloud_secrets", Context.MODE_PRIVATE)
    private val alias = "RovexBenCloudKey"

    fun put(provider: BenCloudAiGateway.Provider, value: String) {
        if (value.isBlank()) return
        val iv = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(), GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        prefs.edit().putString(provider.id, Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)).apply()
    }

    fun get(provider: BenCloudAiGateway.Provider): String? = runCatching {
        val raw = prefs.getString(provider.id, null) ?: return@runCatching null
        val bytes = Base64.decode(raw, Base64.NO_WRAP)
        require(bytes.size > 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), StandardCharsets.UTF_8)
    }.getOrNull()

    fun remove(provider: BenCloudAiGateway.Provider) { prefs.edit().remove(provider.id).apply() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return generator.generateKey()
    }
}
