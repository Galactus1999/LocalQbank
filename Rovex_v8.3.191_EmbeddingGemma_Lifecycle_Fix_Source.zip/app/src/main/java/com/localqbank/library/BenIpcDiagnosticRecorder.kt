package com.localqbank.library

import android.content.Context
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

/**
 * Durable, bounded, model-independent Ben IPC diagnostic journal.
 *
 * IMPORTANT: the Ben worker runs in a separate normal application process. Android
 * SharedPreferences are not a safe cross-process transport, so the IPC trace uses
 * an append-only file journal in the shared application data directory. Critical
 * writes are forced to storage before returning. The journal therefore survives
 * Activity recreation and ordinary process death much better than an in-memory
 * or SharedPreferences-only trace.
 */
object BenIpcDiagnosticRecorder {
    private const val PREFS = "ben_ipc_diagnostic"
    private const val ACTIVE = "active"
    private const val ACTIVE_STARTED = "active_started"
    private const val ACTIVE_KIND = "active_kind"
    private const val MAX_CHARS = 14000
    private const val MAX_EVENT_CHARS = 500
    private const val RECOVERY_STALE_MS = 180_000L
    private const val JOURNAL_NAME = "ben_ipc_diagnostic.journal"
    private const val ACTIVE_FILE_NAME = "ben_ipc_diagnostic.active"
    private const val TERMINAL_MARKER = "|TEST_TERMINAL|"
    private val sequence = AtomicLong(0)

    private fun journal(context: Context) = File(context.applicationContext.filesDir, JOURNAL_NAME)
    private fun activeFile(context: Context) = File(context.applicationContext.filesDir, ACTIVE_FILE_NAME)

    @Synchronized
    fun start(context: Context, kind: String = "IPC"): String {
        val app = context.applicationContext
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val journal = journal(app)
        // A diagnostic run is single-flight. Replace an old stale run only after preserving it.
        recoverStale(app)
        journal.parentFile?.mkdirs()
        FileOutputStream(journal, false).use { it.channel.use { ch -> ch.force(true) } }
        writeAtomic(activeFile(app), "$id|$now|${kind.take(32)}")
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ACTIVE, id)
            .putLong(ACTIVE_STARTED, now)
            .putString(ACTIVE_KIND, kind.take(32))
            .commit()
        event(app, id, "TEST_START", "version=${Build.VERSION.RELEASE} sdk=${Build.VERSION.SDK_INT} device=${Build.MODEL}")
        return id
    }

    @Synchronized
    fun event(context: Context, testId: String?, stage: String, detail: String = "") {
        val app = context.applicationContext
        val id = testId ?: activeId(app) ?: return
        if (id == "NO_TEST") return
        val line = "${System.currentTimeMillis()}|${sequence.incrementAndGet()}|$id|$stage|${detail.replace("\n", " ").take(MAX_EVENT_CHARS)}\n"
        appendForced(journal(app), line)
        // Keep a lightweight compatibility marker for existing telemetry/UI code.
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ACTIVE, id)
            .commit()
    }

    @Synchronized
    fun finish(context: Context, testId: String?, result: String, reason: String? = null): String {
        val app = context.applicationContext
        val id = testId ?: activeId(app)
        event(app, id, "TEST_TERMINAL", "result=$result reason=${reason?.take(400).orEmpty()}")
        val report = buildReport(app, id, result, reason, activeKind(app))
        RovexDiagnosticsStore.publishIpc(app, report)
        clearActive(app)
        return report
    }

    /**
     * Called whenever the diagnostics UI opens. If the previous run disappeared before
     * it could execute finish(), convert the surviving journal into an explicit report.
     */
    @Synchronized
    fun recoverStale(context: Context): String? {
        val app = context.applicationContext
        val id = activeId(app) ?: return null
        val journalText = readBounded(journal(app))
        if (journalText.isBlank()) {
            clearActive(app)
            return null
        }
        val terminalLine = journalText.lineSequence().lastOrNull { it.contains(TERMINAL_MARKER) }
        if (terminalLine != null) {
            val result = terminalLine.substringAfter("result=").substringBefore(" reason=").ifBlank { "RECOVERED" }
            val reason = terminalLine.substringAfter(" reason=", "").takeIf { it.isNotBlank() }
            val report = buildReport(app, id, result, reason, activeKind(app))
            RovexDiagnosticsStore.publishIpc(app, report)
            clearActive(app)
            return report
        }
        val lastTimestamp = journalText.lineSequence().lastOrNull { it.isNotBlank() }
            ?.substringBefore('|')?.toLongOrNull() ?: 0L
        if (lastTimestamp > 0L && System.currentTimeMillis() - lastTimestamp < RECOVERY_STALE_MS) return null
        val report = buildReport(app, id, "INTERRUPTED", "IPC_DIAGNOSTIC_PROCESS_OR_ACTIVITY_INTERRUPTED")
        RovexDiagnosticsStore.publishIpc(app, report)
        clearActive(app)
        return report
    }

    fun latest(context: Context): String? =
        RovexDiagnosticsStore.latestIpc(context) ?: recoverStale(context)

    fun current(context: Context): String? = readBounded(journal(context.applicationContext)).takeIf { it.isNotBlank() }

    fun isRunning(context: Context): Boolean = activeId(context.applicationContext) != null

    private fun buildReport(context: Context, testId: String?, result: String, reason: String?, kind: String?): String {
        val app = context.applicationContext
        val trace = readBounded(journal(app))
        return buildString {
            if (kind.equals("EMBEDDINGGEMMA", true)) {
                appendLine("BEN EMBEDDINGGEMMA ISOLATED DIAGNOSTIC REPORT")
                appendLine("===========================================")
            } else {
                appendLine("BEN IPC DIAGNOSTIC REPORT")
                appendLine("=========================")
            }
            appendLine("testId=${testId ?: "unknown"}")
            appendLine("result=$result")
            if (kind.equals("EMBEDDINGGEMMA", true)) {
                appendLine("modelsRequired=true")
                appendLine("modelsLoaded=unknown (real model/runtime diagnostic)")
            } else {
                appendLine("modelsRequired=false")
                appendLine("modelsLoaded=false (transport/lifecycle diagnostic)")
            }
            if (!reason.isNullOrBlank()) appendLine("failure=${reason.take(500)}")
            appendLine("device=${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("sdk=${Build.VERSION.SDK_INT}")
            appendLine()
            appendLine("EVENT TRACE (oldest → newest)")
            append(trace)
        }.take(MAX_CHARS)
    }

    private fun activeId(context: Context): String? {
        val file = activeFile(context)
        val raw = runCatching { file.readText(StandardCharsets.UTF_8) }.getOrNull().orEmpty()
        return raw.substringBefore('|').takeIf { it.isNotBlank() && it != "NO_TEST" }
            ?: context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ACTIVE, null)
                ?.takeIf { it.isNotBlank() && it != "NO_TEST" }
    }

    private fun activeKind(context: Context): String? {
        val app = context.applicationContext
        val raw = runCatching { activeFile(app).readText(StandardCharsets.UTF_8) }.getOrNull().orEmpty()
        val fileKind = raw.split('|').getOrNull(2)?.takeIf { it.isNotBlank() }
        return fileKind ?: app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ACTIVE_KIND, "IPC")
    }

    private fun clearActive(context: Context) {
        activeFile(context).delete()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(ACTIVE).remove(ACTIVE_STARTED).remove(ACTIVE_KIND).commit()
    }

    private fun appendForced(file: File, text: String) {
        file.parentFile?.mkdirs()
        RandomAccessFile(file, "rw").use { raf ->
            raf.channel.lock().use {
                raf.seek(raf.length())
                raf.write(text.toByteArray(StandardCharsets.UTF_8))
                if (raf.length() > MAX_CHARS * 2L) {
                    raf.seek(maxOf(0L, raf.length() - MAX_CHARS))
                    val tail = ByteArray(minOf(MAX_CHARS.toLong(), raf.length()).toInt())
                    raf.readFully(tail)
                    raf.setLength(0L)
                    raf.seek(0L)
                    raf.write(tail)
                }
                raf.fd.sync()
            }
        }
    }

    private fun readBounded(file: File): String = runCatching {
        if (!file.exists()) return ""
        val bytes = file.readBytes()
        val start = maxOf(0, bytes.size - MAX_CHARS * 2)
        String(bytes, start, bytes.size - start, StandardCharsets.UTF_8).takeLast(MAX_CHARS)
    }.getOrDefault("")

    private fun writeAtomic(file: File, text: String) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        FileOutputStream(tmp, false).use { out ->
            out.write(text.toByteArray(StandardCharsets.UTF_8)); out.flush(); out.fd.sync()
        }
        if (!tmp.renameTo(file)) {
            file.writeText(text, StandardCharsets.UTF_8)
            tmp.delete()
        }
    }
}
