# Rovex v8.3.417 — AI Chat Streaming Lambda Closure Repair

## CI evidence
The v8.3.416 CI run reached `:app:compileDebugKotlin` and failed in
`BenQuestionAiContextDialog.kt` at line 319 with `Syntax error: Expecting an element`,
followed by cascading unresolved references (`result`, `catch`, helpers, etc.).

## Root cause
The `onChunk = { delta -> ... }` lambda of the primary BEN + AI
`generateStreaming(...)` call was not closed before the call's `)`.
The previous repair restored the call close but omitted the lambda close.

## Repair
Added the missing `}` immediately before the `)` that closes
`generateStreaming(...)`.

## Scope
No streaming architecture, provider behavior, renderer, cancellation, or UI logic was
changed. This is a syntax-only correction intended to remove the compiler cascade.

## Verification
- Source ZIP integrity: checked after packaging.
- Android compilation: pending GitHub Actions verification.
- JVM tests: pending GitHub Actions verification.
- Device/runtime: pending a successful release build.
