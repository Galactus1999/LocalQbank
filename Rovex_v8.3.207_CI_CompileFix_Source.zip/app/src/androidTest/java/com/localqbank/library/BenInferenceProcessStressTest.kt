package com.localqbank.library

import android.app.ActivityManager
import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Phase-2 device stress coverage for the already-green Ben IPC architecture.
 *
 * This test is intentionally test-only: the production IPC/diagnostic implementation is not
 * modified by the stress harness. Run on the OnePlus SM8650/CPH2691 device.
 */
@RunWith(AndroidJUnit4::class)
class BenInferenceProcessStressTest {
    private val context: Context
        get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun repeatedWarmEmbeddingRequestsRemainStable() = runBlocking {
        BenInferenceProcessClient(context).use { client ->
            // Prime the worker/model once; subsequent calls measure the warm path.
            val prime = timedCompare(client)
            assertTrue("Prime compare failed", prime.score != null)

            val samples = mutableListOf<Long>()
            repeat(10) { index ->
                val result = timedCompare(client)
                assertNotNull("Warm compare #${index + 1} returned null", result.score)
                assertTrue("Warm compare #${index + 1} produced invalid score", result.score!!.isFinite())
                samples += result.elapsedMs
            }

            val median = samples.sorted()[samples.size / 2]
            val max = samples.maxOrNull() ?: Long.MAX_VALUE
            android.util.Log.i("BenPhase2", "WARM_10 samplesMs=$samples medianMs=$median maxMs=$max")
            // This is a stability test, not a hard performance benchmark. Flag only pathological
            // stalls that would violate the intended foreground-study safety envelope.
            assertTrue("Warm inference pathological stall: ${max}ms", max < 15_000L)
        }
    }

    @Test
    fun rapidLatestRequestWinsStillTerminalizesSupersededFlow() = runBlocking {
        BenInferenceProcessClient(context).use { client ->
            val firstEvents = mutableListOf<BenInferenceProcessClient.GenerationEvent>()
            val secondEvents = mutableListOf<BenInferenceProcessClient.GenerationEvent>()

            val first = launch {
                withTimeout(15_000L) {
                    client.generateStream("Request A: explain acute kidney injury briefly.", 64)
                        .collect { firstEvents += it }
                }
            }
            delay(80L)
            val second = launch {
                withTimeout(15_000L) {
                    client.generateStream("Request B: answer with one short sentence.", 64)
                        .collect { secondEvents += it }
                }
            }
            withTimeout(20_000L) {
                first.join()
                second.join()
            }

            val firstTerminal = firstEvents.count { it.isTerminal() }
            val secondTerminal = secondEvents.count { it.isTerminal() }
            assertTrue("Superseded request A produced no terminal event: $firstEvents", firstTerminal == 1)
            assertTrue("Latest request B produced no terminal event: $secondEvents", secondTerminal == 1)
            android.util.Log.i("BenPhase2", "LATEST_WINS first=$firstEvents second=$secondEvents")
        }
    }

    @Test
    fun cancellationDuringGenerationReleasesRemoteRequest() = runBlocking {
        BenInferenceProcessClient(context).use { client ->
            val job = launch {
                client.generateStream(
                    "Write a medically detailed explanation of renal physiology and keep generating until asked to stop.",
                    192,
                ).collect { }
            }
            delay(250L)
            job.cancel()
            withTimeout(5_000L) { job.join() }

            // The next native request must not be blocked behind the cancelled session.
            val next = timedCompare(client)
            assertNotNull("Native request remained blocked after cancellation", next.score)
            assertTrue("Post-cancellation inference score invalid", next.score!!.isFinite())
        }
    }

    @Test
    fun workerProcessDeathIsRecoveredWithoutStaleGeneration() = runBlocking {
        BenInferenceProcessClient(context).use { client ->
            val before = client.pingSuspend(10_000L)
            assertTrue("Initial Binder ping failed: ${before.failure}", before.ok)

            val prime = timedCompare(client)
            assertNotNull("Could not prime inference worker", prime.score)
            delay(150L)

            val pid = findInferenceWorkerPid()
            assertNotNull("Could not locate :inference_process PID", pid)
            killPid(pid!!)
            delay(800L)

            // Rebinding must establish a new service generation and answer a fresh request.
            val recovered = client.pingSuspend(15_000L)
            assertTrue("Binder did not recover after worker death: ${recovered.failure}", recovered.ok)
            val after = timedCompare(client)
            assertNotNull("Inference did not recover after worker death", after.score)
            assertTrue("Recovered inference score invalid", after.score!!.isFinite())
            android.util.Log.i("BenPhase2", "PROCESS_DEATH pid=$pid recovered=true")
        }
    }

    @Test
    fun repeatedTrimAndRebindLeavesTransportHealthy() = runBlocking {
        repeat(6) { index ->
            BenInferenceProcessClient(context).use { client ->
                val ping = client.pingSuspend(10_000L)
                assertTrue("Cycle ${index + 1} initial ping failed: ${ping.failure}", ping.ok)
                client.trim()
                delay(150L)
                val rebound = client.pingSuspend(10_000L)
                assertTrue("Cycle ${index + 1} rebound ping failed: ${rebound.failure}", rebound.ok)
            }
        }
    }

    private fun BenInferenceProcessClient.GenerationEvent.isTerminal(): Boolean = when (this) {
        is BenInferenceProcessClient.GenerationEvent.Complete,
        is BenInferenceProcessClient.GenerationEvent.Failed,
        BenInferenceProcessClient.GenerationEvent.Cancelled,
        BenInferenceProcessClient.GenerationEvent.ProcessDied -> true
        is BenInferenceProcessClient.GenerationEvent.Token -> false
    }

    private data class TimedCompare(val score: Double?, val elapsedMs: Long)

    private suspend fun timedCompare(client: BenInferenceProcessClient): TimedCompare {
        val start = System.nanoTime()
        val score = client.compareSuspend(
            "acute kidney injury causes and diagnosis",
            "Acute kidney injury is assessed with serum creatinine, urine output, and clinical context.",
        )
        val elapsed = (System.nanoTime() - start) / 1_000_000L
        return TimedCompare(score, elapsed)
    }

    private fun findInferenceWorkerPid(): Int? {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val fromAm = am.runningAppProcesses.orEmpty()
            .firstOrNull { it.processName == "${context.packageName}:inference_process" }
            ?.pid
        if (fromAm != null && fromAm > 0) return fromAm

        return runCatching {
            val fd = InstrumentationRegistry.getInstrumentation().uiAutomation
                .executeShellCommand("pidof ${context.packageName}:inference_process")
            BufferedReader(InputStreamReader(android.os.ParcelFileDescriptor.AutoCloseInputStream(fd)))
                .readLine()
                ?.trim()
                ?.split(Regex("\\s+"))
                ?.firstOrNull()
                ?.toIntOrNull()
        }.getOrNull()
    }

    private fun killPid(pid: Int) {
        val fd = InstrumentationRegistry.getInstrumentation().uiAutomation
            .executeShellCommand("kill -9 $pid")
        android.os.ParcelFileDescriptor.AutoCloseInputStream(fd).use { it.readBytes() }
    }
}
