package com.localqbank.library

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Bridges Ben to a real LLM using the user's own API key (Anthropic or OpenAI-compatible).
 * This is what turns Ben from a fixed rule engine into something that actually reasons:
 * BenBrain builds a grounded context block (current question, local QBank hits, web results,
 * weak-area signal) and hands it here as a system prompt alongside the chat history.
 *
 * Every call is a single bounded HTTPS request; nothing is stored remotely by this app.
 */
object BenLLMClient {
    data class ChatTurn(val role: String, val content: String)

    private const val CONNECT_TIMEOUT_MS = 12_000
    private const val READ_TIMEOUT_MS = 35_000
    private const val MAX_RESPONSE_CHARS = 200_000

    fun complete(
        context: Context,
        systemPrompt: String,
        history: List<ChatTurn>,
        maxTokens: Int = 900
    ): Result<String> {
        val apiKey = BenSettings.apiKey(context)
        if (apiKey.isBlank()) return Result.failure(IllegalStateException("No API key configured"))
        if (history.isEmpty()) return Result.failure(IllegalStateException("No message to send"))
        val model = BenSettings.model(context)
        val provider = BenSettings.provider(context)
        return try {
            val text = when (provider) {
                BenSettings.Provider.ANTHROPIC -> callAnthropic(apiKey, model, systemPrompt, history, maxTokens)
                BenSettings.Provider.OPENAI -> callOpenAI(apiKey, model, systemPrompt, history, maxTokens)
            }
            if (text.isBlank()) Result.failure(IllegalStateException("Empty model response"))
            else Result.success(text)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    private fun callAnthropic(
        apiKey: String, model: String, system: String, history: List<ChatTurn>, maxTokens: Int
    ): String {
        val conn = openConnection("https://api.anthropic.com/v1/messages") {
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        val messages = JSONArray()
        history.forEach { t ->
            val role = if (t.role == "assistant") "assistant" else "user"
            messages.put(JSONObject().put("role", role).put("content", t.content))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("system", system)
            .put("messages", messages)
        val respText = send(conn, body)
        val json = JSONObject(respText)
        val content = json.optJSONArray("content") ?: JSONArray()
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.optJSONObject(i) ?: continue
            if (block.optString("type") == "text") sb.append(block.optString("text"))
        }
        return sb.toString().trim()
    }

    private fun callOpenAI(
        apiKey: String, model: String, system: String, history: List<ChatTurn>, maxTokens: Int
    ): String {
        val conn = openConnection("https://api.openai.com/v1/chat/completions") {
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", system))
        history.forEach { t ->
            val role = if (t.role == "assistant") "assistant" else "user"
            messages.put(JSONObject().put("role", role).put("content", t.content))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", maxTokens)
            .put("messages", messages)
        val respText = send(conn, body)
        val json = JSONObject(respText)
        val choices = json.optJSONArray("choices") ?: JSONArray()
        val first = choices.optJSONObject(0) ?: return ""
        return first.optJSONObject("message")?.optString("content")?.trim() ?: ""
    }

    private fun openConnection(url: String, extraHeaders: HttpURLConnection.() -> Unit): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            doOutput = true
            instanceFollowRedirects = false
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            extraHeaders()
        }
    }

    private fun send(conn: HttpURLConnection, body: JSONObject): String {
        return try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = readBounded(stream, MAX_RESPONSE_CHARS)
            if (code !in 200..299) {
                val reason = runCatching { JSONObject(text).optJSONObject("error")?.optString("message") }
                    .getOrNull()?.takeIf { it.isNotBlank() } ?: text.take(200)
                throw IllegalStateException("API error $code: $reason")
            }
            text
        } finally {
            conn.disconnect()
        }
    }

    /** Reads a bounded response so a malformed/huge reply can't consume unbounded RAM. */
    private fun readBounded(stream: InputStream?, maxChars: Int): String {
        if (stream == null) return ""
        val limit = maxChars.coerceIn(32_000, 500_000)
        val reader = BufferedReader(InputStreamReader(stream, Charsets.UTF_8), 16 * 1024)
        val out = StringBuilder(minOf(limit, 64 * 1024))
        val buf = CharArray(16 * 1024)
        while (out.length < limit) {
            val remaining = limit - out.length
            val read = reader.read(buf, 0, minOf(buf.size, remaining))
            if (read < 0) break
            out.append(buf, 0, read)
        }
        return out.toString()
    }
}
