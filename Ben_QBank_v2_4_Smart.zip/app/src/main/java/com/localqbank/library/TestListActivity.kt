package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TestListActivity:AppCompatActivity(){
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    private var sourceId=0L
    override fun onCreate(b:Bundle?){
        super.onCreate(b);SystemUi.immersive(this);setContentView(makeRoot());db=QBankDb(this);store=ProgressStore(this);sourceId=intent.getLongExtra("sourceId",0)
        BenCompanion.attach(this,"Sections")
        findViewById<TextView>(1001).text=intent.getStringExtra("sourceName")?:"Sections"
        findViewById<RecyclerView>(1002).apply{
            layoutManager=LinearLayoutManager(this@TestListActivity);setHasFixedSize(false);itemAnimator=null
            adapter=TestAdapter(db.tests(sourceId),db,store){t,pos,practice->
                if (t.id.isNotBlank() && db.testById(t.id) != null) {
                    startActivity(Intent(this@TestListActivity,QuizActivity::class.java)
                        .putExtra("testId",t.id).putExtra("title",t.title).putExtra("position",pos)
                        .putExtra("practiceMode",practice))
                }
            }
        }
    }
    override fun onResume(){super.onResume();if(::db.isInitialized)(findViewById<RecyclerView>(1002).adapter as? TestAdapter)?.refresh()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun makeRoot():LinearLayout{
        val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setBackgroundColor(ThemeManager.bg(this))
        val bar=LinearLayout(this);SystemUi.padTopInset(bar,10,10,18,18);bar.setBackgroundColor(Color.rgb(26,70,99))
        val back=TextView(this);back.text="←";back.textSize=23f;back.setTextColor(Color.WHITE);back.gravity=Gravity.CENTER
        back.background=GradientDrawable().apply{setColor(if(ThemeManager.get(this@TestListActivity)==ThemeManager.DARK) Color.rgb(31,43,58) else Color.rgb(28,70,103));cornerRadius=12f*resources.displayMetrics.density};back.setOnClickListener{finish()}
        bar.addView(back,LinearLayout.LayoutParams(dp(56),dp(56)).apply{setMargins(0,0,dp(8),0)})
        val tv=TextView(this);tv.id=1001;tv.setTextColor(Color.WHITE);tv.textSize=19f;tv.setTypeface(null,1);tv.maxLines=2;tv.ellipsize=android.text.TextUtils.TruncateAt.END
        bar.addView(tv,LinearLayout.LayoutParams(0,-2,1f));root.addView(bar)
        val rv=RecyclerView(this);rv.id=1002;rv.setPadding(14,8,14,20);rv.clipToPadding=false;rv.isNestedScrollingEnabled=true;root.addView(rv,LinearLayout.LayoutParams(-1,0,1f));return root
    }
}

class TestAdapter(private val items:List<Test>,private val db:QBankDb,private val store:ProgressStore,private val click:(Test,Int,Boolean)->Unit):RecyclerView.Adapter<TestAdapter.VH>(){
    private val cache=HashMap<String,ProgressSummary>()
    class VH(v:LinearLayout):RecyclerView.ViewHolder(v){
        val t=TextView(v.context);val s=TextView(v.context);val actions=LinearLayout(v.context);val resume=TextView(v.context);val practice=TextView(v.context)
        init{
            v.orientation=LinearLayout.HORIZONTAL;v.setPadding(16,12,12,12)
            val body=LinearLayout(v.context).apply{orientation=LinearLayout.VERTICAL}
            t.textSize=16f;t.setTextColor(ThemeManager.text(v.context));t.setTypeface(null,1);t.maxLines=2;t.ellipsize=android.text.TextUtils.TruncateAt.END
            s.textSize=12f;s.setTextColor(ThemeManager.muted(v.context));s.setPadding(0,6,0,0);body.addView(t);body.addView(s)
            v.addView(body,LinearLayout.LayoutParams(0,-2,1f))
            actions.orientation=LinearLayout.VERTICAL;actions.gravity=Gravity.CENTER_HORIZONTAL
            fun style(b:TextView,label:String){b.text=label;b.textSize=10.5f;b.setTypeface(null,1);b.gravity=Gravity.CENTER;b.setPadding(8,0,8,0);b.minHeight=dp(v.context,38);b.background=GradientDrawable().apply{setColor(if(ThemeManager.get(v.context)==ThemeManager.DARK) Color.rgb(24,52,72) else Color.rgb(225,243,246));cornerRadius=11f*v.resources.displayMetrics.density}}
            style(resume,"RESUME");style(practice,"SOLVE AGAIN")
            actions.addView(resume,LinearLayout.LayoutParams(92,38));actions.addView(practice,LinearLayout.LayoutParams(92,38).apply{setMargins(0,6,0,0)})
            v.addView(actions,LinearLayout.LayoutParams(92,-2).apply{gravity=Gravity.CENTER_VERTICAL;setMargins(8,0,0,0)})
        }
        companion object{private fun dp(c:android.content.Context,v:Int)=(v*c.resources.displayMetrics.density).toInt()}
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{val v=LinearLayout(p.context);v.layoutParams=RecyclerView.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)};return VH(v)}
    override fun onBindViewHolder(h:VH,i:Int){
        val x=items[i];val pr=cache.getOrPut(x.id){db.progressSummaryForTest(x.id,store)};h.t.text=x.title;h.t.setTextColor(ThemeManager.text(h.itemView.context));h.s.setTextColor(ThemeManager.muted(h.itemView.context));val timing=if(x.duration>0)"  •  ${x.duration/60} min" else ""
        h.s.text=when{pr.total==0->"No questions";pr.solved>=pr.total->"✓ Completed  •  ${pr.solved}/${pr.total} solved$timing";pr.solved==0->"Not started  •  ${pr.total} questions$timing";else->"↻ In progress  •  ${pr.solved}/${pr.total} solved$timing"}
        val resumePos=if(pr.solved>0)store.position(x.id) else pr.resumePosition
        h.resume.visibility=if(pr.total>0)View.VISIBLE else View.GONE
        h.practice.visibility=if(pr.total>0)View.VISIBLE else View.GONE
        h.resume.setOnClickListener{click(x,resumePos,false)}
        h.practice.setOnClickListener{click(x,0,true)}
        h.itemView.setOnClickListener{click(x,resumePos,false)}
        val bg=if(ThemeManager.get(h.itemView.context)==ThemeManager.DARK) Color.rgb(24,32,42) else when(i%5){0->Color.rgb(235,245,255);1->Color.rgb(238,249,242);2->Color.rgb(255,245,228);3->Color.rgb(246,239,255);else->Color.rgb(255,237,241)}
        h.itemView.background=GradientDrawable().apply{setColor(bg);cornerRadius=18f*h.itemView.context.resources.displayMetrics.density}
    }
    fun refresh(){cache.clear();notifyDataSetChanged()}
    override fun getItemCount()=items.size
}
