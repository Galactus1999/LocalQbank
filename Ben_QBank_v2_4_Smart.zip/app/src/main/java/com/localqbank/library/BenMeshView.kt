package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class BenMeshView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private var nodes: List<BenAgentStore.Node> = emptyList()
    private var edges: List<BenAgentStore.Edge> = emptyList()
    private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private var selected: BenAgentStore.Node? = null
    private val points = mutableMapOf<String, PointF>()

    fun submit(nodes: List<BenAgentStore.Node>, edges: List<BenAgentStore.Edge>) { this.nodes = nodes; this.edges = edges; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.TRANSPARENT)
        if (nodes.isEmpty()) {
            textPaint.textSize = 16f; textPaint.color = Color.rgb(90,105,120); canvas.drawText("Ben is building his first mesh…", width/2f, height/2f, textPaint); return
        }
        points.clear()
        val cx = width/2f; val cy = height/2f; val radius = min(width,height)*0.34f
        nodes.forEachIndexed { i,n ->
            val angle = -PI/2 + i * 2*PI / nodes.size
            points[n.key] = PointF(cx + cos(angle).toFloat()*radius, cy + sin(angle).toFloat()*radius)
        }
        edgePaint.color = Color.argb(75,55,100,120)
        edges.forEach { e -> val a=points[e.from]; val b=points[e.to]; if(a!=null && b!=null){ edgePaint.strokeWidth=(1f+e.strength.toFloat()*3f).coerceAtMost(4f); canvas.drawLine(a.x,a.y,b.x,b.y,edgePaint) } }
        nodePaint.style = Paint.Style.FILL
        nodes.forEach { n ->
            val p=points[n.key] ?: return@forEach
            val r=(10f + n.weight.toFloat()*1.4f).coerceIn(10f,22f)
            nodePaint.color = if (n.confidence < .55) Color.rgb(218,112,73) else Color.rgb(52,125,143)
            canvas.drawCircle(p.x,p.y,r,nodePaint)
            if(selected?.key==n.key){ nodePaint.style=Paint.Style.STROKE; nodePaint.strokeWidth=3f; nodePaint.color=Color.rgb(105,190,235); canvas.drawCircle(p.x,p.y,r+5,nodePaint); nodePaint.style=Paint.Style.FILL }
            textPaint.textSize = 11f; textPaint.color = Color.rgb(205,220,232)
            val label=if(n.label.length>18)n.label.take(17)+"…" else n.label
            canvas.drawText(label,p.x,p.y+r+16,textPaint)
        }
        nodePaint.color=Color.rgb(18,48,79); canvas.drawCircle(cx,cy,25f,nodePaint)
        textPaint.textSize=12f; textPaint.color=Color.WHITE; canvas.drawText("BEN",cx,cy+4,textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if(event.action!=MotionEvent.ACTION_UP) return true
        var best: BenAgentStore.Node?=null; var d=Float.MAX_VALUE
        nodes.forEach { n -> val p=points[n.key] ?: return@forEach; val dd=hypot(event.x-p.x,event.y-p.y); if(dd<d){d=dd;best=n} }
        if(d<45f){selected=best; invalidate(); performClick();}
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
