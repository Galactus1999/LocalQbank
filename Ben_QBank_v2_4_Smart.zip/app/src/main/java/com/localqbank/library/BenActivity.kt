package com.localqbank.library

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

class BenActivity : AppCompatActivity() {
    private lateinit var store: BenAgentStore
    private lateinit var mesh: BenMeshView
    private lateinit var status: TextView
    private lateinit var face: BenFaceView
    private lateinit var prompt: TextView
    private val executor=Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store=BenAgentStore(this)
        setContentView(build())
        refreshMesh()
    }

    override fun onDestroy(){
        executor.shutdownNow()
        if(::store.isInitialized)store.shutdown()
        super.onDestroy()
    }

    private fun panel(color:Int, radius:Float=18f)=android.graphics.drawable.GradientDrawable().apply{
        setColor(color); cornerRadius=radius*resources.displayMetrics.density
        setStroke((1*resources.displayMetrics.density).toInt(),Color.rgb(39,61,80))
    }

    private fun build(): LinearLayout {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(10),dp(16),dp(16));setBackgroundColor(Color.rgb(4,9,15))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(ImageView(this).apply{setImageResource(R.drawable.ic_ben_cosmic);contentDescription="Ben cosmic logo"},LinearLayout.LayoutParams(dp(44),dp(44)))
        val name=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        name.addView(TextView(this).apply{text="BEN";textSize=25f;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD);letterSpacing=.08f})
        status=TextView(this).apply{text=statusLine();textSize=11f;setTextColor(Color.rgb(72,181,255));setPadding(0,dp(1),0,0)}
        name.addView(status);top.addView(name,LinearLayout.LayoutParams(0,-2,1f))
        top.addView(TextView(this).apply{text="⋮";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setOnClickListener{showMenu()}},LinearLayout.LayoutParams(dp(42),dp(48)))
        root.addView(top)

        face=BenFaceView(this).apply{setMode(BenFaceView.Mode.IDLE);contentDescription="Ben robotic avatar"}
        val faceWrap=FrameLayout(this).apply{addView(face,FrameLayout.LayoutParams(-1,dp(170)));background=panel(Color.rgb(7,15,24),22f)}
        root.addView(faceWrap,LinearLayout.LayoutParams(-1,dp(180)).apply{setMargins(0,dp(10),0,dp(10))})

        val greeting=TextView(this).apply{
            text="I’m Ben. I can reason across your QBank, learn from your performance and help you decide what to do next.\n\nAsk me anything—or tap a command below."
            textSize=15f;setTextColor(Color.rgb(224,236,245));setLineSpacing(0f,1.15f);setPadding(dp(14),dp(12),dp(14),dp(12));background=panel(Color.rgb(10,22,34),16f)
        }
        root.addView(greeting)

        val quick=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f}
        fun qButton(text:String, action:()->Unit){quick.addView(Button(this).apply{this.text=text;isAllCaps=false;textSize=11f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(15,69,104));setOnClickListener{action()}},LinearLayout.LayoutParams(0,dp(52),1f).apply{setMargins(dp(2),dp(8),dp(2),dp(2))})}
        qButton("Explain",::showAsk);qButton("Quiz me",::showAsk);qButton("My weak areas",::showAsk)
        root.addView(quick)

        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=panel(Color.rgb(7,16,26),18f)}
        card.addView(TextView(this).apply{text="LIVE KNOWLEDGE MESH";textSize=12f;typeface=android.graphics.Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(91,190,255));letterSpacing=.08f})
        prompt=TextView(this).apply{text="Building Ben’s map…";textSize=12f;setTextColor(Color.rgb(150,174,191));setPadding(0,dp(5),0,dp(7))};card.addView(prompt)
        mesh=BenMeshView(this); card.addView(mesh,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(card,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,dp(10),0,dp(10))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val ask=Button(this).apply{text="Talk to Ben";isAllCaps=false;textSize=14f;setOnClickListener{showAsk()}}
        val study=Button(this).apply{text="Study with Ben";isAllCaps=false;textSize=14f;setOnClickListener{startActivity(Intent(this@BenActivity,StudyToolsActivity::class.java))}}
        actions.addView(ask,LinearLayout.LayoutParams(0,dp(54),1f).apply{setMargins(0,0,dp(4),0)});actions.addView(study,LinearLayout.LayoutParams(0,dp(54),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        return root
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    private fun statusLine(): String = if (BenSettings.isActive(this)) "ONLINE • AI REASONING • INTERNET-AWARE" else "ONLINE • LOCAL BRAIN • RESOURCE AWARE"

    private fun refreshMesh(){
        executor.execute {
            runCatching {
                runOnUiThread{if(!isFinishing&&!isDestroyed){face.setMode(BenFaceView.Mode.THINKING);prompt.text="Ben is analysing your local study state…"}}
                BenAgentEngine.run(applicationContext)
                val nodes=store.nodes(); val edges=store.edges(); val weak=store.weakCount(); val events=store.eventCount()
                runOnUiThread{if(!isFinishing&&!isDestroyed){mesh.submit(nodes,edges);face.setMode(BenFaceView.Mode.FOCUSED);prompt.text="${nodes.size} active nodes • $weak weak areas • $events learned events";status.text="ONLINE • LEARNING STATE UPDATED"}}
            }.onFailure{runOnUiThread{if(!isFinishing&&!isDestroyed){face.setMode(BenFaceView.Mode.ALERT);status.text="SAFE PAUSE";prompt.text="Ben paused to protect the device: ${it.message ?: "temporary error"}"}}}
        }
    }

    private fun showAsk(){
        val d=resources.displayMetrics.density
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(5),dp(10),dp(8));setBackgroundColor(Color.rgb(4,11,18))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(BenFaceView(this).apply{setMode(BenFaceView.Mode.FOCUSED)},LinearLayout.LayoutParams(dp(86),dp(86)))
        top.addView(TextView(this).apply{text="I'm Ben. Talk naturally. I can use your QBank and learning state, and I can search the internet when the question needs fresh evidence.";textSize=14f;setTextColor(Color.WHITE);setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        root.addView(top)
        val history=TextView(this).apply{text="Ben: Ready. Ask me anything.";textSize=14.5f;setTextColor(Color.rgb(238,245,250));setPadding(0,dp(8),0,dp(8));autoLinkMask=android.text.util.Linkify.WEB_URLS;linksClickable=true}
        val historyScroll=ScrollView(this).apply{addView(history);isFillViewport=true}
        root.addView(historyScroll,LinearLayout.LayoutParams(-1,dp(240)))
        val inputRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.BOTTOM}
        val input=EditText(this).apply{hint="Talk to Ben…";setHintTextColor(Color.rgb(165,190,205));setTextColor(Color.WHITE);setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65,165,220)));minLines=2;maxLines=5;textSize=16f;imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEND;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE}
        val send=Button(this).apply{text="SEND";isAllCaps=false;textSize=12f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(18,104,160));minWidth=dp(82);minHeight=dp(52)}
        inputRow.addView(input,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(0,dp(6),dp(6),0)});inputRow.addView(send,LinearLayout.LayoutParams(dp(82),dp(52)));root.addView(inputRow)
        val quick=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        listOf("Explain this","Exam trap","Quiz me","Web research").forEach{t->quick.addView(Button(this).apply{text=t;isAllCaps=false;textSize=10.5f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(12,57,86));setOnClickListener{sendBenMessage(historyScroll,history,input,t)}},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),dp(5),dp(2),0)})}
        root.addView(quick)
        val titleView=TextView(this).apply{text="Talk to Ben";textSize=18f;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.DEFAULT_BOLD;setPadding(dp(20),dp(16),dp(20),dp(8))}
        val dialog=AlertDialog.Builder(this).setCustomTitle(titleView).setView(root).setNegativeButton("Close",null).create()
        send.setOnClickListener{sendBenMessage(historyScroll,history,input,input.text.toString())}
        input.setOnEditorActionListener{_,actionId,event->if(actionId==android.view.inputmethod.EditorInfo.IME_ACTION_SEND || (event?.keyCode==android.view.KeyEvent.KEYCODE_ENTER && event.isCtrlPressed)){sendBenMessage(historyScroll,history,input,input.text.toString());true}else false}
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(panel(Color.rgb(4,11,18),24f));dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.rgb(125,210,255))}
        dialog.show()
    }

    private fun sendBenMessage(historyScroll:ScrollView,history:TextView,input:EditText,raw:String){
        val q=raw.trim().take(1000);if(q.isBlank())return
        input.setText("");history.append("\n\nYou: $q\nBen: Thinking…");historyScroll.post{historyScroll.fullScroll(View.FOCUS_DOWN)}
        face.setMode(BenFaceView.Mode.THINKING)
        executor.execute{val answer=runCatching{BenBrain.reply(this,q)}.getOrElse{"I hit a temporary problem: ${it.message ?: "unknown error"}."};runOnUiThread{if(!isFinishing&&!isDestroyed){face.setMode(if(BenBrain.wasWebUsed()) BenFaceView.Mode.SEARCHING else BenFaceView.Mode.FOCUSED);history.text=history.text.toString().replace("Ben: Thinking…","Ben: $answer");history.autoLinkMask=android.text.util.Linkify.WEB_URLS;history.linksClickable=true;historyScroll.post{historyScroll.fullScroll(View.FOCUS_DOWN)}}}}
    }

    private fun showBenAnswer(answer:String){
        val titleView=TextView(this).apply{text="BEN";textSize=18f;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.DEFAULT_BOLD;setPadding(dp(20),dp(16),dp(20),dp(8))}
        val dialog=AlertDialog.Builder(this).setCustomTitle(titleView).setMessage(answer).setPositiveButton("Continue",null).create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(panel(Color.rgb(5,14,23),24f))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.rgb(115,205,255))
            dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(Color.rgb(235,242,248))
        }
        dialog.show()
    }

    private fun showMenu(){
        val items=arrayOf("AI settings (internet & smart mode)","About Ben")
        AlertDialog.Builder(this).setTitle("Ben").setItems(items){_,which->when(which){0->showAiSettings();1->showInfo()}}.show()
    }

    private fun showAiSettings(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(10),dp(18),dp(4))}
        root.addView(TextView(this).apply{
            text="Ben can call a real AI model using your own API key for deeper, more natural, conversational answers. Your key is encrypted on this device and sent directly to the provider you choose — never anywhere else. Without a key, Ben keeps working fully offline using his built-in rules."
            textSize=13f;setTextColor(Color.rgb(190,205,215));setPadding(0,0,0,dp(14))
        })

        val providers=BenSettings.Provider.values()
        val currentProvider=BenSettings.provider(this)
        val providerRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        providerRow.addView(TextView(this).apply{text="Provider";setTextColor(Color.WHITE);textSize=14f},LinearLayout.LayoutParams(dp(84),-2))
        val providerSpinner=Spinner(this).apply{adapter=ArrayAdapter(this@BenActivity,android.R.layout.simple_spinner_dropdown_item,providers.map{it.label});setSelection(providers.indexOf(currentProvider))}
        providerRow.addView(providerSpinner,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(providerRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val keyInput=EditText(this).apply{
            hint="Paste your API key"
            setText(BenSettings.apiKey(this@BenActivity))
            setTextColor(Color.WHITE);setHintTextColor(Color.rgb(150,165,178));textSize=14f
            inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(keyInput,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val modelInput=EditText(this).apply{
            hint="Model (optional — default ${currentProvider.defaultModel})"
            setText(BenSettings.model(this@BenActivity).takeIf{it!=currentProvider.defaultModel}?:"")
            setTextColor(Color.WHITE);setHintTextColor(Color.rgb(150,165,178));textSize=14f
        }
        root.addView(modelInput,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})

        val switchRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        switchRow.addView(TextView(this).apply{text="Smart mode (use AI model)";setTextColor(Color.WHITE);textSize=14f},LinearLayout.LayoutParams(0,-2,1f))
        val smartSwitch=Switch(this).apply{isChecked=BenSettings.smartModeEnabled(this@BenActivity)}
        switchRow.addView(smartSwitch)
        root.addView(switchRow)

        val titleView=TextView(this).apply{text="AI settings";textSize=18f;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.DEFAULT_BOLD;setPadding(dp(20),dp(16),dp(20),dp(8))}
        val dialog=AlertDialog.Builder(this).setCustomTitle(titleView).setView(root).setPositiveButton("Save",null).setNegativeButton("Cancel",null).create()
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(panel(Color.rgb(5,14,23),24f))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.rgb(115,205,255))
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.rgb(150,170,185))
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener{
                val provider=providers[providerSpinner.selectedItemPosition]
                BenSettings.setProvider(this,provider)
                BenSettings.setApiKey(this,keyInput.text.toString())
                BenSettings.setModel(this,modelInput.text.toString())
                val wantsSmart=smartSwitch.isChecked
                if(wantsSmart && BenSettings.apiKey(this).isBlank()){
                    Toast.makeText(this,"Add an API key first to enable smart mode.",Toast.LENGTH_LONG).show()
                }else{
                    BenSettings.setSmartModeEnabled(this,wantsSmart)
                    BenBrain.resetConversation()
                    status.text=statusLine()
                    Toast.makeText(this,"Saved.",Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun showInfo(){
        val smart=BenSettings.isActive(this)
        val mode=if(smart) "Smart mode is ON: Ben reasons with a real AI model (your key), grounded in your QBank, weak areas and live web results when needed, and remembers this conversation." else "Smart mode is OFF: Ben is answering with his built-in local rules only. Turn on smart mode from the ⋮ menu to let him reason with a full AI model."
        AlertDialog.Builder(this).setTitle("BEN • operating model").setMessage("Ben is a local-first adaptive agent. He can use your QBank, learning history and knowledge mesh. His background work is deliberately bounded by Android resource and power safeguards.\n\n$mode").setPositiveButton("Understood",null).show()
    }
}
