package com.localqbank.library

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores Ben's AI configuration: which provider to call, which model, and the user's own
 * API key. The key is encrypted at rest via the Android Keystore and is only ever sent
 * directly from this device to the chosen provider's HTTPS endpoint — never anywhere else.
 *
 * "Smart mode" is the switch that lets BenBrain hand reasoning to a real LLM instead of
 * the deterministic rule engine. It stays off by default so the app works fully offline
 * out of the box; the user opts in from AI settings once they add a key.
 */
object BenSettings {
    enum class Provider(val label: String, val defaultModel: String) {
        ANTHROPIC("Anthropic (Claude)", "claude-sonnet-4-5"),
        OPENAI("OpenAI (GPT)", "gpt-4o-mini")
    }

    private const val FILE = "ben_ai_settings"
    private const val KEY_PROVIDER = "provider"
    private const val KEY_API_KEY = "api_key"
    private const val KEY_MODEL = "model"
    private const val KEY_SMART_MODE = "smart_mode"

    private fun prefs(context: Context): SharedPreferences {
        val app = context.applicationContext
        return try {
            val masterKey = MasterKey.Builder(app)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                app, FILE, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Throwable) {
            // Keystore can misbehave on a handful of OEM builds; fall back rather than crash.
            // The key is still sandboxed to this app's private storage either way.
            app.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    fun provider(context: Context): Provider {
        val name = prefs(context).getString(KEY_PROVIDER, Provider.ANTHROPIC.name)
        return runCatching { Provider.valueOf(name ?: Provider.ANTHROPIC.name) }.getOrDefault(Provider.ANTHROPIC)
    }

    fun setProvider(context: Context, provider: Provider) {
        prefs(context).edit().putString(KEY_PROVIDER, provider.name).apply()
    }

    fun apiKey(context: Context): String = prefs(context).getString(KEY_API_KEY, "") ?: ""

    fun setApiKey(context: Context, key: String) {
        prefs(context).edit().putString(KEY_API_KEY, key.trim()).apply()
    }

    fun model(context: Context): String {
        val stored = prefs(context).getString(KEY_MODEL, "")
        return if (stored.isNullOrBlank()) provider(context).defaultModel else stored
    }

    fun setModel(context: Context, model: String) {
        prefs(context).edit().putString(KEY_MODEL, model.trim()).apply()
    }

    fun smartModeEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_SMART_MODE, false)

    fun setSmartModeEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SMART_MODE, enabled).apply()
    }

    fun isConfigured(context: Context): Boolean = apiKey(context).isNotBlank()

    /** True only when the user has both turned smart mode on AND supplied a key. */
    fun isActive(context: Context): Boolean = smartModeEnabled(context) && isConfigured(context)
}
