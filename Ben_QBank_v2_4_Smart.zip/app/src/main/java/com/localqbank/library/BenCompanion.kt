package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.util.concurrent.Executors

/** Lightweight Ben companion available across QBank screens. */
object BenCompanion {
    private val executor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "Ben-Chat").apply { isDaemon = true }
    }

    fun attach(activity: Activity, label: String = "") {
        if (activity is BenActivity) return
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        if (content.findViewWithTag<View>("ben-companion") != null) return
        val d = activity.resources.displayMetrics.density
        val b = TextView(activity).apply {
            tag = "ben-companion"
            text = "BEN"
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_ben_face, 0, 0, 0)
            compoundDrawablePadding = (5 * d).toInt()
            background = GradientDrawable().apply { setColor(Color.rgb(7, 25, 39)); cornerRadius = 28f * d; setStroke((1 * d).toInt(), Color.rgb(52, 178, 255)) }
            elevation = 7f * d
            setPadding((10 * d).toInt(), 0, (14 * d).toInt(), 0)
            contentDescription = "Talk to Ben"
            setOnClickListener { showChat(activity, label) }
        }
        content.addView(b, FrameLayout.LayoutParams(-2, (54 * d).toInt(), Gravity.BOTTOM or Gravity.END).apply {
            setMargins((8 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (14 * d).toInt())
        })
    }

    fun setQuestionContext(title: String, section: String, question: String, explanation: String, correctAnswer: String = "", options: List<Option> = emptyList()) {
        BenBrain.setContext(BenBrain.ContextInfo(title, section, question, explanation, correctAnswer, options.map { BenBrain.OptionInfo(it.label, it.text, it.correct) }))
    }

    private fun showChat(activity: Activity, label: String) {
        val d = activity.resources.displayMetrics.density
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12, d), dp(6, d), dp(12, d), dp(8, d))
            setBackgroundColor(Color.rgb(4, 11, 18))
        }
        val top = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(BenFaceView(activity).apply { setMode(BenFaceView.Mode.FOCUSED) }, LinearLayout.LayoutParams(dp(82, d), dp(82, d)))
        top.addView(TextView(activity).apply {
            text = "I’m Ben. Context: ${label.ifBlank { "current screen" }}\nI can reason from your QBank, memory and current question. If freshness matters, I can use the internet."
            textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(10, d), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top)

        val history = TextView(activity).apply {
            text = "Ben: Ready. Talk naturally. I don't need a special command."
            textSize = 14.5f; setTextColor(Color.rgb(238, 245, 250)); setPadding(0, dp(8, d), 0, dp(10, d)); autoLinkMask = android.text.util.Linkify.WEB_URLS; linksClickable = true
        }
        val historyScroll = ScrollView(activity).apply { addView(history); isFillViewport = true }
        root.addView(historyScroll, LinearLayout.LayoutParams(-1, dp(210, d)))

        val inputRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        val input = EditText(activity).apply {
            hint = "Talk to Ben…"
            setHintTextColor(Color.rgb(165, 190, 205)); setTextColor(Color.WHITE)
            setBackgroundTintList(ColorStateList.valueOf(Color.rgb(65, 165, 220)))
            minLines = 2; maxLines = 5; textSize = 16f; imeOptions = EditorInfo.IME_ACTION_SEND; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val send = Button(activity).apply {
            text = "SEND"; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(Color.rgb(18, 104, 160)); minHeight = dp(52, d); minWidth = dp(82, d)
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, dp(6, d), dp(6, d), 0) })
        inputRow.addView(send, LinearLayout.LayoutParams(dp(82, d), dp(52, d)))
        root.addView(inputRow)

        val quick = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("Explain this", "Exam trap", "Quiz me", "Study next").forEach { t ->
            quick.addView(Button(activity).apply {
                text = t; isAllCaps = false; textSize = 10.5f; setTextColor(Color.WHITE); backgroundTintList = ColorStateList.valueOf(Color.rgb(12, 57, 86))
                setOnClickListener { sendMessage(activity, history, historyScroll, input, t) }
            }, LinearLayout.LayoutParams(0, dp(48, d), 1f).apply { setMargins(dp(2, d), dp(5, d), dp(2, d), 0) })
        }
        root.addView(quick)

        val dialog = AlertDialog.Builder(activity).setTitle("Talk to Ben").setView(root).setNegativeButton("Close", null).create()
        val sendAction = { sendMessage(activity, history, historyScroll, input, input.text.toString()) }
        send.setOnClickListener { sendAction() }
        input.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEND || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.isCtrlPressed)) { sendAction(); true } else false
        }
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(GradientDrawable().apply { setColor(Color.rgb(4, 11, 18)); cornerRadius = 24f * d })
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.rgb(125, 210, 255))
            dialog.findViewById<TextView>(android.R.id.alertTitle)?.setTextColor(Color.WHITE)
        }
        dialog.show()
    }

    private fun sendMessage(activity: Activity, history: TextView, scroll: ScrollView, input: EditText, raw: String) {
        val q = raw.trim().take(1000); if (q.isBlank()) return
        input.setText("")
        history.append("\n\nYou: $q\nBen: Thinking…")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        executor.execute {
            val answer = runCatching { BenBrain.reply(activity, q) }.getOrElse { "I hit a temporary problem: ${it.message ?: "unknown error"}." }
            activity.runOnUiThread {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    val marker = "Ben: Thinking…"
                    history.text = history.text.toString().replace(marker, "Ben: $answer")
                    history.autoLinkMask = android.text.util.Linkify.WEB_URLS
                    history.linksClickable = true
                    scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                }
            }
        }
    }

    private fun dp(v: Int, d: Float) = (v * d).toInt()
}
