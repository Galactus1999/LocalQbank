package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** A deliberately angular, non-cute robotic face for Ben. Lightweight Canvas rendering: no bitmap memory cost. */
class BenFaceView(context: Context) : View(context) {
    enum class Mode { IDLE, THINKING, SEARCHING, FOCUSED, ALERT }
    private var mode = Mode.IDLE
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(18, 22, 28); style = Paint.Style.FILL }
    private val metal = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(92, 104, 116); style = Paint.Style.FILL }
    private val darkMetal = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(35, 41, 48); style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(70, 88, 104); style = Paint.Style.STROKE; strokeWidth = 2f; strokeCap = Paint.Cap.SQUARE }
    private val eye = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(52, 178, 255); style = Paint.Style.FILL }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(55, 52, 178, 255); style = Paint.Style.FILL }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(52, 178, 255); style = Paint.Style.STROKE; strokeWidth = 2.5f; strokeCap = Paint.Cap.SQUARE }

    fun setMode(value: Mode) { mode = value; invalidate() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = minOf(width, height).toFloat().coerceAtLeast(1f)
        val scale = s / 150f
        c.save()
        c.scale(scale, scale)

        // Work entirely in a 150dp-like logical coordinate system. This avoids the
        // previous pivot/coordinate mismatch that could shift the face on wide/tall views.
        val cx = width / (2f * scale)
        val cy = height / (2f * scale)
        val left = cx - 55f
        val top = cy - 62f
        val right = cx + 55f
        val bottom = cy + 62f

        val neck = RectF(cx - 22f, bottom - 2f, cx + 22f, bottom + 18f)
        c.drawRoundRect(neck, 4f, 4f, darkMetal)
        c.drawLine(cx - 18f, bottom + 3f, cx + 18f, bottom + 3f, line)

        val head = Path().apply {
            moveTo(left + 18f, top + 17f)
            lineTo(left + 32f, top + 2f)
            lineTo(right - 32f, top + 2f)
            lineTo(right - 18f, top + 17f)
            lineTo(right - 11f, top + 83f)
            lineTo(right - 27f, bottom - 8f)
            lineTo(left + 27f, bottom - 8f)
            lineTo(left + 11f, top + 83f)
            close()
        }
        c.drawPath(head, metal)
        c.drawPath(head, line)

        val plate = Path().apply {
            moveTo(left + 22f, top + 35f)
            lineTo(right - 22f, top + 35f)
            lineTo(right - 19f, bottom - 18f)
            lineTo(right - 35f, bottom - 5f)
            lineTo(left + 35f, bottom - 5f)
            lineTo(left + 19f, bottom - 18f)
            close()
        }
        c.drawPath(plate, fill)
        c.drawPath(plate, line)

        val brow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(12, 16, 21); style = Paint.Style.FILL }
        c.drawRect(left + 20f, top + 37f, left + 53f, top + 44f, brow)
        c.drawRect(right - 53f, top + 37f, right - 20f, top + 44f, brow)
        c.drawCircle(left + 38f, top + 49f, 12f, glow)
        c.drawCircle(right - 38f, top + 49f, 12f, glow)
        val eyePath = Path().apply { moveTo(left + 27f, top + 48f); lineTo(left + 50f, top + 46f); lineTo(left + 48f, top + 53f); lineTo(left + 28f, top + 53f); close() }
        c.drawPath(eyePath, eye)
        val eyePath2 = Path().apply { moveTo(right - 27f, top + 48f); lineTo(right - 50f, top + 46f); lineTo(right - 48f, top + 53f); lineTo(right - 28f, top + 53f); close() }
        c.drawPath(eyePath2, eye)

        c.drawLine(cx, top + 43f, cx, top + 69f, accent)
        for (i in 0..3) c.drawLine(cx - 19f, top + 78f + i * 5f, cx + 19f, top + 78f + i * 5f, line)
        c.drawLine(cx - 13f, top + 97f, cx + 13f, top + 97f, accent)

        val statusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = when (mode) { Mode.SEARCHING -> Color.rgb(255, 183, 70); Mode.ALERT -> Color.rgb(255, 80, 70); else -> Color.rgb(52, 178, 255) }
            style = Paint.Style.FILL
        }
        c.drawCircle(cx, top - 4f, 4f, statusPaint)
        c.restore()
    }
}
