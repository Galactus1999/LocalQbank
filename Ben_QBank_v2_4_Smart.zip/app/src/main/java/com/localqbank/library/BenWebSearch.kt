package com.localqbank.library

import android.net.Uri
import android.text.Html
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Small, user-triggered web research tool. It never runs from Ben's background heartbeat. */
object BenWebSearch {
    data class Result(val title: String, val url: String, val snippet: String)

    fun search(query: String, maxResults: Int = 5): List<Result> {
        val q = query.trim().take(220)
        if (q.isBlank()) return emptyList()
        val url = URL("https://html.duckduckgo.com/html/?q=${Uri.encode(q)}")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 4500
            readTimeout = 6500
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Ben-QBank/2.3 Android")
            setRequestProperty("Accept", "text/html")
        }
        return try {
            connection.connect()
            if (connection.responseCode !in 200..299) return emptyList()
            val body = readBounded(connection.inputStream, 300_000)
            parse(body, maxResults.coerceIn(1, 6))
        } finally {
            connection.disconnect()
        }
    }


    /** Reads a bounded response so a large/malformed web page cannot consume unbounded RAM. */
    private fun readBounded(stream: java.io.InputStream, maxChars: Int): String {
        val limit = maxChars.coerceIn(32_000, 500_000)
        val reader = BufferedReader(InputStreamReader(stream, Charsets.UTF_8), 16 * 1024)
        val out = StringBuilder(minOf(limit, 64 * 1024))
        val buf = CharArray(16 * 1024)
        while (out.length < limit) {
            val remaining = limit - out.length
            val read = reader.read(buf, 0, minOf(buf.size, remaining))
            if (read < 0) break
            out.append(buf, 0, read)
        }
        return out.toString()
    }

    private fun parse(html: String, max: Int): List<Result> {
        val out = ArrayList<Result>(max)
        val blockRegex = Regex("<div[^>]+class=\\\"result[^>]*>([\\s\\S]*?)</div>\\s*</div>", RegexOption.IGNORE_CASE)
        val titleRegex = Regex("<a[^>]+class=\\\"result__a\\\"[^>]+href=\\\"([^\\\"]+)\\\"[^>]*>([\\s\\S]*?)</a>", RegexOption.IGNORE_CASE)
        val snippetRegex = Regex("<a[^>]+class=\\\"result__snippet\\\"[^>]*>([\\s\\S]*?)</a>|<div[^>]+class=\\\"result__snippet[^>]*>([\\s\\S]*?)</div>", RegexOption.IGNORE_CASE)
        for (block in blockRegex.findAll(html)) {
            val t = titleRegex.find(block.groupValues[1]) ?: continue
            val title = clean(t.groupValues[2])
            val rawUrl = t.groupValues[1]
            val link = if (rawUrl.startsWith("//")) "https:$rawUrl" else rawUrl
            val url = decodeDdg(link)
            val s = snippetRegex.find(block.groupValues[1])
            val snippet = clean(s?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() } ?: "")
            if (title.isNotBlank() && url.startsWith("http")) out.add(Result(title, url, snippet.take(500)))
            if (out.size >= max) break
        }
        return out
    }

    private fun decodeDdg(url: String): String {
        return try {
            val u = Uri.parse(url)
            val target = u.getQueryParameter("uddg")
            target ?: url
        } catch (_: Throwable) { url }
    }

    private fun clean(value: String): String = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)
        .toString().replace(Regex("\\s+"), " ").trim()
}
