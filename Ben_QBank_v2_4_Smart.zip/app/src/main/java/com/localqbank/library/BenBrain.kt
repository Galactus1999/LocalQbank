package com.localqbank.library

import android.content.Context
import java.util.Locale

/**
 * Ben's decision/reasoning layer.
 *
 * Two modes:
 *  - Smart mode (BenSettings.isActive): every message is answered by a real LLM (the user's
 *    own API key), grounded with a context block built from the current question, local QBank
 *    matches, live web results when the request looks time-sensitive, and the student's weak
 *    areas. A short rolling chat history is kept in memory so follow-ups actually work.
 *  - Offline/deterministic mode (default, no key configured): the original rule-based engine
 *    below, which stays cheap and fully local. Smart mode also falls back to this automatically
 *    if the network/model call fails, so Ben never just goes silent.
 */
object BenBrain {
    data class OptionInfo(val label: String, val text: String, val correct: Boolean)
    data class ContextInfo(
        val title: String = "",
        val section: String = "",
        val question: String = "",
        val explanation: String = "",
        val correctAnswer: String = "",
        val options: List<OptionInfo> = emptyList()
    )
    @Volatile private var current = ContextInfo()
    @Volatile private var lastWebUsed = false
    @Volatile private var lastSmartUsed = false

    // Bounded rolling memory so smart mode can hold a real conversation without growing forever.
    private val chatHistory = java.util.Collections.synchronizedList(ArrayList<BenLLMClient.ChatTurn>())
    private const val MAX_HISTORY_TURNS = 16 // ~8 exchanges

    fun setContext(info: ContextInfo) { current = info }
    fun clearContext() { current = ContextInfo() }
    fun wasWebUsed(): Boolean = lastWebUsed
    fun wasSmartUsed(): Boolean = lastSmartUsed
    fun resetConversation() { synchronized(chatHistory) { chatHistory.clear() } }

    fun reply(context: Context, input: String): String {
        val q = input.trim().take(1000)
        if (q.isBlank()) return "I'm here. Give me a question, a concept, a doubt, or a study goal."
        val app = context.applicationContext
        val db = QBankDb(app)
        val store = ProgressStore(app)
        val agent = BenAgentStore(app)
        lastWebUsed = false
        lastSmartUsed = false
        return try {
            agent.observe("ben_chat", q.take(240), 1.0)
            val l = q.lowercase(Locale.ROOT)
            val nodes = agent.nodes(18)
            if (wantsReset(l)) {
                resetConversation()
                return "Fresh start — I've cleared our chat memory. Your QBank data and progress stay exactly as they were."
            }
            if (BenSettings.isActive(app)) {
                smartReply(app, q, l, db, store, nodes)
            } else {
                deterministicReply(app, q, l, db, store, nodes)
            }
        } finally {
            db.close(); agent.shutdown()
        }
    }

    // ---------------------------------------------------------------------
    // Smart mode: LLM-backed reasoning, grounded on local + live context
    // ---------------------------------------------------------------------

    private fun smartReply(
        context: Context, q: String, l: String, db: QBankDb, store: ProgressStore, nodes: List<BenAgentStore.Node>
    ): String {
        val c = current
        val useWeb = shouldUseWeb(l)
        val searchTerm = if (q.length in 1..220) q else c.section.ifBlank { c.title }
        val local = if (searchTerm.isBlank()) emptyList() else runCatching { db.search(searchTerm) }.getOrDefault(emptyList()).take(4)
        val web = if (useWeb) runCatching { BenWebSearch.search(q, 5) }.getOrDefault(emptyList()) else emptyList()
        lastWebUsed = web.isNotEmpty()
        val weak = nodes.filter { it.kind == "weak" || it.confidence < 0.55 }.take(5)

        val contextBlock = buildString {
            if (c.question.isNotBlank() || c.explanation.isNotBlank()) {
                append("CURRENT OPEN QUESTION\n")
                if (c.title.isNotBlank()) append("Topic: ${c.title}\n")
                if (c.section.isNotBlank()) append("Section: ${c.section}\n")
                if (c.question.isNotBlank()) append("Stem: ${strip(c.question).take(900)}\n")
                if (c.options.isNotEmpty()) append("Options: ${c.options.joinToString("; ") { "${it.label}) ${strip(it.text).take(150)}" }}\n")
                if (c.correctAnswer.isNotBlank()) append("Correct answer: ${c.correctAnswer}\n")
                if (c.explanation.isNotBlank()) append("Reference explanation: ${strip(c.explanation).take(1200)}\n")
                append("\n")
            }
            if (local.isNotEmpty()) {
                append("RELEVANT LOCAL QBANK MATCHES\n")
                local.forEach { append("• ${it.testTitle} Q${it.position + 1}: ${strip(it.text).take(500)}\n") }
                append("\n")
            }
            if (web.isNotEmpty()) {
                append("LIVE WEB RESULTS (fetched because this looked time-sensitive or evidence-sensitive)\n")
                web.forEach { append("• ${it.title} — ${it.url}\n  ${strip(it.snippet).take(300)}\n") }
                append("\n")
            }
            if (weak.isNotEmpty()) {
                append("STUDENT'S CURRENT WEAK AREAS (lowest confidence first)\n")
                weak.forEach { append("• ${it.label.removePrefix("Weak: ")} (confidence ${(it.confidence * 100).toInt()}%)\n") }
            }
            if (isBlank()) append("No extra local/web context matched this message — answer from general medical knowledge, and say so if you're unsure.")
        }

        val system = """
            You are Ben, an exam-focused AI study partner embedded in a NEET PG / INI-CET question bank app.
            The student is an Indian medical student preparing intensively for NEET PG and INI-CET, targeting 600+.
            Be brutally exam-oriented: clinical reasoning, elimination logic, examiner behaviour patterns, high-yield
            facts, and explicit guidance on what to skip. Prefer concise, structured answers (short headers, bullet
            points) over long prose, unless the student clearly wants a deeper explanation. Use the CONTEXT block
            below when it's relevant, but synthesise it in your own words rather than repeating it verbatim. If you
            used LIVE WEB RESULTS, say so briefly and flag anything that may be outdated versus a locally taught
            explanation. Never invent a PYQ year, statistic, drug approval, or citation you were not given — say
            plainly when you're not certain instead of guessing. Keep the tone direct, encouraging and non-repetitive,
            and remember earlier turns in this conversation.

            CONTEXT
            $contextBlock
        """.trimIndent()

        appendHistory(BenLLMClient.ChatTurn("user", q))
        val turns = synchronized(chatHistory) { chatHistory.toList() }
        val result = BenLLMClient.complete(context, system, turns)
        return result.fold(
            onSuccess = { text ->
                lastSmartUsed = true
                appendHistory(BenLLMClient.ChatTurn("assistant", text))
                text
            },
            onFailure = { err ->
                // Drop the unanswered user turn so history doesn't desync, then degrade gracefully
                // rather than leaving the student stuck.
                synchronized(chatHistory) { if (chatHistory.isNotEmpty()) chatHistory.removeAt(chatHistory.size - 1) }
                "Smart mode hit a problem (${err.message ?: "network/model error"}) — falling back to Ben's local reasoning for this one.\n\n" +
                    deterministicReply(context, q, l, db, store, nodes)
            }
        )
    }

    private fun appendHistory(turn: BenLLMClient.ChatTurn) {
        synchronized(chatHistory) {
            chatHistory.add(turn)
            while (chatHistory.size > MAX_HISTORY_TURNS) chatHistory.removeAt(0)
        }
    }

    // ---------------------------------------------------------------------
    // Deterministic / offline mode (original rule engine, used as default and as fallback)
    // ---------------------------------------------------------------------

    private fun deterministicReply(
        context: Context, q: String, l: String, db: QBankDb, store: ProgressStore, nodes: List<BenAgentStore.Node>
    ): String = when {
        isGreeting(l) -> greeting(context)
        wantsCurrentExplanation(l) -> explainCurrent()
        wantsTrap(l) -> examTrap()
        wantsSimplify(l) -> simplifyCurrent()
        wantsCompare(l) -> compareCurrent(db)
        wantsQuiz(l) -> quizPrompt(db, nodes)
        wantsPlan(l) || wantsWeak(l) -> recommend(nodes)
        wantsProgress(l) -> performance(store, db)
        shouldUseWeb(l) -> research(q, db, true)
        else -> {
            val local = localAnswer(q, db)
            if (local.isNotBlank()) local else research(q, db, false)
        }
    }

    private fun isGreeting(l: String) = l == "hi" || l == "hello" || l == "hey" || l.startsWith("hey ") || l.startsWith("hi ")
    private fun wantsCurrentExplanation(l: String) = listOf("explain this", "this question", "why is this", "why the answer", "explain the answer").any(l::contains)
    private fun wantsTrap(l: String) = listOf("trap", "exam point", "mcq pitfall", "neet", "ini-cet", "pyq").any(l::contains)
    private fun wantsSimplify(l: String) = listOf("simplify", "simple", "easy way", "memory trick", "mnemonic", "teach me").any(l::contains)
    private fun wantsCompare(l: String) = listOf("compare", "difference between", "differentiate", "vs ", "versus").any(l::contains)
    private fun wantsQuiz(l: String) = listOf("quiz me", "test me", "ask me", "give me a question", "mcq me").any(l::contains)
    private fun wantsPlan(l: String) = listOf("what should i study", "what do i study", "study next", "next topic", "plan my study").any(l::contains)
    private fun wantsWeak(l: String) = listOf("weak area", "weak topic", "weakness", "revise", "revision").any(l::contains)
    private fun wantsProgress(l: String) = listOf("progress", "performance", "accuracy", "how am i doing", "my score").any(l::contains)
    private fun wantsReset(l: String) = listOf("start over", "new conversation", "forget this", "forget our chat", "reset chat", "clear history", "clear our chat").any(l::contains)
    private fun shouldUseWeb(l: String) = listOf("latest", "current", "today", "recent", "guideline", "guidelines", "recommendation", "new drug", "approved", "2026", "update", "news", "paper", "study published", "pubmed", "evidence", "internet", "web research", "search online").any(l::contains)

    private fun greeting(context: Context): String =
        if (BenSettings.isActive(context))
            "I'm Ben, running in smart mode — I can reason freely, remember this conversation, and pull in the web or your QBank when it helps. Ask away."
        else
            "I'm Ben. I can use your current question, QBank history and knowledge mesh. If something needs current evidence, I'll search the web rather than pretending your old explanation is still current. Turn on smart mode (⋮ → AI settings) if you'd like me to reason with a full AI model instead of my built-in rules."

    private fun explainCurrent(): String {
        val c = current
        if (c.question.isBlank() && c.explanation.isBlank()) return "Open a question first. Then ask me 'explain this' and I'll use the actual question context."
        val q = strip(c.question).take(900)
        val exp = strip(c.explanation).take(1400)
        val correct = c.correctAnswer.ifBlank { c.options.firstOrNull { it.correct }?.label ?: "" }
        val answerText = c.options.firstOrNull { it.label.equals(correct, true) }?.text
        val out = StringBuilder()
        out.append("Here’s how I’d attack it:\n\n")
        if (q.isNotBlank()) out.append("1. What the stem is really testing\n").append(q).append("\n\n")
        if (correct.isNotBlank()) out.append("2. Correct option: ").append(correct).append(if (!answerText.isNullOrBlank()) " — ${strip(answerText).take(350)}" else "").append("\n\n")
        if (exp.isNotBlank()) out.append("3. Why it fits\n").append(exp).append("\n\n")
        out.append("4. Ben’s take\nDon’t memorise the answer letter. Anchor the diagnosis/concept to the clue in the stem, then eliminate the distractors. Ask me 'exam trap' for the high-yield pitfall.")
        return out.toString().take(3600)
    }

    private fun examTrap(): String {
        val c = current
        if (c.question.isBlank()) return "Open a question and ask 'exam trap'. I'll identify the clue, likely distractor and the mistake pattern to watch for."
        val correct = c.correctAnswer.ifBlank { c.options.firstOrNull { it.correct }?.label ?: "the correct option" }
        val wrong = c.options.filterNot { it.correct }.take(3).joinToString("; ") { "${it.label}: ${strip(it.text).take(120)}" }
        return "⚠️ EXAM TRAP\n\nKey anchor: ${strip(c.question).take(500)}\n\nCorrect: $correct\n\nLikely distractors: $wrong\n\nBen's rule: identify the discriminating clue first; don't let a familiar-sounding option win just because it is common."
    }

    private fun simplifyCurrent(): String {
        val c = current
        val text = strip(c.explanation.ifBlank { c.question })
        if (text.isBlank()) return "Give me a concept or open a question first."
        return "Let's make it simple.\n\nThink of it as:\n${text.take(1500)}\n\nMemory hook: find one mechanism → one clinical clue → one consequence. If you want, ask me to build a 3-step mnemonic from this."
    }

    private fun compareCurrent(db: QBankDb): String {
        val c = current
        val target = if (c.section.isNotBlank()) c.section else c.title
        val hits = if (target.isBlank()) emptyList() else runCatching { db.search(target) }.getOrDefault(emptyList())
        return if (hits.size >= 2) {
            "Let's compare using your local material.\n\n${hits.take(3).joinToString("\n\n") { "• ${it.testTitle}: ${strip(it.text).take(450)}" }}\n\nTell me the two entities you want contrasted and I'll focus the comparison."
        } else "Tell me the two entities explicitly (for example, 'MCD vs FSGS'). I’ll structure the comparison around mechanism, presentation, investigations and the exam trap."
    }

    private fun quizPrompt(db: QBankDb, nodes: List<BenAgentStore.Node>): String {
        val weak = nodes.firstOrNull { it.kind == "weak" || it.confidence < 0.55 }?.label?.removePrefix("Weak: ")
        val query = weak ?: current.section.takeIf { it.isNotBlank() } ?: current.title
        val hits = if (query.isBlank()) emptyList() else runCatching { db.search(query) }.getOrDefault(emptyList())
        if (hits.isEmpty()) return "Quiz mode is ready. Give me a topic and I'll pull a relevant local question. I can also target your weakest area: ${weak ?: "not enough history yet"}."
        val h = hits.first()
        return "🎯 Ben's challenge\n\n${strip(h.text).take(1100)}\n\nDon't look at the explanation yet. Reply with your answer and your reasoning. I'll challenge the reasoning, not just mark the letter.\n\nSource: ${h.testTitle} • Q${h.position + 1}"
    }

    private fun recommend(nodes: List<BenAgentStore.Node>): String {
        val weak = nodes.filter { it.kind == "weak" || it.confidence < 0.55 }.take(5)
        if (weak.isEmpty()) return "I don't have enough performance signal to rank your weak areas yet. Keep solving questions; I'll update the model after every attempt."
        return "I wouldn't study randomly right now. I'd prioritise:\n\n${weak.mapIndexed { i, n -> "${i + 1}. ${n.label.removePrefix("Weak: ")} — confidence ${(n.confidence * 100).toInt()}%" }.joinToString("\n")}\n\nWhy: these are the nodes Ben currently considers least secure. Ask 'quiz me' and I'll target the first one."
    }

    private fun performance(store: ProgressStore, db: QBankDb): String {
        val entries = store.allProgressKeys(); var c = 0; var w = 0
        entries.forEach { key -> if (key.endsWith(":status")) when (store.status(key.removeSuffix(":status"))) { "correct" -> c; "wrong" -> w } }
        val attempted = c + w; val acc = if (attempted == 0) 0 else c * 100 / attempted
        val total = runCatching { db.questionCountAll() }.getOrDefault(attempted)
        return "Current local picture: $attempted attempted, $c correct, $w wrong ($acc%). QBank size: $total.\n\nI use this signal to change Ben's priorities; it is not a judgement of your overall ability."
    }

    private fun localAnswer(query: String, db: QBankDb): String {
        val hits = runCatching { db.search(query) }.getOrDefault(emptyList())
        if (hits.isEmpty()) return ""
        val joined = hits.take(4).joinToString("\n\n") { "• ${it.testTitle} — Q${it.position + 1}\n${strip(it.text).take(600)}" }
        return "I found relevant local material. Here’s the useful signal:\n\n$joined\n\nI’m not going to pretend that a retrieved question is a complete explanation. Ask me to explain, compare, or find current evidence if needed."
    }

    private fun research(query: String, db: QBankDb, explicit: Boolean): String {
        val local = runCatching { db.search(query) }.getOrDefault(emptyList()).take(2)
        val web = runCatching { BenWebSearch.search(query, 5) }.getOrDefault(emptyList())
        lastWebUsed = web.isNotEmpty()
        if (web.isEmpty()) {
            return if (local.isNotEmpty()) "I couldn't reach the web right now, so I'm using your local QBank instead.\n\n${local.joinToString("\n\n") { "• ${it.testTitle}: ${strip(it.text).take(500)}" }}" else "I couldn't reach the web right now and I don't have a strong local match. Check your connection and ask me again."
        }
        val localContext = if (local.isNotEmpty()) "\n\nLOCAL QBANK CONTEXT\n${local.joinToString("\n") { "• ${it.testTitle}: ${strip(it.text).take(350)}" }}" else ""
        val sources = web.joinToString("\n") { "• ${it.title}\n  ${it.url}\n  ${it.snippet}" }
        return "I checked the web because this request looks time-sensitive or evidence-sensitive. I won't silently treat a search result as fact; verify the source when it matters.\n\nWEB RESULTS\n$sources$localContext\n\nAsk me 'compare local vs web' if you want me to analyse the difference."
    }

    private fun strip(s: String) = s.replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
}
