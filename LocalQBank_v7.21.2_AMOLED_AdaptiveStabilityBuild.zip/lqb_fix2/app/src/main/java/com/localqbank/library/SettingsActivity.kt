package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class SettingsActivity: Activity(){
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private val section by lazy { intent.getStringExtra("section") ?: "all" }

    override fun onCreate(b:Bundle?){
        super.onCreate(b); AppManagers.initialize(applicationContext); SystemUi.immersive(this); setContentView(build())
    }

    private fun build():ScrollView{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(28));setBackgroundColor(ThemeManager.bg(this@SettingsActivity))}
        root.addView(TextView(this).apply{text=when(section){"adaptive"->"Adaptive Engine";"appearance"->"Appearance & Themes";"fonts"->"Quiz Typography";else->"Q Settings"};textSize=27f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity));setPadding(0,0,0,dp(6))})
        root.addView(TextView(this).apply{text="${if(section=="all")"Appearance, backup, typography and adaptive intelligence" else "Dedicated ${section.replaceFirstChar{it.uppercase()}} controls"}";textSize=13f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,0,0,dp(18))})

        if(section=="all" || section=="appearance") addAppearance(root)
        if(section=="all") {
            section(root,"BACKUP & RESTORE")
            root.addView(button("Open Backup & Restore"){startActivity(Intent(this,BackupActivity::class.java))},lp())
        }
        if(section=="all" || section=="fonts") addFonts(root)
        if(section=="all" || section=="adaptive") addAdaptive(root)
        return ScrollView(this).apply{addView(root);isFillViewport=true}
    }

    private fun addAppearance(root:LinearLayout){
        section(root,"APPEARANCE")
        val themes=linkedMapOf(ThemeManager.LIGHT to "Light",ThemeManager.DARK to "Dark",ThemeManager.SEPIA to "Sepia",ThemeManager.AMOLED to "AMOLED Black",ThemeManager.MIDNIGHT to "Midnight Blue")
        themes.forEach{(key,label)-> root.addView(button(if(ThemeManager.get(this)==key)"✓  $label" else label){ThemeManager.set(this,key);recreate()},lp())}
    }

    private fun addFonts(root:LinearLayout){
        section(root,"QUIZ TYPOGRAPHY")
        val fonts=linkedMapOf("sans-serif" to "Modern Sans","serif" to "Serif / textbook","monospace" to "Monospace / coding","sans-serif-condensed" to "Condensed Sans","sans-serif-light" to "Light Sans")
        val current=getSharedPreferences("ui",MODE_PRIVATE).getString("quiz_font_family","sans-serif")?:"sans-serif"
        fonts.forEach{(key,label)->root.addView(button(if(current==key)"✓  $label" else label){getSharedPreferences("ui",MODE_PRIVATE).edit().putString("quiz_font_family",key).apply();recreate()},lp())}
    }

    private fun addAdaptive(root:LinearLayout){
        section(root,"ADAPTIVE INTELLIGENCE CORE")
        val state=AppManagers.adaptive.state()
        val architecture=TextView(this).apply{
            text="ENGINE ARCHITECTURE\n\n${AppManagers.adaptive.architectureSummary()}"
            textSize=13.5f;setTextColor(ThemeManager.text(this@SettingsActivity));setLineSpacing(0f,1.18f);setPadding(dp(16),dp(15),dp(16),dp(15))
            background=rounded(ThemeManager.elevated(this@SettingsActivity),16);
        }
        root.addView(architecture,LinearLayout.LayoutParams(-1,dp(235)))

        val activity=TextView(this).apply{
            text="CURRENT LEARNING & AUTONOMOUS CHANGES\n\nLearning level: ${state.learningScore}%\nConfidence: ${state.confidence}%\nSystem health: ${state.health}%\nObservations: ${state.observations}\nAnswers: ${state.answers}  •  Correct: ${state.correct}  •  Wrong: ${state.wrong}\nAutonomous changes: ${state.autonomousChanges}\nCurrent action: ${state.lastAction}\nPrefetch: ${state.preferredPrefetch} questions\nCache lifetime: ${PerformanceManager.adaptiveCacheTtlMs()/1000}s\nExploration: ${state.exploration}%\n\nWHAT IT IS DOING\n${AppManagers.adaptive.insight()}\n\nRECENT AUTONOMOUS ACTIONS\n${if(state.recentActions.isEmpty()) "No autonomous changes yet." else state.recentActions.joinToString("\n")}"
            textSize=14f;setTextColor(ThemeManager.text(this@SettingsActivity));setLineSpacing(0f,1.18f);setPadding(dp(16),dp(16),dp(16),dp(16));background=rounded(ThemeManager.panel(this@SettingsActivity),16)
        }
        root.addView(activity,LinearLayout.LayoutParams(-1,dp(430)).apply{setMargins(0,dp(10),0,dp(10))})
        root.addView(button("Reset Adaptive Learning History"){AppManagers.adaptive.resetLearning();Toast.makeText(this,"Adaptive history reset",Toast.LENGTH_SHORT).show();recreate()},lp())
    }

    private fun section(root:LinearLayout,t:String){root.addView(TextView(this).apply{text=t;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(16),0,dp(8))})}
    private fun lp()=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}
    private fun button(t:String,click:()->Unit)=TextView(this).apply{text=t;textSize=14f;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),0,dp(16),0);setTextColor(ThemeManager.text(this@SettingsActivity));background=rounded(ThemeManager.elevated(this@SettingsActivity),14);setOnClickListener{click()}}
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
}
