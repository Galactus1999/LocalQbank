# LocalQBank v7.21.2 — AMOLED/UI & Adaptive Intelligence Stability Build

## This release
- Fixed dark-theme contrast paths so AMOLED/ Midnight use the dark palette consistently, including quiz options and result/explanation panels.
- Added a compact grey settings/app-menu button with a round settings icon.
- App Menu opens a structured popup and routes Appearance, Backup & Restore, Adaptive Engine and Quiz Typography to dedicated screens.
- Adaptive Engine settings now show its architecture, current policy, learning state, autonomous changes, and recent autonomous actions.
- Analytics Insight now includes the adaptive engine's current advice/action explanation.
- Added bounded autonomous action history for transparency.
- Kept the adaptive engine offline and safety-bounded; it cannot mutate core question data, schema, or executable code.
- Kept two dark themes: AMOLED Black and Midnight Blue.
- Unified dark-theme detection across activities to avoid AMOLED being treated as light/dark incorrectly.
- Added theme-aware flashcard HTML colors and quiz result backgrounds.

## Stability audit
- ZIP integrity checked with `zip -T`.
- Typed `findViewById<T>()` references reviewed against layout declarations; generic `View` lookups are intentional.
- No duplicate layout IDs found.
- No `Thread.sleep`, `runBlocking`, or `GlobalScope` in production Kotlin.
- Adaptive cooldown/action path reviewed.
- Backup/progress notification path reviewed.
- Android SDK/Gradle runtime compilation is not available in this build environment; use the repository GitHub Actions workflow for the authoritative Android compilation/device test.
