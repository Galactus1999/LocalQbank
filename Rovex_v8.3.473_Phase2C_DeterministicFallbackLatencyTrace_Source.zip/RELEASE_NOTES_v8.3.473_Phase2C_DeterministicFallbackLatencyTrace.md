# Rovex v8.3.473 — Phase 2C Deterministic Fallback Latency Trace

## Purpose

v8.3.472 preserves the explicit-user-enable neural safety contract. Device evidence then showed a deterministic Ben fallback request completing successfully but reporting approximately 64.3 seconds of latency.

v8.3.473 is a **measurement-only diagnostic batch**. It does not attempt to guess or optimize the cause of the delay.

## Instrumentation

The deterministic fallback path now records bounded, non-content diagnostic timings for:

- total request latency
- clinical understanding
- local QBank search
- QBank search-index schema check
- primary search
- alias/expansion search
- variant count
- primary/alias hit counts
- response composition remainder

The Test & Diagnostics Center and complete diagnostics export expose the last deterministic trace.

## Telemetry correctness

Deterministic fallback is retrieval/evidence output, not a completed neural verification. The diagnostics UI therefore reports verification/citation as `N/A` for fallback rather than retaining stale values from a previous neural request.

## Scope restrictions

No changes were made to:

- Ben Binder/isolated inference transport
- EmbeddingGemma or Gemma runtime
- QBank database ownership
- QBank deletion/import contracts
- Frankenstein search authority
- chat renderer
- neural default-off safety policy

## Required next validation

1. Build/install v8.3.473.
2. Keep AI accelerator OFF.
3. Run the same clinical question that previously reported ~64,323 ms.
4. Open Test & Diagnostics Center and capture the fallback trace.
5. Export complete diagnostics.
6. Use the measured stage that dominates latency to select the smallest root-cause repair.

No performance improvement is claimed by this release until device measurements demonstrate it.
