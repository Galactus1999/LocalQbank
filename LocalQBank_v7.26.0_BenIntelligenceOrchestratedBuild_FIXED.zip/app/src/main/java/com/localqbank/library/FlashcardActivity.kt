package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper

class FlashcardActivity: Activity() {
    private lateinit var db: FlashcardDb
    private val executor=Executors.newSingleThreadExecutor()
    private val mainHandler=Handler(Looper.getMainLooper())
    private var importControl: ApkgImporter.Control?=null
    private lateinit var list:LinearLayout
    private lateinit var reviewButton:TextView
    private lateinit var bookmarkButton:TextView
    private lateinit var srsSummary:TextView
    private val expanded=mutableSetOf<String>()
    private val stateListener:()->Unit={if(!isFinishing && !isDestroyed && hasWindowFocus() && ::list.isInitialized)runOnUiThread{render()}}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun semanticFill(kind:String):Int = when(ThemeManager.get(this)) {
        ThemeManager.AMOLED -> when(kind){"primary"->Color.rgb(18,55,70);"secondary"->Color.rgb(43,34,57);"neutral"->Color.rgb(28,30,34);else->Color.rgb(24,44,48)}
        ThemeManager.MIDNIGHT -> when(kind){"primary"->Color.rgb(25,69,96);"secondary"->Color.rgb(55,43,80);"neutral"->Color.rgb(29,42,61);else->Color.rgb(26,54,65)}
        ThemeManager.DARK -> when(kind){"primary"->Color.rgb(25,73,86);"secondary"->Color.rgb(61,45,78);"neutral"->Color.rgb(32,38,45);else->Color.rgb(27,55,60)}
        ThemeManager.SEPIA -> when(kind){"primary"->Color.rgb(120,91,54);"secondary"->Color.rgb(117,83,92);"neutral"->Color.rgb(224,213,188);else->Color.rgb(128,102,64)}
        else -> when(kind){"primary"->Color.rgb(37,113,128);"secondary"->Color.rgb(102,79,135);"neutral"->Color.rgb(229,235,239);else->Color.rgb(225,241,239)}
    }
    private fun button(text:String,fill:Int=semanticFill("primary"),click:()->Unit)=TextView(this).apply{this.text=text;textSize=13.5f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(if(ThemeManager.isDark(this@FlashcardActivity))Color.WHITE else if(fill==semanticFill("neutral"))ThemeManager.text(this@FlashcardActivity) else Color.WHITE);background=GradientDrawable().apply{setColor(fill);cornerRadius=16f*resources.displayMetrics.density;setStroke(dp(1),Color.argb(55,100,120,140))};setOnClickListener{click()}}

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        try {
            SystemUi.immersive(this)
            db=FlashcardDb(this)
            setContentView(build())
            AppState.register(stateListener)
            safeRender()
            intent.data?.let{importUri(it)}
            if (intent.data==null && ApkgImporter.hasPending(this)) showPendingImport()
        } catch (t:Throwable) {
            val msg=t.message ?: t.javaClass.simpleName
            Toast.makeText(this,"Unable to open Flashcards: $msg",Toast.LENGTH_LONG).show()
            finish()
        }
    }
    override fun onResume(){super.onResume();if(::list.isInitialized)safeRender()}

    private fun build():View {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@FlashcardActivity))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(7),dp(10),dp(7));setBackground(GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(semanticFill("primary"),semanticFill("secondary"))).apply{cornerRadius=0f})}
        val back=TextView(this).apply{text="←";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{finish()}}
        bar.addView(back,LinearLayout.LayoutParams(dp(52),dp(50)))
        val title=TextView(this).apply{text="Flashcards";textSize=21f;setTypeface(null,Typeface.BOLD);setTextColor(Color.WHITE)};bar.addView(title,LinearLayout.LayoutParams(0,-2,1f));root.addView(bar)

        val review=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(12),dp(12),dp(6))}
        reviewButton=button("REVIEW DUE",semanticFill("primary")){startReview(false)}
        bookmarkButton=button("★ BOOKMARKED",semanticFill("secondary")){startReview(true)}
        review.addView(reviewButton,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)});review.addView(bookmarkButton,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)});root.addView(review)
        val studyMenu=button("⚡  STUDY MENU  •  Due / New / Hard / Again / Marked / Custom",semanticFill("primary")){showStudyMenu()};root.addView(studyMenu,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(dp(12),dp(2),dp(12),dp(5))})
        val tools=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),0,dp(12),dp(5))}
        val settings=button("⚙  SRS SETTINGS",Color.rgb(74,82,91)){showSrsSettings()};val stats=button("▣  STATS",Color.rgb(88,70,137)){showStats()}
        tools.addView(settings,LinearLayout.LayoutParams(0,dp(44),1f).apply{setMargins(0,0,dp(4),0)});tools.addView(stats,LinearLayout.LayoutParams(0,dp(44),1f).apply{setMargins(dp(4),0,0,0)});root.addView(tools)
        srsSummary=TextView(this).apply{textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(16),dp(1),dp(16),dp(9));maxLines=2};root.addView(srsSummary)
        val import=button("＋  IMPORT .APKG",semanticFill("primary")){pickApkg()};root.addView(import,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(dp(16),dp(5),dp(16),dp(10))})
        val section=TextView(this).apply{text="DECKS";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(16),dp(3),dp(16),dp(4))};root.addView(section)
        val scroll=ScrollView(this).apply{isFillViewport=true};list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(2),dp(12),dp(20))};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));return root
    }

    private fun refreshTop(){if(!::reviewButton.isInitialized)return;reviewButton.text="REVIEW DUE  •  ${db.reviewCount()}";bookmarkButton.text="★ BOOKMARKED  •  ${db.bookmarkCount()}";if(::srsSummary.isInitialized){val s=db.dueStatsAll();srsSummary.text="PENDING  •  Learning ${s.learning}  •  Hard ${s.hard}  •  Good ${s.good}  •  Easy ${s.easy}"}}
    private fun pickApkg(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE);putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/octet-stream","application/zip","application/x-zip-compressed"))},91)}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req==91&&res==RESULT_OK)data?.data?.let{importUri(it)}}
    private fun showPendingImport(){
        AlertDialog.Builder(this).setTitle("Interrupted import found")
            .setMessage("A previous flashcard import did not finish.\n\nProgress: ${ApkgImporter.pendingDescription(this) ?: "checkpoint available"}\n\nYou can safely resume it, or discard the partial import and start again.")
            .setNegativeButton("Discard"){_,_->ApkgImporter.discardPending(this);Toast.makeText(this,"Interrupted import discarded",Toast.LENGTH_SHORT).show()}
            .setPositiveButton("Resume"){_,_->resumeImport()}.show()
    }
    private fun resumeImport(){runImport { control -> ApkgImporter.resume(this,{msg->mainHandler.post{currentImportDialog?.setMessage(msg)}},control) }}
    private var currentImportDialog:AlertDialog?=null
    private fun importUri(uri:android.net.Uri){
        try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Throwable){}
        runImport { control -> ApkgImporter.importFile(this,uri,{msg->mainHandler.post{currentImportDialog?.setMessage(msg)}},control) }
    }
    private fun runImport(job:(ApkgImporter.Control)->ApkgImporter.Result){
        val control=ApkgImporter.Control()
        importControl=control
        val dialog=AlertDialog.Builder(this).setTitle("Importing flashcards")
            .setMessage("Starting…\nThe import can resume if interrupted.").setCancelable(false)
            .setNegativeButton("Cancel import",null).create()
        currentImportDialog=dialog
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                control.cancelled=true
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).isEnabled=false
                dialog.setMessage("Stopping safely at the last checkpoint…")
            }
        }
        dialog.show()
        executor.execute {
            try {
                val r=job(control)
                runOnUiThread {
                    if(!isFinishing){
                        dialog.dismiss(); currentImportDialog=null; importControl=null
                        Toast.makeText(this,"Imported ${r.cards} cards from ${r.decks} deck(s)${if(r.skipped>0)" • skipped ${r.skipped} damaged item(s)" else ""}",Toast.LENGTH_LONG).show()
                        safeRender()
                    }
                }
            } catch(e:Throwable) {
                runOnUiThread {
                    if(!isFinishing){
                        dialog.dismiss(); currentImportDialog=null; importControl=null
                        val pending=ApkgImporter.hasPending(this)
                        AlertDialog.Builder(this)
                            .setTitle(if(control.cancelled)"Import paused safely" else "Import needs attention")
                            .setMessage(if(pending){
                                "The completed batches are safe.\n\n${if(control.cancelled)"The import was cancelled at a checkpoint." else (e.message ?: "An import error occurred.")}\n\nYou can resume from the last checkpoint without starting over."
                            } else (e.message ?: "unsupported or damaged deck"))
                            .setNegativeButton("Close",null)
                            .setPositiveButton("Resume"){_,_->resumeImport()}
                            .show()
                    }
                }
            }
        }
    }

    private data class Node(val name:String,val full:String,val depth:Int,val deck:FlashcardDb.Deck?,val children:MutableList<Node>)
    private fun safeRender(){
        if(!::list.isInitialized)return
        runCatching { render() }.onFailure {
            list.removeAllViews()
            list.addView(TextView(this).apply {
                text="Flashcard library could not be loaded. Your QBank data is unaffected.\n\n${it.javaClass.simpleName}: ${it.message ?: "unknown error"}"
                textSize=14f; setTextColor(ThemeManager.text(this@FlashcardActivity)); setPadding(dp(16),dp(24),dp(16),dp(24))
            })
        }
    }

    private fun render(){if(!::list.isInitialized)return;list.removeAllViews();refreshTop();val decks=db.decks();if(decks.isEmpty()){list.addView(TextView(this).apply{text="No flashcard decks yet. Import an .apkg deck to begin.";textSize=15f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(dp(12),dp(24),dp(12),dp(24))});return};val byFull=decks.associateBy{it.name};val roots=mutableListOf<Node>();val nodes=HashMap<String,Node>();fun nodeFor(path:String):Node{nodes[path]?.let{return it};val parts=path.split("::");val node=Node(parts.last(),parts.joinToString("::"),parts.size-1,byFull[parts.joinToString("::")],mutableListOf());nodes[node.full]=node;if(parts.size>1){val parent=nodeFor(parts.dropLast(1).joinToString("::"));parent.children.add(node)}else roots.add(node);return node};decks.forEach{nodeFor(it.name)}
        fun countTree(n:Node):Int=(n.deck?.count?:0)+n.children.sumOf{countTree(it)}
        fun addNode(n:Node){val own=n.deck;val has=n.children.isNotEmpty();val total=countTree(n);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10+n.depth*20),dp(9),dp(10),dp(9));background=GradientDrawable().apply{setColor(if(n.depth==0) semanticFill("neutral") else ThemeManager.elevated(this@FlashcardActivity));cornerRadius=14f}};val arrow=TextView(this).apply{text=if(has){if(expanded.contains(n.full))"▼" else "▶"}else"•";textSize=14f;setTextColor(ThemeManager.accent(this@FlashcardActivity));gravity=Gravity.CENTER};row.addView(arrow,LinearLayout.LayoutParams(dp(28),dp(48)));val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL};body.addView(TextView(this).apply{text=n.name;textSize=if(n.depth==0)17f else 15.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@FlashcardActivity));maxLines=2});body.addView(TextView(this).apply{
                    if(own!=null){
                        val ds=db.dueStats(own.id)
                        text=when {
                            ds.due>0 -> "${own.count} cards  •  ${ds.due} due now  •  Learning ${ds.learning}  •  Hard ${ds.hard}  •  Good ${ds.good}  •  Easy ${ds.easy}"
                            else -> "${own.count} cards  •  0 due now  •  Next reviews are scheduled automatically"
                        }
                    } else text=if(has)"$total cards  •  subdecks" else "Category"
                    textSize=11.5f;setTextColor(ThemeManager.muted(this@FlashcardActivity));setPadding(0,dp(3),0,0);maxLines=3
                });row.addView(body,LinearLayout.LayoutParams(0,-2,1f));if(own!=null&&own.count>0){val study=button("STUDY",Color.rgb(35,103,120)){startStudy(own.id)};row.addView(study,LinearLayout.LayoutParams(dp(62),dp(38)).apply{setMargins(dp(6),0,0,0)})};row.setOnClickListener{if(has){if(expanded.contains(n.full))expanded.remove(n.full)else expanded.add(n.full);render()}else if(own!=null)startStudy(own.id)};row.setOnLongClickListener{showDeckActions(n);true};list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(4),dp(4),dp(4),dp(4))});if(expanded.contains(n.full))n.children.sortedBy{it.name.lowercase()}.forEach{addNode(it)}};roots.sortedBy{it.name.lowercase()}.forEach{addNode(it)} }

    private fun showStudyMenu(){
        val labels=arrayOf("Due now  •  ${db.modeCount("due")}","All cards  •  ${db.modeCount("all")}","New / unseen  •  ${db.modeCount("unseen")}","Hard  •  ${db.modeCount("hard")}","Again / failed  •  ${db.modeCount("again")}","Bookmarked  •  ${db.modeCount("bookmarked")}","Marked  •  ${db.modeCount("marked")}","10-card sprint","25-card sprint","50-card sprint","100-card sprint")
        val modes=arrayOf("due","all","unseen","hard","again","bookmarked","marked","all","all","all","all")
        val limits=intArrayOf(0,0,0,0,0,0,0,10,25,50,100)
        AlertDialog.Builder(this).setTitle("Choose a study set").setItems(labels){_,which->startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",-1L).putExtra("mode",modes[which]).putExtra("limit",limits[which]))}.show()
    }

    private fun showSrsSettings(){
        val fields=arrayOf("New cards / day","Max reviews / day","Again learning delay (minutes)")
        val keys=arrayOf("new_per_day","max_reviews_per_day","learning_again_min")
        val defaults=intArrayOf(30,200,10)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(24),dp(8),dp(24),0)}
        val inputs=fields.indices.map{i->EditText(this).apply{hint=fields[i];inputType=2;setText(db.settingInt(keys[i],defaults[i]).toString());setSingleLine(true);setPadding(0,dp(10),0,dp(10));box.addView(this)}}
        AlertDialog.Builder(this).setTitle("Flashcard SRS settings").setView(box).setMessage("Good: 3 days for new cards • Easy: 7 days • Again: learning delay.\nThese settings are stored locally and do not affect your QBank.").setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->inputs.forEachIndexed{i,v->db.setSetting(keys[i],v.text.toString().toIntOrNull()?.coerceAtLeast(1)?.toString()?:defaults[i].toString())};Toast.makeText(this,"SRS settings saved",Toast.LENGTH_SHORT).show();safeRender()}.show()
    }

    private fun showStats(){val today=db.reviewedToday();val total=db.totalReviews();val due=db.reviewCount();val all=db.modeCount("all");AlertDialog.Builder(this).setTitle("Flashcard statistics").setMessage("Today\n• Reviewed: $today\n• Remaining due: $due\n\nLibrary\n• Total cards: $all\n• Total reviews: $total\n• Bookmarked: ${db.bookmarkCount()}\n\nDaily limits\n• New: ${db.settingInt("new_per_day",30)}\n• Reviews: ${db.settingInt("max_reviews_per_day",200)}").setPositiveButton("Close",null).show()}


    private fun startStudy(id:Long){startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",id))}
    private fun startReview(bookmarks:Boolean){startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("deckId",-1L).putExtra("bookmarksOnly",bookmarks))}
    private fun showDeckActions(n:Node){val own=n.deck;val options=if(n.children.isNotEmpty())arrayOf("Study deck","Unsuspend cards","Delete this deck","Delete this deck + all subdecks")else arrayOf("Study deck","Unsuspend cards","Delete deck");AlertDialog.Builder(this).setTitle(n.full).setItems(options){_,which->when(which){0->if(own!=null&&own.count>0)startStudy(own.id)else Toast.makeText(this,"This category has no cards of its own.",Toast.LENGTH_SHORT).show();1->if(own!=null){val n2=db.unsuspendDeck(own.id,false);Toast.makeText(this,"Unsuspended $n2 card(s)",Toast.LENGTH_SHORT).show();safeRender()};2->if(own!=null)confirmDelete(n,false);3->if(own!=null)confirmDelete(n,true)}}.show()}
    private fun confirmDelete(n:Node,all:Boolean){val msg=if(all)"Delete ${n.full} and every subdeck? This removes their flashcards from this app."else"Delete ${n.full}? This removes its flashcards from this app.";AlertDialog.Builder(this).setTitle("Delete deck").setMessage(msg).setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->val removed=if(n.deck!=null)db.deleteDeck(n.deck.id,all)else 0;Toast.makeText(this,"Deleted $removed deck(s)",Toast.LENGTH_SHORT).show();safeRender()}.show()}
    override fun onDestroy(){AppState.unregister(stateListener);executor.shutdownNow();if(::db.isInitialized)db.close();super.onDestroy()}
}
