package com.localqbank.library

/** Explicit contracts keep autonomous coordination bounded and auditable. */
data class ManagerContract(
    val name: String,
    val inputs: List<String>,
    val outputs: List<String>,
    val allowedMutations: List<String>,
    val failureMode: String,
    val threadPolicy: String
)

object ManagerContractRegistry {
    val all: List<ManagerContract> = listOf(
        ManagerContract("PerformanceManager", listOf("latency", "memory"), listOf("runtime policy"),
            listOf("prefetch depth", "cache TTL", "safe mode"), "safe defaults", "background only for I/O"),
        ManagerContract("AnalyticsManager", listOf("progress", "question refs"), listOf("AnalyticsSnapshot"),
            emptyList(), "last valid snapshot", "derived work off UI"),
        ManagerContract("DashboardManager", listOf("analytics", "progress", "sources"), listOf("DashboardModel"),
            emptyList(), "last valid model when available", "background build"),
        ManagerContract("BackupManager", listOf("persistent state"), listOf("validated backup"),
            listOf("backup/restore data only"), "abort and preserve current state", "durable background work"),
        ManagerContract("AdaptiveEngine", listOf("typed events", "runtime metrics"), listOf("bounded action proposal"),
            listOf("approved PerformanceManager policies only"), "safe mode / no-op", "single serial worker"),
        ManagerContract("BenIntelligenceOrchestrator", listOf("user intent", "capability registry"), listOf("validated capability plan"),
            listOf("registered derived-data operations and session selection"), "guardian rejection / no-op", "short deterministic dispatch; background work delegated"),
        ManagerContract("IntelligenceGuardian", listOf("capability", "health", "safe mode"), listOf("allow/deny"),
            emptyList(), "deny by default on uncertainty", "synchronous and bounded"),
        ManagerContract("FlashcardIntelligence", listOf("question ids"), listOf("generated cards"),
            listOf("derived flashcard data only"), "skip failed card", "background worker"),
        ManagerContract("KnowledgeEngine", listOf("question/explanation"), listOf("notes", "tables", "images"),
            listOf("derived knowledge data only"), "preserve source and return safe failure", "background for I/O; view capture on UI thread"),
    )
}
