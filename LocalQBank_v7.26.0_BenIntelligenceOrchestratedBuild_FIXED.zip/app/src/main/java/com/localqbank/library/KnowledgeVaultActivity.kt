package com.localqbank.library

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

/** Local viewer for derived notes, saved tables and copied learning images. */
class KnowledgeVaultActivity : Activity() {
    private lateinit var list: LinearLayout
    private val dp get() = resources.displayMetrics.density
    private fun d(v: Int) = (v * dp).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SystemUi.immersive(this)
        setContentView(build())
        render()
    }

    private fun build(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(ThemeManager.bg(this@KnowledgeVaultActivity)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(d(12), d(8), d(12), d(8)) }
        bar.addView(TextView(this).apply { text = "‹"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(ThemeManager.text(this@KnowledgeVaultActivity)); setOnClickListener { finish() } }, LinearLayout.LayoutParams(d(44), d(44)))
        bar.addView(TextView(this).apply { text = "Knowledge Vault"; textSize = 21f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@KnowledgeVaultActivity)) }, LinearLayout.LayoutParams(0, d(44), 1f))
        root.addView(bar)
        root.addView(TextView(this).apply { text = "Auto-created from wrong and important questions. Original QBank data stays unchanged."; textSize = 12.5f; setTextColor(ThemeManager.muted(this@KnowledgeVaultActivity)); setPadding(d(16), 0, d(16), d(12)) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(14), 0, d(14), d(20)) }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun render() {
        list.removeAllViews()
        val root = File(filesDir, "knowledge")
        val notes = File(root, "notes").listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        val tables = File(root, "tables").listFiles()?.sortedBy { it.name } ?: emptyList()
        val images = File(root, "images").listFiles()?.sortedBy { it.name } ?: emptyList()
        addSection("NOTES", "${notes.size} generated summaries")
        notes.take(100).forEach { file -> addRow(file.nameWithoutExtension.replace('_', ' '), "Generated study summary", file) }
        addSection("TABLES", "${tables.size} copied table fragments")
        tables.take(100).forEach { file -> addRow(file.nameWithoutExtension.replace('_', ' '), "Saved source table", file) }
        addSection("IMAGES", "${images.size} copied learning images")
        images.take(100).forEach { file -> addRow(file.nameWithoutExtension.replace('_', ' '), "Saved image", file) }
        if (notes.isEmpty() && tables.isEmpty() && images.isEmpty()) list.addView(TextView(this).apply { text = "Your adaptive knowledge collection will appear here after you answer wrong questions or mark questions Important."; textSize = 14f; setTextColor(ThemeManager.muted(this@KnowledgeVaultActivity)); setPadding(d(12), d(24), d(12), d(24)) })
    }

    private fun addSection(title: String, subtitle: String) {
        list.addView(TextView(this).apply { text = title; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.accent(this@KnowledgeVaultActivity)); setPadding(d(4), d(14), d(4), d(4)) })
        list.addView(TextView(this).apply { text = subtitle; textSize = 12f; setTextColor(ThemeManager.muted(this@KnowledgeVaultActivity)); setPadding(d(4), 0, d(4), d(7)) })
    }

    private fun addRow(title: String, sub: String, file: File) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(14), d(11), d(14), d(11)); background = GradientDrawable().apply { setColor(ThemeManager.elevated(this@KnowledgeVaultActivity)); cornerRadius = d(14).toFloat() }; setOnClickListener { open(file, sub) } }
        row.addView(TextView(this).apply { text = title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ThemeManager.text(this@KnowledgeVaultActivity)) })
        row.addView(TextView(this).apply { text = sub; textSize = 11.5f; setTextColor(ThemeManager.muted(this@KnowledgeVaultActivity)); setPadding(0, d(3), 0, 0) })
        list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, d(4), 0, d(4)) })
    }

    private fun open(file: File, kind: String) {
        if (!file.exists()) return
        if (kind == "Saved image") {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            val sample = if (bounds.outWidth > 1600 || bounds.outHeight > 1600) 2 else 1
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = android.graphics.Bitmap.Config.RGB_565 }
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, opts)
            val iv = ImageView(this).apply { adjustViewBounds = true; setPadding(d(8), d(8), d(8), d(8)); setImageBitmap(bitmap) }
            AlertDialog.Builder(this).setTitle("Saved learning image").setView(iv).setPositiveButton("Close", null).show()
        } else {
            val text = runCatching { file.readText().take(20000) }.getOrDefault("Unable to read this artifact.")
            AlertDialog.Builder(this).setTitle(if (kind == "Saved source table") "Saved table" else "Study note").setMessage(if (kind == "Saved source table") android.text.Html.fromHtml(text, android.text.Html.FROM_HTML_MODE_LEGACY) else text).setPositiveButton("Close", null).show()
        }
    }
}
