package com.localqbank.library

import android.content.Context
import java.util.concurrent.Executors

/**
 * Creates deterministic, local flashcards from source questions. It never changes
 * the source QBank and is idempotent by front/back content.
 */
class FlashcardIntelligenceManager(context: Context) {
    private val app = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "flashcard-intelligence") }

    data class Result(val created: Int, val skipped: Int, val deckName: String)


    data class EngineStats(val generatedDeckPrefix:String = "Adaptive", val available:Boolean = true)
    fun stats(): EngineStats = EngineStats()

    fun createFromQuestions(ids: LongArray, reason: String = "adaptive"): Result {
        if (ids.isEmpty()) return Result(0, 0, "")
        return runCatching {
            val qdb = QBankDb(app)
            val fdb = FlashcardDb(app)
            try {
                val questions = ids.distinct().take(100).mapNotNull { qdb.questionById(it) }
                val deckName = fdb.normalizeDeckName("Adaptive :: ${if (reason.isBlank()) "Learning" else reason.take(36)}")
                val deckId = fdb.upsertDeckForImport(deckName, "LocalQBank Adaptive")
                var created = 0
                var skipped = 0
                questions.forEach { q ->
                    val front = plain(q.text).take(900).trim()
                    val answer = plain(q.correctAnswer ?: q.options.firstOrNull { it.correct }?.label ?: "").trim()
                    val back = buildString {
                        if (answer.isNotBlank()) append("Answer: ").append(answer)
                        val exp = plain(q.explanation.orEmpty()).trim()
                        if (exp.isNotBlank()) append(if (isNotEmpty()) "\n\n" else "").append(exp.take(1800))
                    }.trim()
                    if (front.isBlank() || back.isBlank()) { skipped++; return@forEach }
                    if (fdb.upsertGeneratedCard(deckId, front, back, "adaptive,${reason.take(24)}")) created++ else skipped++
                }
                fdb.setDeckCount(deckId, fdb.cardCount(deckId))
                Result(created, skipped, deckName)
            } finally { qdb.close(); fdb.close() }
        }.getOrDefault(Result(0, ids.size, ""))
    }

    fun createFromWrongQuestionsAsync(limit: Int = 25, onDone: (Result) -> Unit) {
        executor.execute {
            val result = createFromWrongQuestions(limit)
            android.os.Handler(android.os.Looper.getMainLooper()).post { onDone(result) }
        }
    }

    fun createFromWrongQuestions(limit: Int = 25): Result {
        val refs = PerformanceManager.refs(app)
        val progress = PerformanceManager.progress(app)
        val ids = refs.asSequence().filter { progress.record(it.stableKey)?.status == "wrong" }
            .sortedByDescending { progress.record(it.stableKey)?.attempts ?: 0 }
            .take(limit.coerceIn(1, 100)).map { it.id }.toList().toLongArray()
        return createFromQuestions(ids, "Wrong Questions")
    }

    fun createFromQuestionsAsync(ids: LongArray, reason: String = "adaptive", onDone: (Result) -> Unit) {
        executor.execute { val result = createFromQuestions(ids, reason); android.os.Handler(android.os.Looper.getMainLooper()).post { onDone(result) } }
    }

    private fun plain(html: String): String = android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()
}
