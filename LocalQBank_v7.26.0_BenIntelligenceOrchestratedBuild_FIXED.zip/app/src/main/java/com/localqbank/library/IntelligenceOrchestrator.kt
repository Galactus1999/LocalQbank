package com.localqbank.library

import android.content.Context

/** Single coordination facade for future Ben commands and in-app smart actions. */
class IntelligenceOrchestrator(context: Context) {
    private val app = context.applicationContext
    private val bio by lazy { BenIntelligenceOrchestrator(app) }

    data class Plan(val command: String, val questionIds: LongArray, val explanation: String)

    fun plan(command: String, limit: Int = 50): Plan {
        val routed = bio.plan(command, limit)
        val text = command.trim()
        if (text.isBlank()) return Plan(text, longArrayOf(), "Tell me a subject, topic, or study goal.")
        if (routed.capability != null && routed.accepted && routed.questionIds.isNotEmpty()) return Plan(text, routed.questionIds, routed.explanation)
        val lower = text.lowercase()
        return when {
            "wrong" in lower || "mistake" in lower -> {
                val ids = AppManagers.studyIntelligence.smartMix(limit).filter { id ->
                    val ref = PerformanceManager.refs(app).firstOrNull { it.id == id } ?: return@filter false
                    PerformanceManager.progress(app).record(ref.stableKey)?.status == "wrong"
                }.take(limit).toLongArray()
                Plan(text, ids, "Prioritised your wrong questions.")
            }
            else -> {
                val match = AppManagers.studyIntelligence.matchSubject(text, limit)
                Plan(text, match.ids, AppManagers.studyIntelligence.explain(text, match.matched))
            }
        }
    }

    fun createFlashcardsFromPlan(plan: Plan, reason: String = "Ben plan"): FlashcardIntelligenceManager.Result =
        AppManagers.flashcardIntelligence.createFromQuestions(plan.questionIds, reason)

    fun captureKnowledge(question: Question, reason: String = "Ben capture"): KnowledgeEngineManager.Result =
        AppManagers.knowledge.captureQuestion(question, reason)
}
