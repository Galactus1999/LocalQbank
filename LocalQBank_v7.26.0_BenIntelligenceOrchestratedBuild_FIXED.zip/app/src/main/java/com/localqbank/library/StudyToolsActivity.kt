package com.localqbank.library

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class StudyToolsActivity: AppCompatActivity(){
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
    override fun onCreate(b:Bundle?){super.onCreate(b);AppManagers.initialize(applicationContext);SystemUi.immersive(this);db=QBankDb(this);store=ProgressStore(this);setContentView(build());if(intent.getBooleanExtra("openSubjectFocus",false))window.decorView.post{subjectFocusDialog()}}
    private fun build():ScrollView{
        val scroll=ScrollView(this).apply{setBackgroundColor(ThemeManager.bg(this@StudyToolsActivity));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(28))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val back=button("←",14f){finish()};bar.addView(back,LinearLayout.LayoutParams(dp(54),dp(52)))
        val title=TextView(this).apply{text="Study Tools";textSize=24f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@StudyToolsActivity));setPadding(dp(12),0,0,0)}
        bar.addView(title,LinearLayout.LayoutParams(0,dp(52),1f));root.addView(bar)
        val intro=TextView(this).apply{text="Turn your imported QBank into a revision and exam system. All tools use the same question database and progress.";textSize=14f;setTextColor(ThemeManager.muted(this@StudyToolsActivity));setPadding(0,dp(10),0,dp(16))};root.addView(intro)
        addTool(root,"Today's Revision","Due questions • spaced revision", "REVISION"){launchCollection(dueIds(),"Today's Revision",true)}
        addTool(root,"Adaptive Smart Mix","A personalised mix from your current learning state", "SMART"){val ids=AppManagers.studyIntelligence.smartMix(100);launchCollection(ids,"Adaptive Smart Mix",true)}
        addTool(root,"Weakest 50","Wrong + low-performing questions first", "FOCUS"){launchCollection(weakIds(),"Weakest 50",true)}
        addTool(root,"Unsolved Sprint","Fresh questions you have not attempted", "BUILD"){launchCollection(unsolvedIds(),"Unsolved Sprint",true)}
        addTool(root,"Wrong Questions","Reattempt your mistakes", "CORRECT"){launchCollection(wrongIds(),"Wrong Questions",true)}
        addTool(root,"PYQ Mode","Questions labelled as previous-year questions", "EXAM"){pyqIds().let{launchCollection(it,"PYQ",true)}}
        addTool(root,"Subject Focus","Type a subject or topic and build a focused question set", "FOCUS"){subjectFocusDialog()}
        addTool(root,"Exam Mode","Timed block • submit once at the end", "TIMED"){examDialog()}
        addTool(root,"Custom Test","Choose size and question pool", "CUSTOM"){customDialog()}
        addTool(root,"My Notes","Saved notes and memory cues", "NOTES"){startActivity(Intent(this,NotesActivity::class.java))}
        addTool(root,"Knowledge Vault","Auto-notes, copied tables and learning images", "VAULT"){startActivity(Intent(this,KnowledgeVaultActivity::class.java))}
        addTool(root,"Adaptive Flashcards","Generate cards from your wrong questions", "CARDS"){
            AppManagers.flashcardIntelligence.createFromWrongQuestionsAsync(50) { result ->
                if (isFinishing || isDestroyed) return@createFromWrongQuestionsAsync
                Toast.makeText(this,"Created ${result.created} new adaptive cards",Toast.LENGTH_SHORT).show()
                startActivity(Intent(this,FlashcardActivity::class.java))
            }
        }
        val hint=TextView(this).apply{text="Tip: use Today's Revision daily, then Weakest 50 when your accuracy plateaus.";textSize=13f;setTextColor(ThemeManager.muted(this@StudyToolsActivity));setPadding(dp(4),dp(18),dp(4),0)};root.addView(hint)
        scroll.addView(root);return scroll
    }
    private fun addTool(root:LinearLayout,title:String,sub:String,tag:String,click:()->Unit){
        val dark=ThemeManager.isDark(this)
        val card=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(12),dp(12),dp(12));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@StudyToolsActivity));cornerRadius=dp(15).toFloat();setStroke(dp(1),if(dark)Color.rgb(45,57,70) else Color.rgb(222,227,231))};setOnClickListener{click()}}
        val copy=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        copy.addView(TextView(this).apply{text=title;textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@StudyToolsActivity))})
        copy.addView(TextView(this).apply{text=sub;textSize=12.5f;setTextColor(ThemeManager.muted(this@StudyToolsActivity));setPadding(0,dp(4),0,0)})
        card.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
        card.addView(TextView(this).apply{text=tag;textSize=10f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@StudyToolsActivity));background=GradientDrawable().apply{setColor(ThemeManager.explanationBg(this@StudyToolsActivity));cornerRadius=dp(9).toFloat()};setPadding(dp(8),0,dp(8),0)},LinearLayout.LayoutParams(dp(70),dp(28)))
        card.addView(TextView(this).apply{text="›";textSize=25f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@StudyToolsActivity))},LinearLayout.LayoutParams(dp(28),dp(40)))
        root.addView(card,LinearLayout.LayoutParams(-1,dp(78)).apply{setMargins(0,dp(5),0,dp(5))})
    }
    private fun button(text:String,size:Float,click:()->Unit)=TextView(this).apply{this.text=text;textSize=size;gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@StudyToolsActivity));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@StudyToolsActivity));cornerRadius=dp(14).toFloat()};setOnClickListener{click()}}
    private fun launchCollection(ids:LongArray,label:String,practice:Boolean){if(ids.isEmpty()){Toast.makeText(this,"No questions available",Toast.LENGTH_SHORT).show();return};startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel",label).putExtra("practiceMode",practice).putExtra("title",label))}
    private fun dueIds():LongArray {
        val refs=PerformanceManager.refs(applicationContext); val p=PerformanceManager.progress(applicationContext); val now=System.currentTimeMillis()
        return refs.asSequence().filter { r -> val x=p.record(r.stableKey); x==null || x.lastAttempted==0L || (x.nextDue>0L && now>=x.nextDue) || (x.nextDue==0L && now-x.lastAttempted>=when(x.attempts){1->86_400_000L;2->3*86_400_000L;3->7*86_400_000L;4->14*86_400_000L;else->30*86_400_000L}) }.take(100).map{it.id}.toList().toLongArray()
    }
    private fun weakIds():LongArray {
        val refs=PerformanceManager.refs(applicationContext); val p=PerformanceManager.progress(applicationContext)
        return refs.sortedWith(compareBy<QuestionRef>{when(p.record(it.stableKey)?.status){"wrong"->0;null->1;else->2}}.thenByDescending{p.record(it.stableKey)?.attempts ?: 0}).take(50).map{it.id}.toLongArray()
    }
    private fun unsolvedIds():LongArray { val p=PerformanceManager.progress(applicationContext); return PerformanceManager.refs(applicationContext).filter{p.record(it.stableKey)?.status==null}.map{it.id}.toLongArray() }
    private fun wrongIds():LongArray { val p=PerformanceManager.progress(applicationContext); return PerformanceManager.refs(applicationContext).filter{p.record(it.stableKey)?.status=="wrong"}.sortedByDescending{p.record(it.stableKey)?.attempts ?: 0}.map{it.id}.toLongArray() }
    private fun pyqIds():LongArray{return PerformanceManager.refs(applicationContext).filter{it.sourceName.contains("pyq",true)||it.testTitle.contains("pyq",true)||it.category.contains("pyq",true)}.map{it.id}.toLongArray()}
    private fun noteIds():LongArray=db.notes().map{it.first}.toLongArray()

    private fun subjectFocusDialog(){
        val input=EditText(this).apply{
            hint="e.g. Pharmacology, Cardiology, Dermatology"
            textSize=16f
            setSingleLine(true)
            setPadding(dp(14),dp(12),dp(14),dp(12))
        }
        val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)}
        wrap.addView(input,LinearLayout.LayoutParams(-1,dp(58)))
        AlertDialog.Builder(this).setTitle("Subject Focus").setMessage("Enter a subject or topic. The local Study Intelligence engine ranks matching questions and prioritises due, wrong and unseen questions.").setView(wrap).setPositiveButton("Find Questions"){_,_->
            val subject=input.text.toString().trim()
            if(subject.isBlank()){Toast.makeText(this,"Enter a subject or topic",Toast.LENGTH_SHORT).show();return@setPositiveButton}
            val match=runCatching{AppManagers.studyIntelligence.matchSubject(subject,500)}.getOrNull()
            if(match==null || match.ids.isEmpty()){Toast.makeText(this,AppManagers.studyIntelligence.explain(subject,0),Toast.LENGTH_LONG).show();return@setPositiveButton}
            val sizes=arrayOf("20 questions","50 questions","100 questions","All matched")
            AlertDialog.Builder(this).setTitle("${match.matched} questions matched").setItems(sizes){_,which->
                val n=when(which){0->20;1->50;2->100;else->match.ids.size}
                val ids=match.ids.toList().take(n).toLongArray()
                launchCollection(ids,"Subject • $subject",true)
            }.setNegativeButton("Cancel",null).show()
        }.setNegativeButton("Cancel",null).show()
    }

    private fun customDialog(){
        val counts=arrayOf("10","20","50","100","200");var count=20
        val options=arrayOf("All questions","Unsolved","Wrong","Solved","Bookmarked","Important","Revise","Doubt","Favourite")
        var selected=0
        AlertDialog.Builder(this).setTitle("Custom Test").setSingleChoiceItems(options,0){_,which->selected=which}.setPositiveButton("Choose size"){_,_->AlertDialog.Builder(this).setTitle("Number of questions").setItems(counts){_,w->count=counts[w].toInt();val ids=pool(selected).shuffled().take(count).toLongArray();launchCollection(ids,"Custom Test • $count",true)}.show()}.setNegativeButton("Cancel",null).show()
    }
    private fun pool(which:Int):List<Long>{
        val p=PerformanceManager.progress(applicationContext)
        return PerformanceManager.refs(applicationContext).filter{r->when(which){0->true;1->p.record(r.stableKey)?.status==null;2->p.record(r.stableKey)?.status=="wrong";3->p.record(r.stableKey)?.status=="correct";4->!p.record(r.stableKey)?.bookmark.isNullOrBlank();5->p.record(r.stableKey)?.bookmark=="important";6->p.record(r.stableKey)?.bookmark=="revise";7->p.record(r.stableKey)?.bookmark=="doubt";8->{val b=p.record(r.stableKey)?.bookmark;b=="favorite"||b=="favourite"};else->true}}.map{it.id}
    }
    private fun examDialog(){val counts=arrayOf("20","50","100","200");AlertDialog.Builder(this).setTitle("Exam Mode").setItems(counts){_,w->val n=counts[w].toInt();val ids=PerformanceManager.refs(applicationContext).shuffled().take(n).map{it.id};val mins=(n*1.2).roundToInt().coerceAtLeast(10);startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Exam • $n Q").putExtra("examMode",true).putExtra("examDurationMinutes",mins).putExtra("title","Exam Mode"))}.setNegativeButton("Cancel",null).show()}
    override fun onDestroy(){db.close();super.onDestroy()}
}
