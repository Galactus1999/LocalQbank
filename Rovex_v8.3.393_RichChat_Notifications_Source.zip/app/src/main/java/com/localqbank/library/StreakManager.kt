package com.localqbank.library

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.TimeUnit

/**
 * Durable study-streak and user-controlled daily notification owner.
 *
 * Study/streak state remains authoritative in qbank.db. Notifications are presentation-only:
 * they never mutate study data, never invoke Ben, and never create a second study event pipeline.
 * Daily notifications use one-shot WorkManager jobs scheduled for the next local clock time and
 * reschedule themselves after execution. This avoids a 24-hour interval drifting across days.
 */
class StreakManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("streak_settings", Context.MODE_PRIVATE)
    private val listener: (StudyEventSpine.Event) -> Unit = { event ->
        when (event.name) {
            "quiz_completed", "flashcard_reviewed" -> PerformanceManager.submit {
                recordStudyDay(event.timestamp)
            }
        }
    }

    init {
        StudyEventSpine.subscribe(listener)
        // Reminder scheduling is maintenance work, not startup-critical UI work.
        PerformanceManager.submitMaintenance { scheduleReminder() }
    }

    fun recordStudyDay(timestamp: Long = System.currentTimeMillis()): Snapshot =
        resultOf {
            val db = QBankDb(app)
            try {
                synchronized(streakMutationLock) {
                    val before = db.readStudyStreak()
                    val snapshot = db.recordStudyStreakDay(timestamp)
                    val day = snapshot.currentStreak
                    if (day > before.currentStreak && day in MILESTONE_DAYS) {
                        StudyEventSpine.publishAsync(
                            StudyEventSpine.Event(
                                "streak_milestone",
                                source = "streak",
                                metadata = mapOf("days" to day.toString())
                            )
                        )
                    }
                    snapshot
                }
            } finally {
                db.close()
            }
        }.getOrElse { Snapshot() }

    fun snapshot(): Snapshot = QBankDb(app).let { db ->
        try { db.readStudyStreak() } finally { db.close() }
    }

    fun notificationsEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, true)

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (enabled) {
            PerformanceManager.submitMaintenance { scheduleReminder() }
        } else {
            cancelNotificationWork()
        }
    }

    fun dailyQuoteEnabled(): Boolean = prefs.getBoolean(KEY_QUOTE_ENABLED, true)

    fun setDailyQuoteEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_QUOTE_ENABLED, enabled).apply()
        if (!notificationsEnabled()) return
        if (enabled) scheduleDailyQuote() else WorkManager.getInstance(app).cancelUniqueWork(DAILY_QUOTE_WORK_NAME)
    }

    fun dailyTargetEnabled(): Boolean = prefs.getBoolean(KEY_TARGET_ENABLED, true)

    fun setDailyTargetEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_TARGET_ENABLED, enabled).apply()
        if (!notificationsEnabled()) return
        if (enabled) scheduleDailyTarget() else WorkManager.getInstance(app).cancelUniqueWork(DAILY_TARGET_WORK_NAME)
    }

    fun dailyQuoteHour(): Int = prefs.getInt(KEY_QUOTE_HOUR, 8).coerceIn(0, 23)
    fun dailyQuoteMinute(): Int = prefs.getInt(KEY_QUOTE_MINUTE, 0).coerceIn(0, 59)
    fun dailyTargetHour(): Int = prefs.getInt(KEY_TARGET_HOUR, 20).coerceIn(0, 23)
    fun dailyTargetMinute(): Int = prefs.getInt(KEY_TARGET_MINUTE, 0).coerceIn(0, 59)

    fun setDailyQuoteTime(hour: Int, minute: Int) {
        prefs.edit().putInt(KEY_QUOTE_HOUR, hour.coerceIn(0, 23))
            .putInt(KEY_QUOTE_MINUTE, minute.coerceIn(0, 59)).apply()
        if (notificationsEnabled() && dailyQuoteEnabled()) {
            PerformanceManager.submitMaintenance { scheduleDailyQuote() }
        }
    }

    fun setDailyTargetTime(hour: Int, minute: Int) {
        prefs.edit().putInt(KEY_TARGET_HOUR, hour.coerceIn(0, 23))
            .putInt(KEY_TARGET_MINUTE, minute.coerceIn(0, 59)).apply()
        if (notificationsEnabled() && dailyTargetEnabled()) {
            PerformanceManager.submitMaintenance { scheduleDailyTarget() }
        }
    }

    fun shouldPromptNotificationPermission(): Boolean = notificationsEnabled() && QBankDb(app).let { db ->
        try { !db.notificationPermissionPrompted() } finally { db.close() }
    }

    fun markNotificationPermissionPrompted() {
        QBankDb(app).let { db -> try { db.markNotificationPermissionPrompted() } finally { db.close() } }
    }

    private fun scheduleReminder() {
        if (!notificationsEnabled()) return
        scheduleStreakReminder()
        if (dailyQuoteEnabled()) scheduleDailyQuote()
        else WorkManager.getInstance(app).cancelUniqueWork(DAILY_QUOTE_WORK_NAME)
        if (dailyTargetEnabled()) scheduleDailyTarget()
        else WorkManager.getInstance(app).cancelUniqueWork(DAILY_TARGET_WORK_NAME)
    }

    private fun scheduleStreakReminder() {
        val request = PeriodicWorkRequestBuilder<StreakReminderWorker>(24, TimeUnit.HOURS, 6, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(app).enqueueUniquePeriodicWork(
            STREAK_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun scheduleDailyQuote() {
        enqueueAtLocalTime(
            DAILY_QUOTE_WORK_NAME,
            dailyQuoteHour(),
            dailyQuoteMinute(),
            DailyMotivationWorker::class.java
        )
    }

    private fun scheduleDailyTarget() {
        enqueueAtLocalTime(
            DAILY_TARGET_WORK_NAME,
            dailyTargetHour(),
            dailyTargetMinute(),
            DailyTargetReminderWorker::class.java
        )
    }

    private fun <T : Worker> enqueueAtLocalTime(
        workName: String,
        hour: Int,
        minute: Int,
        workerClass: Class<T>
    ) {
        val now = java.time.ZonedDateTime.now(ZoneId.systemDefault())
        val delay = RovexDailyNotificationContent.nextTriggerMillis(now, hour, minute)
        val request = OneTimeWorkRequestBuilder<T>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(app).enqueueUniqueWork(workName, ExistingWorkPolicy.REPLACE, request)
    }

    private fun cancelNotificationWork() {
        WorkManager.getInstance(app).cancelUniqueWork(STREAK_WORK_NAME)
        WorkManager.getInstance(app).cancelUniqueWork(DAILY_QUOTE_WORK_NAME)
        WorkManager.getInstance(app).cancelUniqueWork(DAILY_TARGET_WORK_NAME)
    }

    data class Snapshot(
        val currentStreak: Int = 0,
        val longestStreak: Int = 0,
        val totalStudyDays: Int = 0,
        val lastStudyDay: String? = null
    )

    private companion object {
        val streakMutationLock = Any()
        val MILESTONE_DAYS = setOf(3, 7, 14, 30, 60, 100)
        const val KEY_ENABLED = "enabled"
        const val KEY_QUOTE_ENABLED = "daily_quote_enabled"
        const val KEY_TARGET_ENABLED = "daily_target_enabled"
        const val KEY_QUOTE_HOUR = "daily_quote_hour"
        const val KEY_QUOTE_MINUTE = "daily_quote_minute"
        const val KEY_TARGET_HOUR = "daily_target_hour"
        const val KEY_TARGET_MINUTE = "daily_target_minute"
    }
}

private const val STREAK_WORK_NAME = "rovex_daily_streak_reminder"
private const val DAILY_QUOTE_WORK_NAME = "rovex_daily_motivation"
private const val DAILY_TARGET_WORK_NAME = "rovex_daily_target_reminder"
private const val STREAK_CHANNEL_ID = "rovex_study_reminders"
private const val MOTIVATION_CHANNEL_ID = "rovex_daily_motivation"
private const val TARGET_CHANNEL_ID = "rovex_daily_target"
private const val STREAK_NOTIFICATION_ID = 8401
private const val MOTIVATION_NOTIFICATION_ID = 8402
private const val TARGET_NOTIFICATION_ID = 8403

fun maybeRequestStudyNotificationPermission(activity: android.app.Activity) {
    if (!AppManagers.isReady() || !AppManagers.streak.notificationsEnabled()) return
    if (android.os.Build.VERSION.SDK_INT < 33) return
    if (activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
    PerformanceManager.submit {
        if (!AppManagers.streak.shouldPromptNotificationPermission()) return@submit
        AppManagers.streak.markNotificationPermissionPrompted()
        activity.runOnUiThread {
            if (!activity.isFinishing && !activity.isDestroyed &&
                activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8402)
            }
        }
    }
}

private fun canPostRovexNotification(context: Context): Boolean {
    if (!AppManagers.streak.notificationsEnabled()) return false
    if (android.os.Build.VERSION.SDK_INT >= 33 &&
        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false
    return NotificationManagerCompat.from(context).areNotificationsEnabled()
}

private fun notificationContentIntent(context: Context): PendingIntent? =
    runCatching {
        PendingIntent.getActivity(
            context,
            8400,
            Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }.getOrNull()

internal fun postStreakNotification(context: Context, snapshot: StreakManager.Snapshot): Boolean {
    if (snapshot.currentStreak <= 0 || !canPostRovexNotification(context)) return false
    val manager = context.getSystemService(NotificationManager::class.java)
    if (manager.getNotificationChannel(STREAK_CHANNEL_ID) == null) {
        manager.createNotificationChannel(
            NotificationChannel(
                STREAK_CHANNEL_ID,
                "Study reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Daily Rovex study and streak reminders" }
        )
    }
    val content = if (snapshot.currentStreak == 1) {
        "Start today's session to build your streak."
    } else {
        "Your ${snapshot.currentStreak}-day streak is waiting for today's study."
    }
    val notification = NotificationCompat.Builder(context, STREAK_CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_study)
        .setContentTitle("Keep your Rovex streak alive")
        .setContentText(content)
        .setStyle(NotificationCompat.BigTextStyle().bigText(content))
        .setContentIntent(notificationContentIntent(context))
        .setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .build()
    NotificationManagerCompat.from(context).notify(STREAK_NOTIFICATION_ID, notification)
    return true
}

internal fun postDailyMotivationNotification(context: Context, date: LocalDate = LocalDate.now()): Boolean {
    if (!AppManagers.streak.dailyQuoteEnabled() || !canPostRovexNotification(context)) return false
    val manager = context.getSystemService(NotificationManager::class.java)
    if (manager.getNotificationChannel(MOTIVATION_CHANNEL_ID) == null) {
        manager.createNotificationChannel(
            NotificationChannel(
                MOTIVATION_CHANNEL_ID,
                "Daily motivation",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "A new study motivation message each day" }
        )
    }
    val quote = RovexDailyNotificationContent.quoteFor(date)
    val notification = NotificationCompat.Builder(context, MOTIVATION_CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_study)
        .setContentTitle("Rovex • Daily motivation")
        .setContentText(quote)
        .setStyle(NotificationCompat.BigTextStyle().bigText("“$quote”"))
        .setContentIntent(notificationContentIntent(context))
        .setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .build()
    NotificationManagerCompat.from(context).notify(MOTIVATION_NOTIFICATION_ID, notification)
    return true
}

internal fun postDailyTargetNotification(context: Context): Boolean {
    if (!AppManagers.streak.dailyTargetEnabled() || !canPostRovexNotification(context)) return false
    val goal = runCatching {
        QBankDb(context.applicationContext).let { db ->
            try { db.getProgressMeta("rovex:goal:daily")?.toIntOrNull()?.coerceAtLeast(0) ?: 0 }
            finally { db.close() }
        }
    }.getOrDefault(0)
    if (goal <= 0) return false

    val start = RovexDailyNotificationContent.todayStartMillis(ZoneId.systemDefault())
    val solved = runCatching {
        PerformanceManager.progress(context.applicationContext).all().values.count { it.lastAttempted >= start }
    }.getOrDefault(0)
    if (solved >= goal) return false

    val remaining = goal - solved
    val manager = context.getSystemService(NotificationManager::class.java)
    if (manager.getNotificationChannel(TARGET_CHANNEL_ID) == null) {
        manager.createNotificationChannel(
            NotificationChannel(
                TARGET_CHANNEL_ID,
                "Daily target",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Reminders about your saved daily question target" }
        )
    }
    val content = if (solved == 0) {
        "Today's target is $goal questions. Start a focused session when you are ready."
    } else {
        "$solved of $goal completed today. $remaining ${if (remaining == 1) "question remains" else "questions remain"}."
    }
    val notification = NotificationCompat.Builder(context, TARGET_CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_study)
        .setContentTitle("Rovex • Daily target")
        .setContentText(content)
        .setStyle(NotificationCompat.BigTextStyle().bigText(content))
        .setContentIntent(notificationContentIntent(context))
        .setAutoCancel(true)
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .build()
    NotificationManagerCompat.from(context).notify(TARGET_NOTIFICATION_ID, notification)
    return true
}

class StreakPolicy {
    fun apply(current: StreakManager.Snapshot, today: LocalDate): StreakManager.Snapshot {
        val last = current.lastStudyDay?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val next = when {
            last == today -> current.currentStreak.coerceAtLeast(1)
            last == today.minusDays(1) -> current.currentStreak.coerceAtLeast(1) + 1
            else -> 1
        }
        val total = if (last == today) current.totalStudyDays else current.totalStudyDays + 1
        val longest = maxOf(current.longestStreak, next)
        return StreakManager.Snapshot(next, longest, total, today.toString())
    }
}

class StreakReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result = runCatching {
        val app = applicationContext
        val snapshot = QBankDb(app).let { db ->
            try { db.readStudyStreak() } finally { db.close() }
        }
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        if (snapshot.lastStudyDay == today.toString()) return Result.success()
        val effectiveStreak = snapshot.lastStudyDay?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?.takeIf { it == today.minusDays(1) }
            ?.let { snapshot.currentStreak } ?: 0
        if (effectiveStreak <= 0) return Result.success()
        val reminderSnapshot = snapshot.copy(currentStreak = effectiveStreak)
        val reminderDb = QBankDb(app)
        try {
            if (reminderDb.studyReminderAlreadySent(today.toString())) return Result.success()
            if (postStreakNotification(app, reminderSnapshot)) reminderDb.markStudyReminderSent(today.toString())
        } finally {
            reminderDb.close()
        }
        Result.success()
    }.getOrElse { Result.retry() }
}

class DailyMotivationWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result = runCatching {
        if (AppManagers.streak.notificationsEnabled() && AppManagers.streak.dailyQuoteEnabled()) {
            postDailyMotivationNotification(applicationContext)
        }
        if (AppManagers.streak.notificationsEnabled()) {
            PerformanceManager.submitMaintenance {
                AppManagers.streak.setDailyQuoteTime(AppManagers.streak.dailyQuoteHour(), AppManagers.streak.dailyQuoteMinute())
            }
        }
        Result.success()
    }.getOrElse { Result.retry() }
}

class DailyTargetReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result = runCatching {
        if (AppManagers.streak.notificationsEnabled() && AppManagers.streak.dailyTargetEnabled()) {
            postDailyTargetNotification(applicationContext)
        }
        if (AppManagers.streak.notificationsEnabled()) {
            PerformanceManager.submitMaintenance {
                AppManagers.streak.setDailyTargetTime(AppManagers.streak.dailyTargetHour(), AppManagers.streak.dailyTargetMinute())
            }
        }
        Result.success()
    }.getOrElse { Result.retry() }
}
