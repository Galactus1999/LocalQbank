# Rovex v8.3.451 Root Repair Audit

## Root repairs
1. Hyphen-bearing QBank searches use quoted FTS phrase queries instead of treating `-` as an FTS operator or broad substring LIKE.
2. Hyphen searches that have no exact FTS hit fail closed rather than matching identities such as `question-A2` when searching `question-A`.
3. Legacy tombstone regression explicitly invokes `restoreLegacyTombstonedSources()` before asserting catalog/search recovery.

## Verification status
- Source/static inspection: completed for this repair batch.
- Local Gradle execution: blocked unless Gradle distribution is already available.
- CI/device: required; not claimed here.

## Rescan findings / corrections
- Corrected archive identity from the inconsistent `8.3.449 / 541` metadata to `8.3.451 / 542`; versionCode remains monotonic.
- Confirmed `source.file_name` is still UNIQUE. This is intentional legacy schema state and is not claimed removed; current import identity uses the stable `importKey` as `file_name` while human `displayName` is separate.
- Confirmed the old unconditional hyphen early-return is gone from the FTS-first path: hyphen queries first execute a quoted FTS phrase and only fail closed after that exact attempt returns no hit.
- Confirmed the legacy-hidden regression test invokes `restoreLegacyTombstonedSources()` before asserting catalog visibility.
- Confirmed deletion remains incremental and does not synchronously rebuild/delete the full FTS corpus.

## Execution boundary
- Local Gradle compile: BLOCKED because the wrapper distribution could not resolve `downloads.gradle.org` (DNS failure).
- Instrumented/device execution: NOT RUN for this artifact.
- Therefore this archive is STATICALLY VERIFIED, not CI/device VERIFIED.
