package com.localqbank.library

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.delay
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Main-process IPC facade for Ben's isolated neural runtime.
 *
 * v8.3.145 hardening:
 * - Binder DeathRecipient is attached to every service generation.
 * - Generation IDs prevent stale callbacks after a rebind.
 * - Generation is exposed as a cancellable Flow, so UI/lifecycle cancellation propagates
 *   back across Binder instead of merely abandoning a remote request.
 * - Exactly one terminal event is accepted for each request.
 */
class BenInferenceProcessClient(context: Context) : AutoCloseable {
    private val app = context.applicationContext
    private val callbackThread = HandlerThread("ben-inference-callback").also { it.start() }
    private val callbackHandler = Handler(callbackThread.looper)
    private val connectionMutex = Mutex()
    private val requests = ConcurrentHashMap<String, RequestState>()
    private val oneShots = ConcurrentHashMap<String, OneShotState<*>>()
    private val generationCounter = java.util.concurrent.atomic.AtomicLong(0L)
    private val requestTimeoutHandler = Handler(callbackThread.looper)
    @Volatile private var remote: Messenger? = null
    @Volatile private var serviceBinder: IBinder? = null
    @Volatile private var closed = false
    @Volatile private var warm = false
    @Volatile private var currentServiceGeneration = 0L
    private var connection: ServiceConnection? = null
    private var deathRecipient: IBinder.DeathRecipient? = null
    private var pendingBindConnection: ServiceConnection? = null
    private var pendingBindGeneration: Long = 0L

    sealed interface GenerationEvent {
        data class Token(val text: String) : GenerationEvent
        data class Complete(val text: String) : GenerationEvent
        data class Failed(val reason: String) : GenerationEvent
        data object Cancelled : GenerationEvent
        data object ProcessDied : GenerationEvent
    }

    private class RequestState(
        val id: String,
        val generation: Long,
        val sink: kotlinx.coroutines.channels.SendChannel<GenerationEvent>,
        val terminal: AtomicBoolean = AtomicBoolean(false),
        @Volatile var watchdog: Runnable? = null,
    )

    private class OneShotState<T>(
        val generation: Long,
        val done: AtomicBoolean,
        val continuation: kotlin.coroutines.Continuation<T?>,
    )

    /** Streaming generation bridge. Collector cancellation sends CMD_CANCEL to the isolated process. */
    fun generateStream(prompt: String, maxTokens: Int = 160): Flow<GenerationEvent> = callbackFlow<GenerationEvent> {
        val target = try {
            ensureBound()
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: Exception) {
            trySend(GenerationEvent.Failed("Inference process unavailable"))
            close()
            return@callbackFlow
        }
        val requestId = UUID.randomUUID().toString()
        val generation = currentServiceGeneration
        val state = RequestState(requestId, generation, channel)
        requests[requestId] = state

        val sent = runCatching {
            target.send(Message.obtain(null, BenInferenceProcessService.CMD_GENERATE).apply {
                replyTo = Messenger(callbackHandlerFor(requestId))
                data = Bundle().apply {
                    putString(BenInferenceProcessService.KEY_REQUEST_ID, requestId)
                    putLong(BenInferenceProcessService.KEY_CLIENT_GENERATION, generation)
                    putString(BenInferenceProcessService.KEY_PROMPT, prompt.take(6_000))
                    putInt(BenInferenceProcessService.KEY_MAX_TOKENS, maxTokens.coerceIn(32, 192))
                }
            })
        }.isSuccess

        if (!sent) {
            terminal(state, GenerationEvent.ProcessDied)
            return@callbackFlow
        }
        val watchdog = Runnable {
            if (!state.terminal.get()) {
                terminal(state, GenerationEvent.Failed("Inference request timed out"))
                sendCancelBestEffort(target, requestId, generation)
            }
        }
        state.watchdog = watchdog
        requestTimeoutHandler.postDelayed(watchdog, GENERATION_CLIENT_TIMEOUT_MS)

        awaitClose {
            requests.remove(requestId)
            if (state.terminal.compareAndSet(false, true)) {
                sendCancelBestEffort(target, requestId, generation)
            }
        }
    }

    /** Compatibility one-shot API. Callers that own a lifecycle should prefer generateStream(). */
    suspend fun generateSuspend(prompt: String, maxTokens: Int = 160): String? {
        var output: String? = null
        generateStream(prompt, maxTokens).collect { event ->
            when (event) {
                is GenerationEvent.Token -> Unit
                is GenerationEvent.Complete -> output = event.text
                is GenerationEvent.Failed -> Unit
                GenerationEvent.Cancelled -> Unit
                GenerationEvent.ProcessDied -> Unit
            }
        }
        return output
    }

    data class RerankResult(val indices: IntArray, val scores: DoubleArray, val elapsedMs: Long, val usedModel: Boolean)

    suspend fun rerankSuspend(query: String, candidates: List<String>, limit: Int = 8): RerankResult? =
        oneShot(BenInferenceProcessService.CMD_RERANK, Bundle().apply {
            putString(BenInferenceProcessService.KEY_QUERY, query.take(1_800))
            putStringArrayList(BenInferenceProcessService.KEY_CANDIDATES, ArrayList(candidates.take(8).map { it.take(1_800) }))
            putInt(BenInferenceProcessService.KEY_LIMIT, limit.coerceIn(1, 8))
        }) { message ->
            if (message.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false)) null else RerankResult(
                message.data.getIntArray(BenInferenceProcessService.KEY_INDICES) ?: IntArray(0),
                message.data.getDoubleArray(BenInferenceProcessService.KEY_SCORES) ?: DoubleArray(0),
                message.data.getLong(BenInferenceProcessService.KEY_ELAPSED, 0L),
                message.data.getBoolean(BenInferenceProcessService.KEY_USED_MODEL, false)
            )
        }

    suspend fun diagnosticSuspend(onProgress: ((String) -> Unit)? = null): String? = oneShot(
        BenInferenceProcessService.CMD_DIAGNOSTIC,
        Bundle(),
        timeoutMs = DIAGNOSTIC_CLIENT_TIMEOUT_MS,
        onProgress = onProgress,
    ) { m ->
        m.data.getString(BenInferenceProcessService.KEY_REPORT)
            .takeUnless { m.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false) }
    }

    suspend fun compareSuspend(first: String, second: String): Double? = oneShot(BenInferenceProcessService.CMD_COMPARE, Bundle().apply {
        putString(BenInferenceProcessService.KEY_FIRST, first.take(1_800))
        putString(BenInferenceProcessService.KEY_SECOND, second.take(1_800))
    }) { m ->
        if (m.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false)) null
        else m.data.getDouble(BenInferenceProcessService.KEY_SCORE, Double.NaN).takeUnless { it.isNaN() }
    }

    private fun callbackHandlerFor(requestId: String): Handler = Handler(callbackThread.looper) { message ->
        val id = message.data.getString(BenInferenceProcessService.KEY_REQUEST_ID) ?: requestId
        if (id != requestId) return@Handler true
        val state = requests[id] ?: return@Handler true
        if (message.data.getLong(BenInferenceProcessService.KEY_CLIENT_GENERATION, state.generation) != state.generation) return@Handler true
        when (message.what) {
            BenInferenceProcessService.REPLY_TOKEN -> {
                if (!state.terminal.get()) state.sink.trySend(GenerationEvent.Token(message.data.getString(BenInferenceProcessService.KEY_TOKEN).orEmpty()))
            }
            BenInferenceProcessService.REPLY_GENERATE -> {
                if (message.data.getBoolean(BenInferenceProcessService.KEY_CANCELLED, false)) terminal(state, GenerationEvent.Cancelled)
                else if (message.data.getBoolean(BenInferenceProcessService.KEY_FAILED, false)) terminal(state, GenerationEvent.Failed(message.data.getString(BenInferenceProcessService.KEY_ERROR).orEmpty()))
                else terminal(state, GenerationEvent.Complete(message.data.getString(BenInferenceProcessService.KEY_TEXT).orEmpty()))
            }
        }
        true
    }

    private fun terminal(state: RequestState, event: GenerationEvent) {
        if (!state.terminal.compareAndSet(false, true)) return
        requests.remove(state.id)
        state.watchdog?.let(requestTimeoutHandler::removeCallbacks)
        state.watchdog = null
        state.sink.trySend(event)
        state.sink.close()
    }

    private fun sendCancelBestEffort(target: Messenger, requestId: String, generation: Long) {
        runCatching {
            target.send(Message.obtain(null, BenInferenceProcessService.CMD_CANCEL).apply {
                data = Bundle().apply {
                    putString(BenInferenceProcessService.KEY_REQUEST_ID, requestId)
                    putLong(BenInferenceProcessService.KEY_CLIENT_GENERATION, generation)
                }
            })
        }
    }

    private suspend fun <T> oneShot(
        what: Int,
        data: Bundle,
        timeoutMs: Long = ONE_SHOT_CLIENT_TIMEOUT_MS,
        onProgress: ((String) -> Unit)? = null,
        decode: (Message) -> T?,
    ): T? {
        val target = try {
            ensureBound()
        } catch (_: CancellationException) {
            throw CancellationException("Inference client cancelled")
        } catch (_: Exception) {
            return null
        }
        return suspendCancellableCoroutine { continuation ->
            if (closed) {
                continuation.resume(null)
                return@suspendCancellableCoroutine
            }
            val done = AtomicBoolean(false)
            val requestId = UUID.randomUUID().toString()
            val generation = currentServiceGeneration
            val state = OneShotState(generation, done, continuation)
            oneShots[requestId] = state
            val timeout = Runnable {
                if (done.compareAndSet(false, true)) {
                    oneShots.remove(requestId)
                    sendCancelBestEffort(target, requestId, generation)
                    continuation.resume(null)
                }
            }
            requestTimeoutHandler.postDelayed(timeout, timeoutMs)
            val handler = Handler(callbackThread.looper) { message ->
                if (message.data.getString(BenInferenceProcessService.KEY_REQUEST_ID) != requestId) return@Handler true
                if (message.data.getLong(BenInferenceProcessService.KEY_CLIENT_GENERATION, generation) != generation) return@Handler true
                if (message.what == BenInferenceProcessService.REPLY_DIAGNOSTIC_PROGRESS) {
                    onProgress?.invoke(message.data.getString(BenInferenceProcessService.KEY_PROGRESS).orEmpty())
                    return@Handler true
                }
                oneShots.remove(requestId)
                requestTimeoutHandler.removeCallbacks(timeout)
                if (!done.compareAndSet(false, true)) return@Handler true
                continuation.resume(runCatching { decode(message) }.getOrNull())
                true
            }
            continuation.invokeOnCancellation {
                requestTimeoutHandler.removeCallbacks(timeout)
                oneShots.remove(requestId)
                if (done.compareAndSet(false, true)) sendCancelBestEffort(target, requestId, generation)
            }
            runCatching {
                target.send(Message.obtain(null, what).apply {
                    replyTo = Messenger(handler)
                    this.data = Bundle(data).apply {
                        putString(BenInferenceProcessService.KEY_REQUEST_ID, requestId)
                        putLong(BenInferenceProcessService.KEY_CLIENT_GENERATION, generation)
                    }
                })
            }.onFailure {
                oneShots.remove(requestId)
                requestTimeoutHandler.removeCallbacks(timeout)
                if (done.compareAndSet(false, true)) continuation.resume(null)
            }
        }
    }

    private suspend fun ensureBound(): Messenger = connectionMutex.withLock {
        remote?.let { return@withLock it }
        if (closed) throw CancellationException("Inference client closed")
        suspendCancellableCoroutine { continuation ->
            val nextGeneration = generationCounter.incrementAndGet()
            val conn = object : android.content.ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                    if (service == null) {
                        continuation.resumeWithException(IllegalStateException("Null inference Binder"))
                        return
                    }
                    try {
                        val dr = IBinder.DeathRecipient { onBinderDied(nextGeneration, service) }
                        service.linkToDeath(dr, 0)
                        deathRecipient = dr
                        serviceBinder = service
                        currentServiceGeneration = nextGeneration
                        remote = Messenger(service)
                        warm = false
                        continuation.resume(remote!!)
                    } catch (e: RemoteException) {
                        continuation.resumeWithException(e)
                    }
                }
                override fun onServiceDisconnected(name: ComponentName?) { onConnectionLost(nextGeneration) }
                override fun onBindingDied(name: ComponentName?) { onConnectionLost(nextGeneration) }
                override fun onNullBinding(name: ComponentName?) {
                    onConnectionLost(nextGeneration)
                    if (continuation.isActive) continuation.resumeWithException(IllegalStateException("Null inference binding"))
                }
            }
            pendingBindConnection = conn
            pendingBindGeneration = nextGeneration
            connection = conn
            val bound = app.bindService(Intent(app, BenInferenceProcessService::class.java), conn, Context.BIND_AUTO_CREATE or Context.BIND_NOT_FOREGROUND)
            if (!bound) {
                pendingBindConnection = null
                pendingBindGeneration = 0L
                connection = null
                continuation.resumeWithException(IllegalStateException("Unable to bind inference process"))
                return@suspendCancellableCoroutine
            }
            continuation.invokeOnCancellation { runCatching { app.unbindService(conn) } }
        }
    }

    private fun onBinderDied(generation: Long, binder: IBinder) {
        if (generation != currentServiceGeneration || binder !== serviceBinder) return
        onConnectionLost(generation, processDied = true)
    }

    private fun onConnectionLost(generation: Long, processDied: Boolean = true) {
        if (generation != currentServiceGeneration && currentServiceGeneration != 0L) return
        deathRecipient?.let { dr -> serviceBinder?.let { b -> runCatching { b.unlinkToDeath(dr, 0) } } }
        remote = null
        serviceBinder = null
        deathRecipient = null
        pendingBindConnection = null
        pendingBindGeneration = 0L
        connection = null
        warm = false
        currentServiceGeneration = generationCounter.incrementAndGet()
        requests.values.toList().forEach { state ->
            if (state.generation != generation) return@forEach
            terminal(state, if (processDied) GenerationEvent.ProcessDied else GenerationEvent.Failed("Inference connection lost"))
        }
        oneShots.values.toList().forEach { state ->
            if (state.generation != generation) return@forEach
            if (state.done.compareAndSet(false, true)) {
                @Suppress("UNCHECKED_CAST")
                (state.continuation as kotlin.coroutines.Continuation<Any?>).resume(null)
            }
        }
        oneShots.entries.removeIf { it.value.generation == generation }
    }

    fun trim() {
        requests.values.toList().forEach { state ->
            if (state.terminal.compareAndSet(false, true)) sendCancelBestEffort(remote ?: return@forEach, state.id, state.generation)
        }
        synchronized(this) {
            deathRecipient?.let { dr -> serviceBinder?.let { b -> runCatching { b.unlinkToDeath(dr, 0) } } }
            connection?.let { runCatching { app.unbindService(it) } }
            pendingBindConnection?.let { if (it !== connection) runCatching { app.unbindService(it) } }
            connection = null
            pendingBindConnection = null
            pendingBindGeneration = 0L
            remote = null
            serviceBinder = null
            deathRecipient = null
            currentServiceGeneration = generationCounter.incrementAndGet()
            warm = false
        }
    }

    companion object {
        private const val GENERATION_CLIENT_TIMEOUT_MS = 45_000L
        private const val ONE_SHOT_CLIENT_TIMEOUT_MS = 30_000L
        private const val DIAGNOSTIC_CLIENT_TIMEOUT_MS = 90_000L
    }

    override fun close() {
        closed = true
        requests.values.toList().forEach { terminal(it, GenerationEvent.Cancelled) }
        trim()
        callbackThread.quitSafely()
    }
}
