package com.localqbank.library
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
class RovexSectionDashboardActivity:Activity(){
private lateinit var content:LinearLayout
private var active="home"
private var sectionGeneration=0L
private lateinit var navBar:LinearLayout
private data class Row(val name:String,val total:Int,val solved:Int,val correct:Int,val testId:String="",val position:Int=0,val path:String="",val source:String=""){
    val accuracy:Int get()=if(solved==0)0 else correct*100/solved
    val mastery:Int get()=if(total==0)0 else solved*100/total
}
override fun onCreate(b:Bundle?){super.onCreate(b);active=intent.getStringExtra("section")?:"home";buildShell();repaintNav();loadLiveData(sectionGeneration,active)}
private fun buildShell(){
    val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(ThemeManager.bg(this@RovexSectionDashboardActivity))}
    val scroll=ScrollView(this).apply{isFillViewport=true}
    content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(14),d(16),d(18))}
    scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
    navBar=nav()
    root.addView(navBar,LinearLayout.LayoutParams(-1,d(68)));setContentView(root)
}
private fun switchSection(id:String){active=id;sectionGeneration++;repaintNav();loadLiveData(sectionGeneration,id)}
private fun repaintNav(){if(!::navBar.isInitialized)return;for(i in 0 until navBar.childCount){(navBar.getChildAt(i) as? TextView)?.let{v->val id=v.tag?.toString().orEmpty();v.setTextColor(if(active==id)ThemeManager.accent(this) else ThemeManager.muted(this));v.background=if(active==id)android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.bg(this@RovexSectionDashboardActivity));cornerRadius=d(20).toFloat()} else null}}}
private fun loadLiveData(token:Long=sectionGeneration,requestedSection:String=active){
    PerformanceManager.submit{
        val refs=runCatching{PerformanceManager.lightRefs(applicationContext)}.getOrDefault(emptyList())
        val p=runCatching{PerformanceManager.progress(applicationContext)}.getOrNull()
        val rows=refs.groupBy{it.testId}.map{(_,items)->
            val first=items.first()
            var solved=0;var correct=0
            items.forEach{r->when(p?.record(r.stableKey)?.status){"correct"->{solved++;correct++};"wrong"->solved++}}
            Row(first.testTitle.ifBlank{"Untitled QBank"},items.size,solved,correct,first.testId,items.minOfOrNull{it.position}?:0,first.category.ifBlank{"General"},first.sourceName)
        }.sortedWith(compareBy<Row>{it.path.lowercase()}.thenBy{it.name.lowercase()})
        val cards=runCatching{SqliteFlashcardReviewRepository(applicationContext).use{Triple(it.modeCount("all"),it.reviewCount(),it.dueStatsAll().due)}}.getOrDefault(Triple(0,0,0))
        val overall=Row("Main QBank",rows.sumOf{it.total},rows.sumOf{it.solved},rows.sumOf{it.correct})
        runOnUiThread{if(!isFinishing&&!isDestroyed&&token==sectionGeneration&&requestedSection==active)render(rows,overall,cards)}
    }
}
private fun render(rows:List<Row>,overall:Row,cards:Triple<Int,Int,Int>){
    content.removeAllViews()
    when(active){"qbank"->qbank(rows);"cards"->cards(cards);"stats"->stats(rows,overall);"mastery"->mastery(rows,overall);else->home(overall,cards)}
}
private fun title(a:String,b:String){
    content.addView(TextView(this).apply{text=a;textSize=25f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    content.addView(TextView(this).apply{text=b;textSize=12f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,0,0,d(14))})
}
private fun section(x:String){content.addView(TextView(this).apply{text=x.uppercase();textSize=10f;letterSpacing=.12f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(2,d(12),0,d(7))})}
private fun panel():android.graphics.drawable.Drawable=android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.panel(this@RovexSectionDashboardActivity));cornerRadius=d(22).toFloat()}
private fun card(t:String,s:String,a:Int,act:String,go:()->Unit){
    val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(15),d(16),d(13));background=panel()}
    b.addView(TextView(this).apply{text=t;textSize=16f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    b.addView(TextView(this).apply{text=s;textSize=11.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,d(5))})
    b.addView(TextView(this).apply{text=act.uppercase();textSize=10f;setTypeface(null,Typeface.BOLD);setTextColor(a);gravity=Gravity.CENTER_VERTICAL;setPadding(0,d(4),0,0);setOnClickListener{go()}})
    content.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(8)})
}
private fun progress(r:Row,index:Int){
    val fill=ThemeManager.pastelAccentFill(this,index);val fg=ThemeManager.pastelAccentText(this,index)
    val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(14),d(12),d(14),d(11));background=android.graphics.drawable.GradientDrawable().apply{setColor(fill);cornerRadius=d(17).toFloat()};isClickable=true;isFocusable=true;setOnClickListener{if(r.testId.isNotBlank())startActivity(Intent(this@RovexSectionDashboardActivity,QuizActivity::class.java).apply{putExtra("testId",r.testId);putExtra("title",r.name);putExtra("position",r.position);putExtra("sectionLabel",r.path);putExtra("practiceMode",true)})}}
    val line=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
    line.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.name;textSize=14f;setTypeface(null,Typeface.BOLD);setTextColor(fg)},LinearLayout.LayoutParams(0,-2,1f))
    line.addView(TextView(this@RovexSectionDashboardActivity).apply{text=r.mastery.toString()+"%";textSize=12f;setTypeface(null,Typeface.BOLD);setTextColor(fg)})
    b.addView(line)
    b.addView(TextView(this).apply{text=r.path+"  •  "+r.solved.toString()+"/"+r.total+" solved  •  "+r.accuracy+"% accuracy";textSize=10.5f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(3),0,d(5))})
    b.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{progress=r.mastery;progressTintList=android.content.res.ColorStateList.valueOf(fg)})
    content.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(6)})
}
private fun home(o:Row,c:Triple<Int,Int,Int>){
    title("Rovex","Study cockpit")
    card("Continue studying","Resume the active QBank session from the existing Rovex workflow.",ThemeManager.accent(this),"CONTINUE"){finish()}
    section("LIVE DATA")
    card("QBank performance",o.solved.toString()+" solved  •  "+o.accuracy+"% accuracy  •  "+o.total+" questions available.",ThemeManager.accent(this),"VIEW STATS"){switchSection("stats")}
    card("Flashcards",c.first.toString()+" cards  •  "+c.third+" due now  •  "+c.second+" reviews.",ThemeManager.pastelAccentText(this,1),"OPEN CARDS"){switchSection("cards")}
    section("FOCUS")
    card("All QBank subjects","Browse the complete imported subject/section hierarchy. Nothing is hard-coded.",ThemeManager.accent(this),"OPEN QBANK"){switchSection("qbank")}
}
private fun subjectRows(rows:List<Row>):List<Row>{
    val grouped=linkedMapOf<String,MutableList<Row>>()
    rows.forEach{r->val raw=r.path.trim();val subject=raw.substringBefore(">",raw).substringBefore("/",raw).substringBefore("::",raw).trim().ifBlank{r.name.substringBefore(" - ").trim().ifBlank{"General"}};grouped.getOrPut(subject){mutableListOf()}.add(r)}
    return grouped.map{(name,items)->val f=items.minByOrNull{it.position}?:items.first();Row(name,items.sumOf{it.total},items.sumOf{it.solved},items.sumOf{it.correct},f.testId,f.position,name,f.source)}.sortedBy{it.name.lowercase()}
}
private fun qbank(rows:List<Row>){
    title("QBank","Main Bank • all subjects combined")
    analyticsHero(rows)
    section("SUBJECTS")
    if(rows.isEmpty())card("No imported QBank yet","Import content first; this view never invents question counts.",ThemeManager.accent(this),"SEARCH"){openSearch()}
    subjectRows(rows).forEachIndexed{index,r->progress(r,index)}
}
private fun analyticsHero(rows:List<Row>){
    val total=rows.sumOf{it.total};val solved=rows.sumOf{it.solved};val correct=rows.sumOf{it.correct}
    val mastery=if(total==0)0 else solved*100/total;val accuracy=if(solved==0)0 else correct*100/solved
    val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(16),d(16),d(16),d(14));background=panel()}
    val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
    val ring=FrameLayout(this)
    val gauge=ProgressBar(this,null,android.R.attr.progressBarStyleLarge).apply{isIndeterminate=false;max=100;progress=mastery;progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(this@RovexSectionDashboardActivity))}
    ring.addView(gauge,FrameLayout.LayoutParams(d(112),d(112),Gravity.CENTER))
    ring.addView(TextView(this).apply{text=mastery.toString()+"%\nMASTERY";gravity=Gravity.CENTER;textSize=17f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))},FrameLayout.LayoutParams(d(112),d(112),Gravity.CENTER))
    top.addView(ring,LinearLayout.LayoutParams(d(126),d(126)))
    val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(10),0,0,0)}
    info.addView(TextView(this).apply{text="Main QBank";textSize=23f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})
    info.addView(TextView(this).apply{text="All subjects combined\n"+rows.size+" topics";textSize=13f;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity));setPadding(0,d(4),0,d(7))})
    info.addView(TextView(this).apply{text=solved.toString()+" / "+total+" Questions";textSize=14f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity));setPadding(d(10),d(7),d(10),d(7));background=ThemeManager.transparentSectionDrawable(this@RovexSectionDashboardActivity)})
    info.addView(TextView(this).apply{text=accuracy.toString()+"% Accuracy";textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.pastelAccentText(this@RovexSectionDashboardActivity,0));setPadding(0,d(7),0,0)})
    top.addView(info,LinearLayout.LayoutParams(0,-2,1f));box.addView(top)
    val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,d(10),0,d(9))}
    fun stat(label:String,value:String){stats.addView(LinearLayout(this@RovexSectionDashboardActivity).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(d(5),d(8),d(5),d(8));background=ThemeManager.transparentSectionDrawable(this@RovexSectionDashboardActivity);addView(TextView(this@RovexSectionDashboardActivity).apply{text=label;textSize=9f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@RovexSectionDashboardActivity))});addView(TextView(this@RovexSectionDashboardActivity).apply{text=value;textSize=15f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@RovexSectionDashboardActivity))})},LinearLayout.LayoutParams(0,d(68),1f).apply{setMargins(d(3),0,d(3),0)})}
    stat("SOLVED",solved.toString());stat("ACCURACY",accuracy.toString()+"%");stat("COVERAGE",mastery.toString()+"%");box.addView(stats)
    val resume=TextView(this).apply{text="▶  Resume Main Bank";gravity=Gravity.CENTER;textSize=15f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.bg(this@RovexSectionDashboardActivity));background=android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.accent(this@RovexSectionDashboardActivity));cornerRadius=d(28).toFloat()};setPadding(0,d(14),0,d(14));setOnClickListener{rows.firstOrNull()?.let{r->if(r.testId.isNotBlank())startActivity(Intent(this@RovexSectionDashboardActivity,QuizActivity::class.java).apply{putExtra("testId",r.testId);putExtra("title",r.name);putExtra("position",r.position);putExtra("practiceMode",true)})}}}
    box.addView(resume,LinearLayout.LayoutParams(-1,d(54)));content.addView(box,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(10)})
}
private fun cards(c:Triple<Int,Int,Int>){
    title("Cards","Flashcards • retention • review")
    card("Flashcard library",c.first.toString()+" cards • "+c.third+" due now • "+c.second+" reviews recorded.",ThemeManager.accent(this),"OPEN FLASHCARDS"){startActivity(Intent(this,FlashcardActivity::class.java))}
    section("REVIEW")
    card("Due now","Open the existing flashcard scheduler without inventing dashboard numbers.",ThemeManager.pastelAccentText(this,1),"REVIEW"){startActivity(Intent(this,FlashcardActivity::class.java))}
    card("Flashcard tools","Create, import and review using the existing FlashcardActivity.",ThemeManager.accent(this),"OPEN TOOLS"){startActivity(Intent(this,FlashcardActivity::class.java))}
}
private fun stats(rows:List<Row>,o:Row){
    title("Stats","Performance • accuracy • subject analysis")
    analyticsHero(rows)
    section("PERFORMANCE")
    card("Solved",o.solved.toString()+" questions have recorded progress.",ThemeManager.pastelAccentText(this,0),"OPEN QBANK"){switchSection("qbank")}
    card("Correct",o.correct.toString()+" correct answers • "+o.accuracy+"% accuracy.",ThemeManager.pastelAccentText(this,1),"REVIEW"){switchSection("qbank")}
    card("Wrong",(o.solved-o.correct).coerceAtLeast(0).toString()+" recorded wrong answers.",ThemeManager.pastelAccentText(this,2),"REVIEW"){switchSection("qbank")}
    section("SUBJECT PERFORMANCE")
    subjectRows(rows).forEachIndexed{index,r->progress(r,index)}
}
private fun mastery(rows:List<Row>,o:Row){
    title("Mastery","Retention • coverage • subject progress")
    card("Overall mastery",o.mastery.toString()+"% of imported questions have been attempted at least once.",ThemeManager.accent(this),"OPEN QBANK"){switchSection("qbank")}
    section("SUBJECT MASTERY")
    if(rows.isEmpty())card("No imported subjects","Import content to build the mastery map.",ThemeManager.accent(this),"IMPORT"){startActivity(Intent(this,HtmlImportActivity::class.java))}
    subjectRows(rows).forEachIndexed{index,r->progress(r,index)}
}
private fun nav():LinearLayout{
    val l=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(d(7),d(7),d(7),d(7));background=android.graphics.drawable.GradientDrawable().apply{setColor(ThemeManager.elevated(this@RovexSectionDashboardActivity));cornerRadius=d(30).toFloat()}}
    listOf("home" to "Home","qbank" to "QBank","cards" to "Cards","stats" to "Stats","mastery" to "Mastery").forEach{(id,label)->l.addView(TextView(this).apply{tag=id;text=label;gravity=Gravity.CENTER;textSize=10f;setTypeface(null,Typeface.BOLD);setPadding(d(2),0,d(2),0);setOnClickListener{switchSection(id)}},LinearLayout.LayoutParams(0,-1,1f).apply{setMargins(d(2),0,d(2),0)})};return l
}
private fun openSearch(){startActivity(Intent(this,SearchActivity::class.java).apply{putExtra("focusSearch",true)})}
private fun d(x:Int)=(x*resources.displayMetrics.density).toInt()
}