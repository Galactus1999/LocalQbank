package com.localqbank.library

import android.content.Context
import kotlin.math.roundToInt
import kotlin.math.max
import kotlin.math.min

/** Offline adaptive controller. It learns from app events and guides managers without owning data. */
class AdaptiveEngineManager(context: Context) {
    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "adaptive-engine") }
    private val prefs = context.applicationContext.getSharedPreferences("adaptive_engine", Context.MODE_PRIVATE)
    data class State(
        val observations: Long, val answers: Long, val correct: Long, val wrong: Long,
        val refreshes: Long, val navigations: Long, val learningScore: Int, val confidence: Int,
        val preferredPrefetch: Int, val recommendedRefreshMs: Long
    )
    @Synchronized private fun observeInternal(event: String) {
        val e=prefs.edit().putLong("observations",prefs.getLong("observations",0L)+1L)
            .putLong(event,prefs.getLong(event,0L)+1L)
        if(event=="answer_correct") e.putFloat("accuracy_ema",ema("accuracy_ema",1f,.08f))
        if(event=="answer_wrong") e.putFloat("accuracy_ema",ema("accuracy_ema",0f,.08f))
        e.apply()
    }
    private fun ema(key:String,value:Float,alpha:Float):Float { val old=prefs.getFloat(key,.5f); return old+alpha*(value-old) }
    @Synchronized fun state():State {
        val o=prefs.getLong("observations",0); val a=prefs.getLong("answers",0); val c=prefs.getLong("answer_correct",0); val w=prefs.getLong("answer_wrong",0)
        val r=prefs.getLong("refresh",0); val n=prefs.getLong("navigation",0)
        val acc=prefs.getFloat("accuracy_ema",if(a==0L).5f else c.toFloat()/max(1L,a))
        val confidence=min(100,(o*2).coerceAtMost(100).toInt())
        val score=min(100,(o*.7f+a*1.5f+confidence*.3f).roundToInt())
        val prefetch=when { a<20->2; acc>=.80f->4; acc>=.60f->3; else->2 }
        val refresh=when { a<20->15_000L; r>200&&acc>=.75f->45_000L; else->30_000L }
        return State(o,a,c,w,r,n,score,confidence,prefetch,refresh)
    }
    fun observeAsync(event: String) {
        if (executor.isShutdown) return
        executor.execute { runCatching { observeInternal(event) } }
    }
    fun observe(event: String) { observeInternal(event) }
    fun recordAnswer(correct:Boolean){ observeAsync("answers"); observeAsync(if(correct)"answer_correct" else "answer_wrong") }
    fun recordNavigation(){observeAsync("navigation")}
    fun recordRefresh(){observeAsync("refresh")}
    fun resetLearning(){prefs.edit().clear().apply()}
    fun shutdown(){executor.shutdownNow()}
}
