package com.localqbank.library

/** Lightweight in-process invalidation bus. Screens refresh after committed state mutations.
 * Adaptive learning is deliberately asynchronous so telemetry can never add answer latency. */
object AppState {
    private val listeners = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()
    fun register(listener: () -> Unit) { listeners.add(listener) }
    fun unregister(listener: () -> Unit) { listeners.remove(listener) }
    fun changed(reason: String = "state") {
        PerformanceManager.invalidate()
        if (AppManagers.isReady()) AppManagers.adaptive.observeAsync(reason)
        listeners.forEach { listener -> runCatching { listener() } }
    }
}
