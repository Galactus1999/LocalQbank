package com.localqbank.library

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class StudyToolsActivity: AppCompatActivity(){
    private lateinit var db:QBankDb
    private lateinit var store:ProgressStore
    private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);db=QBankDb(this);store=ProgressStore(this);setContentView(build())}
    private fun build():ScrollView{
        val scroll=ScrollView(this).apply{setBackgroundColor(ThemeManager.bg(this@StudyToolsActivity));isFillViewport=true}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(28))}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val back=button("←",14f){finish()};bar.addView(back,LinearLayout.LayoutParams(dp(54),dp(52)))
        val title=TextView(this).apply{text="Study Tools";textSize=24f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@StudyToolsActivity));setPadding(dp(12),0,0,0)}
        bar.addView(title,LinearLayout.LayoutParams(0,dp(52),1f));root.addView(bar)
        val intro=TextView(this).apply{text="Turn your imported QBank into a revision and exam system. All tools use the same question database and progress.";textSize=14f;setTextColor(ThemeManager.muted(this@StudyToolsActivity));setPadding(0,dp(10),0,dp(16))};root.addView(intro)
        addTool(root,"🧠  Today's Revision","Questions due now • spaced revision",Color.rgb(27,105,111)){launchCollection(dueIds(),"Today's Revision",true)}
        addTool(root,"🔥  Weakest 50","Wrong + low-performing questions first",Color.rgb(155,79,52)){launchCollection(weakIds(),"Weakest 50",true)}
        addTool(root,"⚡  Rapid 100","100 mixed questions • daily challenge",Color.rgb(112,75,150)){launchCollection(PerformanceManager.refs(applicationContext).shuffled().take(100).map{it.id}.toLongArray(),"Rapid 100",true)}
        addTool(root,"❌  Wrong Questions","Reattempt your mistakes",Color.rgb(155,65,65)){launchCollection(wrongIds(),"Wrong Questions",true)}
        addTool(root,"📝  Custom Test","Choose size and question pool",Color.rgb(52,94,139)){customDialog()}
        addTool(root,"⏱  Exam Mode","Timed test • no answers/explanations until submission",Color.rgb(79,83,127)){examDialog()}
        addTool(root,"📊  Analytics","Accuracy, attempts, weak subjects and progress",Color.rgb(55,111,78)){analyticsDialog()}
        addTool(root,"⭐  PYQ Mode","Questions from QBanks/sections labelled PYQ",Color.rgb(116,91,43)){pyqIds().let{launchCollection(it,"PYQ",true)}}
        addTool(root,"🗒  My Notes","Your saved notes • question optional",Color.rgb(91,79,112)){startActivity(Intent(this,NotesActivity::class.java))}
        val hint=TextView(this).apply{text="Tip: use Today's Revision daily, then Weakest 50 when your accuracy plateaus.";textSize=13f;setTextColor(ThemeManager.muted(this@StudyToolsActivity));setPadding(dp(4),dp(18),dp(4),0)};root.addView(hint)
        scroll.addView(root);return scroll
    }
    private fun addTool(root:LinearLayout,title:String,sub:String,color:Int,click:()->Unit){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(13),dp(16),dp(13));background=GradientDrawable().apply{setColor(if(ThemeManager.get(this@StudyToolsActivity)==ThemeManager.DARK)ThemeManager.elevated(this@StudyToolsActivity) else Color.WHITE);cornerRadius=dp(17).toFloat();setStroke(dp(1),Color.argb(55,90,110,130))};setOnClickListener{click()}}
        val t=TextView(this).apply{text=title;textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(if(ThemeManager.get(this@StudyToolsActivity)==ThemeManager.DARK)Color.WHITE else Color.rgb(20,39,58))}
        val s=TextView(this).apply{text=sub;textSize=12.5f;setTextColor(ThemeManager.muted(this@StudyToolsActivity));setPadding(0,dp(4),0,0)}
        card.addView(t);card.addView(s);root.addView(card,LinearLayout.LayoutParams(-1,dp(78)).apply{setMargins(0,dp(5),0,dp(5))})
    }
    private fun button(text:String,size:Float,click:()->Unit)=TextView(this).apply{this.text=text;textSize=size;gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@StudyToolsActivity));background=GradientDrawable().apply{setColor(ThemeManager.elevated(this@StudyToolsActivity));cornerRadius=dp(14).toFloat()};setOnClickListener{click()}}
    private fun launchCollection(ids:LongArray,label:String,practice:Boolean){if(ids.isEmpty()){Toast.makeText(this,"No questions available",Toast.LENGTH_SHORT).show();return};startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel",label).putExtra("practiceMode",practice).putExtra("title",label))}
    private fun dueIds():LongArray {
        val refs=PerformanceManager.refs(applicationContext); val p=PerformanceManager.progress(applicationContext); val now=System.currentTimeMillis()
        return refs.asSequence().filter { r -> val x=p.record(r.stableKey); x==null || x.lastAttempted==0L || (x.nextDue>0L && now>=x.nextDue) || (x.nextDue==0L && now-x.lastAttempted>=when(x.attempts){1->86_400_000L;2->3*86_400_000L;3->7*86_400_000L;4->14*86_400_000L;else->30*86_400_000L}) }.take(100).map{it.id}.toList().toLongArray()
    }
    private fun weakIds():LongArray {
        val refs=PerformanceManager.refs(applicationContext); val p=PerformanceManager.progress(applicationContext)
        return refs.sortedWith(compareBy<QuestionRef>{when(p.record(it.stableKey)?.status){"wrong"->0;null->1;else->2}}.thenByDescending{p.record(it.stableKey)?.attempts ?: 0}).take(50).map{it.id}.toLongArray()
    }
    private fun wrongIds():LongArray { val p=PerformanceManager.progress(applicationContext); return PerformanceManager.refs(applicationContext).filter{p.record(it.stableKey)?.status=="wrong"}.sortedByDescending{p.record(it.stableKey)?.attempts ?: 0}.map{it.id}.toLongArray() }
    private fun pyqIds():LongArray{return PerformanceManager.refs(applicationContext).filter{it.sourceName.contains("pyq",true)||it.testTitle.contains("pyq",true)||it.category.contains("pyq",true)}.map{it.id}.toLongArray()}
    private fun noteIds():LongArray=db.notes().map{it.first}.toLongArray()
    private fun customDialog(){
        val counts=arrayOf("10","20","50","100","200");var count=20
        val options=arrayOf("All questions","Unsolved","Wrong","Solved","Bookmarked","Important","Revise","Doubt","Favourite")
        var selected=0
        AlertDialog.Builder(this).setTitle("Custom Test").setSingleChoiceItems(options,0){_,which->selected=which}.setPositiveButton("Choose size"){_,_->AlertDialog.Builder(this).setTitle("Number of questions").setItems(counts){_,w->count=counts[w].toInt();val ids=pool(selected).shuffled().take(count).toLongArray();launchCollection(ids,"Custom Test • $count",true)}.show()}.setNegativeButton("Cancel",null).show()
    }
    private fun pool(which:Int):List<Long>{
        val p=PerformanceManager.progress(applicationContext)
        return PerformanceManager.refs(applicationContext).filter{r->when(which){0->true;1->p.record(r.stableKey)?.status==null;2->p.record(r.stableKey)?.status=="wrong";3->p.record(r.stableKey)?.status=="correct";4->!p.record(r.stableKey)?.bookmark.isNullOrBlank();5->p.record(r.stableKey)?.bookmark=="important";6->p.record(r.stableKey)?.bookmark=="revise";7->p.record(r.stableKey)?.bookmark=="doubt";8->{val b=p.record(r.stableKey)?.bookmark;b=="favorite"||b=="favourite"};else->true}}.map{it.id}
    }
    private fun examDialog(){val counts=arrayOf("20","50","100","200");AlertDialog.Builder(this).setTitle("Exam Mode").setItems(counts){_,w->val n=counts[w].toInt();val ids=PerformanceManager.refs(applicationContext).shuffled().take(n).map{it.id};val mins=(n*1.2).roundToInt().coerceAtLeast(10);startActivity(Intent(this,QuizActivity::class.java).putExtra("collectionMode",true).putExtra("sessionIds",ids.joinToString(",")).putExtra("sessionLabel","Exam • $n Q").putExtra("examMode",true).putExtra("examDurationMinutes",mins).putExtra("title","Exam Mode"))}.setNegativeButton("Cancel",null).show()}
    private fun analyticsDialog(){
        PerformanceManager.submit{
            val refs=runCatching{PerformanceManager.refs(applicationContext)}.getOrDefault(emptyList())
            val snap=runCatching{AppManagers.analytics.snapshot(refs)}.getOrDefault(AnalyticsSnapshot())
            runOnUiThread{if(!isFinishing&&!isDestroyed) AlertDialog.Builder(this).setTitle("Q Performance")
                .setMessage("Questions: ${snap.total}\nSolved: ${snap.attempted}\nCorrect: ${snap.correct}\nWrong: ${snap.wrong}\nUnsolved: ${snap.unsolved}\nAccuracy: ${snap.accuracy}%\nBookmarked: ${snap.bookmarks}")
                .setPositiveButton("OK",null).show()}
        }
    }
    override fun onDestroy(){db.close();super.onDestroy()}
}
