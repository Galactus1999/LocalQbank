package com.localqbank.library

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Device-only IPC torture smoke test. It exercises rapid latest-request-wins churn without asserting model output. */
@RunWith(AndroidJUnit4::class)
class BenInferenceProcessStressTest {
    @Test fun rapidClientLifecycleChurnDoesNotThrow() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        repeat(4) {
            val client = BenInferenceProcessClient(context)
            try {
                val job = kotlinx.coroutines.launch {
                    runCatching { withTimeout(5_000L) { client.generateSuspend("Return one short word.", 32) } }
                }
                delay(120)
                client.trim()
                job.cancel()
                delay(120)
            } finally {
                client.close()
            }
        }
        assertTrue(true)
    }
}
