package com.localqbank.library

/** Deterministic retry classification for isolated-process IPC. */
const val BEN_IPC_MAX_ATTEMPTS = 2
const val BEN_IPC_RETRY_BACKOFF_MS = 350L

fun benIpcIsRetryable(reason: String): Boolean =
    reason.startsWith("INFERENCE_PROCESS_DIED") ||
        reason.startsWith("INFERENCE_CONNECTION_LOST") ||
        reason.startsWith("IPC_REMOTE_NOT_READY") ||
        reason.startsWith("IPC_SEND_FAILED") ||
        reason.startsWith("IPC_BIND_FAILED") ||
        reason.startsWith("IPC_FGS_NOT_READY")
