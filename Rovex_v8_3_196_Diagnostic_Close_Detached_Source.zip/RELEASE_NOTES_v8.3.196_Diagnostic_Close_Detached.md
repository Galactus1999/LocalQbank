# Rovex 8.3.196 — Diagnostic Post-Inference Close Detached From Result Path

VersionCode: 291

## What the device trace actually showed

`result=INTERRUPTED`, `failure=EMBEDDING_NATIVE_INFERENCE_STALL_OR_PROCESS_DEATH` looked
like a failure, but the event trace tells a different story: the LiteRT runtime was created,
the Qualcomm/HTP tensor contract was ready, and **all three smoke-test inferences passed**
(`WORKER_EMBEDDING_INFERENCE_1/2/3_PASS`, 29-35ms each, `dim=768`). The trace goes completely
silent immediately after the third `_PASS` event -- no further worker or client events at all.

## Root cause

`BenEmbeddingGemmaEngine.diagnosticReport()` ran its entire body -- including building the
final report -- inside `Runtime(installed.file, tokenizerFile, onProgress).use { runtime -> ... }`.
Kotlin's `use{}` closes the resource (`Runtime.close()`, which tears down the native Qualcomm
HTP/QNN `CompiledModel`/`Environment`) **before** the enclosing function actually returns to its
caller, even when the lambda body does `return@withContext`. If that native teardown crashes the
process -- a real risk right after rapid back-to-back HTP inference calls on some QNN driver
builds -- it takes the whole `:inference_process` down *after* a fully successful result was
computed but *before* that result ever reached the IPC layer to be sent back. That is exactly
the "all three inferences pass, then total silence" signature in the trace.

This is the only call site in `BenEmbeddingGemmaEngine.kt` with this shape: `rerank()` keeps a
long-lived cached runtime via `acquireRuntime()` and never opens-then-immediately-closes a
runtime on the success path, so it is not affected.

## Fix

`diagnosticReport()` no longer uses `.use { }` for this block. It now:
1. Computes the report and calls `publish(report)` exactly as before.
2. Starts the native `runtime.close()` on its own detached daemon thread.
3. Returns the already-published report immediately, without waiting for that thread.

If native teardown still crashes on some devices, it now happens *after* the successful result
has already been published/returned, so it can no longer erase a successful diagnostic run.

## Known follow-up (not fixed in this change)

On the exception path, `failureReport()` never explicitly closes `diagnosticRuntimeForFailure`
if a `Runtime` was partially constructed before the failure. That's a pre-existing, unrelated,
narrower leak (only on already-failing runs) -- flagging it rather than changing it here, to keep
this fix scoped to the exact crash shown in the trace under time pressure.

## Scope

`BenEmbeddingGemmaEngine.kt` (`diagnosticReport()`) only.

## Verification status

Static source change audited locally; braces/parens balanced. Not exercised on-device in this
environment. Run the isolated IPC diagnostic again on v8.3.196: if this was the whole story, the
report should now come back with `overallPassed=true` instead of ending in
`EMBEDDING_NATIVE_INFERENCE_STALL_OR_PROCESS_DEATH`.
