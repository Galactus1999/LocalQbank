package com.localqbank.library

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.widget.*
import kotlin.math.roundToInt
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity: AppCompatActivity(){
    private var isVisible = false
    private var appliedThemeKey: String? = null
    private var fullyDrawnReported = false
    private val stateListener:()->Unit={if(!isFinishing && !isDestroyed && isVisible)runOnUiThread{RovexHomeRevolution.refreshData(this);refreshOpenAnalyticsDialog()}}
    private fun dp(value:Int):Int = (value * resources.displayMetrics.density).roundToInt()
    private var analyticsDialog: Dialog? = null
    private var celebrationView: RovexCelebrationView? = null
    private val milestoneListener: (StudyEventSpine.Event) -> Unit = { event ->
        if (event.name == "milestone_reached") runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            val shell = findViewById<ViewGroup>(R.id.dashboardRoot)?.findViewWithTag<ViewGroup>("ROVEX_HOME_SHELL")
            val target = when (event.metadata["kind"]) {
                "streak" -> shell?.findViewWithTag<View>("rovex_home_progress_value")
                else -> shell?.findViewWithTag<View>("modern_feature_flashcards")
            }
            val host = celebrationView ?: RovexCelebrationHost.install(findViewById(android.R.id.content)).also { celebrationView = it }
            if (target != null) host.celebrateAt(target) else host.celebrate()
            RovexSoundFeedback.playMilestone(this)
        }
    }
    private var analyticsPeriod: Int = 0
    private val uiPreferences by lazy { MainUiPreferences(this) }
    private val htmlImportLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            startActivity(Intent(this, HtmlImportActivity::class.java).putParcelableArrayListExtra("uris", ArrayList(uris)))
        }
    }
    override fun onCreate(b:Bundle?){super.onCreate(b);AppManagers.initialize(applicationContext)
        SystemUi.immersive(this)
        // The legacy XML dashboard remains in the project as a compatibility/reference surface,
        // but the production Home must not inflate and hide a second complete UI tree. Android
        // recommends a single authoritative UI state/navigation path; keeping the old tree
        // instantiated created duplicate Views, IDs, listeners and measurement work.
        val modernRoot = FrameLayout(this).apply { id = R.id.dashboardRoot; setBackgroundColor(Color.TRANSPARENT) }
        setContentView(modernRoot)
        celebrationView = RovexCelebrationHost.install(findViewById(android.R.id.content))
        StudyEventSpine.subscribe(milestoneListener)
        RovexHomeRevolution.apply(this)
        AppState.register(stateListener)
        RovexBottomNavigation.install(this, RovexBottomNavigation.Destination.HOME.index, b)
        findViewById<ViewGroup>(R.id.dashboardRoot)
            ?.findViewWithTag<ViewGroup>("ROVEX_HOME_SHELL")
            ?.let { AliveMotion.installTree(it) }
        installHomeSwipeToFlashcards()
        TransitionCoordinator.install(this)
        appliedThemeKey = ThemeManager.get(this)
        // The modern Home is the sole runtime dashboard. The former XML dashboard and its
        // MainViewModel collector are retained only as source-level compatibility artifacts;
        // neither is instantiated or consulted by the production Home path.
        RovexHomeRevolution.refreshData(this)
        window.decorView.postDelayed({showRecoveryPrompt()},500)}
    override fun onSaveInstanceState(outState: Bundle) {
        RovexBottomNavigation.saveInstanceState(outState, RovexBottomNavigation.Destination.HOME.index)
        super.onSaveInstanceState(outState)
    }
        override fun onStart(){ super.onStart(); isVisible = true }
    override fun onResume(){
        super.onResume()
        StartupHealthStore(applicationContext).markInteractive(this)
        if(isFinishing || isDestroyed)return
        val currentTheme = ThemeManager.get(this)
        if (appliedThemeKey != null && appliedThemeKey != currentTheme) {
            // The Home Revolution shell creates its own theme-aware views. Rebuilding the
            // shell is safer than trying to recolour an already-created tree and prevents
            // mixed-theme text/background states after returning from Settings.
            appliedThemeKey = currentTheme
            recreate()
            return
        }
        appliedThemeKey = currentTheme
        RovexHomeRevolution.refreshTheme(this)
        RovexHomeRevolution.refreshData(this)
        setupRovexBottomNav()
    }
    override fun onPause(){ super.onPause() }
    override fun onStop(){
        isVisible = false
        // Cloud backup may perform network/file I/O. Lifecycle callbacks must stay cheap; queue
        // the flush instead of making Activity.onStop block the main thread.
        PerformanceManager.submitMaintenance { runCatching { MainRepository(applicationContext).use { it.flushBackup() } } }
        super.onStop()
    }
    private fun installHomeSwipeToFlashcards(){
        // Section navigation is handled at Activity dispatch level so the child ScrollView/RecyclerView
        // keeps normal vertical scrolling. Horizontal-scrollable/WebView/text-selection targets are
        // explicitly excluded by RovexSectionSwipeDetector.
        val order=listOf("home","qbank","flashcards","more")
        window.decorView.setTag(R.id.dashboardRoot, RovexSectionSwipeDetector(this){direction ->
            val current=0
            val next=(current + if(direction>0) 1 else -1 + order.size)%order.size
            when(order[next]){
                "home" -> scrollHomeTop()
                "qbank" -> openSection("qbank")
                "flashcards" -> startActivity(Intent(this,FlashcardActivity::class.java))
                "more" -> startActivity(Intent(this,StudyToolsActivity::class.java))
            }
        })
    }

    override fun dispatchTouchEvent(ev:MotionEvent):Boolean{
        val detector=window.decorView.getTag(R.id.dashboardRoot) as? RovexSectionSwipeDetector
        if(detector?.onTouchEvent(ev)==true) return true
        return super.dispatchTouchEvent(ev)
    }

    private fun showRecoveryPrompt(){
        if (isFinishing || isDestroyed || !ResilienceManager.shouldOfferRecovery(this)) return
        val recovery = ResilienceManager.recovery(this) ?: return
        AlertDialog.Builder(this)
            .setTitle("Resume protected study session?")
            .setMessage("Rovex saved question ${recovery.position + 1} before the previous interruption. Your QBank data was preserved.")
            .setNegativeButton("Later") { _, _ -> ResilienceManager.dismissRecoveryOffer(this) }
            .setPositiveButton("Resume") { _, _ ->
                ResilienceManager.dismissRecoveryOffer(this)
                val intent = Intent(this, QuizActivity::class.java).apply {
                    putExtra("testId", recovery.testId)
                    putExtra("position", recovery.position)
                    putExtra("sessionLabel", recovery.session)
                    if (recovery.stableKey.isNotBlank()) putExtra("questionId", recovery.stableKey.substringAfterLast(':').toLongOrNull() ?: -1L)
                }
                startActivity(intent)
            }.show()
    }

    private fun refreshOpenAnalyticsDialog(){
        val dialog=analyticsDialog
        if(dialog!=null && dialog.isShowing && !isFinishing && !isDestroyed){
            PerformanceManager.submit {
                val refs = PerformanceManager.refs(applicationContext)
                val progress = PerformanceManager.progress(applicationContext)
                runOnUiThread { if (!isFinishing && !isDestroyed) resultOf { showInteractiveAnalyticsPrepared(refs, analyticsPeriod, progress) } }
            }
        }
    }
    fun openPerformanceLabFromModernHome(){
        if (isFinishing || isDestroyed) return
        PerformanceManager.submit {
            val refs = PerformanceManager.refs(applicationContext)
            val progress = PerformanceManager.progress(applicationContext)
            runOnUiThread { if (!isFinishing && !isDestroyed) showInteractiveAnalyticsPrepared(refs, 7, progress) }
        }
    }

    private fun setupRovexBottomNav(){
        RovexBottomNavigation.install(this, RovexBottomNavigation.Destination.HOME.index)
    }

    private fun openSection(id:String){
        when(id){
            "qbank" -> startActivity(Intent(this, RovexSectionDashboardActivity::class.java).apply {
                putExtra("section", "qbank")
                addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            })
            "flashcards" -> startActivity(Intent(this, FlashcardActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP) })
            "ben" -> startActivity(Intent(this, RenActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP) })
            else -> startActivity(Intent(this, RovexSectionDashboardActivity::class.java).apply { putExtra("section",id); addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP) })
        }
    }

    private fun scrollHomeTop(){
        val shell=findViewById<ViewGroup>(R.id.dashboardRoot)?.findViewWithTag<ViewGroup>("ROVEX_HOME_SHELL") ?: return
        shell.findViewWithTag<ScrollView>("ROVEX_HOME_SCROLL")?.smoothScrollTo(0,0)
    }

    private fun currentQBankRefs(allRefs:List<QuestionRef>):List<QuestionRef> =
        StudyQueuePolicy.currentQBankRefs(allRefs, AppManagers.sessionStore.current())

    private fun startTodayRevision(refs:List<QuestionRef>){
        if (isFinishing || isDestroyed) return
        PerformanceManager.submit {
            val repo = MainRepository(applicationContext)
            val ids = try { MainStudyUseCase(repo).todayRevisionIds(refs).toList() }
            catch (_: Exception) { emptyList() }
            finally { repo.close() }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if(ids.isEmpty()){
                    Toast.makeText(this,"No questions are due for today's revision yet.",Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                startActivity(Intent(this,QuizActivity::class.java)
                    .putExtra("collectionMode",true)
                    .putExtra("sessionIds",ids.joinToString(","))
                    .putExtra("sessionLabel","Today's Revision")
                    .putExtra("practiceMode",true)
                    .putExtra("title","Today's Revision"))
            }
        }
    }

    private fun showInteractiveAnalytics(allRefs:List<QuestionRef>,periodDays:Int=0){
        if (isFinishing || isDestroyed) return
        PerformanceManager.submit {
            val progress = PerformanceManager.progress(applicationContext)
            runOnUiThread {
                if (!isFinishing && !isDestroyed) showInteractiveAnalyticsPrepared(allRefs, periodDays, progress)
            }
        }
    }

    private fun showInteractiveAnalyticsPrepared(allRefs:List<QuestionRef>,periodDays:Int=0,progress:ProgressSnapshot){
        if (isFinishing || isDestroyed) return
        try {
        analyticsPeriod=periodDays
        val baseRefs=if(periodDays<=0) allRefs else { val since=System.currentTimeMillis()-periodDays*86_400_000L; allRefs.filter{progress.record(it.stableKey)?.lastAttempted?.let{t->t>=since}==true} }
        val refs=currentQBankRefs(baseRefs)
        val snap=AppManagers.analytics.snapshot(refs, progress, periodDays)
        val solved=snap.correct
        val wrong=snap.wrong
        val attempted=snap.attempted
        val total=snap.total
        val accuracy=snap.accuracy
        val mastery=snap.mastery
        val due=snap.due
        val notes=snap.notes
        val bookmarks=snap.bookmarks
        val avgMs=snap.averageTimeMs
        val today=snap.todaySolved
        val dark=ThemeManager.isDark(this)
        val themeLabBg=uiPreferences.performanceLabThemeBackground()
        analyticsDialog?.dismiss()
        val dialog=Dialog(this)
        analyticsDialog=dialog
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=if(themeLabBg)ThemeManager.backgroundDrawable(this@MainActivity) else GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(ThemeManager.accent(this@MainActivity),ThemeManager.elevated(this@MainActivity),ThemeManager.bg(this@MainActivity)))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(18),dp(12),dp(10),dp(8));background=GradientDrawable().apply{setColor(ThemeManager.accent(this@MainActivity));cornerRadius=0f}}
        top.addView(TextView(this).apply{text="PERFORMANCE LAB";textSize=15.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.onAccent(this@MainActivity))},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(TextView(this).apply{
            text=if(themeLabBg)"THEME" else "DATA";textSize=9.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.onAccent(this@MainActivity))
            background=UiDrawableUtils.roundedDrawable(this@MainActivity,Color.argb(45,255,255,255),10f);setPadding(dp(8),0,dp(8),0)
            setOnClickListener{uiPreferences.setPerformanceLabThemeBackground(!themeLabBg);dialog.dismiss();showInteractiveAnalytics(allRefs,periodDays)}
        },LinearLayout.LayoutParams(dp(58),dp(34)).apply{setMargins(0,0,dp(6),0)})
        top.addView(TextView(this).apply{text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(ThemeManager.onAccent(this@MainActivity));setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(dp(42),dp(48)))
        root.addView(top)
        val periods=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(10),dp(12),dp(2))}
        listOf(1 to "DAILY",7 to "WEEKLY",30 to "MONTHLY",0 to "ALL TIME").forEach{(days,label)->
            val selected=periodDays==days
            val chip=TextView(this).apply{text=label;textSize=10.5f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(if(selected)ThemeManager.onAccent(this@MainActivity) else ThemeManager.text(this@MainActivity));background=UiDrawableUtils.roundedDrawable(this@MainActivity,if(selected)ThemeManager.accent(this@MainActivity) else ThemeManager.elevated(this@MainActivity),14f);setPadding(dp(8),dp(7),dp(8),dp(7));setOnClickListener{dialog.dismiss();showInteractiveAnalytics(allRefs,days)}}
            periods.addView(chip,LinearLayout.LayoutParams(0,dp(38),1f).apply{setMargins(dp(3),0,dp(3),0)})
        }
        root.addView(periods)
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(26))}

        val hero=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(16),dp(14),dp(16));background=GradientDrawable().apply{setColor(ThemeManager.peacockFill(this@MainActivity));cornerRadius=24f}}
        hero.addView(PerformanceRing(this,accuracy,mastery,dark),LinearLayout.LayoutParams(dp(126),dp(126)))
        val heroText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(4),0)}
        heroText.addView(TextView(this).apply{text=when{attempted==0->"Ready to build your profile";accuracy>=85->"Elite accuracy zone";accuracy>=70->"Strong base — sharpen weak areas";else->"High-yield opportunity zone"};textSize=19f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity))})
        heroText.addView(TextView(this).apply{text="${accuracy}% accuracy  •  ${mastery}% mastery";textSize=13f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@MainActivity));setPadding(0,dp(7),0,dp(5))})
        heroText.addView(TextView(this).apply{text="${today} questions in this period. ${if(due>0)"${due} questions are waiting for revision." else "No revision backlog is waiting."}";textSize=12.5f;setTextColor(ThemeManager.muted(this@MainActivity));setLineSpacing(0f,1.15f)})
        hero.addView(heroText,LinearLayout.LayoutParams(0,-2,1f));box.addView(hero)

        val section=TextView(this).apply{text="YOUR CONTROL PANEL";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@MainActivity));setPadding(dp(2),dp(18),dp(2),dp(8))};box.addView(section)
        val actionRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f}
        fun action(label:String,value:String,bg:Int,click:()->Unit){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(7),dp(11),dp(7),dp(10));background=UiDrawableUtils.roundedDrawable(this@MainActivity,if(dark)ThemeManager.panel(this@MainActivity)else ThemeManager.pastelAccentFill(this@MainActivity,0),18f);setOnClickListener{click()}};c.addView(TextView(this).apply{text=value;textSize=22f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@MainActivity))});c.addView(TextView(this).apply{text=label;textSize=10.5f;gravity=Gravity.CENTER;setTextColor(ThemeManager.muted(this@MainActivity))});actionRow.addView(c,LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(3),0,dp(3),0)})}
        action("WRONG",wrong.toString(),Color.rgb(253,232,235)){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","status").putExtra("filterValue","wrong"))}
        val currentRefs=currentQBankRefs(refs)
        val nowForDue=System.currentTimeMillis()
        val currentDue=currentRefs.count { ref ->
            val p=progress.record(ref.stableKey)
            p?.status != null && ((p.nextDue>0L && nowForDue>=p.nextDue) ||
                (p.nextDue==0L && p.lastAttempted>0L && nowForDue-p.lastAttempted>=when(p.attempts){
                    1->86_400_000L; 2->3*86_400_000L; 3->7*86_400_000L; 4->14*86_400_000L; else->30*86_400_000L
                }))
        }
        action("DUE NOW",currentDue.toString(),Color.rgb(255,243,214)){startTodayRevision(currentRefs)}
        action("UNSOLVED",(total-attempted).coerceAtLeast(0).toString(),Color.rgb(230,241,248)){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","status").putExtra("filterValue","unsolved"))}
        box.addView(actionRow)

        val speed=if(avgMs>0)"${(avgMs/1000).coerceAtLeast(1)}s / question" else "—"
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;weightSum=3f;setPadding(0,dp(10),0,0)}
        fun metric(label:String,value:String,click:(()->Unit)?=null){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(11),dp(10),dp(8),dp(10));background=UiDrawableUtils.roundedDrawable(this@MainActivity,ThemeManager.panel(this@MainActivity),16f);if(click!=null){isClickable=true;isFocusable=true;setOnClickListener{click()}}};c.addView(TextView(this).apply{text=value;textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity))});c.addView(TextView(this).apply{text=label;textSize=10.5f;setTextColor(ThemeManager.muted(this@MainActivity));setPadding(0,dp(3),0,0)});stats.addView(c,LinearLayout.LayoutParams(0,dp(70),1f).apply{setMargins(dp(3),0,dp(3),0)})}
        metric("AVG TIME",speed);metric("BOOKMARKS",bookmarks.toString()){startActivity(Intent(this,CollectionActivity::class.java).putExtra("filterType","bookmark").putExtra("filterValue","all"))};metric("NOTES",notes.toString()){startActivity(Intent(this,NotesActivity::class.java))};box.addView(stats)

        box.addView(TextView(this).apply{text="QBANK FOCUS MAP";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.muted(this@MainActivity));setPadding(dp(2),dp(18),dp(2),dp(7))})
        refs.groupBy { it.sourceId to it.sourceName }.entries.take(10).forEach { (sourceKey, sourceRefs) ->
            val sourceId = sourceKey.first
            val sourceName = sourceKey.second
            val attemptedForSource = sourceRefs.count { progress.record(it.stableKey)?.status != null }
            val correctForSource = sourceRefs.count { progress.record(it.stableKey)?.status == "correct" }
            val pct = if (attemptedForSource == 0) 0 else correctForSource * 100 / attemptedForSource
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(9),dp(12),dp(9));background=UiDrawableUtils.roundedDrawable(this@MainActivity,ThemeManager.panel(this@MainActivity),16f)}
            val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            head.addView(TextView(this).apply{text=sourceName;textSize=13.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(this@MainActivity));maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,-2,1f))
            head.addView(TextView(this).apply{text="$attemptedForSource/${sourceRefs.size}  •  $pct%";textSize=11.5f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.accent(this@MainActivity));gravity=Gravity.END})
            row.addView(head)
            val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pct;progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(this@MainActivity));backgroundTintList=android.content.res.ColorStateList.valueOf(Color.argb(if(dark)70 else 45,Color.red(ThemeManager.accent(this@MainActivity)),Color.green(ThemeManager.accent(this@MainActivity)),Color.blue(ThemeManager.accent(this@MainActivity))))}
            row.addView(bar,LinearLayout.LayoutParams(-1,dp(6)).apply{setMargins(0,dp(8),0,0)})
            row.setOnClickListener{startActivity(Intent(this,RovexSectionDashboardActivity::class.java).putExtra("section","qbank").putExtra("sourceId",sourceId))}
            box.addView(row,LinearLayout.LayoutParams(-1,dp(70)).apply{setMargins(0,dp(3),0,dp(3))})
        }
        box.addView(TextView(this).apply{text="ADAPTIVE INSIGHT\n\n${AppManagers.adaptive.insight()}\n\nStudy guidance: ${AppManagers.learning.recommendation(refs)}";textSize=12.5f;setTextColor(ThemeManager.text(this@MainActivity));setLineSpacing(0f,1.12f);setPadding(dp(14),dp(13),dp(14),dp(13));background=UiDrawableUtils.roundedDrawable(this@MainActivity,ThemeManager.panel(this@MainActivity),16f)})
        box.addView(TextView(this).apply{text="Open Study Menu  →";textSize=14f;setTypeface(null,Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@MainActivity));setPadding(0,dp(16),0,dp(4));setOnClickListener{dialog.dismiss();startActivity(Intent(this@MainActivity,StudyToolsActivity::class.java))}})
        scroll.addView(box);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if (isFinishing || isDestroyed) return
        dialog.setContentView(root)
        dialog.setOnDismissListener { if (analyticsDialog === dialog) analyticsDialog = null }
        dialog.show()
        dialog.window?.setLayout(-1,(resources.displayMetrics.heightPixels*0.92f).toInt())
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        } catch (t:Exception) {
            analyticsDialog = null
            resultOf { if (!isFinishing && !isDestroyed) RovexUndoSnackbar.show(window.decorView,"Analytics could not be opened. Please try again.") }
        }
    }

    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==RovexDailyStudyHub.CALENDAR_PERMISSION_REQUEST) RovexDailyStudyHub.onCalendarPermissionResult(this,grantResults)
    }
    fun openQBankImporterFromHome(){ openImporter() }
    private fun openImporter(){
        htmlImportLauncher.launch(arrayOf("text/html", "text/plain", "application/xhtml+xml"))
    }

    override fun onDestroy(){analyticsDialog?.dismiss();analyticsDialog=null;AppState.unregister(stateListener);StudyEventSpine.unsubscribe(milestoneListener);celebrationView=null;super.onDestroy()}

}

private fun Int.dp(context: android.content.Context): Int = (this * context.resources.displayMetrics.density).toInt()
