plugins {
    id("com.android.application") version "9.1.1" apply false
    id("com.android.test") version "9.1.1" apply false
}
