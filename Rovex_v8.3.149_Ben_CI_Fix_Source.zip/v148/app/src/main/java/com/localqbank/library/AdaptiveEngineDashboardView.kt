package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Compact, lifecycle-fed visualization for Adaptive Engine + Ben runtime state.
 * It owns no policy and never samples engines itself; SettingsScreen supplies snapshots.
 */
class AdaptiveEngineDashboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val density = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.8f * density }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }
    private var adaptive: AdaptiveEngineManager.State? = null
    private var telemetry: BenNeuralTelemetry.Snapshot = BenNeuralTelemetry.Snapshot()
    private var ramMb: Int = 0
    private var thermal: String = "—"
    private var pulse: Float = 0f

    fun update(state: AdaptiveEngineManager.State, telemetry: BenNeuralTelemetry.Snapshot, ramText: String, thermal: String) {
        this.adaptive = state
        this.telemetry = telemetry
        this.ramMb = ramText.toIntOrNull() ?: 0
        this.thermal = thermal
        pulse = (pulse + 0.16f) % 1f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val state = adaptive ?: return
        val dark = ThemeManager.isDark(context)
        val bg = if (ThemeManager.get(context) == ThemeManager.AMOLED) android.graphics.Color.BLACK else ThemeManager.elevated(context)
        val fg = ThemeManager.text(context)
        val muted = ThemeManager.muted(context)
        val accent = ThemeManager.accent(context)
        val border = if (dark) android.graphics.Color.rgb(58, 72, 88) else android.graphics.Color.rgb(220, 226, 230)
        fill.color = bg
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 20f * density, 20f * density, fill)

        val cx = width * .5f
        val cy = height * .38f
        val radius = min(width, height) * .19f
        val nodes = arrayOf("LEARN", "BEN", "RUNTIME", "RESILIENCE", "BATTERY", "RAG")
        val values = intArrayOf(state.learningScore, telemetry.lastConfidence, state.health, state.health, 100 - state.exploration.coerceIn(0, 100), state.confidence)
        val nodeRadius = 20f * density

        line.color = border
        for (i in nodes.indices) {
            val angle = (-Math.PI / 2.0) + i * (Math.PI * 2.0 / nodes.size)
            val nx = cx + cos(angle).toFloat() * radius
            val ny = cy + sin(angle).toFloat() * radius
            canvas.drawLine(cx, cy, nx, ny, line)
        }

        fill.color = accent
        canvas.drawCircle(cx, cy, nodeRadius * (1f + .08f * sin(pulse * Math.PI * 2).toFloat()), fill)
        text.color = android.graphics.Color.WHITE
        text.textSize = 9f * density
        text.textAlign = Paint.Align.CENTER
        canvas.drawText("ADAPTIVE", cx, cy + 3f * density, text)

        for (i in nodes.indices) {
            val angle = (-Math.PI / 2.0) + i * (Math.PI * 2.0 / nodes.size)
            val nx = cx + cos(angle).toFloat() * radius
            val ny = cy + sin(angle).toFloat() * radius
            fill.color = if (i == 1 && telemetry.stage != BenNeuralTelemetry.Stage.IDLE) accent else border
            canvas.drawCircle(nx, ny, nodeRadius, fill)
            text.color = if (i == 1 && telemetry.stage != BenNeuralTelemetry.Stage.IDLE) android.graphics.Color.WHITE else fg
            text.textSize = 7.5f * density
            canvas.drawText(nodes[i], nx, ny + 2.5f * density, text)
        }

        val left = 18f * density
        val right = width - 18f * density
        val base = height - 37f * density
        val barW = (right - left - 5f * density * 5) / 6f
        val maxH = 25f * density
        val histogram = intArrayOf(state.learningScore, state.confidence, state.health, telemetry.lastConfidence, telemetry.lastEvidenceCount.coerceAtMost(100), (ramMb / 20).coerceIn(0, 100))
        val labels = arrayOf("L", "C", "H", "B", "E", "R")
        histogram.forEachIndexed { i, value ->
            val x = left + i * (barW + 5f * density)
            val h = maxH * (value.coerceIn(0, 100) / 100f)
            fill.color = if (i == 1 && telemetry.stage != BenNeuralTelemetry.Stage.IDLE) accent else border
            canvas.drawRoundRect(RectF(x, base - h, x + barW, base), 5f * density, 5f * density, fill)
            text.color = muted
            text.textSize = 7f * density
            canvas.drawText(labels[i], x + barW / 2f, base + 12f * density, text)
        }

        text.color = fg
        text.textAlign = Paint.Align.LEFT
        text.textSize = 10f * density
        canvas.drawText("LIVE ENGINE TOPOLOGY", left, 17f * density, text)
        text.color = muted
        text.textSize = 8f * density
        canvas.drawText("${telemetry.stage.name.replace('_', ' ')}  •  RAM ${ramMb}MB  •  thermal $thermal", left, 30f * density, text)
        text.textAlign = Paint.Align.CENTER
    }
}
