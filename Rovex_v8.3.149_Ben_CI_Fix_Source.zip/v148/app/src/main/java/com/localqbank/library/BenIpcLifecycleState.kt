package com.localqbank.library

/** Pure, deterministic IPC lifecycle guard. No Android/native dependencies.
 *
 * Terminal and release are deliberately separate: callers may finish the client-visible
 * request before the native runtime has actually been released. The monitor makes the
 * transition exactly-once under Binder/coroutine race conditions.
 */
internal class BenIpcLifecycleState {
    enum class Phase { ACTIVE, TERMINAL, RELEASED }
    private var phase = Phase.ACTIVE
    @Synchronized fun phase(): Phase = phase
    @Synchronized fun terminal(): Boolean {
        if (phase != Phase.ACTIVE) return false
        phase = Phase.TERMINAL
        return true
    }
    @Synchronized fun released(): Boolean {
        if (phase == Phase.RELEASED) return false
        phase = Phase.RELEASED
        return true
    }
    @Synchronized fun canRunNative(): Boolean = phase == Phase.ACTIVE
}
