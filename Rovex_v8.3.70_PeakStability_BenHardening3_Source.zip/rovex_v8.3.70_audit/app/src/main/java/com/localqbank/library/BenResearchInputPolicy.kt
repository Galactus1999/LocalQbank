package com.localqbank.library

/** Deterministic, allocation-bounded input policy for Ben's local research gateway. */
object BenResearchInputPolicy {
    const val MAX_QUERY_CHARS = 4096

    fun normalize(raw: String): String? {
        if (raw.isEmpty()) return null
        // Bound both output size and scan work. Do not walk an arbitrarily large pasted payload.
        val bounded = truncateSafely(raw, MAX_QUERY_CHARS)
        val clean = buildString(bounded.length) {
            var pendingSpace = false
            for (ch in bounded) {
                when {
                    ch.isISOControl() && ch != '\n' && ch != '\t' -> Unit
                    ch.isWhitespace() -> pendingSpace = true
                    else -> {
                        if (pendingSpace && isNotEmpty()) append(' ')
                        pendingSpace = false
                        append(ch)
                    }
                }
            }
        }.trim()
        if (clean.isEmpty()) return null
        return truncateSafely(clean, MAX_QUERY_CHARS).trimEnd()
    }

    /** Truncates by Unicode code point so a limit never leaves a dangling surrogate. */
    private fun truncateSafely(value: String, maxChars: Int): String {
        if (value.length <= maxChars) return value
        var end = maxChars
        if (end > 0 && end < value.length && Character.isHighSurrogate(value[end - 1]) && Character.isLowSurrogate(value[end])) {
            end--
        }
        return value.substring(0, end)
    }
}
