package com.localqbank.library

/** Deterministic bounds and hygiene for text returned by an optional local Ben backend. */
object BenResponsePolicy {
    const val MAX_RESPONSE_CHARS = 16_384

    fun normalize(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val bounded = truncateSafely(raw, MAX_RESPONSE_CHARS)
        val clean = buildString(bounded.length) {
            var pendingSpace = false
            for (ch in bounded) {
                when {
                    ch.isISOControl() && ch != '\n' && ch != '\t' -> Unit
                    ch.isWhitespace() -> pendingSpace = true
                    else -> {
                        if (pendingSpace && isNotEmpty()) append(' ')
                        pendingSpace = false
                        append(ch)
                    }
                }
            }
        }.trim()
        return truncateSafely(clean, MAX_RESPONSE_CHARS).trimEnd().takeIf { it.isNotEmpty() }
    }

    /** Truncates without leaving a dangling UTF-16 surrogate. */
    private fun truncateSafely(value: String, maxChars: Int): String {
        if (value.length <= maxChars) return value
        var end = maxChars
        if (end > 0 && end < value.length && Character.isHighSurrogate(value[end - 1]) && Character.isLowSurrogate(value[end])) {
            end--
        }
        return value.substring(0, end)
    }
}
