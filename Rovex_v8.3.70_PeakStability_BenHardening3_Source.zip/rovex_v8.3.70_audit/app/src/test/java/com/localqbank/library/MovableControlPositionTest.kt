package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Test

class MovableControlPositionTest {
    @Test fun savedPositionScalesToNewContainer() {
        val p = MovableControlPosition.resolve(0.5f, 0.25f, 200, 400, 0.9f, 0.1f)
        assertEquals(100f, p.x, 0.001f)
        assertEquals(100f, p.y, 0.001f)
    }

    @Test fun defaultPositionIsUsedWhenNothingWasSaved() {
        val p = MovableControlPosition.resolve(Float.NaN, Float.NaN, 200, 400, 0.9f, 0.1f)
        assertEquals(180f, p.x, 0.001f)
        assertEquals(40f, p.y, 0.001f)
    }

    @Test fun nonFiniteSavedCoordinatesFallBackToDefaults() {
        val p = MovableControlPosition.resolve(Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY, 200, 400, 0.9f, 0.1f)
        assertEquals(180f, p.x, 0.001f)
        assertEquals(40f, p.y, 0.001f)
    }

    @Test fun nonFiniteDraggedCoordinatesNormalizeSafely() {
        val p = MovableControlPosition.normalized(Float.NaN, Float.POSITIVE_INFINITY, 200, 400)
        assertEquals(0f, p.x, 0.001f)
        assertEquals(0f, p.y, 0.001f)
    }

    @Test fun positionsAreClampedAndNormalized() {
        val p = MovableControlPosition.normalized(500f, -10f, 200, 400)
        assertEquals(1f, p.x, 0.001f)
        assertEquals(0f, p.y, 0.001f)
    }
}
