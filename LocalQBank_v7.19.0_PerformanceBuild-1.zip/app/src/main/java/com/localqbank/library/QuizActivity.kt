package com.localqbank.library

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.net.Uri
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Html
import android.text.Spanned
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.app.AlertDialog
import android.app.Dialog
import android.view.MotionEvent
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.widget.*
import android.os.CountDownTimer
import android.os.SystemClock
import android.text.InputType
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {
    private lateinit var db: QBankDb
    private lateinit var store: ProgressStore
    private lateinit var testId: String
    private var questionCount = 0
    private var currentQuestion: Question? = null
    private var sourceId = 0L
    private var pos = 0
    private lateinit var title: String
    private lateinit var content: LinearLayout
    private lateinit var counter: TextView
    private lateinit var result: TextView
    private lateinit var scroll: LockedScrollView
    private lateinit var bookmarkButton: TextView
    private lateinit var settingsButton: TextView
    private lateinit var sectionChip: TextView
    private lateinit var jumpButton: TextView
    private var fontScale = 1f
    private var fontFamily = "sans-serif"
    private var headerMm = 10f
    private var sectionLabel: String? = null
    // Practice mode hides previously saved answers so a question can be actively recalled again.
    private var practiceMode = false
    private var practiceAnsweredKey: String? = null
    // Collection mode is a filtered question session (Wrong/Solved/Unsolved/Bookmarks).
    // It deliberately ignores the parent QBank section for swipe/jump navigation.
    private var collectionMode = false
    private var collectionQuestionIds: LongArray = longArrayOf()
    private var bankName: String = "QBank"
    private var examMode = false
    private var examDurationMinutes = 0
    private var examRemainingMs = 0L
    private var examTimer: CountDownTimer? = null
    private var guidanceTimer: CountDownTimer? = null
    private var guidanceRemainingMs = 0L
    private val guidanceSecondsPerQuestion = 60L
    private val examAnswers = linkedMapOf<String, Boolean>()
    private var sessionLabel: String? = null
    private lateinit var bankNameView: TextView
    private var gestureDownX = 0f
    private var gestureDownY = 0f
    private var questionStartedAt = 0L
    private var timeRecordedForKey: String? = null
    private var questionLoadToken = 0L
    private val imageExecutor = java.util.concurrent.Executors.newFixedThreadPool(2)
    private val prefetchExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val spannedCache = object : java.util.LinkedHashMap<String, Spanned>(16, 0.75f, true) { override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Spanned>?) = size > 16 }
    // Small LRU keeps adjacent questions hot; avoids repeated SQLite joins while swiping.
    private val questionCache = object : java.util.LinkedHashMap<String, Question>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Question>?): Boolean = size > 8
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try {
            db = QBankDb(this)
            store = ProgressStore(this)
            title = extraText("title") ?: "QBank"
            testId = extraText("testId") ?: ""
            val sessionIdsRaw = extraText("sessionIds")
            collectionMode = intent.getBooleanExtra("collectionMode", false) || !sessionIdsRaw.isNullOrBlank()
            val exactQuestionId = extraLong("questionId")
            val requested = extraInt("position", -1)
            examMode = intent.getBooleanExtra("examMode", false)
            examDurationMinutes = extraInt("examDurationMinutes", 0).coerceIn(1, 240)
            sessionLabel = extraText("sessionLabel")

            if (!sessionIdsRaw.isNullOrBlank()) {
                // Validate the lightweight ID session against SQLite before rendering.
                // This prevents stale/deleted IDs from producing a reviewer crash.
                val requestedIds = sessionIdsRaw.split(',').mapNotNull { it.toLongOrNull() }.filter { it > 0L }.distinct().take(500).toLongArray()
                val existing = runCatching { db.existingQuestionIds(requestedIds).toSet() }.getOrDefault(emptySet())
                collectionQuestionIds = requestedIds.filter { it in existing }.toLongArray()
                questionCount = collectionQuestionIds.size
                if (questionCount == 0) { showFatalError("This practice session has no available questions."); return }
                pos = if (exactQuestionId > 0L) collectionQuestionIds.indexOf(exactQuestionId).takeIf { it >= 0 } ?: requested.coerceIn(0, questionCount-1) else requested.coerceIn(0, questionCount-1)
                testId = db.questionById(collectionQuestionIds[pos])?.let { findTestIdForQuestion(it.id) } ?: ""
                sourceId = if (testId.isBlank()) 0L else db.sourceIdForTest(testId)
            } else if (collectionMode) {
                val filterType = extraText("collectionFilterType") ?: "status"
                val filterValue = extraText("collectionFilterValue") ?: "unsolved"
                collectionQuestionIds = buildCollectionQuestionIds(filterType, filterValue)
                questionCount = collectionQuestionIds.size
                if (questionCount == 0) { showFatalError("There are no questions in this collection yet."); return }
                pos = if (exactQuestionId > 0L) collectionQuestionIds.indexOf(exactQuestionId).takeIf { it >= 0 } ?: requested.coerceIn(0, questionCount-1) else requested.coerceIn(0, questionCount-1)
                if (testId.isBlank()) testId = db.questionById(collectionQuestionIds[pos])?.let { findTestIdForQuestion(it.id) } ?: ""
                sourceId = if (testId.isBlank()) 0L else db.sourceIdForTest(testId)
            } else {
                if (testId.isBlank()) { showFatalError("This section could not be opened because its QBank ID is missing."); return }
                questionCount = db.questionCount(testId)
                sourceId = db.sourceIdForTest(testId)
                pos = (if (requested >= 0) requested else store.position(testId)).coerceIn(0, (questionCount - 1).coerceAtLeast(0))
            }
            val ui = getSharedPreferences("ui", MODE_PRIVATE)
            fontScale = ui.getFloat("quiz_font_scale", 1f).coerceIn(.85f, 1.30f)
            fontFamily = ui.getString("quiz_font_family", "sans-serif") ?: "sans-serif"
            headerMm = ui.getFloat("quiz_header_mm", 10f).coerceIn(7f, 13f)
            sectionLabel = extraText("sectionLabel")
            practiceMode = intent.getBooleanExtra("practiceMode", false)
            bankName = sessionLabel ?: db.sourceNameForTest(testId) ?: "QBank"
            setContentView(build())
            // Exact-question routing is resolved against the lightweight session/test metadata.
            // Full question content is deliberately loaded off the UI thread.
            if (!collectionMode && exactQuestionId > 0L) {
                val exactPos = runCatching {
                    db.rawQuestionPosition(testId, exactQuestionId)
                }.getOrNull()
                if (exactPos != null) pos = exactPos.coerceIn(0, (questionCount - 1).coerceAtLeast(0))
            }
            show()
            if (examMode && examDurationMinutes > 0) startExamTimer(examDurationMinutes)
            else if (!examMode) startGuidanceTimer()
        } catch (t: Throwable) {
            showFatalError("Unable to open this question. The QBank data is still safe.\n\n${t.javaClass.simpleName}: ${t.message ?: "unknown error"}")
        }
    }

    private fun buildCollectionQuestionIds(type: String, value: String): LongArray {
        val refs = PerformanceManager.refs(applicationContext)
        val progress = PerformanceManager.progress(applicationContext)
        return refs.asSequence().filter { r ->
            val p = progress.record(r.stableKey)
            when (type) {
                "status" -> when (value) {
                    "unsolved" -> p?.status == null
                    else -> p?.status == value
                }
                "bookmark" -> if (value == "all") !p?.bookmark.isNullOrBlank() else p?.bookmark == value
                else -> false
            }
        }.map { it.id }.toList().toLongArray()
    }

    private fun findTestIdForQuestion(questionId: Long): String = db.testIdForQuestion(questionId) ?: ""

    /** Read navigation extras defensively. Older builds may have stored IDs as numeric extras. */
    private fun extraText(key: String): String? = when (val v = intent.extras?.get(key)) {
        null -> null
        is String -> v
        is CharSequence -> v.toString()
        is Number -> v.toString()
        else -> v.toString()
    }

    private fun extraLong(key: String): Long = when (val v = intent.extras?.get(key)) {
        is Number -> v.toLong()
        is String -> v.toLongOrNull() ?: -1L
        else -> -1L
    }

    private fun extraInt(key: String, fallback: Int): Int = when (val v = intent.extras?.get(key)) {
        is Number -> v.toInt()
        is String -> v.toIntOrNull() ?: fallback
        else -> fallback
    }

    private fun showFatalError(message: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(ThemeManager.bg(this@QuizActivity))
        }
        val titleView = TextView(this).apply {
            text = "Could not open question"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ThemeManager.text(this@QuizActivity))
            gravity = Gravity.CENTER
        }
        val detail = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(ThemeManager.muted(this@QuizActivity))
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(20))
        }
        val back = Button(this).apply {
            text = "← Back"
            setOnClickListener { finish() }
        }
        root.addView(titleView, LinearLayout.LayoutParams(-1, -2))
        root.addView(detail, LinearLayout.LayoutParams(-1, -2))
        root.addView(back, LinearLayout.LayoutParams(-2, dp(52)))
        setContentView(root)
    }

    private fun startGuidanceTimer(){
        if(examMode || questionCount<=0) return
        guidanceTimer?.cancel()
        guidanceRemainingMs=guidanceSecondsPerQuestion*1000L
        updateGuidanceTimer()
        guidanceTimer=object:CountDownTimer(guidanceRemainingMs,1000){
            override fun onTick(ms:Long){guidanceRemainingMs=ms;updateGuidanceTimer()}
            override fun onFinish(){guidanceRemainingMs=0;updateGuidanceTimer()}
        }.start()
    }
    private fun updateGuidanceTimer(){
        if(!::counter.isInitialized || examMode) return
        val sec=(guidanceRemainingMs/1000).coerceAtLeast(0)
        val label=if(sec>0) String.format("%02d:%02d",sec/60,sec%60) else "Overtime"
        counter.text="Question ${pos+1} / ${questionCount}  •  Guide $label"
    }

    private fun startExamTimer(minutes:Int){
        examTimer?.cancel()
        examRemainingMs=minutes*60_000L
        examTimer=object:CountDownTimer(examRemainingMs,1000){
            override fun onTick(ms:Long){ examRemainingMs=ms; updateExamTimer() }
            override fun onFinish(){ examRemainingMs=0; updateExamTimer(); submitExam(true) }
        }.start()
    }
    private fun updateExamTimer(){
        if (!::counter.isInitialized) return
        val sec=(examRemainingMs/1000).coerceAtLeast(0)
        val text=String.format("%02d:%02d",sec/60,sec%60)
        counter.text="${pos+1}/$questionCount  •  $text"
    }
    private fun submitExam(auto:Boolean=false){
        examTimer?.cancel()
        val total=examAnswers.size
        val correct=examAnswers.values.count{it}
        val wrong=total-correct
        val unanswered=(questionCount-total).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(if(auto) "Time is up" else "Exam submitted")
            .setMessage("Correct: $correct\nWrong: $wrong\nUnanswered: $unanswered\nAttempted: $total/$questionCount")
            .setPositiveButton("Done"){_,_->finish()}
            .setCancelable(false).show()
    }
    override fun onStop(){ BackupManager(this).flushCloudBackup(); guidanceTimer?.cancel(); examTimer?.cancel(); super.onStop() }

    override fun onDestroy() {
        imageExecutor.shutdownNow(); prefetchExecutor.shutdownNow(); guidanceTimer?.cancel(); examTimer?.cancel()
        if (::db.isInitialized) runCatching { db.close() }
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { gestureDownX = ev.rawX; gestureDownY = ev.rawY }
            MotionEvent.ACTION_UP -> {
                val dx = ev.rawX - gestureDownX
                val dy = ev.rawY - gestureDownY
                if (kotlin.math.abs(dx) > dp(56) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.15f) {
                    if (dx < 0 && pos < questionCount - 1) { recordCurrentTime(); pos++; savePosition(); show(); startGuidanceTimer(); return true }
                    if (dx > 0 && pos > 0) { recordCurrentTime(); pos--; savePosition(); show(); startGuidanceTimer(); return true }
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onPause() {
        recordCurrentTime()
        savePosition()
        super.onPause()
    }

    private fun recordCurrentTime() {
        val key = currentQuestion?.stableKey
        if (questionStartedAt <= 0L || key.isNullOrBlank() || timeRecordedForKey == key) return
        store.addTime(key, (SystemClock.elapsedRealtime() - questionStartedAt).coerceAtLeast(0L))
        timeRecordedForKey = key
    }

    private fun savePosition() {
        if (collectionMode) return
        if (::store.isInitialized && testId.isNotBlank()) store.setPosition(testId, pos, sourceId, bankName)
    }


    private fun build(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ThemeManager.bg(this@QuizActivity))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(34, 86, 120))
            clipToPadding = false
        }
        SystemUi.padTopInset(top, 8, 8, 12, 12)

        val back = headerButton("←", 24f) { finish() }
        top.addView(back, LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(0, 0, dp(8), 0) })

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply {
            text = title
            textSize = 18f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, dp(4), 0)
        }
        titleBox.addView(tv, LinearLayout.LayoutParams(-1, dp(26)))
        val subRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bankNameView = TextView(this).apply {
            text = bankName
            textSize = 11f
            setTextColor(Color.rgb(210, 231, 242))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        subRow.addView(bankNameView, LinearLayout.LayoutParams(0, dp(24), 1f))
        sectionChip = TextView(this).apply {
            textSize = 10f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(25, 74, 94))
            gravity = Gravity.CENTER
            setPadding(dp(9), 0, dp(9), 0)
        }
        subRow.addView(sectionChip, LinearLayout.LayoutParams(-2, dp(22)).apply { setMargins(dp(6), 0, 0, 0) })
        titleBox.addView(subRow, LinearLayout.LayoutParams(-1, dp(24)))
        top.addView(titleBox, LinearLayout.LayoutParams(0, -1, 1f))

        settingsButton = headerButton("⚙", 20f) { showSettingsMenu(settingsButton) }
        top.addView(settingsButton, LinearLayout.LayoutParams(dp(50), dp(50)).apply { setMargins(dp(4), 0, 0, 0) })
        if (examMode) {
            val submit = headerButton("✓", 20f) { submitExam(false) }
            submit.contentDescription="Submit exam"
            top.addView(submit, LinearLayout.LayoutParams(dp(50), dp(50)).apply { setMargins(dp(4), 0, 0, 0) })
        }
        top.minimumHeight = headerHeightPx()
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val infoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(1), dp(18), dp(1))
            setBackgroundColor(ThemeManager.elevated(this@QuizActivity))
        }
        counter = TextView(this).apply {
            textSize = 14f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.text(this@QuizActivity))
            gravity = Gravity.CENTER_VERTICAL
        }
        infoRow.addView(counter, LinearLayout.LayoutParams(0, dp(22), 1f))
        jumpButton = TextView(this).apply {
            textSize = 14f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.accent(this@QuizActivity))
            gravity = Gravity.CENTER
            background = rounded(if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) Color.rgb(31,55,76) else Color.rgb(220,241,244), 10f)
            elevation = dp(2).toFloat()
            setOnClickListener { showQuestionJumpMenu(this) }
            contentDescription = "Jump to question"
        }
        infoRow.addView(jumpButton, LinearLayout.LayoutParams(dp(34), dp(22)).apply { setMargins(dp(16), 0, 0, 0) })
        root.addView(infoRow)

        scroll = LockedScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setBackgroundColor(ThemeManager.panel(this@QuizActivity))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(30))
            setBackgroundColor(ThemeManager.panel(this@QuizActivity))
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        result = TextView(this).apply {
            setPadding(dp(20), dp(10), dp(20), dp(10))
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setBackgroundColor(Color.rgb(238, 246, 251))
            visibility = View.GONE
        }
        root.addView(result)
        return root
    }

    private fun headerButton(label: String, size: Float, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(31,43,58) else Color.rgb(28,70,103), 12f)
        setOnClickListener { click() }
        isClickable = true
        isFocusable = true
    }

    private fun actionButton(label: String, color: Int, size: Float = 13f, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(ThemeManager.text(this@QuizActivity))
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = bookmarkPopupDrawable(color)
        elevation = dp(3).toFloat()
        setPadding(dp(8), 0, dp(8), 0)
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun optionCard(q: Question, option: Option, answered: Boolean) {
        val correct = option.correct ||
            q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(option.label.trim() + ".", true) == true
        val selected = answered && store.selected(q.stableKey)?.equals(option.label, true) == true
        val bg = when {
            !answered -> ThemeManager.optionBg(this@QuizActivity)
            correct -> ThemeManager.correctBg(this@QuizActivity)
            selected -> ThemeManager.wrongBg(this@QuizActivity)
            else -> ThemeManager.elevated(this@QuizActivity)
        }
        val fg = when {
            !answered -> ThemeManager.optionText(this@QuizActivity)
            correct -> ThemeManager.correctText(this@QuizActivity)
            selected -> ThemeManager.wrongText(this@QuizActivity)
            else -> ThemeManager.muted(this@QuizActivity)
        }
        val row = LinearLayout(this).apply {
            tag = "option:${option.label}"
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = if (answered) dp(62) else dp(70)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = rounded(bg, 20f)
            isClickable = !answered
            isFocusable = !answered
            if (!answered) setOnClickListener { answer(option.label) }
        }
        val letter = TextView(this).apply {
            text = option.label
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(if (!answered) (if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) Color.rgb(43,60,79) else Color.rgb(207,224,240)) else bg, 50f)
        }
        row.addView(letter, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(0, 0, dp(14), 0) })
        val text = TextView(this).apply {
            this.text = toSpanned(option.text)
            textSize = 17.5f * fontScale
            setTypeface(Typeface.create(fontFamily, Typeface.NORMAL))
            setTextColor(fg)
            gravity = Gravity.CENTER_VERTICAL
            setLineSpacing(0f, 1.16f)
        }
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) })
    }

    private fun answer(label: String) {
        val q = currentQuestion ?: return
        if (!practiceMode && store.status(q.stableKey) != null) return
        val selected = q.options.firstOrNull { it.label.equals(label, true) }
        val correct = selected?.correct == true ||
            q.correctAnswer?.trim()?.equals(label.trim(), true) == true ||
            q.correctAnswer?.trim()?.equals(label.trim() + ".", true) == true
        recordCurrentTime()
        if (examMode) {
            examAnswers[q.stableKey] = correct
            practiceAnsweredKey = q.stableKey
        } else {
            store.setAnswer(q.stableKey, label, if (correct) "correct" else "wrong")
            practiceAnsweredKey = if (practiceMode) q.stableKey else null
        }
        // Do not rebuild the entire question hierarchy after every tap. The old show()
        // path reparsed HTML and recreated every option, which made answer marking feel laggy.
        showAnsweredInPlace(q, label, correct)
    }

    private fun showAnsweredInPlace(q: Question, label: String, correct: Boolean) {
        val dark = ThemeManager.get(this@QuizActivity) == ThemeManager.DARK
        for (i in 0 until content.childCount) {
            val row = content.getChildAt(i) as? LinearLayout ?: continue
            val tag = row.tag?.toString() ?: continue
            if (!tag.startsWith("option:")) continue
            val optionLabel = tag.removePrefix("option:")
            val option = q.options.firstOrNull { it.label.equals(optionLabel, true) } ?: continue
            val isCorrect = option.correct || q.correctAnswer?.trim()?.equals(option.label.trim(), true) == true || q.correctAnswer?.trim()?.equals(option.label.trim()+".", true) == true
            val isSelected = option.label.equals(label, true)
            val bg = when { isCorrect -> ThemeManager.correctBg(this@QuizActivity); isSelected -> ThemeManager.wrongBg(this@QuizActivity); else -> ThemeManager.elevated(this@QuizActivity) }
            val fg = when { isCorrect -> ThemeManager.correctText(this@QuizActivity); isSelected -> ThemeManager.wrongText(this@QuizActivity); else -> ThemeManager.muted(this@QuizActivity) }
            row.background = rounded(bg,20f); row.isClickable=false; row.isFocusable=false
            (row.getChildAt(0) as? TextView)?.apply { setTextColor(fg); background=rounded(bg,50f) }
            (row.getChildAt(1) as? TextView)?.setTextColor(fg)
        }
        result.visibility = View.VISIBLE
        result.text = if (correct) "✓  Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}" else "✗  Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}"
        result.setTextColor(if (!correct) ThemeManager.wrongText(this@QuizActivity) else ThemeManager.correctText(this@QuizActivity))
        result.setBackgroundColor(if (!correct) ThemeManager.wrongBg(this@QuizActivity) else ThemeManager.correctBg(this@QuizActivity))
        scroll.isVerticalScrollBarEnabled = true
        // Keep answer feedback instant; explanation is added on the next UI turn so the
        // selected state gets a frame before potentially expensive HTML parsing/layout.
        content.post {
            if (isFinishing || isDestroyed || currentQuestion?.stableKey != q.stableKey) return@post
            appendAnswerDetails(q, !correct)
        }
    }

    private fun appendAnswerDetails(q: Question, wrong: Boolean) {
        // Avoid duplicate explanation if a rapid lifecycle callback already appended it.
        if (content.findViewWithTag<View>("explanation-panel:${q.stableKey}") != null) return
        if (wrong) {
            val why = TextView(this).apply {
                text = store.mistakeType(q.stableKey)?.let { "Why I missed it: $it  •  Tap to change" } ?: "🧠 Why did I miss this?"
                textSize = 12.5f * fontScale; setTypeface(null, Typeface.BOLD); setTextColor(ThemeManager.accent(this@QuizActivity)); setPadding(dp(4),dp(10),dp(4),dp(4)); setOnClickListener{showMistakeTypeDialog(q)}
            }
            content.addView(why,LinearLayout.LayoutParams(-1,-2)); why.tag="explanation-why:${q.stableKey}"
        }
        val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(4));background=rounded(ThemeManager.explanationBg(this@QuizActivity),16f);tag="explanation-panel:${q.stableKey}"}
        panel.addView(TextView(this).apply{text="EXPLANATION";textSize=12.5f*fontScale;setTypeface(Typeface.create(fontFamily,Typeface.BOLD));setTextColor(ThemeManager.explanationTitle(this@QuizActivity));setLetterSpacing(.06f)},LinearLayout.LayoutParams(-1,dp(28)))
        content.addView(panel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(2))})
        addHtmlText(q.explanation ?: "<p>No explanation available.</p>",17f*fontScale,false,ThemeManager.text(this@QuizActivity),q.id)
        q.explanationImages.forEach{addImage(it)}
    }

    private fun show() {
        content.removeAllViews()
        if (questionCount == 0) {
            counter.text = "No questions imported"
            addHtmlText("<h2>No questions</h2><p>Import a QBank HTML file first.</p>", 20f)
            result.visibility = View.GONE
            scroll.locked = true
            return
        }
        val key = if (collectionMode) "id:${collectionQuestionIds.getOrNull(pos) ?: -1L}" else "$testId:$pos"
        val q = synchronized(questionCache) { questionCache[key] }
        if (q == null) {
            counter.text = "Loading question ${pos + 1} / $questionCount…"
            result.visibility = View.GONE
            questionLoadToken++
            val token = questionLoadToken
            prefetchExecutor.execute {
                val loaded = runCatching {
                    if (collectionMode) collectionQuestionIds.getOrNull(pos)?.let { db.questionById(it) }
                    else db.questionAt(testId, pos)
                }.getOrNull()
                runOnUiThread {
                    if (isFinishing || isDestroyed || token != questionLoadToken) return@runOnUiThread
                    if (loaded != null) {
                        synchronized(questionCache) { questionCache[key] = loaded }
                        show()
                    } else {
                        counter.text = "Question unavailable"
                    }
                }
            }
            return
        }
        recordCurrentTime()
        currentQuestion = q
        questionStartedAt = SystemClock.elapsedRealtime()
        timeRecordedForKey = null
        savePosition()
        val status = store.status(q.stableKey)
        val answered = if (examMode) examAnswers.containsKey(q.stableKey) else if (practiceMode) practiceAnsweredKey == q.stableKey else status != null
        if(examMode) updateExamTimer() else updateGuidanceTimer()
        jumpButton.text = (pos + 1).toString()
        // The question area must remain scrollable even before answering, especially for image-based questions.
        // Explanations are only added after an answer, so there is nothing to reveal prematurely.
        scroll.locked = false
        scroll.isVerticalScrollBarEnabled = answered
        updateSectionChip(q, status)

        val bm = TextView(this).apply {
            textSize = 13.5f
            setTextColor(ThemeManager.text(this@QuizActivity))
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            elevation = dp(5).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            background = bookmarkGradient()
            setOnClickListener { showBookmarkMenu(this) }
        }
        updateBookmarkButton(q, bm)
        bookmarkButton = bm

        addHtmlText(q.text, 20f * fontScale, true)
        q.questionImages.forEach { addImage(it) }
        q.options.forEach { optionCard(q, it, answered) }

        // Keep bookmarking near the lower-left of the question content, after the options.
        // This avoids competing with the question counter/jump control at the top.
        val noteButton=TextView(this).apply{
            text="📝 Note"; textSize=13.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            setTextColor(ThemeManager.accent(this@QuizActivity)); background=rounded(ThemeManager.elevated(this@QuizActivity),18f)
            setPadding(dp(14),0,dp(14),0); setOnClickListener{showNoteEditor(q)}
        }
        val actionRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.END}
        actionRow.addView(noteButton,LinearLayout.LayoutParams(-2,dp(46)).apply{setMargins(0,dp(8),dp(8),dp(14))})
        actionRow.addView(bm,LinearLayout.LayoutParams(-2,dp(46)).apply{setMargins(0,dp(8),dp(4),dp(14))})
        content.addView(actionRow,LinearLayout.LayoutParams(-1,dp(60)))

        if (answered && !examMode) {
            result.visibility = View.VISIBLE
            result.text = if (status == "correct") "✓  Correct  •  Answer: ${q.correctAnswer ?: "see highlighted option"}"
            else "✗  Wrong  •  Correct: ${q.correctAnswer ?: "see highlighted option"}"
            result.setTextColor(if (status == "wrong") ThemeManager.wrongText(this@QuizActivity) else ThemeManager.correctText(this@QuizActivity))
            result.setBackgroundColor(if (status == "wrong") ThemeManager.wrongBg(this@QuizActivity) else ThemeManager.correctBg(this@QuizActivity))
            if (status == "wrong") {
                val why = TextView(this).apply {
                    text = store.mistakeType(q.stableKey)?.let { "Why I missed it: $it  •  Tap to change" } ?: "🧠 Why did I miss this?"
                    textSize = 12.5f * fontScale
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(ThemeManager.accent(this@QuizActivity))
                    setPadding(dp(4), dp(10), dp(4), dp(4))
                    setOnClickListener { showMistakeTypeDialog(q) }
                }
                content.addView(why, LinearLayout.LayoutParams(-1, -2))
            }
            val explanationPanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(4))
                background = rounded(ThemeManager.explanationBg(this@QuizActivity), 16f)
            }
            val explanationTitle = TextView(this).apply {
                text = "EXPLANATION"
                textSize = 12.5f * fontScale
                setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
                setTextColor(ThemeManager.explanationTitle(this@QuizActivity))
                setLetterSpacing(0.06f)
            }
            explanationPanel.addView(explanationTitle, LinearLayout.LayoutParams(-1, dp(28)))
            content.addView(explanationPanel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(2)) })
            addHtmlText(q.explanation ?: "<p>No explanation available.</p>", 17f * fontScale, false, ThemeManager.text(this@QuizActivity), q.id)
            q.explanationImages.forEach { addImage(it) }
        } else {
            result.visibility = View.GONE
        }
        scroll.post { scroll.scrollTo(0, 0) }
        prefetchNextQuestion()
    }

    private fun prefetchNextQuestion() {
        // Keep a tiny rolling window hot. One question is normally enough, two makes rapid
        // swiping feel instantaneous without turning the cache into a memory sink.
        val targets = listOf(pos + 1, pos + 2).filter { it < questionCount }
        if (targets.isEmpty()) return
        prefetchExecutor.execute {
            targets.forEach { target ->
                runCatching {
                    val key = if (collectionMode) "id:${collectionQuestionIds.getOrNull(target) ?: return@forEach}" else "$testId:$target"
                    synchronized(questionCache) { if (questionCache.containsKey(key)) return@runCatching }
                    val q = if (collectionMode) collectionQuestionIds.getOrNull(target)?.let { db.questionById(it) } else db.questionAt(testId,target)
                    if (q != null) synchronized(questionCache) { questionCache[key] = q }
                }
            }
        }
    }

    private fun updateSectionChip(q: Question, status: String?) {
        val bookmark = store.bookmark(q.stableKey)
        val raw = sectionLabel?.trim()?.takeIf { it.isNotBlank() && !it.equals("practice", true) }
            ?: bookmark?.let { bookmarkLabel(it) }
            ?: when {
                status == "wrong" -> "Wrong"
                status == "correct" -> "Solved"
                else -> "Unsolved"
            }
        sectionChip.text = raw.uppercase()
        val bg = when (raw.lowercase()) {
            "important" -> Color.rgb(246, 235, 199)
            "revise" -> Color.rgb(222, 237, 251)
            "doubt" -> Color.rgb(237, 224, 247)
            "favourite", "favorite" -> Color.rgb(249, 222, 232)
            "wrong" -> Color.rgb(252, 224, 228)
            "solved" -> Color.rgb(221, 243, 230)
            else -> Color.rgb(226, 239, 244)
        }
        sectionChip.background = rounded(bg, 12f)
    }

    private fun applyHeaderHeight() {
        val root = window.decorView.findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0) as? ViewGroup
        root?.getChildAt(0)?.minimumHeight = headerHeightPx()
    }

    private fun headerHeightPx(): Int {
        val dpi = resources.displayMetrics.densityDpi.toFloat()
        val px = dpi * (headerMm / 25.4f)
        return px.toInt().coerceIn(dp(56), dp(104))
    }

    private fun showQuestionJumpMenu(anchor: View) {
        if (questionCount == 0) return
        val popup = PopupWindow(this).apply {
            width = dp(290)
            height = dp(190)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(ThemeManager.elevated(this@QuizActivity)); cornerRadius = dp(20).toFloat(); setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(55,69,86) else Color.rgb(210,223,231)) }
        }
        val heading = TextView(this).apply {
            text = "Jump to question"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.text(this@QuizActivity))
        }
        box.addView(heading, LinearLayout.LayoutParams(-1, dp(28)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 17f
            gravity = Gravity.CENTER
            setSingleLine(true)
            setSelectAllOnFocus(true)
            hint = "1 – ${questionCount}"
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(ThemeManager.optionBg(this@QuizActivity), 12f)
        }
        input.setText((pos + 1).toString())
        row.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val go = actionButton("GO", Color.rgb(27, 128, 91), 14f) {
            val n = input.text.toString().toIntOrNull()
            if (n != null && n in 1..questionCount) {
                pos = n - 1
                savePosition()
                popup.dismiss()
                show()
            } else input.error = "Enter 1–${questionCount}"
        }
        row.addView(go, LinearLayout.LayoutParams(dp(78), dp(52)).apply { setMargins(dp(10), 0, 0, 0) })
        box.addView(row, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(8), 0, 0) })
        val hint = TextView(this).apply {
            text = "Swipe left/right to move one question"
            textSize = 12f
            setTextColor(ThemeManager.muted(this@QuizActivity))
            gravity = Gravity.CENTER
        }
        box.addView(hint, LinearLayout.LayoutParams(-1, dp(28)).apply { setMargins(0, dp(5), 0, 0) })
        popup.contentView = box
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(12), (loc[1] + dp(48)).coerceAtLeast(dp(50)))
        box.startAnimation(ScaleAnimation(.94f, 1f, .94f, 1f, 1f, 0f).apply { duration = 160 })
        input.requestFocus()
        input.post { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun showSettingsMenu(anchor: View) {
        val popup = PopupWindow(this).apply {
            width = dp(320)
            height = dp(485)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(this@QuizActivity))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(55,69,86) else Color.rgb(210,223,231))
            }
        }
        val heading = TextView(this).apply {
            text = "Reading settings"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.text(this@QuizActivity))
        }
        box.addView(heading, LinearLayout.LayoutParams(-1, dp(30)))

        val fs = TextView(this).apply {
            text = "Font size"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(10), 0, dp(2))
        }
        box.addView(fs)
        val fsValue = TextView(this).apply {
            textSize = 13f
            setTextColor(ThemeManager.accent(this@QuizActivity))
            gravity = Gravity.CENTER_VERTICAL
        }
        box.addView(fsValue, LinearLayout.LayoutParams(-1, dp(24)))
        val seek = SeekBar(this).apply {
            max = 45
            progress = ((fontScale.coerceIn(.85f, 1.30f) - .85f) * 100f).toInt()
            setPadding(dp(4), 0, dp(4), 0)
        }
        fun fontText(p: Int) = "${85 + p}%  •  ${when { p < 10 -> "Small"; p < 18 -> "Medium"; p < 27 -> "Large"; else -> "Extra large" }}"
        fsValue.text = fontText(seek.progress)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { fsValue.text = fontText(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                fontScale = (.85f + seek.progress / 100f).coerceIn(.85f, 1.30f)
                getSharedPreferences("ui", MODE_PRIVATE).edit().putFloat("quiz_font_scale", fontScale).apply()
                show()
            }
        })
        box.addView(seek, LinearLayout.LayoutParams(-1, dp(46)))

        val ft = TextView(this).apply {
            text = "Font type"
            textSize = 14f
            setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(8), 0, dp(4))
        }
        box.addView(ft)
        val fonts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("sans-serif" to "Sans", "serif" to "Serif", "monospace" to "Mono").forEach { pair ->
            val b = TextView(this).apply {
                text = pair.second
                textSize = 12.5f
                gravity = Gravity.CENTER
                setTextColor(ThemeManager.text(this@QuizActivity))
                background = rounded(if (fontFamily == pair.first) ThemeManager.explanationBg(this@QuizActivity) else ThemeManager.elevated(this@QuizActivity), 12f)
                setOnClickListener {
                    fontFamily = pair.first
                    getSharedPreferences("ui", MODE_PRIVATE).edit().putString("quiz_font_family", fontFamily).apply()
                    popup.dismiss()
                    show()
                }
            }
            fonts.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply { if (pair.first != "sans-serif") setMargins(dp(5),0,0,0) })
        }
        box.addView(fonts, LinearLayout.LayoutParams(-1, dp(42)))

        val hs = TextView(this).apply {
            text = "Header height"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(10), 0, dp(4))
        }
        box.addView(hs)
        val heights = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(8f, 10f, 12f, 13f).forEach { mm ->
            val b = TextView(this).apply {
                text = "${mm.toInt()} mm"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(ThemeManager.text(this@QuizActivity))
                background = rounded(if (kotlin.math.abs(headerMm-mm)<.01f) ThemeManager.explanationBg(this@QuizActivity) else ThemeManager.elevated(this@QuizActivity), 12f)
                setOnClickListener {
                    headerMm = mm
                    getSharedPreferences("ui", MODE_PRIVATE).edit().putFloat("quiz_header_mm", mm).apply()
                    popup.dismiss()
                    savePosition()
                    applyHeaderHeight()
                    // Keep the exact current question; changing UI settings must never reset position.
                    if (!collectionMode) pos = store.position(testId).coerceIn(0, (questionCount - 1).coerceAtLeast(0))
                }
            }
            heights.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(if (mm == 8f) 0 else dp(4), 0, 0, 0) })
        }
        box.addView(heights, LinearLayout.LayoutParams(-1, dp(46)))

        val ap = TextView(this).apply { text = "Appearance"; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(Color.rgb(80,94,110)); setPadding(0, dp(10), 0, dp(4)) }
        box.addView(ap)
        val themes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(ThemeManager.LIGHT to "Light", ThemeManager.DARK to "Dark", ThemeManager.SEPIA to "Sepia").forEach { pair ->
            val b = TextView(this).apply { text = pair.second; textSize = 12f; gravity = Gravity.CENTER; setTextColor(ThemeManager.text(this@QuizActivity)); background = rounded(if (ThemeManager.get(this@QuizActivity)==pair.first) ThemeManager.explanationBg(this@QuizActivity) else ThemeManager.elevated(this@QuizActivity), 12f); setOnClickListener { ThemeManager.set(this@QuizActivity,pair.first); popup.dismiss(); recreate() } }
            themes.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply { if (pair.first != ThemeManager.LIGHT) setMargins(dp(5),0,0,0) })
        }
        box.addView(themes, LinearLayout.LayoutParams(-1, dp(42)))

        val note = TextView(this).apply {
            text = "Font size is continuous (85–115%) so larger text remains usable with scrolling."
            textSize = 11.5f
            setTextColor(ThemeManager.muted(this@QuizActivity))
            setPadding(0, dp(12), 0, 0)
        }
        box.addView(note, LinearLayout.LayoutParams(-1, dp(42)))

        popup.contentView = box
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(10), (loc[1] + dp(54)).coerceAtLeast(dp(40)))
        box.startAnimation(ScaleAnimation(.94f,1f,.94f,1f,1f,0f).apply{duration=160})
    }

    private fun updateBookmarkButton(q: Question, button: TextView) {
        val value = store.bookmark(q.stableKey)
        if (value.isNullOrBlank()) {
            button.text = "🔖  Bookmark"
            button.setTextColor(ThemeManager.text(this@QuizActivity))
        } else {
            button.text = "🔖  ${bookmarkLabel(value)}"
            button.setTextColor(ThemeManager.bookmarkText(this, value))
            button.background = rounded(ThemeManager.bookmarkFill(this, value), 20f)
        }
    }

    private fun bookmarkLabel(value: String) = when (value) {
        "important" -> "Important"
        "revise" -> "Revise"
        "doubt" -> "Doubt"
        "favorite" -> "Favourite"
        else -> "Bookmark"
    }

    private fun addHtmlText(html: String?, size: Float, bold: Boolean = false, color: Int? = null, noteQuestionId: Long? = null) {
        val raw = html ?: ""
        val imageSrcs = Regex("<img\\s+[^>]*src\\s*=\\s*[\"']([^\"']+)[^>]*>", RegexOption.IGNORE_CASE)
            .findAll(raw).map { it.groupValues[1] }.toList()
        var cleaned = raw.replace(Regex("<img\\s+[^>]*>", RegexOption.IGNORE_CASE), "")
        cleaned = cleaned.replace(Regex("(?i)data:image/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=\\r\\n]+"), "")
        cleaned = cleaned.replace(Regex("\\s+face\\s*=\\s*['\"][^'\"]*['\"]", RegexOption.IGNORE_CASE), "")

        if (Regex("<table\\b", RegexOption.IGNORE_CASE).containsMatchIn(cleaned)) {
            addRichHtmlWithTables(cleaned, size, bold, color, noteQuestionId)
        } else {
            addSelectableHtmlText(cleaned, size, bold, color, noteQuestionId)
        }
        imageSrcs.forEach { addImage(it) }
    }

    /** Render HTML fragments and real Android TableLayouts for Match-the-Following questions. */
    private fun addRichHtmlWithTables(html: String, size: Float, bold: Boolean, color: Int?, noteQuestionId: Long?) {
        val tableRx = Regex("<table\\b[^>]*>(.*?)</table>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        var cursor = 0
        for (m in tableRx.findAll(html)) {
            val before = html.substring(cursor, m.range.first)
            if (before.replace(Regex("<[^>]+>"), "").trim().isNotBlank()) addSelectableHtmlText(before, size, bold, color, noteQuestionId)
            addNativeHtmlTable(m.value, size, color)
            cursor = m.range.last + 1
        }
        val after = html.substring(cursor)
        if (after.replace(Regex("<[^>]+>"), "").trim().isNotBlank()) addSelectableHtmlText(after, size, bold, color, noteQuestionId)
    }

    private fun addSelectableHtmlText(html: String, size: Float, bold: Boolean, color: Int?, noteQuestionId: Long?) {
        val t = TextView(this).apply {
            text = toSpanned(html)
            textSize = size
            typeface = Typeface.create(fontFamily, if (bold) Typeface.BOLD else Typeface.NORMAL)
            setTextColor(color ?: ThemeManager.text(this@QuizActivity))
            setLineSpacing(0f, 1.25f)
            setPadding(0, 0, 0, dp(14))
            setTypeface(Typeface.create(fontFamily, if (bold) Typeface.BOLD else Typeface.NORMAL), if (bold) Typeface.BOLD else Typeface.NORMAL)
            if (noteQuestionId != null) configureNoteSelection(this, noteQuestionId)
        }
        content.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun configureNoteSelection(t: TextView, noteQuestionId: Long) {
        t.setTextIsSelectable(true)
        t.isLongClickable = true
        t.setCustomSelectionActionModeCallback(object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                menu?.add(0, 0x4E4F5445, 0, "Add to Notes")?.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
                return true
            }
            override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?) = false
            override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
                if (item?.itemId != 0x4E4F5445) return false
                val lo = minOf(t.selectionStart.coerceAtLeast(0), t.selectionEnd.coerceAtLeast(0))
                val hi = maxOf(t.selectionStart.coerceAtLeast(0), t.selectionEnd.coerceAtLeast(0))
                val selected = t.text?.subSequence(lo, hi)?.toString()?.trim().orEmpty()
                if (selected.isNotBlank()) {
                    val existing = db.note(noteQuestionId).orEmpty().trim()
                    db.saveNote(noteQuestionId, if (existing.isBlank()) selected else existing + "\\n\\n" + selected)
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Explanation", selected))
                    Toast.makeText(this@QuizActivity, "Selected text added to Notes", Toast.LENGTH_SHORT).show()
                }
                mode?.finish(); return true
            }
            override fun onDestroyActionMode(mode: ActionMode?) {}
        })
    }

    private fun addNativeHtmlTable(tableHtml: String, size: Float, color: Int?) {
        val outer = HorizontalScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setPadding(0, dp(4), 0, dp(16))
        }
        val table = TableLayout(this).apply {
            isStretchAllColumns = false
            isShrinkAllColumns = false
            setPadding(dp(1), dp(1), dp(1), dp(1))
        }
        val rows = Regex("<tr\\b[^>]*>(.*?)</tr>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(tableHtml)
        var rowIndex = 0
        for (rowMatch in rows) {
            val tr = TableRow(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val cells = Regex("<(td|th)\\b([^>]*)>(.*?)</\\1>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).findAll(rowMatch.groupValues[1])
            var cellIndex = 0
            for (cell in cells) {
                val tag = cell.groupValues[1].lowercase()
                val attrs = cell.groupValues[2]
                val inner = cell.groupValues[3]
                val tv = TextView(this).apply {
                    text = toSpanned(inner)
                    textSize = maxOf(13f, size - 1f)
                    setTextColor(color ?: ThemeManager.text(this@QuizActivity))
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    gravity = Gravity.CENTER_VERTICAL
                    if (tag == "th") setTypeface(Typeface.create(fontFamily, Typeface.BOLD))
                    background = GradientDrawable().apply {
                        setColor(if (tag == "th") {
                            if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) Color.rgb(38,55,70) else Color.rgb(226,239,247)
                        } else {
                            if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) Color.rgb(25,34,44) else if (rowIndex % 2 == 0) Color.WHITE else Color.rgb(247,250,252)
                        })
                        setStroke(dp(1), if (ThemeManager.get(this@QuizActivity) == ThemeManager.DARK) Color.rgb(76,92,108) else Color.rgb(190,201,211))
                    }
                    minWidth = dp(92)
                }
                val colspan = Regex("colspan\\s*=\\s*[\"'](\\d+)[\"']", RegexOption.IGNORE_CASE).find(attrs)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1
                val lp = TableRow.LayoutParams(dp(110), -2)
                lp.span = colspan.coerceAtLeast(1)
                tr.addView(tv, lp)
                cellIndex++
            }
            if (cellIndex > 0) { table.addView(tr); rowIndex++ }
        }
        if (table.childCount > 0) {
            outer.addView(table, ViewGroup.LayoutParams(-2, -2))
            content.addView(outer, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun addImage(uri: String) {
        val raw = uri.trim()
        if (raw.isBlank()) return
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, dp(6), 0, dp(10))
            minimumHeight = dp(28)
            contentDescription = "Question image"
        }
        content.addView(image, LinearLayout.LayoutParams(-1, -2))
        image.setOnClickListener { showImageFullscreen(raw) }
        imageExecutor.execute {
            try {
                val bitmap = decodeScaledImage(raw, dp(1000), dp(1600))
                if (bitmap != null) runOnUiThread { if (!isFinishing && !isDestroyed) image.setImageBitmap(bitmap) }
            } catch (_: Throwable) { }
        }
    }

    private fun showImageFullscreen(raw:String){
        val iv=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;setBackgroundColor(Color.BLACK);setPadding(dp(8),dp(8),dp(8),dp(8))}
        val dlg=Dialog(this).apply{window?.setBackgroundDrawableResource(android.R.color.black)}
        dlg.setContentView(iv); dlg.window?.setLayout(-1,-1); iv.setOnClickListener{dlg.dismiss()}; dlg.show(); dlg.window?.setLayout(-1,-1)
        imageExecutor.execute{try{val bm=decodeScaledImage(raw,resources.displayMetrics.widthPixels*2,resources.displayMetrics.heightPixels*2);if(bm!=null)runOnUiThread{if(!isFinishing)iv.setImageBitmap(bm)}}catch(_:Throwable){}}
    }

    private fun decodeScaledImage(value: String, maxW: Int, maxH: Int): android.graphics.Bitmap? {
        var uri = value.trim().replace("\\/", "/").replace("&amp;", "&")
        if (uri.startsWith("url(", true)) uri = uri.substringAfter('(').substringBeforeLast(')').trim().trim('"', '\'')
        if (uri.startsWith("//")) uri = "https:" + uri
        if (uri.startsWith("data:image", true)) {
            val comma = uri.indexOf(',')
            if (comma < 0) return null
            val payload = uri.substring(comma + 1)
            // Stream-decode the Base64 image twice: first for dimensions, then at the
            // calculated sample size. Never materialise the full decoded image byte[];
            // large QBank images are a common source of process-death/OOM on phones.
            fun stream() = android.util.Base64InputStream(payload.byteInputStream(Charsets.US_ASCII), android.util.Base64.DEFAULT)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            stream().use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val opts = BitmapFactory.Options().apply {
                inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, maxW, maxH)
                inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                inDither = true
            }
            return stream().use { BitmapFactory.decodeStream(it, null, opts) }
        }
        val parsed = Uri.parse(uri)
        fun open(): java.io.InputStream? {
            return when (parsed.scheme?.lowercase()) {
                "http", "https" -> java.net.URL(uri).openConnection().let { c -> c.connectTimeout=10000; c.readTimeout=15000; c.getInputStream() }
                "content", "file" -> contentResolver.openInputStream(parsed)
                else -> null
            }
        }
        // For file/content/network images, also avoid readBytes(): bounds are read first,
        // then the stream is reopened and decoded at the required sample size.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options().apply {
            inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, maxW, maxH)
            inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
            inDither = true
        }
        return open()?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun calculateSample(w: Int, h: Int, maxW: Int, maxH: Int): Int {
        var sample = 1
        while (w / (sample * 2) >= maxW && h / (sample * 2) >= maxH) sample *= 2
        while (w / sample > maxW * 2 || h / sample > maxH * 2) sample *= 2
        return sample.coerceAtLeast(1)
    }

    private fun decodeBytes(data: ByteArray, maxW: Int, maxH: Int): android.graphics.Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxW || bounds.outHeight / sample > maxH) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize=sample; inPreferredConfig=android.graphics.Bitmap.Config.RGB_565; inScaled=true }
        return BitmapFactory.decodeByteArray(data, 0, data.size, opts)
    }

    private fun showMistakeTypeDialog(q: Question) {
        val choices = arrayOf("Didn't know", "Concept confusion", "Misread question", "Silly mistake", "Changed correct answer", "Time pressure")
        val current = store.mistakeType(q.stableKey)
        val checked = choices.indexOfFirst { it.equals(current, true) }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Why did you miss it?")
            .setSingleChoiceItems(choices, checked) { dialog, which ->
                store.setMistakeType(q.stableKey, choices[which])
                dialog.dismiss()
                show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showNoteEditor(q:Question){
        val input=EditText(this).apply{setText(db.note(q.id) ?: "");setHint("Your memory cue, trap, or mnemonic");inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;minLines=4;setPadding(dp(12),dp(10),dp(12),dp(10))}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(4),dp(8),0)};box.addView(input,LinearLayout.LayoutParams(-1,dp(150)))
        AlertDialog.Builder(this).setTitle("Note for this question").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->db.saveNote(q.id,input.text.toString().trim());Toast.makeText(this,"Note saved",Toast.LENGTH_SHORT).show()}.show()
    }

    private fun showBookmarkMenu(anchor: View) {
        if (questionCount == 0) return
        val popup = PopupWindow(this).apply {
            width = dp(336)
            height = dp(276)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(this@QuizActivity))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(55,69,86) else Color.rgb(205,220,231))
            }
            elevation = dp(8).toFloat()
        }
        val titleView = TextView(this).apply {
            text = "Bookmark category"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.text(this@QuizActivity))
            setPadding(dp(6), dp(2), dp(6), dp(10))
        }
        box.addView(titleView)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val values = listOf(
            "important" to "★  Important",
            "revise" to "↻  Revise",
            "doubt" to "❔  Doubt",
            "favorite" to "♥  Favourite"
        )
        for (r in 0..1) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..1) {
                val pair = values[r * 2 + c]
                val b = actionButton(pair.second, bookmarkColor(pair.first), 14.5f) {
                    currentQuestion?.let { q -> store.setBookmark(q.stableKey, pair.first) }
                    savePosition()
                    popup.dismiss()
                    show()
                }
                b.setTextColor(ThemeManager.bookmarkText(this@QuizActivity, pair.first))
                row.addView(b, LinearLayout.LayoutParams(0, dp(82), 1f).apply {
                    setMargins(if (c == 0) 0 else dp(6), dp(4), if (c == 0) dp(6) else 0, dp(4))
                })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, dp(90)))
        }
        box.addView(grid)
        popup.contentView = box
        popup.setOnDismissListener { }
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(10), popupTopY(anchor))
        val anim = AnimationSet(true).apply {
            addAnimation(ScaleAnimation(.92f, 1f, .92f, 1f, 1f, .5f).apply { duration = 170 })
            addAnimation(AlphaAnimation(.25f, 1f).apply { duration = 170 })
        }
        box.startAnimation(anim)
    }

    private fun popupTopY(anchor: View): Int {
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        return (loc[1] + dp(8)).coerceAtLeast(dp(44))
    }

    private fun bookmarkGradient() = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(19, 111, 151), Color.rgb(27, 157, 117))).apply { cornerRadius = dp(24).toFloat() }

    private fun bookmarkColor(v: String) = ThemeManager.bookmarkFill(this@QuizActivity, v)

    private fun bookmarkPopupDrawable(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), if (ThemeManager.get(this@QuizActivity)==ThemeManager.DARK) Color.rgb(75,88,105) else Color.rgb(205,215,225))
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius * resources.displayMetrics.density
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toSpanned(html: String): Spanned {
        if (html.length > 180_000) return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        synchronized(spannedCache) { spannedCache[html]?.let { return it } }
        val parsed = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        synchronized(spannedCache) { spannedCache[html] = parsed }
        return parsed
    }

}

/** Prevents accidental vertical scrolling while the user is still answering. */
private class LockedScrollView(context: android.content.Context) : ScrollView(context) {
    var locked: Boolean = false
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onInterceptTouchEvent(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean = if (locked) false else super.onTouchEvent(ev)
}
