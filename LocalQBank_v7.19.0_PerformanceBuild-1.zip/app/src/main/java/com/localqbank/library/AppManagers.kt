package com.localqbank.library

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/**
 * Application-level coordination layer.
 *
 * UI screens never own business rules. Managers read/write through the existing
 * QBankDb/ProgressStore and communicate through AppState. Each manager is deliberately
 * deterministic and failure-tolerant: a derived metric can fail without taking down the UI.
 */
object AppManagers {
    @Volatile private var initialized = false
    lateinit var analytics: AnalyticsManager
        private set
    lateinit var todaySolved: TodaySolvedManager
        private set
    lateinit var health: DataHealthManager
        private set
    lateinit var learning: LearningManager
        private set

    @Synchronized fun initialize(context: Context) {
        if (initialized) return
        val app = context.applicationContext
        analytics = AnalyticsManager(app)
        todaySolved = TodaySolvedManager(app)
        health = DataHealthManager(app)
        learning = LearningManager(app, analytics)
        initialized = true
    }
}

data class AnalyticsSnapshot(
    val total: Int = 0,
    val attempted: Int = 0,
    val correct: Int = 0,
    val wrong: Int = 0,
    val unsolved: Int = 0,
    val accuracy: Int = 0,
    val mastery: Int = 0,
    val due: Int = 0,
    val todaySolved: Int = 0,
    val bookmarks: Int = 0,
    val notes: Int = 0,
    val averageTimeMs: Long = 0L
)

class AnalyticsManager(context: Context) {
    private val app = context.applicationContext

    fun snapshot(refs: List<QuestionRef>, periodDays: Int = 0): AnalyticsSnapshot {
        return runCatching {
            val progress = PerformanceManager.progress(app)
            val now = System.currentTimeMillis()
            val since = if (periodDays > 0) now - periodDays * 86_400_000L else Long.MIN_VALUE
            val todaySince = startOfToday()
            var total = 0
            var correct = 0
            var wrong = 0
            var bookmarks = 0
            var today = 0
            var due = 0
            var timeTotal = 0L
            var timed = 0
            refs.forEach { ref ->
                val r = progress.record(ref.stableKey)
                if (r != null && r.lastAttempted < since) return@forEach
                total++
                when (r?.status) { "correct" -> correct; "wrong" -> wrong }
                if (!r?.bookmark.isNullOrBlank()) bookmarks++
                if (r != null && r.lastAttempted >= todaySince && r.status != null) today++
                if (r == null || r.nextDue == 0L || now >= r.nextDue) due++
                if (r != null && r.timeMs > 0L) { timeTotal += r.timeMs; timed++ }
            }
            val attempted = correct + wrong
            AnalyticsSnapshot(
                total = total,
                attempted = attempted,
                correct = correct,
                wrong = wrong,
                unsolved = (total - attempted).coerceAtLeast(0),
                accuracy = if (attempted == 0) 0 else (correct * 100 / attempted).coerceIn(0, 100),
                mastery = if (total == 0) 0 else (correct * 100 / total).coerceIn(0, 100),
                due = due,
                todaySolved = today,
                bookmarks = bookmarks,
                notes = 0, // Notes are intentionally excluded from the hot dashboard path.
                averageTimeMs = if (timed == 0) 0L else timeTotal / timed
            )
        }.getOrDefault(AnalyticsSnapshot())
    }

    private fun startOfToday(): Long = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis
}

class TodaySolvedManager(context: Context) {
    private val app = context.applicationContext
    fun ids(refs: List<QuestionRef>, limit: Int = 200): LongArray {
        val since = startOfToday()
        val progress = PerformanceManager.progress(app)
        return refs.asSequence().filter { r ->
            val p = progress.record(r.stableKey)
            p != null && (p.status == "correct" || p.status == "wrong") && p.lastAttempted >= since
        }.map { it.id }.distinct().take(limit.coerceIn(1, 500)).toList().toLongArray()
    }
    fun count(refs: List<QuestionRef>): Int {
        val since = startOfToday(); val progress = PerformanceManager.progress(app)
        return refs.count { r -> progress.record(r.stableKey)?.let { (it.status == "correct" || it.status == "wrong") && it.lastAttempted >= since } == true }
    }
    private fun startOfToday(): Long = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis
}

/** Performs cheap integrity checks before a screen consumes progress-derived state. */
class DataHealthManager(context: Context) {
    private val app = context.applicationContext
    private val store = ProgressStore(app)

    fun sanitizeProgressKeys(validStableKeys: Set<String>): Int {
        if (validStableKeys.isEmpty()) return 0
        val entries = store.allEntries()
        val known = ConcurrentHashMap.newKeySet<String>()
        validStableKeys.forEach { known.add(it) }
        var removed = 0
        entries.keys.forEach { key ->
            val base = key.substringBeforeLast(':')
            val suffix = key.substringAfterLast(':', "")
            // Position/resume keys and source-level settings are intentionally preserved.
            if (suffix in setOf("answer", "status", "bookmark", "review", "attempts", "lastAttempted", "timeMs", "mistake", "ef", "reps", "intervalDays", "nextDue") && !known.contains(base)) {
                removed++
            }
        }
        return removed
    }
}

/** Small adaptive rule engine. It observes outcomes but does not directly mutate core state. */
class LearningManager(context: Context, private val analyticsManager: AnalyticsManager) {
    private val app = context.applicationContext

    fun recommendation(refs: List<QuestionRef>): String {
        return runCatching {
            val analytics = analyticsManager.snapshot(refs)
            when {
                analytics.attempted == 0 -> "Start with a mixed set to establish your baseline."
                analytics.due > 0 && analytics.due >= analytics.attempted / 2 -> "Clear the revision queue before adding much new volume."
                analytics.wrong > analytics.correct -> "Prioritize wrong questions and revisit their explanations."
                analytics.accuracy >= 85 -> "Accuracy is strong; use timed mixed practice to improve speed."
                else -> "Keep solving, then revisit weak questions on their scheduled due dates."
            }
        }.getOrDefault("Continue with a balanced mix of new questions and revision.")
    }
}

/** Safe extension used only for short-lived DB reads. */
private inline fun <T> QBankDb.useDb(block: QBankDb.() -> T): T {
    return try { block() } finally { close() }
}
