package com.localqbank.library

/** Lightweight in-process invalidation bus. Screens can refresh immediately after DB mutations. */
object AppState {
    private val listeners = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()
    fun register(listener: () -> Unit) { listeners.add(listener) }
    fun unregister(listener: () -> Unit) { listeners.remove(listener) }
    fun changed() { PerformanceManager.invalidate(); listeners.toList().forEach { runCatching { it() } } }
}
