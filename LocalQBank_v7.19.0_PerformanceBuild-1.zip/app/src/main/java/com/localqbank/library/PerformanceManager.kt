package com.localqbank.library

import android.content.Context
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicLong

/**
 * Runtime performance coordinator.
 *
 * Rules:
 * 1. Never perform a full-QBank scan on the main thread.
 * 2. Read SharedPreferences once per snapshot, never once per question.
 * 3. Coalesce repeated refresh requests while a calculation is running.
 * 4. Keep derived state in memory and invalidate it only after a real mutation.
 */
object PerformanceManager {
    private const val REF_CACHE_MS = 5_000L
    private val executor: ExecutorService = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "qbank-worker").apply { priority = Thread.NORM_PRIORITY }
    }
    private val generation = AtomicLong(0)
    @Volatile private var refsCache: List<QuestionRef>? = null
    @Volatile private var refsAt = 0L
    @Volatile private var progressCache: ProgressSnapshot? = null
    @Volatile private var progressAt = 0L

    fun invalidate() {
        generation.incrementAndGet()
        refsCache = null
        progressCache = null
        refsAt = 0L
        progressAt = 0L
    }

    fun submit(task: () -> Unit): Future<*> = executor.submit(task)

    fun refs(context: Context): List<QuestionRef> {
        val now = System.currentTimeMillis()
        refsCache?.let { if (now - refsAt < REF_CACHE_MS) return it }
        val db = QBankDb(context.applicationContext)
        return try {
            val value = db.allQuestionRefs()
            refsCache = value
            refsAt = now
            value
        } finally { db.close() }
    }

    fun progress(context: Context): ProgressSnapshot {
        val now = System.currentTimeMillis()
        progressCache?.let { if (now - progressAt < REF_CACHE_MS) return it }
        val p = context.applicationContext.getSharedPreferences("progress", Context.MODE_PRIVATE).all
        val snapshot = ProgressSnapshot.from(p)
        progressCache = snapshot
        progressAt = now
        return snapshot
    }

    fun currentGeneration(): Long = generation.get()
}

data class ProgressRecord(
    val status: String?,
    val bookmark: String?,
    val lastAttempted: Long,
    val nextDue: Long,
    val timeMs: Long,
    val attempts: Int
)

class ProgressSnapshot private constructor(private val records: Map<String, ProgressRecord>) {
    fun record(key: String): ProgressRecord? = records[key]
    fun all(): Map<String, ProgressRecord> = records

    companion object {
        fun from(values: Map<String, *>): ProgressSnapshot {
            val grouped = HashMap<String, MutableMap<String, Any?>>()
            values.forEach { (fullKey, value) ->
                val split = fullKey.lastIndexOf(':')
                if (split <= 0 || split >= fullKey.lastIndex) return@forEach
                val id = fullKey.substring(0, split)
                val field = fullKey.substring(split + 1)
                // Position/source metadata is not per-question progress.
                if (field !in FIELDS) return@forEach
                grouped.getOrPut(id) { HashMap() }[field] = value
            }
            val out = HashMap<String, ProgressRecord>(grouped.size)
            grouped.forEach { (id, m) ->
                out[id] = ProgressRecord(
                    status = m["status"] as? String,
                    bookmark = m["bookmark"] as? String,
                    lastAttempted = number(m["lastAttempted"]),
                    nextDue = number(m["nextDue"]),
                    timeMs = number(m["timeMs"]),
                    attempts = number(m["attempts"]).toInt()
                )
            }
            return ProgressSnapshot(out)
        }

        private fun number(v: Any?): Long = when (v) {
            is Long -> v
            is Int -> v.toLong()
            is Float -> v.toLong()
            is Double -> v.toLong()
            else -> 0L
        }

        private val FIELDS = setOf("status", "bookmark", "lastAttempted", "nextDue", "timeMs", "attempts")
    }
}
