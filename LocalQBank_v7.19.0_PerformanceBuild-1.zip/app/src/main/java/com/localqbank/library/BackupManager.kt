package com.localqbank.library

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.*
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Durable progress backup. The QBank HTML/database is never copied into these small backups. */
class BackupManager(private val context: Context) {
    companion object {
        const val PREFS = "backup_settings"
        const val TREE_URI = "backup_tree_uri"
        const val LAST_BACKUP = "last_backup"
        const val BACKUP_NAME = "Q_Progress_latest.qbackup"
        private const val LOCAL_DIR = "q_backups"
        private val io = Executors.newSingleThreadExecutor()
        private val snapshotQueued = AtomicBoolean(false)
        private val generation = AtomicLong(0)
        private val lastCloudSchedule = AtomicLong(0)
        private val lastLocalSchedule = AtomicLong(0)
    }
    private val app = context.applicationContext
    private val settings = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun onProgressChanged(cloud:Boolean=true) {
        // SharedPreferences is already committed synchronously by ProgressStore.
        // Coalesce rapid quiz navigation into one background snapshot; never block the UI.
        generation.incrementAndGet()
        // Local snapshots are durability aids, not part of the answer transaction. Debounce them
        // so a fast 50-question session does not perform dozens of JSON serializations and fsyncs.
        val nowLocal = System.currentTimeMillis()
        val previousLocal = lastLocalSchedule.get()
        if (nowLocal - previousLocal >= 1_500L && lastLocalSchedule.compareAndSet(previousLocal, nowLocal)) {
            if(snapshotQueued.compareAndSet(false,true)) io.submit {
                try {
                    Thread.sleep(1_200L)
                    writeLocalSnapshot()
                } finally { snapshotQueued.set(false) }
            }
        }
        if(!cloud) return
        val uri = settings.getString(TREE_URI, null) ?: return
        // Do not enqueue/replace WorkManager work for every tap/answer. Cloud backup is
        // intentionally debounced; local progress is already persisted immediately.
        val now = System.currentTimeMillis()
        val previous = lastCloudSchedule.get()
        if (now - previous < 30_000L) return
        if (!lastCloudSchedule.compareAndSet(previous, now)) return
        val request = OneTimeWorkRequestBuilder<CloudBackupWorker>()
            .setInitialDelay(2, TimeUnit.MINUTES)
            .setInputData(workDataOf("treeUri" to uri))
            .addTag("q_cloud_backup")
            .build()
        WorkManager.getInstance(app).enqueueUniqueWork("q_cloud_backup_after_changes", ExistingWorkPolicy.REPLACE, request)
    }

    fun setTreeUri(uri: Uri) {
        try { app.contentResolver.takePersistableUriPermission(uri, IntentFlags.READ_WRITE) } catch (_: Throwable) {}
        settings.edit().putString(TREE_URI, uri.toString()).apply()
        schedulePeriodic()
    }

    fun clearTreeUri() { settings.edit().remove(TREE_URI).apply(); WorkManager.getInstance(app).cancelUniqueWork("q_cloud_backup_after_changes"); WorkManager.getInstance(app).cancelUniqueWork("q_cloud_backup_periodic") }
    fun treeUri(): Uri? = settings.getString(TREE_URI, null)?.let { Uri.parse(it) }
    fun lastBackup(): Long = settings.getLong(LAST_BACKUP, 0L)

    fun flushCloudBackup() {
        val uri=settings.getString(TREE_URI,null) ?: return
        val request=OneTimeWorkRequestBuilder<CloudBackupWorker>().setInputData(workDataOf("treeUri" to uri)).addTag("q_cloud_backup_flush").build()
        WorkManager.getInstance(app).enqueueUniqueWork("q_cloud_backup_flush",ExistingWorkPolicy.REPLACE,request)
    }

    fun backupNow(): Boolean {
        val file = writeLocalSnapshot() ?: return false
        val uri = treeUri() ?: return true
        return upload(file, uri)
    }

    fun exportFile(): File? = writeLocalSnapshot()

    private fun writeLocalSnapshot(): File? {
        return try {
            val dir = File(app.filesDir, LOCAL_DIR).apply { mkdirs() }
            val target = File(dir, BACKUP_NAME)
            val tmp = File(dir, ".tmp_latest.qbackup")
            val json = buildPayload()
            FileOutputStream(tmp).use { it.write(json.toString().toByteArray(Charsets.UTF_8)); it.fd.sync() }
            if (!tmp.renameTo(target)) { tmp.copyTo(target, true); tmp.delete() }
            settings.edit().putLong(LAST_BACKUP, System.currentTimeMillis()).apply()
            target
        } catch (_: Throwable) { null }
    }

    private fun buildPayload(): JSONObject {
        val p = app.getSharedPreferences("progress", Context.MODE_PRIVATE)
        val ui = app.getSharedPreferences("ui", Context.MODE_PRIVATE)
        val progress = JSONObject()
        for ((k,v) in p.all) when(v) {
            is String -> progress.put(k,v); is Boolean -> progress.put(k,v); is Int -> progress.put(k,v)
            is Long -> progress.put(k,v); is Float -> progress.put(k,v.toDouble())
        }
        val uiJson=JSONObject()
        for ((k,v) in ui.all) when(v) { is String->uiJson.put(k,v); is Boolean->uiJson.put(k,v); is Int->uiJson.put(k,v); is Long->uiJson.put(k,v); is Float->uiJson.put(k,v.toDouble()) }
        val notesJson=org.json.JSONArray()
        runCatching {
            val noteDb=QBankDb(app)
            try {
                noteDb.notes().forEach { (questionId,note) ->
                    notesJson.put(JSONObject().put("questionId",questionId).put("note",note))
                }
            } finally { noteDb.close() }
        }
        val core=JSONObject().put("format",2).put("createdAt",System.currentTimeMillis()).put("progress",progress).put("ui",uiJson).put("notes",notesJson)
        val digest=sha256(core.toString())
        return JSONObject().put("qBackup",core).put("sha256",digest)
    }

    fun restoreFromFile(file: File): Boolean {
        return runCatching { restorePayload(file.readText(Charsets.UTF_8)) }.getOrDefault(false)
    }

    fun restoreFromUri(uri: Uri): Boolean {
        return runCatching {
            val input = app.contentResolver.openInputStream(uri) ?: return false
            input.use { restorePayload(it.readBytes().toString(Charsets.UTF_8)) }
        }.getOrDefault(false)
    }

    /**
     * Restore is intentionally two-phase. We validate the complete payload and all note
     * references before changing anything. If the final commit fails, the previous state is
     * restored from an in-memory snapshot. This prevents a bad backup from leaving the app in
     * the dangerous half-restored state that can make derived screens appear broken.
     */
    private fun restorePayload(text: String): Boolean {
        val wrapper = JSONObject(text)
        val core = wrapper.optJSONObject("qBackup") ?: return false
        require(wrapper.optString("sha256").equals(sha256(core.toString()), ignoreCase = true)) { "Backup checksum failed" }
        val format = core.optInt("format", -1)
        require(format in 1..2) { "Unsupported backup version" }
        val progress = core.optJSONObject("progress") ?: JSONObject()
        val ui = core.optJSONObject("ui")
        val notes = core.optJSONArray("notes")

        val progressValues = jsonToMap(progress)
        val uiValues = if (ui == null) null else jsonToMap(ui)
        val noteValues = ArrayList<Pair<Long, String>>()
        if (notes != null) {
            for (i in 0 until notes.length()) {
                val n = notes.optJSONObject(i) ?: continue
                val id = n.optLong("questionId", 0L)
                val note = n.optString("note", "").trim()
                if (id > 0L && note.isNotBlank()) noteValues.add(id to note)
            }
        }

        // Validate note foreign keys against the CURRENT QBank before touching preferences.
        // A progress backup is allowed to be imported into a different QBank; stale notes are
        // simply discarded rather than making the entire restore fail.
        val db = QBankDb(app)
        val validNotes = try {
            noteValues.filter { runCatching { db.questionExists(it.first) }.getOrDefault(false) }
        } finally { db.close() }

        val progressPrefs = app.getSharedPreferences("progress", Context.MODE_PRIVATE)
        val uiPrefs = app.getSharedPreferences("ui", Context.MODE_PRIVATE)
        val oldProgress = progressPrefs.all.toMap()
        val oldUi = uiPrefs.all.toMap()
        val oldNotes = runCatching {
            val noteDb = QBankDb(app)
            try { noteDb.notes() } finally { noteDb.close() }
        }.getOrDefault(emptyList())

        try {
            replacePrefs(progressPrefs, progressValues)
            if (uiValues != null) replacePrefs(uiPrefs, uiValues)
            val noteDb = QBankDb(app)
            try { noteDb.replaceNotes(validNotes) } finally { noteDb.close() }

            // Notify every manager/screen only AFTER all stores agree on the new state.
            AppState.changed()
            writeLocalSnapshot()
            return true
        } catch (t: Throwable) {
            // Best-effort rollback. The original state is retained if rollback itself fails;
            // importantly, no partially imported state is reported as successful.
            runCatching { replacePrefs(progressPrefs, oldProgress) }
            runCatching { replacePrefs(uiPrefs, oldUi) }
            runCatching {
                val noteDb = QBankDb(app)
                try { noteDb.replaceNotes(oldNotes) } finally { noteDb.close() }
            }
            AppState.changed()
            throw t
        }
    }

    private fun jsonToMap(json: JSONObject): Map<String, Any> {
        val out = LinkedHashMap<String, Any>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            when (val v = json.opt(key)) {
                is Boolean -> out[key] = v
                is Int -> out[key] = v
                is Long -> out[key] = v
                is Double -> out[key] = v.toFloat()
                is String -> out[key] = v
                JSONObject.NULL -> Unit
            }
        }
        return out
    }

    private fun replacePrefs(prefs: android.content.SharedPreferences, values: Map<String, *>) {
        val editor = prefs.edit().clear()
        values.forEach { (k, v) ->
            when (v) {
                is Boolean -> editor.putBoolean(k, v)
                is Int -> editor.putInt(k, v)
                is Long -> editor.putLong(k, v)
                is Float -> editor.putFloat(k, v)
                is Double -> editor.putFloat(k, v.toFloat())
                is String -> editor.putString(k, v)
            }
        }
        check(editor.commit()) { "Preference restore commit failed" }
    }

    fun backupToUri(tree: Uri): Boolean { val local=writeLocalSnapshot() ?: return false; return upload(local,tree) }

    private fun upload(local:File, tree:Uri): Boolean {
        return try {
            val root=DocumentFile.fromTreeUri(app,tree) ?: return false
            // Keep one stable cloud backup. Re-create only when necessary; this avoids a new
            // timestamped file on every progress change while remaining compatible with SAF.
            val latest=root.findFile(BACKUP_NAME) ?: root.createFile("application/octet-stream",BACKUP_NAME) ?: return false
            val ok=app.contentResolver.openOutputStream(latest.uri)?.use{out->local.inputStream().use{input->input.copyTo(out,1024*1024)}} != null
            if(!ok)return false
            settings.edit().putLong(LAST_BACKUP,System.currentTimeMillis()).apply();true
        } catch(_:Throwable){false}
    }

    private fun schedulePeriodic() {
        val request=PeriodicWorkRequestBuilder<CloudBackupWorker>(12,TimeUnit.HOURS)
            .setInputData(workDataOf("treeUri" to (treeUri()?.toString() ?: ""))).addTag("q_cloud_backup_periodic").build()
        WorkManager.getInstance(app).enqueueUniquePeriodicWork("q_cloud_backup_periodic",ExistingPeriodicWorkPolicy.UPDATE,request)
    }
    private fun sha256(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString(""){String.format("%02x",it)}

    object IntentFlags { const val READ_WRITE = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION }
}

class CloudBackupWorker(appContext: Context, params: WorkerParameters): Worker(appContext,params) {
    override fun doWork(): Result {
        val uri=inputData.getString("treeUri")?.let { Uri.parse(it) } ?: BackupManager(applicationContext).treeUri() ?: return Result.success()
        val ok=BackupManager(applicationContext).backupToUri(uri)
        return if(ok) Result.success() else Result.retry()
    }
}
