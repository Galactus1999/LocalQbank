# Rovex v8.3.615 — Clinical Day Imported Motion Phase Audit

## Baseline
- Input: v8.3.614 Clinical Day Home CI-green baseline supplied by the project workflow.
- Version: 8.3.615 / versionCode 701.

## Scope
This phase adds one professionally authored, permissively licensed bundled Lottie motion asset to the Clinical Day Home header and a restrained native breathing/color-flow treatment to the Home-only selected navigation and hero border. It does not redesign another screen and does not alter QBank/Ben/data ownership.

## Imported asset
- `app/src/main/res/raw/rovex_header_flow.json`
- Source repository: `spemer/lottie-animations-json`
- Asset: `animate_tab/animate_tab_1.json`
- Repository license: MIT.
- The JSON is bundled locally; there is no runtime network request.

## Runtime library
- `com.airbnb.android:lottie:6.7.1`
- Apache-2.0.
- Hardware rendering is explicitly requested for the simple vector-only header animation.
- Animation is enabled only on Clinical Day Home and is suppressed when Rovex AnimationPolicy disables motion.

## Visual changes
1. Home header gains a thin, slow-moving imported Lottie accent below the Rovex brand row.
2. Clinical Day hero surface gains a low-amplitude animated border flow using a cached LinearGradient + Matrix; no per-frame shader allocation.
3. Home selected bottom-navigation icon/label receives subtle accent↔secondary color breathing and 3.5% scale breathing. This is restricted to MainActivity + LIGHT/Clinical Day Home so Flashcards, Quiz and other screens do not inherit the motion change.
4. Existing background, card hierarchy, study data, navigation, and QBank behavior are preserved.

## Static verification
- Full Kotlin source scan: 299 `.kt` files.
- XML source scan: 36 files.
- XML parse errors: 0.
- Duplicate IDs within individual XML layouts/resources: 0.
- Changed-source `catch(Throwable)`: 0.
- Merge-marker scan: false positives only from separator strings (`================`), no actual conflict markers.
- Changed-file brace balance: PASS.
- Changed-file parenthesis balance: PASS.
- Bundled Lottie JSON parses as valid JSON and reports expected composition metadata.
- Diff from v8.3.614 contains only the intended build/version, Home, bottom-navigation, ID resource, bundled JSON, and notice/audit changes.

## Not yet proven
- Android Gradle compilation of v8.3.615.
- GitHub Actions CI result.
- Device screenshot of v8.3.615.
- Frame-time/jank measurement on the target OnePlus CPH2691.
- APK size impact after resolving the new Lottie dependency.

## Next gate
Run the complete CI workflow before adding another imported visual asset. If CI is green, install on the target device and compare the Clinical Day Home header, hero border motion, and bottom-navigation breathing against the supplied v8.3.614 screenshots. Only then proceed to a dedicated imported background/atmospheric asset phase.
