# Rovex Visual Third-Party Notices — v8.3.615

## Lottie Android
- Project: Airbnb Lottie for Android
- Version: 6.7.1
- License: Apache-2.0
- Purpose: native rendering of the bundled Clinical Day header motion asset.
- Source: https://github.com/airbnb/lottie-android

## Bundled animation asset
- Project: spemer/lottie-animations-json
- Asset: `animate_tab/animate_tab_1.json`
- License: MIT (repository license)
- Purpose: decorative animated header accent only; no network fetch at runtime.
- Source: https://github.com/spemer/lottie-animations-json

The asset is bundled locally and is not fetched from the network at runtime.
