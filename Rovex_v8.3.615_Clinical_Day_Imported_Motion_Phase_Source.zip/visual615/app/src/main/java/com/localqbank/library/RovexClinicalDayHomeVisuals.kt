package com.localqbank.library

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import android.os.SystemClock
import kotlin.math.cos
import kotlin.math.sin

/**
 * Clinical Day home-only visual layer. It is deliberately isolated from the global theme engine
 * so the reference theme can be tuned screen-by-screen without destabilising other themes.
 */
class RovexClinicalDayHomeBackgroundDrawable(
    context: android.content.Context
) : Drawable() {
    private val appContext = context.applicationContext
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cloudRects = Array(4) { RectF() }
    private val fallbackLinear = arrayOfNulls<LinearGradient>(1)
    private var fallbackGlowA: RadialGradient? = null
    private var fallbackGlowB: RadialGradient? = null
    private var fallbackGlowC: RadialGradient? = null
    private var shader: android.graphics.RuntimeShader? = null
    private var running = true
    private var phase = 0f
    private val tick = Runnable { invalidateSelf() }

    init {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            shader = runCatching { android.graphics.RuntimeShader(CLINICAL_SHADER) }.getOrNull()
        }
    }

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        val t = phase
        val s = shader
        if (s != null) {
            runCatching {
                s.setFloatUniform("resolution", w, h)
                s.setFloatUniform("time", t)
                paint.shader = s
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
            }.onFailure { drawFallback(canvas, w, h, t) }
        } else {
            drawFallback(canvas, w, h, t)
        }

        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(18, 255, 255, 255)
        for (i in cloudRects.indices) {
            val drift = ((t * (0.010f + i * .002f) + i * .31f) % 1.35f) - .18f
            val r = cloudRects[i]
            val y = h * (.18f + i * .16f)
            val width = w * .62f
            r.set(w * drift, y, w * drift + width, y + h * .11f)
            canvas.drawOval(r, paint)
        }

        for (i in 0 until 20) {
            val x = ((i * 53 + 17) % 101) / 100f * w + sin(t * .22f + i) * w * .003f
            val y = ((i * 37 + 11) % 101) / 100f * h + cos(t * .18f + i * .7f) * h * .002f
            val a = (12f + 10f * ((sin(t * .7f + i) + 1f) * .5f)).toInt()
            paint.color = Color.argb(a, 54, 118, 186)
            canvas.drawCircle(x, y, minOf(w, h) * .0016f, paint)
        }

        if (running && AnimationPolicy.enabled(appContext)) {
            phase = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f
            scheduleSelf(tick, SystemClock.uptimeMillis() + 50L)
        }
    }

    private fun drawFallback(canvas: Canvas, w: Float, h: Float, t: Float) {
        paint.shader = fallbackLinear[0]
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = fallbackGlowA
        canvas.drawCircle(w * .80f, h * .12f, minOf(w, h) * .34f, paint)
        paint.shader = fallbackGlowB
        canvas.drawCircle(w * .10f, h * .70f, minOf(w, h) * .48f, paint)
        paint.shader = fallbackGlowC
        canvas.drawCircle(w * .74f, h * .78f, minOf(w, h) * .42f, paint)
        paint.shader = null
    }

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        super.onBoundsChange(bounds)
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        fallbackLinear[0] = LinearGradient(0f, 0f, w, h, Color.rgb(239,247,255), Color.rgb(251,248,241), Shader.TileMode.CLAMP)
        val r = minOf(w, h)
        fallbackGlowA = RadialGradient(w*.80f, h*.12f, r*.34f, Color.argb(76,255,225,154), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        fallbackGlowB = RadialGradient(w*.10f, h*.70f, r*.48f, Color.argb(34,72,166,255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        fallbackGlowC = RadialGradient(w*.74f, h*.78f, r*.42f, Color.argb(26,0,173,190), Color.TRANSPARENT, Shader.TileMode.CLAMP)
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        running = visible
        if (!visible) unscheduleSelf(tick)
        if (visible && restart) phase = 0f
        return super.setVisible(visible, restart)
    }
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter }
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT

    companion object {
        private const val CLINICAL_SHADER = """
            uniform float2 resolution;
            uniform float time;
            half4 main(float2 p) {
                float2 uv = p / resolution;
                float t = time * 0.055;
                float sun = exp(-length((uv - float2(.82,.12)) * float2(1.0,1.15)) * 3.2);
                float cool = exp(-length((uv - float2(.12,.72)) * float2(1.0,.85)) * 2.5);
                float aqua = exp(-length((uv - float2(.76,.78)) * float2(1.1,.9)) * 2.9);
                float drift = sin(uv.x * 3.1 + t) * .5 + sin(uv.y * 4.2 - t * .7) * .5;
                float3 base = mix(float3(.937,.969,1.0), float3(.984,.973,.945), uv.y);
                base += float3(1.0,.82,.42) * sun * .085;
                base += float3(.22,.55,1.0) * cool * .035;
                base += float3(.0,.65,.70) * aqua * .022;
                base += drift * .006;
                return half4(clamp(base,0.0,1.0),1.0);
            }
        """
    }
}

/** Premium Clinical Day surface: glass-like depth without bitmap assets or heavy blur. */
class RovexClinicalSurfaceDrawable(
    private val radiusPx: Float,
    private val accent: Int,
    private val secondary: Int,
    private val animatedBorder: Boolean = false
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val highlightPath = Path()
    private val highlightRect = RectF()
    private val edgeMatrix = Matrix()
    private var fillShader: LinearGradient? = null
    private var edgeShader: LinearGradient? = null
    private var phase = 0f
    private var running = true
    private val tick = Runnable { invalidateSelf() }

    override fun draw(canvas: Canvas) {
        val r = radiusPx.coerceAtLeast(1f)
        val b = bounds
        rect.set(b.left + 1f, b.top + 1f, b.right - 1f, b.bottom - 1f)
        fill.shader = fillShader
        canvas.drawRoundRect(rect, r, r, fill)
        fill.shader = null

        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 1.15f
        if (animatedBorder && edgeShader != null) {
            val travel = ((phase * 0.055f) % 1f) * (rect.width() + rect.height())
            edgeMatrix.setTranslate(travel, -travel * 0.18f)
            edgeShader?.setLocalMatrix(edgeMatrix)
        }
        edge.shader = edgeShader
        canvas.drawRoundRect(rect, r, r, edge)
        edge.shader = null

        highlight.style = Paint.Style.STROKE
        highlight.strokeWidth = 1f
        val breathing = if (animatedBorder) (88f + 34f * ((sin(phase * 0.75f) + 1f) * 0.5f)).toInt() else 115
        highlight.color = Color.argb(breathing, 255, 255, 255)
        highlightRect.set(rect.left + 1.5f, rect.top + 1.5f, rect.right - 1.5f, rect.top + rect.height() * .28f)
        pathRoundTop(canvas, highlightRect, r)
        if (running && animatedBorder) {
            phase = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f
            scheduleSelf(tick, SystemClock.uptimeMillis() + 60L)
        }
    }

    private fun pathRoundTop(canvas: Canvas, rect: RectF, r: Float) {
        highlightPath.reset()
        highlightPath.moveTo(rect.left + r, rect.top)
        highlightPath.lineTo(rect.right - r, rect.top)
        highlightPath.quadTo(rect.right, rect.top, rect.right, rect.top + r)
        canvas.drawPath(highlightPath, highlight)
    }

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        super.onBoundsChange(bounds)
        val left = bounds.left + 1f
        val top = bounds.top + 1f
        val right = bounds.right - 1f
        val bottom = bounds.bottom - 1f
        fillShader = LinearGradient(
            left, top, right, bottom,
            Color.argb(245, 255, 255, 255),
            Color.argb(226, 244, 249, 255),
            Shader.TileMode.CLAMP
        )
        edgeShader = LinearGradient(
            left, top, right, bottom,
            Color.argb(155, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Color.argb(72, Color.red(secondary), Color.green(secondary), Color.blue(secondary)),
            Shader.TileMode.CLAMP
        )
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        running = visible
        if (!visible) unscheduleSelf(tick)
        if (visible && restart) phase = 0f
        return super.setVisible(visible, restart)
    }
    override fun setAlpha(alpha: Int) { fill.alpha = alpha; edge.alpha = alpha; highlight.alpha = alpha }
    override fun setColorFilter(filter: android.graphics.ColorFilter?) { fill.colorFilter = filter; edge.colorFilter = filter; highlight.colorFilter = filter }
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}


/** Compact clinical telemetry ring used only by the Clinical Day Home reference screen. */
class RovexClinicalFocusRingView(context: android.content.Context) : View(context) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD }
    private var progress = 0f
    private var solved = 0
    private val rect = RectF()
    private var ringShader: LinearGradient? = null

    init { contentDescription = "Today's solved progress" }

    fun setProgress(solved: Int, fraction: Float?) {
        this.solved = solved.coerceAtLeast(0)
        progress = (fraction ?: 0f).coerceIn(0f, 1f)
        contentDescription = if (fraction != null) "Today's progress $solved questions, ${(progress * 100).toInt()} percent of goal" else "Today's progress $solved questions"
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val size = minOf(w, h).toFloat()
        val cx = w * .5f
        val cy = h * .5f
        val r = size * .34f
        ringShader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            Color.rgb(38, 91, 230),
            Color.rgb(0, 171, 190),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val size = minOf(width, height).toFloat()
        val cx = width * .5f
        val cy = height * .5f
        val r = size * .34f
        track.strokeWidth = size * .075f
        track.color = Color.argb(32, 31, 77, 120)
        canvas.drawCircle(cx, cy, r, track)
        ring.strokeWidth = size * .075f
        ring.shader = ringShader
        rect.set(cx - r, cy - r, cx + r, cy + r)
        if (progress > 0f) canvas.drawArc(rect, -90f, progress * 360f, false, ring)
        ring.shader = null
        label.color = Color.rgb(24, 48, 82)
        label.textSize = size * .20f
        canvas.drawText(solved.toString(), cx, cy + size * .055f, label)
        label.textSize = size * .085f
        label.color = Color.rgb(84, 103, 130)
        canvas.drawText(if (progress > 0f) "TODAY" else "SOLVED", cx, cy + size * .18f, label)
    }
}

/** Small line-art icons for the Clinical Day Home; replaces emoji glyph dependence on the reference screen. */
class RovexClinicalFeatureIconView(context: android.content.Context, private val kind: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val s = minOf(w, h)
        paint.strokeWidth = s * .075f
        paint.color = Color.rgb(38, 91, 230)
        val cx = w * .5f; val cy = h * .5f
        when (kind) {
            0 -> { // QBank book
                canvas.drawRoundRect(cx-s*.29f,cy-s*.34f,cx+s*.29f,cy+s*.34f,s*.07f,s*.07f,paint); canvas.drawLine(cx-s*.16f,cy-s*.12f,cx+s*.16f,cy-s*.12f,paint); canvas.drawLine(cx-s*.16f,cy,cx+s*.16f,cy,paint); canvas.drawLine(cx-s*.16f,cy+s*.12f,cx+s*.10f,cy+s*.12f,paint)
            }
            1 -> { // flashcard / memory
                canvas.drawRoundRect(cx-s*.30f,cy-s*.24f,cx+s*.24f,cy+s*.31f,s*.06f,s*.06f,paint); canvas.drawRoundRect(cx-s*.20f,cy-s*.34f,cx+s*.34f,cy+s*.21f,s*.06f,s*.06f,paint); canvas.drawCircle(cx+s*.07f,cy-s*.06f,s*.08f,paint)
            }
            2 -> { // telemetry
                path.reset(); path.moveTo(cx-s*.34f,cy+s*.18f); path.lineTo(cx-s*.12f,cy+s*.04f); path.lineTo(cx,cy+s*.17f); path.lineTo(cx+s*.13f,cy-s*.20f); path.lineTo(cx+s*.34f,cy-s*.04f); canvas.drawPath(path,paint); canvas.drawLine(cx-s*.34f,cy+s*.30f,cx+s*.34f,cy+s*.30f,paint)
            }
            3 -> { // health
                path.reset(); path.moveTo(cx-s*.34f,cy); path.lineTo(cx-s*.15f,cy); path.lineTo(cx-s*.07f,cy-s*.17f); path.lineTo(cx+s*.08f,cy+s*.18f); path.lineTo(cx+s*.16f,cy); path.lineTo(cx+s*.34f,cy); canvas.drawPath(path,paint); canvas.drawCircle(cx,cy,s*.34f,paint) }
            else -> { // AI node
                canvas.drawCircle(cx,cy,s*.18f,paint); canvas.drawCircle(cx-s*.27f,cy-s*.20f,s*.07f,paint); canvas.drawCircle(cx+s*.28f,cy-s*.20f,s*.07f,paint); canvas.drawCircle(cx,cy+s*.29f,s*.07f,paint); canvas.drawLine(cx-s*.14f,cy-s*.10f,cx-s*.23f,cy-s*.16f,paint); canvas.drawLine(cx+s*.14f,cy-s*.10f,cx+s*.23f,cy-s*.16f,paint); canvas.drawLine(cx,cy+s*.18f,cx,cy+s*.24f,paint)
            }
        }
    }
}
