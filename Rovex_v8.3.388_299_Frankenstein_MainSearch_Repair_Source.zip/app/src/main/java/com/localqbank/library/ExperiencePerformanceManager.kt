package com.localqbank.library

import android.content.Context
import android.os.Process
import java.util.concurrent.ExecutorService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

import kotlinx.coroutines.CancellationException
/**
 * Foreground-experience coordinator. Heavy derived work is isolated from the main thread
 * and stale work is prevented from publishing after a newer screen state exists.
 * It deliberately does not own study/database business logic.
 */
class ExperiencePerformanceManager(context: Context) {
    private val generation = AtomicLong(0)
    private val executor: ThreadPoolExecutor = ThreadPoolExecutor(
        1, 2, 15L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>()
    ).apply {
        threadFactory = java.util.concurrent.ThreadFactory { r ->
            Thread(r, "rovex-experience").apply { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
        }
    }

    private fun adaptBudget() {
        val workers = if (AppManagers.isReady()) AppManagers.runtime.recommendedBackgroundWorkers() else 1
        executor.corePoolSize = workers.coerceIn(1, 2)
    }

    fun newGeneration(): Long = generation.incrementAndGet()
    fun currentGeneration(): Long = generation.get()

    fun submitHome(task: () -> Unit): Future<*> {
        adaptBudget()
        return executor.submit {
            Process.setThreadPriority(if (AppManagers.runtime.framePressure() >= 2) Process.THREAD_PRIORITY_BACKGROUND + 1 else Process.THREAD_PRIORITY_BACKGROUND)
            task()
        }
    }
    fun submitFrankenstein(task: () -> Unit): Future<*> {
        adaptBudget()
        return executor.submit {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            task()
        }
    }

    /** Suspend-aware lane for LiteRT/MediaPipe neural work without blocking a worker on a synchronous coroutine bridge. */
    private val coroutineScope by lazy { CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher()) }

    fun submitFrankensteinSuspend(task: suspend () -> Unit): Job {
        adaptBudget()
        return coroutineScope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            task()
        }
    }

    fun shutdown() { coroutineScope.cancel(); executor.shutdownNow() }
}

/**
 * Supporting engine for Dr. Frankenstein. It moves cognition/search off the UI thread,
 * coalesces identical commands and keeps a very small result cache.
 */
class FrankensteinSupportEngine(context: Context) {
    private val app = context.applicationContext
    private data class Cached(val insight: RenCognitiveEngine.Insight, val ids: LongArray, val at: Long)
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Cached>()
    private val inFlight = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val runningJobs = java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.Job>()
    private val ttlMs = 20_000L
    private val neuralPipeline by lazy { BenGroundedNeuralPipeline(app) }
    private val neuralPolicy by lazy { BenAiRuntimePolicy(app) }
    private val neuralModels by lazy { BenNeuralModelManager(app) }
    private val localSearch by lazy { LocalQBankSearchService(app) }

    fun respond(command: String, currentQuestion: Question? = null, onResult: (RenCognitiveEngine.Insight, LongArray) -> Unit) {
        val key = command.trim().lowercase() + "\u0000" + (currentQuestion?.stableKey.orEmpty())
        val now = System.currentTimeMillis()
        cache[key]?.let { cached ->
            if (now - cached.at < ttlMs) {
                AppManagers.experience.submitFrankenstein { onResult(cached.insight, cached.ids.copyOf()) }
                return
            }
        }
        // Reserve the key before launching the coroutine. A Job can complete before launch()
        // returns, so storing the Job after launch used to race with finally/remove and could
        // leave a dead key permanently suppressing later identical requests.
        if (!inFlight.add(key)) return

        val job = AppManagers.experience.submitFrankensteinSuspend {
            try {
                val actionCommand = isActionCommand(command)
                val localSearchCommand = isLocalSearchCommand(command)
                val hasNeuralArtifact = neuralModels.installed(BenNeuralModelRegistry.embeddingGemma300m) != null ||
                    neuralModels.installed(BenNeuralModelRegistry.gemma3_270m) != null

                // Search is a deterministic local retrieval operation. Never wait for model
                // initialization/inference before returning matching QBank questions.
                val useNeural = !actionCommand && !localSearchCommand && neuralPolicy.enabled && !neuralPolicy.circuitOpen && hasNeuralArtifact

                // SEARCH CONTRACT: explicit local-search/topic requests bypass every optional
                // ontology, ranking, and neural layer. The authoritative corpus is the SQLite
                // QBank, so a ranking/model failure must never become a false "no result".
                if (localSearchCommand) {
                    // Keep the v8.3.299 deterministic search lane as the compatibility fallback,
                    // but prefer the shared retrieval contract so Search, Frankenstein and
                    // grounded AI never disagree about the local corpus.
                    val result = runCatching { localSearch.search(command, 100) }.getOrElse { error ->
                        android.util.Log.w("Rovex.Frankenstein", "Shared local search failed; using direct QBank fallback", error)
                        val ids = runCatching { AppManagers.renCognitive.searchQuestionIds(command, 100) }
                            .getOrDefault(longArrayOf())
                            .distinct()
                        val fallbackHits = runCatching {
                            QBankDb(app).let { db ->
                                try {
                                    ids.mapNotNull { id ->
                                        val q = db.questionById(id) ?: return@mapNotNull null
                                        val testId = db.testIdForQuestion(q.id).orEmpty()
                                        if (testId.isBlank()) return@mapNotNull null
                                        val test = db.testById(testId)
                                        SearchHit(q.id, testId, test?.title.orEmpty(), q.position, q.text, test?.path, db.sourceNameForTest(testId).orEmpty(), q.stableKey)
                                    }
                                } finally { db.close() }
                            }
                        }.getOrDefault(emptyList())
                        LocalQBankSearchService.Result(fallbackHits, listOf(command), fallbackHits.size, 0)
                    }
                    val ids = result.hits.map { it.id }.distinct().take(100).toLongArray()
                    val examples = result.hits.take(6).map { "Q${it.position + 1} • ${it.testTitle}" }
                    val body = if (ids.isNotEmpty()) {
                        "Found ${ids.size} relevant local question${if (ids.size == 1) "" else "s"}.\n\n" +
                            examples.joinToString("\n") +
                            "\n\nSearch is grounded in the local QBank content."
                    } else {
                        "I could not find a matching local QBank question for that request. Try the main clinical term, disease, drug, investigation, or QBank name."
                    }
                    val insight = RenCognitiveEngine.Insight(
                        "Dr. Frankenstein local search", body,
                        if (ids.isNotEmpty()) listOf("Open matching questions") else emptyList()
                    )
                    if (ids.isNotEmpty()) cache[key] = Cached(insight, ids.copyOf(), System.currentTimeMillis())
                    trimCache()
                    runCatching { onResult(insight, ids) }
                        .onFailure { android.util.Log.e("Rovex.Frankenstein", "Local-search result callback failed", it) }
                    return@submitFrankensteinSuspend
                }

                if (useNeural) {
                    val result = try {
                        neuralPipeline.run(command)
                    } catch (cancel: CancellationException) {
                        throw cancel
                    } catch (_: Exception) {
                        null
                    }
                    if (result != null && BenResponsePolicy.normalize(result.answer).orEmpty().isNotBlank()) {
                        val visual = runCatching { AppManagers.renCognitive.understand(command).visualIntent }.getOrDefault(false)
                        val ids = runCatching {
                            AppManagers.renCognitive.searchQuestionIds(command, if (visual) 500 else 100)
                        }.getOrDefault(longArrayOf())
                        val actions = if (ids.isNotEmpty()) listOf("Open matching questions") else emptyList()
                        val insight = RenCognitiveEngine.Insight(
                            if (result.modelUsed) "Dr. Frankenstein • grounded neural response" else "Dr. Frankenstein • deterministic fallback",
                            BenResponsePolicy.normalize(result.answer).orEmpty().trim(),
                            actions
                        )
                        cache[key] = Cached(insight, ids.copyOf(), System.currentTimeMillis())
                        trimCache()
                        runCatching { onResult(insight, ids) }
                            .onFailure { android.util.Log.e("Rovex.Frankenstein", "Result callback failed", it) }
                        return@submitFrankensteinSuspend
                    }
                }

                // Action-oriented commands stay on the deterministic command router.
                val cognitive = AppManagers.renCognitive
                val insight = runCatching { cognitive.answer(command, currentQuestion) }
                    .getOrElse { t ->
                        // Do not turn an internal deterministic-engine exception into a dead-end
                        // user response. The engine itself owns the authoritative raw-QBank
                        // fallback; this catch is only the final containment boundary.
                        android.util.Log.e("Rovex.Frankenstein", "Deterministic cognitive route failed", t)
                        ProductionCrashReporter.breadcrumb(
                            RovexApplicationContextHolder.context,
                            "REN_DETERMINISTIC_ROUTE_FAILED:${t.javaClass.simpleName}"
                        )
                        runCatching {
                            val ids = cognitive.searchQuestionIds(command, 100)
                            RenCognitiveEngine.Insight(
                                "Dr. Frankenstein local recovery",
                                if (ids.isNotEmpty()) "I found matching local QBank questions and recovered the request through the direct retrieval path."
                                else "I could not find a matching local QBank result. Try the main clinical term or topic name.",
                                if (ids.isNotEmpty()) listOf("Open matching questions") else emptyList()
                            )
                        }.getOrElse { recovery ->
                            android.util.Log.e("Rovex.Frankenstein", "Deterministic recovery failed", recovery)
                            RenCognitiveEngine.Insight(
                                "Dr. Frankenstein",
                                "The local study engine is temporarily unavailable for this request. Your QBank data is unchanged; try the request again."
                            )
                        }
                    }
                val ids = if (insight.actions.contains("Open matching questions")) {
                    val visual = runCatching { cognitive.understand(command).visualIntent }.getOrDefault(false)
                    runCatching { cognitive.searchQuestionIds(command, if (visual) 500 else 100) }.getOrDefault(longArrayOf())
                } else longArrayOf()
                cache[key] = Cached(insight, ids.copyOf(), System.currentTimeMillis())
                trimCache()
                runCatching { onResult(insight, ids) }
                    .onFailure { android.util.Log.e("Rovex.Frankenstein", "Result callback failed", it) }
            } finally {
                inFlight.remove(key)
                runningJobs.remove(key)
            }
        }
        runningJobs[key] = job
    }

    fun invalidate() { cache.clear() }
    fun trimNeuralResources() { runCatching { neuralPipeline.trim() } }
    fun shutdown() {
        cache.clear()
        runningJobs.values.forEach { it.cancel() }
        runningJobs.clear()
        inFlight.clear()
        runCatching { localSearch.close() }
        runCatching { neuralPipeline.close() }
    }

    private fun isLocalSearchCommand(command: String): Boolean {
        val q = command.trim().lowercase()
        val explicitSearch = listOf(
            "find", "search", "related question", "related questions",
            "similar question", "similar questions", "matching question",
            "matching questions", "show questions", "give me questions",
            "qbank questions", "previous question", "pyq"
        ).any { q.contains(it) }
        if (explicitSearch) return true

        // A bare medical topic is a retrieval request in Frankenstein. Previously a short noun
        // phrase such as "cervical cancer" was routed into the neural answer pipeline because it
        // lacked the words "find/search/questions". That pipeline can legitimately answer the
        // topic, but it is not the authoritative QBank retrieval path and could therefore surface
        // the generic no-result fallback even when an equivalent local term exists. Keep topic-only
        // prompts deterministic so the local corpus is searched before any optional generation.
        // Keep this decision in the shared local-search contract so Frankenstein and other
        // consumers cannot diverge on punctuation/topic routing.
        return LocalQBankSearchService.isLikelyTopicQuery(q)
    }

    private fun isActionCommand(command: String): Boolean {
        val q = command.lowercase()
        return listOf("flashcard", "flash card", "create note", "save note", "what should i study", "study plan", "wrong questions", "make a note", "start quiz", "open study tools").any { q.contains(it) }
    }

    private fun trimCache() {
        if (cache.size <= 24) return
        val oldest = cache.entries.minByOrNull { it.value.at }?.key ?: return
        cache.remove(oldest)
    }
}

