# Repair audit — Rovex 8.3.680 Phase 2A

## Scope
Reduce avoidable regex allocation/compilation in Mermaid rich-content rendering. This batch does not change chat storage, transcript ownership, DOM insertion semantics, WebView security policy, AI inference, or QBank scheduling.

## Changes
- `app/src/main/java/com/localqbank/library/RovexMarkdown.kt`: shared private compiled pattern set; node, flow edge, fallback edge, label, diagram family and chart parsing now reuse compiled instances.
- `app/src/test/java/com/localqbank/library/RovexRichRendererTest.kt`: repeated deterministic-render regression.
- `tools/verify_chat_render_performance.sh`: static architecture gate; existing five static gates also pass.
- `app/build.gradle.kts`: versionName 8.3.680, versionCode 766.

## Verification
- Dedicated chat-render hot-path gate: PASS.
- Dashboard indexing gate: PASS.
- Phase 1 QBank contention gate: PASS.
- Search/QBank regression gate: PASS.
- Performance/search architecture gate: PASS.
- Defect regression gate: PASS.
- `./gradlew :app:testDebugUnitTest --no-daemon`: BLOCKED before Gradle starts; wrapper could not resolve `downloads.gradle.org` (curl exit 6).
- Exact-source CI, release APK/signature, visual acceptance, physical-device tracing and measured latency/allocation delta: NOT VERIFIED.

## Risk and rollback
The change centralizes previously local regex instances and keeps their patterns/matching calls unchanged. Rollback is limited to restoring the previous `RovexMarkdown.kt`, removing the added regression test and static gate, and restoring the previous version metadata. Do not call this a measured performance win until a controlled benchmark shows lower render CPU/allocation without output regressions.
