# Repair audit — v8.3.681

## Change

Added `security-tests/firestore.rules.test.mjs`, pinned test dependencies and emulator command, Firestore Emulator configuration, and instructions. Tests cover owner-scoped request reads, sender-scoped outgoing reads, client friend-code hijacking, cross-user profile mutation, XP/aggregate spoofing, forged incoming requests, and immutable mailbox updates. Bumped app version to 8.3.681 / versionCode 767.

## Safety

No production Firebase project is configured in the test harness. The suite uses `demo-rovex-security`. Rules tests use emulator-only fixture seeding through `withSecurityRulesDisabled`.

## Verification boundary

This is test coverage added, not proof of a passing emulator run. The test dependencies and Firebase CLI must be installed and `npm test` must pass. Production rules parity and deployed behavior remain separate gates. No release APK or runtime success is claimed.
