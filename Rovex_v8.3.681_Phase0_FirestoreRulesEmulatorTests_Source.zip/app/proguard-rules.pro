# Retain the inert encrypted provenance anchor in optimized APKs.
-keep class com.localqbank.library.BuildMetadataAnchor { *; }

# Android WebView JavaScript bridge: method names are part of the HTML extractor contract.
-keepclassmembers class com.localqbank.library.HtmlImportActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}

# StartupHealthChecker resolves Activity classes by string name. Keep Activity names and
# constructors stable while allowing method/member shrinking where safe.
-keepnames class com.localqbank.library.**Activity
-keep class com.localqbank.library.**Activity { public <init>(...); }

# Keep classes/members explicitly annotated for reflection by Android/Firebase libraries.
-keep @androidx.annotation.Keep class * { *; }
-keepclassmembers class * { @androidx.annotation.Keep *; }
