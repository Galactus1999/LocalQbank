package com.localqbank.library

import com.localqbank.library.ai.context.EvidencePack
import com.localqbank.library.ai.context.toEvidencePack
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Adversarial, deterministic contracts for Ben's retrieval-role boundary. */
class BenContrastiveEvidencePlannerTest {

    @Test
    fun malformedSourceIdsAndNonFiniteScoresNeverEnterEvidence() {
        val result = BenContrastiveEvidencePlanner.plan(
            query = "clinical question",
            candidates = listOf(
                BenContrastiveEvidencePlanner.Candidate(10L, "valid lower", 0.4),
                BenContrastiveEvidencePlanner.Candidate(20L, "valid higher", 0.8),
                BenContrastiveEvidencePlanner.Candidate(0L, "zero source", 100.0),
                BenContrastiveEvidencePlanner.Candidate(-2L, "negative source", 200.0),
                BenContrastiveEvidencePlanner.Candidate(30L, "NaN score", Double.NaN),
                BenContrastiveEvidencePlanner.Candidate(40L, "positive infinity", Double.POSITIVE_INFINITY),
                BenContrastiveEvidencePlanner.Candidate(50L, "negative infinity", Double.NEGATIVE_INFINITY),
            )
        )

        assertEquals(listOf(20L, 10L), result.answers.map { it.sourceId })
        assertTrue((result.answers + result.distractors).none { it.sourceId <= 0L })
        assertTrue(result.all().none { !it.score.isFinite() })
    }

    @Test
    fun rankingIsDeterministicAndDuplicateSourceCannotOccupyTwoRoles() {
        val candidates = listOf(
            BenContrastiveEvidencePlanner.Candidate(33L, "tie source 33", 0.9),
            BenContrastiveEvidencePlanner.Candidate(22L, "older duplicate", 0.7),
            BenContrastiveEvidencePlanner.Candidate(11L, "tie source 11", 0.9),
            BenContrastiveEvidencePlanner.Candidate(22L, "best source 22", 0.95),
            BenContrastiveEvidencePlanner.Candidate(44L, "fourth", 0.1),
        )

        val result = BenContrastiveEvidencePlanner.plan(
            query = "query", candidates = candidates, maxAnswer = 2, maxDistractor = 3
        )

        assertEquals(listOf(22L, 11L), result.answers.map { it.sourceId })
        assertEquals(listOf(33L, 44L), result.distractors.map { it.sourceId })
        assertTrue(result.answers.map { it.sourceId }.toSet().intersect(
            result.distractors.map { it.sourceId }.toSet()
        ).isEmpty())
    }

    @Test
    fun totalCharacterBudgetIncludesQuestionAndClipsRetrievedEvidence() {
        val result = BenContrastiveEvidencePlanner.plan(
            query = "QUERY",
            candidates = listOf(
                BenContrastiveEvidencePlanner.Candidate(1L, "1234567890", 1.0),
                BenContrastiveEvidencePlanner.Candidate(2L, "abcdefghij", 0.5),
            ),
            maxAnswer = 2,
            maxDistractor = 2,
            maxTotalChars = 12,
        )

        assertEquals(12, result.totalChars())
        assertEquals("QUERY", result.question.single().text)
        assertEquals("1234567", result.answers.single().text)
        assertTrue(result.totalChars() <= 12)
    }

    @Test
    fun distractorEvidenceCannotBecomeCitationAuthoritative() {
        val planned = BenContrastiveEvidencePlanner.plan(
            query = "question",
            candidates = listOf(
                BenContrastiveEvidencePlanner.Candidate(101L, "supported answer evidence", 0.95),
                BenContrastiveEvidencePlanner.Candidate(202L, "contradictory distractor evidence", 0.2),
            ),
            maxAnswer = 1,
            maxDistractor = 1,
        )
        val pack: EvidencePack = planned.toEvidencePack()

        assertEquals(listOf(101L), pack.authoritativeAnswerEvidence().map { it.sourceId })
        assertEquals(listOf(202L), pack.distractorEvidence.map { it.sourceId })
        assertTrue(pack.authoritativeAnswerEvidence().none { it.sourceId == 202L })
    }

    @Test
    fun zeroBudgetDoesNotPromoteCandidates() {
        val result = BenContrastiveEvidencePlanner.plan(
            query = "question",
            candidates = listOf(BenContrastiveEvidencePlanner.Candidate(1L, "answer", 1.0)),
            maxTotalChars = 0,
        )

        assertTrue(result.answers.isEmpty())
        assertTrue(result.distractors.isEmpty())
        assertEquals(0, result.totalChars())
    }
}
