# Rovex 8.3.679 — Phase 1 dashboard performance

- Moved QBank dashboard subject/category grouping and metric aggregation into the existing background data-loading path.
- Reused pre-indexed groups for QBank, Subject Tests, and Mastery rendering to avoid repeated full-catalog scans on the main thread.
- Preserved QBank hierarchy, the combined Community Medicine / PSM subject, category ordering, progress formulas, and lazy subject expansion.
- Refreshed stale static regression gates to follow the current database/search/progress ownership boundaries.

Verification: targeted static regression gates pass. Exact-source Gradle/CI and physical-device benchmark validation are still pending.
