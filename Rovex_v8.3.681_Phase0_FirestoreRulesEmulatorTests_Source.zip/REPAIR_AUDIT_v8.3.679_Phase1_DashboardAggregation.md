# Rovex v8.3.679 — Phase 1 dashboard aggregation/indexing

## Scope
Continue Phase 1 (QBank data/performance stability) with a narrow, source-proven main-thread work reduction. No database schema, progress identity, import/delete semantics, search ranking, Ben inference, or SRS scheduling changes.

## Finding
`RovexSectionDashboardActivity.loadLiveData()` already receives dashboard rows from `QBankLoadingEngine`'s background executor, but `qbank()`, `tests()`, and `mastery()` repeatedly filtered the full catalog and recomputed subject totals/accuracy/coverage while constructing Views on the main thread. The QBank page filtered all rows once per canonical subject; Subject Tests did the same and then filtered each subject's rows again. The dashboard has 19 canonical subjects, so this work scales as repeated full-catalog scans during rendering.

## Repair
- Build `rowsBySubject`, `rowsBySubjectKind`, and `unassignedByKind` once in the background callback.
- Precompute overall and per-group totals/solved/correct metrics before posting the snapshot to the UI thread.
- QBank, Subject Tests, and Mastery rendering now consume the indexed groups and precomputed metrics rather than repeatedly filtering the complete row list.
- Preserve the existing 19-subject canonical hierarchy, combined Community Medicine / PSM category, category names, ordering within each category, progress formulas, and lazy expansion of each subject's child rows.
- Bump versionName to 8.3.679 and versionCode to 765.

## Verification performed
PASS:
- `tools/verify_dashboard_indexing.sh`
- `tools/verify_phase1_qbank_contention.sh`
- `tools/verify_search_qbank_regressions.sh`
- `tools/verify_performance_search_architecture.sh`
- `tools/verify_defect_regressions.sh`

The existing static gates had stale source-ownership/range assumptions after repository decomposition (e.g. SQL moved to `QBankSearchRepository.kt`/`QBankDatabaseProvider.kt`, progress writes moved to `ProgressStore.kt`, and an overly broad `sed` range mistook unrelated order-management worker work for the critical QBank catalog load). Those assertions were updated to check the current owners and actual method boundaries; they now pass against this source.

## Not yet verified
- Gradle compile / JVM test suite for 8.3.679.
- Full GitHub Actions build for this exact source ZIP.
- Physical-device cold/warm QBank and Subject Tests latency, frame timing, memory, and Perfetto evidence.
- Actual large-corpus performance delta; the repair removes redundant full-list scans by construction, but no measured latency improvement is claimed yet.

The previously green CI run #1316 built a different repository-selected ZIP and does not verify v8.3.679 or v8.3.678. Do not call this phase build-green or device-validated until the exact 8.3.679 source is selected by CI and real-device measurements are collected.
