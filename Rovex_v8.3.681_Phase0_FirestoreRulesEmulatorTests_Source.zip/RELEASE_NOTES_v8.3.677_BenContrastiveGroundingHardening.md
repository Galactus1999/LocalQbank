# Rovex v8.3.677 — Ben contrastive evidence hardening

- Reject retrieved candidates with non-positive source IDs or non-finite scores before ranking.
- Add deterministic JVM regression coverage for score ordering, duplicate-source exclusion, bounded context, and answer-vs-distractor citation authority.
- Keep the existing deterministic answer verifier authoritative; this phase changes no model/runtime lifecycle or neural backend policy.
- No Android database schema, package ID, signing configuration, or existing study behavior is intentionally changed.
