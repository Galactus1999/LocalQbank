# Firestore security emulator tests

These tests exercise the checked-in `firestore.rules` against the Firestore Emulator. They are intentionally separate from the Cloud Functions unit tests because source-pattern tests cannot prove the rules engine denies a request.

## Run

From this directory, install the pinned development dependencies and run:

```sh
npm install
npm test
```

The test script starts the Firestore Emulator through `firebase emulators:exec`, runs the Node test suite, and shuts the emulator down. The configured emulator project is `demo-rovex-security`; no production project is targeted.

Coverage includes:

- owner-only reads of incoming friend requests and recipient mailboxes;
- sender-only reads of outgoing requests;
- denied client reads/writes of canonical `friendCodes` ownership;
- denied cross-user profile writes and client writes to XP/study aggregates;
- denied forged incoming requests and mutation of immutable mailbox messages.

A passing test run is required before treating Firestore isolation as verified. These tests do not themselves prove deployed production rules match this source; deployment revision and project must be checked separately.
