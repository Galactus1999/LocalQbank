import test, { before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} from '@firebase/rules-unit-testing';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
} from 'firebase/firestore';

const here = path.dirname(fileURLToPath(import.meta.url));
const projectId = 'demo-rovex-security';
const OWNER = 'owner-user';
const SENDER = 'sender-user';
const ATTACKER = 'attacker-user';
const OWNER_CODE = 'RVX-AAAA-BBBB';
const REQUEST_ID = 'request-001';
let env;

before(async () => {
  env = await initializeTestEnvironment({
    projectId,
    firestore: {
      host: '127.0.0.1',
      port: 8080,
      rules: fs.readFileSync(path.resolve(here, '../firestore.rules'), 'utf8'),
    },
  });
});

after(async () => {
  if (env) await env.cleanup();
});

beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await setDoc(doc(db, 'users', OWNER), {
      uid: OWNER, displayName: 'Owner', rovexId: OWNER_CODE,
      xp: 9000, questionsSolved: 120, aggregateVersion: 1,
    });
    await setDoc(doc(db, 'users', SENDER), {
      uid: SENDER, displayName: 'Sender', rovexId: 'RVX-CCCC-DDDD',
    });
    await setDoc(doc(db, 'friendCodes', OWNER_CODE), {
      uid: OWNER, displayName: 'Owner',
    });
    await setDoc(doc(db, 'friendRequestMailboxes', OWNER_CODE, 'requests', REQUEST_ID), {
      requestId: REQUEST_ID, requesterUid: SENDER, requesterName: 'Sender',
      requesterCode: 'RVX-CCCC-DDDD', targetCode: OWNER_CODE,
      status: 'pending', createdAt: 123,
    });
    await setDoc(doc(db, 'friendRequests', OWNER, 'incoming', SENDER), {
      targetUid: OWNER, requesterUid: SENDER, targetCode: OWNER_CODE,
      intentId: REQUEST_ID, status: 'pending',
    });
    await setDoc(doc(db, 'friendRequestsBySender', SENDER, 'outgoing', REQUEST_ID), {
      requestId: REQUEST_ID, requesterUid: SENDER, requesterName: 'Sender',
      requesterCode: 'RVX-CCCC-DDDD', targetCode: OWNER_CODE,
      status: 'pending', createdAt: 123,
    });
  });
});

test('only the owner can read their request mailbox and incoming requests', async () => {
  const ownerDb = env.authenticatedContext(OWNER).firestore();
  const attackerDb = env.authenticatedContext(ATTACKER).firestore();
  await assertSucceeds(getDoc(doc(ownerDb, 'friendRequestMailboxes', OWNER_CODE, 'requests', REQUEST_ID)));
  await assertSucceeds(getDoc(doc(ownerDb, 'friendRequests', OWNER, 'incoming', SENDER)));
  await assertFails(getDoc(doc(attackerDb, 'friendRequestMailboxes', OWNER_CODE, 'requests', REQUEST_ID)));
  await assertFails(getDoc(doc(attackerDb, 'friendRequests', OWNER, 'incoming', SENDER)));
  await assertFails(getDocs(collection(attackerDb, 'friendRequests', OWNER, 'incoming')));
});

test('outgoing request records are private to the authenticated sender', async () => {
  const senderDb = env.authenticatedContext(SENDER).firestore();
  const attackerDb = env.authenticatedContext(ATTACKER).firestore();
  await assertSucceeds(getDoc(doc(senderDb, 'friendRequestsBySender', SENDER, 'outgoing', REQUEST_ID)));
  await assertFails(getDoc(doc(attackerDb, 'friendRequestsBySender', SENDER, 'outgoing', REQUEST_ID)));
  await assertFails(getDocs(collection(attackerDb, 'friendRequestsBySender', SENDER, 'outgoing')));
});

test('clients cannot read or hijack canonical friend-code ownership', async () => {
  const attackerDb = env.authenticatedContext(ATTACKER).firestore();
  await assertFails(getDoc(doc(attackerDb, 'friendCodes', OWNER_CODE)));
  await assertFails(setDoc(doc(attackerDb, 'friendCodes', OWNER_CODE), { uid: ATTACKER }));
  await assertFails(updateDoc(doc(attackerDb, 'friendCodes', OWNER_CODE), { uid: ATTACKER }));
  await assertFails(setDoc(doc(attackerDb, 'friendCodes', 'RVX-EEEE-FFFF'), { uid: ATTACKER }));
});

test('users cannot overwrite another profile or client-owned competitive aggregates', async () => {
  const attackerDb = env.authenticatedContext(ATTACKER).firestore();
  const ownerDb = env.authenticatedContext(OWNER).firestore();
  await assertFails(updateDoc(doc(attackerDb, 'users', OWNER), { displayName: 'Hijacked' }));
  await assertFails(updateDoc(doc(ownerDb, 'users', OWNER), { xp: 999999999 }));
  await assertFails(updateDoc(doc(ownerDb, 'users', OWNER), { questionsSolved: 999999999 }));
  await assertFails(updateDoc(doc(ownerDb, 'users', OWNER), { correct: 999999999 }));
});

test('a user cannot forge incoming requests as another recipient or alter immutable mail', async () => {
  const attackerDb = env.authenticatedContext(ATTACKER).firestore();
  await assertFails(setDoc(doc(attackerDb, 'friendRequests', OWNER, 'incoming', ATTACKER), {
    targetUid: OWNER, requesterUid: ATTACKER, targetCode: OWNER_CODE,
    intentId: REQUEST_ID, status: 'pending',
  }));
  await assertFails(updateDoc(doc(attackerDb, 'friendRequestMailboxes', OWNER_CODE, 'requests', REQUEST_ID), {
    status: 'accepted',
  }));
});
