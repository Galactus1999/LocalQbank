# LocalQBank v7.25.0 — Adaptive Intelligence Platform

This release adds a bounded multi-engine intelligence layer with local-first resilience.

## New architecture
- Adaptive Engine: bounded runtime optimisation and study strategy.
- Study Intelligence: subject focus and adaptive question selection.
- Flashcard Intelligence: idempotent flashcard generation from wrong/important questions.
- Knowledge Engine: automatic local notes, table capture and image copying from important/wrong questions.
- Resilience Engine: crash checkpointing, safe-mode escalation, UI-heartbeat stall detection and recovery prompt.
- Engine Health: read-only health and incident status for the settings console.
- Intelligence Orchestrator: a single coordination facade for future Ben/local natural-language commands.

## Safety design
The engines produce derived artifacts only. Original QBank question data and progress records are not rewritten by AI-derived content. Autonomous performance actions remain limited to prefetch depth, cache lifetime and safe mode. The resilience layer never attempts to kill or forcibly restart a process; Android remains authoritative for ANR/process lifecycle decisions.

## Recovery
Quiz position is checkpointed on pause/stop and meaningful navigation. If a process interruption is detected, the next healthy launch can offer to resume the protected study session. Repeated failures or a stale UI heartbeat force conservative safe mode.

## Performance
All heavy retrieval, flashcard generation, knowledge capture and image copying are background operations. Image capture is bounded to eight images and 8 MiB per image. The question cache remains small and adaptive.

## Validation
Static XML/type and Kotlin syntax audits should be run in CI. Android SDK/Gradle compilation and device profiling must remain the authoritative build/performance tests. This environment does not contain the Android SDK, so no APK compilation or device test is claimed here.


## v7.25.1 final polish
- Home header is now part of the scrollable content; it no longer persists as a fixed slab.
- Home hero/greeting/continue and quick-action surfaces are theme-derived.
- Quiz settings moved beside the question counter to avoid device notification/cutout overlap.
- Added an in-question Auto Note action backed by the Knowledge Engine.
- Adaptive settings expose separate Flashcard Intelligence and Knowledge/Auto-Notes engine sections.
- Flashcard/home study surfaces use theme-aware semantic colors.
- Added explicit Add QBank XML resource and cross-checked all app R.id references.
