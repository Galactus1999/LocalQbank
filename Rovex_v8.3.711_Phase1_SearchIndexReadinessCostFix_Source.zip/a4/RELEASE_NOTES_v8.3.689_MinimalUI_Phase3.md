# Rovex v8.3.689 — Minimal UI Phase 3

- Version code: 775
- Baseline: v8.3.688 / versionCode 774
- Package/application ID preserved: `com.localqbank.library`

## Changes
- Removed the explanatory introductory paragraph from Ben's reference-PDF import screen; the import action remains explicit.
- Moved the PDF OCR/local-privacy explanation to the screen's accessibility description rather than permanent small text.
- Replaced Visual Lab's verbose tiny progress caption with a compact `68%` value while preserving its accessibility description.
- Removed the Visual Lab sample dialog's visible explanatory paragraph; retained the no-study-state-change information in accessibility metadata.
- No business logic, import pipeline, study scheduling, QBank persistence, or AI runtime logic intentionally changed.
- Preserves the prior v8.3.687 QBank interaction/motion changes and v8.3.688 StudyToolsActivity compile fix.

## Verification
- Source/static checks are documented in `ROVEX_MINIMAL_UI_PHASE3_AUDIT.md`.
- This source archive is not a verified APK. Android build, tests, CI and device visual checks must be run separately.
