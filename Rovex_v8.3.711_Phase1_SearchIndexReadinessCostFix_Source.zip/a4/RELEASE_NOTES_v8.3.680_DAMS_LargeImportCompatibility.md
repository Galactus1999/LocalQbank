# Rovex v8.3.680 — DAMS large HTML import compatibility

## Root cause
The large-file streaming scanner did not recognize all question/option aliases already supported by the regular HTML parser. In particular, `option_list` / `optionList`, `questionText`, and legacy option-object fields could cause every record in an otherwise parseable export to be discarded during preflight. Because preflight correctly rejects zero normalized questions, import stopped at 28% and protected the existing QBank.

## Changes
- Align `LargeHtmlScanner.normalize()` aliases with the existing regular HTML parser for legacy option arrays, question text, answer, explanation, and option text fields.
- Add a regression test using a DAMS-like `TESTS_LIST` payload with `questionText`, `option_list`, `option_text`, and `explanationText`.
- Preserve streaming/preflight behavior and existing-QBank protection; do not weaken zero-question rejection.

## Verification
Static source review only. Full Android compilation, Gradle tests, CI, and a real DAMS export/device import still require execution. The regression test is added but not claimed as executed.
