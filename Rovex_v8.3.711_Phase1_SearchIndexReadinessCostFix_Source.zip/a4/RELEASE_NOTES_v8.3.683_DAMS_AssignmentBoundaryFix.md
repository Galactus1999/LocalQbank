# Rovex v8.3.683 — DAMS large-HTML import assignment-boundary fix

## Root cause

The large-file scanner's JavaScript assignment recognizer required the declaration keyword (`const`, `let`, or `var`) to be the entire suffix after the last semicolon. JavaScript permits automatic semicolon insertion and common exports place `const TESTS_LIST = [...]` after a function/object block without a semicolon. In those files, the scanner could ignore the real payload, emit zero normalized questions, and stop at the preflight guard with the exact user-visible message seen at 28%.

The small-file parser and large-file scanner use different discovery paths, explaining why an export can work in the older/small import route but fail once it crosses the large-file threshold.

## Repair

- Keep streaming parsing and bounded question-object materialization.
- Accept the declaration keyword at a valid lexical boundary after the last semicolon or closing brace, including newline/ASI boundaries.
- Continue to require an exact supported identifier; this does not loosen matching to arbitrary variables or substring matches.
- Add a regression test with a function block lacking a semicolon immediately before a populated `TESTS_LIST`.
- Preserve preflight-before-replacement and the zero-question guard.
- Version: 8.3.683, versionCode 769; package remains `com.localqbank.library`.

## Verification

- Source diff reviewed; exact-name matching remains enforced.
- ZIP integrity verified after packaging.
- Regression test added but not executed: Gradle wrapper distribution download failed because `downloads.gradle.org` DNS could not resolve in this environment.
- The exact DAMS file from the user's device is not attached, so real-file/device confirmation remains required. The available `DAMS_Quiz_Club.html` fixture is a reference, not assumed to be the same export.

## Research basis

HTML/JavaScript source is not safely parsed by simplistic regex alone; a scanner must respect lexical contexts and JavaScript declaration boundaries. The existing streaming lexer is retained and its boundary recognition is repaired rather than replacing it with a whole-file load. See the WHATWG/HTML parsing overview and Android/SQLite guidance referenced in the accompanying response.
