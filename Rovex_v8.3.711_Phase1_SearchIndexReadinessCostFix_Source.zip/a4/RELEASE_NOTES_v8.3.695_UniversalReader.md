# v8.3.695 — Universal Reader foundation

- Added bounded adaptive source hints for Marrow, DocTutorials, PrepLadder, DAMS, Cerebellum, DBMCI, eGurukul and generic exports.
- Expanded common question stem, options, answer, explanation and section aliases in native and large-file parsing.
- Added additional nested container traversal with recursion depth limits.
- Added provider-detection and parser regression fixtures.
- Preserved read-only preflight and zero-question/partial-count abort safeguards.
- Verification caveat: Gradle tests/build could not start because `downloads.gradle.org` DNS resolution failed; platform export/device compatibility remains unverified.
