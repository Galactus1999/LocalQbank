# Rovex v8.3.685 — Minimal UI Phase 1

## Scope
- Reduce Home vertical clutter by removing generic microcopy, duplicate status text, search shortcut decoration, and redundant section subtitles.
- Compact the Home brand header and metrics cards while retaining existing custom views, click targets, and IDs where possible.
- Simplify Flashcards header and deck section title; remove repeated subtitle rows from shared popup/sheet/card builders.
- Preserve flashcard counts by moving them into visible option titles rather than hiding them with descriptive copy.
- Simplify Study Tools into compact title-first rows; remove generic introduction, per-row descriptions/tags, and closing tip.
- Keep secondary explanations available to accessibility services where they are useful, without permanently displaying them as tiny copy.
- Bump version to 8.3.685 / versionCode 771.

## Safety boundaries
- No QBank import, database, SRS scheduling, study-progress, deletion, or signing logic intentionally changed.
- This is a source-level UI pass. Build, automated tests, CI, and device visual validation must be run before calling the release verified.
