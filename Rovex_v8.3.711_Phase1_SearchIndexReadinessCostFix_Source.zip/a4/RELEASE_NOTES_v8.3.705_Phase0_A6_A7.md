# v8.3.705 — Phase 0 A6/A7 audit guardrails

- Audited the HTML import and flashcard WebView security boundaries and recorded compatibility-sensitive residual risks.
- Added source-contract regression tests for importer bridge isolation and key WebView settings.
- Explicitly kept R8 minification/resource shrinking disabled until signed release, reflection, and native inference validation is available.
- No claim of Android compilation, emulator, CI, or device success.
