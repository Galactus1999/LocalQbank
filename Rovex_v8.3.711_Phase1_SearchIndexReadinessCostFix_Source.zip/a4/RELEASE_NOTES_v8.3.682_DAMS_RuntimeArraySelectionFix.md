# Rovex v8.3.682 — DAMS runtime-array selection repair

## Regression root cause
The large-file scanner grouped several candidate variable names into a set and selected the first matching assignment in document order. Generic names such as `tests` may be declared as empty runtime/UI state before a real export payload such as `TESTS_LIST`. If that empty array was encountered first, the scanner emitted zero questions and moved to a different alias tier instead of trying the more specific payload in the same tier.

## Repair
- Evaluate candidate variable aliases in explicit specificity order rather than source-document order.
- Prefer `TESTS_LIST` and other explicit combined-test payload names before generic `tests` runtime state.
- Continue to the next alias when a candidate produces zero valid questions; preserve preflight-before-database-replacement.
- Recognize legacy `items`, `question_list`, `questionlist`, `question_data`, and `questiondata` arrays inside a combined test object.
- Preserve streaming parsing, bounded object materialization, existing QBank data on preflight failure, and all earlier import/deletion/Ben/header fixes from the v8.3.681 source.

## Regression tests added
- An empty `const tests = []` preceding a populated `const TESTS_LIST = [...]` must import the populated list.
- `items` nested inside a combined test must be parsed using the same question normalizer.

## Verification status
- Source diff and version identity checked.
- Regression tests added; execution requires Android/JVM Gradle test environment.
- Full Gradle build and device import remain unverified until CI/build and a real DAMS file test pass.
