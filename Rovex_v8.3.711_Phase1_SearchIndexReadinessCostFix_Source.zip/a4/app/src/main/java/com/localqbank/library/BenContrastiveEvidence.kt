package com.localqbank.library

/**
 * Evidence container. Retrieval rank is not proof of claim support: retrieved records remain
 * candidates until the deterministic verifier checks the generated claim/citation relationship.
 * Contrastive context is never citation-authoritative.
 */
internal object BenContrastiveEvidence {
    enum class Role { QUESTION_EVIDENCE, CANDIDATE_EVIDENCE, CONTRASTIVE_EVIDENCE }

    data class Item(
        val role: Role,
        val sourceId: Long,
        val text: String,
        val score: Double = 0.0,
    )

    data class Bundle(
        val question: List<Item> = emptyList(),
        val contrastive: List<Item> = emptyList(),
        val candidates: List<Item> = emptyList(),
    ) {
        fun bounded(maxQuestion: Int = 4, maxContrastive: Int = 4, maxCandidates: Int = 8): Bundle =
            Bundle(
                question = question.filter { it.role == Role.QUESTION_EVIDENCE }.take(maxQuestion.coerceAtLeast(0)),
                contrastive = contrastive.filter { it.role == Role.CONTRASTIVE_EVIDENCE }.take(maxContrastive.coerceAtLeast(0)),
                candidates = candidates.filter { it.role == Role.CANDIDATE_EVIDENCE }.take(maxCandidates.coerceAtLeast(0)),
            )

        fun all(): List<Item> = question + candidates + contrastive

        fun totalChars(): Int = all().sumOf { it.text.length }
    }
}
