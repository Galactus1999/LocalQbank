package com.localqbank.library

/** WCAG 2.x contrast utilities for text/icons placed on dynamically chosen surfaces. */
object RovexContrastPolicy {
    private fun linearize(channel: Int): Double {
        val s = channel.coerceIn(0, 255) / 255.0
        return if (s <= 0.04045) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }

    /** Relative luminance in the WCAG sRGB color space, in [0, 1]. */
    fun relativeLuminance(color: Int): Double =
        0.2126 * linearize((color shr 16) and 0xFF) +
            0.7152 * linearize((color shr 8) and 0xFF) +
            0.0722 * linearize(color and 0xFF)

    fun contrastRatio(foreground: Int, background: Int): Double {
        val a = relativeLuminance(foreground)
        val b = relativeLuminance(background)
        val lighter = maxOf(a, b)
        val darker = minOf(a, b)
        return (lighter + 0.05) / (darker + 0.05)
    }

    /** Select whichever of white or near-black provides the stronger contrast. */
    fun onColor(background: Int): Int {
        val dark = 0xFF08141C.toInt()
        val light = 0xFFFFFFFF.toInt()
        return if (contrastRatio(dark, background) >= contrastRatio(light, background)) dark else light
    }
}
