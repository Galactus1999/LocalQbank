package com.localqbank.library

import android.database.sqlite.SQLiteDatabase

/**
 * Source-scoped cleanup for resume metadata. `sourceName:*` keys are legacy compatibility
 * aliases and are not unique identifiers; only remove one when its stored test belongs to the
 * source being deleted. All callers invoke this inside their existing database transaction.
 */
internal object QBankProgressMetaOwnership {
    fun deleteResumeKeysForSource(db: SQLiteDatabase, sourceId: Long, sourceName: String?) {
        db.delete("progress_meta", "meta_key=?", arrayOf("source:$sourceId:resume"))
        if (sourceName.isNullOrBlank()) return
        val legacyKey = "sourceName:$sourceName:resume"
        val value = db.rawQuery(
            "SELECT meta_value FROM progress_meta WHERE meta_key=? LIMIT 1",
            arrayOf(legacyKey)
        ).use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null } ?: return
        val parts = value.split('|')
        val testId = parts.firstOrNull()?.takeIf { it.isNotBlank() } ?: return
        // Newer/global values may carry the source ID explicitly; prefer that durable owner.
        val explicitSourceId = parts.getOrNull(2)?.toLongOrNull()
        val testOwner = if (explicitSourceId == null) {
            db.rawQuery(
                "SELECT source_id FROM test WHERE id=? LIMIT 1",
                arrayOf(testId)
            ).use { cursor -> if (cursor.moveToFirst()) cursor.getLong(0) else null }
        } else null
        if (legacyResumeKeyBelongsToSource(sourceId, value, testOwner)) {
            db.delete("progress_meta", "meta_key=?", arrayOf(legacyKey))
        }
    }

    /** Pure ownership rule, separately testable without Android SQLite. */
    internal fun legacyResumeKeyBelongsToSource(sourceId: Long, value: String, testOwnerSourceId: Long?): Boolean {
        if (sourceId <= 0L) return false
        val parts = value.split('|')
        if (parts.firstOrNull().isNullOrBlank()) return false
        val explicitSourceId = parts.getOrNull(2)?.toLongOrNull()
        return explicitSourceId?.let { it == sourceId } ?: (testOwnerSourceId == sourceId)
    }
}
