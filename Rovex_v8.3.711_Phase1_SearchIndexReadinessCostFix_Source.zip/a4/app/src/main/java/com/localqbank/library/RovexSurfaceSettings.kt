package com.localqbank.library

import android.content.Context

/** Persistent user choice for the app's surface treatment, independent of theme/motion. */
object RovexSurfaceSettings {
    private const val PREFS = "rovex_surface_appearance"
    private const val KEY_GLASS = "liquid_glass_enabled"
    fun isGlassEnabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_GLASS, true)
    fun setGlassEnabled(context: Context, enabled: Boolean) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_GLASS, enabled).apply()
    }
}
