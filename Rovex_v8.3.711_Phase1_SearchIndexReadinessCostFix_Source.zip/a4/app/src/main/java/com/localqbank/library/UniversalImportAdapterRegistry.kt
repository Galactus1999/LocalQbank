package com.localqbank.library

/** Source-independent routing hints for exported educational content. */
internal object UniversalImportAdapterRegistry {
    enum class Format { HTML, JSON, APKG_OR_ZIP, PDF, EPUB, UNKNOWN }
    data class Detection(val format: Format, val provider: String, val strategy: String, val confidence: Int)

    fun detect(fileName: String, prefix: String): Detection {
        val name = fileName.lowercase()
        val sample = prefix.take(512 * 1024).lowercase()
        val format = when {
            name.endsWith(".apkg") || name.endsWith(".zip") || prefix.startsWith("PK\u0003\u0004") -> Format.APKG_OR_ZIP
            name.endsWith(".pdf") || prefix.startsWith("%pdf-") -> Format.PDF
            name.endsWith(".epub") -> Format.EPUB
            name.endsWith(".json") || sample.trimStart().let { it.startsWith("{") || it.startsWith("[") } -> Format.JSON
            name.endsWith(".html") || name.endsWith(".htm") || sample.contains("<html") || sample.contains("<!doctype html") -> Format.HTML
            else -> Format.UNKNOWN
        }
        val provider = when {
            containsAny(name, sample, "marrow") -> "Marrow"
            containsAny(name, sample, "doctutorials", "doc tutorials", "doctutorial") -> "DocTutorials"
            containsAny(name, sample, "prepladder", "prep ladder") -> "PrepLadder"
            containsAny(name, sample, "dams") -> "DAMS"
            containsAny(name, sample, "cerebellum") -> "Cerebellum"
            containsAny(name, sample, "dbmci", "dnb") -> "DBMCI"
            containsAny(name, sample, "egurukul", "e-gurukul") -> "eGurukul"
            else -> "Imported"
        }
        val strategy = when {
            format == Format.APKG_OR_ZIP -> "separate APKG/ZIP import route required"
            format == Format.PDF -> "separate PDF import route required"
            format == Format.EPUB -> "EPUB/document adapter not yet connected"
            format == Format.JSON -> "native JSON/streaming parser"
            format == Format.HTML && sample.contains("srcdoc") -> "embedded-document adapter"
            format == Format.HTML -> "native HTML/JSON detection with compatibility fallback"
            else -> "format not yet identified"
        }
        return Detection(format, provider, strategy, if (provider != "Imported") 95 else if (format != Format.UNKNOWN) 80 else 25)
    }

    private fun containsAny(name: String, sample: String, vararg signatures: String): Boolean =
        signatures.any { name.contains(it) || sample.contains(it) }
}
