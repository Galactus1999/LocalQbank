package com.localqbank.library

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

/**
 * Six pinned, unchanged CC0 theme wallpapers. Decode the focal crop off-main-thread so a tall
 * phone gets near-native portrait detail without retaining six full 4K bitmaps in heap memory.
 */
object RovexBundledVisualAssets {
    private val loading = ConcurrentHashMap.newKeySet<String>()
    private fun cacheBudgetKb(): Int {
        val heapKb = Runtime.getRuntime().maxMemory() / 1024L
        return (heapKb / 12L).coerceIn(8L * 1024L, 32L * 1024L).toInt()
    }
    private val cache: LruCache<String, Bitmap> by lazy {
        object : LruCache<String, Bitmap>(cacheBudgetKb()) {
            override fun sizeOf(key: String, value: Bitmap): Int =
                (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    private fun resourceFor(theme: String): Int = when (theme) {
        ThemeManager.PASTEL -> R.drawable.rovex_wallpaper_pastel
        ThemeManager.MINT -> R.drawable.rovex_wallpaper_mint
        ThemeManager.SUNSET -> R.drawable.rovex_wallpaper_sunset
        ThemeManager.LAVENDER -> R.drawable.rovex_wallpaper_lavender
        ThemeManager.AMOLED -> R.drawable.rovex_wallpaper_amoled
        ThemeManager.PANDORA -> R.drawable.rovex_wallpaper_pandora
        ThemeManager.SPACE -> R.drawable.rovex_wallpaper_space
        else -> R.drawable.rovex_wallpaper_light
    }

    fun preload(context: Context) {
        bitmapIfReady(context, ThemeManager.get(context))
    }

    fun bitmapIfReady(context: Context, theme: String = ThemeManager.get(context)): Bitmap? {
        cache.get(theme)?.let { return it }
        val app = context.applicationContext
        if (!loading.add(theme)) return null
        PerformanceManager.submit {
            var decoded: Bitmap? = null
            try {
                val resource = resourceFor(theme)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeResource(app.resources, resource, bounds)
                if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                    val metrics = app.resources.displayMetrics
                    val targetAspect = metrics.widthPixels.toFloat() /
                        metrics.heightPixels.coerceAtLeast(1).toFloat()
                    val sourceAspect = bounds.outWidth.toFloat() / bounds.outHeight.toFloat()
                    val cropWidth: Int
                    val cropHeight: Int
                    if (sourceAspect > targetAspect) {
                        cropHeight = bounds.outHeight
                        cropWidth = (cropHeight * targetAspect).roundToInt().coerceIn(1, bounds.outWidth)
                    } else {
                        cropWidth = bounds.outWidth
                        cropHeight = (cropWidth / targetAspect).roundToInt().coerceIn(1, bounds.outHeight)
                    }
                    val focalX = bounds.outWidth / 2
                    val focalY = bounds.outHeight / 2
                    val left = (focalX - cropWidth / 2).coerceIn(0, bounds.outWidth - cropWidth)
                    val top = (focalY - cropHeight / 2).coerceIn(0, bounds.outHeight - cropHeight)
                    val region = Rect(left, top, left + cropWidth, top + cropHeight)
                    var sample = 1
                    val targetW = (metrics.widthPixels * 1.5f).toInt().coerceAtLeast(720)
                    val targetH = (metrics.heightPixels * 1.5f).toInt().coerceAtLeast(1280)
                    while (region.width() / sample > targetW ||
                        region.height() / sample > targetH ||
                        (region.width().toLong() / sample) * (region.height().toLong() / sample) * 4L >
                            cacheBudgetKb().toLong() * 1024L) {
                        sample *= 2
                    }
                    val stream = app.resources.openRawResource(resource)
                    val decoder = try {
                        BitmapRegionDecoder.newInstance(stream, false)
                            ?: error("Android could not create a wallpaper region decoder")
                    } finally {
                        stream.close()
                    }
                    try {
                        decoded = decoder.decodeRegion(
                            region,
                            BitmapFactory.Options().apply {
                                inSampleSize = sample
                                inPreferredConfig = Bitmap.Config.ARGB_8888
                            }
                        )
                    } finally {
                        decoder.recycle()
                    }
                }
                if (decoded != null) cache.put(theme, decoded!!)
            } catch (_: OutOfMemoryError) {
                // Decorative wallpaper must never take down foreground study.
                decoded?.recycle()
                decoded = null
            } catch (_: java.io.IOException) {
                decoded?.recycle()
                decoded = null
            } catch (_: RuntimeException) {
                decoded?.recycle()
                decoded = null
            } finally {
                loading.remove(theme)
            }
            Handler(Looper.getMainLooper()).post {
                if (ThemeManager.get(app) == theme && AppManagers.isReady()) {
                    AppState.changed("bundled_wallpaper_loaded:" + theme)
                } else if (ThemeManager.get(app) != theme) {
                    bitmapIfReady(app, ThemeManager.get(app))
                }
            }
        }
        return null
    }
}
