package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.view.View
import kotlin.math.max

/** Offline daily accuracy chart backed only by the user's saved answers. */
class TodayProgressGraphView(context: Context) : View(context) {
    private data class Point(val at: Long, val correct: Boolean)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private var fillShader: Shader? = null
    private var shaderWidth = 0
    private var shaderHeight = 0
    private var points: List<Point> = emptyList()

    fun setTodayProgress(records: List<Pair<Long, Boolean>>) {
        points = records.filter { it.first > 0L }.sortedBy { it.first }.takeLast(120).map { Point(it.first, it.second) }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shaderWidth = 0
        shaderHeight = 0
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val dark = ThemeManager.isDark(context)
        val accent = ThemeManager.accent(context)
        val accent2 = ThemeManager.accentSecondary(context)
        val left = 35f * d
        val right = max(left + 1f, width - 12f * d)
        val top = 13f * d
        val bottom = max(top + 1f, height - 27f * d)
        val plotWidth = right - left
        val plotHeight = bottom - top

        // Deliberate low-contrast grid with a stronger baseline; avoid the old cramped 76dp strip.
        grid.strokeWidth = 1f * d
        grid.color = if (dark) 0x443E526B else 0x332C4D83
        for (i in 0..4) {
            val y = bottom - plotHeight * i / 4f
            c.drawLine(left, y, right, y, grid)
        }
        label.textSize = 9f * d
        label.color = ThemeManager.muted(context)
        label.textAlign = Paint.Align.RIGHT
        c.drawText("100%", left - 7f * d, top + 3f * d, label)
        c.drawText("50%", left - 7f * d, top + plotHeight / 2f + 3f * d, label)
        c.drawText("0%", left - 7f * d, bottom + 3f * d, label)
        label.textAlign = Paint.Align.LEFT
        label.textSize = 8.5f * d
        c.drawText("START", left, height - 7f * d, label)
        label.textAlign = Paint.Align.RIGHT
        c.drawText("NOW", right, height - 7f * d, label)
        label.textAlign = Paint.Align.LEFT

        if (points.isEmpty()) {
            label.textSize = 11f * d
            label.color = ThemeManager.muted(context)
            c.drawText("Answer questions to reveal your trend", left + 3f * d, top + plotHeight / 2f, label)
            return
        }

        val values = ArrayList<Pair<Float, Float>>(points.size)
        var correct = 0
        val firstTime = points.first().at
        val lastTime = points.last().at
        val span = (lastTime - firstTime).coerceAtLeast(1L).toFloat()
        points.forEachIndexed { i, p ->
            if (p.correct) correct++
            val accuracy = correct * 100f / (i + 1)
            // Distribute sparse same-minute answers evenly so short sessions remain legible.
            val timeX = ((p.at - firstTime).toFloat() / span).coerceIn(0f, 1f)
            val fallbackX = if (points.size <= 1) 0.5f else i.toFloat() / (points.size - 1)
            val progress = if (lastTime - firstTime < 60_000L) fallbackX else timeX
            val x = left + plotWidth * progress
            val y = bottom - plotHeight * (accuracy / 100f).coerceIn(0f, 1f)
            values += x to y
        }

        val curve = Path().apply {
            moveTo(values.first().first, values.first().second)
            for (i in 1 until values.size) {
                val (x0, y0) = values[i - 1]
                val (x1, y1) = values[i]
                val mid = (x0 + x1) / 2f
                cubicTo(mid, y0, mid, y1, x1, y1)
            }
        }
        val area = Path(curve).apply {
            lineTo(values.last().first, bottom)
            lineTo(values.first().first, bottom)
            close()
        }
        if (shaderWidth != width || shaderHeight != height || fillShader == null) {
            fillShader = LinearGradient(0f, top, 0f, bottom, accent2 and 0x66FFFFFF, accent and 0x08FFFFFF, Shader.TileMode.CLAMP)
            shaderWidth = width
            shaderHeight = height
        }
        fill.shader = fillShader
        c.drawPath(area, fill)
        fill.shader = null

        line.color = accent
        line.strokeWidth = 2.8f * d
        line.setShadowLayer(3.5f * d, 0f, 1f * d, accent and 0x55000000)
        c.drawPath(curve, line)
        line.clearShadowLayer()
        values.forEachIndexed { i, (x, y) ->
            val radius = if (i == values.lastIndex) 4.5f * d else 2.8f * d
            dot.color = if (points[i].correct) accent2 else 0xFFFF6B91.toInt()
            c.drawCircle(x, y, radius + if (i == values.lastIndex) 2f * d else 0f, dot.apply { alpha = if (i == values.lastIndex) 42 else 28 })
            dot.alpha = 255
            c.drawCircle(x, y, radius, dot)
            if (i == values.lastIndex) {
                dot.color = if (dark) 0xFFFFFFFF.toInt() else 0xFFFDFEFF.toInt()
                c.drawCircle(x, y, 1.6f * d, dot)
            }
        }
    }
}
