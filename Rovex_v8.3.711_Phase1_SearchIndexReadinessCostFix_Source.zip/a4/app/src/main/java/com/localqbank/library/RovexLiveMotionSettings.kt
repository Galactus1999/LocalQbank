package com.localqbank.library

import android.content.Context

/** User-owned switch for animated wallpaper/background layers; tap feedback remains independent. */
object RovexLiveMotionSettings {
    private const val PREFS = "rovex_live_motion"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_SURFACE_FLOW = "surface_flow_enabled"
    fun enabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }
    fun surfaceFlowEnabled(context: Context): Boolean = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SURFACE_FLOW, true)
    fun setSurfaceFlowEnabled(context: Context, enabled: Boolean) { context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SURFACE_FLOW, enabled).apply() }
}
