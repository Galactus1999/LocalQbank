package com.localqbank.library

import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * One-shot bridge from callback-driven extraction back to the single import worker.
 * Completion is exactly-once, waits are bounded, and callback failures reach the worker.
 */
internal class DeferredImportGate<T>(
    private val timeout: Long = 120,
    private val timeoutUnit: TimeUnit = TimeUnit.SECONDS
) {
    private val latch = CountDownLatch(1)
    private val completed = AtomicBoolean(false)
    @Volatile private var value: T? = null
    @Volatile private var failure: Throwable? = null

    fun complete(result: T): Boolean {
        if (!completed.compareAndSet(false, true)) return false
        value = result
        latch.countDown()
        return true
    }

    fun fail(error: Throwable): Boolean {
        if (!completed.compareAndSet(false, true)) return false
        failure = error
        latch.countDown()
        return true
    }

    @Throws(TimeoutException::class)
    fun await(): T {
        if (!latch.await(timeout, timeoutUnit)) {
            throw TimeoutException("Import extraction timed out after $timeout $timeoutUnit")
        }
        failure?.let { throw IllegalStateException("Import extraction failed: ${it.message ?: it.javaClass.simpleName}", it) }
        @Suppress("UNCHECKED_CAST")
        return value ?: throw IllegalStateException("Import extraction completed without a result")
    }
}
