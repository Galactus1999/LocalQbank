# Rovex v8.3.694 — Large HTML import root-cause repair
Date: 2026-10-18

## Evidence from the supplied screenshot
The live importer reaches `LargeHtmlScanner.scan()`, recognizes the `paper_data` array name, and reports `0 valid questions`. This distinguishes the failure from file-picker handoff or an inability to find any array. The defect is downstream: the recognized array's contents are not being traversed/normalized into questions.

## Source-level root cause
In v8.3.693, `LargeHtmlScanner.parseTestObject()` only treats a narrow set of keys (`questions`, `items`, `question_list`, `question_data`, etc.) as question arrays. Any other value is sent to `skipValue(r)`. Nested container keys such as `paper_data`, `test_data`, `data`, `sections`, or `papers` therefore were consumed without inspecting their child question arrays. This is consistent with the screenshot's recognized `paper_data` plus zero normalized questions. The actual failing HTML was not attached, so the exact nesting shape remains unconfirmed.

## Repair
- Added a bounded recursive streaming walk for known nested question-container keys (`paper_data`, `test_data`, `data`, `sections`, `papers`, etc.).
- Preserved streaming object/array traversal; no whole-file JSON/HTML materialization was introduced.
- Added a depth limit of 8 to avoid pathological recursive nesting.
- Added regression test `nestedPaperDataContainerEmitsQuestionsInsteadOfReportingZero` for a nested `paper_data -> sections -> questions` fixture.
- Bumped versionName to 8.3.694 and versionCode to 780.

## Research basis
- Android `JsonReader` is token-stream based and intended for incremental traversal of JSON structures: https://developer.android.com/reference/android/util/JsonReader
- Android documents that `OpenableColumns.SIZE` can be null when the provider cannot determine size: https://developer.android.com/reference/android/provider/OpenableColumns
- WebView runs in Chromium/native code and has meaningful baseline memory cost; large-file fallback should remain bounded and not be used as the primary large-file parser: https://developer.android.com/develop/ui/views/layout/webapps/webview

## Verification status
- Static source checks: completed for recursive key dispatch, recursion bound, regression-test presence and version metadata.
- ZIP integrity: checked after packaging.
- Full Gradle/JUnit run: not completed in this environment; Gradle distribution access may be network-blocked.
- Real failing HTML fixture and 60–180 MB device import: not supplied/not verified. The screenshot supports the failure boundary but cannot establish the exact nested schema.
- CI/device status: pending; do not call the build green until the exact archive passes the full workflow and real-file fixture.
