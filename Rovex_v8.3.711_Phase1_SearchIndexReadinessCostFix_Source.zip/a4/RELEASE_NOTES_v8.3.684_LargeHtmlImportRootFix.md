# v8.3.684 — Large HTML Import Root-Cause Repair

- Version: `8.3.684`
- versionCode: `770` (monotonic bump from v8.3.683 / 769)
- Package remains `com.localqbank.library`.
- Baseline: `Rovex_v8.3.683_DAMS_AssignmentBoundaryFix_Source.zip`
  - SHA-256: `a5e77cee87dc48c0a27e94376af6cf7af07911f3e93185c8237efa71b14d378f`

## GitHub source-history comparison

Compared the v8.3.678, v8.3.681, v8.3.682 and v8.3.683 source archives in `Galactus1999/LocalQbank`.

- v8.3.678 established a read-only large-file preflight before database replacement and guarded against an empty successful import.
- v8.3.682 introduced alias-by-alias candidate selection to prioritize `TESTS_LIST` over generic arrays. However, it only inspected the **first assignment** for each alias. If that assignment was an empty runtime array or metadata-only array, the scanner never examined a later assignment with the same alias; it fell through to other aliases and could reread the entire file many times.
- v8.3.683 adjusted JavaScript declaration-boundary recognition, but did not correct the first-assignment masking behavior.

## Changes

- `LargeHtmlScanner` now continues scanning for later assignments of the same alias when an earlier matching array yields zero normalized questions. Alias priority is preserved.
- The scanner still streams question-by-question; it does not load the entire HTML file or question array into memory.
- Large-file preflight progress now reports the alias currently being searched or parsed, plus the count of valid questions discovered.
- A zero-question preflight error includes content-free diagnostics: how many candidate arrays were recognized, their names, and the normalized question count. Existing QBank data is still not replaced when preflight emits zero questions.
- Added regression tests for an empty first `TESTS_LIST` followed by a valid `TESTS_LIST`, and metadata-only first `QUESTIONS_DATA` followed by a valid `QUESTIONS_DATA`. Updated the source-level transaction-order regression test to match the named preflight scanner and verify diagnostics are surfaced.

## Validation status

- Source diff/static inspection: performed.
- Version/app-id invariants: checked in source (`com.localqbank.library`, versionCode 770, versionName 8.3.684).
- Gradle unit test: **blocked before test execution** because the environment could not resolve `downloads.gradle.org` while attempting to download Gradle 9.3.1. No test-pass claim is made.
- Full Android build, release CI, APK/signature checks, and actual 60–180 MB device import: **not verified**.
- The exact 60–180 MB HTML file that fails on-device was not available in the current working set. This repair addresses a demonstrated scanner defect, but confirmation that it is the user's specific export root cause requires that exact fixture or a device run with diagnostics.

## Online engineering guidance

Android's official `android.util.JsonReader` API documents token-by-token streaming of JSON values, including `beginArray`, `beginObject`, `hasNext`, and `skipValue`; this is the appropriate design direction for bounded-memory parsing rather than building a whole-document object tree. See https://developer.android.com/reference/android/util/JsonReader. Android's Storage Access Framework also supports document-provider URIs and streaming through `ContentResolver.openInputStream`; providers may have different underlying behavior, so the staging copy must remain bounded and checked. See https://developer.android.com/training/data-storage/shared/documents-files.
