# Rovex v8.3.690 — Theme Contrast Foundation, Phase 4

- Version code: 776
- Baseline: v8.3.689 / versionCode 775
- Application ID preserved: `com.localqbank.library`

## Root-cause finding
The shared `ThemeManager.onAccent()` selected white or dark text using an approximate weighted average of un-linearized RGB channels and a fixed threshold. That is not the WCAG relative-luminance/contrast calculation and can select the lower-contrast foreground for some accent colours. Several accent-filled controls also bypassed the shared helper and hardcoded white text.

## Changes
- Added `RovexContrastPolicy`, a pure Kotlin WCAG 2.x sRGB relative-luminance and contrast-ratio helper.
- Routed `ThemeManager.onAccent()` through the contrast-maximizing policy and exposed `ThemeManager.onColor(fill)` for dynamic fills.
- Updated the Imported QBanks import action, Study Tools FIND QUESTIONS action, Ben Model Lab actions, Diagnostics actions, and flashcard study buttons to choose a foreground from the actual fill rather than assume white is readable.
- Added unit tests asserting at least 4.5:1 contrast for every configured theme accent and representative light/dark fills.
- No database, import, QBank ownership, SRS scheduling, inference, backup, or signing behaviour intentionally changed.

## Verification classification
- Source review: performed for changed functions; see `ROVEX_THEME_CONTRAST_PHASE4_AUDIT.md`.
- Kotlin unit test execution: not yet verified until a real Gradle test result is available.
- Android build/CI/device screenshots: not implied by this source patch; report actual results separately.
