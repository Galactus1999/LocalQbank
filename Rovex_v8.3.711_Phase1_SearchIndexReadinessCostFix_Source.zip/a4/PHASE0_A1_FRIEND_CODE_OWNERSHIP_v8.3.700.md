# Phase 0 A1 — Friend-code ownership hardening

Base: `Rovex_v8.3.699_MinimalHome_Source.zip` (repository artifact)
Target: v8.3.700 / versionCode 786

## Root cause
The previous `friendCodes/{code}` rule combined create and update and checked only that the incoming `uid` matched the caller. On update, it did not bind the existing document owner to the caller, so a caller could attempt to overwrite a code already owned by another user.

## Repair
- Split create/update/delete rules.
- Restrict codes to `RVX-XXXX-XXXX` uppercase alphanumeric format.
- Restrict document fields to `uid` and `displayName`, require both, validate owner uid and displayName length.
- On update, require existing owner == caller and immutable uid binding; permits legitimate display-name refresh used by `RovexOnlineRepository.ensureIdentityProfile`.
- Client reads remain denied; recipient mailbox rules continue resolving ownership server-side.
- Added Firebase Rules Emulator tests for unauthenticated creation, valid self-creation, cross-user overwrite, owner display-name refresh, uid mutation, malformed fields/code, unauthorized delete and client read denial.

## Verification
Static rule/source review only in this patch generation. Emulator tests require `npm install` and Firebase Emulator execution and have not yet been run. Android build/CI/device verification is pending.
