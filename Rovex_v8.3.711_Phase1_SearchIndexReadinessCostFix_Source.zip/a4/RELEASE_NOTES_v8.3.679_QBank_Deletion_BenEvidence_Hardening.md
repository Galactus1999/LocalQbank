# Rovex v8.3.679 — QBank Deletion and Ben Evidence Hardening

## Base
- Derived from the patched Rovex Adaptive Android CI #1305 source baseline (v8.3.677 / versionCode 763), including the previously applied compact quiz-header and large-HTML empty-import safeguards.
- Version advanced to v8.3.679 / versionCode 765 to avoid reusing a prior local artifact's version label.

## QBank deletion
- Added ownership-aware cleanup for legacy `sourceName:<display-name>:resume` metadata. The key is deleted only when its stored test belongs to the source being reset/deleted; source-ID-scoped resume metadata remains canonical.
- Made `search_index_meta.garbage_pending=1` durable in the same transaction as the deletion tombstone, both for explicit user deletion and physical deletion/recovery paths.
- Preserved bounded question deletion, the existing write coordinator, resumable recovery, and deferred incremental/idle FTS maintenance.

## Ben+AI
- Replaced rank-implies-answer/distractor role names with candidate/contrastive roles. Lower-ranked records are not called distractors merely because of rank; the default bounded candidate set includes up to eight records.
- Updated the evidence pack and prompt to state that retrieved QBank text is untrusted data, ranking is not proof of support, and only supplied citation IDs may be used.
- Added a conservative lexical citation/source linkage gate. This is a minimum mismatch detector, not a semantic entailment or clinical fact checker; verifier fallback remains authoritative.
- Added unit regression tests for candidate role assignment and relevant/irrelevant citation linkage.

## Verification
- Static source checks and ZIP integrity should be run before distribution.
- Android Gradle compilation, unit test execution, CI, signing certificate, and device stress tests must be reported separately and are not assumed to pass from source inspection.

## Local validation record
- `tools/phase0_offline_gate.py`: PASS after correcting stale source-path assumptions in the gate and narrowing the wallpaper rollback catch to `Exception` plus `Error` while preserving rollback behavior.
- Focused Kotlin compile of the evidence planner, evidence pack, verifier, and progress-metadata ownership helper with Android/API stubs: PASS (only existing unused-parameter warnings in verifier).
- Focused smoke runner: PASS for eight-candidate retention, rank-not-distractor semantics, source-name resume-key ownership, and relevant/irrelevant citation linkage.
- `./gradlew --offline testDebugUnitTest`: BLOCKED before configuration because the wrapper attempted to download Gradle 9.3.1 and `downloads.gradle.org` DNS resolution failed. Full Android compile, full JUnit/instrumented tests, CI, release signing, and device tests remain unverified.
