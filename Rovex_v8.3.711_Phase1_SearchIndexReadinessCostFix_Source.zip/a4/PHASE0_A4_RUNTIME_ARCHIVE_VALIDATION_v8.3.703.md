# Phase 0 A4 — LiteRT Qualcomm runtime archive validation (v8.3.703)

## Confirmed defect
`tools/prepare_litert_qualcomm_v75_jit.sh` treated any non-empty cached archive as reusable. A truncated/interrupted archive could persist in the build cache and repeatedly fail extraction instead of being invalidated and re-downloaded.

## Repair
- Validate ZIP CRC/structure with `unzip -tq` before extraction.
- Require the expected `fetch_qualcomm_library.sh` and v75 arm64 runtime member paths.
- Download to a temporary `.download` file and atomically move into cache only after a non-empty download.
- Validate a fresh download before extraction; delete it and fail closed if validation fails.
- Bumped app version to 8.3.703 / versionCode 789.

## Verification
- `bash -n tools/prepare_litert_qualcomm_v75_jit.sh`: PASS.
- `node --check functions/index.js`: PASS.
- `node --check firestore-tests/firestore.rules.test.js`: PASS.
- Existing `tools/ruthless_audit.sh`: FAIL due to an existing production `Thread.sleep()` in `QuizQuestionLoader.kt:40`; this pass did not silently suppress or rewrite that retry behavior. XML and MainActivity layout ID checks in the same audit passed.
- No 2.35 GB LiteRT/QAIRT download was attempted; archive-cache behavior was not exercised against the actual vendor asset.
- Android Gradle compilation, unit tests, GitHub Actions, Firebase emulator, deployment, and device runtime are NOT verified.

## Supply-chain limitation
This change validates ZIP structure and expected members; it does **not** provide cryptographic provenance or a pinned SHA-256 for the LiteRT release asset or the nested Qualcomm fetch script. Do not interpret ZIP CRC checks as protection against a malicious but well-formed archive. Before enabling a strict hash pin, obtain an authoritative digest/signature for the exact release asset and document its provenance. The downloaded helper remains a residual supply-chain risk.
