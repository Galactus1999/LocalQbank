const { onDocumentCreatedWithAuthContext, onDocumentCreated, onDocumentDeleted } = require("firebase-functions/v2/firestore");
const { setGlobalOptions } = require("firebase-functions/v2");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
setGlobalOptions({ maxInstances: 4, timeoutSeconds: 30 });
const db = getFirestore();

const EVENT_XP = Object.freeze({ quiz_completed: 10, flashcard_reviewed: 5 });
// Correctness is client-supplied and cannot be verified against a trusted server question bank.
// Do not award correctness bonus/counts from it. Server UTC-day ceilings bound event spam.
const DAILY_LIMITS = Object.freeze({ quiz_completed: 300, flashcard_reviewed: 1000 });
const VALID_SOURCES = new Set(["quiz", "flashcards"]);

/**
 * Server-authoritative competitive progress.
 * The Android client can submit immutable study events, but cannot write the aggregate counters.
 * Firestore triggers may retry, so event processing is idempotent inside one transaction.
 */
exports.acceptStudyEvent = onDocumentCreatedWithAuthContext(
  "studyEvents/{userId}/events/{eventId}",
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const uid = event.params.userId;
    // Firestore Security Rules already guarantee that only the authenticated uid can create
    // this path. Auth-context identifiers can be unavailable/unknown in some trigger paths,
    // so do not make legitimate events depend on a fragile authId mapping. Reject only explicit
    // non-user/system principals here.
    if (["unauthenticated", "api_key", "service_account", "system"].includes(event.authType)) {
      await snap.ref.set({ accepted: false, rejection: "NON_USER_PRINCIPAL", processedAt: FieldValue.serverTimestamp() }, { merge: true });
      return;
    }

    const data = snap.data() || {};
    const type = data.type;
    const operationId = event.params.eventId;
    if (data.operationId !== operationId ||
        !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(operationId) ||
        !Object.prototype.hasOwnProperty.call(EVENT_XP, type) || data.uid !== uid ||
        typeof data.source !== "string" || !VALID_SOURCES.has(data.source) ||
        (data.stableKeyHash !== undefined &&
          (typeof data.stableKeyHash !== "string" || !/^[a-f0-9]{24}$/.test(data.stableKeyHash))) ||
        (data.clientTimestamp !== undefined &&
          (!Number.isFinite(data.clientTimestamp) || data.clientTimestamp < 0))) {
      await snap.ref.set({ accepted: false, rejection: "INVALID_EVENT", processedAt: FieldValue.serverTimestamp() }, { merge: true });
      return;
    }

    const profileRef = db.collection("users").doc(uid);
    const dayKey = new Date().toISOString().slice(0, 10); // server UTC day; ignore client time for quotas
    const quotaRef = db.collection("studyEventQuotas").doc(uid).collection("days").doc(dayKey);
    await db.runTransaction(async (tx) => {
      // Reads and writes are in one transaction: trigger retries cannot double-increment quota or XP.
      const eventSnap = await tx.get(snap.ref);
      if (eventSnap.get("processedAt")) return;
      const quotaSnap = await tx.get(quotaRef);
      const quota = quotaSnap.exists ? quotaSnap.data() : {};
      const used = Number(quota[type] || 0);
      if (!Number.isSafeInteger(used) || used < 0 || used >= DAILY_LIMITS[type]) {
        tx.update(snap.ref, { accepted: false, rejection: "DAILY_LIMIT", processedAt: FieldValue.serverTimestamp() });
        return;
      }
      const profileSnap = await tx.get(profileRef);
      const current = profileSnap.exists ? profileSnap.data() : {};
      const attempted = Number(current.questionsSolved || 0) + (type === "quiz_completed" ? 1 : 0);
      const correctCount = Number(current.correct || 0); // never trust client-supplied correctness
      const flashcards = Number(current.flashcardsReviewed || 0) + (type === "flashcard_reviewed" ? 1 : 0);
      const xp = Number(current.xp || 0) + EVENT_XP[type]; // fixed award; no forged correctness bonus
      const accuracy = attempted > 0 ? Math.floor((correctCount * 100) / attempted) : 0;
      const todaySolved = Number(current.todaySolved || 0) + (type === "quiz_completed" ? 1 : 0);

      tx.set(quotaRef, { [type]: used + 1, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
      tx.set(profileRef, {
        uid, questionsSolved: attempted, correct: correctCount,
        accuracyPercent: Math.min(100, accuracy), todaySolved,
        flashcardsReviewed: flashcards, xp, updatedAt: FieldValue.serverTimestamp(),
      }, { merge: true });
      tx.update(snap.ref, { accepted: true, correctnessVerified: false, processedAt: FieldValue.serverTimestamp() });
    });
  }
);


