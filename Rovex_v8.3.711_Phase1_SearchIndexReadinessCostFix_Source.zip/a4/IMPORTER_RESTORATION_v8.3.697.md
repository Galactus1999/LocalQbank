# Rovex v8.3.697 — v8.3.299 Importer Compatibility Restoration

Date: 2026-10-18

## Provenance

The v8.3.299 source archive was recovered from the historical public repository commit `eb5144f90b8c33066488ee2828ba017083d6da57` (`Rovex_v8.3.299_Offline_ModernUI_Phase_Source.zip`). The recovered archive SHA-256 is `731c4484b708ba28f99373cd0231ec38129eaaf6341c7d81c795ad48876a4ed6`, matching the checksum recorded with the archived source.

## Change

- Added `LegacyLargeHtmlScannerV8299.kt`, copied from the v8.3.299 `LargeHtmlScanner.kt` implementation with only the class name and descriptive comment changed so both implementations can coexist.
- Restored the v8.3.299 scanner as the first-pass parser for large HTML files.
- Kept the newer adaptive `LargeHtmlScanner` as the fallback when the legacy parser throws or emits zero normalized questions.
- The exact parser that passes read-only preflight is used for the actual transactional write. The preflight count and written count must match.
- If neither streaming parser finds valid questions, the bounded compatibility fallback is still available for files within its existing size limit; larger files fail clearly without replacing the existing QBank.
- Preserved existing source identity, streaming transaction, abort/rollback, count-mismatch rejection, staged-file cleanup, and zero-question rejection protections.
- Added `LegacyLargeHtmlScannerV8299RegressionTest` with a combined `TESTS_LIST` fixture.
- Version bumped to `8.3.697`, `versionCode = 783`.

## Verification

- Exact v8.3.299 source archive hash verified.
- Legacy scanner Kotlin syntax/type-shape check passed using temporary API stubs for Android's JSON classes and the imported-question model. This is a syntax check only, not an application build.
- `HtmlImportActivity.kt` parsed without Kotlin syntax errors; full type resolution was unavailable without the Android/project classpath.
- 37 XML files parsed; no duplicate `@+id` values were found within any individual layout XML.
- Source-level invariants confirmed: positive preflight required before database replacement; streaming session abort remains present; count mismatch remains fatal; version is 8.3.697 / 783.
- `./gradlew :app:testDebugUnitTest --no-daemon --stacktrace` was attempted but stopped before Gradle startup because DNS could not resolve `downloads.gradle.org`. JUnit, Android compilation, CI, and device import remain unverified.

## Limitation

The original failing HTML was not supplied. This restoration therefore provides a compatibility path based on the user-confirmed v8.3.299 parser, but does not prove that the screenshot's specific file now imports. The decisive test remains importing that exact file and confirming the expected question count and database integrity.
