# Rovex v8.3.705 — Phase 0 A6/A7 WebView and R8 release-contract audit

## Scope and provenance
- Starting source: supplied v8.3.704 source archive, SHA-256 recorded separately by its source artifact.
- Package/applicationId: `com.localqbank.library`.
- Version: `8.3.705`, versionCode `791`.
- This is a source-level audit/guardrail update. It is not an Android build or device validation.

## Confirmed observations
1. `HtmlImportActivity` does not call `addJavascriptInterface`; the extracted result is read with `evaluateJavascript`.
2. `HtmlImportActivity` blocks top-level navigation in `shouldOverrideUrlLoading`, disables file-origin cross-access and universal access, blocks mixed content, disables cookies, and enables Safe Browsing where supported.
3. The HTML importer still enables JavaScript and `allowFileAccess`/`allowContentAccess` while processing user-selected HTML using the selected URI as `loadDataWithBaseURL`'s base URL. This is compatibility-sensitive because relative resources and legacy exports may depend on the selected URI. Do not declare the WebView fully isolated: a scheme-aware redesign plus hostile HTML regression fixtures is still required before tightening those permissions safely.
4. `FlashcardStudyActivity` retains one native JavaScript bridge, `RovexImages`, with only `reveal()` and `open(src)`. `open` delegates to `FlashcardImageUriPolicy.validatePreviewSource`; the card HTML is sanitized to remove scripts, iframes, inline event handlers, and `javascript:`. This narrows exposure but does not prove the sanitizer is a complete HTML security boundary. A bridge replacement requires an origin-aware messaging design and device compatibility tests.
5. `app/build.gradle.kts` had no explicit minification/shrinking settings in the release block. R8 is therefore not enabled by this patch. Release now explicitly sets `isMinifyEnabled = false` and `isShrinkResources = false` pending a proper signed-release matrix.
6. A source scan found `Class.forName` in `StartupHealthChecker.kt` for manifest activity health checks. Android manifest-declared Activity classes are generally kept as components by AGP, but that assumption must be confirmed from the generated R8 mapping/usage output after a minified build. No broad keep rule was added speculatively.
7. The source archive does not contain staged `app/src/main/jniLibs` Qualcomm `.so` files. The project expects a build-time staging script; a successful build must prove required native payloads are actually packaged.

## Changes in v8.3.705
- Explicitly hold release minification and resource shrinking off until reflection/JNI/native inference compatibility is tested on the canonical signed APK.
- Add `Phase0SecurityBuildContractSourceTest` source-contract tests to prevent accidental reintroduction of the HTML import JavaScript bridge and loss of key WebView restrictions, and to keep release optimization disabled until the validation gate is satisfied.
- Bump versionName/versionCode to 8.3.705/791.

## Checks executed
- `node --check functions/index.js`: pass.
- `node --check firestore-tests/firestore.rules.test.js`: pass.
- `bash -n tools/prepare_litert_qualcomm_v75_jit.sh`: pass.
- Main-source XML parsing: 37 files, pass.
- Duplicate IDs within individual XML files: none found.
- ZIP integrity: checked separately after packaging.

## Not executed / not claimed
- Kotlin/JUnit compilation or execution: not run.
- Android Gradle compilation: not run.
- GitHub Actions canonical release workflow: not run.
- Firebase emulator tests/deployment: not run.
- R8/minified release build: intentionally not enabled or run.
- WebView hostile-input/device tests: not run.
- Physical device validation: not run.
- No source changes pushed to GitHub.

## Remaining acceptance gates
- Scheme-aware WebView isolation for imported HTML without regressing relative media resolution.
- Replace/contain flashcard JavaScript bridge with origin-restricted messaging if compatible; otherwise retain strict sanitization and test all exposed methods against adversarial HTML.
- Obtain authoritative digest/provenance for LiteRT and nested Qualcomm artifacts before executing downloaded scripts.
- Run Firestore and Functions emulator tests.
- Build and install the canonical signed APK, verify signing fingerprint and required Zstd/native payload, then run importer/flashcard/AI smoke and regression tests.
