# v8.3.693 — Home progress geometry CI fix

Date: 2026-10-18

## Root cause
The v8.3.692 Home graph was increased to 136dp, but the existing instrumented geometry contract caps `rovex_home_today_progress` at 225dp. The rendered card measured 266.7dp on the CI emulator and failed `RovexHomeCompactGeometryRegressionTest.primaryHomeCardsStayCompactAndMotivationUsesStableTypography`.

## Correction
- Reduced the graph plot to 96dp (still taller than the prior 76dp strip), preserving a more legible chart while allowing the card to meet its compact-height contract.
- Tightened graph top spacing from 8dp to 6dp and button top spacing from 6dp to 5dp.
- Bumped versionName to 8.3.693 and versionCode to 779.
- Kept the existing test threshold; did not weaken or disable the test.

## Verification
- Source-level assertions: graph layout uses 96dp and version metadata is 8.3.693 / 779.
- CI log root cause: actual measured progress card height was 266.7dp against 225dp maximum.
- Full Gradle build and instrumented test rerun: NOT RUN here. Submit this source to CI before claiming the failure is resolved.
