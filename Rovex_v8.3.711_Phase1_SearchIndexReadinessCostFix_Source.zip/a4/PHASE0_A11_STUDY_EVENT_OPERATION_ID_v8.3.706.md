# Phase 0 A11 — Study event operation ID

- Adds an immutable UUID operationId to each StudyEventSpine.Event instance.
- Uses that ID as the Firestore event document ID and includes it in the payload.
- Firestore rules require operationId to equal the path ID and deny event updates/deletes.
- Cloud Function validates operationId/path consistency before processing.
- Adds a static contract test for retry identity behavior.

## Important limitation
This closes duplicate counting when the same Event instance is resubmitted, including retries that reuse the same in-memory event object. The operation ID is not yet durably persisted in a local outbox, so reconstructing the same logical operation as a new Event after process death still generates a new ID. Do not claim crash/restart-safe logical-operation deduplication until a durable outbox is implemented and tested. Historical XP is not modified.
