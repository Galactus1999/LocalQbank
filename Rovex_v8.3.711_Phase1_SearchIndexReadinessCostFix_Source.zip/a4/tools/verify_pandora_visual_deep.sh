#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
THEME="$ROOT/app/src/main/java/com/localqbank/library/ThemeManager.kt"
SETTINGS="$ROOT/app/src/main/java/com/localqbank/library/SettingsScreen.kt"
BACKDROP="$ROOT/app/src/main/java/com/localqbank/library/RovexPremiumHomeBackdropDrawable.kt"
MOTION="$ROOT/app/src/main/java/com/localqbank/library/RovexAmbientMotionDrawable.kt"
LIFECYCLE="$ROOT/app/src/main/java/com/localqbank/library/RovexAmbientMotionLifecycle.kt"
PROFILE="$ROOT/app/src/main/java/com/localqbank/library/RovexThemeProfile.kt"
LOAD="$ROOT/app/src/main/java/com/localqbank/library/QBankLoadingEngine.kt"
DB="$ROOT/app/src/main/java/com/localqbank/library/QBankDb.kt"
BUILD="$ROOT/app/build.gradle.kts"
fail(){ echo "FAIL: $*" >&2; exit 1; }

# Theme tokens were consolidated into RovexThemeProfile and the settings swatch now reads
# the profile rather than duplicating literal RGB values. Assert the current single source of truth.
grep -Fq 'ThemeManager.PANDORA -> RovexThemeProfile(' "$PROFILE" || fail 'Pandora theme profile missing'
grep -Fq '0xFF020717.toInt(), 0xFF071A2F.toInt(), 0xFF19082B.toInt()' "$PROFILE" || fail 'Pandora background palette missing'
grep -Fq '0xFF071727.toInt(), 0xFF0B2130.toInt(), 0xFF46EBFF.toInt(), 0xFFCD52FF.toInt()' "$PROFILE" || fail 'Pandora panel/accent palette missing'
grep -Fq '0xFFF1F7FF.toInt(), 0xFF97B7D5.toInt()' "$PROFILE" || fail 'Pandora text contrast palette missing'
grep -Fq 'ThemeManager.PANDORA to "Pandora • Living World"' "$SETTINGS" || fail 'Pandora settings theme entry missing'
grep -Fq 'RovexThemeProfile.forKey(key).backgroundA' "$SETTINGS" || fail 'Settings swatch no longer follows the authoritative theme profile'

# The old per-theme terrain renderer was replaced by a static premium backdrop plus a
# separate lifecycle-gated ambient-motion drawable. Validate the current architecture, not retired helper names.
grep -Fq 'class RovexPremiumHomeBackdropDrawable' "$BACKDROP" || fail 'Production static backdrop missing'
grep -Fq 'override fun draw(canvas: Canvas)' "$BACKDROP" || fail 'Static backdrop draw path missing'
grep -Fq 'paint.shader = LinearGradient' "$BACKDROP" || fail 'Layered backdrop gradients missing'
! grep -Fq 'scheduleSelf(' "$BACKDROP" || fail 'Static backdrop unexpectedly schedules continuous redraws'
grep -Fq 'private val frame = Runnable' "$MOTION" || fail 'Ambient motion frame runnable missing'
grep -Fq 'scheduleSelf(frame, SystemClock.uptimeMillis() + 125L)' "$MOTION" || fail 'Ambient motion frame cap missing'
grep -Fq 'unscheduleSelf(frame)' "$MOTION" || fail 'Ambient motion does not unschedule hidden frames'
grep -Fq 'if (!active)' "$MOTION" || fail 'Ambient motion foreground stop path missing'
grep -Fq 'WeakHashMap<RovexAmbientMotionDrawable, Boolean>' "$LIFECYCLE" || fail 'Lifecycle registry does not weakly reference drawables'
grep -Fq 'drawable.setAppForeground(foreground)' "$LIFECYCLE" || fail 'Foreground lifecycle state is not applied to new drawables'

python3 - "$LOAD" <<'PY'
import sys
from pathlib import Path
p=Path(sys.argv[1]); s=p.read_text()
start=s.index('fun loadSectionBundle')
end=s.index('fun warmSource', start)
block=s[start:end]
if 'if (cacheEpoch.get() == epoch)' not in block:
    raise SystemExit('FAIL: bundle epoch guard missing')
# The callback must be lexically inside the epoch guard. For this compact function, require the
# first callback occurrence to be contained in the guard block and reject an unconditional sibling.
guard=block.index('if (cacheEpoch.get() == epoch)')
cb=block.index('onLoaded(bundle)')
if cb < guard or 'onLoaded(bundle)' not in block[guard:]:
    raise SystemExit('FAIL: stale bundle callback escapes epoch guard')
print('PASS: stale section-bundle callback cannot repaint an invalidated epoch')
PY

current_version="$(sed -n 's/^[[:space:]]*versionCode[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$BUILD" | head -n1)"
[[ "$current_version" =~ ^[1-9][0-9]*$ ]] || fail 'valid monotonically increasing versionCode missing'
grep -Eq 'versionName = "[0-9]+\.[0-9]+\.[0-9]+"' "$BUILD" || fail 'semantic versionName missing'
grep -Fq 'sourceNameForId = { id -> sourceNameForId(id) }' "$DB" || fail 'restored sourceNameForId provider wiring missing'

echo 'PANDORA_VISUAL_DEEP_AUDIT=PASS'
