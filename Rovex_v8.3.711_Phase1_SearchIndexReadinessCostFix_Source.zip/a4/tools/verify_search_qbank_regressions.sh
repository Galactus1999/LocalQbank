#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EXP="$ROOT/app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt"
SEARCH="$ROOT/app/src/main/java/com/localqbank/library/SearchActivity.kt"
DB="$ROOT/app/src/main/java/com/localqbank/library/QBankSearchRepository.kt"
PROGRESS="$ROOT/app/src/main/java/com/localqbank/library/ProgressStore.kt"
INDEX="$ROOT/app/src/main/java/com/localqbank/library/QBankSearchIndexCoordinator.kt"
INDEX_TEST="$ROOT/app/src/androidTest/java/com/localqbank/library/QBankDbSearchRegressionTest.kt"
NAV="$ROOT/app/src/main/java/com/localqbank/library/QuizNavigationUseCase.kt"
MARK="$ROOT/app/src/main/java/com/localqbank/library/RenActivity.kt"
fail(){ echo "FAIL: $*" >&2; exit 1; }
grep -Fq 'private val localSearch by lazy { LocalQBankSearchService(app) }' "$EXP" || fail "Frankenstein local search owner missing"
grep -Fq 'if (localSearchCommand) {' "$EXP" || fail "Frankenstein deterministic search lane missing"
grep -Fq 'localSearch.search(command, 100' "$EXP" || fail "Frankenstein not using shared retrieval"
grep -Fq 'localSearch.searchSections(text, 60)' "$SEARCH" || fail "Main Search hierarchy retrieval missing"
grep -Fq 'localSearch.search(text, 300).hits' "$SEARCH" || fail "Main Search question retrieval missing"
grep -Fq 'verifiedContract == VERIFIED_INDEX_CONTRACT' "$INDEX" || fail "steady-state readiness no longer uses the persisted verification contract"
grep -Fq 'if (dirtyState != "0")' "$INDEX" || fail "missing/dirty index metadata no longer fails closed"
grep -Fq 'legacyCleanIndexIsAuditedOnceThenUsesPersistedVerificationContract' "$INDEX_TEST" || fail "legacy index one-time audit regression missing"
grep -Fq 'partialLegacyCleanIndexFailsClosedAndIsNotMarkedVerified' "$INDEX_TEST" || fail "partial index fail-closed regression missing"
grep -Fq 'missingDirtyMarkerFailsClosedInsteadOfAssumingIndexIsClean' "$INDEX_TEST" || fail "missing metadata regression missing"
grep -Fq 'maintenanceRebuildsWhenDirtyMetadataIsMissing' "$INDEX_TEST" || fail "missing metadata repair regression missing"
grep -Fq 'dirtyMarkerOverridesPreviouslyVerifiedContract' "$INDEX_TEST" || fail "dirty marker precedence regression missing"
grep -Fq 'WHERE ${clauses.joinToString(" OR ")}' "$DB" || fail "Section search still uses AND-only recall"
grep -Fq 'require(count > 0) { "This QBank subsection contains no importable questions." }' "$NAV" || fail "Sub-QBank validation missing"
grep -Fq 'RovexMarkdownBody' "$MARK" 2>/dev/null || true
grep -Fq 'rovexMarkdownBody(msg' "$MARK" || fail "Frankenstein rich Markdown body rendering missing"
echo 'PASS: Frankenstein deterministic local search lane'
echo 'PASS: Main Search shared question + hierarchy retrieval'
echo 'PASS: QBank/sub-QBank OR recall'
echo 'PASS: search-index readiness uses one-time integrity audit and fail-closed metadata contract'
echo 'PASS: subsection launch validates question-bearing QBank before progress mutation'
echo 'PASS: Frankenstein WebView rich Markdown/table rendering path present'
