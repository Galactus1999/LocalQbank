#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REN="$ROOT/app/src/main/java/com/localqbank/library/RenActivity.kt"
SEARCH="$ROOT/app/src/main/java/com/localqbank/library/SearchActivity.kt"
SERVICE="$ROOT/app/src/main/java/com/localqbank/library/LocalQBankSearchService.kt"
QUIZ="$ROOT/app/src/main/java/com/localqbank/library/QuizActivity.kt"
LIFE="$ROOT/app/src/main/java/com/localqbank/library/QuizSessionLifecycleController.kt"
PROGRESS="$ROOT/app/src/main/java/com/localqbank/library/ProgressStore.kt"

fail(){ echo "FAIL: $*" >&2; exit 1; }

grep -Fq 'headerButton("CLEAR",58){clearChatHistory()}' "$REN" || fail "Frankenstein CLEAR control missing"
grep -Fq 'AppManagers.renMemory.clearChatContext()' "$REN" || fail "Frankenstein durable chat clear missing"
grep -Fq 'chatTurns.clear()' "$REN" || fail "Frankenstein UI chat clear missing"
! grep -Fq 'quizViewModel.persistSessionCursor()' "$QUIZ" || fail "QuizActivity still promotes QBank open to Continue cursor"
! grep -Fq 'viewModel.persistSessionCursor()' "$LIFE" || fail "QuizSessionLifecycleController still promotes onPause to Continue cursor"
grep -Fq 'putProgressMeta("last_solved_global"' "$PROGRESS" || fail "Answer resume checkpoint missing"
grep -Fq 'beginProgressMetaTransaction(resumeTestId, nextPosition' "$PROGRESS" || fail "Answer resume position checkpoint missing"
grep -Fq 'fun searchSections(' "$SERVICE" || fail "Shared search service lacks hierarchy retrieval"
grep -Fq 'localSearch.searchSections(text, 60)' "$SEARCH" || fail "Main Search does not use authoritative hierarchy retrieval"
grep -Fq 'localSearch.search(text, 300)' "$SEARCH" || fail "Main Search does not use authoritative question retrieval"
grep -Fq 'override fun onResume(){super.onResume();if(::searchBox.isInitialized)runSearch(searchBox.text.toString())}' "$SEARCH" || fail "Search onResume does not guard lateinit UI initialization"
grep -Fq 'override fun onDestroy(){executor.close();super.onDestroy()}' "$SEARCH" || fail "Search executor is not lifecycle-closed on destroy"
grep -Fq 'private fun rawQBankIds' "$ROOT/app/src/main/java/com/localqbank/library/RenCognitiveEngine.kt" || fail "Frankenstein raw ID fallback missing"
grep -Fq 'if (ids.isEmpty()) return' "$ROOT/app/src/main/java/com/localqbank/library/RenCognitiveEngine.kt" || fail "Frankenstein empty-result cache poison guard missing"

echo 'PASS: DEFECT_1 chat-clear and local-search route invariants'
echo 'PASS: DEFECT_2 shared question + QBank/sub-QBank retrieval invariants'
echo 'PASS: DEFECT_3 Continue cursor is written only by explicit study interaction'
