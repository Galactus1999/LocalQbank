#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DB="$ROOT/app/src/main/java/com/localqbank/library/QBankDatabaseProvider.kt"
DASH_REPO="$ROOT/app/src/main/java/com/localqbank/library/QBankDashboardRepository.kt"
SEARCH_REPO="$ROOT/app/src/main/java/com/localqbank/library/QBankSearchRepository.kt"
LOAD="$ROOT/app/src/main/java/com/localqbank/library/QBankLoadingEngine.kt"
HOME="$ROOT/app/src/main/java/com/localqbank/library/RovexHomeRevolution.kt"
DASH="$ROOT/app/src/main/java/com/localqbank/library/RovexSectionDashboardActivity.kt"
STATE="$ROOT/app/src/main/java/com/localqbank/library/AppState.kt"
fail(){ echo "FAIL: $*"; exit 1; }
grep -q 'progress_v2.*test_id TEXT' "$DB" || fail "progress_v2 test_id denormalization missing"
grep -q 'idx_progress_v2_test_status' "$DB" || fail "progress test/status index missing"
grep -q 'GROUP BY test_id' "$DASH_REPO" || fail "dashboard still lacks set-based progress aggregation"
! grep -q 'p.stable_key LIKE (t.id' "$DASH_REPO" || fail "dashboard still uses per-test correlated progress scan"
grep -q 'fun loadDashboardRows' "$LOAD" || fail "shared dashboard loader missing"
grep -q 'loadDashboardRows' "$HOME" || fail "Home still owns a direct dashboard database load"
grep -q 'loadDashboardRows' "$DASH" || fail "QBank dashboard still owns a direct database load"
grep -q 'showSectionLoading()' "$DASH" || fail "QBank dashboard has no immediate loading state"
grep -q 'import_completed' "$STATE" && grep -Eq 'qbank_delete_requested|qbank_deleted' "$STATE" || fail "QBank catalog invalidation missing"
current_version="$(sed -n 's/^[[:space:]]*versionCode[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$ROOT/app/build.gradle.kts" | head -n1)"
[[ "$current_version" =~ ^[1-9][0-9]*$ ]] || fail "versionCode missing or invalid"
if git -C "$ROOT" rev-parse HEAD^ >/dev/null 2>&1; then
  previous_version="$(git -C "$ROOT" show HEAD^:app/build.gradle.kts 2>/dev/null | sed -n 's/^[[:space:]]*versionCode[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' | head -n1 || true)"
  if [[ "$previous_version" =~ ^[1-9][0-9]*$ ]] && (( current_version <= previous_version )); then
    fail "versionCode must monotonically increase (current=$current_version previous=$previous_version)"
  fi
fi
# Search must remain generic, with image filtering isolated to the visual path.
generic="$(awk '/fun search\(query:String/{on=1} /fun searchImageQuestions/{on=0} on{print}' "$SEARCH_REPO")"
! grep -q 'question_image' <<<"$generic" || fail "generic search contaminated by image-only predicate"
grep -q 'fun searchImageQuestions' "$SEARCH_REPO" || fail "visual search path missing"
echo 'PASS: progress_v2 has indexed test ownership'
echo 'PASS: dashboard progress aggregation is set-based, not per-test correlated'
echo 'PASS: Home and QBank dashboard share cached catalog loading'
echo 'PASS: QBank dashboard has immediate loading state'
echo 'PASS: import/delete invalidates shared QBank catalog cache'
echo 'PASS: generic search remains non-visual and visual search remains isolated'
