# Rovex v8.3.696 — Universal Reader large-file scan fix

## Evidence from the supplied screenshot
The UI is still at 28% and reports `Searching for questionlist data array… • 0 valid questions found…`. The message is emitted by `LargeHtmlScanner.scan()` during preflight. It does not prove that the file has no questions; it only means the current alias candidate has not emitted a normalized question yet.

## Confirmed source defect
In v8.3.695, `scan()` constructed a priority list of aliases and reopened/re-scanned the entire HTML file for each alias via `seekToDataArray()`. Large files could be read from start to finish many times before the parser reached later aliases. The UI progress remained at 28% during this work, making the importer appear stalled and making large files impractically slow. This is a concrete performance defect in source, independent of whether the failing payload has an additional schema mismatch.

## Repair
- Added one byte-oriented lexical indexing pass that records candidate array byte offsets and names without materializing payloads.
- Candidate arrays are then tried in the existing priority order, seeking directly to the byte offset rather than rescanning the entire file for each alias.
- UTF-8 byte offsets are used because Java character offsets are not safe random-access positions for files containing non-ASCII content.
- Preserve every occurrence of an alias so an earlier empty runtime assignment cannot mask a later valid export array.
- Preserve zero-question preflight rejection and existing database rollback behavior.
- Add a regression test with non-ASCII HTML prefix, commented/quoted fake assignments, an empty preferred alias, and a later valid `QUESTIONLIST` payload.

## Verification boundary
Source-level changes and ZIP integrity can be checked here. Full Android compilation/JUnit/CI and device import remain unverified until Gradle/CI and the original failing HTML file are available. This change fixes repeated whole-file scans; it does not claim to prove compatibility with the user's exact export schema without that file.

## Additional implementation note
The indexer uses a 1 MiB buffered byte stream rather than one-byte file-system reads; it records offsets in bytes and uses `FileChannel.position()` to start candidate parsing without replaying the prefix. The obsolete per-alias whole-file seek routine was removed so future changes do not accidentally reintroduce the repeated-scan path.
