package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BenResearchInputPolicyTest {
    @Test fun blankInputIsRejected() {
        assertNull(BenResearchInputPolicy.normalize("   \n\t"))
    }

    @Test fun inputIsTrimmedAndBounded() {
        assertEquals("hello", BenResearchInputPolicy.normalize("  hello  "))
        val oversized = "x".repeat(BenResearchInputPolicy.MAX_QUERY_CHARS + 500)
        assertEquals(BenResearchInputPolicy.MAX_QUERY_CHARS, BenResearchInputPolicy.normalize(oversized)?.length)
    }
}
