package com.localqbank.library

/** Deterministic, allocation-bounded input policy for Ben's local research gateway. */
object BenResearchInputPolicy {
    const val MAX_QUERY_CHARS = 4096

    fun normalize(raw: String): String? {
        val clean = raw.trim()
        if (clean.isEmpty()) return null
        return if (clean.length <= MAX_QUERY_CHARS) clean else clean.take(MAX_QUERY_CHARS).trimEnd()
    }
}
