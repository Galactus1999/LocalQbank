package com.localqbank.library

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import android.util.Base64
import java.security.SecureRandom
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Google-account authentication for Gemini access. */
class GoogleAccountManager(private val activity: Activity) {
    private val context: Context get() = activity.applicationContext
    private val credentials by lazy { CredentialManager.create(activity) }

    fun auth(): FirebaseAuth? = runCatching {
        if (FirebaseAppAvailability.ensureInitialized(context) != null) FirebaseAuth.getInstance() else null
    }.getOrNull()

    fun currentEmail(): String? = auth()?.currentUser?.email

    suspend fun signIn(): Result<String> = withContext(Dispatchers.Main) {
        val firebaseAuth = auth() ?: return@withContext Result.failure(
            IllegalStateException("Firebase is not configured. Add google-services.json and enable Google sign-in.")
        )
        val webClientId = webClientId()
        if (webClientId.isBlank()) return@withContext Result.failure(
            IllegalStateException("Missing default_web_client_id. Configure Firebase Google sign-in.")
        )

        suspend fun requestStandard(authorizedOnly: Boolean, autoSelect: Boolean): Result<String> {
            val option = GetGoogleIdOption.Builder()
                .setServerClientId(webClientId)
                .setFilterByAuthorizedAccounts(authorizedOnly)
                .setAutoSelectEnabled(autoSelect)
                .setNonce(secureNonce())
                .build()
            return requestCredential(option, firebaseAuth)
        }

        suspend fun requestExplicitGoogleButton(): Result<String> {
            // This is the documented persistent-button flow. Unlike the bottom-sheet
            // GetGoogleIdOption flow, it can surface accounts that require Google
            // re-authentication instead of treating the provider response as a
            // cancellation.
            val option = GetSignInWithGoogleOption.Builder(webClientId)
                .setNonce(secureNonce())
                .build()
            return requestCredential(option, firebaseAuth)
        }

        try {
            // The user explicitly tapped Rovex's Google button, so start with the
            // explicit Sign in with Google flow. This is important for accounts that
            // require re-authentication; Android documents that the bottom-sheet flow
            // can exclude those accounts.
            val explicit = requestExplicitGoogleButton()
            if (explicit.isSuccess) return@withContext explicit

            val first = explicit.exceptionOrNull()
            // A genuine user dismissal/cancellation should not immediately reopen the
            // account chooser. Only fall back for provider-side credential availability
            // failures; re-authentication is handled by the explicit flow itself.
            if (first is NoCredentialException) {
                requestStandard(authorizedOnly = true, autoSelect = true).fold(
                    onSuccess = { Result.success(it) },
                    onFailure = { standardFailure ->
                        if (standardFailure is NoCredentialException) {
                            requestStandard(authorizedOnly = false, autoSelect = false)
                        } else {
                            Result.failure(standardFailure)
                        }
                    }
                )
            } else {
                Result.failure(first ?: IllegalStateException("Google sign-in could not be completed."))
            }
        } catch (e: GetCredentialCancellationException) {
            // Preserve cancellation semantics. In particular, do not turn a user
            // cancellation into an automatic second chooser.
            Result.failure(e)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }


    private suspend fun requestCredential(
        option: androidx.credentials.CredentialOption,
        firebaseAuth: FirebaseAuth
    ): Result<String> {
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = credentials.getCredential(request = request, context = activity)
        val credential = result.credential
        if (credential !is CustomCredential || credential.type != TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            return Result.failure(IllegalStateException("Google returned an unsupported credential."))
        }
        val google = try { GoogleIdTokenCredential.createFrom(credential.data) }
        catch (e: GoogleIdTokenParsingException) { return Result.failure(e) }
        val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
        val signedIn = firebaseAuth.signInWithCredential(firebaseCredential).awaitTask()
        return Result.success(signedIn.user?.email ?: "Google account")
    }

    suspend fun signOut() = withContext(Dispatchers.Main) {
        auth()?.signOut()
        runCatching { credentials.clearCredentialState(ClearCredentialStateRequest()) }
    }

    fun firebaseReady(): Boolean = auth() != null && webClientId().isNotBlank()

    fun webClientId(): String {
        val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        return id.takeIf { it != 0 }?.let(context::getString)?.trim().orEmpty()
    }

    fun friendlyError(t: Throwable): String {
        val message = t.message.orEmpty()
        return when {
            message.contains("DEVELOPER_ERROR", true) || message.contains("10", true) ->
                "Google sign-in configuration mismatch. Refresh google-services.json and verify the app SHA-1/SHA-256 in Firebase."
            message.contains("12500", true) || message.contains("SIGN_IN_FAILED", true) ->
                "Google sign-in failed. Enable Google in Firebase Authentication and verify the OAuth clients."
            message.contains("reauth", true) ->
                "Google requires account re-authentication. The explicit Google sign-in flow was used; please complete the Google verification and try again."
            message.contains("GetCredentialCancellationException", true) || message.contains("cancel", true) ->
                "Google sign-in was cancelled or the Google credential provider did not complete the request."
            else -> message.ifBlank { "Google sign-in could not be completed." }
        }
    }

    private fun secureNonce(byteLength: Int = 32): String {
        val bytes = ByteArray(byteLength)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    }
}

private suspend fun <T> com.google.android.gms.tasks.Task<T>.awaitTask(): T =
    suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
        addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
        addOnCanceledListener { continuation.cancel() }
    }
