# Rovex v8.3.231 — Google Sign-In Re-authentication + Sign-Out Hardening

- Bumped versionCode 323 → 325 and versionName 8.3.229 → 8.3.231.
- Uses Credential Manager's explicit `GetSignInWithGoogleOption` as the primary path when the user explicitly taps Rovex's Google sign-in button. This addresses provider-side account re-authentication cases that can surface as `GetCredentialCancellationException` after account selection.
- Keeps the standard `GetGoogleIdOption` flow as a bounded fallback for credential-availability failures.
- Generates a fresh nonce for each credential request.
- Uses the Activity directly as the Credential Manager context.
- Preserves real user cancellation instead of reopening the chooser automatically.
- Google sign-out remains a real Firebase `signOut()` followed by Credential Manager `clearCredentialState()`, matching current Firebase/Android guidance.
- Existing Settings → Adaptive Engine Google account button and RenActivity account dialog retain working sign-out controls.
