# Rovex v8.3.681 — DAMS large QBank array-selection root fix

## Root cause
The streaming scanner selected the first variable whose name matched a broad supported-array allowlist. An HTML export can contain a generic `APP_DATA`/folder metadata array before its actual combined `TESTS_LIST` question payload. The scanner could therefore parse the metadata array, emit zero normalized questions, and fail preflight at approximately 28%, despite valid question data later in the same file.

## Fix
- Scan candidate arrays in explicit specificity tiers: combined test arrays first, root question arrays second, and generic app-data arrays last.
- If a recognized candidate produces zero valid questions, continue to the next specificity tier; no database callback side effects occur when zero questions are emitted.
- Preserve the existing preflight-before-replacement invariant and zero-question rejection.
- Keep streaming parsing and bounded per-question materialization; no full-file HTML string is introduced.
- Add regression coverage for `APP_DATA` metadata appearing before a valid `TESTS_LIST` payload.
- Retain legacy DAMS aliases for question text, option list, option text, answer, and explanation.

## Verification
- Source review and regression test added.
- Full Gradle test execution attempted but blocked because `downloads.gradle.org` could not be resolved in this environment.
- No claim of Android compilation, CI success, or device import success until those checks run.
- Added a bounded legacy `APP_DATA` fallback that uses the existing strict recursive parser to find questions nested under folders/lessons when the export does not expose a supported combined-test array.
- Added regression coverage for nested `APP_DATA -> folders -> lessons -> questions` layouts.
