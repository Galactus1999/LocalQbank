package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BenDeletionAiArchitectureRegressionTest {
    @Test
    fun sameNamedSourcesDoNotDeleteAnotherSourcesLegacyResumeKey() {
        val legacyValue = "test-from-source-22|7"
        assertFalse(QBankProgressMetaOwnership.legacyResumeKeyBelongsToSource(11L, legacyValue, 22L))
        assertTrue(QBankProgressMetaOwnership.legacyResumeKeyBelongsToSource(22L, legacyValue, 22L))
    }

    @Test
    fun explicitSourceIdInLegacyValueWinsOverMissingTestRow() {
        assertTrue(QBankProgressMetaOwnership.legacyResumeKeyBelongsToSource(22L, "test-1|3|22|1700000000", null))
        assertFalse(QBankProgressMetaOwnership.legacyResumeKeyBelongsToSource(11L, "test-1|3|22|1700000000", null))
    }

    @Test
    fun rankedRetrievalResultsRemainCandidatesInsteadOfBeingRelabeledAsDistractors() {
        val hits = (1L..8L).map { id ->
            BenContrastiveEvidencePlanner.Candidate(id, "Clinical evidence record $id contains relevant clinical concept", 1.0 / id)
        }
        val bundle = BenContrastiveEvidencePlanner.plan(
            query = "clinical concept",
            candidates = hits,
            maxCandidates = 8,
            maxContrastive = 4
        )
        assertEquals(8, bundle.candidates.size)
        assertTrue(bundle.contrastive.isEmpty())
        assertTrue(bundle.candidates.all { it.role == BenContrastiveEvidence.Role.CANDIDATE_EVIDENCE })
    }

    @Test
    fun citationToUnrelatedEvidenceFailsMinimumSupportGate() {
        val verifier = BenAnswerVerifier()
        val evidence = mapOf(1 to BenAnswerVerifier.EvidenceItem(1, 10L, "Photosynthesis converts light energy into chemical energy in plants."))
        assertFalse(verifier.hasMinimumCitationSupport("Kidney injury is associated with this drug [1].", evidence))
    }

    @Test
    fun citationWithRelevantEvidencePassesMinimumSupportGate() {
        val verifier = BenAnswerVerifier()
        val evidence = mapOf(1 to BenAnswerVerifier.EvidenceItem(1, 10L, "Acute kidney injury can occur after exposure to the drug."))
        assertTrue(verifier.hasMinimumCitationSupport("Acute kidney injury can occur after exposure to the drug [1].", evidence))
    }

    @Test
    fun inventedCitationCannotPassMinimumSupportGate() {
        val verifier = BenAnswerVerifier()
        assertFalse(verifier.hasMinimumCitationSupport("Acute kidney injury is possible [2].", emptyMap()))
    }
}
