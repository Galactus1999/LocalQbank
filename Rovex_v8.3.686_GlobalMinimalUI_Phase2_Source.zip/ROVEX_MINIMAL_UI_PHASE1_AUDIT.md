# Rovex Minimal UI Phase 1 — Source Audit

- Source baseline: `Rovex_v8.3.684_LargeHtmlImport_RootFix_Source.zip`
- Output version: `8.3.685` / `versionCode 771`
- Package namespace / applicationId: `com.localqbank.library`
- Scope: Home density, generic subtitles/microcopy, Study Tools rows, Flashcards sheet/header/card builders.

## Changes made
- Home header height reduced from 76dp to 66dp; custom logo/search/wordmark bounds reduced proportionally.
- Removed redundant search shortcut and Ren tagline.
- Reduced Home metric cards from 104dp to 88dp; removed small eyebrow labels and study-menu subtitle.
- Removed generic Flashcards subtitle and static “library ready” line; reduced visual-summary height.
- Simplified Performance section to a single `Performance` title, reduced chart height, removed repeated summary/hint copy.
- Study Tools now uses compact title-first rows; removed introductory paragraph, row subtitles/tags and closing tip.
- Flashcard header, sheet headers, sheet cards, popup sections, SRS section and field descriptions no longer render a tiny subtitle line. Useful counts remain visible in study-menu titles; secondary explanations are retained in accessibility descriptions where practical.
- No intentional changes to database, import pipeline, SRS scheduling, study progress, QBank deletion, AI runtime, or signing configuration.

## Source-level checks
- All 37 XML files under `app/src/main` parsed successfully.
- No duplicate IDs in `activity_main.xml`.
- No Kotlin/Java references found for removed Home-only IDs (`flashcardHint`, `flashcardProgress`, `performanceLabLabel`, `performanceLabHint`, `studyMenuSub`, `homeSearchShortcut`).
- `namespace = "com.localqbank.library"` and `applicationId = "com.localqbank.library"` retained.
- Signing configuration block was not edited.

## Verification status
- Static XML/source review: PASS (limited to checks above).
- Gradle unit tests / compilation: BLOCKED — wrapper attempted to download Gradle 9.3.1, but DNS resolution for `downloads.gradle.org` failed (`curl: (6) Could not resolve host`).
- GitHub CI: NOT RUN for this source version.
- Physical-device screenshots, light/dark/Midnight Blue theme review, accessibility checks, and interaction regression tests: NOT RUN.
- Release status: NOT VERIFIED; do not treat this source ZIP as a green build until CI and device checks succeed.
