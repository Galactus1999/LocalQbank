pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() 
        maven { url = uri("https://jitpack.io") } // Rovex debug-only liquid-glass prototype, pinned v2.0.11
}
}
rootProject.name = "Rovex"
include(":app", ":benchmark")
