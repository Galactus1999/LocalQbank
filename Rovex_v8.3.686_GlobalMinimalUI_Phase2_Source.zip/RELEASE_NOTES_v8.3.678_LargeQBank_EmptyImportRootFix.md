# Rovex v8.3.678 — Large QBank Empty-Import Root Fix

## Root cause
The large-HTML path called `beginStreamingImport()` before proving that `LargeHtmlScanner` could recognize and normalize any questions. `beginStreamingImport()` replaces/removes the existing source. If the scanner found a supported array but emitted zero questions (or selected an export array with an unexpected capitalization), the old flow could still call `finish(true)` and publish an empty source.

## Repair
- `LargeHtmlScanner.scan()` now returns the number of normalized, de-duplicated questions emitted.
- Assignment aliases are matched case-insensitively while remaining an explicit allowlist to avoid selecting arbitrary metadata arrays.
- Large imports perform a complete read-only preflight before touching the database. Unsupported structure, malformed input, or zero valid questions fails with a clear message and does not replace the existing QBank.
- The second streaming pass checks that the count matches preflight and only finishes successfully when a non-empty, fully matching import was written; otherwise it aborts the partial new source.
- `QBankStreamingImportSession.finish(true)` independently refuses a zero-question finish as defense in depth.
- Import progress now reports validation counts and database-write counts, with a terminal success summary.
- Added regression tests for count reporting, lowercase aliases, empty arrays, preflight-before-replacement ordering, and the zero-question session guard.

## Verification status
- Source/static checks: run on the modified source archive.
- Unit tests/build: BLOCKED because the Gradle 9.3.1 distribution could not be downloaded (`downloads.gradle.org` DNS resolution failed).
- CI/device verification: NOT RUN. Do not treat this source archive as a verified APK or claim the import behavior is device-validated.
