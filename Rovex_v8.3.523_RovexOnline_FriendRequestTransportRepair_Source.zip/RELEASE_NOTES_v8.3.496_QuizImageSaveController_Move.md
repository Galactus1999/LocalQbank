# Rovex v8.3.496 — Quiz Image Save Controller Move

Move-only refactor after v8.3.495 CI-green report.

Extracted the image-save menu and image+note editor from QuizActivity into `QuizImageSaveController`.

Preserved wording, validation, theme colors, dialog sizing, persistence callbacks, success/error feedback, and AdaptiveTypography application. No persistence or business-logic changes.

Verification performed locally: source wiring scan, controller Activity-reference scan, brace-balance sanity check.
CI/device verification pending.
