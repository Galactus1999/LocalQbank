# v8.3.523 — Rovex Online Friend Request Transport Repair

## Root cause
The failing UI path waited on a backend acknowledgement and treated a timeout/network failure as if the target friend were unreachable. The older implementation also depended on a client-side `friendCodes/{targetCode}` document lookup; Firestore exact-document reads can fail when the document is not cached and the server cannot be reached. The recipient’s online state is unrelated to request creation.

## Repair
- Preserve the write-first `friendRequestIntents/{intentId}` protocol from v8.3.522.
- Do not block the Online Activity waiting for backend acknowledgement.
- Tell the user the request is queued/saved immediately after the intent is submitted.
- Keep a retry outbox only for an actual transport failure; never use recipient presence as a prerequisite.
- Keep server-side Rovex-ID resolution in `resolveFriendRequestIntent`.
- Harden resolver input validation for requester/target IDs and terminal status timestamps.

## Server requirement
Deploy the updated `firestore.rules` and `functions/index.js` before runtime testing. The Cloud Function is the authoritative resolver.

## Verification
- Node syntax check: required/pass after generation.
- Kotlin/static source audits: required.
- Android Gradle compile: currently blocked if the environment cannot resolve Gradle distribution DNS.
- Firebase deployment/device runtime: pending until credentials/deployment and two-account test are performed.
