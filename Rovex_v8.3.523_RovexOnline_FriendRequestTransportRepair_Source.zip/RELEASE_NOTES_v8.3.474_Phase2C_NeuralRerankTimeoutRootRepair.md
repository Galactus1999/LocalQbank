# Rovex v8.3.474 — Phase 2C neural rerank timeout root repair

## Root cause

Device evidence from v8.3.473 showed deterministic fallback itself completing in 23–364 ms, while the user-visible request could take about 64 seconds when the neural path was enabled. Source audit of v8.3.472 identified the mechanism: `BenInferenceProcessClient.rerankSuspend()` used the generic one-shot IPC policy of two attempts with a 30,000 ms timeout per attempt. A stalled/failed optional EmbeddingGemma rerank could therefore consume roughly 60 seconds before deterministic Ben was reached.

## Repair

- Semantic reranking now has a dedicated 8,000 ms client timeout.
- Semantic reranking uses exactly one attempt; model-execution timeouts are not retried.
- The generic 30 s × 2 transport retry policy remains unchanged for other one-shot IPC operations.
- Deterministic QBank retrieval remains authoritative and unchanged.
- No Binder architecture, database owner, QBank search implementation, model artifact, or neural runtime implementation was rewritten.
- Neural execution remains OFF by default and still requires explicit user enablement.

## Expected behavior

If EmbeddingGemma reranking is healthy, the neural path may continue to semantic reranking. If it stalls or times out, Ben should proceed to deterministic fallback after the bounded 8 s semantic attempt rather than waiting ~60 s for repeated attempts.

## Validation status

Static/source repair only in this environment. Android/CI/device verification is required before claiming build or runtime green.
