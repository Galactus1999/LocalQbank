package com.localqbank.library

import android.content.Context

/**
 * Durable, tiny outbox for friend-request intents. We persist the Rovex ID, not a target UID,
 * because an ID lookup may be impossible while offline. The worker resolves the ID when network
 * connectivity returns; the target user's own online state is never a prerequisite.
 */
class RovexFriendRequestOutbox(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun enqueue(code: String): Boolean {
        val normalized = RovexFriendRequestState.normalize(code)
        if (!RovexFriendRequestState.isValidCode(normalized)) return false
        val current = prefs.getStringSet(KEY_CODES, emptySet()).orEmpty().toMutableSet()
        val changed = current.add(normalized)
        if (changed) prefs.edit().putStringSet(KEY_CODES, current).apply()
        return true
    }

    @Synchronized
    fun snapshot(): List<String> = prefs.getStringSet(KEY_CODES, emptySet()).orEmpty().toList().sorted()

    @Synchronized
    fun remove(code: String) {
        val normalized = RovexFriendRequestState.normalize(code)
        val current = prefs.getStringSet(KEY_CODES, emptySet()).orEmpty().toMutableSet()
        if (current.remove(normalized)) prefs.edit().putStringSet(KEY_CODES, current).apply()
    }

    fun size(): Int = snapshot().size

    companion object {
        private const val PREFS = "rovex_online_friend_outbox"
        private const val KEY_CODES = "pending_codes"
    }
}
