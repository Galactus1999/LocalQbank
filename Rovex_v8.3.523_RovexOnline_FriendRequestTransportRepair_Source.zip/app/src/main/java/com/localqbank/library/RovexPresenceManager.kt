package com.localqbank.library

import android.content.Context
import android.os.SystemClock
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Realtime presence boundary. Firestore remains authoritative for identity/friendship; RTDB is
 * used only for short-lived connection state and last-seen timestamps.
 *
 * Each installation owns one connection node. Multiple devices therefore do not incorrectly
 * force a user offline when only one device disconnects. onDisconnect() is registered before the
 * online write so process death/network loss is handled server-side.
 */
object RovexPresenceManager : DefaultLifecycleObserver {
    private const val DATABASE_URL = "https://rovex-81c4e-default-rtdb.asia-southeast1.firebasedatabase.app"
    private const val PREFS = "rovex_presence"
    private const val KEY_CONNECTION_ID = "connection_id"

    data class PresenceState(val online: Boolean, val lastSeenMillis: Long?)
    data class Subscription(val reference: DatabaseReference, val listener: ValueEventListener)

    private var appContext: Context? = null
    private var connectionRef: DatabaseReference? = null
    private var connectedRef: DatabaseReference? = null
    private var connectedListener: ValueEventListener? = null
    private val installed = AtomicBoolean(false)
    private var foreground = false

    fun install(context: Context) {
        if (!installed.compareAndSet(false, true)) return
        appContext = context.applicationContext
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        FirebaseAuth.getInstance().addAuthStateListener { auth ->
            if (foreground) {
                if (auth.currentUser == null) stopPresence() else startPresence()
            }
        }
        if (ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) {
            foreground = true
            startPresence()
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        foreground = true
        startPresence()
    }

    override fun onStop(owner: LifecycleOwner) {
        foreground = false
        stopPresence()
    }

    private fun database(): FirebaseDatabase = FirebaseDatabase.getInstance(DATABASE_URL)

    private fun connectionId(): String {
        val prefs = appContext!!.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_CONNECTION_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString().replace("-", "")
        prefs.edit().putString(KEY_CONNECTION_ID, created).apply()
        return created
    }

    @Synchronized
    private fun startPresence() {
        val user = FirebaseAuth.getInstance().currentUser ?: return
        if (connectionRef != null) return
        val ref = database().getReference("presence/${user.uid}/connections/${connectionId()}")
        val connected = database().getReference(".info/connected")
        connectionRef = ref
        connectedRef = connected
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.getValue(Boolean::class.java) == true && FirebaseAuth.getInstance().currentUser?.uid == user.uid) {
                    ref.onDisconnect().setValue(offlineValue())
                        .addOnCompleteListener {
                            ref.setValue(onlineValue())
                        }
                }
            }
            override fun onCancelled(error: DatabaseError) {
                ProductionCrashReporter.breadcrumb(appContext!!, "ROVEX_PRESENCE_CONNECTION_CANCELLED:${error.code}")
            }
        }
        connectedListener = listener
        connected.addValueEventListener(listener)
    }

    @Synchronized
    private fun stopPresence() {
        val ref = connectionRef
        val connected = connectedRef
        val listener = connectedListener
        connectionRef = null
        connectedRef = null
        connectedListener = null
        if (connected != null && listener != null) connected.removeEventListener(listener)
        if (ref != null) {
            ref.setValue(offlineValue())
            // Keep the connection node so last-seen remains available. A later session reuses it.
        }
    }

    private fun onlineValue(): Map<String, Any> = mapOf(
        "state" to "online",
        "lastChanged" to ServerValue.TIMESTAMP,
        "platform" to "android"
    )

    private fun offlineValue(): Map<String, Any> = mapOf(
        "state" to "offline",
        "lastChanged" to ServerValue.TIMESTAMP,
        "platform" to "android"
    )

    fun observeFriend(uid: String, onState: (PresenceState) -> Unit, onError: (DatabaseError) -> Unit = {}): Subscription {
        val ref = database().getReference("presence/$uid/connections")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val state = RovexPresenceState.derive(snapshot.children.map { child ->
                    RovexPresenceState.Connection(
                        online = child.child("state").getValue(String::class.java) == "online",
                        lastChangedMillis = child.child("lastChanged").getValue(Long::class.java)
                    )
                })
                onState(PresenceState(state.online, state.lastSeenMillis))
            }
            override fun onCancelled(error: DatabaseError) = onError(error)
        }
        ref.addValueEventListener(listener)
        return Subscription(ref, listener)
    }
}
