package com.localqbank.library

/** Pure, deterministic reducer for multi-device presence snapshots. */
object RovexPresenceState {
    data class Connection(val online: Boolean, val lastChangedMillis: Long?)
    data class State(val online: Boolean, val lastSeenMillis: Long?)

    fun derive(connections: Iterable<Connection>): State {
        var online = false
        var latest: Long? = null
        for (connection in connections) {
            if (connection.online) online = true
            val changed = connection.lastChangedMillis
            if (changed != null && (latest == null || changed > latest)) latest = changed
        }
        return State(online, if (online) null else latest)
    }
}
