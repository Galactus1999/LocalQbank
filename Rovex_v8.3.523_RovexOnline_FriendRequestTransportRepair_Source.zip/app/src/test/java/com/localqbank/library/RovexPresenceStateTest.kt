package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexPresenceStateTest {
    @Test fun anyOnlineConnectionMakesUserOnline() {
        val state = RovexPresenceState.derive(listOf(
            RovexPresenceState.Connection(false, 100L),
            RovexPresenceState.Connection(true, 200L)
        ))
        assertTrue(state.online)
        assertNull(state.lastSeenMillis)
    }

    @Test fun latestOfflineConnectionDeterminesLastSeen() {
        val state = RovexPresenceState.derive(listOf(
            RovexPresenceState.Connection(false, 100L),
            RovexPresenceState.Connection(false, 300L),
            RovexPresenceState.Connection(false, 200L)
        ))
        assertFalse(state.online)
        assertEquals(300L, state.lastSeenMillis)
    }

    @Test fun emptyPresenceIsOfflineWithoutLastSeen() {
        val state = RovexPresenceState.derive(emptyList())
        assertFalse(state.online)
        assertNull(state.lastSeenMillis)
    }
}
