# Rovex v8.3.512 — v8.3.511 CI Compile Repair

## Root cause
CI for v8.3.511 selected the intended source archive but failed at `:app:compileDebugKotlin`.

The study-history patch mixed `QBankDb` wrapper methods with the underlying `SQLiteDatabase` receiver and also called a private `QBankDb` helper from `ProgressStore`. This caused unresolved `sourceIdForTest`, `getProgressMeta`, `putProgressMeta`, `recordStudyAttempt`, and invalid `rawQuery/moveToFirst/execSQL/getLong` calls.

The Celebration Planner Preview button also referenced its own local variable from inside its initializer, producing an unresolved `preview` reference.

## Repair
- Keep study-history SQL operations owned by `QBankDb`.
- Correct seed calls to `QBankDb` methods without the SQLiteDatabase receiver.
- Expose the controlled `recordStudyAttempt` operation to `ProgressStore`.
- Add `updateLatestStudyAttemptTime()` to `QBankDb`; `ProgressStore` no longer reaches into SQLite directly.
- Rename the Preview button variable to `previewButton` so the click closure has an initialized target.
- Increment versionCode 601 -> 602 and versionName 8.3.511 -> 8.3.512.

## Validation
- Changed Kotlin brace balance: PASS.
- Source assertions for repaired receiver boundaries and Preview target: PASS.
- Version monotonicity: PASS (602 > 601).
- Android/Gradle build: NOT RUN locally; CI required.
- Device/runtime validation: PENDING.
