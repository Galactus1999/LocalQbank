package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexRichRendererTest {
    @Test fun labeledMermaidFlowchartRendersAsDiagram() {
        val markdown = """
            ## Decision flow

            ```mermaid
            flowchart TD
              A[Patient presents with cystocele] --> B{Stage of prolapse?}
              B -->|I-II| C[Conservative: PT + pessary]
              B -->|III-IV| D[Conservative trial + consider surgery]
              D --> E{Symptomatic?}
              E -->|Yes| F[Continue pessary & PT]
              E -->|No| G[Follow-up; consider surgery if symptoms develop]
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Patient presents with cystocele"))
        assertTrue(html.contains("I-II"))
        assertFalse(html.contains("```mermaid"))
    }

    @Test fun twoBacktickProviderFenceIsRecovered() {
        val markdown = """
            Text before

            `` mermaid
            flowchart LR
              A[Start] -->|yes| B[Finish]
            ``

            Text after
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Start"))
        assertFalse(html.contains("`` mermaid"))
    }

    @Test fun sequenceDiagramDoesNotBecomeRawSource() {
        val markdown = """
            ```mermaid
            sequenceDiagram
              participant A as Doctor
              participant B as Patient
              A->>B: Explain diagnosis
              B-->>A: Ask question
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Doctor"))
        assertTrue(html.contains("Explain diagnosis"))
    }

    @Test fun stateDiagramDoesNotBreakNormalChat() {
        val markdown = """
            ```mermaid
            stateDiagram-v2
              [*] --> Idle
              Idle --> Processing : start
              Processing --> Done : complete
            ```
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("rich-diagram"))
        assertTrue(html.contains("Processing"))
    }

    @Test fun malformedDiagramFallsBackWithoutThrowing() {
        val html = rovexMarkdownToHtml(
            "```mermaid\nthis is not valid mermaid and should remain readable\n```",
            true
        )
        assertTrue(html.contains("rich-mermaid-fragment"))
        assertTrue(html.contains("this is not valid mermaid"))
    }
    @Test fun appendedHeadingAndThematicBreakBecomeBlocks() {
        val html = rovexMarkdownToHtml("Children may need special care. --- ### 2. Insomnia Associated with Medical Conditions\n\nCondition | Age\n--- | ---\nOSA | All ages", true)
        assertTrue(html.contains("<hr>"))
        assertTrue(html.contains("<h3>2. Insomnia Associated with Medical Conditions</h3>"))
        assertTrue(html.contains("<table>"))
        assertFalse(html.contains("<p>Children may need special care. <hr>"))
    }

    @Test fun normalSoftBreaksStayInsideOneParagraph() {
        val html = rovexMarkdownToHtml("First sentence.\nSecond sentence.\nThird sentence.", true)
        assertTrue(html.contains("<p>First sentence. Second sentence. Third sentence.</p>"))
        assertFalse(html.contains("First sentence.<br>Second"))
    }

    @Test fun adjacentListItemsBecomeSemanticList() {
        val html = rovexMarkdownToHtml("- One\n- Two\n- Three", true)
        assertTrue(html.contains("<ul><li>One</li><li>Two</li><li>Three</li></ul>"))
    }

    @Test fun collapsedDistractorTableIsRecoveredWithoutPipeSource() {
        val markdown = "9. Close distractors & why they’re wrong | Distractor | Why it’s incorrect | |-------------|-------------------| “HPV 16 is the only HPV type that causes cervical cancer.” | HPV 18 also accounts for a significant proportion of cases (Q1). |"
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("HPV 16 is the only HPV type"))
        assertFalse(html.contains("|-------------|-------------------|"))
    }

    @Test fun inlineBoldCannotConsumeFollowingParagraph() {
        val markdown = "**Only this phrase is bold.** Normal text continues.\n\nNext paragraph text stays normal."
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<b>Only this phrase is bold.</b> Normal text continues."))
        assertFalse(html.contains("<b>Only this phrase is bold.</b> Normal text continues. Next paragraph"))
        assertTrue(html.contains("</p><p>Next paragraph text stays normal.</p>"))
    }


    @Test fun collapsedThreeColumnTableIsRecoveredFromSingleLine() {
        val markdown = "3. Diagnosis | Modality | What it shows | Typical findings | |---|---|---| Pap smear | Cytologic atypia | ASC-US, LSIL, HSIL, SCC || HPV DNA test | Presence of high-risk HPV | Positive for HPV-16/18 || Colposcopy | Cervical architecture | Acetowhite changes, mosaicism, punctuation || Biopsy | Histology | CIN 1–3, invasive squamous cell carcinoma |"
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<th>Modality</th>"))
        assertTrue(html.contains("<th>Typical findings</th>"))
        assertTrue(html.contains("<td>Pap smear</td>"))
        assertFalse(html.contains("|---|---|---|"))
    }

    @Test fun inlineClinicalBulletsBecomeSeparateBlocks() {
        val markdown = "Primary screening: Cytology or HPV DNA testing. - Co-testing: HPV + Pap is recommended. - Screening interval: Pap alone every 3 y."
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<ul><li>Co-testing: HPV + Pap is recommended.</li><li>Screening interval: Pap alone every 3 y.</li><li>Age range: 21–65 y.</li></ul>"))
        assertTrue(html.contains("Screening interval: Pap alone every 3 y."))
    }

    @Test fun contentHasExplicitNormalWeightContract() {
        val html = wrapMarkdownDocument(rovexMarkdownBody("Normal paragraph. **Important term.**", true))
        assertTrue(html.contains("font-weight:400"))
        assertTrue(html.contains("strong,b{font-weight:650}"))
    }

    @Test fun numberedClinicalSectionTitleGetsProfessionalHeading() {
        val markdown = """
            9. Close distractors & why they’re wrong

            | Distractor | Why |
            | --- | --- |
            | HPV 16 | HPV 18 also contributes (Q1). |
        """.trimIndent()
        val html = rovexMarkdownToHtml(markdown, true)
        assertTrue(html.contains("<h3>9. Close distractors &amp; why they’re wrong</h3>"))
    }

}

// Paragraph/block regression coverage: AI providers often omit blank lines between semantic blocks.
// The renderer must recover structure without forcing every soft newline into a <br>.
