package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Proves the human filename is only presentation; the internal import identity isolates QBanks. */
@RunWith(AndroidJUnit4::class)
class QBankImportIdentityRegressionTest {
    private lateinit var db: QBankDb

    @Before fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
    }

    private fun oneQuestion(title: String) = ImportedTest(
        originalId = title, title = title, path = null, totalMarks = 1.0, duration = 0,
        timePerQuestion = 0.0, questions = listOf(
            ImportedQuestion(
                sourceId = "q1", text = "question-$title", rawText = null, correctAnswer = "A",
                explanation = null, bot = null, video = null, audio = null,
                options = listOf(ImportedOption("A", "answer", true)),
                questionImages = emptyList(), explanationImages = emptyList()
            )
        )
    )

    @Test fun sameDisplayFilenameDoesNotDeleteOtherImportedQBank() {
        db.importBundle("rvx-uri-A", "index.html", "HTML", listOf(oneQuestion("A")))
        db.importBundle("rvx-uri-B", "index.html", "HTML", listOf(oneQuestion("B")))

        val sources = db.sources()
        assertEquals(2, sources.size)
        assertTrue(sources.any { it.fileName == "index.html" })
        assertEquals(1, db.search("question-A").size)
        assertEquals(1, db.search("question-B").size)
    }

    @Test fun reimportSameIdentityReplacesOnlyThatQBank() {
        db.importBundle("rvx-uri-A", "index.html", "HTML", listOf(oneQuestion("A")))
        db.importBundle("rvx-uri-B", "index.html", "HTML", listOf(oneQuestion("B")))
        db.importBundle("rvx-uri-A", "index.html", "HTML", listOf(oneQuestion("A2")))

        assertEquals(2, db.sources().size)
        assertEquals(0, db.search("question-A").size)
        assertEquals(1, db.search("question-A2").size)
        assertEquals(1, db.search("question-B").size)
    }
    @Test fun legacyHiddenQBankIsRecoveredWithoutDeletingItsData() {
        db.importBundle("rvx-uri-legacy", "old.html", "HTML", listOf(oneQuestion("Legacy")))
        val raw = ApplicationProvider.getApplicationContext<Context>().openOrCreateDatabase("qbank.db", 0, null)
        val sourceId = raw.rawQuery("SELECT id FROM source WHERE file_name=? LIMIT 1", arrayOf("rvx-uri-legacy")).use { it.moveToFirst(); it.getLong(0) }
        raw.execSQL("UPDATE source SET deleting=1,delete_requested=0 WHERE id=?", arrayOf(sourceId))
        raw.close()

        val recovered = db.sources()
        assertEquals(1, recovered.size)
        assertEquals(1, db.search("question-Legacy").size)
    }

}
