package com.localqbank.library.ai.context

import android.content.Context
import com.localqbank.library.Question
import com.localqbank.library.currentBenExamProfile

/** Single builder used by UI/AI adapters so context construction cannot silently diverge. */
class ContextPackBuilder(private val context: Context) {
    fun forQuestion(question: Question, selectedOption: String? = null, learnerNote: String? = null): ContextPack =
        ContextPack.fromQuestion(question, currentBenExamProfile(context), selectedOption, learnerNote)

    fun forQuery(query: String, task: String = "Answer the study query using only supplied evidence."): ContextPack =
        ContextPack(
            examProfile = currentBenExamProfile(context),
            questionId = 0L,
            question = query.take(6000),
            options = emptyList(),
            selectedOption = null,
            keyedAnswer = null,
            qbankExplanation = null,
            task = task
        ).bounded()
}
