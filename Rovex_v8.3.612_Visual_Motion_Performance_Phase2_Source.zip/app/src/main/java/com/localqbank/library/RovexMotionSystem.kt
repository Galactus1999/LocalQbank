package com.localqbank.library

import android.view.View

/** Small, allocation-free interaction motion shared by themed controls. */
object RovexMotionSystem {
    private const val DOWN_SCALE = 0.985f
    private const val UP_SCALE = 1f
    private const val DOWN_MS = 70L
    private const val UP_MS = 120L

    fun pressDown(view: View) {
        if (!AnimationPolicy.enabled(view.context) || view.width == 0 || view.height == 0) return
        view.animate().cancel()
        view.animate().scaleX(DOWN_SCALE).scaleY(DOWN_SCALE).setDuration(DOWN_MS).start()
    }

    fun pressUp(view: View) {
        if (!AnimationPolicy.enabled(view.context)) return
        view.animate().cancel()
        view.animate().scaleX(UP_SCALE).scaleY(UP_SCALE).setDuration(UP_MS).start()
    }

    fun pressCancel(view: View) {
        if (!AnimationPolicy.enabled(view.context)) return
        view.animate().cancel()
        view.animate().scaleX(UP_SCALE).scaleY(UP_SCALE).setDuration(UP_MS).start()
    }
}
