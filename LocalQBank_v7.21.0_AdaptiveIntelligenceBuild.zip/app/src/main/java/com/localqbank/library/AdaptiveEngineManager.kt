package com.localqbank.library

import android.content.Context
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Closed-loop offline adaptive controller.
 *
 * Observe -> learn -> decide -> validate -> actuate -> measure.
 * The engine never edits source code or core user data. It can only change the
 * small set of runtime knobs exposed by AdaptiveAction/PerformanceManager.
 */
class AdaptiveEngineManager(context: Context) {
    enum class Action(val key: String) {
        PREFETCH_1("prefetch_1"), PREFETCH_2("prefetch_2"), PREFETCH_3("prefetch_3"),
        CACHE_SHORT("cache_short"), CACHE_NORMAL("cache_normal"), CACHE_LONG("cache_long")
    }

    data class State(
        val observations: Long, val answers: Long, val correct: Long, val wrong: Long,
        val refreshes: Long, val navigations: Long, val learningScore: Int, val confidence: Int,
        val preferredPrefetch: Int, val recommendedRefreshMs: Long,
        val autonomousChanges: Long = 0L, val lastAction: String = "none",
        val health: Int = 100, val exploration: Int = 0
    )

    private val app = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "adaptive-engine") }
    private val prefs = app.getSharedPreferences("adaptive_engine", Context.MODE_PRIVATE)
    private val running = AtomicBoolean(true)

    private fun ema(key: String, value: Float, alpha: Float): Float {
        val old = prefs.getFloat(key, .5f)
        return old + alpha * (value - old)
    }

    private fun observeInternal(event: String) {
        val observations = prefs.getLong("observations", 0L) + 1L
        val e = prefs.edit().putLong("observations", observations).putLong(event, prefs.getLong(event, 0L) + 1L)
        when (event) {
            "answer_correct" -> e.putFloat("accuracy_ema", ema("accuracy_ema", 1f, .08f))
            "answer_wrong" -> e.putFloat("accuracy_ema", ema("accuracy_ema", 0f, .08f))
        }
        e.apply()
    }

    /** Context bucket keeps the bandit small and interpretable. */
    private fun contextBucket(): String {
        val answers = prefs.getLong("answers", 0L)
        val acc = prefs.getFloat("accuracy_ema", .5f)
        return when {
            answers < 20 -> "cold"
            acc >= .80f -> "strong"
            acc < .60f -> "weak"
            else -> "steady"
        }
    }

    /** Beta/Thompson sampler. Priors are deliberately conservative. */
    private fun sampleBeta(alpha0: Double, beta0: Double): Double {
        // Lightweight approximation: posterior mean plus bounded noise.
        // This avoids a heavy statistics dependency in the hot path.
        val mean = alpha0 / (alpha0 + beta0).coerceAtLeast(1.0)
        val variance = mean * (1.0 - mean) / (alpha0 + beta0 + 1.0)
        return (mean + Random.nextDouble(-1.0, 1.0) * kotlin.math.sqrt(variance) * 1.8).coerceIn(0.0, 1.0)
    }

    private fun doublePref(key: String, fallback: Double): Double =
        prefs.getString(key, null)?.toDoubleOrNull() ?: fallback

    private fun selectAction(): Action {
        val bucket = contextBucket()
        return Action.values().maxByOrNull { action ->
            val a = doublePref("$bucket:${action.key}:a", 1.0)
            val b = doublePref("$bucket:${action.key}:b", 1.0)
            sampleBeta(a, b)
        } ?: Action.PREFETCH_2
    }

    private fun actionAllowed(action: Action): Boolean = when (action) {
        Action.PREFETCH_1, Action.PREFETCH_2, Action.PREFETCH_3,
        Action.CACHE_SHORT, Action.CACHE_NORMAL, Action.CACHE_LONG -> true
    }

    private fun actuate(action: Action) {
        if (!actionAllowed(action)) return
        when (action) {
            Action.PREFETCH_1 -> PerformanceManager.setAdaptivePolicy(prefetchDepth = 1)
            Action.PREFETCH_2 -> PerformanceManager.setAdaptivePolicy(prefetchDepth = 2)
            Action.PREFETCH_3 -> PerformanceManager.setAdaptivePolicy(prefetchDepth = 3)
            Action.CACHE_SHORT -> PerformanceManager.setAdaptivePolicy(cacheTtlMs = 2_000L)
            Action.CACHE_NORMAL -> PerformanceManager.setAdaptivePolicy(cacheTtlMs = 5_000L)
            Action.CACHE_LONG -> PerformanceManager.setAdaptivePolicy(cacheTtlMs = 12_000L)
        }
        prefs.edit()
            .putLong("autonomous_changes", prefs.getLong("autonomous_changes", 0L) + 1L)
            .putLong("last_action_at", System.currentTimeMillis())
            .putString("last_action", action.key)
            .apply()
    }

    private fun learnAction(action: Action, reward: Double) {
        val bucket = contextBucket()
        val ak = "$bucket:${action.key}:a"
        val bk = "$bucket:${action.key}:b"
        val a = doublePref(ak, 1.0)
        val b = doublePref(bk, 1.0)
        val r = reward.coerceIn(0.0, 1.0)
        prefs.edit().putString(ak, (a + r).toString()).putString(bk, (b + 1.0 - r).toString()).apply()
    }

    /** Receives an application event and closes the learning/action loop asynchronously. */
    fun onEvent(event: String, latencyMs: Long = 0L) {
        if (!running.get()) return
        executor.execute {
            runCatching {
                observeInternal(event)
                if (event == "answer_correct" || event == "answer_wrong") {
                    val correct = event == "answer_correct"
                    learnAction(lastAction(), if (correct) .7 else .3)
                }
                if (event == "question_opened" || event == "navigation" || event == "database_slow") {
                    val reward = when {
                        latencyMs <= 40L -> 1.0
                        latencyMs <= 120L -> .75
                        latencyMs <= 300L -> .35
                        else -> 0.0
                    }
                    if (latencyMs > 0L) learnAction(lastAction(), reward)
                    if (event == "database_slow") {
                        // Reliability wins over aggressive performance when the system is unhealthy.
                        PerformanceManager.setAdaptivePolicy(prefetchDepth = 1, cacheTtlMs = 2_000L)
                    } else if (shouldActuate()) {
                        actuate(selectAction())
                    }
                }
            }
        }
    }

    private fun lastAction(): Action = runCatching {
        Action.values().firstOrNull { it.key == prefs.getString("last_action", "") } ?: Action.PREFETCH_2
    }.getOrDefault(Action.PREFETCH_2)

    fun observeAsync(event: String) = onEvent(event)
    fun observe(event: String) { if (running.get()) observeInternal(event) }
    fun recordAnswer(correct: Boolean) {
        if (!running.get()) return
        executor.execute {
            runCatching {
                prefs.edit().putLong("answers", prefs.getLong("answers", 0L) + 1L).apply()
                onEvent(if (correct) "answer_correct" else "answer_wrong")
            }
        }
    }
    fun recordNavigation() = onEvent("navigation")
    fun recordRefresh() = onEvent("refresh")

    fun state(): State {
        val o = prefs.getLong("observations", 0L)
        val a = prefs.getLong("answers", 0L)
        val c = prefs.getLong("answer_correct", 0L)
        val w = prefs.getLong("answer_wrong", 0L)
        val r = prefs.getLong("refresh", 0L)
        val n = prefs.getLong("navigation", 0L)
        val acc = prefs.getFloat("accuracy_ema", if (a == 0L) .5f else c.toFloat() / max(1L, a))
        val confidence = min(100, (o * 2).coerceAtMost(100).toInt())
        val score = min(100, (o * .5f + a * 1.5f + confidence * .3f).toInt())
        val prefetch = PerformanceManager.adaptivePrefetchDepth()
        val refresh = when { a < 20 -> 15_000L; r > 200 && acc >= .75f -> 45_000L; else -> 30_000L }
        val health = PerformanceManager.healthScore()
        val exploration = (100 - confidence).coerceIn(0, 100)
        return State(o, a, c, w, r, n, score, confidence, prefetch, refresh,
            prefs.getLong("autonomous_changes", 0L), prefs.getString("last_action", "none") ?: "none", health, exploration)
    }

    fun resetLearning() {
        prefs.edit().clear().apply()
        PerformanceManager.setAdaptivePolicy(prefetchDepth = 2, cacheTtlMs = 5_000L)
    }

    fun shutdown() { running.set(false); executor.shutdownNow() }
}
