package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class SettingsActivity: Activity(){
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(b:Bundle?){super.onCreate(b);AppManagers.initialize(applicationContext);SystemUi.immersive(this);setContentView(build())}
    private fun build():ScrollView{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(28));setBackgroundColor(ThemeManager.bg(this@SettingsActivity))}
        root.addView(TextView(this).apply{text="Q Settings";textSize=27f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@SettingsActivity));setPadding(0,0,0,dp(6))})
        root.addView(TextView(this).apply{text="Appearance, backup and the local adaptive engine";textSize=13f;setTextColor(ThemeManager.muted(this@SettingsActivity));setPadding(0,0,0,dp(18))})
        section(root,"APPEARANCE")
        val themes=linkedMapOf(ThemeManager.LIGHT to "Light",ThemeManager.DARK to "Dark",ThemeManager.SEPIA to "Sepia",ThemeManager.AMOLED to "AMOLED Black",ThemeManager.MIDNIGHT to "Midnight Blue")
        val group=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        themes.forEach{(key,label)-> val row=button(if(ThemeManager.get(this)==key)"✓  $label" else label){ThemeManager.set(this,key);recreate()};group.addView(row,lp()) }
        root.addView(group)
        section(root,"BACKUP & RESTORE")
        root.addView(button("Open Backup & Restore"){startActivity(Intent(this,BackupActivity::class.java))},lp())
        section(root,"QUIZ TYPOGRAPHY")
        val fonts=linkedMapOf("sans-serif" to "Modern Sans","serif" to "Serif / textbook","monospace" to "Monospace / coding","sans-serif-condensed" to "Condensed Sans","sans-serif-light" to "Light Sans")
        val current=getSharedPreferences("ui",MODE_PRIVATE).getString("quiz_font_family","sans-serif")?:"sans-serif"
        fonts.forEach{(key,label)->root.addView(button(if(current==key)"✓  $label" else label){getSharedPreferences("ui",MODE_PRIVATE).edit().putString("quiz_font_family",key).apply();recreate()},lp())}
        section(root,"ADAPTIVE ENGINE")
        val state=AppManagers.adaptive.state()
        root.addView(TextView(this).apply{text="LEARNING LEVEL  ${state.learningScore}%\nCONFIDENCE  ${state.confidence}%  •  HEALTH ${state.health}%\nOBSERVATIONS  ${state.observations}\nANSWERS  ${state.answers}  •  CORRECT ${state.correct}  •  WRONG ${state.wrong}\nAUTONOMOUS CHANGES  ${state.autonomousChanges}\nLAST ACTION  ${state.lastAction}\nPREFETCH  ${state.preferredPrefetch} questions  •  CACHE ${PerformanceManager.adaptiveCacheTtlMs()/1000}s\nEXPLORATION  ${state.exploration}%\n\nThe engine is local and offline. It observes app behaviour, learns which runtime policies work, and safely applies bounded changes through managers. It cannot change your answers, database schema or application code.";textSize=14f;setTextColor(ThemeManager.text(this@SettingsActivity));setLineSpacing(0f,1.18f);background=rounded(ThemeManager.elevated(this@SettingsActivity),18);setPadding(dp(16),dp(16),dp(16),dp(16))},LinearLayout.LayoutParams(-1,dp(250)))
        root.addView(button("Reset Adaptive Learning History"){AppManagers.adaptive.resetLearning();Toast.makeText(this,"Adaptive history reset",Toast.LENGTH_SHORT).show();recreate()},lp())
        return ScrollView(this).apply{addView(root);isFillViewport=true}
    }
    private fun section(root:LinearLayout,t:String){root.addView(TextView(this).apply{text=t;textSize=11.5f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.accent(this@SettingsActivity));setPadding(0,dp(16),0,dp(8))})}
    private fun lp()=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}
    private fun button(t:String,click:()->Unit)=TextView(this).apply{text=t;textSize=14f;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),0,dp(16),0);setTextColor(ThemeManager.text(this@SettingsActivity));background=rounded(ThemeManager.elevated(this@SettingsActivity),14);setOnClickListener{click()}}
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
}
