# Rovex v8.3.98 Release Audit

Baseline: v8.3.96 source.

Changed:
- BenEmbeddingGemmaEngine.kt: removed GeckoEmbeddingModel/LocalAgents dependency and restored MediaPipe TextEmbedder 0.10.35.
- Explicit EmbeddingGemma task formatting is used for retrieval and semantic-similarity tests.
- SettingsActivity and BenModelLabActivity expose actual telemetry failure details.
- versionCode 196 / versionName 8.3.98.

Required external gate:
- Android Gradle compilation remains CI-only because services.gradle.org DNS is unavailable in the current environment.
- CI must pass before installation/release.
