package com.localqbank.library

import android.content.Context
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.sqrt

/**
 * CPU-first EmbeddingGemma 300M accelerator.
 *
 * Uses the stable MediaPipe TextEmbedder surface available in the build environment.
 * The pinned 0.10.35 artifact does not expose the newer TextFormatContext API,
 * so the stable default TextEmbedder path is used.
 * This class owns only embedding execution; retrieval policy remains in Ben's
 * deterministic/RAG layers and every failure falls back safely.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)
    data class Result<T>(val hits: List<SemanticHit<T>>, val elapsedMs: Long, val usedModel: Boolean)

    suspend fun <T> rerank(
        query: String,
        candidates: List<T>,
        textOf: (T) -> String,
        limit: Int = 8
    ): Result<T> = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile)
        if (installed == null) {
            BenNeuralTelemetry.blocked("EmbeddingGemma model is not installed")
            return@withContext fallback(candidates, limit, started)
        }
        if (!policy.mayStartModel(profile.estimatedModelMb) ||
            !governor.mayRun(policy, profile.estimatedRuntimeMb)
        ) {
            BenNeuralTelemetry.blocked("EmbeddingGemma blocked by policy/resource governor")
            return@withContext fallback(candidates, limit, started)
        }

        val boundedQuery = clean(query)
        if (boundedQuery.length < 2 || candidates.isEmpty()) {
            return@withContext fallback(candidates, limit, started)
        }

        try {
            val embedder = TextEmbedder.createFromFile(app, installed.file)
            try {
                // The pinned 0.10.35 API has no TextFormatContext. Its default EmbeddingGemma
                // path uses the model-supported default task formatting.
                val queryVector = vector(embedder.embed(boundedQuery))
                val selected = candidates.take(8)
                val scored = selected.map { candidate ->
                    val text = clean(textOf(candidate))
                    val documentVector = vector(embedder.embed(text))
                    SemanticHit(candidate, cosine(queryVector, documentVector))
                }.sortedByDescending { it.similarity }.take(limit.coerceIn(1, 8))
                policy.recordBackendSuccess()
                BenNeuralTelemetry.semantic(max(0L, System.currentTimeMillis() - started), true)
                Result(scored, max(0L, System.currentTimeMillis() - started), true)
            } finally {
                embedder.close()
            }
        } catch (error: Exception) {
            val detail = "EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}"
            BenNeuralTelemetry.error(detail)
            policy.recordBackendFailure()
            fallback(candidates, limit, started)
        }
    }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile) ?: run {
            BenNeuralTelemetry.blocked("EmbeddingGemma model is not installed")
            return@withContext null
        }
        if (!policy.mayStartModel(profile.estimatedModelMb) ||
            !governor.mayRun(policy, profile.estimatedRuntimeMb)
        ) {
            BenNeuralTelemetry.blocked("EmbeddingGemma blocked by policy/resource governor")
            return@withContext null
        }
        try {
            val embedder = TextEmbedder.createFromFile(app, installed.file)
            try {
                // The pinned 0.10.35 API has no TextFormatContext; both inputs use
                // the model-supported default embedding task. This is sufficient
                // for a stable semantic-similarity smoke test.
                val a = vector(embedder.embed(clean(first)))
                val b = vector(embedder.embed(clean(second)))
                val score = cosine(a, b)
                policy.recordBackendSuccess()
                BenNeuralTelemetry.semantic(max(0L, System.currentTimeMillis() - started), true)
                score
            } finally {
                embedder.close()
            }
        } catch (error: Exception) {
            val detail = "EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}"
            BenNeuralTelemetry.error(detail)
            policy.recordBackendFailure()
            null
        }
    }

    private fun vector(result: TextEmbedderResult): List<Float> =
        result.embeddingResult().embeddings().firstOrNull()?.floatEmbedding()?.toList()
            ?: error("EmbeddingGemma returned no embedding vector")

    private fun cosine(a: List<Float>, b: List<Float>): Double {
        val n = minOf(a.size, b.size)
        if (n == 0) return 0.0
        var dot = 0.0
        var aa = 0.0
        var bb = 0.0
        for (i in 0 until n) {
            val x = a[i].toDouble()
            val y = b[i].toDouble()
            dot += x * y
            aa += x * x
            bb += y * y
        }
        return if (aa <= 0.0 || bb <= 0.0) 0.0 else
            (dot / (sqrt(aa) * sqrt(bb))).coerceIn(-1.0, 1.0)
    }

    private fun clean(value: String) = value.replace(Regex("\\s+"), " ").trim().take(1200)

    private fun <T> fallback(candidates: List<T>, limit: Int, started: Long) =
        Result(
            candidates.take(limit.coerceAtLeast(0)).map { SemanticHit(it, 0.0) },
            max(0L, System.currentTimeMillis() - started),
            false
        )
}
