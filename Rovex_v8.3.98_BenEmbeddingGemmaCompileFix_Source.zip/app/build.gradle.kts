plugins {
    id("com.android.application")
}
android {
    namespace = "com.localqbank.library"
    compileSdk = 37
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    signingConfigs {
        // CI uses one persistent keystore so debug APKs remain installable as
        // in-place updates across GitHub Actions runners. Secrets are supplied by CI;
        // no private signing material is stored in source control.
        val storeFilePath = System.getenv("ROVEX_SIGNING_STORE_FILE")
        val storePasswordEnv = System.getenv("ROVEX_SIGNING_STORE_PASSWORD")
        val keyAliasEnv = System.getenv("ROVEX_SIGNING_KEY_ALIAS")
        val keyPasswordEnv = System.getenv("ROVEX_SIGNING_KEY_PASSWORD")
        val ciSigningConfigured = !storeFilePath.isNullOrBlank() &&
            !storePasswordEnv.isNullOrBlank() && !keyAliasEnv.isNullOrBlank() &&
            !keyPasswordEnv.isNullOrBlank()
        if (ciSigningConfigured) {
            create("ci") {
                storeFile = file(storeFilePath!!)
                storePassword = storePasswordEnv
                keyAlias = keyAliasEnv
                keyPassword = keyPasswordEnv
            }
        }
    }
    buildTypes {
        debug {
            // Local builds retain the normal Android debug key; CI supplies the
            // persistent signing environment and therefore uses signingConfigs.ci.
            val hasCiSigning = signingConfigs.names.contains("ci")
            if (hasCiSigning) signingConfig = signingConfigs.getByName("ci")
        }
        release {
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // The release APK is the canonical user-update artifact. In CI it is
            // signed with the same persistent Rovex certificate used by every
            // previous update-safe build, so Android can install it over the
            // existing app without uninstalling or clearing its data.
            val hasCiSigning = signingConfigs.names.contains("ci")
            if (hasCiSigning) signingConfig = signingConfigs.getByName("ci")
        }
        // AGP 9.3.x does not expose a generated `profile {}` shortcut; create the
        // custom build type explicitly. `isProfileable` is the supported AGP DSL
        // and causes the generated manifest to be profileable without a raw
        // android:profileableByShell attribute.
        create("profile") {
            initWith(getByName("release"))
            isDebuggable = false
            isProfileable = true
            val hasCiSigning = signingConfigs.names.contains("ci")
            if (hasCiSigning) signingConfig = signingConfigs.getByName("ci")
        }
    }
    defaultConfig {
        applicationId = "com.localqbank.library"
        minSdk = 26
        targetSdk = 36
        versionCode = 196
        versionName = "8.3.98"
    }
}
// Update safety: release artifacts must never silently fall back to the developer/debug key.
// CI injects the persistent signing configuration; local unsigned release builds are allowed
// for development, but the CI guard below rejects any artifact whose certificate differs.

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.webkit:webkit:1.12.1")
    debugImplementation("androidx.metrics:metrics-performance:1.0.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.work:work-runtime-ktx:2.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")
    // Optional on-device generative accelerator. Never bundled with a model artifact.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.16.1")
    // Optional on-device embedding runtime. This Google AI Edge RAG SDK supplies the
    // native tokenizer + LiteRT embedding path used by the user-imported EmbeddingGemma model.
    implementation("com.google.mediapipe:tasks-text:0.10.35")
    // Modern Anki .apkg uses Zstandard-compressed collection.anki21b and media.
    implementation("com.github.luben:zstd-jni:1.5.7-16@aar")
    // JVM unit tests (src/test) - starting point for extracting and locking in pure logic
    // like SpacedRepetitionScheduler out of the Activities/DB layer.
    testImplementation("junit:junit:4.13.2")
}
