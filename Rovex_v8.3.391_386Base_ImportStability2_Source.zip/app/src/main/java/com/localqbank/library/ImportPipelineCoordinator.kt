package com.localqbank.library

import android.content.Context
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** Serial, resumable import coordinator. Existing importers remain the parser of record. */
class ImportPipelineCoordinator(context: Context) {
    private val app = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "qbank-import") }
    private val running = AtomicBoolean(false)
    private val currentName = AtomicReference<String?>(null)
    private val currentFuture = AtomicReference<Future<*>?>(null)

    fun enqueue(sourceName: String, bytes: Long, work: () -> Unit, onSuccess: () -> Unit = {}, onFailure: (Throwable) -> Unit = {}): Boolean {
        if (!ImportSecurityPolicy.acceptsSize(bytes) || !running.compareAndSet(false, true)) return false
        currentName.set(sourceName.take(160))
        val future = executor.submit {
            val started = System.currentTimeMillis()
            AppEventBus.publish(AppEventBus.Event(AppEventBus.Type.IMPORT_STARTED))
            StudyEventSpine.publishAsync(StudyEventSpine.Event("import_started", source = "import", metadata = mapOf("name" to sourceName.take(120))))
            val result = runCatching { work() }
            // Release the coordinator before invoking completion callbacks. Those callbacks may
            // immediately enqueue the next selected file; keeping the gate closed here would
            // reject that legitimate next job and silently stall multi-file imports.
            running.set(false)
            currentName.set(null)
            currentFuture.set(null)
            result
                .onSuccess {
                    AppEventBus.publish(AppEventBus.Event(AppEventBus.Type.IMPORT_COMPLETED, latencyMs = System.currentTimeMillis() - started))
                    StudyEventSpine.publishAsync(StudyEventSpine.Event("import_completed", source = "import"))
                    onSuccess()
                }
                .onFailure { error ->
                    StudyEventSpine.publishAsync(StudyEventSpine.Event("import_failed", source = "import", metadata = mapOf("error" to (error.message ?: "unknown").take(160))))
                    onFailure(error)
                }
        }
        currentFuture.set(future)
        return true
    }

    fun isRunning(): Boolean = running.get()

    fun currentImportName(): String? = currentName.get()

    /** Cancels the active import and releases the scheduling gate after the worker observes interruption. */
    fun cancelCurrent() {
        // Do not release the gate here: the worker must unwind its DB/parser resources first.
        // Releasing it early could start two SQLite writers concurrently.
        currentFuture.get()?.cancel(true)
    }

    /** Test-only lifecycle hook; AppManagers owns the production coordinator. */
    internal fun closeForTest() {
        running.set(false)
        currentName.set(null)
        currentFuture.set(null)
        executor.shutdownNow()
    }
}
