# Deep Audit — v8.3.436

## Proven root cause repaired
The large HTML streaming import path committed the new source/questions but did not publish `AppState.changed("import_completed")`. The source-list loader caches non-empty results, so returning to the library could reuse a stale source list and hide the newly imported source.

## Source proof
- `QBankDb.StreamingImportSession.finish(true)` now finalizes the search index and publishes `AppState.changed("import_completed")`.
- `AppState.changed("import_completed")` calls `AppManagers.qbankLoading.invalidate()`.
- `QBankLoadingEngine.invalidate()` clears `sourceCache`, `testCache`, `bundleCache`, and dashboard cache.
- `MainQBankLibraryActivity.onResume()` calls `load()`, which then reads the committed source catalog rather than a stale non-empty cache.

## Additional repair
The large-file importer had a duplicate `finally` construct after the prior cache cleanup patch. It has been reduced to one valid outer staging-file cleanup block; repository closure remains in the inner repository-owning `finally`.

## Required runtime proof
Static analysis can prove the invalidation chain but cannot prove device persistence/visibility. Final acceptance still requires a real APK build and device test without clearing app data.
