# Rovex v8.3.436 — Import Visibility Cache Repair

## Root cause
The large-file HTML import path uses `QBankDb.beginStreamingImport()` / `StreamingImportSession.finish()`. Unlike the bounded `importBundle()` path, the streaming success path did not publish `AppState.changed("import_completed")` after its transaction committed.

`MainQBankLibraryActivity` loads sources through `QBankLoadingEngine`. That engine intentionally caches a non-empty source list for fast navigation. When an import completed while the cached list was populated, returning from `HtmlImportActivity` could therefore render the old source list and omit the newly committed QBank.

This was a real cache-invalidation defect, not a UI-only symptom.

## Fix
- Streaming import success now publishes the same committed-state `import_completed` invalidation used by `importBundle()`.
- `QBankLoadingEngine` therefore clears its source/test/dashboard caches before the QBank library reloads.
- Removed an invalid duplicate `finally` block left in the large-file staging repair path.
- Version: 8.3.436, versionCode 528.

## Verification target
A device test must import a large HTML QBank while the Imported QBanks screen already has at least one visible QBank cached, return to the library, and verify the new QBank appears immediately. Then open it, search it, return, and verify the existing QBank remains visible and accessible.
