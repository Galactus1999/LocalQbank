# Rovex v8.3.434 — QBank Import Identity + Tombstone Root Repair

## User-visible defect

The device showed `Import failed: UNIQUE constraint failed: source.file_name (code 2067 SQLITE_CONSTRAINT_UNIQUE)` and the Imported QBanks screen showed `No imported QBank yet`.

## Root cause

The `source.file_name` column was simultaneously:

1. the human display filename, and
2. a UNIQUE database identity.

`HtmlImportActivity` passed `displayName(uri)` (for example `index.html`) into `QBankDb.importBundle()` / `beginStreamingImport()` as that identity.

The importer therefore treated two different QBank documents with the same filename as the same database object. Before inserting the new source, the code attempted to delete the old row. The new tombstone-based deletion hides the old source immediately (`deleting=1`) but can legitimately return false if a database writer is temporarily unavailable. The import code previously ignored that false result and attempted the INSERT anyway. Because the old tombstoned row still occupied the UNIQUE `file_name`, SQLite raised code 2067.

The hidden-source symptom and the UNIQUE error are therefore two sides of the same defect:

`same display filename -> old source marked deleting -> UI excludes deleting rows -> deletion not yet complete -> INSERT same filename -> SQLITE_CONSTRAINT_UNIQUE`.

## Repair

### 1. Separate identity from presentation

New HTML imports now use a deterministic SHA-256 identity derived from the selected document URI:

`rvx-uri-<sha256(uri)>`

The database stores that value in the existing unique `source.file_name` field as the internal key, while `source.display_name` stores the real human filename.

This avoids a schema-destructive migration and preserves compatibility with existing databases.

Consequences:

- `index.html` from document A and `index.html` from document B can coexist.
- Re-importing the same selected document identity replaces only that document's QBank.
- Human filenames remain unchanged in the UI.
- Test IDs are also derived from the internal import identity, preventing same-name collisions.

### 2. Never ignore replacement deletion failure

Both normal and streaming import paths now check the result of replacing an existing import identity. If deletion has not completed, the importer aborts with a controlled recovery message instead of generating a raw UNIQUE constraint failure.

### 3. Recover complete tombstones created by the old bug

A one-time safety reconciliation checks `deleting=1` sources. A source is restored to `deleting=0` only if every stored test has a positive `num_questions` count matching its actual question count. Incomplete sources remain tombstoned and are handled by the resumable deletion worker.

This protects intact QBanks that were accidentally hidden by the filename-identity bug while not resurrecting partially deleted QBanks.

### 4. Recovery runs immediately

The deletion recovery worker no longer waits an arbitrary 15 seconds before beginning the safety reconciliation.

## Regression tests

`QBankImportIdentityRegressionTest` proves:

- two different internal import identities with the same human filename coexist;
- searching both QBanks works;
- re-importing identity A replaces A only;
- identity B remains intact.

Existing `QBankDeletionIsolationTest` remains intact and proves deleting one source does not hide/delete another.

## Static proof

- Coroutine cancellation audit: PASS
- Chat architecture audit: PASS
- Performance/search architecture audit: PASS
- Search/QBank regression audit: PASS
- Root architecture audit: PASS
- Frankenstein policy audit: PASS
- Ruthless static audit: PASS
- Kotlin delimiter audit: PASS

## Build limitation

A full Gradle build was not run in this environment because Gradle 9.3.1 cannot be downloaded from `downloads.gradle.org` due DNS/network restrictions. Therefore this report does not claim a green APK build or device verification.
