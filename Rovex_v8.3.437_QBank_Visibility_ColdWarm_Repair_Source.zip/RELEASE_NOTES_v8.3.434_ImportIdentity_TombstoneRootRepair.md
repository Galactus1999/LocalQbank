# v8.3.434 — QBank Import Identity + Tombstone Root Repair

- Decoupled QBank identity from human display filename.
- Added deterministic document-URI import identity for HTML imports.
- Same-named QBanks can now coexist without replacing/hiding each other.
- Re-import of the same selected document replaces only that document identity.
- Import paths now stop cleanly if an old identity cannot yet be removed instead of surfacing raw SQLite UNIQUE error 2067.
- Added recovery of complete QBanks accidentally tombstoned by the pre-v8.3.434 filename identity bug.
- Kept incomplete tombstones hidden and resumable.
- Added regression tests for same-display-name isolation and same-identity replacement.
- Preserved QBank deletion batching, tombstone isolation, deferred FTS maintenance, and bounded Frankenstein/Ren retrieval.
