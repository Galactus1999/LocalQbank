package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Regression coverage for the normalized-table LIKE fallback used when FTS is unavailable/dirty.
 * The ESCAPE expression must resolve to exactly one SQLite character because escapeLike() uses
 * a single backslash to quote %, _, and backslash in user search terms.
 */
@RunWith(AndroidJUnit4::class)
class QBankDbSearchRegressionTest {
    private lateinit var db: SQLiteDatabase
    private lateinit var qbankDb: QBankDb

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        context.deleteDatabase("qbank.db")
        qbankDb = QBankDb(context)
        db = context.openOrCreateDatabase("qbank.db", 0, null)
        db.execSQL("DELETE FROM question_image")
        db.execSQL("DELETE FROM option_item")
        db.execSQL("DELETE FROM question")
        db.execSQL("DELETE FROM test")
        db.execSQL("DELETE FROM source")
        db.execSQL("DELETE FROM question_fts")
        db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','1')")
        db.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(1,'regression.apkg','Regression','test',1)")
        db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('reg-test',1,'Regression Test','regression',1)")
        db.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(1,'reg-test',0,'q1','acid_base disturbance','acid_base disturbance')")
        db.execSQL("INSERT INTO question_image(question_id,kind,position,uri) VALUES(1,'stem',0,'content://regression/image')")
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun searchLikeFallbackEscapesUnderscoreWithoutSQLiteEscapeError() {
        val results = qbankDb.search("acid_base")
        assertFalse("LIKE fallback must return the matching row", results.isEmpty())
        assertEquals(1L, results.single().questionId)
    }

    @Test
    fun imageSearchLikeFallbackEscapesUnderscoreWithoutSQLiteEscapeError() {
        val results = qbankDb.searchImageQuestions("acid_base")
        assertFalse("Image LIKE fallback must return the matching row", results.isEmpty())
        assertEquals(1L, results.single().questionId)
    }

    @Test
    fun deletingQBankIsFastSafeAndLeavesStaleFtsForIdleMaintenance() {
        db.execSQL("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(1,'reg-test',1,'acid_base disturbance Regression')")
        db.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")

        assertTrue("QBank deletion should succeed", qbankDb.deleteSource(1L))

        assertEquals(0L, db.rawQuery("SELECT COUNT(*) FROM source", null).use { it.moveToFirst(); it.getLong(0) })
        assertEquals(0L, db.rawQuery("SELECT COUNT(*) FROM test", null).use { it.moveToFirst(); it.getLong(0) })
        assertEquals(0L, db.rawQuery("SELECT COUNT(*) FROM question", null).use { it.moveToFirst(); it.getLong(0) })
        // FTS4 source_id is UNINDEXED; deletion must not scan the entire FTS corpus on the
        // foreground delete path. A stale FTS row is harmless because search joins normalized
        // question/test/source tables. The idle maintenance worker later reconciles it.
        assertEquals(1L, db.rawQuery("SELECT COUNT(*) FROM question_fts", null).use { it.moveToFirst(); it.getLong(0) })
        assertTrue("Deleted QBank must never be returned by FTS-backed search", qbankDb.search("acid_base").isEmpty())
        val dirtyAfterDelete = db.rawQuery(
            "SELECT meta_value FROM search_index_meta WHERE meta_key='dirty' LIMIT 1",
            null
        ).use { it.moveToFirst(); it.getString(0) }
        // Logical FTS remains usable after source deletion; only physical garbage is deferred.
        assertEquals("0", dirtyAfterDelete)

        assertTrue("Idle maintenance must reconcile stale FTS rows", qbankDb.repairSearchIndexForMaintenance())
        assertEquals(0L, db.rawQuery("SELECT COUNT(*) FROM question_fts", null).use { it.moveToFirst(); it.getLong(0) })
    }

    @Test
    fun subQBankProgressSummaryIsAggregatedByTestWithoutQuestionWalkInKotlin() {
        db.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('reg-test-2',1,'Second Test','second',2)")
        db.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text) VALUES(2,'reg-test-2',0,'q2','one')")
        db.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text) VALUES(3,'reg-test-2',1,'q3','two')")
        db.execSQL("INSERT INTO progress_v2(stable_key,test_id,status,attempts) VALUES('reg-test-2:0:q2','reg-test-2','correct',1)")
        db.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('reg-test-2:position','1')")

        val summary = qbankDb.testProgressSummaries(1).getValue("reg-test-2")
        assertEquals(2, summary.total)
        assertEquals(1, summary.solved)
        assertEquals(1, summary.correct)
        assertEquals(1, summary.resumePosition)
    }

    @Test
    fun homeStatsUseSparseProgressAndIgnoreDeletedSources() {
        db.execSQL("INSERT INTO progress_v2(stable_key,test_id,status,bookmark,last_attempted) VALUES('reg-test:0:q1','reg-test','correct','important',1000000000)")
        val stats = qbankDb.homeStudyStats(0L, 0L, 0L)
        assertEquals(1, stats.today)
        assertEquals(1, stats.correct)
        assertEquals(1, stats.bookmarks)

        db.execSQL("UPDATE source SET deleting=1 WHERE id=1")
        val hidden = qbankDb.homeStudyStats(0L, 0L, 0L)
        assertEquals(0, hidden.today)
        assertEquals(0, hidden.bookmarks)
    }

}
