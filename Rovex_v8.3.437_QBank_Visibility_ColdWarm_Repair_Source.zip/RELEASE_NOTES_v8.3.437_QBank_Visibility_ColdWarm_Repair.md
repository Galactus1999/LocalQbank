# Rovex v8.3.437 — QBank Visibility Hardening

## Root cause addressed
The large/streaming HTML import path committed source data without invalidating the cached QBank catalog. v8.3.436 fixed that mutation path.

A second defensive weakness remained: the QBank library reused any non-empty in-memory source cache when it resumed. This meant a stale catalog could still be displayed if any mutation path failed to publish an invalidation or if an external import finished outside the current process's event chain.

## Fix
- v8.3.437 retains the v8.3.436 streaming-import `import_completed` invalidation.
- `QBankLoadingEngine.loadSources()` now supports an explicit `forceRefresh` path.
- `MainQBankLibraryActivity` uses `forceRefresh=true` on subsequent `onResume()` calls. The source catalog query is tiny and does not scan questions, so this preserves fast navigation while guaranteeing that returning from an import/delete Activity re-reads the authoritative source table.
- Streaming `finish(true)` now publishes the invalidation only after the SQLite transaction has actually ended successfully; a failed transaction cannot announce a false import completion.
- Version: 8.3.437, versionCode 529.
