# Rovex v8.3.435 — QBank Visibility, Thermal Budget, Import/Delete Root Repair

## Root causes confirmed

1. `source.deleting` was overloaded as both a visibility tombstone and an explicit destructive-delete intent. Crash recovery could therefore treat legacy hidden sources as deletion candidates. This could leave otherwise-present QBank data hidden, matching the device report of ~2.02 GB app data with an empty QBank catalog.
2. The HTML importer already used a document-derived URI identity for production imports, but the database still treated `file_name` as a unique internal key. Legacy/compatibility paths could still feed human filenames directly into the unique column and produce `SQLITE_CONSTRAINT_UNIQUE` (2067). Import identity is now normalized through `safeImportKey()` and the production path remains URI-derived; human display names remain presentation-only.
3. `BenKnowledgeBuildWorker` could run after an import without charging/idle constraints. It scans the imported corpus and performs clinical understanding/index writes. This is inappropriate for foreground responsiveness and can contribute to sustained CPU/thermal load.
4. Home `refreshDynamic()` materialized the complete lightweight question-reference corpus and the complete progress snapshot merely to display today's/weekly metrics. This was a whole-QBank scan on every Home refresh and was a major avoidable source of CPU, allocations, and SQLite work.
5. Large HTML import staging files were written into app cache and were not guaranteed to be deleted after success/failure. This can directly explain large cache growth (the device screenshot shows 333 MB cache).
6. Automatic backups had insufficient thermal/power constraints for a battery/heat-sensitive foreground study app.

## Repairs

- Added `source.delete_requested` with an index. User/import deletion sets both `deleting=1` and `delete_requested=1`.
- Recovery worker now restores legacy hidden sources and only destructively resumes sources with explicit `delete_requested=1`.
- `sources()` performs a safe legacy-visibility recovery before returning the live catalog; it never deletes legacy tombstones.
- Production/compatibility import keys are normalized through SHA-256; URI-derived `rvx-uri-*` identities remain stable, while legacy filename keys cannot become raw human filename identities.
- Home metrics now use SQL aggregation (`homeStudyStats`) over sparse `progress_v2` plus live-source joins. No full `QuestionRef` corpus or full progress map is materialized during ordinary Home refresh.
- Ben knowledge indexing now requires charging + battery-not-low + device-idle + storage-not-low constraints.
- Large HTML staging files are always deleted in `finally`; repository/session resources are also closed deterministically.
- Automatic local/cloud backup scheduling now requires charging, battery-not-low and device-idle; cloud backup additionally requires network connectivity.
- Existing bounded Frankenstein/Ren retrieval, QBank tombstone isolation, deferred FTS maintenance, WAL and batched deletion remain intact.

## Regression coverage

Added/updated instrumentation coverage for:
- same display filename with distinct internal identities;
- reimporting one identity without affecting another;
- legacy hidden QBank visibility recovery;
- sparse Home aggregate statistics and exclusion of deleted sources.

## Static verification

PASS:
- performance/search architecture audit
- QBank/search regression audit
- ruthless static audit
- coroutine cancellation audit
- Frankenstein policy audit
- root architecture audit
- delimiter balance for modified Kotlin files

Gradle/device verification remains a separate gate because this environment cannot resolve `downloads.gradle.org` to obtain Gradle 9.3.1.
