# Deep Audit — v8.3.437

## Visibility chain
1. HTML import derives a document-specific URI/SHA-256 import identity.
2. Streaming import inserts the source and questions transactionally in bounded sections.
3. Successful streaming completion commits the transaction before publishing `import_completed`.
4. `AppState.changed("import_completed")` invalidates the shared QBank catalog cache.
5. `MainQBankLibraryActivity` force-refreshes the source catalog whenever it resumes after its first display.
6. The source query reads `source WHERE deleting=0`, while legacy hidden sources are conservatively restored before the query.

## Why this is root-level
The fix does not add a fake UI row or copy a missing name into the screen. It fixes the authoritative data-to-cache lifecycle: commit -> invalidation -> authoritative source query.

## Additional safety
A failed streaming SQLite commit cannot emit `import_completed` because completion publication now occurs only after `endTransaction()` returns successfully.

## Required device proof
Install over the existing app without clearing data. Import a large HTML QBank while another QBank is already visible. Return to Imported QBanks and verify the new QBank appears. Then cold-restart the app and verify both QBanks remain visible. Open both, run Frankenstein/BEN+AI, and delete only one; the other must remain visible.
