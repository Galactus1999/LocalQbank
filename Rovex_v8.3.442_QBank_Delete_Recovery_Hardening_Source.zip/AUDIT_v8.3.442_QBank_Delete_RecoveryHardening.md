# Rovex v8.3.442 — QBank Delete Recovery Hardening

## Repair
The v8.3.441 recovery worker iterated explicit deletion intents with `runCatching` but ignored individual failures and always returned `Result.success()`. That could strand a tombstoned source indefinitely after a transient SQLite/IO failure.

The worker now records a per-source nonfatal error, tracks any failed deletion, and returns `Result.retry()` when cleanup did not complete. Successful sources remain complete; failed sources remain tombstoned and are eligible for the next recovery attempt.

## Version
- versionName: `8.3.442`
- versionCode: `534`

## Validation
Static source scans and archive integrity were rerun after this repair. Gradle compilation and device execution are not claimed without CI/device evidence.
