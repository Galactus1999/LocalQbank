# Rovex v8.3.442 — QBank Delete Responsiveness Repair

## Root cause
The previous UI dispatched the entire physical QBank deletion to the background executor, but it did not commit the deletion tombstone until that worker entered `QBankDb.deleteSource()`. The Activity therefore waited for the complete destructive operation before refreshing its catalog. Large QBanks could remain visible while SQLite cleanup was running and could continue competing with foreground navigation.

## Repair
- Added an explicit, tiny `requestSourceDeletion()` transaction that sets `deleting=1` and `delete_requested=1` before physical cleanup.
- The main QBank catalog refreshes immediately after that transaction, so the requested source disappears from foreground navigation without waiting for question/test deletion.
- Physical cleanup continues on the dedicated QBank deletion executor and remains resumable through the existing tombstone/recovery architecture.
- Made the explicit deletion request idempotent so recovery/continuation does not create a second deletion owner.
- Preserved incremental/deferred FTS cleanup and the shared QBankDatabase architecture.
- Added an instrumented regression proving the target source becomes invisible immediately while an unrelated source remains visible, and that the request is idempotent.

## Version
- versionName: `8.3.441`
- versionCode: `534`

## Validation status
Static source validation and test-source inspection are performed before packaging. Android/Gradle compilation and device execution require the CI/device gates; this document does not claim those as PASS without actual evidence.


## Follow-up hardening
- Recovery no longer reports success when an explicit deletion fails. Failed source cleanup now causes WorkManager retry, preserving the tombstone until physical deletion succeeds.
