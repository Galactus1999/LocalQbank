package com.localqbank.library

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.NoCredentialException
import android.content.MutableContextWrapper
import android.util.Base64
import java.security.SecureRandom
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Google-account authentication for Gemini access. */
class GoogleAccountManager(private val activity: Activity) {
    private val context: Context get() = activity.applicationContext
    private val credentials by lazy { CredentialManager.create(activity) }

    fun auth(): FirebaseAuth? = runCatching {
        if (FirebaseAppAvailability.ensureInitialized(context) != null) FirebaseAuth.getInstance() else null
    }.getOrNull()

    fun currentEmail(): String? = auth()?.currentUser?.email

    /**
     * Normal Credential Manager sign-in: automatic/authorized accounts first,
     * then all device accounts, then the explicit Google sign-in recovery flow.
     */
    suspend fun signIn(): Result<String> = withContext(Dispatchers.Main) {
        val firebaseAuth = auth() ?: return@withContext Result.failure(
            IllegalStateException("Firebase is not configured. Add google-services.json and enable Google sign-in.")
        )
        val webClientId = webClientId()
        if (webClientId.isBlank()) return@withContext Result.failure(
            IllegalStateException("Missing default_web_client_id. Configure Firebase Google sign-in.")
        )
        val nonce = secureNonce()
        suspend fun request(authorizedOnly: Boolean, autoSelect: Boolean): Result<String> {
            val option = GetGoogleIdOption.Builder()
                .setServerClientId(webClientId)
                .setFilterByAuthorizedAccounts(authorizedOnly)
                .setAutoSelectEnabled(autoSelect)
                .setNonce(nonce)
                .build()
            return requestCredential(option, firebaseAuth)
        }

        suspend fun requestExplicitGoogleButton(): Result<String> {
            // Credential Manager's explicit Sign in with Google button flow is the
            // documented recovery path when the bottom-sheet flow has no eligible
            // credential (for example, an account needs re-authentication).
            val option = GetSignInWithGoogleOption.Builder(webClientId)
                .setNonce(nonce)
                .build()
            return requestCredential(option, firebaseAuth)
        }

        try {
            request(authorizedOnly = true, autoSelect = true).fold(
                onSuccess = { Result.success(it) },
                onFailure = { first ->
                    if (first is NoCredentialException) {
                        request(authorizedOnly = false, autoSelect = false).fold(
                            onSuccess = { Result.success(it) },
                            onFailure = { second ->
                                if (second is NoCredentialException) requestExplicitGoogleButton()
                                else Result.failure(second)
                            }
                        )
                    } else Result.failure(first)
                }
            )
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }


    private suspend fun requestCredential(
        option: androidx.credentials.CredentialOption,
        firebaseAuth: FirebaseAuth
    ): Result<String> {
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val mutableContext = MutableContextWrapper(activity)
        val result = credentials.getCredential(request = request, context = mutableContext)
        val credential = result.credential
        if (credential !is CustomCredential || credential.type != TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            return Result.failure(IllegalStateException("Google returned an unsupported credential."))
        }
        val google = try { GoogleIdTokenCredential.createFrom(credential.data) }
        catch (e: GoogleIdTokenParsingException) { return Result.failure(e) }
        val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
        val signedIn = firebaseAuth.signInWithCredential(firebaseCredential).awaitTask()
        return Result.success(signedIn.user?.email ?: "Google account")
    }

    /**
     * Explicit Sign in with Google flow used by the visible G button.
     * Unlike the bottom-sheet GetGoogleIdOption flow, this is specifically
     * designed to show Google's sign-in UI and can add/re-authenticate an
     * account when no eligible Credential Manager credential exists.
     */
    suspend fun signInExplicit(): Result<String> = withContext(Dispatchers.Main) {
        val firebaseAuth = auth() ?: return@withContext Result.failure(
            IllegalStateException("Firebase is not configured. Add google-services.json and enable Google sign-in.")
        )
        val webClientId = webClientId()
        if (webClientId.isBlank()) return@withContext Result.failure(
            IllegalStateException("Missing default_web_client_id. Configure Firebase Google sign-in.")
        )
        return@withContext runCatching {
            val option = GetSignInWithGoogleOption.Builder(webClientId)
                .setNonce(secureNonce())
                .build()
            requestCredential(option, firebaseAuth).getOrThrow()
        }
    }

    suspend fun signOut() = withContext(Dispatchers.Main) {
        auth()?.signOut()
        runCatching { credentials.clearCredentialState(ClearCredentialStateRequest()) }
    }

    fun firebaseReady(): Boolean = auth() != null && webClientId().isNotBlank()

    fun webClientId(): String {
        val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        return id.takeIf { it != 0 }?.let(context::getString)?.trim().orEmpty()
    }

    fun friendlyError(t: Throwable): String {
        val message = t.message.orEmpty()
        return when {
            message.contains("DEVELOPER_ERROR", true) || message.contains("10", true) ->
                "Google sign-in configuration mismatch. Refresh google-services.json and verify the app SHA-1/SHA-256 in Firebase."
            message.contains("12500", true) || message.contains("SIGN_IN_FAILED", true) ->
                "Google sign-in failed. Enable Google in Firebase Authentication and verify the OAuth clients."
            message.contains("cancel", true) -> "Google sign-in was cancelled."
            else -> message.ifBlank { "Google sign-in could not be completed." }
        }
    }

    private fun secureNonce(byteLength: Int = 32): String {
        val bytes = ByteArray(byteLength)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    }
}

private suspend fun <T> com.google.android.gms.tasks.Task<T>.awaitTask(): T =
    suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
        addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
        addOnCanceledListener { continuation.cancel() }
    }
