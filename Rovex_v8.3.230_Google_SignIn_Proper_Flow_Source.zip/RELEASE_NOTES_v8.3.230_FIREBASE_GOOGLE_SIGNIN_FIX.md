# Rovex v8.3.230 — Google Sign-In UI Recovery

- Uses AndroidX Credential Manager 1.6.0 (stable) and Google Identity Services `googleid` 1.2.0.
- The visible G button now invokes `GetSignInWithGoogleOption` directly, matching the documented explicit Sign in with Google button flow.
- Normal Ben/Gemini flows retain the authorized-account → all-account → explicit fallback sequence.
- The explicit flow can add/re-authenticate a Google account when the bottom-sheet flow reports no credential.
- Adds technical exception class to the G-button error dialog for forensic diagnosis.
- versionCode 324 / versionName 8.3.230.
