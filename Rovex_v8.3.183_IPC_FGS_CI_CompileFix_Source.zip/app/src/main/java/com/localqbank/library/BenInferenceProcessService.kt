package com.localqbank.library

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.Process
import android.os.Parcel
import android.os.PowerManager
import android.os.Build
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Isolated neural-runtime service.
 *
 * v8.3.145: single-flight/latest-request-wins generation, explicit remote cancellation, native
 * LiteRT-LM async streaming, and a release barrier before a replacement request may run.
 */
class BenInferenceProcessService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val singleFlight = Mutex()
    private val requests = ConcurrentHashMap<String, GenerationControl>()
    private val oneShotRequests = ConcurrentHashMap<String, OneShotControl>()
    private val serviceGenerationId = AtomicLong(System.nanoTime())
    private val latestGenerationSequence = AtomicLong(0L)
    private val handlerThread by lazy { HandlerThread("ben-inference-binder").also { it.start() } }
    private var generator: BenLiteRtLmGenerator? = null
    private var embedding: BenEmbeddingGemmaEngine? = null
    private var generatorWarm = false
    private var embeddingWarm = false
    private lateinit var messenger: Messenger
    private val powerManager by lazy { getSystemService(PowerManager::class.java) }
    private val lifecycleHandler by lazy { Handler(mainLooper) }
    /** Independent watchdog scheduler: it must not share Dispatchers.IO with native work. */
    private val ipcWatchdog: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "ben-ipc-watchdog").apply { isDaemon = true }
    }
    private val warmTrimRunnable = Runnable {
        if (requests.isEmpty() && oneShotRequests.isEmpty()) {
            scope.launch {
                singleFlight.withLock { closeRuntimes() }
                runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
                stopSelf()
            }
        }
    }

    // v8.3.166: nothing in this service previously kept the OS from treating
    // :inference_process as an ordinary background process. On aggressive OEM battery
    // managers (OnePlus/OxygenOS in particular) a background process doing sustained
    // NPU/CPU work for tens of seconds is a well-known freeze/throttle target -- the
    // process stays alive (no Binder death, so the client never sees
    // INFERENCE_PROCESS_DIED) but simply stops making progress, which looks exactly like
    // the "Stage: IDLE" / IPC timeout symptom reported from a device diagnostic run.
    // beginForegroundWork()/endForegroundWork() promote this process to foreground
    // priority (notification + wake lock) only while a generation or diagnostic request
    // is actually in flight, and demote it again as soon as none are, so it isn't a
    // silently always-on foreground service.
    private var wakeLock: PowerManager.WakeLock? = null
    private val activeForegroundOps = AtomicInteger(0)
    private val foregroundPromoted = AtomicBoolean(false)
    private val shuttingDown = AtomicBoolean(false)
    @Volatile private var foregroundRequested = false
    @Volatile private var foregroundFailure: String? = null

    private fun beginForegroundWork(): Boolean {
        val count = activeForegroundOps.incrementAndGet()
        if (count != 1) {
            if (foregroundPromoted.get()) return true
            activeForegroundOps.decrementAndGet()
            return false
        }
        if (!foregroundPromoted.get() && !promoteForegroundAndWait()) {
            activeForegroundOps.decrementAndGet()
            val reason = foregroundFailure ?: "IPC_FGS_NOT_READY"
            BenNeuralTelemetry.error("Foreground work admission denied: $reason")
            return false
        }
        runCatching {
            val lock = wakeLock ?: powerManager
                ?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Rovex:BenInference")
                ?.apply { setReferenceCounted(false) }
                ?.also { wakeLock = it }
            lock?.acquire(WAKE_LOCK_TIMEOUT_MS)
        }.onFailure { BenNeuralTelemetry.error("Wake lock acquire failed: ${it.javaClass.simpleName}: ${it.message}") }
        return true
    }

    /**
     * Foreground promotion is deliberately synchronous on the Service main thread. Android
     * starts the FGS deadline from startForegroundService(), so promotion must not wait for
     * bindService callbacks, Dispatchers.IO, a Binder request, or a coroutine.
     */
    private fun promoteForegroundIfNeeded(): Boolean {
        if (foregroundPromoted.get()) return true
        if (Looper.myLooper() !== mainLooper) {
            BenNeuralTelemetry.error("Foreground promotion requested off main thread")
            return false
        }
        return promoteForegroundOnMainThread()
    }

    /**
     * Binder callbacks are handled on the dedicated IPC thread, while Android requires prompt
     * foreground promotion from the Service main thread. This bridge prevents the old race where
     * a bound client could send the real command before onStartCommand()/onBind() had completed
     * FGS admission. The wait is bounded and never runs on the main thread.
     */
    private fun promoteForegroundAndWait(): Boolean {
        if (foregroundPromoted.get()) return true
        if (Looper.myLooper() === mainLooper) return promoteForegroundOnMainThread()
        val latch = CountDownLatch(1)
        val result = AtomicBoolean(false)
        lifecycleHandler.post {
            result.set(promoteForegroundOnMainThread())
            latch.countDown()
        }
        return runCatching {
            latch.await(FOREGROUND_PROMOTION_WAIT_MS, TimeUnit.MILLISECONDS) && result.get()
        }.getOrDefault(false)
    }

    private fun promoteForegroundOnMainThread(): Boolean {
        if (foregroundPromoted.get()) return true
        return runCatching {
            ensureNotificationChannel()
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= 34) {
                androidx.core.app.ServiceCompat.startForeground(
                    this,
                    FOREGROUND_NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
                )
            } else {
                // specialUse is an Android 14 type; pre-34 uses the legacy two-argument API.
                startForeground(FOREGROUND_NOTIFICATION_ID, notification)
            }
            foregroundFailure = null
            foregroundPromoted.set(true)
            true
        }.getOrElse { error ->
            foregroundPromoted.set(false)
            val code = when (error.javaClass.simpleName) {
                "ForegroundServiceStartNotAllowedException" -> "IPC_FGS_START_NOT_ALLOWED"
                "ForegroundServiceDidNotStartInTimeException" -> "IPC_FGS_DID_NOT_START_IN_TIME"
                "MissingForegroundServiceTypeException" -> "IPC_FGS_TYPE_MISSING"
                "InvalidForegroundServiceTypeException", "IllegalArgumentException" -> "IPC_FGS_TYPE_INVALID"
                "SecurityException" -> "IPC_FGS_SECURITY_EXCEPTION"
                else -> "IPC_FGS_PROMOTION_FAILED"
            }
            foregroundFailure = "$code: ${error.message ?: "unknown"}".take(300)
            BenNeuralTelemetry.error("Foreground promotion failed: $foregroundFailure")
            false
        }
    }

    private fun endForegroundWork() {
        if (activeForegroundOps.updateAndGet { (it - 1).coerceAtLeast(0) } != 0) return
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        // startForeground() state is not a durable capability. Once stopForeground() has
        // demoted the service, the next real request must promote it again; otherwise a
        // subsequent diagnostic can incorrectly believe it is still foreground and run
        // background-throttled native work.
        foregroundPromoted.set(false)
        foregroundRequested = false
        // The FGS is explicitly started for active neural work. Once the final active
        // operation ends, clear the started-service state as well. Existing bindings may
        // keep the service alive for the bounded warm-runtime window.
        runCatching { stopSelf() }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(FOREGROUND_CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(FOREGROUND_CHANNEL_ID, "Ben on-device AI", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Shown only while Ben is running an on-device model test or answer"
                setShowBadge(false)
            }
        )
    }

    private fun buildNotification(): Notification {
        // minSdk is 26, so the channel-based constructor is always available here.
        return Notification.Builder(this, FOREGROUND_CHANNEL_ID)
            .setContentTitle("Ben is running an on-device test")
            .setContentText("EmbeddingGemma / Ben neural runtime")
            .setSmallIcon(R.drawable.rovex_launcher_monochrome)
            .setOngoing(true)
                        .build()
    }
    private val thermalListener = if (Build.VERSION.SDK_INT >= 29) object : PowerManager.OnThermalStatusChangedListener {
        override fun onThermalStatusChanged(status: Int) {
            if (status >= PowerManager.THERMAL_STATUS_SEVERE) activeGeneration?.cancel()
        }
    } else null
    @Volatile private var activeGeneration: GenerationControl? = null

    private class GenerationControl(
        val requestId: String,
        val clientGeneration: Long,
        val reply: Messenger,
        val sequence: Long,
    ) {
        val cancelled = AtomicBoolean(false)
        val terminalSent = AtomicBoolean(false)
        val nativeReleased = AtomicBoolean(false)
        val nativeStarted = AtomicBoolean(false)
        val lifecycle = BenIpcLifecycleState()
        @Volatile var job: Job? = null
        @Volatile var nativeCancel: (() -> Unit)? = null
        val tokenLock = Any()
        val pendingTokens = StringBuilder()
        @Volatile var tokenFlush: ScheduledFuture<*>? = null

        fun cancel() {
            if (cancelled.compareAndSet(false, true)) runCatching { nativeCancel?.invoke() }
        }
    }

    private class OneShotControl(
        val requestId: String,
        val clientGeneration: Long,
        val reply: Messenger?,
    ) {
        val cancelled = AtomicBoolean(false)
        val terminalSent = AtomicBoolean(false)
        val phase = AtomicReference("queued")
        @Volatile var job: Job? = null
        @Volatile var watchdog: ScheduledFuture<*>? = null
    }

    override fun onCreate() {
        super.onCreate()
        messenger = Messenger(Handler(handlerThread.looper) { message -> handle(message) })
        if (Build.VERSION.SDK_INT >= 29) runCatching { thermalListener?.let { powerManager?.addThermalStatusListener(it) } }
    }

    private fun handle(message: Message): Boolean {
        if (bundleSizeBytes(message.data) > MAX_IPC_PAYLOAD_BYTES) {
            val replyCode = when (message.what) {
                CMD_PING -> REPLY_PING
                CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
                else -> REPLY_GENERATE
            }
            sendReply(message.replyTo, replyCode, Bundle().apply {
                putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
                putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
                putBoolean(KEY_FAILED, true)
                putString(KEY_ERROR, "IPC_PAYLOAD_TOO_LARGE")
            })
            return true
        }
        if (shuttingDown.get() && message.what != CMD_CANCEL) {
            sendCommandFailure(message, "INFERENCE_SERVICE_SHUTTING_DOWN")
            return true
        }
        when (message.what) {
            CMD_FGS_ADMISSION -> handleForegroundAdmission(message)
            CMD_GENERATE -> startGeneration(message)
            CMD_CANCEL -> cancelGeneration(message.data.getString(KEY_REQUEST_ID).orEmpty())
            CMD_RERANK, CMD_DIAGNOSTIC, CMD_COMPARE -> startOneShot(message)
            CMD_PING -> sendReply(message.replyTo, REPLY_PING, Bundle().apply {
                putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
                putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
                putBoolean(KEY_OK, true)
            })
            else -> {
                sendCommandFailure(message, "IPC_UNKNOWN_COMMAND_${message.what}")
                return true
            }
        }
        return true
    }

    private fun handleForegroundAdmission(message: Message) {
        foregroundRequested = true
        val ready = promoteForegroundAndWait()
        sendReply(message.replyTo, REPLY_FGS_ADMISSION, Bundle().apply {
            putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
            putBoolean(KEY_OK, ready)
            putBoolean(KEY_FAILED, !ready)
            if (!ready) putString(KEY_ERROR, foregroundFailure ?: "IPC_FGS_NOT_READY")
        })
    }

    private fun startGeneration(message: Message) {
        val requestId = message.data.getString(KEY_REQUEST_ID).orEmpty()
        val reply = message.replyTo
        if (reply == null) {
            BenNeuralTelemetry.error("IPC generate rejected: missing reply Messenger")
            return
        }
        if (requestId.isBlank()) {
            sendCommandFailure(message, "IPC_MISSING_REQUEST_ID")
            return
        }
        activeGeneration?.cancel()
        requests.values.forEach { if (it !== activeGeneration) it.cancel() }
        val control = GenerationControl(
            requestId = requestId,
            clientGeneration = message.data.getLong(KEY_CLIENT_GENERATION),
            reply = reply,
            sequence = latestGenerationSequence.incrementAndGet(),
        )
        requests[requestId] = control
        control.job = scope.launch {
            if (!beginForegroundWork()) {
                sendTerminal(control, failed = true, error = "IPC_FGS_PROMOTION_FAILED")
                requests.remove(requestId, control)
                return@launch
            }
            val watchdog = launch {
                delay(GENERATION_HARD_TIMEOUT_MS)
                if (!control.terminalSent.get() && requests[control.requestId] === control) {
                    BenNeuralTelemetry.error("Generation hard deadline exceeded; terminating isolated inference process")
                    Process.killProcess(Process.myPid())
                }
            }
            try {
                singleFlight.withLock {
                    if (control.cancelled.get() || control.sequence != latestGenerationSequence.get()) return@withLock
                    activeGeneration = control
                    control.nativeStarted.set(true)
                    try {
                        runGeneration(control, benIpcGetText(message.data, KEY_PROMPT), message.data.getInt(KEY_MAX_TOKENS, 160))
                    } finally {
                        watchdog.cancel()
                        control.lifecycle.released()
                        control.nativeReleased.set(true)
                        activeGeneration = null
                    }
                }
            } finally {
                watchdog.cancel()
                requests.remove(requestId, control)
                endForegroundWork()
            }
        }
    }

    private suspend fun runGeneration(control: GenerationControl, prompt: String, maxTokens: Int) {
        val governor = BenAiResourceGovernor(applicationContext)
        val policy = BenAiRuntimePolicy(applicationContext)
        val profile = BenNeuralModelRegistry.gemma3_270m
        val installed = BenNeuralModelManager(applicationContext).installed(profile)
        if (installed == null || !governor.mayRun(policy, profile.estimatedRuntimeMb, foreground = true)) {
            sendTerminal(control, failed = true, error = "Generation blocked by model/resource policy")
            return
        }
        val promptBudget = BenAiResourceGate.promptBudgetChars(governor.snapshot(foreground = true).thermalStatus)
        if (promptBudget <= 0) {
            sendTerminal(control, failed = true, error = "Thermal safety gate denied neural generation")
            return
        }
        try {
            if (generator == null) generator = BenLiteRtLmGenerator(applicationContext)
            val stream = generator!!.generateStream(
                prompt = prompt.take(promptBudget),
                maxOutputTokens = maxTokens,
                onCancel = { control.cancelled.get() },
                onNativeCancelReady = { cancel -> control.nativeCancel = cancel },
            )
            stream
                .catch { error ->
                    if (error is CancellationException || control.cancelled.get()) {
                        sendTerminal(control, cancelled = true)
                    } else {
                        policy.recordBackendFailure()
                        sendTerminal(control, failed = true, error = error.message ?: error.javaClass.simpleName)
                    }
                }
                .collect { chunk ->
                    if (!control.cancelled.get()) sendToken(control, chunk)
                }
            if (control.cancelled.get()) {
                sendTerminal(control, cancelled = true)
            } else {
                policy.recordBackendSuccess()
                sendTerminal(control, text = controlReplyText.remove(control.requestId)?.toString().orEmpty())
            }
        } catch (error: Exception) {
            if (error is Error) throw error
            if (control.cancelled.get() || error is CancellationException) sendTerminal(control, cancelled = true)
            else {
                policy.recordBackendFailure()
                sendTerminal(control, failed = true, error = error.message ?: error.javaClass.simpleName)
            }
        }
    }

    private val controlReplyText = ConcurrentHashMap<String, StringBuilder>()

    private fun sendToken(control: GenerationControl, token: String) {
        if (control.cancelled.get() || control.terminalSent.get()) return
        controlReplyText.getOrPut(control.requestId) { StringBuilder() }.append(token)
        synchronized(control.tokenLock) {
            if (control.cancelled.get() || control.terminalSent.get()) return
            control.pendingTokens.append(token)
            val flushNow = control.pendingTokens.length >= TOKEN_BATCH_MAX_CHARS
            if (flushNow) {
                control.tokenFlush?.cancel(false)
                control.tokenFlush = null
            } else if (control.tokenFlush == null || control.tokenFlush?.isDone == true) {
                control.tokenFlush = ipcWatchdog.schedule(
                    { flushTokens(control) },
                    TOKEN_BATCH_WINDOW_MS,
                    TimeUnit.MILLISECONDS,
                )
                return
            }
        }
        flushTokens(control)
    }

    private fun flushTokens(control: GenerationControl, allowReschedule: Boolean = true) {
        val chunk: String
        synchronized(control.tokenLock) {
            if (control.pendingTokens.isEmpty()) {
                control.tokenFlush = null
                return
            }
            val length = minOf(control.pendingTokens.length, TOKEN_BATCH_MAX_CHARS)
            chunk = control.pendingTokens.substring(0, length)
            control.pendingTokens.delete(0, length)
            control.tokenFlush = null
            if (allowReschedule && control.pendingTokens.isNotEmpty() && !control.cancelled.get() && !control.terminalSent.get()) {
                control.tokenFlush = ipcWatchdog.schedule(
                    { flushTokens(control) },
                    TOKEN_BATCH_WINDOW_MS,
                    TimeUnit.MILLISECONDS,
                )
            }
        }
        if (control.cancelled.get() || control.terminalSent.get()) return
        sendReply(control.reply, REPLY_TOKEN, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_TOKEN, chunk)
        })
    }

    private fun sendTerminal(
        control: GenerationControl,
        text: String? = null,
        failed: Boolean = false,
        cancelled: Boolean = false,
        error: String? = null,
    ) {
        if (!control.lifecycle.terminal()) return
        control.tokenFlush?.cancel(false)
        control.tokenFlush = null
        if (control.cancelled.get()) {
            synchronized(control.tokenLock) { control.pendingTokens.setLength(0) }
        } else {
            do {
                flushTokens(control, allowReschedule = false)
            } while (synchronized(control.tokenLock) { control.pendingTokens.isNotEmpty() })
        }
        control.terminalSent.set(true)
        synchronized(control.tokenLock) { control.pendingTokens.setLength(0) }
        val finalText = text ?: controlReplyText.remove(control.requestId)?.toString().orEmpty()
        sendReply(control.reply, REPLY_GENERATE, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_TEXT, finalText)
            putBoolean(KEY_FAILED, failed)
            putBoolean(KEY_CANCELLED, cancelled)
            if (error != null) putString(KEY_ERROR, error)
        })
    }

    private fun sendOneShotFailure(control: OneShotControl, command: Int, error: String) {
        if (!control.terminalSent.compareAndSet(false, true)) return
        val reply = control.reply ?: return
        val data = Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putBoolean(KEY_FAILED, true)
            putString(KEY_ERROR, error)
            if (command == CMD_COMPARE) putDouble(KEY_SCORE, Double.NaN)
        }
        sendReply(reply, when (command) {
            CMD_RERANK -> REPLY_RERANK
            CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
            else -> REPLY_COMPARE
        }, data)
    }

    private fun cancelGeneration(requestId: String) {
        if (requestId.isBlank()) return
        val control = requests[requestId]
        if (control != null) {
            control.cancel()
        } else {
            oneShotRequests[requestId]?.cancelled?.set(true)
        }
        if (control == null) return
        // LiteRT-LM documents that CancelProcess() can leave a native session unusable, and
        // current upstream reports show that a pathological cancellation can delay session
        // release. Never let that wedge the single-flight barrier indefinitely: the isolated
        // process is disposable, so kill it after a short cancellation grace period.
        scope.launch {
            delay(CANCEL_GRACE_MS)
            if (!control.nativeReleased.get() && requests[requestId] === control) {
                BenNeuralTelemetry.error("Cancellation grace exceeded; terminating isolated inference process")
                Process.killProcess(Process.myPid())
            }
        }
    }

    private fun startOneShot(message: Message) {
        val requestId = message.data.getString(KEY_REQUEST_ID).orEmpty()
        val reply = message.replyTo
        if (reply == null) {
            BenNeuralTelemetry.error("IPC one-shot rejected: missing reply Messenger; command=${message.what}")
            return
        }
        if (requestId.isBlank()) {
            sendCommandFailure(message, "IPC_MISSING_REQUEST_ID")
            return
        }
        if (shuttingDown.get()) {
            sendCommandFailure(message, "INFERENCE_SERVICE_SHUTTING_DOWN")
            return
        }
        val control = OneShotControl(requestId, message.data.getLong(KEY_CLIENT_GENERATION), reply)
        oneShotRequests[requestId] = control
        // Start a watchdog on a dedicated scheduler BEFORE any foreground admission or coroutine
        // dispatch. The previous watchdog shared Dispatchers.IO and was created only after
        // beginForegroundWork(), leaving the exact "accepted, then nothing for 150 s" blind spot.
        // This watchdog therefore remains independent of native work, the coroutine dispatcher,
        // and the single-flight mutex.
        val watchdogDelayMs = if (message.what == CMD_DIAGNOSTIC) DIAGNOSTIC_PREKILL_MS else ONE_SHOT_HARD_TIMEOUT_MS
        control.watchdog = ipcWatchdog.schedule({
            if (oneShotRequests[requestId] === control && !control.terminalSent.get()) {
                val phase = control.phase.get()
                if (message.what == CMD_DIAGNOSTIC) {
                    sendOneShotFailure(control, message.what, "SERVER_DIAGNOSTIC_TIMEOUT_STAGE=$phase")
                    BenNeuralTelemetry.error("Independent IPC watchdog fired; diagnostic stage=$phase")
                } else {
                    sendOneShotFailure(control, message.what, "SERVER_ONE_SHOT_TIMEOUT_STAGE=$phase")
                }
                // Give the terminal Binder transaction a short delivery window, then kill the
                // disposable process. Never let a wedged FGS/native admission consume the client's
                // full 150 s timeout without a server-side explanation.
                ipcWatchdog.schedule({
                    if (oneShotRequests[requestId] === control) {
                        val finalPhase = control.phase.get()
                        BenNeuralTelemetry.error("IPC watchdog terminal grace exceeded; killing isolated process; stage=$finalPhase")
                        Process.killProcess(Process.myPid())
                    }
                }, if (message.what == CMD_DIAGNOSTIC) DIAGNOSTIC_KILL_GRACE_MS else CANCEL_GRACE_MS, TimeUnit.MILLISECONDS)
            }
        }, watchdogDelayMs, TimeUnit.MILLISECONDS)

        if (message.what == CMD_DIAGNOSTIC) {
            control.phase.set("accepted")
            sendOneShotProgress(control, "Remote diagnostic accepted by isolated Ben process")
        }
        if (!foregroundPromoted.get() && !promoteForegroundAndWait()) {
            val reason = foregroundFailure ?: "IPC_FGS_NOT_READY"
            control.phase.set("fgs_failed")
            sendOneShotFailure(control, message.what, reason)
            oneShotRequests.remove(requestId, control)
            control.watchdog?.cancel(false)
            control.watchdog = null
            return
        }
        control.job = scope.launch {
            try {
                if (message.what == CMD_DIAGNOSTIC) {
                    control.phase.set("fgs_admission")
                    sendOneShotProgress(control, "IPC accepted • promoting isolated Ben process to foreground")
                }
                if (!beginForegroundWork()) {
                    sendOneShotFailure(control, message.what, "IPC_FGS_PROMOTION_FAILED")
                    return@launch
                }
                if (message.what == CMD_DIAGNOSTIC) {
                    control.phase.set("foreground_ready")
                    sendOneShotProgress(control, "Foreground admission complete • entering diagnostic engine")
                }
                singleFlight.withLock {
                    if (control.cancelled.get()) return@withLock
                    if (Build.VERSION.SDK_INT >= 29 && (powerManager?.currentThermalStatus ?: PowerManager.THERMAL_STATUS_NONE) >= PowerManager.THERMAL_STATUS_SEVERE) {
                        sendOneShotFailure(control, message.what, "Thermal safety gate denied neural operation")
                        return@withLock
                    }
                    if (message.what == CMD_DIAGNOSTIC) {
                        control.phase.set("admission")
                        sendOneShotProgress(control, "Starting full EmbeddingGemma contract + NPU test")
                    }
                    handleOneShot(message, control)
                }
            } finally {
                control.watchdog?.cancel(false)
                control.watchdog = null
                oneShotRequests.remove(requestId, control)
                endForegroundWork()
            }
        }
    }

    private suspend fun handleOneShot(message: Message, control: OneShotControl) {
        val reply = control.reply
        if (control.cancelled.get()) return
        val result = when (message.what) {
            CMD_RERANK -> runCatching {
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                val query = benIpcGetText(message.data, KEY_QUERY)
                val candidates = message.data.getStringArrayList(KEY_CANDIDATES) ?: arrayListOf()
                val limit = message.data.getInt(KEY_LIMIT, 8)
                embedding!!.rerank(query, candidates.mapIndexed { index, text -> Candidate(index, text) }, { it.text }, limit.coerceIn(1, 8))
            }.getOrNull()?.let { r -> Bundle().apply {
                putIntArray(KEY_INDICES, r.hits.map { it.item.index }.toIntArray())
                putDoubleArray(KEY_SCORES, r.hits.map { it.similarity }.toDoubleArray())
                putLong(KEY_ELAPSED, r.elapsedMs)
                putBoolean(KEY_USED_MODEL, r.usedModel)
                putBoolean(KEY_FAILED, false)
            }} ?: Bundle().apply { putBoolean(KEY_FAILED, true) }
            CMD_DIAGNOSTIC -> runCatching {
                control.phase.set("engine_start")
                sendOneShotProgress(control, "Initializing EmbeddingGemma runtime • first run may take around 20 seconds")
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                control.phase.set("diagnostic")
                embedding!!.diagnostic { progress ->
                    control.phase.set(progress.take(80))
                    sendOneShotProgress(control, progress)
                }
            }.getOrNull()?.let { Bundle().apply { putString(KEY_REPORT, it); putBoolean(KEY_FAILED, false) } }
                ?: Bundle().apply { putBoolean(KEY_FAILED, true) }
            CMD_COMPARE -> runCatching {
                if (embedding == null) embedding = BenEmbeddingGemmaEngine(applicationContext)
                embedding!!.compare(benIpcGetText(message.data, KEY_FIRST), benIpcGetText(message.data, KEY_SECOND))
            }.getOrNull()?.let { Bundle().apply { putDouble(KEY_SCORE, it); putBoolean(KEY_FAILED, false) } }
                ?: Bundle().apply { putDouble(KEY_SCORE, Double.NaN); putBoolean(KEY_FAILED, true) }
            else -> Bundle().apply { putBoolean(KEY_FAILED, true) }
        }
        if (control.cancelled.get()) return
        if (message.what == CMD_DIAGNOSTIC) {
            control.phase.set("complete")
            sendOneShotProgress(control, "Diagnostic complete • publishing report")
        }
        if (!control.terminalSent.compareAndSet(false, true)) return
        result.putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
        result.putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
        sendReply(reply, when (message.what) {
            CMD_RERANK -> REPLY_RERANK
            CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
            else -> REPLY_COMPARE
        }, result)
    }

    private data class Candidate(val index: Int, val text: String)

    private fun sendOneShotProgress(control: OneShotControl, progress: String) {
        val reply = control.reply ?: return
        sendReply(reply, REPLY_DIAGNOSTIC_PROGRESS, Bundle().apply {
            putString(KEY_REQUEST_ID, control.requestId)
            putLong(KEY_CLIENT_GENERATION, control.clientGeneration)
            putString(KEY_PROGRESS, progress.take(220))
        })
    }

    private fun sendCommandFailure(message: Message, error: String) {
        val replyCode = when (message.what) {
            CMD_PING -> REPLY_PING
            CMD_RERANK -> REPLY_RERANK
            CMD_DIAGNOSTIC -> REPLY_DIAGNOSTIC
            CMD_COMPARE -> REPLY_COMPARE
            else -> REPLY_GENERATE
        }
        sendReply(message.replyTo, replyCode, Bundle().apply {
            putString(KEY_REQUEST_ID, message.data.getString(KEY_REQUEST_ID).orEmpty())
            putLong(KEY_CLIENT_GENERATION, message.data.getLong(KEY_CLIENT_GENERATION))
            putBoolean(KEY_FAILED, true)
            putBoolean(KEY_OK, false)
            putString(KEY_ERROR, error)
            if (message.what == CMD_COMPARE) putDouble(KEY_SCORE, Double.NaN)
        })
    }

    private fun sendReply(target: Messenger?, what: Int, data: Bundle) {
        if (target == null) {
            BenNeuralTelemetry.error("IPC reply dropped: null reply Messenger; what=$what")
            return
        }
        val outbound = Bundle(data)
        val sharedResources = mutableListOf<android.os.SharedMemory>()
        listOf(KEY_TEXT, KEY_REPORT, KEY_ERROR).forEach { key ->
            val text = outbound.getString(key) ?: return@forEach
            runCatching { benIpcPutText(outbound, key, text) }
                .onSuccess { memory -> if (memory != null) sharedResources += memory }
                .onFailure { error ->
                    BenNeuralTelemetry.error("IPC shared-memory reply preparation failed: key=$key ${error.javaClass.simpleName}: ${error.message ?: "unknown"}")
                }
        }
        try {
            target.send(Message.obtain(null, what).apply { this.data = outbound })
        } catch (error: Exception) {
            BenNeuralTelemetry.error(
                "IPC reply delivery failed: what=$what ${error.javaClass.simpleName}: ${error.message ?: "unknown"}"
            )
        } finally {
            sharedResources.forEach(::benIpcCloseSharedMemory)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // This is the only FGS admission path. startForegroundService() has a short OS deadline;
        // therefore promote synchronously from the service main thread before doing any Binder
        // or native work. Never dispatch this through IO/Default or wait on a latch here.
        if (intent?.getBooleanExtra(EXTRA_FOREGROUND_REQUESTED, false) == true) {
            foregroundRequested = true
            if (!promoteForegroundIfNeeded()) {
                BenNeuralTelemetry.error("FGS admission failed at onStartCommand: ${foregroundFailure ?: "unknown"}")
            }
        }
        // The service is deliberately START_NOT_STICKY: Ben's neural runtime is disposable.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder {
        lifecycleHandler.removeCallbacks(warmTrimRunnable)
        if (intent?.getBooleanExtra(EXTRA_FOREGROUND_REQUESTED, false) == true) {
            foregroundRequested = true
            promoteForegroundIfNeeded()
        } else if (foregroundRequested && !foregroundPromoted.get()) {
            promoteForegroundIfNeeded()
        }
        return messenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        requests.values.forEach { it.cancel() }
        oneShotRequests.values.forEach { it.cancelled.set(true) }
        // Keep a successfully initialized runtime warm for a short bounded window. This avoids
        // paying EmbeddingGemma's ~20 s cold initialization for every isolated request, while
        // still trimming deterministically when the process becomes idle.
        lifecycleHandler.removeCallbacks(warmTrimRunnable)
        lifecycleHandler.postDelayed(warmTrimRunnable, WARM_RUNTIME_TTL_MS)
        return false
    }

    override fun onDestroy() {
        shuttingDown.set(true)
        foregroundRequested = false
        foregroundFailure = null
        lifecycleHandler.removeCallbacks(warmTrimRunnable)
        if (Build.VERSION.SDK_INT >= 29) runCatching { thermalListener?.let { powerManager?.removeThermalStatusListener(it) } }
        requests.values.forEach { it.cancel() }
        oneShotRequests.values.forEach { it.cancelled.set(true) }
        // Do not synchronously close native runtimes from Service.onDestroy(). onDestroy() can
        // run while the service coroutine is still returning from native inference; direct close
        // here would reintroduce the exact concurrent-close race this barrier prevents. The
        // isolated process is disposable, so OS process teardown is the final cleanup boundary.
        scope.coroutineContext[Job]?.cancel()
        ipcWatchdog.shutdownNow()
        handlerThread.quitSafely()
        // Defensive: the coroutine finally blocks normally pair every beginForegroundWork()
        // with endForegroundWork(), but if the service is torn down mid-request, make sure
        // the wake lock does not outlive the process.
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        super.onDestroy()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) {
            scope.launch { singleFlight.withLock { closeRuntimes() } }
        }
    }

    private fun bundleSizeBytes(bundle: Bundle): Int {
        return runCatching {
            val parcel = Parcel.obtain()
            return try {
                bundle.writeToParcel(parcel, 0)
                parcel.dataSize()
            } finally {
                parcel.recycle()
            }
        }.getOrDefault(Int.MAX_VALUE)
    }

    private fun closeRuntimes() {
        runCatching { generator?.close() }
        generator = null
        generatorWarm = false
        runCatching { embedding?.close() }
        embedding = null
        embeddingWarm = false
    }

    companion object {
        const val CMD_GENERATE = 1
        const val CMD_RERANK = 2
        const val CMD_PING = 3
        const val CMD_DIAGNOSTIC = 4
        const val CMD_COMPARE = 5
        const val CMD_CANCEL = 6
        const val CMD_FGS_ADMISSION = 7
        const val REPLY_GENERATE = 101
        const val REPLY_RERANK = 102
        const val REPLY_DIAGNOSTIC = 104
        const val REPLY_COMPARE = 105
        const val REPLY_PING = 103
        const val REPLY_TOKEN = 106
        const val REPLY_DIAGNOSTIC_PROGRESS = 107
        const val REPLY_FGS_ADMISSION = 108
        const val KEY_REQUEST_ID = "requestId"
        const val KEY_CLIENT_GENERATION = "clientGeneration"
        const val KEY_PROMPT = "prompt"
        const val KEY_MAX_TOKENS = "maxTokens"
        const val KEY_QUERY = "query"
        const val KEY_CANDIDATES = "candidates"
        const val KEY_LIMIT = "limit"
        const val KEY_TEXT = "text"
        const val KEY_TOKEN = "token"
        const val KEY_INDICES = "indices"
        const val KEY_SCORES = "scores"
        const val KEY_ELAPSED = "elapsedMs"
        const val KEY_USED_MODEL = "usedModel"
        const val KEY_FAILED = "failed"
        const val KEY_CANCELLED = "cancelled"
        const val KEY_ERROR = "error"
        const val KEY_OK = "ok"
        const val KEY_REPORT = "report"
        const val KEY_PROGRESS = "progress"
        const val KEY_FIRST = "first"
        const val KEY_SECOND = "second"
        const val KEY_SCORE = "score"
        const val EXTRA_FOREGROUND_REQUESTED = "foregroundRequested"
        private const val CANCEL_GRACE_MS = 2_500L
        private const val GENERATION_HARD_TIMEOUT_MS = 45_000L
        private const val ONE_SHOT_HARD_TIMEOUT_MS = 30_000L
        private const val DIAGNOSTIC_PREKILL_MS = 100_000L
        private const val DIAGNOSTIC_HARD_TIMEOUT_MS = 120_000L
        private const val DIAGNOSTIC_KILL_GRACE_MS = 2_500L
        private const val FOREGROUND_CHANNEL_ID = "ben_inference_foreground"
        private const val FOREGROUND_PROMOTION_WAIT_MS = 2_000L
        private const val FOREGROUND_NOTIFICATION_ID = 4171
        // Slightly longer than the longest hard deadline in this file (DIAGNOSTIC_HARD_TIMEOUT_MS)
        // so the lock cannot expire out from under a legitimately still-running diagnostic; every
        // acquire() is still paired with a release() in endForegroundWork()/onDestroy(), this is
        // only a backstop against a leaked wake lock outliving its request.
        private const val WAKE_LOCK_TIMEOUT_MS = 130_000L
        // Evidence-driven warm retention: the verified SM8650 cold init is ~20 s while warm
        // inference is ~100 ms. Keep the native runtime for 120 s after unbind, then trim.
        private const val WARM_RUNTIME_TTL_MS = 120_000L
        private const val MAX_IPC_PAYLOAD_BYTES = 128 * 1024
        private const val TOKEN_BATCH_WINDOW_MS = 50L
        private const val TOKEN_BATCH_MAX_CHARS = 8 * 1024
    }
}
