package com.localqbank.library

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView

/**
 * Deterministic chat chrome controller.
 *
 * The WebView owns the scroll gesture; the controller only reacts to its committed scrollY.
 * This avoids the old ViewTreeObserver race where programmatic transcript scrolling could make
 * header/footer animations fight the user's gesture. It can collapse either bottom-only chrome
 * (Frankenstein) or both top+bottom chrome (Ben+AI).
 */
class RovexChatChromeController(
    private val web: WebView,
    private val topChrome: ViewGroup,
    private val bottomChrome: ViewGroup,
    private val reveal: View,
    private val keepExpanded: () -> Boolean = { false },
    private val collapseTop: Boolean = true,
    private val revealAtBottom: Boolean = false
) {
    private var lastY = 0
    private var hidden = false
    private var programmaticUntil = 0L

    init {
        reveal.contentDescription = "Show chat controls"
        reveal.setOnClickListener { show() }
        reveal.visibility = View.GONE
        positionReveal()
        web.setOnScrollChangeListener { _, scrollY, _, _, _ ->
            if (!web.isShown || keepExpanded()) return@setOnScrollChangeListener
            if (System.currentTimeMillis() < programmaticUntil) {
                lastY = scrollY
                return@setOnScrollChangeListener
            }
            val delta = scrollY - lastY
            // Android WebView reports tiny oscillations while momentum settles. Ignore them.
            if (!hidden && scrollY > 64 && delta > 6) hide()
            else if (hidden && (delta < -6 || scrollY <= 12)) show()
            lastY = scrollY
        }
        web.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = Unit
            override fun onViewDetachedFromWindow(v: View) {
                web.setOnScrollChangeListener(null)
            }
        })
    }

    private fun positionReveal() {
        val lp = reveal.layoutParams as? ViewGroup.MarginLayoutParams ?: return
        lp.bottomMargin = if (revealAtBottom) 6 else 0
        lp.topMargin = if (revealAtBottom) 0 else 6
        lp.marginEnd = 6
        reveal.layoutParams = lp
        reveal.translationZ = 20f
    }

    /** Call after a transcript load that intentionally jumps to the newest answer. */
    fun markProgrammaticScroll(windowMs: Long = 450L) {
        programmaticUntil = System.currentTimeMillis() + windowMs
        lastY = web.scrollY
    }

    fun show() {
        if (!hidden) return
        hidden = false
        reveal.visibility = View.GONE
        if (collapseTop) topChrome.visibility = View.VISIBLE
        bottomChrome.visibility = View.VISIBLE
        if (collapseTop) topChrome.animate().cancel()
        bottomChrome.animate().cancel()
        if (collapseTop) {
            topChrome.alpha = 0f
            topChrome.animate().alpha(1f).setDuration(140L).start()
        }
        bottomChrome.alpha = 0f
        bottomChrome.animate().alpha(1f).setDuration(140L).start()
    }

    fun hide() {
        if (hidden || keepExpanded()) return
        hidden = true
        if (collapseTop) {
            topChrome.animate().alpha(0f).setDuration(110L).withEndAction {
                if (hidden) topChrome.visibility = View.GONE
            }.start()
        }
        bottomChrome.animate().alpha(0f).setDuration(110L).withEndAction {
            if (hidden) bottomChrome.visibility = View.GONE
        }.start()
        reveal.visibility = View.VISIBLE
        reveal.alpha = 0f
        reveal.animate().alpha(0.96f).setDuration(110L).start()
    }
}
