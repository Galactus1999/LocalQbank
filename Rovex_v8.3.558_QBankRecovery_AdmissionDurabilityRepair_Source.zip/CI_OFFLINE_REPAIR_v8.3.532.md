# v8.3.532 Offline CI Repair

The v8.3.532 source transport repair itself is retained unchanged.

## Root cause repaired
GitHub Actions was failing inside `android-actions/setup-android@v3` because the action attempted to install the obsolete SDK package `tools`:

`Warning: Failed to find package 'tools'`

The runner already contains the Android SDK at `/usr/local/lib/android/sdk`. The repaired workflow therefore:

- does not invoke `android-actions/setup-android@v3`;
- explicitly selects the runner's installed SDK;
- verifies `cmdline-tools/16.0/bin/sdkmanager` exists;
- installs/validates only the required platform-tools, Android 37 platform, and build-tools 37.0.0;
- proceeds to Kotlin compile, unit tests, APK build, identity verification and proof packaging.

This repair does **not** claim Android compilation is verified offline on the current model container; this container has no Android SDK installed.
