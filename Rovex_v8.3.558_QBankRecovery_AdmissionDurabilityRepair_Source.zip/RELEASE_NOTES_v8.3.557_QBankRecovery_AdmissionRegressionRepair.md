# Rovex v8.3.557 — QBank Recovery Admission Regression Repair

## Scope
Follow-up audit of v8.3.556 DeviceIdle recovery admission and related QBank-library Activity paths.

## Finding
The v8.3.556 worker correctly requested `setRequiresDeviceIdle(true)`, but a pre-v8.3.556 uniquely named WorkManager request could already exist without the new constraint. Because the admission path used `ExistingWorkPolicy.KEEP`, that stale request could survive the repair and continue running outside the intended DeviceIdle boundary.

## Repair
Added a durable recovery-admission version fence. On the first admission after the DeviceIdle contract upgrade, Rovex cancels the old unique request once, records admission version `556`, and then enqueues the constrained request. Subsequent calls use `KEEP` and do not create a chain.

## Activity regression audit
Reviewed the interactive deletion path in `MainQBankLibraryActivity` and `MainViewModel`. The Activity still performs only the durable tombstone request, updates the library order off the foreground path, invalidates catalog/performance state, and reloads the catalog after acceptance. No destructive SQLite cleanup was moved back onto the Activity thread. No confirmed Activity regression was found.

## Never-idle contract
If the device never enters DeviceIdle, the physical deletion worker remains inadmissible. The source remains tombstoned/hidden and recoverable; unrelated QBanks remain untouched.

## Verification boundary
Static/source audit only for this batch. Android compile, CI, instrumented tests, and device validation remain pending.
