package com.localqbank.library

/** Pure SQL/query construction for QBank text-search fallback paths. */
internal object QBankSearchQueryBuilder {
    data class QueryPlan(val sql: String, val args: List<String>)

    private const val SELECT = "SELECT q.id,q.test_id,t.title,q.position,q.source_question_id,q.text,t.path,COALESCE(s.display_name,s.file_name) " +
        "FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 "

    private fun fieldClause(): String =
        "(q.text LIKE ? ESCAPE CHAR(92) OR q.raw_text LIKE ? ESCAPE CHAR(92) OR " +
        "q.correct_answer LIKE ? ESCAPE CHAR(92) OR q.explanation LIKE ? ESCAPE CHAR(92) OR " +
        "q.bot LIKE ? ESCAPE CHAR(92) OR q.video LIKE ? ESCAPE CHAR(92) OR q.audio LIKE ? ESCAPE CHAR(92) OR " +
        "t.title LIKE ? ESCAPE CHAR(92) OR COALESCE(t.path,'') LIKE ? ESCAPE CHAR(92) OR " +
        "COALESCE(s.display_name,s.file_name) LIKE ? ESCAPE CHAR(92) OR " +
        "EXISTS(SELECT 1 FROM option_item o WHERE o.question_id=q.id AND " +
        "(o.label LIKE ? ESCAPE CHAR(92) OR o.text LIKE ? ESCAPE CHAR(92))))"

    fun textLikePlan(tokens: List<String>, limit: Int, requireAll: Boolean): QueryPlan {
        require(tokens.isNotEmpty()) { "tokens must not be empty" }
        val clauses = tokens.map { fieldClause() }
        val args = tokens.flatMap { token ->
            val like = QBankSearchSql.likePattern(token)
            List(12) { like }
        }
        val joiner = if (requireAll) " AND " else " OR "
        return QueryPlan(
            sql = SELECT +
                "WHERE ${clauses.joinToString(joiner)} " +
                "ORDER BY s.imported_at DESC,t.rowid,q.position LIMIT ${limit.coerceIn(1, 1200)}",
            args = args
        )
    }
}
