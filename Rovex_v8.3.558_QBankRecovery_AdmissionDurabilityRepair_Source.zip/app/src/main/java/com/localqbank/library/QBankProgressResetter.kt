package com.localqbank.library

import android.database.sqlite.SQLiteDatabase

/**
 * Owns the transactional learner-state reset operations used by QBankDb.
 * Content and immutable study history are deliberately outside this component's scope.
 */
internal class QBankProgressResetter(
    private val dbProvider: () -> SQLiteDatabase,
    private val sourceNameForId: (Long) -> String?
) {
    private val db: SQLiteDatabase
        get() = dbProvider()
    fun resetTestProgress(testId: String): Boolean {
        val id = testId.trim()
        if (id.isBlank()) return false
        return try {
            db.beginTransactionNonExclusive()
            try {
                db.delete("progress_v2", "test_id=?", arrayOf(id))
                db.delete(
                    "progress",
                    "question_id IN (SELECT id FROM question WHERE test_id=?)",
                    arrayOf(id)
                )
                val keys = arrayOf("$id:position", "$id:completed")
                db.delete("progress_meta", "meta_key IN (?,?)", keys)
                listOf("last_resume_global", "last_solved_global").forEach { key ->
                    val raw = progressMeta(key)
                    val parts = raw?.split("|", limit = 4).orEmpty()
                    if (parts.getOrNull(0) == id) {
                        db.delete("progress_meta", "meta_key=?", arrayOf(key))
                    }
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun resetSourceProgress(sourceId: Long): Boolean {
        if (sourceId <= 0L) return false
        return try {
            db.beginTransactionNonExclusive()
            try {
                val testIds = db.rawQuery(
                    "SELECT id FROM test WHERE source_id=?",
                    arrayOf(sourceId.toString())
                ).use { c -> buildList { while (c.moveToNext()) add(c.getString(0)) } }

                db.delete(
                    "progress_v2",
                    "test_id IN (SELECT id FROM test WHERE source_id=?)",
                    arrayOf(sourceId.toString())
                )
                db.delete(
                    "progress",
                    "question_id IN (SELECT q.id FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?)",
                    arrayOf(sourceId.toString())
                )

                db.delete(
                    "progress_meta",
                    "meta_key=? OR meta_key=?",
                    arrayOf("source:$sourceId:resume", "sourceName:${sourceNameForId(sourceId)}:resume")
                )
                if (testIds.isNotEmpty()) {
                    val keys = testIds.flatMap { listOf("$it:position", "$it:completed") }.toTypedArray()
                    val placeholders = keys.joinToString(",") { "?" }
                    db.delete("progress_meta", "meta_key IN ($placeholders)", keys)
                }
                listOf("last_resume_global", "last_solved_global").forEach { key ->
                    val raw = progressMeta(key)
                    val parts = raw?.split("|", limit = 4).orEmpty()
                    if (parts.getOrNull(2)?.toLongOrNull() == sourceId) {
                        db.delete("progress_meta", "meta_key=?", arrayOf(key))
                    }
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun progressMeta(key: String): String? =
        db.rawQuery("SELECT meta_value FROM progress_meta WHERE meta_key=? LIMIT 1", arrayOf(key)).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
}
