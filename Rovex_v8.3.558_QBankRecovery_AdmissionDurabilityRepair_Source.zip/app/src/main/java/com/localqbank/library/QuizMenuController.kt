package com.localqbank.library

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.ScaleAnimation
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Presentation-only controller for QuizActivity question/settings/bookmark menus. */
class QuizMenuController(
    private val context: Context,
    private val quizViewModel: QuizViewModel,
    private val scroll: View,
    private val dp: (Int) -> Int,
    private val rounded: (Int, Float) -> GradientDrawable,
    private val actionButton: (String, Int, Float, () -> Unit) -> TextView,
    private val getFontScale: () -> Float,
    private val setFontScale: (Float) -> Unit,
    private val getFontFamily: () -> String,
    private val setFontFamily: (String) -> Unit,
    private val getHeaderMm: () -> Float,
    private val setHeaderMm: (Float) -> Unit,
    private val uiPreferences: QuizUiPreferences,
    private val persistPosition: () -> Unit,
    private val showQuestion: () -> Unit,
    private val applyHeaderHeight: () -> Unit,
    private val showCelebrationPlanner: () -> Unit,
    private val recreateQuestion: () -> Unit,
    private val captureAutoNote: (Question, (KnowledgeEngineManager.Result) -> Unit) -> Unit
) {
    fun showQuestionJumpMenu(anchor: View) {
        if (quizViewModel.state.questionCount == 0) return
        val popup = PopupWindow(context).apply {
            width = dp(290)
            height = dp(190)
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(14).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(ThemeManager.elevated(context)); cornerRadius = dp(20).toFloat()
                setStroke(dp(1), if (ThemeManager.isDark(context)) Color.rgb(55,69,86) else Color.rgb(210,223,231))
            }
        }
        val heading = TextView(context).apply {
            text = "Jump to question"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ThemeManager.text(context))
        }
        box.addView(heading, LinearLayout.LayoutParams(-1, dp(28)))
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(context).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 17f
            gravity = Gravity.CENTER
            setSingleLine(true)
            setSelectAllOnFocus(true)
            hint = "1 – ${quizViewModel.state.questionCount}"
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(ThemeManager.optionBg(context), 12f)
        }
        input.setText((quizViewModel.state.position + 1).toString())
        row.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val go = actionButton("GO", Color.rgb(27, 128, 91), 14f) {
            val n = input.text.toString().toIntOrNull()
            if (n != null && n in 1..quizViewModel.state.questionCount) {
                quizViewModel.moveToPosition(n - 1)
                popup.dismiss()
                showQuestion()
            } else input.error = "Enter 1–${quizViewModel.state.questionCount}"
        }
        row.addView(go, LinearLayout.LayoutParams(dp(78), dp(52)).apply { setMargins(dp(10), 0, 0, 0) })
        box.addView(row, LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(8), 0, 0) })
        val hint = TextView(context).apply {
            text = "Swipe left/right to move one question"
            textSize = 12f
            setTextColor(ThemeManager.muted(context))
            gravity = Gravity.CENTER
        }
        box.addView(hint, LinearLayout.LayoutParams(-1, dp(28)).apply { setMargins(0, dp(5), 0, 0) })
        popup.contentView = box
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        popup.showAtLocation(scroll, Gravity.TOP or Gravity.END, dp(12), (loc[1] + dp(48)).coerceAtLeast(dp(50)))
        if (AnimationPolicy.enabled(context)) box.startAnimation(ScaleAnimation(.94f, 1f, .94f, 1f, 1f, 0f).apply { duration = 160 })
        input.requestFocus()
        input.post { (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) }
    }

    fun showSettingsMenu(anchor: View) {
        val popup = PopupWindow(context).apply {
            width = (context.resources.displayMetrics.widthPixels * 0.92f).toInt().coerceAtMost(dp(390))
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            isOutsideTouchable = true
            elevation = dp(20).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
        }
        val dark = ThemeManager.isDark(context)
        val border = if (dark) Color.rgb(48,61,75) else Color.rgb(216,224,231)
        val scrollPanel = ScrollView(context).apply { isFillViewport = true; setBackgroundColor(Color.TRANSPARENT) }
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(ThemeManager.elevated(context)); cornerRadius = dp(26).toFloat(); setStroke(dp(1), border) }
        }
        fun heading(text: String, sub: String? = null) {
            box.addView(TextView(context).apply { this.text=text; textSize=19f; setTypeface(null,Typeface.BOLD); setTextColor(ThemeManager.text(context)) }, LinearLayout.LayoutParams(-1,dp(30)))
            if (sub != null) box.addView(TextView(context).apply { this.text=sub; textSize=11.5f; setTextColor(ThemeManager.muted(context)); setPadding(0,dp(1),0,dp(12)) }, LinearLayout.LayoutParams(-1,dp(28)))
        }
        fun label(text: String) = TextView(context).apply { this.text=text; textSize=11.5f; setTypeface(null,Typeface.BOLD); setTextColor(ThemeManager.muted(context)); setPadding(0,dp(10),0,dp(6)) }
        fun tile(text: String, selected: Boolean = false, click: () -> Unit): TextView = TextView(context).apply {
            this.text=text; textSize=12f; gravity=Gravity.CENTER; setTypeface(null,Typeface.BOLD)
            setTextColor(if(selected)ThemeManager.accent(context) else ThemeManager.text(context))
            background=GradientDrawable().apply { setColor(if(selected)ThemeManager.explanationBg(context) else ThemeManager.panel(context)); cornerRadius=dp(13).toFloat(); setStroke(dp(1),if(selected)ThemeManager.accent(context) else border) }
            setOnClickListener { click() }
        }
        heading("Question settings", "Tune the reading surface without leaving your question.")
        box.addView(label("TEXT SIZE  •  ${"%.0f".format(getFontScale() * 100)}%"))
        val fs = QuizFontScaleSeekBarController(context, getFontScale(), { value -> setFontScale(value); uiPreferences.setFontScale(value) }, { popup.dismiss(); showQuestion() }).create()
        box.addView(fs, LinearLayout.LayoutParams(-1,dp(34)))
        box.addView(label("FONT"))
        val fonts=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL}
        listOf("sans-serif" to "Modern","serif" to "Textbook","sans-serif-condensed" to "Compact").forEachIndexed{i,pair->
            val b=tile(pair.second,getFontFamily()==pair.first){setFontFamily(pair.first);uiPreferences.setFontFamily(pair.first);popup.dismiss();showQuestion()}
            fonts.addView(b,LinearLayout.LayoutParams(0,dp(40),1f).apply{if(i>0)setMargins(dp(6),0,0,0)})
        }
        box.addView(fonts,LinearLayout.LayoutParams(-1,dp(40)))
        box.addView(label("HEADER DENSITY"))
        val heights=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL}
        listOf(8f to "Compact",10f to "Balanced",12f to "Roomy").forEachIndexed{i,pair->
            val b=tile(pair.second,kotlin.math.abs(getHeaderMm()-pair.first)<.01f){setHeaderMm(pair.first);uiPreferences.setHeaderMm(pair.first);popup.dismiss();persistPosition();applyHeaderHeight()}
            heights.addView(b,LinearLayout.LayoutParams(0,dp(40),1f).apply{if(i>0)setMargins(dp(6),0,0,0)})
        }
        box.addView(heights,LinearLayout.LayoutParams(-1,dp(40)))
        box.addView(label("APPEARANCE"))
        val themes=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL}
        listOf(ThemeManager.LIGHT to "Light",ThemeManager.PASTEL to "Pastel",ThemeManager.MINT to "Mint",ThemeManager.SUNSET to "Sunset",ThemeManager.LAVENDER to "Lavender",ThemeManager.AMOLED to "AMOLED").forEachIndexed{i,pair->
            val b=tile(pair.second,ThemeManager.get(context)==pair.first){ThemeManager.set(context,pair.first);popup.dismiss();recreateQuestion()}
            themes.addView(b,LinearLayout.LayoutParams(0,dp(40),1f).apply{if(i>0)setMargins(dp(6),0,0,0)})
        }
        box.addView(themes,LinearLayout.LayoutParams(-1,dp(40)))
        box.addView(tile("CELEBRATION LAB"){popup.dismiss();showCelebrationPlanner()},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(0,dp(10),0,dp(4))})
        box.addView(tile("CREATE AUTO NOTE"){quizViewModel.state.currentQuestion?.let{q->captureAutoNote(q){r->if(AppManagers.isReady())AppManagers.adaptive.onEvent("knowledge_captured",(r.tablesSaved+r.imagesSaved).toLong());Toast.makeText(context,"Auto note saved • ${r.tablesSaved} tables • ${r.imagesSaved} images",Toast.LENGTH_SHORT).show()}}},LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(0,dp(4),0,dp(4))})
        scrollPanel.addView(box,ViewGroup.LayoutParams(-1,-2))
        popup.contentView=scrollPanel
        val x=((context.resources.displayMetrics.widthPixels-popup.width)/2).coerceAtLeast(dp(8))
        val safeTop=(scroll.rootView.getTag(R.id.adaptiveSafeTop) as? Int) ?: dp(32)
        popup.showAtLocation(scroll,Gravity.TOP or Gravity.START,x,safeTop+dp(8))
        if(AnimationPolicy.enabled(context))box.startAnimation(ScaleAnimation(.96f,1f,.96f,1f,.5f,.08f).apply{duration=180})
    }

    fun showBookmarkMenu(anchor: View) {
        if (quizViewModel.state.questionCount == 0) return
        val popup=PopupWindow(context).apply{width=dp(336);height=dp(276);isFocusable=true;isOutsideTouchable=true;elevation=dp(14).toFloat();setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))}
        val box=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(14));background=GradientDrawable().apply{setColor(ThemeManager.elevated(context));cornerRadius=dp(20).toFloat();setStroke(dp(1),if(ThemeManager.isDark(context))Color.rgb(55,69,86)else Color.rgb(205,220,231))};elevation=dp(8).toFloat()}
        box.addView(TextView(context).apply{text="Bookmark category";textSize=17f;setTypeface(null,Typeface.BOLD);setTextColor(ThemeManager.text(context));setPadding(dp(6),dp(2),dp(6),dp(10))})
        val grid=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL}
        val values=listOf("important" to "★  Important","revise" to "↻  Revise","doubt" to "❔  Doubt","favorite" to "♥  Favourite")
        val current = quizViewModel.state.currentQuestion?.let { quizViewModel.bookmark(it.stableKey) }
        for(r in 0..1){val row=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL};for(c in 0..1){val pair=values[r*2+c];val b=actionButton(pair.second,ThemeManager.bookmarkFill(context,pair.first),14.5f){quizViewModel.state.currentQuestion?.let{q->val next=if(quizViewModel.bookmark(q.stableKey)==pair.first)null else pair.first;quizViewModel.setBookmark(q.stableKey,next);if(AppManagers.isReady())AppManagers.adaptive.onEvent("bookmark_changed")};quizViewModel.persistPosition();popup.dismiss();showQuestion()};b.setTextColor(ThemeManager.bookmarkText(context,pair.first));row.addView(b,LinearLayout.LayoutParams(0,dp(82),1f).apply{setMargins(if(c==0)0 else dp(6),dp(4),if(c==0)dp(6)else 0,dp(4))})};grid.addView(row,LinearLayout.LayoutParams(-1,dp(90)))}
        box.addView(grid);
        if (!current.isNullOrBlank()) {
            box.addView(actionButton("✕  Remove current bookmark", ThemeManager.elevated(context), 13.5f) {
                quizViewModel.state.currentQuestion?.let { q -> quizViewModel.setBookmark(q.stableKey, null); if (AppManagers.isReady()) AppManagers.adaptive.onEvent("bookmark_changed") }
                quizViewModel.persistPosition(); popup.dismiss(); showQuestion()
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        }
        popup.contentView=box;popup.setOnDismissListener{};popup.showAtLocation(scroll,Gravity.TOP or Gravity.END,dp(10),popupTopY(anchor))
        val anim=AnimationSet(true).apply{addAnimation(ScaleAnimation(.92f,1f,.92f,1f,1f,.5f).apply{duration=170});addAnimation(AlphaAnimation(.25f,1f).apply{duration=170})};if(AnimationPolicy.enabled(context))box.startAnimation(anim)
    }

    private fun popupTopY(anchor: View): Int { val loc=IntArray(2);anchor.getLocationOnScreen(loc);return(loc[1]+dp(8)).coerceAtLeast(dp(44)) }
}
