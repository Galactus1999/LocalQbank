package com.localqbank.library

import java.util.Calendar

/**
 * Deterministic personal-progress projection used when no server-side aggregate function is
 * available. It reads the existing local study state and never creates or mutates study records.
 *
 * This is intentionally a personal projection, not a server-authoritative competitive score.
 */
object RovexOnlineProgressProjector {
    data class Projection(
        val questionsSolved: Int,
        val correct: Int,
        val accuracyPercent: Int,
        val todaySolved: Int,
        val flashcardsReviewed: Int,
        val currentStreak: Int,
        val longestStreak: Int,
        val xp: Long,
        val updatedAtMillis: Long
    )

    fun from(
        progress: ProgressSnapshot,
        flashcardsReviewed: Int,
        streak: StreakManager.Snapshot,
        nowMillis: Long = System.currentTimeMillis()
    ): Projection {
        val rows = progress.all().values
        val answered = rows.filter { it.status == "correct" || it.status == "wrong" }
        val solved = answered.size
        val correct = answered.count { it.status == "correct" }
        val todayStart = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val todaySolved = answered.count { it.lastAttempted >= todayStart }
        val cards = flashcardsReviewed.coerceAtLeast(0)
        val xp = solved.toLong() * 10L + correct.toLong() * 15L + cards.toLong() * 5L
        return Projection(
            questionsSolved = solved,
            correct = correct,
            accuracyPercent = if (solved == 0) 0 else correct * 100 / solved,
            todaySolved = todaySolved,
            flashcardsReviewed = cards,
            currentStreak = streak.currentStreak.coerceAtLeast(0),
            longestStreak = streak.longestStreak.coerceAtLeast(0),
            xp = xp,
            updatedAtMillis = nowMillis
        )
    }
}
