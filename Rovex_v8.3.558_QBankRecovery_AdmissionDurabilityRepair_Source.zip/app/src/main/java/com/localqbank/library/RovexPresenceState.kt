package com.localqbank.library

/** Pure, deterministic reducer for multi-device presence snapshots. */
object RovexPresenceState {
    data class Connection(val online: Boolean, val lastChangedMillis: Long?)
    data class State(val online: Boolean, val lastSeenMillis: Long?)

    fun derive(connections: Iterable<Connection>): State = derive(connections, Long.MAX_VALUE, Long.MAX_VALUE)

    fun derive(connections: Iterable<Connection>, nowMillis: Long, onlineTtlMillis: Long): State {
        var online = false
        var latest: Long? = null
        for (connection in connections) {
            val changed = connection.lastChangedMillis
            if (changed != null && (latest == null || changed > latest)) latest = changed
            val fresh = changed != null && nowMillis >= changed && nowMillis - changed <= onlineTtlMillis
            if (connection.online && fresh) online = true
        }
        return State(online, if (online) null else latest)
    }
}
