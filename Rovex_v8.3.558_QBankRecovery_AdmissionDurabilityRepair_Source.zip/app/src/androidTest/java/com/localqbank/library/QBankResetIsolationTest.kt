package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Proves reset clears only learner state for the requested QBank and preserves content/history. */
@RunWith(AndroidJUnit4::class)
class QBankResetIsolationTest {
    private lateinit var db: QBankDb
    private lateinit var raw: android.database.sqlite.SQLiteDatabase

    @Before fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
        db.sources()
        raw = context.openOrCreateDatabase("qbank.db", 0, null)
        raw.execSQL("DELETE FROM study_attempt_history")
        raw.execSQL("DELETE FROM progress_v2")
        raw.execSQL("DELETE FROM progress")
        raw.execSQL("DELETE FROM progress_meta")
        raw.execSQL("DELETE FROM question")
        raw.execSQL("DELETE FROM test")
        raw.execSQL("DELETE FROM source")
        raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(1,'reset.me','Reset Me','test',1)")
        raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(2,'keep.me','Keep Me','test',2)")
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('reset-test',1,'Reset Test','reset',1)")
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('keep-test',2,'Keep Test','keep',1)")
        raw.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(1,'reset-test',0,'r1','reset-question','reset-question')")
        raw.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(2,'keep-test',0,'k1','keep-question','keep-question')")
        raw.execSQL("INSERT INTO progress_v2(stable_key,test_id,status,bookmark,attempts,last_attempted,next_due) VALUES('reset-test:0:r1','reset-test','correct','important',4,100,200)")
        raw.execSQL("INSERT INTO progress_v2(stable_key,test_id,status,bookmark,attempts,last_attempted,next_due) VALUES('keep-test:0:k1','keep-test','wrong','keep',2,100,200)")
        raw.execSQL("INSERT INTO progress(question_id,status,bookmark,attempt_count,last_attempted) VALUES(1,'correct','important',4,100)")
        raw.execSQL("INSERT INTO progress(question_id,status,bookmark,attempt_count,last_attempted) VALUES(2,'wrong','keep',2,100)")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('reset-test:position','0')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('reset-test:completed','1')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('source:1:resume','reset-test|0')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_resume_global','reset-test|0|1|1000')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_solved_global','reset-test|0|1|1000')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('keep-test:position','0')")
        raw.execSQL("INSERT INTO study_attempt_history(stable_key,test_id,source_id,attempted_at,correct,time_ms) VALUES('reset-test:0:r1','reset-test',1,100,1,500)")
        raw.execSQL("INSERT INTO study_attempt_history(stable_key,test_id,source_id,attempted_at,correct,time_ms) VALUES('keep-test:0:k1','keep-test',2,100,0,600)")
    }

    @Test fun resetClearsOnlyTargetQBankProgress() {
        assertTrue(db.resetSourceProgress(1L))

        assertEquals(1, db.questionCount("reset-test"))
        assertEquals(1, db.questionCount("keep-test"))
        assertEquals(0, raw.rawQuery("SELECT COUNT(*) FROM progress_v2 WHERE test_id='reset-test'", null).use { it.moveToFirst(); it.getInt(0) })
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM progress_v2 WHERE test_id='keep-test'", null).use { it.moveToFirst(); it.getInt(0) })
        assertEquals(0, raw.rawQuery("SELECT COUNT(*) FROM progress WHERE question_id=1", null).use { it.moveToFirst(); it.getInt(0) })
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM progress WHERE question_id=2", null).use { it.moveToFirst(); it.getInt(0) })
        assertNull(db.getProgressMeta("reset-test:position"))
        assertNull(db.getProgressMeta("reset-test:completed"))
        assertNull(db.getProgressMeta("source:1:resume"))
        assertNull(db.getProgressMeta("last_resume_global"))
        assertNull(db.getProgressMeta("last_solved_global"))
        assertEquals("0", db.getProgressMeta("keep-test:position"))
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM study_attempt_history WHERE source_id=1", null).use { it.moveToFirst(); it.getInt(0) })
        assertEquals(1, raw.rawQuery("SELECT COUNT(*) FROM study_attempt_history WHERE source_id=2", null).use { it.moveToFirst(); it.getInt(0) })
        assertNotNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
    }

    @Test fun resetDoesNotClearUnrelatedGlobalCursor() {
        raw.execSQL("DELETE FROM progress_meta WHERE meta_key IN ('last_resume_global','last_solved_global')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_resume_global','keep-test|0|2|2000')")
        raw.execSQL("INSERT INTO progress_meta(meta_key,meta_value) VALUES('last_solved_global','reset-test|0|1|2000')")

        assertTrue(db.resetSourceProgress(1L))

        assertEquals("keep-test|0|2|2000", db.getProgressMeta("last_resume_global"))
        assertNull(db.getProgressMeta("last_solved_global"))
    }

}
