#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SEARCH="$ROOT/app/src/main/java/com/localqbank/library/SearchActivity.kt"
FRANK="$ROOT/app/src/main/java/com/localqbank/library/ExperiencePerformanceManager.kt"
COG="$ROOT/app/src/main/java/com/localqbank/library/RenCognitiveEngine.kt"
LOCAL="$ROOT/app/src/main/java/com/localqbank/library/LocalQBankSearchService.kt"
DB="$ROOT/app/src/main/java/com/localqbank/library/QBankSearchQueryBuilder.kt"
fail(){ echo "FAIL: $*" >&2; exit 1; }

grep -Fq 'private val localSearch by lazy { LocalQBankSearchService(app) }' "$FRANK" || fail "Frankenstein shared local-search owner missing"
grep -Fq 'localSearch.search(command, 100' "$FRANK" || fail "Frankenstein deterministic search lane missing"
grep -Fq 'localSearch.searchSections(text, 60)' "$SEARCH" || fail "Main Search hierarchy retrieval missing"
grep -Fq 'localSearch.search(text, 300).hits' "$SEARCH" || fail "Main Search question retrieval missing"
grep -Fq 'private val db = QBankDb(app)' "$LOCAL" || fail "LocalQBankSearchService authoritative DB owner missing"
grep -Fq 'db.search(normalized, safeLimit)' "$LOCAL" || fail "Local search primary retrieval missing"
grep -Fq 'db.searchSections(variant)' "$LOCAL" || fail "Local search hierarchy retrieval missing"
grep -Fq 'WHERE ${clauses.joinToString(joiner)}' "$DB" || fail "LIKE fallback does not support OR recall"
grep -Fq 'require(count > 0) { "This QBank subsection contains no importable questions." }' "$ROOT/app/src/main/java/com/localqbank/library/QuizNavigationUseCase.kt" || fail "Sub-QBank validation missing"

echo 'PASS: Frankenstein deterministic search uses shared bounded local retrieval'
echo 'PASS: Main Search uses shared question + hierarchy retrieval'
echo 'PASS: LocalQBankSearchService owns authoritative QBankDb retrieval'
echo 'PASS: QBank/sub-QBank LIKE fallback supports OR recall'
echo 'PASS: subsection launch validates question-bearing QBank before progress mutation'
