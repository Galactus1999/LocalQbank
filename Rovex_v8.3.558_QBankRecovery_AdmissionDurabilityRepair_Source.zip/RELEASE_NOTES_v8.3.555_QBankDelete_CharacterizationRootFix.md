# Rovex v8.3.555 — QBank Delete Characterization / Root Fix

Scope: begin QBankDb Delete/Reset Stage 3B characterization before any production delete extraction.

Fix found during characterization:
- `QBankDb.deleteSource()` cleared `last_resume_global` when its test belonged to the deleted source, but did not clear the corresponding `last_solved_global` cursor.
- This could leave a global solved cursor pointing at a deleted QBank after physical deletion.
- The delete path now clears both global cursors only when their encoded test ID belongs to the source being deleted.

Regression coverage added:
- Deleted source clears its global resume and solved cursors.
- Unrelated source preservation remains covered.
- A paused/bounded deletion remains tombstoned, preserves physical data for resumable maintenance, keeps unrelated source data intact, and keeps deleted content out of logical search.

Idle/Doze characterization:
- The existing worker is documented as idle-only, but the current WorkManager request does not declare a native device-idle constraint (WorkManager does not expose a direct `DEVICE_IDLE` constraint).
- This batch does not invent a new scheduler policy. The safe half-state is characterized through the bounded/pause delete contract; worker scheduling/Doze policy remains a separate follow-up audit before extraction.

Verification: source/static only; CI, instrumented execution, and device validation pending.
