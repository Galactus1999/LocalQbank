# v8.3.537 — CI compile repair

Repairs the two Kotlin compilation blockers reported by the adaptive Android CI log.

- `MainQBankLibraryActivity`: replace the ambiguous `background = ...` assignment with `setBackground(...)`.
- `QBankDb`: call the owning `QBankDb.getProgressMeta(...)` instead of incorrectly resolving `getProgressMeta` on the raw `SQLiteDatabase` receiver.
- Preserves the v8.3.536 QBankDb search SQL seam and v8.3.535 QBank reset feature.
