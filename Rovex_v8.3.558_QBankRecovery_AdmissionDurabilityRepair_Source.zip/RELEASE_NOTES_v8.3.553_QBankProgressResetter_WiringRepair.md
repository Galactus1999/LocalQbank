# Rovex v8.3.553 — QBankProgressResetter Wiring Repair

## Scope
- Complete the QBankDb Reset/Progress extraction started in v8.3.552.
- Remove duplicated reset implementations from QBankDb.
- Wire QBankDb.resetTestProgress() and resetSourceProgress() to QBankProgressResetter.
- Preserve provider-owned database lifecycle by resolving the current SQLiteDatabase per operation.
- Preserve QBankDb application side effects (AppState.changed and PerformanceManager.invalidateProgress).

## Wired
- YES: both public QBankDb reset methods delegate to QBankProgressResetter.
- QBankProgressResetter is no longer dead/unreferenced production code.

## Verification status
- Static/source audit: PENDING FINAL AUDIT
- Unit/JVM execution: PENDING
- Android compile: PENDING
- CI: PENDING
- Instrumented/device reset test: PENDING

## Explicit non-claims
- No build or runtime PASS is claimed without execution evidence.
