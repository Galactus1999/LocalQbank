# Rovex v8.3.507 — QuizQuestionShowCoordinator Move

## Scope
Move-only decomposition of the remaining `QuizActivity.show()` orchestration after v8.3.506.

## Moved responsibilities
- Clear question content before presentation.
- Zero-question state routing through the existing Activity callback.
- Collection/test question cache-key calculation.
- Synchronized question-cache lookup.
- Existing asynchronous `QuizQuestionLoader` handoff when the question is absent.
- Existing `QuizQuestionStateCoordinator.prepare()` invocation.
- Existing presentation callback invocation.
- Existing post-render callback invocation.

## Preserved behavior
- Existing cache key formats are unchanged.
- Existing question cache synchronization is unchanged.
- Existing question loader is unchanged.
- Existing state coordinator is unchanged.
- Existing `QuizQuestionPresentationRenderer` is unchanged.
- Existing post-render sequence remains: typography -> theme visibility -> motion tree -> scroll-to-top -> prefetch.
- No QBank/database behavior changed.
- No answer/evaluation/audio/celebration behavior changed.
- No Ben/AI behavior changed.

## Architecture safety
`QuizQuestionShowCoordinator` is intentionally short-lived. Its callbacks are supplied for one `show()` call and it is not retained by `QuizActivity` or any long-lived manager. It does not reference `QuizActivity`, `AppCompatActivity`, or `this@QuizActivity`.

## Version
- versionName: `8.3.507`
- versionCode: `597`

## Validation
- Brace/source structural scan: PASS.
- Single `QuizActivity.show()` owner: PASS.
- New coordinator contains no Activity capture: PASS.
- Local Gradle compilation: BLOCKED because Gradle 9.3.1 could not resolve `downloads.gradle.org` in the offline environment.
- CI: PENDING.
- Device: PENDING.
