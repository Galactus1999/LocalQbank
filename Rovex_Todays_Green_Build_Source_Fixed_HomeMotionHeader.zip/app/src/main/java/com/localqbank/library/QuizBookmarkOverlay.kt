package com.localqbank.library

import java.util.concurrent.ConcurrentHashMap

/** Explicit null/presence-safe optimistic overlay for asynchronous bookmark writes. */
internal class QuizBookmarkOverlay {
    private companion object { const val CLEAR="\u0000ROVEX_BOOKMARK_CLEAR" }
    private val values=ConcurrentHashMap<String,String>()
    fun put(key:String,value:String?){ values[key]=value ?: CLEAR }
    fun contains(key:String)=values.containsKey(key)
    fun value(key:String):String?=values[key]?.let{if(it==CLEAR)null else it}
    fun removeIfEquals(key:String,value:String?){ values.remove(key,value ?: CLEAR) }
}
