package com.localqbank.library

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import android.os.SystemClock
import kotlin.math.cos
import kotlin.math.sin

/**
 * Clinical Day home-only visual layer. It is deliberately isolated from the global theme engine
 * so the reference theme can be tuned screen-by-screen without destabilising other themes.
 */
class RovexClinicalDayHomeBackgroundDrawable(
    context: android.content.Context
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var backgroundShader: LinearGradient? = null

    /**
     * Clinical Day is intentionally a static, opaque foundation.
     * Decorative motion belongs in isolated foreground views/layers.
     */
    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        paint.shader = backgroundShader
        if (paint.shader != null) {
            canvas.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
        } else {
            canvas.drawColor(Color.rgb(247, 250, 255))
        }
    }

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        super.onBoundsChange(bounds)
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        backgroundShader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(
                Color.rgb(247, 250, 255),
                Color.rgb(236, 245, 255),
                Color.rgb(255, 247, 238)
            ),
            floatArrayOf(0f, 0.56f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean =
        super.setVisible(visible, restart)
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter }
    override fun getOpacity(): Int = android.graphics.PixelFormat.OPAQUE
}

/** Premium Clinical Day surface: glass-like depth without bitmap assets or heavy blur. */
class RovexClinicalSurfaceDrawable(
    private val radiusPx: Float,
    private val accent: Int,
    private val secondary: Int,
    private val animatedBorder: Boolean = false
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val highlight = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val highlightPath = Path()
    private val highlightRect = RectF()
    private val edgeMatrix = Matrix()
    private var fillShader: LinearGradient? = null
    private var edgeShader: LinearGradient? = null
    private var phase = 0f
    private var running = true
    private val tick = Runnable { invalidateSelf() }

    override fun draw(canvas: Canvas) {
        val r = radiusPx.coerceAtLeast(1f)
        val b = bounds
        rect.set(b.left + 1f, b.top + 1f, b.right - 1f, b.bottom - 1f)
        fill.shader = fillShader
        canvas.drawRoundRect(rect, r, r, fill)
        fill.shader = null

        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 1.15f
        if (animatedBorder && edgeShader != null) {
            val travel = ((phase * 0.055f) % 1f) * (rect.width() + rect.height())
            edgeMatrix.setTranslate(travel, -travel * 0.18f)
            edgeShader?.setLocalMatrix(edgeMatrix)
        }
        edge.shader = edgeShader
        canvas.drawRoundRect(rect, r, r, edge)
        edge.shader = null

        highlight.style = Paint.Style.STROKE
        highlight.strokeWidth = 1f
        val breathing = if (animatedBorder) (88f + 34f * ((sin(phase * 0.75f) + 1f) * 0.5f)).toInt() else 115
        highlight.color = Color.argb(breathing, 255, 255, 255)
        highlightRect.set(rect.left + 1.5f, rect.top + 1.5f, rect.right - 1.5f, rect.top + rect.height() * .28f)
        pathRoundTop(canvas, highlightRect, r)
        if (running && animatedBorder) {
            phase = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f
            scheduleSelf(tick, SystemClock.uptimeMillis() + 60L)
        }
    }

    private fun pathRoundTop(canvas: Canvas, rect: RectF, r: Float) {
        highlightPath.reset()
        highlightPath.moveTo(rect.left + r, rect.top)
        highlightPath.lineTo(rect.right - r, rect.top)
        highlightPath.quadTo(rect.right, rect.top, rect.right, rect.top + r)
        canvas.drawPath(highlightPath, highlight)
    }

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        super.onBoundsChange(bounds)
        val left = bounds.left + 1f
        val top = bounds.top + 1f
        val right = bounds.right - 1f
        val bottom = bounds.bottom - 1f
        fillShader = LinearGradient(
            left, top, right, bottom,
            Color.argb(245, 255, 255, 255),
            Color.argb(226, 244, 249, 255),
            Shader.TileMode.CLAMP
        )
        edgeShader = LinearGradient(
            left, top, right, bottom,
            Color.argb(155, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Color.argb(72, Color.red(secondary), Color.green(secondary), Color.blue(secondary)),
            Shader.TileMode.CLAMP
        )
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        running = visible
        if (!visible) unscheduleSelf(tick)
        if (visible && restart) phase = 0f
        return super.setVisible(visible, restart)
    }
    override fun setAlpha(alpha: Int) { fill.alpha = alpha; edge.alpha = alpha; highlight.alpha = alpha }
    override fun setColorFilter(filter: android.graphics.ColorFilter?) { fill.colorFilter = filter; edge.colorFilter = filter; highlight.colorFilter = filter }
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}


/** Compact clinical telemetry ring used only by the Clinical Day Home reference screen. */
class RovexClinicalFocusRingView(context: android.content.Context) : View(context) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD }
    private var progress = 0f
    private var solved = 0
    private val rect = RectF()
    private var ringShader: LinearGradient? = null

    init { contentDescription = "Today's solved progress" }

    fun setProgress(solved: Int, fraction: Float?) {
        this.solved = solved.coerceAtLeast(0)
        progress = (fraction ?: 0f).coerceIn(0f, 1f)
        contentDescription = if (fraction != null) "Today's progress $solved questions, ${(progress * 100).toInt()} percent of goal" else "Today's progress $solved questions"
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val size = minOf(w, h).toFloat()
        val cx = w * .5f
        val cy = h * .5f
        val r = size * .34f
        ringShader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            Color.rgb(38, 91, 230),
            Color.rgb(0, 171, 190),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val size = minOf(width, height).toFloat()
        val cx = width * .5f
        val cy = height * .5f
        val r = size * .34f
        track.strokeWidth = size * .075f
        track.color = Color.argb(32, 31, 77, 120)
        canvas.drawCircle(cx, cy, r, track)
        ring.strokeWidth = size * .075f
        ring.shader = ringShader
        rect.set(cx - r, cy - r, cx + r, cy + r)
        if (progress > 0f) canvas.drawArc(rect, -90f, progress * 360f, false, ring)
        ring.shader = null
        label.color = Color.rgb(24, 48, 82)
        label.textSize = size * .20f
        canvas.drawText(solved.toString(), cx, cy + size * .055f, label)
        label.textSize = size * .085f
        label.color = Color.rgb(84, 103, 130)
        canvas.drawText(if (progress > 0f) "TODAY" else "SOLVED", cx, cy + size * .18f, label)
    }
}

/** Small line-art icons for the Clinical Day Home; replaces emoji glyph dependence on the reference screen. */
class RovexClinicalFeatureIconView(context: android.content.Context, private val kind: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val s = minOf(w, h)
        paint.strokeWidth = s * .075f
        paint.color = Color.rgb(38, 91, 230)
        val cx = w * .5f; val cy = h * .5f
        when (kind) {
            0 -> { // QBank book
                canvas.drawRoundRect(cx-s*.29f,cy-s*.34f,cx+s*.29f,cy+s*.34f,s*.07f,s*.07f,paint); canvas.drawLine(cx-s*.16f,cy-s*.12f,cx+s*.16f,cy-s*.12f,paint); canvas.drawLine(cx-s*.16f,cy,cx+s*.16f,cy,paint); canvas.drawLine(cx-s*.16f,cy+s*.12f,cx+s*.10f,cy+s*.12f,paint)
            }
            1 -> { // flashcard / memory
                canvas.drawRoundRect(cx-s*.30f,cy-s*.24f,cx+s*.24f,cy+s*.31f,s*.06f,s*.06f,paint); canvas.drawRoundRect(cx-s*.20f,cy-s*.34f,cx+s*.34f,cy+s*.21f,s*.06f,s*.06f,paint); canvas.drawCircle(cx+s*.07f,cy-s*.06f,s*.08f,paint)
            }
            2 -> { // telemetry
                path.reset(); path.moveTo(cx-s*.34f,cy+s*.18f); path.lineTo(cx-s*.12f,cy+s*.04f); path.lineTo(cx,cy+s*.17f); path.lineTo(cx+s*.13f,cy-s*.20f); path.lineTo(cx+s*.34f,cy-s*.04f); canvas.drawPath(path,paint); canvas.drawLine(cx-s*.34f,cy+s*.30f,cx+s*.34f,cy+s*.30f,paint)
            }
            3 -> { // health
                path.reset(); path.moveTo(cx-s*.34f,cy); path.lineTo(cx-s*.15f,cy); path.lineTo(cx-s*.07f,cy-s*.17f); path.lineTo(cx+s*.08f,cy+s*.18f); path.lineTo(cx+s*.16f,cy); path.lineTo(cx+s*.34f,cy); canvas.drawPath(path,paint); canvas.drawCircle(cx,cy,s*.34f,paint) }
            else -> { // AI node
                canvas.drawCircle(cx,cy,s*.18f,paint); canvas.drawCircle(cx-s*.27f,cy-s*.20f,s*.07f,paint); canvas.drawCircle(cx+s*.28f,cy-s*.20f,s*.07f,paint); canvas.drawCircle(cx,cy+s*.29f,s*.07f,paint); canvas.drawLine(cx-s*.14f,cy-s*.10f,cx-s*.23f,cy-s*.16f,paint); canvas.drawLine(cx+s*.14f,cy-s*.10f,cx+s*.23f,cy-s*.16f,paint); canvas.drawLine(cx,cy+s*.18f,cx,cy+s*.24f,paint)
            }
        }
    }
}
