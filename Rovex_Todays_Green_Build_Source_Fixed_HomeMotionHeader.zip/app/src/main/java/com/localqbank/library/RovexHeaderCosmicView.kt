package com.localqbank.library

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.airbnb.lottie.RenderMode

/** Living Rovex mark: original app-logo bitmap plus imported, theme-coloured Lottie motion. */
class RovexHeaderCosmicView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {
    private val motion: LottieAnimationView
    init {
        clipChildren = false; clipToPadding = false
        val density = resources.displayMetrics.density
        val clip = FrameLayout(context).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
            clipToOutline = true; clipChildren = true
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        motion = LottieAnimationView(context).apply {
            tag = "rovex_home_motion_logo"
            setAnimationFromJson(RovexMotionAssetLoader.themedJson(context),
                "rovex_logo_flow_${RovexColorFlowTextView.colorOne(context)}_${RovexColorFlowTextView.colorTwo(context)}")
            repeatCount = LottieDrawable.INFINITE; repeatMode = LottieDrawable.RESTART; speed = 0.42f
            alpha = 0.18f; renderMode = RenderMode.HARDWARE
            contentDescription = null; importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            isClickable = false; isFocusable = false
        }
        clip.addView(motion, FrameLayout.LayoutParams(-1,-1))
        addView(clip, FrameLayout.LayoutParams(-1,-1))
        val logo = ImageView(context).apply {
            setImageResource(R.drawable.rovex_app_logo); scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Rovex"; importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        addView(logo, FrameLayout.LayoutParams(-1,-1).apply { val inset=(5f*density).toInt(); setMargins(inset,inset,inset,inset) })
    }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (AnimationPolicy.enabled(context) && RovexLiveMotionSettings.enabled(context)) motion.playAnimation() else motion.pauseAnimation()
    }
    override fun onDetachedFromWindow() { runCatching { motion.cancelAnimation() }; super.onDetachedFromWindow() }
}
