package com.localqbank.library

/** Shared motion constants; animation ownership remains in RovexMotionSystem. */
object RovexMotionSpec {
    const val PRESS_SCALE = 0.985f
    const val PRESS_DOWN_MS = 70L
    const val PRESS_UP_MS = 120L
}
