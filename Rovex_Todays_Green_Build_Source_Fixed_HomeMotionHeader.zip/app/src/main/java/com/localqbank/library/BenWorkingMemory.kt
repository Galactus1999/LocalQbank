package com.localqbank.library

/** Bounded per-request working memory. It never persists raw medical reasoning or user secrets. */
class BenWorkingMemory(private val maxSteps: Int = 12, private val maxEvidence: Int = 12) {
    data class Step(val id: String, val status: Status, val note: String)
    enum class Status { PENDING, COMPLETE, SKIPPED, FAILED }

    private val steps = ArrayList<Step>(maxSteps)
    private val evidence = LinkedHashMap<Long, String>()

    fun start(plan: BenCognitivePlan) {
        steps.clear()
        evidence.clear()
        plan.tasks.take(maxSteps).forEach { steps += Step(it.id, Status.PENDING, it.objective) }
    }

    fun complete(id: String, note: String) = update(id, Status.COMPLETE, note)
    fun skip(id: String, note: String) = update(id, Status.SKIPPED, note)
    fun fail(id: String, note: String) = update(id, Status.FAILED, note)

    fun addEvidence(sourceId: Long, text: String) {
        if (text.isBlank()) return
        if (!evidence.containsKey(sourceId) && evidence.size >= maxEvidence) return
        evidence[sourceId] = text.take(700)
    }

    fun snapshot(): Snapshot = Snapshot(steps.toList(), evidence.entries.map { Evidence(it.key, it.value) })

    data class Snapshot(val steps: List<Step>, val evidence: List<Evidence>)
    data class Evidence(val sourceId: Long, val text: String)

    private fun update(id: String, status: Status, note: String) {
        val index = steps.indexOfFirst { it.id == id }
        if (index < 0) return
        steps[index] = Step(id, status, note.take(320))
    }
}
