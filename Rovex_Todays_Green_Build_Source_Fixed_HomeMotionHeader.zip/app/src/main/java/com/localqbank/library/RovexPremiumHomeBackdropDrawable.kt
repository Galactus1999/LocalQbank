package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import kotlin.math.min

/**
 * Production backdrop: static/opaque base + bounded decorative geometry.
 * No frame scheduling, no per-frame allocation, no shader animation.
 */
class RovexPremiumHomeBackdropDrawable(private val context: Context) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val dark get() = ThemeManager.isDark(context)

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat().coerceAtLeast(1f)
        val h = bounds.height().toFloat().coerceAtLeast(1f)
        val a = ThemeManager.accent(context)

        val baseA = if (dark) Color.rgb(7, 13, 27) else Color.rgb(247, 250, 255)
        val baseB = if (dark) Color.rgb(13, 22, 42) else Color.rgb(238, 247, 255)
        val baseC = if (dark) Color.rgb(24, 12, 38) else Color.rgb(255, 247, 241)

        paint.shader = LinearGradient(0f, 0f, w, h, baseA, baseB, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)

        paint.shader = RadialGradient(
            w * 0.12f, h * 0.16f, min(w, h) * 0.62f,
            Color.argb(if (dark) 88 else 48, Color.red(a), Color.green(a), Color.blue(a)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(w * 0.12f, h * 0.16f, min(w, h) * 0.62f, paint)

        paint.shader = RadialGradient(
            w * 0.88f, h * 0.72f, min(w, h) * 0.70f,
            if (dark) Color.argb(92, 96, 67, 214) else Color.argb(44, 225, 166, 224),
            Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(w * 0.88f, h * 0.72f, min(w, h) * 0.70f, paint)

        paint.shader = LinearGradient(0f, h * 0.55f, w, h, baseB, baseC, Shader.TileMode.CLAMP)
        paint.alpha = if (dark) 90 else 125
        canvas.drawRect(0f, h * 0.52f, w, h, paint)
        paint.alpha = 255
        paint.shader = null

        // Fine clinical-grid geometry: intentionally sparse and static.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = context.resources.displayMetrics.density
        paint.color = Color.argb(if (dark) 30 else 24, Color.red(a), Color.green(a), Color.blue(a))
        val step = context.resources.displayMetrics.density * 44f
        var x = -step
        while (x < w + step) {
            canvas.drawLine(x, 0f, x + h * 0.10f, h, paint)
            x += step
        }

        // A single flowing contour anchors the lower composition.
        path.reset()
        path.moveTo(-w * 0.05f, h * 0.78f)
        path.cubicTo(w * 0.20f, h * 0.67f, w * 0.34f, h * 0.92f, w * 0.54f, h * 0.80f)
        path.cubicTo(w * 0.73f, h * 0.69f, w * 0.83f, h * 0.86f, w * 1.05f, h * 0.73f)
        paint.color = Color.argb(if (dark) 42 else 34, Color.red(a), Color.green(a), Color.blue(a))
        paint.strokeWidth = context.resources.displayMetrics.density * 1.5f
        canvas.drawPath(path, paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.argb(if (dark) 55 else 30, 255, 255, 255)
        val dotR = context.resources.displayMetrics.density * 1.2f
        for (i in 0..11) {
            val dx = w * (0.06f + i * 0.083f)
            val dy = h * (0.11f + ((i * 37) % 71) / 100f)
            canvas.drawCircle(dx, dy, dotR, paint)
        }
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
