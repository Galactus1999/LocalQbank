package com.localqbank.library

/** Semantic text sizes for compact, action-oriented View UI. */
object RovexVisualTypography {
    const val ACTION_SP = 11.5f
    const val ACTION_EMPHASIS_SP = 10.5f
}
