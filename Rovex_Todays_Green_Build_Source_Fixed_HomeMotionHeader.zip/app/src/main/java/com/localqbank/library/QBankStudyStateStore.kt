package com.localqbank.library

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

/**
 * Owns the durable learner/study-state SQL formerly embedded in QBankDb.
 * QBankDb remains the compatibility facade; this class owns no UI/navigation policy.
 * All database access resolves the shared provider-owned connection supplied by the facade.
 */
internal class QBankStudyStateStore(
    private val dbProvider: () -> SQLiteDatabase,
    private val sourceIdForTest: (String) -> Long,
    private val lock: Any
) {
    private val db: SQLiteDatabase get() = dbProvider()

    private fun Cursor.getStringOrNull(index: Int): String? = if (isNull(index)) null else getString(index)

    fun readStoredProgress(stableKey: String): QBankDb.StoredProgress? = db.rawQuery(
        "SELECT selected_answer,status,bookmark,review,attempts,last_attempted,time_ms,mistake_type,ease_factor,repetitions,interval_days,next_due FROM progress_v2 WHERE stable_key=? LIMIT 1",
        arrayOf(stableKey)
    ).use { c ->
        if (!c.moveToFirst()) return@use null
        QBankDb.StoredProgress(
            c.getStringOrNull(0), c.getStringOrNull(1), c.getStringOrNull(2), c.getInt(3) != 0,
            c.getInt(4), c.getLong(5), c.getLong(6), c.getStringOrNull(7),
            c.getFloat(8), c.getInt(9), c.getFloat(10), c.getLong(11)
        )
    }

    fun writeStoredProgress(stableKey: String, value: QBankDb.StoredProgress) {
        db.beginTransaction()
        try {
            val testId = stableKey.substringBefore(':').takeIf { it.isNotBlank() }
            db.execSQL(
                "INSERT OR REPLACE INTO progress_v2(stable_key,test_id,selected_answer,status,bookmark,review,attempts,last_attempted,time_ms,mistake_type,ease_factor,repetitions,interval_days,next_due) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                arrayOf<Any?>(stableKey, testId, value.selected, value.status, value.bookmark,
                    if (value.review) 1 else 0, value.attempts, value.lastAttempted, value.timeMs,
                    value.mistake, value.easeFactor, value.repetitions, value.intervalDays, value.nextDue)
            )
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun deleteStoredProgress(stableKey: String) = db.delete("progress_v2", "stable_key=?", arrayOf(stableKey))

    fun allStoredProgress(): Map<String, QBankDb.StoredProgress> = db.rawQuery(
        "SELECT stable_key,selected_answer,status,bookmark,review,attempts,last_attempted,time_ms,mistake_type,ease_factor,repetitions,interval_days,next_due FROM progress_v2", null
    ).use { c ->
        buildMap {
            while (c.moveToNext()) put(c.getString(0), QBankDb.StoredProgress(
                c.getStringOrNull(1), c.getStringOrNull(2), c.getStringOrNull(3), c.getInt(4) != 0,
                c.getInt(5), c.getLong(6), c.getLong(7), c.getStringOrNull(8),
                c.getFloat(9), c.getInt(10), c.getFloat(11), c.getLong(12)
            ))
        }
    }

    fun getProgressMeta(key: String): String? = db.rawQuery(
        "SELECT meta_value FROM progress_meta WHERE meta_key=? LIMIT 1", arrayOf(key)
    ).use { c -> if (c.moveToFirst()) c.getString(0) else null }

    fun putProgressMeta(key: String, value: String?) {
        if (value == null) db.delete("progress_meta", "meta_key=?", arrayOf(key))
        else db.execSQL("INSERT OR REPLACE INTO progress_meta(meta_key,meta_value) VALUES(?,?)", arrayOf(key, value))
    }

    fun allProgressMeta(): Map<String, String> = db.rawQuery("SELECT meta_key,meta_value FROM progress_meta", null).use { c ->
        buildMap { while (c.moveToNext()) put(c.getString(0), c.getString(1)) }
    }

    fun recordStudyStreakDay(timestamp: Long = System.currentTimeMillis()): StreakManager.Snapshot = synchronized(lock) {
        val today = java.time.Instant.ofEpochMilli(timestamp).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        val next = StreakPolicy().apply(readStudyStreak(), today)
        db.execSQL("UPDATE study_streak SET current_streak=?,longest_streak=?,total_study_days=?,last_study_day=? WHERE id=1",
            arrayOf<Any?>(next.currentStreak, next.longestStreak, next.totalStudyDays, next.lastStudyDay))
        next
    }

    fun readStudyStreak(): StreakManager.Snapshot = db.rawQuery(
        "SELECT current_streak,longest_streak,total_study_days,last_study_day FROM study_streak WHERE id=1 LIMIT 1", null
    ).use { c ->
        if (!c.moveToFirst()) StreakManager.Snapshot()
        else StreakManager.Snapshot(c.getInt(0), c.getInt(1), c.getInt(2), if (c.isNull(3)) null else c.getString(3))
    }

    fun studyReminderAlreadySent(day: String): Boolean = db.rawQuery(
        "SELECT last_reminder_day FROM study_streak WHERE id=1 LIMIT 1", null
    ).use { c -> c.moveToFirst() && !c.isNull(0) && c.getString(0) == day }

    fun markStudyReminderSent(day: String) = db.execSQL("UPDATE study_streak SET last_reminder_day=? WHERE id=1", arrayOf(day))

    fun notificationPermissionPrompted(): Boolean = db.rawQuery(
        "SELECT notification_prompted FROM study_streak WHERE id=1 LIMIT 1", null
    ).use { c -> c.moveToFirst() && c.getInt(0) != 0 }

    fun markNotificationPermissionPrompted() = db.execSQL("UPDATE study_streak SET notification_prompted=1 WHERE id=1")

    fun replaceStoredProgress(entries: Map<String, QBankDb.StoredProgress>, meta: Map<String, String>) {
        db.beginTransaction()
        try {
            db.delete("progress_v2", null, null)
            db.delete("progress_meta", null, null)
            val ps = db.compileStatement("INSERT INTO progress_v2(stable_key,test_id,selected_answer,status,bookmark,review,attempts,last_attempted,time_ms,mistake_type,ease_factor,repetitions,interval_days,next_due) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            try {
                entries.forEach { (key, v) ->
                    ps.bindString(1, key)
                    bindNullable(ps, 2, key.substringBefore(':').takeIf { it.isNotBlank() })
                    bindNullable(ps, 3, v.selected); bindNullable(ps, 4, v.status); bindNullable(ps, 5, v.bookmark)
                    ps.bindLong(6, if (v.review) 1 else 0); ps.bindLong(7, v.attempts.toLong()); ps.bindLong(8, v.lastAttempted)
                    ps.bindLong(9, v.timeMs); bindNullable(ps, 10, v.mistake); ps.bindDouble(11, v.easeFactor.toDouble())
                    ps.bindLong(12, v.repetitions.toLong()); ps.bindDouble(13, v.intervalDays.toDouble()); ps.bindLong(14, v.nextDue)
                    ps.executeInsert(); ps.clearBindings()
                }
            } finally { ps.close() }
            val ms = db.compileStatement("INSERT INTO progress_meta(meta_key,meta_value) VALUES(?,?)")
            try { meta.forEach { (k, v) -> ms.bindString(1, k); ms.bindString(2, v); ms.executeInsert(); ms.clearBindings() } }
            finally { ms.close() }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun bindNullable(statement: android.database.sqlite.SQLiteStatement, index: Int, value: String?) {
        if (value == null) statement.bindNull(index) else statement.bindString(index, value)
    }

    fun beginProgressMetaTransaction(testId: String, position: Int, sourceId: Long, sourceName: String?, resumeSavedAt: Long? = null) {
        db.beginTransaction()
        try {
            putProgressMeta("${testId}:position", position.toString())
            if (sourceId > 0L) putProgressMeta("source:$sourceId:resume", "$testId|$position")
            if (!sourceName.isNullOrBlank()) putProgressMeta("sourceName:$sourceName:resume", "$testId|$position")
            putProgressMeta("last_resume_global", "$testId|$position|$sourceId|${resumeSavedAt ?: System.currentTimeMillis()}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun bookmarkCounts(): Map<String, Int> = db.rawQuery(
        "SELECT LOWER(bookmark), COUNT(*) FROM progress_v2 WHERE bookmark IS NOT NULL AND bookmark<>'' GROUP BY LOWER(bookmark)", null
    ).use { c -> buildMap { while (c.moveToNext()) put(c.getString(0).orEmpty(), c.getInt(1)) } }

    fun homeStudyStats(todayStart: Long, weekStart: Long, graphStart: Long): QBankDb.HomeStudyStats {
        val todayRows = db.rawQuery(
            "SELECT p.last_attempted,p.status FROM progress_v2 p JOIN test t ON t.id=p.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE p.last_attempted>=? AND p.status IS NOT NULL AND p.status<>'' ORDER BY p.last_attempted",
            arrayOf(todayStart.toString())
        ).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0) to (c.getString(1) == "correct")) } }
        val aggregate = db.rawQuery(
            "SELECT COALESCE(SUM(CASE WHEN p.last_attempted>=? AND p.status IS NOT NULL AND p.status<>'' THEN 1 ELSE 0 END),0), COALESCE(SUM(CASE WHEN p.last_attempted>=? AND p.status='correct' THEN 1 ELSE 0 END),0), COALESCE(SUM(CASE WHEN p.last_attempted>=? AND p.status='wrong' THEN 1 ELSE 0 END),0), COALESCE(SUM(CASE WHEN p.last_attempted>=? AND p.status IS NOT NULL AND p.status<>'' THEN 1 ELSE 0 END),0), COALESCE(SUM(CASE WHEN p.bookmark IS NOT NULL AND p.bookmark<>'' THEN 1 ELSE 0 END),0) FROM progress_v2 p JOIN test t ON t.id=p.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
            arrayOf(todayStart.toString(), todayStart.toString(), todayStart.toString(), weekStart.toString())
        ).use { c -> c.moveToFirst(); intArrayOf(c.getInt(0), c.getInt(0), c.getInt(1), c.getInt(2), c.getInt(3)) }
        val dayRows = db.rawQuery(
            "SELECT ((p.last_attempted-?)/86400000) AS day_offset, COUNT(*), COALESCE(SUM(CASE WHEN p.status='correct' THEN 1 ELSE 0 END),0) FROM progress_v2 p JOIN test t ON t.id=p.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE p.last_attempted>=? AND p.status IS NOT NULL AND p.status<>'' GROUP BY day_offset ORDER BY day_offset",
            arrayOf(graphStart.toString(), graphStart.toString())
        ).use { c -> buildList { while (c.moveToNext()) add(graphStart + c.getLong(0) * 86_400_000L to (c.getInt(1) to c.getInt(2))) } }
        return QBankDb.HomeStudyStats(todayRows, aggregate[0], aggregate[0], aggregate[1], aggregate[2], aggregate[3], aggregate[4], dayRows)
    }

    fun studyAttemptHistory(stableKeys: Set<String>, since: Long): List<QBankDb.StudyAttemptHistoryRow> {
        if (stableKeys.isEmpty()) return emptyList()
        val out = ArrayList<QBankDb.StudyAttemptHistoryRow>()
        stableKeys.toList().chunked(200).forEach { chunk ->
            val placeholders = chunk.joinToString(",") { "?" }
            val args = arrayOf(since.toString(), *chunk.toTypedArray())
            db.rawQuery("SELECT stable_key,attempted_at,correct,time_ms FROM study_attempt_history WHERE attempted_at>=? AND stable_key IN ($placeholders) ORDER BY attempted_at", args).use { c ->
                while (c.moveToNext()) out += QBankDb.StudyAttemptHistoryRow(c.getString(0), c.getLong(1), c.getInt(2) != 0, c.getLong(3))
            }
        }
        return out
    }

    fun recordStudyAttempt(stableKey: String, testId: String, sourceId: Long, attemptedAt: Long, correct: Boolean) {
        db.execSQL("INSERT INTO study_attempt_history(stable_key,test_id,source_id,attempted_at,correct,time_ms) VALUES(?,?,?,?,?,0)",
            arrayOf<Any?>(stableKey, testId, sourceId, attemptedAt, if (correct) 1 else 0))
    }

    fun updateLatestStudyAttemptTime(stableKey: String, elapsedMs: Long) {
        if (elapsedMs <= 0L || stableKey.isBlank()) return
        db.rawQuery("SELECT id FROM study_attempt_history WHERE stable_key=? ORDER BY id DESC LIMIT 1", arrayOf(stableKey)).use { c ->
            if (c.moveToFirst()) db.execSQL("UPDATE study_attempt_history SET time_ms=time_ms+? WHERE id=?", arrayOf(elapsedMs, c.getLong(0)))
        }
    }

    fun seedStudyAttemptHistoryIfNeeded() {
        val marker = "study_attempt_history_seed_v3_at"
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            db.rawQuery("""
                SELECT p.stable_key,p.test_id,p.last_attempted,p.status,p.time_ms
                FROM progress_v2 p
                WHERE p.last_attempted>0 AND p.status IS NOT NULL AND p.status<>''
                  AND NOT EXISTS (
                    SELECT 1 FROM study_attempt_history h
                    WHERE h.stable_key=p.stable_key AND h.attempted_at=p.last_attempted
                      AND h.correct=CASE WHEN p.status='correct' THEN 1 ELSE 0 END
                  )
            """.trimIndent(), null).use { c ->
                while (c.moveToNext()) {
                    val testId = c.getString(1).orEmpty()
                    db.execSQL("INSERT INTO study_attempt_history(stable_key,test_id,source_id,attempted_at,correct,time_ms) VALUES(?,?,?,?,?,?)",
                        arrayOf(c.getString(0), testId, sourceIdForTest(testId), c.getLong(2), if (c.getString(3) == "correct") 1 else 0, c.getLong(4)))
                }
            }
            putProgressMeta(marker, now.toString())
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}
