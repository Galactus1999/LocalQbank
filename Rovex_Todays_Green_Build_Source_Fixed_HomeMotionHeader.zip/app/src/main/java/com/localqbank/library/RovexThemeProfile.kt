package com.localqbank.library

/** Immutable visual profile. Colors are deliberately distinct per theme; no theme is only a tint swap. */
data class RovexThemeProfile(
    val key: String,
    val name: String,
    val backgroundA: Int,
    val backgroundB: Int,
    val backgroundC: Int,
    val panel: Int,
    val elevated: Int,
    val accent: Int,
    val accentSecondary: Int,
    val text: Int,
    val muted: Int,
    val scene: Int,
    val flowSpeed: Float,
    val motionAlpha: Float,
    val cornerDp: Int
) {
    companion object {
        fun forKey(key: String): RovexThemeProfile = when (key) {
            ThemeManager.PASTEL -> RovexThemeProfile(
                key, "Pastel Prism", 0xFFF4F8FF.toInt(), 0xFFFFEFF9.toInt(), 0xFFEBEFFF.toInt(),
                0xFFFCFDFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF4A5BFF.toInt(), 0xFFE25CB8.toInt(),
                0xFF192246.toInt(), 0xFF5B6685.toInt(), 1, .34f, .22f, 24
            )
            ThemeManager.MINT -> RovexThemeProfile(
                key, "Living Mint", 0xFFE8FFF8.toInt(), 0xFFE1F3FF.toInt(), 0xFFEEFFF1.toInt(),
                0xFFF8FFFC.toInt(), 0xFFFFFFFF.toInt(), 0xFF00B09A.toInt(), 0xFF2D7DE1.toInt(),
                0xFF0D3033.toInt(), 0xFF466968.toInt(), 2, .42f, .25f, 24
            )
            ThemeManager.SUNSET -> RovexThemeProfile(
                key, "Solar Ember", 0xFFFFF7E8.toInt(), 0xFFFFE0D3.toInt(), 0xFFFFEFE0.toInt(),
                0xFFFFFBF6.toInt(), 0xFFFFFFFF.toInt(), 0xFFF55D30.toInt(), 0xFFFFB242.toInt(),
                0xFF43271E.toInt(), 0xFF775B4C.toInt(), 3, .30f, .22f, 24
            )
            ThemeManager.LAVENDER -> RovexThemeProfile(
                key, "Iris Aurora", 0xFFF6F2FF.toInt(), 0xFFE1EEFF.toInt(), 0xFFFFEBF9.toInt(),
                0xFFFCFAFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF7048FF.toInt(), 0xFFD84FB5.toInt(),
                0xFF2A1E4C.toInt(), 0xFF64577E.toInt(), 4, .38f, .24f, 26
            )
            ThemeManager.AMOLED -> RovexThemeProfile(
                key, "OLED Aurora", 0xFF000000.toInt(), 0xFF01070F.toInt(), 0xFF000E13.toInt(),
                0xFF050A10.toInt(), 0xFF090F17.toInt(), 0xFF34BDFF.toInt(), 0xFF5AFFCC.toInt(),
                0xFFF1F7FF.toInt(), 0xFF96B1D0.toInt(), 5, .28f, .16f, 22
            )
            ThemeManager.PANDORA -> RovexThemeProfile(
                key, "Pandora Living World", 0xFF020717.toInt(), 0xFF071A2F.toInt(), 0xFF19082B.toInt(),
                0xFF071727.toInt(), 0xFF0B2130.toInt(), 0xFF46EBFF.toInt(), 0xFFCD52FF.toInt(),
                0xFFF1F7FF.toInt(), 0xFF97B7D5.toInt(), 6, .22f, .24f, 26
            )
            ThemeManager.SPACE -> RovexThemeProfile(
                key, "Deep Cosmos", 0xFF010410.toInt(), 0xFF090B28.toInt(), 0xFF1E0731.toInt(),
                0xFF080D1F.toInt(), 0xFF0D122A.toInt(), 0xFF78AEFF.toInt(), 0xFFBD62FF.toInt(),
                0xFFF2F7FF.toInt(), 0xFF97AED3.toInt(), 7, .16f, .20f, 24
            )
            else -> RovexThemeProfile(
                key, "Clinical Day", 0xFFF7FAFF.toInt(), 0xFFE8F2FF.toInt(), 0xFFFFF6ED.toInt(),
                0xFFFCFDFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF2D5BE6.toInt(), 0xFF00A4BE.toInt(),
                0xFF122048.toInt(), 0xFF4D5E7D.toInt(), 0, .26f, .18f, 22
            )
        }
    }
}
