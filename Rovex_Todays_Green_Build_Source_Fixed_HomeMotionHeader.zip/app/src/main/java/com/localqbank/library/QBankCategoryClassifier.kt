package com.localqbank.library

/** Single deterministic classification contract shared by storage/search/UI consumers. */
object QBankCategoryClassifier {
    val canonicalSubjects: List<String> = listOf(
        "Anatomy", "Physiology", "Biochemistry", "Pharmacology", "Pathology", "Microbiology",
        "Forensic Medicine", "Community Medicine / PSM", "General Medicine", "Dermatology",
        "Psychiatry", "Pediatrics", "Radiology", "Anesthesiology", "General Surgery",
        "Orthopedics", "ENT", "Ophthalmology", "Obstetrics & Gynecology"
    )

    fun normalize(value: String): String = value.lowercase()
        .replace("&", " and ")
        .replace(Regex("[\\u2010-\\u2015\\u2212]"), "-")
        .replace(Regex("[^a-z0-9]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    fun subject(path: String?, title: String, source: String): String? {
        val hay = normalize(listOf(path.orEmpty(), title, source).joinToString(" "))
        fun has(vararg aliases: String): Boolean = aliases.any { a ->
            Regex("(^| )${Regex.escape(normalize(a)).replace("\\ ", "\\s+")}( |$)").containsMatchIn(hay)
        }
        return when {
            Regex("\\b(anatomy|gross anatomy|embryology|histology|neuroanatomy)\\b").containsMatchIn(hay) -> "Anatomy"
            Regex("\\bphysiology\\b").containsMatchIn(hay) -> "Physiology"
            Regex("\\b(biochem|biochemistry)\\b").containsMatchIn(hay) -> "Biochemistry"
            Regex("\\b(pharmacology|pharmaco)\\b").containsMatchIn(hay) -> "Pharmacology"
            Regex("\\b(pathology|histopathology)\\b").containsMatchIn(hay) -> "Pathology"
            Regex("\\bmicrobiology\\b").containsMatchIn(hay) -> "Microbiology"
            Regex("\\b(forensic|toxicology|fmt)\\b").containsMatchIn(hay) -> "Forensic Medicine"
            Regex("\\b(community medicine|communitymedicine|psm|preventive and social medicine|preventive social medicine)\\b").containsMatchIn(hay) -> "Community Medicine / PSM"
            Regex("\\b(general medicine|internal medicine|medicine and allied|medicine allied|medicine and allied subjects|medicine allied subjects|medical and allied|respiratory medicine|pulmonology|tb and chest|tb chest)\\b").containsMatchIn(hay) || has("medicine", "medicine & allied", "internal medicine") -> "General Medicine"
            Regex("\\b(dermatology|dvl|venereology)\\b").containsMatchIn(hay) -> "Dermatology"
            Regex("\\b(psychiatry|psychiatric)\\b").containsMatchIn(hay) -> "Psychiatry"
            Regex("\\b(pediatrics|paediatrics|paediatric|pediatric)\\b").containsMatchIn(hay) -> "Pediatrics"
            Regex("\\b(radiology|radiodiagnosis|radio diagnosis|radiodiagnostic)\\b").containsMatchIn(hay) -> "Radiology"
            Regex("\\b(anesthesiology|anaesthesiology|anesthesia|anaesthesia)\\b").containsMatchIn(hay) -> "Anesthesiology"
            Regex("\\b(general surgery|surgery and allied|surgery allied|surgery and allied subjects|surgical sciences|surgical)\\b").containsMatchIn(hay) || has("surgery", "surgery & allied") -> "General Surgery"
            Regex("\\b(orthopedic|orthopaedic|orthopedics|orthopaedics)\\b").containsMatchIn(hay) -> "Orthopedics"
            Regex("(^| )ent( |$)|otorhinolaryngology|otolaryngology|ear nose throat").containsMatchIn(hay) -> "ENT"
            Regex("""\b(ophthalmology|ophthal)\b|\beye\s+(medicine|surgery|diseases|questions?|mcq|qbank|test)\b""").containsMatchIn(hay) -> "Ophthalmology"
            Regex("\\b(obstetrics|gynaecology|gynecology|obgyn|obg)\\b").containsMatchIn(hay) -> "Obstetrics & Gynecology"
            else -> null
        }
    }

    fun legacyCategory(path: String?, title: String, source: String): String {
        fun useful(v: String): Boolean {
            val x = v.trim().lowercase()
            return x.isNotBlank() && x !in setOf("test", "tests", "section", "sections", "qbank", "question bank", "quiz", "quizzes", "practice")
        }
        val parts = path.orEmpty().trim().trim('/').replace("\\", "/")
            .split('/').map { it.trim() }.filter(::useful)
        if (parts.isNotEmpty()) return parts.last().take(48)
        val titleParts = title.split(Regex("\\s*[-–—|:]\\s*"), limit = 2).map { it.trim() }
        if (titleParts.isNotEmpty() && useful(titleParts.first())) return titleParts.first().take(48)
        val file = source.substringBeforeLast('.', source).trim()
        return if (useful(file)) file.take(48) else "General"
    }

    /** Maps a source/test label to the best preloaded medical hierarchy node. */
    fun taxonomy(path: String?, title: String, source: String, context: android.content.Context): MedicalTaxonomyMatch? =
        MedicalTaxonomyRepository.get(context).classify(listOf(path.orEmpty(), title, source).joinToString(" "), 1).firstOrNull()

    fun taxonomyPath(path: String?, title: String, source: String, context: android.content.Context): String? =
        taxonomy(path, title, source, context)?.node?.path

    fun kind(path: String?, title: String, source: String): String {
        val hay = normalize(listOf(title, path.orEmpty(), source).joinToString(" "))
        return when {
            Regex("\\bpyq\\b|previous year|previous year questions|previous-year").containsMatchIn(hay) -> "PYQ"
            Regex("\\bcustom\\b|customized|custom qbank").containsMatchIn(hay) -> "Custom"
            Regex("image test|image based test|image based questions|image-based test").containsMatchIn(hay) -> "Image Test"
            Regex("subject test|subject-wise test|subject wise test|subject test series").containsMatchIn(hay) -> "Subject Test"
            Regex("other test|grand test|mock test|test series|mixed test|full test").containsMatchIn(hay) -> "Other Test"
            else -> "QBank"
        }
    }
}
