package com.localqbank.library

import android.graphics.Color

/** Semantic color roles for Rovex production surfaces. */
data class RovexColorRoles(
    val background: Int,
    val surface: Int,
    val surfaceContainer: Int,
    val surfaceElevated: Int,
    val primary: Int,
    val onPrimary: Int,
    val primaryContainer: Int,
    val onPrimaryContainer: Int,
    val secondary: Int,
    val tertiary: Int,
    val onSurface: Int,
    val onSurfaceVariant: Int,
    val outline: Int,
    val outlineStrong: Int,
    val success: Int,
    val onSuccess: Int,
    val successContainer: Int,
    val onSuccessContainer: Int,
    val error: Int,
    val onError: Int,
    val errorContainer: Int,
    val onErrorContainer: Int,
    val warning: Int,
    val onWarning: Int,
    val warningContainer: Int,
    val onWarningContainer: Int,
    val info: Int,
    val infoContainer: Int,
    val selectedContainer: Int,
    val navSurface: Int,
    val navSelected: Int,
    val navOnSelected: Int
)

object RovexPremiumPalette {
    const val CLINICAL = "clinical"
    const val PASTEL = "pastel"
    const val MINT = "mint"
    const val SOLAR = "solar"
    const val IRIS = "iris"
    const val OLED = "oled"
    const val PANDORA = "pandora"
    const val COSMOS = "cosmos"

    fun forKey(key: String, dark: Boolean): RovexColorRoles {
        return when (key.lowercase()) {
            PASTEL, "pastel_prism" -> pastel(dark)
            MINT, "living_mint" -> mint(dark)
            SOLAR, "sunset", "solar_ember" -> solar(dark)
            IRIS, "lavender", "iris_aurora" -> iris(dark)
            OLED, "amoled", "oled_aurora", "obsidian_night", "midnight" -> oled()
            PANDORA -> pandora(dark)
            COSMOS, "space", "deep_cosmos" -> cosmos(dark)
            else -> clinical(dark)
        }
    }

    private fun clinical(d: Boolean) = if (!d) roles(
        bg = Color.rgb(246, 249, 253), surface = Color.rgb(255, 255, 255),
        container = Color.rgb(241, 246, 252), elevated = Color.rgb(255, 255, 255),
        primary = Color.rgb(32, 91, 214), onPrimary = Color.WHITE,
        primaryContainer = Color.rgb(220, 232, 255), onPrimaryContainer = Color.rgb(15, 48, 108),
        secondary = Color.rgb(0, 132, 145), tertiary = Color.rgb(117, 72, 184),
        onSurface = Color.rgb(18, 31, 58), onVariant = Color.rgb(77, 94, 125),
        outline = Color.rgb(173, 188, 211), outlineStrong = Color.rgb(105, 128, 165),
        success = Color.rgb(0, 125, 86), onSuccess = Color.WHITE,
        successContainer = Color.rgb(218, 247, 234), onSuccessContainer = Color.rgb(0, 74, 49),
        error = Color.rgb(190, 45, 77), onError = Color.WHITE,
        errorContainer = Color.rgb(255, 226, 233), onErrorContainer = Color.rgb(112, 24, 48),
        warning = Color.rgb(166, 101, 0), onWarning = Color.WHITE,
        warningContainer = Color.rgb(255, 239, 202), onWarningContainer = Color.rgb(91, 55, 0),
        info = Color.rgb(0, 105, 170), infoContainer = Color.rgb(220, 240, 255),
        selected = Color.rgb(225, 235, 255),
        nav = Color.rgb(250, 252, 255), navSelected = Color.rgb(215, 229, 255), navOn = Color.rgb(20, 66, 155)
    ) else roles(
        bg = Color.rgb(6, 12, 24), surface = Color.rgb(12, 21, 38),
        container = Color.rgb(16, 27, 46), elevated = Color.rgb(20, 32, 53),
        primary = Color.rgb(91, 169, 255), onPrimary = Color.rgb(5, 25, 57),
        primaryContainer = Color.rgb(20, 57, 101), onPrimaryContainer = Color.rgb(206, 229, 255),
        secondary = Color.rgb(77, 215, 222), tertiary = Color.rgb(193, 135, 255),
        onSurface = Color.rgb(238, 245, 255), onVariant = Color.rgb(169, 190, 220),
        outline = Color.rgb(69, 91, 122), outlineStrong = Color.rgb(101, 130, 170),
        success = Color.rgb(75, 225, 169), onSuccess = Color.rgb(0, 48, 31),
        successContainer = Color.rgb(8, 67, 51), onSuccessContainer = Color.rgb(157, 255, 218),
        error = Color.rgb(255, 108, 145), onError = Color.rgb(70, 5, 28),
        errorContainer = Color.rgb(82, 18, 39), onErrorContainer = Color.rgb(255, 207, 219),
        warning = Color.rgb(255, 198, 79), onWarning = Color.rgb(65, 39, 0),
        warningContainer = Color.rgb(74, 55, 9), onWarningContainer = Color.rgb(255, 226, 152),
        info = Color.rgb(91, 200, 255), infoContainer = Color.rgb(8, 49, 75),
        selected = Color.rgb(19, 57, 103),
        nav = Color.rgb(8, 15, 29), navSelected = Color.rgb(22, 55, 91), navOn = Color.rgb(204, 230, 255)
    )

    /** Pastel Prism dark profile; this stage deliberately does not modify other themes. */
    private fun pastel(d: Boolean) = if (!d) roles(
        Color.rgb(244,247,255),Color.rgb(255,255,255),Color.rgb(239,243,255),Color.rgb(255,255,255),
        Color.rgb(78,94,226),Color.WHITE,Color.rgb(226,231,255),Color.rgb(43,54,129),
        Color.rgb(110,91,205),Color.rgb(202,83,154),Color.rgb(28,35,72),Color.rgb(91,99,132),
        Color.rgb(177,183,211),Color.rgb(118,128,171),Color.rgb(25,139,99),Color.WHITE,Color.rgb(220,248,237),Color.rgb(0,75,49),
        Color.rgb(193,55,93),Color.WHITE,Color.rgb(255,226,236),Color.rgb(113,22,51),
        Color.rgb(164,104,0),Color.WHITE,Color.rgb(255,240,205),Color.rgb(88,55,0),
        Color.rgb(65,110,191),Color.rgb(226,238,255),Color.rgb(230,234,255),
        Color.rgb(250,251,255),Color.rgb(220,225,255),Color.rgb(48,57,143)
    ) else roles(
        Color.rgb(14,13,28),Color.rgb(24,22,45),Color.rgb(34,31,61),Color.rgb(43,38,75),
        Color.rgb(169,158,255),Color.rgb(25,20,60),Color.rgb(54,47,104),Color.rgb(232,226,255),
        Color.rgb(113,225,255),Color.rgb(255,145,208),Color.rgb(248,245,255),Color.rgb(197,190,222),
        Color.rgb(91,84,124),Color.rgb(132,122,170),Color.rgb(91,235,181),Color.rgb(0,45,30),Color.rgb(12,72,56),Color.rgb(173,255,225),
        Color.rgb(255,112,157),Color.rgb(73,8,30),Color.rgb(91,22,46),Color.rgb(255,211,223),
        Color.rgb(255,204,91),Color.rgb(69,43,0),Color.rgb(82,60,13),Color.rgb(255,231,160), 
        Color.rgb(111,215,255),Color.rgb(10,55,81),Color.rgb(55,47,103),
        Color.rgb(17,15,34),Color.rgb(55,48,101),Color.rgb(238,233,255)
    )

    private fun mint(d: Boolean) = if (!d) roles(
        Color.rgb(239,250,247),Color.rgb(255,255,255),Color.rgb(232,247,243),Color.WHITE,
        Color.rgb(0,157,137),Color.WHITE,Color.rgb(207,244,236),Color.rgb(0,78,68),
        Color.rgb(39,116,150),Color.rgb(96,76,172),Color.rgb(18,49,46),Color.rgb(72,105,99),
        Color.rgb(160,193,186),Color.rgb(91,137,127),Color.rgb(0,130,91),Color.WHITE,Color.rgb(215,248,235),Color.rgb(0,72,48),
        Color.rgb(193,57,84),Color.WHITE,Color.rgb(255,226,232),Color.rgb(112,20,44),
        Color.rgb(157,102,0),Color.WHITE,Color.rgb(255,239,202),Color.rgb(85,53,0),
        Color.rgb(0,113,154),Color.rgb(219,241,255),Color.rgb(211,246,239),
        Color.rgb(248,254,252),Color.rgb(210,244,237),Color.rgb(0,83,73)
    ) else clinical(true)

    private fun solar(d: Boolean) = if (!d) roles(
        Color.rgb(255,247,239),Color.rgb(255,255,255),Color.rgb(255,240,228),Color.WHITE,
        Color.rgb(226,83,32),Color.WHITE,Color.rgb(255,225,210),Color.rgb(118,35,8),
        Color.rgb(190,96,0),Color.rgb(146,60,139),Color.rgb(61,30,21),Color.rgb(117,83,67),
        Color.rgb(207,170,147),Color.rgb(157,113,91),Color.rgb(0,127,91),Color.WHITE,Color.rgb(220,248,236),Color.rgb(0,73,49),
        Color.rgb(192,49,77),Color.WHITE,Color.rgb(255,226,233),Color.rgb(111,21,48),
        Color.rgb(159,92,0),Color.WHITE,Color.rgb(255,239,201),Color.rgb(83,50,0),
        Color.rgb(0,111,161),Color.rgb(222,240,255),Color.rgb(255,226,210),
        Color.rgb(255,251,247),Color.rgb(255,229,211),Color.rgb(112,41,9)
    ) else clinical(true)

    private fun iris(d: Boolean) = if (!d) roles(
        Color.rgb(247,244,255),Color.WHITE,Color.rgb(240,236,255),Color.WHITE,
        Color.rgb(108,74,226),Color.WHITE,Color.rgb(230,223,255),Color.rgb(60,38,126),
        Color.rgb(28,128,151),Color.rgb(192,73,157),Color.rgb(30,25,60),Color.rgb(93,87,124),
        Color.rgb(181,171,214),Color.rgb(120,107,164),Color.rgb(0,128,92),Color.WHITE,Color.rgb(218,247,235),Color.rgb(0,73,48),
        Color.rgb(193,54,91),Color.WHITE,Color.rgb(255,226,235),Color.rgb(112,21,48),
        Color.rgb(160,100,0),Color.WHITE,Color.rgb(255,239,201),Color.rgb(87,53,0),
        Color.rgb(0,105,164),Color.rgb(224,239,255),Color.rgb(232,226,255),
        Color.rgb(251,249,255),Color.rgb(228,221,255),Color.rgb(68,43,151)
    ) else clinical(true)

    private fun oled() = roles(
        Color.BLACK,Color.rgb(3,5,9),Color.rgb(7,10,16),Color.rgb(11,15,23),
        Color.rgb(65,194,255),Color.rgb(0,31,47),Color.rgb(8,48,72),Color.rgb(184,229,255),
        Color.rgb(75,226,191),Color.rgb(184,119,255),Color.rgb(239,247,255),Color.rgb(157,180,211),
        Color.rgb(54,77,107),Color.rgb(93,125,164),Color.rgb(66,232,171),Color.rgb(0,44,29),Color.rgb(5,67,50),Color.rgb(154,255,218),
        Color.rgb(255,90,132),Color.rgb(70,4,25),Color.rgb(75,13,34),Color.rgb(255,202,218),
        Color.rgb(255,196,72),Color.rgb(65,39,0),Color.rgb(71,52,6),Color.rgb(255,226,146),
        Color.rgb(79,205,255),Color.rgb(6,48,72),Color.rgb(10,45,70),
        Color.rgb(2,4,8),Color.rgb(13,45,70),Color.rgb(195,231,255)
    )

    private fun pandora(d: Boolean) = if (!d) roles(
        Color.rgb(247,243,255),Color.rgb(255,255,255),Color.rgb(240,234,255),Color.WHITE,
        Color.rgb(103,73,210),Color.WHITE,Color.rgb(231,223,255),Color.rgb(57,38,118),
        Color.rgb(0,145,158),Color.rgb(198,72,147),Color.rgb(29,25,57),Color.rgb(91,84,124),
        Color.rgb(181,169,215),Color.rgb(119,105,164),Color.rgb(0,128,91),Color.WHITE,Color.rgb(218,247,235),Color.rgb(0,73,48),
        Color.rgb(192,52,88),Color.WHITE,Color.rgb(255,226,235),Color.rgb(110,20,46),
        Color.rgb(160,100,0),Color.WHITE,Color.rgb(255,239,201),Color.rgb(86,53,0),
        Color.rgb(0,106,163),Color.rgb(223,239,255),Color.rgb(232,225,255),
        Color.rgb(251,249,255),Color.rgb(228,221,255),Color.rgb(66,43,148)
    ) else clinical(true)

    private fun cosmos(d: Boolean) = if (!d) iris(true) else roles(
        Color.rgb(5,7,17),Color.rgb(10,12,27),Color.rgb(15,18,37),Color.rgb(20,23,48),
        Color.rgb(143,112,255),Color.rgb(22,12,55),Color.rgb(44,31,95),Color.rgb(224,215,255),
        Color.rgb(66,210,210),Color.rgb(245,91,178),Color.rgb(242,240,255),Color.rgb(178,176,210),
        Color.rgb(76,74,115),Color.rgb(120,117,171),Color.rgb(74,226,171),Color.rgb(0,48,31),Color.rgb(8,68,52),Color.rgb(157,255,219),
        Color.rgb(255,95,140),Color.rgb(73,5,28),Color.rgb(80,17,41),Color.rgb(255,205,218),
        Color.rgb(255,199,73),Color.rgb(65,39,0),Color.rgb(76,56,8),Color.rgb(255,228,153),
        Color.rgb(90,207,255),Color.rgb(8,49,76),Color.rgb(47,32,99),
        Color.rgb(7,8,21),Color.rgb(43,32,95),Color.rgb(232,225,255)
    )

    private fun roles(
        bg:Int,surface:Int,container:Int,elevated:Int,
        primary:Int,onPrimary:Int,primaryContainer:Int,onPrimaryContainer:Int,
        secondary:Int,tertiary:Int,onSurface:Int,onVariant:Int,
        outline:Int,outlineStrong:Int,success:Int,onSuccess:Int,successContainer:Int,onSuccessContainer:Int,
        error:Int,onError:Int,errorContainer:Int,onErrorContainer:Int,
        warning:Int,onWarning:Int,warningContainer:Int,onWarningContainer:Int,
        info:Int,infoContainer:Int,selected:Int,nav:Int,navSelected:Int,navOn:Int
    ) = RovexColorRoles(bg,surface,container,elevated,primary,onPrimary,primaryContainer,onPrimaryContainer,
        secondary,tertiary,onSurface,onVariant,outline,outlineStrong,success,onSuccess,successContainer,onSuccessContainer,
        error,onError,errorContainer,onErrorContainer,warning,onWarning,warningContainer,onWarningContainer,
        info,infoContainer,selected,nav,navSelected,navOn)
}
