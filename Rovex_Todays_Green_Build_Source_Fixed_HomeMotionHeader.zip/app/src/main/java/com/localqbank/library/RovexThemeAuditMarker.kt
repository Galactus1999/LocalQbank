package com.localqbank.library
object RovexThemeAuditMarker { const val SYSTEM="ROVEX_UI_309"; const val USER_THEMES="LIGHT,PASTEL,MINT,SUNSET,LAVENDER,AMOLED,PANDORA,SPACE" }
