package com.localqbank.library

/** Small semantic spacing vocabulary for the visual system. */
object RovexVisualSpacing {
    const val XXS_DP = 2
    const val XS_DP = 4
    const val SM_DP = 8
    const val MD_DP = 12
    const val LG_DP = 16
    const val XL_DP = 24
}
