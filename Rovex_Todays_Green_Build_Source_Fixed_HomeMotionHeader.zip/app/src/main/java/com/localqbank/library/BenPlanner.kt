package com.localqbank.library


class BenPlanner(
    private val knowledge: BenKnowledgeGraph,
    private val learner: BenLearnerModel
) {
    fun plan(query: String, knowledgeGraphEnabled: Boolean = true, precomputed: ClinicalKnowledgeLayer.Understanding? = null): BenCognitiveArchitecture.Plan {
        val understanding = if (knowledgeGraphEnabled) (precomputed ?: knowledgeUnderstanding(query)) else
            ClinicalKnowledgeLayer.Understanding(query, query, emptyList(), null, emptySet(), emptyList(), false, emptySet(), emptyList())
        val concepts = understanding.concepts.map { it.canonical }.take(8)
        val tools = linkedSetOf<String>()
        when (understanding.intent) {
            "management" -> tools += "management_reasoner"
            "diagnosis_investigation" -> tools += "diagnostic_reasoner"
            "mechanism" -> tools += "mechanism_reasoner"
            "pathology" -> tools += "pathology_reasoner"
            "imaging" -> tools += "imaging_reasoner"
            "genetics" -> tools += "genetics_reasoner"
            "complication_adverse_effect" -> tools += "safety_reasoner"
            "epidemiology" -> tools += "epidemiology_reasoner"
            "association" -> tools += "association_reasoner"
            else -> tools += "clinical_retrieval"
        }
        if (query.contains("wrong", true) || query.contains("mistake", true) || query.contains("weak", true)) tools += "learner_weakness"
        tools += "qbank_retrieval"
        val weakest = learner.weakest(concepts)
        if (weakest != null) {
            tools += "weakness_context"
            if (learner.stats(weakest).wrong >= 2) tools += "misconception_check"
        }
        if (query.contains("trap", true) || query.contains("except", true) || query.contains("incorrect", true) || query.contains("not true", true)) tools += "exam_trap_detector"
        if (query.contains("guideline", true) || query.contains("dose", true) || query.contains("cutoff", true) || query.contains("criteria", true)) tools += "evidence_caution"
        if (understanding.visualIntent) tools += "visual_question_retrieval"
        if (understanding.examTerms.isNotEmpty()) tools += "exam_terminology"
        val relationBoost = (understanding.concepts.sumOf { it.related.size } * 2).coerceAtMost(20)
        val weaknessBoost = weakest?.let { (100 - learner.stats(it).mastery) / 5 } ?: 0
        val confidence = (45 + concepts.size * 6 + relationBoost + weaknessBoost.coerceAtMost(12)).coerceIn(0, 95)
        return BenCognitiveArchitecture.Plan(query, understanding.intent, concepts, understanding.domains, tools.toList(), confidence)
    }

    private fun knowledgeUnderstanding(query: String): ClinicalKnowledgeLayer.Understanding = knowledge.understand(query)
}

