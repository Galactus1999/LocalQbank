package com.localqbank.library

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View

/** Premium surface primitives. Uses bounded translucency/highlights; no device-wide blur dependency. */
object RovexVisualSurfaceStyle {
    fun glass(context: Context, radiusDp: Float, prominent: Boolean = false): LayerDrawable {
        val d=context.resources.displayMetrics.density
        val r=radiusDp.coerceIn(8f,28f)*d
        val base=RovexVisualColors.glassBase(context,prominent)
        val tint=RovexVisualColors.glassTint(context,prominent)
        val fill=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(base,base,Color.argb((Color.alpha(base)*.88f).toInt(),Color.red(base),Color.green(base),Color.blue(base)))).apply{cornerRadius=r}
        val tintLayer=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,intArrayOf(tint,Color.TRANSPARENT)).apply{cornerRadius=r}
        val sheen=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,intArrayOf(RovexVisualColors.glassSheen(context),Color.TRANSPARENT,RovexVisualColors.glassShadow(context))).apply{cornerRadius=r}
        val border=GradientDrawable().apply{setColor(Color.TRANSPARENT);cornerRadius=r;setStroke((d).toInt().coerceAtLeast(1),RovexVisualColors.glassHighlight(context))}
        return LayerDrawable(arrayOf(fill,tintLayer,sheen,border))
    }
    fun apply(view:View,context:Context,radiusDp:Float,prominent:Boolean=false,touch:Boolean=true){
        view.background=glass(context,radiusDp,prominent)
        if(touch&&(view.isClickable||view.hasOnClickListeners())) RovexTouchFeedback.bind(view)
    }
}
