package com.localqbank.library

import android.database.sqlite.SQLiteDatabase

/** Read-only catalog of explicitly deleted sources whose physical cleanup is still pending. */
internal class QBankDeletedSourceRepository(private val dbProvider: () -> SQLiteDatabase) {
    data class PendingDeletedQBank(
        val id: Long,
        val name: String,
        val provider: String,
        val importedAt: Long,
        val testCount: Int,
        val questionCount: Int,
        val ageLabel: String
    )

    private val db: SQLiteDatabase get() = dbProvider()

    fun isPending(sourceId: Long): Boolean {
        if (sourceId <= 0L) return false
        return db.rawQuery(
            "SELECT 1 FROM source WHERE id=? AND deleting=1 AND COALESCE(delete_requested,0)=1 LIMIT 1",
            arrayOf(sourceId.toString())
        ).use { it.moveToFirst() }
    }

    fun list(): List<PendingDeletedQBank> = db.rawQuery(
        """
        SELECT s.id,COALESCE(s.display_name,s.file_name,''),COALESCE(s.provider,''),s.imported_at,
               (SELECT COUNT(*) FROM test t WHERE t.source_id=s.id),
               (SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=s.id)
        FROM source s
        WHERE s.deleting=1 AND COALESCE(s.delete_requested,0)=1
        ORDER BY s.imported_at DESC,s.id DESC
        """.trimIndent(), null
    ).use { c ->
        buildList {
            while (c.moveToNext()) add(
                PendingDeletedQBank(
                    c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getInt(4), c.getInt(5),
                    ageLabel(c.getLong(3))
                )
            )
        }
    }

    private fun ageLabel(importedAt: Long): String {
        if (importedAt <= 0L) return "Pending cleanup"
        val days = ((System.currentTimeMillis() - importedAt).coerceAtLeast(0L) / 86_400_000L)
        return when {
            days == 0L -> "Imported today"
            days == 1L -> "Imported yesterday"
            else -> "Imported $days days ago"
        }
    }
}
