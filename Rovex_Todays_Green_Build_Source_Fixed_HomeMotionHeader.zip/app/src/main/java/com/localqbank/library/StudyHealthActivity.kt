package com.localqbank.library

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.localqbank.library.learning.LocalLearningObservatoryRepository
import com.localqbank.library.learning.LearningSnapshot

/** Read-only study-health surface over existing flashcard, progress and streak data. */
class StudyHealthActivity : Activity() {
    private lateinit var content: LinearLayout
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=13f,bold:Boolean=false,col:Int=ThemeManager.text(this))=TextView(this).apply{
        text=s;textSize=size;setTextColor(col);if(bold)setTypeface(typeface,Typeface.BOLD);setLineSpacing(0f,1.12f)
    }
    private fun panel(index:Int=0)=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(ThemeManager.pastelAccentFill(this@StudyHealthActivity,index),ThemeManager.elevated(this@StudyHealthActivity))).apply{
        cornerRadius=dp(22).toFloat();setStroke(dp(1),ThemeManager.accent(this@StudyHealthActivity))
    }
    override fun onCreate(b:Bundle?){super.onCreate(b);SystemUi.immersive(this);build();load()}
    private fun build(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(20));background=ThemeManager.backgroundDrawable(this@StudyHealthActivity)}
        val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        head.addView(text("←",25f,false).apply{gravity=Gravity.CENTER;background=panel(0);setOnClickListener{finish()}},LinearLayout.LayoutParams(dp(50),dp(50)))
        head.addView(text("Study Health",27f,true).apply{setPadding(dp(13),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        root.addView(head)
        root.addView(text("A read-only view of the study signals Rovex already has.",11.5f,false,ThemeManager.muted(this)).apply{setPadding(dp(3),dp(8),dp(3),dp(10))})
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this).apply{addView(content)}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root);RovexThemeTransition.prepareEntry(root);AdaptiveTypographyManager.apply(root)
    }
    private fun load(){
        content.removeAllViews()
        content.addView(text("Reading your local study data…",12f,false,ThemeManager.muted(this)))
        PerformanceManager.submit {
            val snap=runCatching{LocalLearningObservatoryRepository(applicationContext).snapshot()}.getOrNull()
            runOnUiThread{if(!isFinishing&&!isDestroyed){content.removeAllViews();if(snap==null)empty() else render(snap)}}
        }
    }
    private fun empty(){content.addView(text("Study Health is unavailable right now. Your study data has not been changed.",13f,false,ThemeManager.muted(this)).apply{setPadding(dp(8),dp(18),dp(8),0)})}
    private fun render(s:LearningSnapshot){
        val overview=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=panel(1)}
        overview.addView(text("STUDY HEALTH",10f,true,ThemeManager.muted(this)))
        overview.addView(text("${s.questionsAttempted} answered • ${s.accuracyPercent}% accuracy",20f,true).apply{setPadding(0,dp(5),0,dp(2))})
        overview.addView(text("${s.recentMinutes} min recorded • ${s.dueFlashcards} flashcards due",11.5f,false,ThemeManager.muted(this)))
        content.addView(overview,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})

        val due=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=panel(2)}
        due.addView(text("🧠  DUE CARDS",10f,true,ThemeManager.muted(this)))
        due.addView(text(if(s.dueFlashcards>0)"${s.dueFlashcards} flashcards need review" else "No flashcards are currently due",18f,true).apply{setPadding(0,dp(5),0,dp(3))})
        due.addView(text("Review due cards before adding more new material.",11.5f,false,ThemeManager.muted(this)))
        if(s.dueFlashcards>0) due.addView(action("REVIEW DUE CARDS"){startActivity(Intent(this,FlashcardStudyActivity::class.java).putExtra("mode","due"))},LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(9)})
        content.addView(due,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})

        val weak=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=panel(3)}
        weak.addView(text("⚠  WEAK AREAS",10f,true,ThemeManager.muted(this)))
        if(s.weakAreas.isEmpty()) weak.addView(text("Not enough answered data yet to identify weak areas.",12f,false,ThemeManager.muted(this)).apply{setPadding(0,dp(7),0,0)})
        else s.weakAreas.take(6).forEachIndexed{i,w->
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(7),0,dp(2));isClickable=true;setOnClickListener{startActivity(Intent(this@StudyHealthActivity,RovexSectionDashboardActivity::class.java).putExtra("section","qbank").putExtra("focusKind","QBank"))}}
            row.addView(text("${w.label}  •  ${w.masteryPercent}%",14f,true))
            row.addView(text("${w.attempts} answered questions",10.5f,false,ThemeManager.muted(this)).apply{setPadding(0,dp(2),0,dp(2))})
            row.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=w.masteryPercent;progressTintList=android.content.res.ColorStateList.valueOf(ThemeManager.accent(this@StudyHealthActivity))},LinearLayout.LayoutParams(-1,dp(5)).apply{topMargin=dp(3)})
            weak.addView(row)
        }
        content.addView(weak,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})

        val streak=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=panel(0)}
        streak.addView(text("🔥  STREAK",10f,true,ThemeManager.muted(this)))
        val headline=when{ s.studiedToday -> "${s.streakDays} day streak protected"; s.streakAtRisk -> "Your ${s.streakDays}-day streak is at risk today"; else -> "Start today's study streak" }
        streak.addView(text(headline,18f,true).apply{setPadding(0,dp(5),0,dp(3))})
        streak.addView(text(when{s.studiedToday->"Today's study activity is already recorded.";s.streakAtRisk->"A study day was recorded yesterday. One focused session today keeps the current streak going.";else->"No active consecutive-day streak is currently recorded."},11.5f,false,ThemeManager.muted(this)))
        if(!s.studiedToday) streak.addView(action("START A STUDY SESSION"){startActivity(Intent(this,MainQBankLibraryActivity::class.java))},LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(9)})
        content.addView(streak,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})

        content.addView(text("Study Health uses existing local flashcard due state, QBank progress and the authoritative study-streak record. It does not create or modify study data.",10.5f,false,ThemeManager.muted(this)).apply{setPadding(dp(5),dp(4),dp(5),dp(20))})
    }
    private fun action(label:String,go:()->Unit)=TextView(this).apply{ text=label;textSize=11f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(this@StudyHealthActivity));background=panel(1);RovexTouchFeedback.bind(this);setOnClickListener{go()} }
}
