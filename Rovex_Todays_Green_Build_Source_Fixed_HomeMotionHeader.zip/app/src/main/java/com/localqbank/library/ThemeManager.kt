package com.localqbank.library

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable

/**
 * Sole visual-token owner. Theme profiles are immutable and cached so hot draw paths do not
 * repeatedly allocate palettes or query SharedPreferences.
 */
object ThemeManager {
    const val LIGHT="light"; const val PASTEL="pastel"; const val MINT="mint"; const val SUNSET="sunset"; const val LAVENDER="lavender"; const val AMOLED="amoled"; const val PANDORA="pandora"; const val SPACE="space"
    private const val PREF="ui"; private const val KEY="theme"

    @Volatile private var cachedKey: String? = null
    @Volatile private var cachedProfile: RovexThemeProfile? = null

    private fun normalize(raw:String?):String=when(raw){PASTEL,MINT,SUNSET,LAVENDER,AMOLED,PANDORA,SPACE,LIGHT->raw; "amoled_dark"->AMOLED; else->LIGHT}
    fun get(c:Context):String {
        val raw = c.applicationContext.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,LIGHT)
        val n = normalize(raw)
        if (raw != n) c.applicationContext.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,n).apply()
        return n
    }
    fun profile(c:Context):RovexThemeProfile {
        val key = get(c)
        val old = cachedProfile
        if (old != null && cachedKey == key) return old
        val next = RovexThemeProfile.forKey(key)
        cachedKey = key
        cachedProfile = next
        return next
    }
    fun set(c:Context,v:String){
        val key=normalize(v)
        c.applicationContext.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,key).apply()
        cachedKey=key
        cachedProfile=RovexThemeProfile.forKey(key)
    }
    fun isDark(c:Context)=profile(c).scene>=5
    fun bg(c:Context)=profile(c).backgroundA
    fun panel(c:Context)=profile(c).panel
    fun elevated(c:Context)=profile(c).elevated
    fun text(c:Context)=profile(c).text
    fun muted(c:Context)=profile(c).muted
    fun accent(c:Context)=profile(c).accent
    fun accentSecondary(c:Context)=profile(c).accentSecondary
    fun onAccent(c:Context):Int {
        val a=accent(c)
        val luminance=(0.2126*Color.red(a)+0.7152*Color.green(a)+0.0722*Color.blue(a))/255.0
        return if(luminance>0.62) Color.rgb(8,20,28) else Color.WHITE
    }
    fun questionText(c:Context)=text(c); fun explanationText(c:Context)=text(c)
    fun aiText(c:Context)=if(isDark(c))Color.rgb(99,221,255) else Color.rgb(62,55,174)
    fun optionBg(c:Context)=if(isDark(c))Color.rgb(7,13,23) else Color.rgb(246,249,255)
    fun optionText(c:Context)=text(c)
    fun correctBg(c:Context)=if(isDark(c))Color.rgb(5,62,48) else Color.rgb(225,250,239)
    fun correctText(c:Context)=if(isDark(c))Color.rgb(86,255,189) else Color.rgb(0,119,78)
    fun wrongBg(c:Context)=if(isDark(c))Color.rgb(65,14,30) else Color.rgb(255,232,238)
    fun wrongText(c:Context)=if(isDark(c))Color.rgb(255,110,156) else Color.rgb(172,36,78)
    fun explanationBg(c:Context)=if(isDark(c))Color.rgb(7,12,20) else Color.rgb(241,247,255)
    fun explanationTitle(c:Context)=if(isDark(c))Color.rgb(255,181,58) else Color.rgb(79,67,190)
    fun dialogBg(c:Context)=if(isDark(c))Color.rgb(7,10,16) else Color.WHITE
    fun dialogText(c:Context)=text(c); fun dialogMuted(c:Context)=muted(c)
    private fun mix(a:Int,b:Int,t:Float):Int {
        val f=t.coerceIn(0f,1f);return Color.rgb((Color.red(a)+(Color.red(b)-Color.red(a))*f).toInt(),(Color.green(a)+(Color.green(b)-Color.green(a))*f).toInt(),(Color.blue(a)+(Color.blue(b)-Color.blue(a))*f).toInt())
    }
    fun peacockFill(c:Context)=mix(profile(c).panel,profile(c).accent,if(isDark(c)) .24f else .10f)
    fun peacockText(c:Context)=if(isDark(c)) profile(c).accentSecondary else mix(profile(c).accent,Color.BLACK,.30f)
    fun statsFill(c:Context)=if(isDark(c))Color.rgb(43,20,54) else Color.rgb(247,239,255); fun statsText(c:Context)=if(isDark(c))Color.rgb(255,145,225) else Color.rgb(113,49,145); fun resultBg(c:Context)=correctBg(c)
    fun bookmarkFill(c:Context,type:String):Int=if(isDark(c))when(type.lowercase()){"important"->Color.rgb(69,48,5);"revise"->Color.rgb(6,45,74);"favorite","favourite"->Color.rgb(66,17,43);else->Color.rgb(20,28,40)}else when(type.lowercase()){"important"->Color.rgb(255,242,196);"revise"->Color.rgb(225,239,255);"favorite","favourite"->Color.rgb(255,229,239);else->Color.rgb(238,243,250)}
    fun bookmarkText(c:Context,type:String)=if(isDark(c))Color.rgb(255,205,87) else Color.rgb(50,67,100)
    fun pastelBlueFill(c:Context)=when(get(c)){PANDORA->Color.rgb(6,42,58);SPACE->Color.rgb(13,28,65);AMOLED->Color.rgb(7,38,64);else->Color.rgb(222,241,255)}
    fun pastelBlueText(c:Context)=when(get(c)){PANDORA->Color.rgb(120,255,218);SPACE->Color.rgb(142,190,255);AMOLED->Color.rgb(93,210,255);else->Color.rgb(30,79,150)}
    fun pastelPinkFill(c:Context)=when(get(c)){PANDORA->Color.rgb(48,28,62);SPACE->Color.rgb(39,23,70);AMOLED->Color.rgb(61,18,47);else->Color.rgb(255,228,242)}
    fun pastelPinkText(c:Context)=when(get(c)){PANDORA->Color.rgb(238,157,255);SPACE->Color.rgb(221,169,255);AMOLED->Color.rgb(255,127,202);else->Color.rgb(139,48,111)}
    fun pastelRedFill(c:Context)=if(isDark(c))Color.rgb(62,20,23) else Color.rgb(255,232,224)
    fun pastelRedText(c:Context)=if(isDark(c))Color.rgb(255,142,110) else Color.rgb(171,64,31)
    fun pastelYellowFill(c:Context)=when(get(c)){PANDORA->Color.rgb(48,48,22);SPACE->Color.rgb(51,43,20);AMOLED->Color.rgb(62,45,7);else->Color.rgb(255,246,213)}
    fun pastelYellowText(c:Context)=when(get(c)){PANDORA->Color.rgb(255,235,125);SPACE->Color.rgb(255,221,133);AMOLED->Color.rgb(255,209,84);else->Color.rgb(130,91,0)}
    fun pastelLavenderFill(c:Context)=when(get(c)){PANDORA->Color.rgb(22,38,68);SPACE->Color.rgb(24,29,74);AMOLED->Color.rgb(34,22,72);else->Color.rgb(238,232,255)}
    fun pastelLavenderText(c:Context)=when(get(c)){PANDORA->Color.rgb(143,218,255);SPACE->Color.rgb(164,194,255);AMOLED->Color.rgb(184,154,255);else->Color.rgb(82,55,151)}
    fun pastelAccentFill(c:Context,index:Int):Int {
        val i=((index%4)+4)%4
        return when(get(c)) {
            LIGHT -> when(i){0->Color.rgb(235,244,255);1->Color.rgb(246,240,255);2->Color.rgb(255,247,224);else->Color.rgb(232,250,247)}
            PASTEL -> when(i){0->Color.rgb(224,235,255);1->Color.rgb(255,226,243);2->Color.rgb(255,241,203);else->Color.rgb(230,224,255)}
            MINT -> when(i){0->Color.rgb(218,247,237);1->Color.rgb(215,242,248);2->Color.rgb(237,249,220);else->Color.rgb(218,240,231)}
            SUNSET -> when(i){0->Color.rgb(255,230,211);1->Color.rgb(255,218,224);2->Color.rgb(255,241,205);else->Color.rgb(250,224,242)}
            LAVENDER -> when(i){0->Color.rgb(232,225,255);1->Color.rgb(247,225,250);2->Color.rgb(225,232,255);else->Color.rgb(241,229,255)}
            else -> when(i){0->pastelBlueFill(c);1->pastelPinkFill(c);2->pastelYellowFill(c);else->pastelLavenderFill(c)}
        }
    }
    fun pastelAccentText(c:Context,index:Int)=when(index%4){0->pastelBlueText(c);1->pastelPinkText(c);2->pastelYellowText(c);else->pastelLavenderText(c)}
    fun transparentSectionDrawable(c:Context):Drawable=GradientDrawable().apply{setColor(Color.TRANSPARENT);setStroke((c.resources.displayMetrics.density).toInt().coerceAtLeast(1),Color.argb(if(isDark(c))110 else 65,Color.red(accent(c)),Color.green(accent(c)),Color.blue(accent(c))));cornerRadius=profile(c).cornerDp*c.resources.displayMetrics.density}
    fun backgroundDrawable(c:Context):Drawable {
        val base: Drawable = if (RovexLiveMotionSettings.enabled(c) && AnimationPolicy.enabled(c)) RovexImportedMotionBackgroundDrawable(c, profile(c)) else GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(profile(c).backgroundA, profile(c).backgroundB))
        val custom = RovexWallpaperManager.bitmap(c, get(c))
        val bundled = if (custom == null && get(c) == PASTEL) RovexBundledVisualAssets.bitmapIfReady(c) else null
        val bitmap = custom ?: bundled ?: return base
        val alpha = if (custom != null) { if (isDark(c)) 76 else 26 } else 30
        val wallpaper = RovexWallpaperDrawable(bitmap, alpha)
        return LayerDrawable(arrayOf(base, wallpaper))
    }
}
