package com.localqbank.library

import android.database.sqlite.SQLiteDatabase

/** Read-side dashboard aggregation kept separate from the QBank compatibility façade. */
internal class QBankDashboardRepository(
    private val databaseProvider: () -> SQLiteDatabase
) {
    private val db: SQLiteDatabase get() = databaseProvider()

fun dashboardTestRows(): List<DashboardTestRow> {
    // Dashboard rendering must never scan/materialize the question corpus. The imported
    // test row already owns the authoritative question count; durable progress is sparse
    // in progress_v2 and can be aggregated independently. This keeps opening the QBank
    // dashboard proportional to the number of sub-QBanks rather than total questions.
    val sql = """
        SELECT t.id,
               COALESCE(t.title, ''),
               COALESCE(t.path, ''),
               COALESCE(s.display_name, s.file_name, ''),
               COALESCE(t.num_questions, 0),
               COALESCE(src_totals.source_total, 0),
               COALESCE(p.solved, 0),
               COALESCE(p.correct, 0),
               COALESCE(CAST(m.meta_value AS INTEGER), 0)
        FROM test t
        JOIN source s ON s.id=t.source_id AND s.deleting=0
        LEFT JOIN (
            SELECT test_id,
                   SUM(CASE WHEN status IS NOT NULL AND status <> '' THEN 1 ELSE 0 END) AS solved,
                   SUM(CASE WHEN status = 'correct' THEN 1 ELSE 0 END) AS correct
            FROM progress_v2
            WHERE test_id IS NOT NULL AND test_id <> ''
            GROUP BY test_id
        ) p ON p.test_id=t.id
        LEFT JOIN (
            SELECT source_id, SUM(COALESCE(num_questions,0)) AS source_total
            FROM test
            GROUP BY source_id
        ) src_totals ON src_totals.source_id=t.source_id
        LEFT JOIN progress_meta m ON m.meta_key=(t.id || ':position')
        ORDER BY s.imported_at DESC, t.rowid
    """.trimIndent()
    return db.rawQuery(sql, null).use { c ->
        buildList {
            while (c.moveToNext()) {
                add(DashboardTestRow(
                    testId = c.getString(0),
                    name = c.getString(1),
                    path = c.getString(2),
                    source = c.getString(3),
                    total = c.getInt(4),
                    sourceTotal = c.getInt(5),
                    solved = c.getInt(6),
                    correct = c.getInt(7),
                    position = c.getInt(8).coerceAtLeast(0)
                ))
            }
        }
    }
}
}
