package com.localqbank.library

import android.content.Context

/** Shared compatibility owner for ProgressStore's QBankDb identity. */
internal object ProgressDbRegistry {
    @Volatile private var instance: QBankDb? = null

    fun get(context: Context): QBankDb {
        instance?.let { return it }
        return synchronized(this) {
            instance ?: QBankDb(context.applicationContext).also { instance = it }
        }
    }
}
