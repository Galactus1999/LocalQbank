package com.localqbank.library

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.widget.TextView

/** Applies the first consolidated Rovex action-button contract without owning theme state. */
object RovexVisualButtonStyle {
    fun apply(view: TextView, context: Context, emphasized: Boolean = false) {
        view.setTextColor(
            if (emphasized) RovexVisualColors.onAccent(context)
            else RovexVisualColors.controlText(context)
        )
        val density = context.resources.displayMetrics.density
        val radius = RovexVisualShapes.controlCornerDp(context) * density
        val fill = GradientDrawable().apply {
            setColor(if (emphasized) RovexVisualColors.accentFill(context) else RovexVisualColors.controlFill(context))
            cornerRadius = radius
            setStroke((1f * density).toInt().coerceAtLeast(1), RovexVisualColors.border(context, emphasized))
        }
        view.background = RippleDrawable(
            ColorStateList.valueOf(RovexVisualColors.controlRipple(context)),
            fill,
            null
        )
        view.isClickable = true
        view.isFocusable = true
        view.stateListAnimator = null
        RovexTouchFeedback.bind(view)
    }
}
