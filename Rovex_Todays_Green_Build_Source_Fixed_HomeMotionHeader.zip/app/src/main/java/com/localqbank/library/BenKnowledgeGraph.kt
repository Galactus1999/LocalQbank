package com.localqbank.library

import android.content.Context

class BenKnowledgeGraph(context: Context) {
    private val app = context.applicationContext
    private val clinical = ClinicalKnowledgeLayer(app)

    data class Concept(
        val id: String,
        val label: String,
        val domains: Set<String>,
        val related: List<String>
    )

    fun resolve(query: String, max: Int = 8): List<Concept> = clinical.understand(query).concepts.take(max).map {
        Concept(it.id, it.canonical, it.domains, it.related)
    }

    fun expansions(query: String, max: Int = 32): List<String> = clinical.understand(query).expansions.take(max)

    fun understand(query: String): ClinicalKnowledgeLayer.Understanding = clinical.understand(query)

    fun relationCount(concepts: List<Concept>): Int = concepts.sumOf { it.related.size }.coerceAtMost(128)
}
