package com.localqbank.library

import android.database.sqlite.SQLiteDatabase
import android.util.Log

/**
 * Read-only search repository. Owns FTS/LIKE retrieval and section discovery;
 * QBankDb remains the compatibility façade and search-index lifecycle owner.
 */
internal class QBankSearchRepository(
    private val databaseProvider: () -> SQLiteDatabase
) {
    private val db: SQLiteDatabase get() = databaseProvider()

private fun images(qid: Long, kind: String): List<String> =
    db.rawQuery("SELECT uri FROM question_image WHERE question_id=? AND kind=? ORDER BY position", arrayOf(qid.toString(), kind))
        .use { c -> buildList { while (c.moveToNext()) add(c.getString(0)) } }

private fun stableKey(testId: String, position: Int, sourceQuestionId: String?): String =
    "$testId:$position:${sourceQuestionId.orEmpty()}"

fun search(query:String, resultLimit:Int = 400):List<SearchHit>{
    val rawTokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
    if(rawTokens.isEmpty()) return emptyList()
    // Natural-language questions contain grammatical stop words. Requiring every surface
    // token in FTS made normal questions such as "What is the mechanism of action of
    // atropine?" fail even when the clinical terms were present. Keep strict recall first,
    // then broaden to meaningful-token recall; Ben/Ren performs the semantic ranking later.
    val stopWords=setOf("a","an","the","is","are","was","were","be","been","being",
        "what","which","who","whom","whose","where","when","why","how","does","do","did",
        "can","could","will","would","should","may","might","of","to","in","on","at","for",
        "from","with","by","and","or","but","as","than","then","this","that","these","those",
        "please","tell","me","give","show","find","search","about","question","questions")
    val meaningful=rawTokens.flatMap{it.replace(Regex("[^\\p{L}\\p{N}_%\\\\]+")," ").split(Regex("\\s+"))}
        .filter{it.length>=2 && it.lowercase() !in stopWords}.distinct().take(8)
    val ftsTokens=if(meaningful.isNotEmpty()) meaningful else rawTokens
    val tokens=ftsTokens
    // Literal punctuation must bypass FTS tokenization. This preserves exact search semantics
    // for %, _, backslash, and hyphen-bearing question/import identities.
    val hasLikeLiteralSyntax=rawTokens.any { raw -> raw.any { it == '%' || it == '_' || it == '\\' } }
    val hasHyphenSyntax=rawTokens.any { raw -> raw.contains('-') }
    val likeTokens=rawTokens.mapNotNull { raw ->
        if (raw.any { it == '%' || it == '_' || it == '\\' }) raw
        else raw.takeIf { it.length >= 2 && it.lowercase() !in stopWords }
    }.distinct().take(8).ifEmpty { rawTokens }
    val limit=resultLimit.coerceIn(1,1200)
    val fullQuery=query.trim().lowercase()
    fun read(match:String):List<SearchHit> =db.rawQuery(
        "SELECT q.id,q.test_id,t.title,q.position,q.source_question_id,q.text,t.path,COALESCE(s.display_name,s.file_name) FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE question_fts MATCH ? ORDER BY CASE WHEN lower(q.text) LIKE ? ESCAPE CHAR(92) THEN 0 WHEN lower(t.title) LIKE ? ESCAPE CHAR(92) OR lower(COALESCE(t.path,'')) LIKE ? ESCAPE CHAR(92) OR lower(COALESCE(s.display_name,s.file_name)) LIKE ? ESCAPE CHAR(92) THEN 1 ELSE 2 END, s.imported_at DESC,t.rowid,q.position LIMIT $limit",
        arrayOf(match,QBankSearchSql.likePattern(fullQuery),QBankSearchSql.likePattern(fullQuery),QBankSearchSql.likePattern(fullQuery),QBankSearchSql.likePattern(fullQuery))
    ).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
    try {
        if (hasHyphenSyntax) {
            // FTS treats '-' as an operator unless the surface form is quoted.
            // Quoted FTS preserves token boundaries: "question-A" matches that
            // identity without broad substring matching such as question-A2.
            val hyphenQuery=rawTokens.filter { it.contains('-') }
                .joinToString(" ") { "\"${it.replace("\"", "\"\"")}\"" }
            val exact=read(hyphenQuery)
            if (exact.isNotEmpty()) return exact
        } else if (!hasLikeLiteralSyntax) {
            val strict=read(ftsTokens.joinToString(" AND "){"$it*"})
            if(strict.isNotEmpty()) return strict
            val broad=read(ftsTokens.joinToString(" OR "){"$it*"})
            if(broad.isNotEmpty()) return broad
        }
    } catch (e:Exception) {
        Log.w("QBankDb", "FTS search fallback: ${e.message}")
        ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.fts_search_failed:${e.javaClass.simpleName}")
    }
    fun likeRows(all:Boolean):List<SearchHit>{
        val plan = QBankSearchQueryBuilder.textLikePlan(likeTokens, limit, all)
        return db.rawQuery(plan.sql, plan.args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
    }
    if (hasLikeLiteralSyntax) return likeRows(true)
    // A hyphen query that reached this point did not produce an exact FTS hit.
    // Never broaden it to substring LIKE, which can conflate distinct identities.
    if (hasHyphenSyntax) return emptyList()
    val strictFallback=likeRows(true)
    return if(strictFallback.isNotEmpty() || likeTokens.size<=1) strictFallback else likeRows(false)
}

/**
 * Hard-filtered visual retrieval. A question must own at least one imported
 * question/explanation image; textual mentions of "image" are never sufficient.
 * This is intentionally separate from generic FTS search so a request such as
 * "pathology slides" can return image-bearing pathology questions whose stems
 * never contain the words slide/image.
 */
fun searchImageQuestions(query:String, resultLimit:Int = 400):List<SearchHit>{
    val rawTokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
    if(rawTokens.isEmpty()) return emptyList()
    val stopWords=setOf("a","an","the","is","are","was","were","be","been","being","what","which","who","whom","whose","where","when","why","how","does","do","did","can","could","will","would","should","may","might","of","to","in","on","at","for","from","with","by","and","or","but","as","than","then","this","that","these","those","please","tell","me","give","show","find","search","about","question","questions","image","images","visual","related")
    val meaningful=rawTokens.flatMap{it.replace(Regex("[^\\p{L}\\p{N}_%\\\\]+")," ").split(Regex("\\s+"))}
        .filter{it.length>=2 && it.lowercase() !in stopWords}.distinct().take(8)
    val ftsTokens=if(meaningful.isNotEmpty()) meaningful else rawTokens
    val tokens=ftsTokens
    val hasLikeLiteralSyntax=rawTokens.any { raw -> raw.any { it == '%' || it == '_' || it == '\\' } }
    val hasHyphenSyntax=rawTokens.any { raw -> raw.contains('-') }
    val likeTokens=rawTokens.mapNotNull { raw ->
        if (raw.any { it == '%' || it == '_' || it == '\\' }) raw
        else raw.takeIf { it.length >= 2 && it.lowercase() !in stopWords }
    }.distinct().take(8).ifEmpty { rawTokens }
    val safeLimit=resultLimit.coerceIn(1,1200)
    fun fts(match:String):List<SearchHit>{
        val sql="SELECT q.id,q.test_id,t.title,q.position,q.source_question_id,q.text,t.path,COALESCE(s.display_name,s.file_name) " +
            "FROM question_fts f JOIN question q ON q.id=f.question_id JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 " +
            "WHERE question_fts MATCH ? AND EXISTS(SELECT 1 FROM question_image qi WHERE qi.question_id=q.id) " +
            "ORDER BY s.imported_at DESC,t.rowid,q.position LIMIT $safeLimit"
        return db.rawQuery(sql,arrayOf(match)).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
    }
    try {
        if (hasHyphenSyntax) {
            val hyphenQuery=rawTokens.filter { it.contains('-') }
                .joinToString(" ") { "\"${it.replace("\"", "\"\"")}\"" }
            val exact=fts(hyphenQuery)
            if (exact.isNotEmpty()) return exact
        } else if (!hasLikeLiteralSyntax) {
            val strict=fts(ftsTokens.joinToString(" AND "){"$it*"})
            if(strict.isNotEmpty()) return strict
            val broad=fts(ftsTokens.joinToString(" OR "){"$it*"})
            if(broad.isNotEmpty()) return broad
        }
    } catch (e:Exception) {
        Log.w("QBankDb", "FTS search fallback: ${e.message}")
        ProductionCrashReporter.breadcrumb(RovexApplicationContextHolder.context, "QBankDb.fts_search_failed:${e.javaClass.simpleName}")
    }
    fun likeRows(all:Boolean):List<SearchHit>{
        val plan = QBankSearchQueryBuilder.textLikePlan(likeTokens, safeLimit, all)
        return db.rawQuery(plan.sql,plan.args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SearchHit(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(5) ?: "",c.getString(6),c.getString(7),stableKey(c.getString(1), c.getInt(3), c.getString(4))))}}
    }
    if (hasLikeLiteralSyntax) return likeRows(true)
    if (hasHyphenSyntax) return emptyList()
    val strictFallback=likeRows(true)
    return if(strictFallback.isNotEmpty() || likeTokens.size<=1) strictFallback else likeRows(false)
}

fun searchSections(query:String):List<SectionHit>{
    val tokens=query.trim().split(Regex("\\s+")).map{it.trim()}.filter{it.length>=2}.distinct().take(8)
    if(tokens.isEmpty()) return emptyList()
    // Hierarchy search is a recall problem, not an AND-filter problem. A subsection can
    // legitimately contain only one clinically meaningful token (e.g. "Cervix") while the
    // question corpus contains the full phrase. Use OR recall and rank rows by the number of
    // matched title/path/source tokens so QBank/sub-QBank discovery never collapses to empty.
    val clauses=tokens.map{ "(t.title LIKE ? ESCAPE CHAR(92) OR COALESCE(t.path,'') LIKE ? ESCAPE CHAR(92) OR COALESCE(s.display_name,s.file_name) LIKE ? ESCAPE CHAR(92))" }
    val whereArgs=tokens.flatMap{ val like=QBankSearchSql.likePattern(it); listOf(like,like,like) }
    val scoreParts=tokens.map{
        "CASE WHEN t.title LIKE ? ESCAPE CHAR(92) THEN 3 ELSE 0 END + " +
            "CASE WHEN COALESCE(t.path,'') LIKE ? ESCAPE CHAR(92) THEN 2 ELSE 0 END + " +
            "CASE WHEN COALESCE(s.display_name,s.file_name) LIKE ? ESCAPE CHAR(92) THEN 1 ELSE 0 END"
    }
    val scoreArgs=whereArgs
    val sql="SELECT t.id,t.title,COALESCE(t.path,''),COALESCE(s.display_name,s.file_name),t.num_questions FROM test t JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE ${clauses.joinToString(" OR ")} ORDER BY (${scoreParts.joinToString(" + ")}) DESC,s.imported_at DESC,t.rowid LIMIT 200"
    val args=whereArgs + scoreArgs
    return db.rawQuery(sql,args.toTypedArray()).use{c->buildList{while(c.moveToNext()) add(SectionHit(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4)))}}
}

}
