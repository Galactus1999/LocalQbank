package com.localqbank.library
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
object RovexModernUi {
 private fun dp(v:Int,view:View)= (v*view.resources.displayMetrics.density).toInt()
 private fun surface(view:View,fill:Int,stroke:Int,radius:Int=20)=RovexVisualSurfaceStyle.glass(view.context,radius.toFloat())
 fun applySection(root:View,a:RovexSectionDashboardActivity){root.setBackgroundColor(ThemeManager.bg(a));tintText(root,a);}
 fun applyRen(root:View,a:RenActivity){root.setBackgroundColor(ThemeManager.bg(a));tintText(root,a)}
 private fun tintText(v:View,a:android.app.Activity){if(v is TextView){val id=if(v.id!=View.NO_ID)runCatching{v.resources.getResourceEntryName(v.id).lowercase()}.getOrDefault("") else "";v.setTextColor(when{ id.contains("ai")||id.contains("ben")->ThemeManager.aiText(a);id.contains("hint")||id.contains("sub")||id.contains("stats")->ThemeManager.muted(a);else->ThemeManager.text(a)})};if(v is ViewGroup)for(i in 0 until v.childCount)tintText(v.getChildAt(i),a)}
 private fun styleButton(b:Button){val c=b.context;b.background=surface(b,ThemeManager.peacockFill(c),Color.argb(80,Color.red(ThemeManager.accent(c)),Color.green(ThemeManager.accent(c)),Color.blue(ThemeManager.accent(c))),16);b.setTextColor(ThemeManager.peacockText(c));b.stateListAnimator=null;b.minHeight=dp(42,b);b.isAllCaps=false;RovexTouchFeedback.bind(b)}
}
