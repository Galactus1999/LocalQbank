package com.localqbank.library

import android.content.Context
import java.util.Locale
import kotlin.math.roundToInt

class BenLearnerModel(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("ben_learner", Context.MODE_PRIVATE)
    private val clinical = ClinicalKnowledgeLayer(app)

    data class ConceptStats(val seen: Int, val wrong: Int, val correct: Int) {
        val mastery: Int
            get() = if (seen == 0) 0 else ((correct * 100.0) / seen).roundToInt().coerceIn(0, 100)
    }

    fun observeQuery(plan: BenCognitiveArchitecture.Plan) {
        plan.concepts.take(8).forEach { touch(it) }
    }

    fun observeQuestion(question: Question) {
        val understanding = clinical.understand(question.text)
        val progress = runCatching { PerformanceManager.progress(app) }.getOrNull()
        val record = progress?.record(question.stableKey)
        understanding.concepts.take(8).forEach { concept ->
            when (record?.status) {
                "wrong" -> update(concept.canonical, 1, 1, 0)
                "correct" -> update(concept.canonical, 1, 0, 1)
                else -> touch(concept.canonical)
            }
        }
    }

    fun stats(concept: String): ConceptStats {
        val key = key(concept)
        return ConceptStats(prefs.getInt("$key.seen", 0), prefs.getInt("$key.wrong", 0), prefs.getInt("$key.correct", 0))
    }

    fun weakest(concepts: List<String>): String? = concepts.minByOrNull { stats(it).mastery }

    private fun touch(concept: String) = update(concept, 1, 0, 0)

    private fun update(concept: String, seen: Int, wrong: Int, correct: Int) {
        val k = key(concept)
        val old = stats(concept)
        prefs.edit()
            .putInt("$k.seen", (old.seen + seen).coerceAtMost(100_000))
            .putInt("$k.wrong", (old.wrong + wrong).coerceAtMost(100_000))
            .putInt("$k.correct", (old.correct + correct).coerceAtMost(100_000))
            .apply()
    }

    private fun key(value: String): String = "c_${value.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(80)}"
}

