package com.localqbank.library

/**
 * Move-only extraction of the asynchronous question-load portion of QuizActivity.show().
 * This class owns only load fencing/cache population; question rendering remains in QuizActivity.
 */
class QuizQuestionLoader(
    private val quizViewModel: QuizViewModel,
    private val executor: LifecycleExecutor,
    private val cache: MutableMap<String, Question>,
    private val postToMain: (() -> Unit) -> Unit,
    private val isHostFinishing: () -> Boolean,
    private val showLoading: (String) -> Unit,
    private val showUnavailable: () -> Unit,
    private val onLoaded: () -> Unit
) {
    private var loadToken = 0L

    fun load(key: String) {
        showLoading("Loading question " + (quizViewModel.state.position + 1) + " / " + quizViewModel.state.questionCount + "…")
        loadToken++
        val token = loadToken
        executor.execute {
            var loaded: Question? = null
            var lastError: Throwable? = null
            repeat(3) { attempt ->
                if (loaded != null) return@repeat
                val result = runCatching {
                    if (quizViewModel.state.collectionMode) {
                        quizViewModel.state.collectionQuestionIds
                            .getOrNull(quizViewModel.state.position)
                            ?.let { quizViewModel.questionById(it) }
                    } else {
                        quizViewModel.questionAt(quizViewModel.state.testId, quizViewModel.state.position)
                    }
                }
                loaded = result.getOrNull()
                lastError = result.exceptionOrNull()
                if (loaded == null && attempt < 2) {
                    try { Thread.sleep(if (attempt == 0) 60L else 180L) }
                    catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return@repeat
                    }
                }
            }
            postToMain {
                if (isHostFinishing() || token != loadToken) return@postToMain
                if (loaded != null) {
                    synchronized(cache) { cache[key] = loaded!! }
                    onLoaded()
                } else {
                    if (lastError != null) {
                        ProductionCrashReporter.recordNonFatal(lastError!!, "QUIZ_QUESTION_LOAD_RETRY_EXHAUSTED")
                    }
                    showUnavailable()
                }
            }
        }
    }
}
