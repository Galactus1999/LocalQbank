package com.localqbank.library

import android.content.Context

/** Semantic shape tokens. Values derive from the authoritative theme profile. */
object RovexVisualShapes {
    fun controlCornerDp(context: Context): Float =
        (ThemeManager.profile(context).cornerDp * 0.5f).coerceIn(10f, 14f)
    fun prominentCornerDp(context: Context): Float =
        (ThemeManager.profile(context).cornerDp * 0.55f).coerceIn(11f, 15f)
}
