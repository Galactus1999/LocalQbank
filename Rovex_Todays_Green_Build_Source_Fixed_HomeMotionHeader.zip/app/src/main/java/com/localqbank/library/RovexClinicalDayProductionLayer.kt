package com.localqbank.library

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

/** Home color treatment: semantic, restrained and theme-specific. */
object RovexClinicalDayProductionLayer {
    private const val TAG = "ROVEX_COLOR_SYSTEM_625"
    private val cardIds = intArrayOf(
        R.id.renCard, R.id.todaySolvedCard, R.id.studyMenuCard,
        R.id.flashcardCard, R.id.performanceLabCard, R.id.homeSearchCard
    )

    fun apply(activity: MainActivity) {
        val root = activity.findViewById<ViewGroup>(R.id.dashboardRoot) ?: return
        if (root.getTag() == TAG) return
        root.setTag(TAG)
        root.background = RovexPremiumHomeBackdropDrawable(activity)
        cardIds.forEachIndexed { index, id ->
            activity.findViewById<View>(id)?.let { card ->
                styleCard(activity, card, index)
                bindPress(card)
            }
        }
        normalizeTextTree(activity, root)
    }

    private fun styleCard(activity: MainActivity, card: View, index: Int) {
        val p = RovexPremiumPalette.forKey(ThemeManager.get(activity), ThemeManager.isDark(activity))
        val fills = intArrayOf(p.surface, p.primaryContainer, p.surfaceContainer, p.selectedContainer)
        val fill = fills[index % fills.size]
        val stroke = if (index == 0) p.primary else if (index == 1) p.tertiary else p.outline
        card.background = GradientDrawable().apply {
            cornerRadius = activity.resources.displayMetrics.density * 24f
            setColor(fill)
            setStroke(activity.resources.displayMetrics.density.toInt().coerceAtLeast(1), stroke)
        }
        card.elevation = activity.resources.displayMetrics.density * if (ThemeManager.isDark(activity)) 2f else 3f
        card.clipToOutline = true
        if (card is ViewGroup) card.setPadding(dp(activity, 18), dp(activity, 16), dp(activity, 18), dp(activity, 16))
    }

    private fun normalizeTextTree(activity: MainActivity, parent: ViewGroup) {
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            if (child is ViewGroup) normalizeTextTree(activity, child)
            val tv = child as? TextView ?: continue
            if (child !is Button && child !is EditText && isCardDescendant(tv)) tv.background = null
            tv.includeFontPadding = false
            if (tv.maxLines <= 0 || tv.maxLines == Int.MAX_VALUE) tv.maxLines = 2
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            tv.setTextColor(ThemeManager.text(activity))
        }
    }

    private fun isCardDescendant(view: View): Boolean {
        var p = view.parent
        while (p is ViewGroup) {
            if (cardIds.contains(p.id)) return true
            p = p.parent
        }
        return false
    }

    private fun bindPress(view: View) { RovexTouchFeedback.bind(view) }

    private fun dp(c: android.content.Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
}
