package com.localqbank.library

/**
 * Explicit cognitive task graph used by Ben before retrieval/generation.
 * It is model-independent: a neural model may accelerate synthesis, but it cannot
 * silently remove required evidence or verification stages.
 */
data class BenCognitiveTask(
    val id: String,
    val type: Type,
    val objective: String,
    val dependsOn: List<String> = emptyList(),
    val concepts: List<String> = emptyList(),
    val required: Boolean = true
) {
    enum class Type {
        UNDERSTAND, RETRIEVE, CONNECT, COMPARE, EXPLAIN, PERSONALIZE, VISUAL_GROUND, VERIFY, COMPOSE
    }
}

data class BenCognitivePlan(
    val query: String,
    val tasks: List<BenCognitiveTask>,
    val intent: String?,
    val concepts: List<String>,
    val visualKinds: Set<String>,
    val estimatedHops: Int
) {
    val requiredTasks: List<BenCognitiveTask> get() = tasks.filter { it.required }
    val hasComparison: Boolean get() = tasks.any { it.type == BenCognitiveTask.Type.COMPARE }
    val hasMultiHop: Boolean get() = estimatedHops > 1
}

class BenTaskDecomposer {
    fun decompose(
        query: String,
        understanding: ClinicalKnowledgeLayer.Understanding,
        plan: BenCognitiveArchitecture.Plan
    ): BenCognitivePlan {
        val tasks = mutableListOf<BenCognitiveTask>()
        tasks += BenCognitiveTask("understand", BenCognitiveTask.Type.UNDERSTAND, "Normalize intent, concepts, exam terminology and modality.")
        tasks += BenCognitiveTask(
            "retrieve",
            BenCognitiveTask.Type.RETRIEVE,
            "Retrieve bounded authoritative local evidence.",
            dependsOn = listOf("understand"),
            concepts = plan.concepts
        )

        val related = understanding.concepts.flatMap { it.related }.distinct().take(6)
        if (related.isNotEmpty()) {
            tasks += BenCognitiveTask(
                "connect",
                BenCognitiveTask.Type.CONNECT,
                "Traverse concept relationships to find relevant second-hop evidence.",
                dependsOn = listOf("retrieve"),
                concepts = related
            )
        }

        if (isComparison(query)) {
            tasks += BenCognitiveTask(
                "compare",
                BenCognitiveTask.Type.COMPARE,
                "Build an explicit contrast between the requested entities and preserve distinguishing evidence.",
                dependsOn = listOf("retrieve", "connect").filter { id -> tasks.any { it.id == id } }
            )
        }
        if (understanding.intent in setOf("mechanism", "pathology", "management", "diagnosis_investigation", "association", "epidemiology")) {
            tasks += BenCognitiveTask(
                "explain",
                BenCognitiveTask.Type.EXPLAIN,
                "Construct a causal or exam-oriented explanation from grounded evidence.",
                dependsOn = listOf("retrieve", "connect").filter { id -> tasks.any { it.id == id } }
            )
        }
        if (understanding.visualIntent) {
            tasks += BenCognitiveTask(
                "visual_ground",
                BenCognitiveTask.Type.VISUAL_GROUND,
                "Require actual visual evidence before making an image finding claim.",
                dependsOn = listOf("retrieve"),
                concepts = understanding.visualKinds.toList()
            )
        }
        if (plan.concepts.isNotEmpty()) {
            tasks += BenCognitiveTask(
                "personalize",
                BenCognitiveTask.Type.PERSONALIZE,
                "Adjust emphasis using the learner's local mastery and repeated-error signals.",
                dependsOn = listOf("understand")
            )
        }
        tasks += BenCognitiveTask(
            "verify",
            BenCognitiveTask.Type.VERIFY,
            "Check evidence support, contradictions, critical numeric claims and citation integrity.",
            dependsOn = tasks.filter { it.id != "verify" }.map { it.id }.takeLast(4)
        )
        tasks += BenCognitiveTask(
            "compose",
            BenCognitiveTask.Type.COMPOSE,
            "Produce the final response only after the evidence gate succeeds.",
            dependsOn = listOf("verify")
        )
        return BenCognitivePlan(
            query = query,
            tasks = tasks,
            intent = understanding.intent,
            concepts = plan.concepts,
            visualKinds = understanding.visualKinds,
            estimatedHops = if (related.isEmpty()) 1 else 2
        )
    }

    private fun isComparison(query: String): Boolean = Regex(
        "\\b(compare|comparison|difference|differentiate|distinguish|versus|vs\\.?|between|contrast|similarity|similarities|how.*different)\\b",
        RegexOption.IGNORE_CASE
    ).containsMatchIn(query)
}
