package com.localqbank.library

import android.content.Context
import android.graphics.Color

/** Single semantic adapter between production views and the selected palette. */
object RovexVisualColors {
    private fun p(context: Context) =
        RovexPremiumPalette.forKey(ThemeManager.get(context), ThemeManager.isDark(context))

    fun background(context: Context): Int = p(context).background
    fun surface(context: Context): Int = p(context).surface
    fun container(context: Context): Int = p(context).surfaceContainer
    fun elevated(context: Context): Int = p(context).surfaceElevated
    fun controlFill(context: Context): Int = p(context).surfaceContainer
    fun controlText(context: Context): Int = p(context).onSurface
    fun accentFill(context: Context): Int = p(context).primary
    fun onAccent(context: Context): Int = p(context).onPrimary
    fun muted(context: Context): Int = p(context).onSurfaceVariant
    fun primaryContainer(context: Context): Int = p(context).primaryContainer
    fun onPrimaryContainer(context: Context): Int = p(context).onPrimaryContainer
    fun secondary(context: Context): Int = p(context).secondary
    fun tertiary(context: Context): Int = p(context).tertiary
    fun success(context: Context): Int = p(context).success
    fun successContainer(context: Context): Int = p(context).successContainer
    fun error(context: Context): Int = p(context).error
    fun errorContainer(context: Context): Int = p(context).errorContainer
    fun warning(context: Context): Int = p(context).warning
    fun warningContainer(context: Context): Int = p(context).warningContainer
    fun info(context: Context): Int = p(context).info
    fun selected(context: Context): Int = p(context).selectedContainer
    fun nav(context: Context): Int = p(context).navSurface
    fun navSelected(context: Context): Int = p(context).navSelected
    fun navOnSelected(context: Context): Int = p(context).navOnSelected

    fun border(context: Context, strong: Boolean = false): Int {
        val c = if (strong) p(context).outlineStrong else p(context).outline
        return c
    }

    fun glassBase(context: Context, prominent: Boolean = false): Int {
        val base=if(prominent)p(context).surfaceElevated else p(context).surface
        val alpha=if(ThemeManager.isDark(context)) if(prominent)150 else 126 else if(prominent)156 else 132
        return Color.argb(alpha,Color.red(base),Color.green(base),Color.blue(base))
    }
    fun glassTint(context: Context, prominent: Boolean = false): Int {
        val a=p(context).primary
        val alpha=if(ThemeManager.isDark(context)) if(prominent)34 else 24 else if(prominent)26 else 18
        return Color.argb(alpha,Color.red(a),Color.green(a),Color.blue(a))
    }
    fun glassHighlight(context: Context): Int =
        Color.argb(if(ThemeManager.isDark(context))72 else 108,255,255,255)
    fun glassSheen(context: Context): Int =
        Color.argb(if(ThemeManager.isDark(context))24 else 42,255,255,255)
    fun glassShadow(context: Context): Int =
        Color.argb(if(ThemeManager.isDark(context))46 else 22,0,0,0)

    fun controlRipple(context: Context): Int {
        val c = p(context).primary
        return Color.argb(if (ThemeManager.isDark(context)) 64 else 42, Color.red(c), Color.green(c), Color.blue(c))
    }
}
