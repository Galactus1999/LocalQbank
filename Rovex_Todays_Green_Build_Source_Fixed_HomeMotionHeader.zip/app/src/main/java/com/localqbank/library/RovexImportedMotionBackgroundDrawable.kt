package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import com.airbnb.lottie.LottieCompositionFactory
import com.airbnb.lottie.LottieDrawable

/** Theme background composed from theme tokens plus the imported, licensed Lottie motion asset. */
class RovexImportedMotionBackgroundDrawable(
    private val context: Context,
    profile: RovexThemeProfile
) : Drawable(), Drawable.Callback {
    private val base = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(profile.backgroundA, profile.backgroundB)
    )
    private val motion = LottieDrawable()
    private val motionAlpha = 18
    private var released = false

    init {
        base.callback = this
        motion.callback = this
        motion.repeatCount = LottieDrawable.INFINITE
        motion.repeatMode = LottieDrawable.RESTART
        motion.speed = 0.24f
        motion.setAlpha(motionAlpha)
        val first = RovexColorFlowTextView.colorOne(context)
        val second = RovexColorFlowTextView.colorTwo(context)
        val key = "rovex-live-wallpaper-" + ThemeManager.get(context) + "-" + first + "-" + second
        LottieCompositionFactory.fromJsonString(RovexMotionAssetLoader.themedJson(context, first, second), key)
            .addListener { composition ->
                if (released) return@addListener
                motion.composition = composition
                if (isVisible && allowed()) motion.playAnimation()
                invalidateSelf()
            }
            .addFailureListener { invalidateSelf() }
    }

    private fun allowed(): Boolean = !released && isVisible &&
        AnimationPolicy.enabled(context) && RovexLiveMotionSettings.enabled(context)

    override fun draw(canvas: Canvas) {
        base.bounds = bounds
        base.draw(canvas)
        if (!allowed()) {
            if (motion.isAnimating) motion.pauseAnimation()
            return
        }
        motion.bounds = bounds
        if (motion.composition != null && !motion.isAnimating) motion.playAnimation()
        motion.draw(canvas)
    }

    override fun onBoundsChange(bounds: Rect) {
        base.bounds = bounds
        motion.bounds = bounds
    }

    override fun setAlpha(alpha: Int) {
        base.setAlpha(alpha)
        motion.setAlpha((alpha * motionAlpha / 255).coerceIn(0, 255))
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        base.colorFilter = colorFilter
        motion.colorFilter = colorFilter
        invalidateSelf()
    }

    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        motion.setVisible(visible, restart)
        if (visible && allowed()) {
            if (restart) motion.progress = 0f
            if (motion.composition != null && !motion.isAnimating) motion.playAnimation()
        } else {
            motion.pauseAnimation()
        }
        return changed
    }

    override fun invalidateDrawable(who: Drawable) = invalidateSelf()
    override fun scheduleDrawable(who: Drawable, what: Runnable, time: Long) = scheduleSelf(what, time)
    override fun unscheduleDrawable(who: Drawable, what: Runnable) = unscheduleSelf(what)
    override fun onLevelChange(level: Int): Boolean = base.setLevel(level) || motion.setLevel(level)
    override fun onStateChange(state: IntArray): Boolean = base.setState(state) || motion.setState(state)
}
