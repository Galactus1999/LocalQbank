package com.localqbank.library

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Re-colours an imported licensed Lottie gradient; it never synthesizes or changes animation motion. */
object RovexMotionAssetLoader {
    private const val ASSET = "rovex/motion/gradient_animated_background.json"
    private val rawCache = ConcurrentHashMap<String, String>()
    private val themedCache = ConcurrentHashMap<String, String>()
    private const val MAX_THEMED_CACHE_ENTRIES = 8

    fun themedJson(context: Context, first: Int = RovexColorFlowTextView.colorOne(context),
                   second: Int = RovexColorFlowTextView.colorTwo(context)): String {
        val key = "$first:$second"
        return themedCache[key] ?: synchronized(this) {
            themedCache[key] ?: run {
                val raw = rawCache[ASSET] ?: context.applicationContext.assets.open(ASSET)
                    .bufferedReader().use { it.readText() }.also { rawCache[ASSET] = it }
                val json = JSONObject(raw)
                recolour(json, first, second)
                json.toString().also {
                    if (themedCache.size >= MAX_THEMED_CACHE_ENTRIES) {
                        themedCache.keys.firstOrNull()?.let { stale -> themedCache.remove(stale) }
                    }
                    themedCache[key] = it
                }
            }
        }
    }

    private fun recolour(node: Any?, first: Int, second: Int) {
        when (node) {
            is JSONObject -> {
                when (node.optString("ty")) {
                    "gf" -> recolourGradient(node.optJSONObject("g"), first, second)
                    "st" -> recolourSolid(node.optJSONObject("c")?.opt("k"), first)
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (key == "g" && node.optString("ty") == "gf") continue
                    if (key == "c" && node.optString("ty") == "st") continue
                    recolour(node.opt(key), first, second)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) recolour(node.opt(i), first, second)
        }
    }

    private fun recolourGradient(gradient: JSONObject?, first: Int, second: Int) {
        gradient ?: return
        recolourGradientValue(gradient.opt("k"), gradient.optInt("p", 3).coerceIn(2, 8), first, second)
    }

    private fun recolourGradientValue(value: Any?, stops: Int, first: Int, second: Int) {
        when (value) {
            is JSONObject -> {
                val keys = value.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val child = value.opt(key)
                    if ((key == "s" || key == "e") && child is JSONArray) recolourStops(child, stops, first, second)
                    else recolourGradientValue(child, stops, first, second)
                }
            }
            is JSONArray -> {
                if (value.length() >= stops * 4 && value.opt(0) is Number) recolourStops(value, stops, first, second)
                else for (i in 0 until value.length()) recolourGradientValue(value.opt(i), stops, first, second)
            }
        }
    }

    private fun recolourStops(values: JSONArray, stops: Int, first: Int, second: Int) {
        val usable = minOf(stops, values.length() / 4)
        for (i in 0 until usable) {
            val base = i * 4
            val t = values.optDouble(base, i.toDouble() / (usable - 1).coerceAtLeast(1)).toFloat().coerceIn(0f, 1f)
            val colour = mix(first, second, t)
            values.put(base + 1, Color.red(colour) / 255.0)
            values.put(base + 2, Color.green(colour) / 255.0)
            values.put(base + 3, Color.blue(colour) / 255.0)
        }
    }

    private fun recolourSolid(value: Any?, colour: Int) {
        if (value !is JSONArray || value.length() < 3) return
        value.put(0, Color.red(colour) / 255.0)
        value.put(1, Color.green(colour) / 255.0)
        value.put(2, Color.blue(colour) / 255.0)
    }

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt().coerceIn(0, 255)
    )
}
