package com.localqbank.library

import android.app.Activity
import android.graphics.Color
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.airbnb.lottie.RenderMode

/** External-asset motion bridge. It owns choreography only; no navigation or business state. */
object RovexMotionTransition {
    private const val ASSET = "rovex/motion/theme_transition.json"

    fun play(activity: Activity): Boolean {
        if (!AnimationPolicy.enabled(activity)) return false
        val decor = activity.window.decorView as? ViewGroup ?: return false
        val density = activity.resources.displayMetrics.density
        val motion = LottieAnimationView(activity).apply {
            setAnimation(ASSET)
            repeatCount = 0
            repeatMode = LottieDrawable.RESTART
            speed = 5f
            alpha = 0.82f
            setBackgroundColor(Color.TRANSPARENT)
            renderMode = RenderMode.HARDWARE
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            contentDescription = null
        }
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            (18f * density).toInt().coerceAtLeast(1),
            Gravity.TOP
        )
        decor.addView(motion, lp)
        runCatching { decor.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK) }
        motion.playAnimation()
        motion.postDelayed({
            runCatching { decor.removeView(motion) }
            runCatching { motion.cancelAnimation() }
        }, 180L)
        return true
    }
}
