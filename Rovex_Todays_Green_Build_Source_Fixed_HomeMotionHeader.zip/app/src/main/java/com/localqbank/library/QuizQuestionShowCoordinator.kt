package com.localqbank.library

import android.view.ViewGroup

/**
 * Move-only owner for the remaining QuizActivity.show() orchestration.
 * The coordinator is intentionally short-lived: callbacks are supplied by the Activity for one
 * show() invocation and are not retained after this call returns.
 */
class QuizQuestionShowCoordinator(
    private val content: ViewGroup,
    private val questionCache: MutableMap<String, Question>,
    private val quizViewModel: QuizViewModel,
    private val questionLoader: QuizQuestionLoader,
    private val questionStateCoordinator: QuizQuestionStateCoordinator,
    private val showQuestion: (Question, String?, Boolean, Boolean) -> Unit,
    private val postRender: () -> Unit,
    private val showNoQuestions: () -> Unit
) {
    fun show() {
        if (quizViewModel.state.questionCount == 0) {
            content.removeAllViews()
            showNoQuestions()
            return
        }

        val key = if (quizViewModel.state.collectionMode) {
            "id:${quizViewModel.state.collectionQuestionIds.getOrNull(quizViewModel.state.position) ?: -1L}"
        } else {
            "${quizViewModel.state.testId}:${quizViewModel.state.position}"
        }
        val q = synchronized(questionCache) { questionCache[key] }
        if (q == null) {
            questionLoader.load(key)
            return
        }

        content.removeAllViews()
        val prepared = questionStateCoordinator.prepare(q)
        showQuestion(q, prepared.status, prepared.answered, quizViewModel.state.examMode)
        postRender()
    }
}
