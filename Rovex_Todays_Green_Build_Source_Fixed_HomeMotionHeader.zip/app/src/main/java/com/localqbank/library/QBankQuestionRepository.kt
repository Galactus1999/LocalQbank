package com.localqbank.library

import android.database.sqlite.SQLiteDatabase

/**
 * Read-side QBank data source.
 *
 * QBankDb remains the compatibility facade and authoritative owner of database lifecycle.
 * This class owns only live-corpus catalog/question projections; it does not own deletion,
 * import, search-index maintenance, progress, or business-policy state.
 */
internal class QBankQuestionRepository(
    private val databaseProvider: () -> SQLiteDatabase
) {
    private val db: SQLiteDatabase get() = databaseProvider()

    fun questionExists(questionId: Long): Boolean = db.rawQuery(
        "SELECT 1 FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.id=? LIMIT 1",
        arrayOf(questionId.toString())
    ).use { it.moveToFirst() }

    fun aiIndexQuestionCount(): Int = db.rawQuery(
        "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0",
        null
    ).use { c -> c.moveToFirst(); c.getInt(0) }

    fun aiIndexBatch(afterQuestionId: Long = 0L, limit: Int = 64): List<AiIndexRow> {
        val safeLimit = limit.coerceIn(1, 256)
        val sql = "SELECT q.id, COALESCE(q.text,''), COALESCE(q.explanation,''), COALESCE(t.title,''), COALESCE(t.path,''), COALESCE(s.display_name,s.file_name,'') " +
            "FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 " +
            "WHERE q.id>? ORDER BY q.id LIMIT $safeLimit"
        return db.rawQuery(sql, arrayOf(afterQuestionId.toString())).use { c ->
            buildList {
                while (c.moveToNext()) add(AiIndexRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5)))
            }
        }
    }

    fun existingQuestionIds(ids: LongArray): LongArray {
        if (ids.isEmpty()) return longArrayOf()
        val out = ArrayList<Long>(ids.size)
        ids.distinct().chunked(500).forEach { chunk ->
            val placeholders = chunk.joinToString(",") { "?" }
            db.rawQuery(
                "SELECT q.id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.id IN ($placeholders)",
                chunk.map { it.toString() }.toTypedArray()
            ).use { c -> while (c.moveToNext()) out.add(c.getLong(0)) }
        }
        return out.toLongArray()
    }

    fun sources(): List<Source> = db.rawQuery(
        "SELECT id,COALESCE(display_name,file_name),provider,COALESCE(series_number,'') FROM source WHERE deleting=0 ORDER BY imported_at DESC",
        null
    ).use { c -> buildList { while (c.moveToNext()) add(Source(c.getLong(0),c.getString(1),c.getString(2),c.getString(3))) } }

    fun sourceById(sourceId: Long): Source? = db.rawQuery(
        "SELECT id,COALESCE(display_name,file_name),provider,COALESCE(series_number,'') FROM source WHERE id=? AND deleting=0 LIMIT 1",
        arrayOf(sourceId.toString())
    ).use { c -> if (c.moveToFirst()) Source(c.getLong(0),c.getString(1),c.getString(2),c.getString(3)) else null }

    fun sourceNameForTest(testId: String): String? = db.rawQuery(
        "SELECT COALESCE(s.display_name,s.file_name) FROM source s JOIN test t ON t.source_id=s.id WHERE t.id=? AND s.deleting=0 LIMIT 1",
        arrayOf(testId)
    ).use { c -> if (c.moveToFirst()) c.getString(0) else null }

    fun testById(testId: String): Test? = db.rawQuery(
        "SELECT t.id,t.title,t.path,t.num_questions,t.total_marks,t.duration_seconds,t.time_per_question,COALESCE(t.series_number,'') FROM test t JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.id=? LIMIT 1",
        arrayOf(testId)
    ).use { c ->
        if (c.moveToFirst()) Test(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getDouble(4),c.getInt(5),c.getDouble(6),c.getString(7)) else null
    }

    fun tests(sourceId: Long): List<Test> = db.rawQuery(
        "SELECT t.id,t.title,t.path,t.num_questions,t.total_marks,t.duration_seconds,t.time_per_question,COALESCE(t.series_number,'') FROM test t JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.source_id=? ORDER BY t.rowid",
        arrayOf(sourceId.toString())
    ).use { c ->
        buildList { while (c.moveToNext()) add(Test(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getDouble(4),c.getInt(5),c.getDouble(6),c.getString(7))) }
    }

    fun questionContext(questionId: Long): Pair<String,String> = db.rawQuery(
        "SELECT COALESCE(t.title,''), COALESCE(t.path,'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.id=? LIMIT 1",
        arrayOf(questionId.toString())
    ).use { c ->
        if (c.moveToFirst()) {
            val title = c.getString(0).orEmpty()
            val path = c.getString(1).orEmpty()
            val subject = path.split("/","\\",">","::").map { it.trim() }.filter { it.isNotBlank() }.firstOrNull()
                ?: title.substringBefore("-").trim()
            subject.ifBlank { "General" } to title.ifBlank { "Question $questionId" }
        } else "Unlinked" to "Question $questionId"
    }

    fun questionCount(testId: String): Int = db.rawQuery(
        "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.test_id=?",
        arrayOf(testId)
    ).use { c -> c.moveToFirst(); c.getInt(0) }

    fun questionByStableKey(stableKey: String): Question? {
        val parts = stableKey.split(":")
        if (parts.size < 3) return null
        val testId = parts.dropLast(2).joinToString(":")
        val position = parts[parts.size - 2].toIntOrNull() ?: return null
        val sourceQuestionId = parts.last()
        return questionAt(testId, position)?.takeIf { it.sourceId.orEmpty() == sourceQuestionId }
    }

    /** Return the quiz ordinal for an exact question id, not its imported raw position. */
    fun rawQuestionPosition(testId: String, questionId: Long): Int? = db.rawQuery(
        "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.test_id=? AND q.id=? AND s.deleting=0",
        arrayOf(testId, questionId.toString())
    ).use { exact ->
        if (!exact.moveToFirst() || exact.getInt(0) == 0) return@use null
        db.rawQuery(
            "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.test_id=? AND q.position < (SELECT position FROM question WHERE id=? AND test_id=?) AND s.deleting=0",
            arrayOf(testId, questionId.toString(), testId)
        ).use { c -> if (c.moveToFirst()) c.getInt(0) else null }
    }

    /**
     * Quiz position is an ordinal within the active QBank, not the imported q.position.
     * Imported/deleted data can leave gaps in q.position; addressing by equality therefore
     * produced null questions mid-session even though COUNT(*) still reported them.
     */
    fun questionAt(testId: String, position: Int): Question? = db.rawQuery(
        "SELECT q.id,q.position,q.source_question_id,COALESCE(q.text,''),q.raw_text,q.correct_answer,q.explanation,q.bot,q.video,q.audio FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.test_id=? AND s.deleting=0 ORDER BY q.position,q.id LIMIT 1 OFFSET ?",
        arrayOf(testId, position.coerceAtLeast(0).toString())
    ).use { c ->
        if (!c.moveToFirst()) return@use null
        val id = c.getLong(0)
        val opts = mutableListOf<Option>()
        db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position", arrayOf(id.toString())).use { o ->
            while (o.moveToNext()) opts.add(Option(o.getString(0) ?: "", o.getString(1) ?: "", o.getInt(2) != 0))
        }
        Question(id, stableKey(testId,c.getInt(1),c.getString(2)), c.getInt(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getString(7), c.getString(8), c.getString(9), opts, images(id,"question"), images(id,"explanation"))
    }

    fun questionById(questionId: Long): Question? = db.rawQuery("SELECT q.id,q.test_id,q.position,q.source_question_id,COALESCE(q.text,''),q.raw_text,q.correct_answer,q.explanation,q.bot,q.video,q.audio FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.id=? AND s.deleting=0 LIMIT 1",arrayOf(questionId.toString())).use { c ->
        if (!c.moveToFirst()) return@use null
        val id=c.getLong(0); val testId=c.getString(1); val rawPos=c.getInt(2); val sourceKey=c.getString(3)
        val opts=mutableListOf<Option>()
        db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position",arrayOf(id.toString())).use { o -> while(o.moveToNext()) opts.add(Option(o.getString(0) ?: "",o.getString(1) ?: "",o.getInt(2)!=0)) }
        Question(id,stableKey(testId,rawPos,sourceKey),rawPos,sourceKey,c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10),opts,images(id,"question"),images(id,"explanation"))
    }
    fun sourceIdForTest(testId: String): Long = db.rawQuery(
        "SELECT t.source_id FROM test t JOIN source s ON s.id=t.source_id WHERE t.id=? AND s.deleting=0 LIMIT 1",
        arrayOf(testId)
    ).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }

    fun testIdForQuestion(questionId: Long): String? = db.rawQuery(
        "SELECT q.test_id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.id=? AND s.deleting=0 LIMIT 1",
        arrayOf(questionId.toString())
    ).use { c -> if (c.moveToFirst()) c.getString(0) else null }

    fun questions(testId: String): List<Question> = db.rawQuery(
        "SELECT q.id,q.position,q.source_question_id,COALESCE(q.text,''),q.raw_text,q.correct_answer,q.explanation,q.bot,q.video,q.audio FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id WHERE q.test_id=? AND s.deleting=0 ORDER BY q.position",
        arrayOf(testId)
    ).use { c ->
        buildList {
            while (c.moveToNext()) {
                val id=c.getLong(0)
                val opts=mutableListOf<Option>()
                db.rawQuery("SELECT label,text,is_correct FROM option_item WHERE question_id=? ORDER BY position",arrayOf(id.toString())).use { o -> while(o.moveToNext()) opts.add(Option(o.getString(0) ?: "",o.getString(1) ?: "",o.getInt(2)!=0)) }
                add(Question(id,stableKey(testId,c.getInt(1),c.getString(2)),c.getInt(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),opts,images(id,"question"),images(id,"explanation")))
            }
        }
    }

    fun allStableKeys(): List<String> = db.rawQuery(
        "SELECT q.test_id,q.position,q.source_question_id FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 ORDER BY q.rowid",
        null
    ).use { c -> buildList { while(c.moveToNext()) add(stableKey(c.getString(0),c.getInt(1),c.getString(2))) } }

    fun allQuestionRefs(lightweight: Boolean = false): List<QuestionRef> {
        val textExpr = if (lightweight) "''" else "COALESCE(q.text,'')"
        val sql = "SELECT q.id,q.test_id,q.position,q.source_question_id,$textExpr,t.title,t.path,s.id,COALESCE(s.display_name,s.file_name) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 ORDER BY s.imported_at DESC,t.rowid,q.position"
        return db.rawQuery(sql,null).use { c -> buildList { while(c.moveToNext()) {
            val id=c.getLong(0); val testId=c.getString(1); val pos=c.getInt(2); val sid=c.getString(3)
            add(QuestionRef(id,"$testId:$pos:${sid ?: ""}",testId,pos,c.getString(4) ?: "",c.getString(5),c.getLong(7),c.getString(8),QBankCategoryClassifier.legacyCategory(c.getString(6),c.getString(5),c.getString(8))))
        } } }
    }

    fun questionRefsForStableKeys(keys: Collection<String>): List<QuestionRef> {
        if (keys.isEmpty()) return emptyList()
        val parsed = keys.mapNotNull { key ->
            val first=key.indexOf(':'); val last=key.lastIndexOf(':')
            if(first<=0 || last<=first || last>=key.lastIndex) null
            else Triple(key.substring(0,first),key.substring(first+1,last).toIntOrNull() ?: return@mapNotNull null,key.substring(last+1))
        }.distinct()
        if(parsed.isEmpty()) return emptyList()
        val out=ArrayList<QuestionRef>(parsed.size)
        parsed.chunked(100).forEach { chunk ->
            val where=chunk.joinToString(" OR ") { "(q.test_id=? AND q.position=?)" }
            val args=chunk.flatMap { listOf(it.first,it.second.toString()) }.toTypedArray()
            db.rawQuery("SELECT q.id,q.test_id,q.position,COALESCE(q.source_question_id,''),COALESCE(q.text,''),COALESCE(t.title,''),s.id,COALESCE(s.display_name,s.file_name,''),COALESCE(t.path,'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE $where ORDER BY s.imported_at DESC,t.rowid,q.position",args).use { c ->
                while(c.moveToNext()) { val testId=c.getString(1); val pos=c.getInt(2); val sourceQuestionId=c.getString(3); out.add(QuestionRef(c.getLong(0),stableKey(testId,pos,sourceQuestionId),testId,pos,c.getString(4),c.getString(5),c.getLong(6),c.getString(7),QBankCategoryClassifier.legacyCategory(c.getString(8),c.getString(5),c.getString(7)))) }
            }
        }
        return out
    }

    fun questionRefsForIdsBounded(ids: LongArray): List<QuestionRef> {
        if(ids.isEmpty()) return emptyList()
        val unique=ids.asList().distinct().take(100)
        val byId=LinkedHashMap<Long,QuestionRef>(unique.size)
        unique.chunked(100).forEach { chunk ->
            val placeholders=chunk.joinToString(",") { "?" }
            db.rawQuery("SELECT q.id,q.test_id,q.position,COALESCE(q.source_question_id,''),COALESCE(q.text,''),COALESCE(t.title,''),s.id,COALESCE(s.display_name,s.file_name,''),COALESCE(t.path,'') FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE q.id IN ($placeholders) ORDER BY q.id",chunk.map(Long::toString).toTypedArray()).use { c ->
                while(c.moveToNext()) { val testId=c.getString(1); val pos=c.getInt(2); val sourceQuestionId=c.getString(3); byId[c.getLong(0)]=QuestionRef(c.getLong(0),stableKey(testId,pos,sourceQuestionId),testId,pos,c.getString(4),c.getString(5),c.getLong(6),c.getString(7),QBankCategoryClassifier.legacyCategory(c.getString(8),c.getString(5),c.getString(7))) }
            }
        }
        return unique.mapNotNull { byId[it] }
    }

    fun questionRefsForIds(ids: LongArray): List<QuestionRef> = questionRefsForIdsBounded(ids)

    fun questionRefsByKeyword(keyword: String): List<QuestionRef> {
        val k=keyword.trim(); if(k.isBlank()) return emptyList()
        return allQuestionRefs().filter { it.testTitle.contains(k,true)||it.category.contains(k,true)||it.sourceName.contains(k,true) }
    }

    fun sourceQuestionCount(sourceId: Long): Int = db.rawQuery(
        "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id JOIN source s ON s.id=t.source_id AND s.deleting=0 WHERE t.source_id=?",
        arrayOf(sourceId.toString())
    ).use { c -> c.moveToFirst(); c.getInt(0) }

    fun testQuestionRefs(testId: String): List<QuestionRef> = allQuestionRefs().filter { it.testId == testId }

    private fun images(questionId: Long, kind: String): List<String> = db.rawQuery(
        "SELECT uri FROM question_image WHERE question_id=? AND kind=? ORDER BY position",
        arrayOf(questionId.toString(),kind)
    ).use { c -> buildList { while(c.moveToNext()) add(c.getString(0)) } }

    private fun stableKey(testId: String, position: Int, sourceQuestionId: String?): String = "$testId:$position:${sourceQuestionId.orEmpty()}"
}
