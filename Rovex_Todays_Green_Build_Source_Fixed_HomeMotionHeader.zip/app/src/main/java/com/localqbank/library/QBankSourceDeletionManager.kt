package com.localqbank.library

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabaseLockedException
import android.util.Log
import java.util.concurrent.locks.LockSupport
import java.util.concurrent.locks.ReentrantLock

/**
 * Owns physical QBank source deletion after a durable tombstone has been established.
 *
 * Contract:
 * - never performs an implicit/legacy destructive recovery;
 * - keeps the source tombstoned while cleanup is incomplete;
 * - deletes question-owned rows in bounded transactions;
 * - never performs synchronous whole-corpus FTS cleanup;
 * - is idempotent and safe for resumable WorkManager execution;
 * - resolves the provider-owned SQLite database per operation instead of retaining a stale handle.
 */
class QBankSourceDeletionManager(
    private val dbProvider: () -> SQLiteDatabase,
    private val appContext: Context,
    private val scheduleSearchIndexRepair: () -> Unit,
    private val markSearchIndexGarbagePending: () -> Unit
) {
    private val db: SQLiteDatabase
        get() = dbProvider()

    fun deleteSource(
        sourceId: Long,
        repairSearchIndex: Boolean = true,
        maxQuestionBatches: Int = Int.MAX_VALUE,
        shouldPause: (() -> Boolean)? = null
    ): Boolean {
        if (sourceId <= 0L) return false
        SOURCE_DELETION_LOCK.lock()
        return try {
            runCatching {
                val sourceName = sourceNameForId(sourceId)
                val exists = db.rawQuery(
                    "SELECT 1 FROM source WHERE id=? LIMIT 1",
                    arrayOf(sourceId.toString())
                ).use { it.moveToFirst() }
                if (!exists) {
                    val orphan = db.rawQuery(
                        "SELECT COUNT(*) FROM test WHERE source_id=?",
                        arrayOf(sourceId.toString())
                    ).use { c -> c.moveToFirst(); c.getLong(0) }
                    return@runCatching orphan == 0L
                }

                check(withWriteRetry("mark-source-deleting") { markSourceDeleting(sourceId) }) {
                    "QBank source disappeared before deletion started: $sourceId"
                }
                AppState.changed("qbank_delete_started")

                val globalResume = progressMeta("last_resume_global").orEmpty()
                val globalSolved = progressMeta("last_solved_global").orEmpty()
                val globalResumeBelongsToSource = db.rawQuery(
                    "SELECT EXISTS(SELECT 1 FROM test WHERE source_id=? AND id=substr(?,1,instr(?,'|')-1))",
                    arrayOf(sourceId.toString(), globalResume, globalResume)
                ).use { it.moveToFirst() && it.getInt(0) == 1 }
                val globalSolvedBelongsToSource = db.rawQuery(
                    "SELECT EXISTS(SELECT 1 FROM test WHERE source_id=? AND id=substr(?,1,instr(?,'|')-1))",
                    arrayOf(sourceId.toString(), globalSolved, globalSolved)
                ).use { it.moveToFirst() && it.getInt(0) == 1 }

                withWriteRetry("delete-progress") {
                    QBankWriteCoordinator.lock.lock()
                    try {
                    var transactionStarted = false
                    try {
                        db.beginTransactionNonExclusive()
                        transactionStarted = true
                        // Keep this set-based: large imports can have thousands of tests, and
                        // constructing a giant IN-list of test IDs both consumes memory and can
                        // approach SQLite's bind-variable limit.
                        db.delete(
                            "progress_v2",
                            "test_id IN (SELECT id FROM test WHERE source_id=?)",
                            arrayOf(sourceId.toString())
                        )
                        db.delete(
                            "progress_meta",
                            "meta_key IN (SELECT id || ':position' FROM test WHERE source_id=?) OR " +
                                "meta_key IN (SELECT id || ':completed' FROM test WHERE source_id=?)",
                            arrayOf(sourceId.toString(), sourceId.toString())
                        )
                        db.delete(
                            "progress_meta",
                            "meta_key=? OR meta_key=?",
                            arrayOf("source:$sourceId:resume", "sourceName:$sourceName:resume")
                        )
                        if (globalResumeBelongsToSource) putProgressMeta("last_resume_global", "")
                        if (globalSolvedBelongsToSource) putProgressMeta("last_solved_global", "")
                        db.setTransactionSuccessful()
                    } finally {
                        if (transactionStarted) db.endTransaction()
                    }
                    } finally {
                        QBankWriteCoordinator.lock.unlock()
                    }
                }

                var questionBatches = 0
                var paused = false
                while (true) {
                    if (shouldPause?.invoke() == true) {
                        paused = true
                        break
                    }
                    if (questionBatches >= maxQuestionBatches.coerceAtLeast(1)) break
                    val ids = db.rawQuery(
                        "SELECT q.id FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=? LIMIT 50",
                        arrayOf(sourceId.toString())
                    ).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0)) } }
                    if (ids.isEmpty()) break
                    val placeholders = ids.joinToString(",") { "?" }
                    val args = ids.map { it.toString() }.toTypedArray()
                    withWriteRetry("delete-question-batch") {
                        QBankWriteCoordinator.lock.lock()
                        try {
                        var transactionStarted = false
                        try {
                            db.beginTransactionNonExclusive()
                            transactionStarted = true
                            db.delete("option_item", "question_id IN ($placeholders)", args)
                            db.delete("question_image", "question_id IN ($placeholders)", args)
                            db.delete("question_note_image", "question_id IN ($placeholders)", args)
                            db.delete("question_note", "question_id IN ($placeholders)", args)
                            db.delete("progress", "question_id IN ($placeholders)", args)
                            db.delete("question", "id IN ($placeholders)", args)
                            db.setTransactionSuccessful()
                        } finally {
                            if (transactionStarted) db.endTransaction()
                        }
                        } finally {
                            QBankWriteCoordinator.lock.unlock()
                        }
                    }
                    questionBatches++
                    Thread.yield()
                    if (shouldPause?.invoke() == true) {
                        paused = true
                        break
                    }
                }

                if (paused) return@runCatching false

                val remainingAfterBudget = if (questionBatches >= maxQuestionBatches.coerceAtLeast(1)) {
                    db.rawQuery(
                        "SELECT 1 FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=? LIMIT 1",
                        arrayOf(sourceId.toString())
                    ).use { it.moveToFirst() }
                } else false
                if (remainingAfterBudget) return@runCatching false

                withWriteRetry("delete-source-finalize") {
                    QBankWriteCoordinator.lock.lock()
                    try {
                    var transactionStarted = false
                    try {
                        db.beginTransactionNonExclusive()
                        transactionStarted = true
                        db.delete("test", "source_id=?", arrayOf(sourceId.toString()))
                        db.delete(
                            "progress_meta",
                            "meta_key=? OR meta_key=?",
                            arrayOf("source:$sourceId:resume", "sourceName:$sourceName:resume")
                        )
                        db.delete("source", "id=?", arrayOf(sourceId.toString()))
                        val remainingTests = db.rawQuery(
                            "SELECT COUNT(*) FROM test WHERE source_id=?",
                            arrayOf(sourceId.toString())
                        ).use { c -> c.moveToFirst(); c.getLong(0) }
                        val remainingQuestions = db.rawQuery(
                            "SELECT COUNT(*) FROM question q JOIN test t ON t.id=q.test_id WHERE t.source_id=?",
                            arrayOf(sourceId.toString())
                        ).use { c -> c.moveToFirst(); c.getLong(0) }
                        check(remainingTests == 0L && remainingQuestions == 0L) {
                            "QBank delete postcondition failed: source=$sourceId tests=$remainingTests questions=$remainingQuestions"
                        }
                        db.setTransactionSuccessful()
                    } finally {
                        if (transactionStarted) db.endTransaction()
                    }
                    } finally {
                        QBankWriteCoordinator.lock.unlock()
                    }
                }

                markSearchIndexGarbagePending()
                if (repairSearchIndex) scheduleSearchIndexRepair()
                AppState.changed("qbank_deleted")
                true
            }.getOrElse { e ->
                QBankDeletionRecoveryWorker.markRecoveryNeeded(appContext)
                Log.e("QBankSourceDeletionManager", "QBank deletion interrupted for source=$sourceId", e)
                ProductionCrashReporter.recordNonFatal(
                    e,
                    "QBANK_DELETE",
                    mapOf("source_id" to sourceId.toString())
                )
                if (repairSearchIndex) scheduleSearchIndexRepair()
                false
            }
        } finally {
            SOURCE_DELETION_LOCK.unlock()
        }
    }

    private fun sourceNameForId(sourceId: Long): String = db.rawQuery(
        "SELECT COALESCE(display_name,file_name,'') FROM source WHERE id=? LIMIT 1",
        arrayOf(sourceId.toString())
    ).use { c -> if (c.moveToFirst()) c.getString(0).orEmpty() else "" }

    private fun progressMeta(key: String): String? = db.rawQuery(
        "SELECT meta_value FROM progress_meta WHERE meta_key=? LIMIT 1",
        arrayOf(key)
    ).use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun putProgressMeta(key: String, value: String?) {
        if (value == null) {
            db.delete("progress_meta", "meta_key=?", arrayOf(key))
        } else {
            db.execSQL(
                "INSERT OR REPLACE INTO progress_meta(meta_key,meta_value) VALUES(?,?)",
                arrayOf(key, value)
            )
        }
    }

    private fun markSourceDeleting(sourceId: Long): Boolean {
        QBankWriteCoordinator.lock.lock()
        var transactionStarted = false
        return try {
            db.beginTransactionNonExclusive()
            transactionStarted = true
            val changed = db.update(
                "source",
                android.content.ContentValues().apply {
                    put("deleting", 1)
                    put("delete_requested", 1)
                },
                "id=?",
                arrayOf(sourceId.toString())
            ) > 0
            db.setTransactionSuccessful()
            changed
        } finally {
            if (transactionStarted) db.endTransaction()
            QBankWriteCoordinator.lock.unlock()
        }
    }

    private inline fun <T> withWriteRetry(label: String, attempts: Int = 4, block: () -> T): T {
        var last: Throwable? = null
        for (attempt in 0 until attempts) {
            try {
                return block()
            } catch (t: SQLiteDatabaseLockedException) {
                last = t
                if (attempt + 1 >= attempts) break
                LockSupport.parkNanos((20L shl attempt).coerceAtMost(160L) * 1_000_000L)
                if (Thread.currentThread().isInterrupted) throw InterruptedException("QBank delete interrupted")
            }
        }
        throw last ?: IllegalStateException("$label failed")
    }

    companion object {
        private val SOURCE_DELETION_LOCK = ReentrantLock()
    }
}
