package com.localqbank.library

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.atomic.AtomicBoolean

/** Loads only verified, bundled third-party visual assets; never generates artwork. */
object RovexBundledVisualAssets {
    private const val MAX_EDGE = 1440
    @Volatile private var cachedWallpaper: Bitmap? = null
    private val loading = AtomicBoolean(false)

    fun preload(context: Context) {
        val app = context.applicationContext
        if (cachedWallpaper != null || !loading.compareAndSet(false, true)) return
        PerformanceManager.submit {
            val bitmap = decodeBounded(app)
            if (bitmap != null) cachedWallpaper = bitmap
            loading.set(false)
            if (bitmap != null) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    if (AppManagers.isReady()) AppState.changed("bundled_visual_asset_loaded")
                }
            }
        }
    }

    fun bitmapIfReady(context: Context): Bitmap? = cachedWallpaper

    private fun decodeBounded(context: Context): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeResource(context.resources, R.drawable.rovex_cc0_abstract_spiral, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
        var sample = 1
        while (bounds.outWidth / sample > MAX_EDGE * 2 || bounds.outHeight / sample > MAX_EDGE * 2) sample *= 2
        BitmapFactory.decodeResource(
            context.resources,
            R.drawable.rovex_cc0_abstract_spiral,
            BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
        )
    }.getOrNull()
}
