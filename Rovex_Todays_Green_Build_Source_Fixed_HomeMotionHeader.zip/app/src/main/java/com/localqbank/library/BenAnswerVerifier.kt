package com.localqbank.library

import android.content.Context
import java.util.Locale

class BenAnswerVerifier {
    /** Stable citation identity carried from the QBank hit through generation and verification. */
    data class EvidenceItem(val index: Int, val hitId: Long? = null, val text: String)

    enum class ClaimStatus { SUPPORTED, UNSUPPORTED_CRITICAL, NOT_APPLICABLE }

    data class ClaimCheck(
        val value: String,
        val context: String,
        val status: ClaimStatus,
        val evidenceIndex: Int? = null
    )

    data class Verification(
        val acceptable: Boolean,
        val score: Int,
        val criticalClaims: List<ClaimCheck> = emptyList(),
        val citationValid: Boolean = true
    )

    private data class NumberToken(
        val raw: String,
        val value: Double,
        val unit: String?,
        val start: Int,
        val end: Int
    )

    private data class NormalizedQuantity(val value: Double, val unit: String?)

    /**
     * Conservative evidence-grounded v1. This is deliberately NOT clinical NLU: it only
     * gates exam-critical numeric claims and critical recommendation phrases against the
     * retrieved QBank evidence. Unknown semantic relationships fail closed.
     */
    fun verify(
        query: String,
        answer: String,
        plan: BenCognitiveArchitecture.Plan,
        evidence: List<EvidenceItem> = emptyList()
    ): Verification {
        if (answer.isBlank()) return Verification(false, 0)
        var score = 45
        val lower = answer.lowercase(Locale.US)
        val conceptMatch = plan.concepts.any { lower.contains(it.lowercase(Locale.US).take(40)) }
        if (plan.concepts.isEmpty() || conceptMatch) score += 20
        if (plan.intent != null) score += 10
        if (conceptMatch) score += 10
        if (answer.length >= 40) score += 5
        if (answer.contains("could not", true) || answer.contains("try again", true)) score -= 20

        // Deterministic/local callers without grounded evidence retain the legacy lightweight gate.
        if (evidence.isEmpty()) return Verification(score >= 50, score.coerceIn(0, 100))

        val validEvidence = evidence.filter { it.index > 0 }.associateBy { it.index }
        val citations = extractCitations(answer)
        val citationValid = citations.all { it in validEvidence.keys }
        if (!citationValid) score -= 35

        val criticalClaims = extractCriticalNumericClaims(answer, validEvidence)
        val unsupported = criticalClaims.filter { it.status == ClaimStatus.UNSUPPORTED_CRITICAL }
        val criticalPhraseWithoutCitation = hasCriticalPhraseWithoutNearbyCitation(answer, validEvidence)
        val unsupportedVisualFinding = plan.visualIntent && hasVisualFindingWithoutNearbyCitation(answer, validEvidence)

        // Fail closed: a critical number that cannot be grounded, an invented citation, or a
        // critical recommendation without a nearby valid citation discards the neural draft.
        var acceptable = score >= 50 && citationValid && unsupported.isEmpty() && !criticalPhraseWithoutCitation && !unsupportedVisualFinding
        if (unsupported.isNotEmpty()) score -= 45
        if (criticalPhraseWithoutCitation) score -= 25
        if (unsupportedVisualFinding) score -= 25
        if (!citationValid) acceptable = false

        return Verification(acceptable, score.coerceIn(0, 100), criticalClaims, citationValid)
    }

    private fun extractCitations(answer: String): Set<Int> =
        Regex("\\[(\\d{1,2})\\]").findAll(answer).mapNotNull { it.groupValues[1].toIntOrNull() }.toSet()

    private fun extractCriticalNumericClaims(
        answer: String,
        evidence: Map<Int, EvidenceItem>
    ): List<ClaimCheck> {
        val out = mutableListOf<ClaimCheck>()
        val tokenRegex = Regex("(?<![A-Za-z\\[])(?:\\d+(?:\\.\\d+)?|\\.\\d+)(?:\\s*(?:%|mg/kg|g/kg|mcg/kg|µg/kg|mg|mcg|µg|μg|g|kg|ml|mL|l|L|d|day|days|wk|week|weeks|mo|month|months|yr|year|years))?(?![A-Za-z])")
        val criticalRegex = Regex(
            "\\b(age|aged|years? old|dose|dosage|mg|mcg|µg|microgram|milligram|gram|g/kg|mg/kg|ml|%|percent|cut[- ]?off|threshold|criterion|criteria|score|staging|stage|duration|days?|weeks?|months?|years?|interval|screening|first[- ]line|drug of choice|contraindicated|contraindication|mortality|sensitivity|specificity|pregnan(?:cy|t)|trimester|lab(?:oratory)?|hemoglobin|hb|wbc|platelet|creatinine|bilirubin|inr|glucose|pressure)\\b",
            RegexOption.IGNORE_CASE
        )

        for (m in tokenRegex.findAll(answer)) {
            val raw = m.value.replace(Regex("\\s+"), "").trim()
            val numeric = Regex("(?:\\d+(?:\\.\\d+)?|\\.\\d+)").find(raw)?.value?.toDoubleOrNull() ?: continue
            val unit = raw.dropWhile { c -> c.isDigit() || c == '.' }.lowercase(Locale.US).ifBlank { null }
            val token = NumberToken(raw, numeric, unit, m.range.first, m.range.last + 1)
            val contextStart = (token.start - 90).coerceAtLeast(0)
            val contextEnd = (token.end + 90).coerceAtMost(answer.length)
            val context = answer.substring(contextStart, contextEnd).replace(Regex("\\s+"), " ").trim()
            val immediateStart = (token.start - 45).coerceAtLeast(0)
            val immediateEnd = (token.end + 45).coerceAtMost(answer.length)
            val immediateContext = answer.substring(immediateStart, immediateEnd).replace(Regex("\\s+"), " ").trim()
            val isCriticalByUnit = token.unit in setOf("%", "mg", "mcg", "µg", "g", "mg/kg", "g/kg", "mcg/kg", "µg/kg", "kg", "ml", "l", "d", "day", "days", "wk", "week", "weeks", "mo", "month", "months", "yr", "year", "years")
            val isCriticalByCue = criticalRegex.findAll(immediateContext).any { cue ->
                val distance = kotlin.math.min(kotlin.math.abs(token.start - cue.range.first), kotlin.math.abs(token.end - cue.range.last - 1))
                distance <= 45
            }
            if (!isCriticalByUnit && !isCriticalByCue) continue

            val nearbyCitations = extractNearbyCitations(answer, token.start, token.end)
            val candidateEvidence = nearbyCitations.mapNotNull { evidence[it] }
            val searchEvidence = if (candidateEvidence.isNotEmpty()) candidateEvidence else emptyList()
            val matched = searchEvidence.firstOrNull { quantitySupportedNear(token, immediateContext, it.text) }
            if (matched != null) {
                out += ClaimCheck(token.raw, context, ClaimStatus.SUPPORTED, matched.index)
            } else {
                // No citation or no high-confidence numeric+context match: unsupported critical.
                out += ClaimCheck(token.raw, context, ClaimStatus.UNSUPPORTED_CRITICAL, null)
            }
        }

        // Explicit small equivalences: 1/2, 1/4, 3/4 and the words half/quarter.
        // These are only accepted when the evidence contains the same fraction/word or a
        // directly equivalent percentage (50/25/75). No general fraction semantics.
        val fractionRegex = Regex("\\b(1/2|1/4|3/4|half|quarter|three[- ]quarters?)\\b", RegexOption.IGNORE_CASE)
        for (m in fractionRegex.findAll(answer)) {
            val contextStart = (m.range.first - 110).coerceAtLeast(0)
            val contextEnd = (m.range.last + 111).coerceAtMost(answer.length)
            val context = answer.substring(contextStart, contextEnd).replace(Regex("\\s+"), " ").trim()
            if (!criticalRegex.containsMatchIn(context)) continue
            val nearby = extractNearbyCitations(answer, m.range.first, m.range.last + 1)
            val match = nearby.mapNotNull { evidence[it] }.firstOrNull { ev ->
                val e = ev.text.lowercase(Locale.US)
                when (m.value.lowercase(Locale.US)) {
                    "1/2", "half" -> e.contains("1/2") || e.contains("50%") || Regex("\\bhalf\\b").containsMatchIn(e)
                    "1/4", "quarter" -> e.contains("1/4") || e.contains("25%") || Regex("\\bquarter\\b").containsMatchIn(e)
                    else -> e.contains("3/4") || e.contains("75%") || Regex("three[- ]quarters?").containsMatchIn(e)
                }
            }
            out += ClaimCheck(m.value, context, if (match != null) ClaimStatus.SUPPORTED else ClaimStatus.UNSUPPORTED_CRITICAL, match?.index)
        }
        return out
    }

    private fun extractNearbyCitations(answer: String, start: Int, end: Int): Set<Int> {
        val from = (start - 100).coerceAtLeast(0)
        val to = (end + 100).coerceAtMost(answer.length)
        return extractCitations(answer.substring(from, to))
    }

    private fun hasVisualFindingWithoutNearbyCitation(answer: String, validEvidence: Map<Int, EvidenceItem>): Boolean {
        val visualRegex = Regex(
            "\\b(image|mammogram|mammography|scan|ct|mri|x[- ]?ray|ultrasound|slide|micrograph|histology|pathology)\\b.{0,45}\\b(shows?|demonstrates?|reveals?|consistent with|suggests?|evidence of)\\b",
            RegexOption.IGNORE_CASE
        )
        val stopWords = setOf(
            "the", "a", "an", "is", "are", "was", "were", "shows", "show", "demonstrates",
            "demonstrate", "reveals", "reveal", "suggests", "suggest", "evidence", "of", "with",
            "and", "or", "on", "in", "to", "from", "image", "scan", "finding", "findings"
        )
        for (m in visualRegex.findAll(answer)) {
            val from = (m.range.first - 100).coerceAtLeast(0)
            val to = (m.range.last + 101).coerceAtMost(answer.length)
            val window = answer.substring(from, to)
            val nearby = extractCitations(window)
            val cited = nearby.filter { it in validEvidence }.toSet()
            if (cited.isEmpty()) return true

            // A citation proves only that an evidence item was retrieved; it does not by itself
            // prove an image interpretation. Require the cited evidence text to contain at least
            // one meaningful finding term from the visual claim. This prevents statements such as
            // "the image shows pulmonary edema [1]" from passing when evidence [1] merely says
            // "the image is provided". It remains deterministic and does not pretend that text
            // evidence can perform image understanding.
            val findingStart = m.range.last + 1
            val findingEnd = (findingStart + 90).coerceAtMost(answer.length)
            val findingTerms = Regex("[A-Za-z][A-Za-z-]{2,}")
                .findAll(answer.substring(findingStart, findingEnd).substringBefore("["))
                .map { it.value.lowercase(Locale.US) }
                .filter { it !in stopWords }
                .distinct()
                .toList()
            val grounded = cited.any { index ->
                val evidenceText = validEvidence[index]?.text.orEmpty()
                findingTerms.any { term -> evidenceText.contains(term, ignoreCase = true) }
            }
            if (!grounded) return true
        }
        return false
    }


    private fun hasCriticalPhraseWithoutNearbyCitation(answer: String, validEvidence: Map<Int, EvidenceItem>): Boolean {
        val phraseRegex = Regex(
            "\\b(drug of choice|first[- ]line|contraindicated|diagnostic criteria|diagnostic criterion|cut[- ]off|threshold|screening (?:age|interval|recommendation)|recommended (?:at|from)|stage [ivx]+|mortality|sensitivity|specificity)\\b",
            RegexOption.IGNORE_CASE
        )
        for (m in phraseRegex.findAll(answer)) {
            val from = (m.range.first - 100).coerceAtLeast(0)
            val to = (m.range.last + 101).coerceAtMost(answer.length)
            val nearby = extractCitations(answer.substring(from, to))
            // A nearby citation index alone is not enough: the cited evidence text must actually
            // ground the matched critical phrase, or the recommendation is treated as unsupported.
            val grounded = nearby.any { idx -> validEvidence[idx]?.text?.contains(m.value, ignoreCase = true) == true }
            if (!grounded) return true
        }
        return false
    }

    /**
     * High-precision quantity matching only. A value must have the same/explicitly convertible
     * unit AND a nearby critical-context token must also occur near that value in the evidence.
     */
    private fun quantitySupportedNear(token: NumberToken, answerContext: String, evidenceText: String): Boolean {
        val target = normalizeQuantity(token.value, token.unit) ?: return false
        val contextTerms = criticalContextTerms(answerContext)
        val tokenRegex = Regex("(?<![A-Za-z\\[])(?:\\d+(?:\\.\\d+)?|\\.\\d+)(?:\\s*(?:%|mg/kg|g/kg|mcg/kg|µg/kg|mg|mcg|µg|μg|g|kg|ml|mL|l|L|d|day|days|wk|week|weeks|mo|month|months|yr|year|years))?(?![A-Za-z])")
        return tokenRegex.findAll(evidenceText).any { match ->
            val raw = match.value.replace(Regex("\\s+"), "").trim()
            val number = Regex("(?:\\d+(?:\\.\\d+)?|\\.\\d+)").find(raw)?.value?.toDoubleOrNull() ?: return@any false
            val unit = raw.dropWhile { c -> c.isDigit() || c == '.' }.lowercase(Locale.US).ifBlank { null }
            val candidate = normalizeQuantity(number, unit) ?: return@any false
            val direct = compatible(candidate, target)
            val ageUnitlessEquivalent = target.unit == "years" && candidate.unit == null &&
                contextTerms.any { it == "age" || it == "aged" || it == "year" } && nearlyEqual(candidate.value, target.value)
            val percentFractionEquivalent = target.unit == "%" && candidate.unit == null &&
                ((nearlyEqual(candidate.value, 0.5) && nearlyEqual(target.value, 50.0)) ||
                    (nearlyEqual(candidate.value, 0.25) && nearlyEqual(target.value, 25.0)) ||
                    (nearlyEqual(candidate.value, 0.75) && nearlyEqual(target.value, 75.0)))
            if (!direct && !ageUnitlessEquivalent && !percentFractionEquivalent) return@any false
            if (contextTerms.isEmpty()) return@any false
            val eFrom = (match.range.first - 110).coerceAtLeast(0)
            val eTo = (match.range.last + 111).coerceAtMost(evidenceText.length)
            val eContext = evidenceText.substring(eFrom, eTo).lowercase(Locale.US)
            contextTerms.any { term -> eContext.contains(term) }
        }
    }

    private fun criticalContextTerms(context: String): List<String> {
        val keywords = listOf(
            "age", "aged", "year", "dose", "dosage", "cut-off", "cutoff", "threshold", "criterion",
            "criteria", "score", "stage", "staging", "duration", "day", "week", "month", "interval",
            "screening", "first-line", "first line", "drug of choice", "contraindicated", "mortality",
            "sensitivity", "specificity", "pregnancy", "pregnant", "trimester", "hemoglobin", "wbc",
            "platelet", "creatinine", "bilirubin", "inr", "glucose", "pressure"
        )
        val lower = context.lowercase(Locale.US)
        return keywords.filter { lower.contains(it) }.distinct().take(4)
    }

    /** Explicitly small conversion table; deliberately no open-ended clinical equivalence. */
    private fun normalizeQuantity(value: Double, unit: String?): NormalizedQuantity? {
        val u = unit?.lowercase(Locale.US)?.replace("μ", "µ")
        return when (u) {
            null -> NormalizedQuantity(value, null)
            "%" -> NormalizedQuantity(value, "%")
            "mg" -> NormalizedQuantity(value, "mg")
            "g" -> NormalizedQuantity(value * 1000.0, "mg")
            "mcg", "µg" -> NormalizedQuantity(value / 1000.0, "mg")
            "mg/kg" -> NormalizedQuantity(value, "mg/kg")
            "g/kg" -> NormalizedQuantity(value * 1000.0, "mg/kg")
            "mcg/kg", "µg/kg" -> NormalizedQuantity(value / 1000.0, "mg/kg")
            "kg" -> NormalizedQuantity(value, "kg")
            "ml" -> NormalizedQuantity(value, "ml")
            "l" -> NormalizedQuantity(value * 1000.0, "ml")
            "d", "day", "days" -> NormalizedQuantity(value, "days")
            "wk", "week", "weeks" -> NormalizedQuantity(value * 7.0, "days")
            "mo", "month", "months" -> NormalizedQuantity(value * 30.0, "days")
            "yr", "year", "years" -> NormalizedQuantity(value, "years")
            else -> null
        }
    }

    private fun compatible(a: NormalizedQuantity, b: NormalizedQuantity): Boolean {
        if (a.unit == null || b.unit == null) return a.unit == b.unit && nearlyEqual(a.value, b.value)
        return a.unit == b.unit && nearlyEqual(a.value, b.value)
    }

    private fun nearlyEqual(a: Double, b: Double): Boolean =
        kotlin.math.abs(a - b) <= 0.0005 * kotlin.math.max(1.0, kotlin.math.max(kotlin.math.abs(a), kotlin.math.abs(b)))

    /** Legacy helper retained for deterministic callers; never used to rescue rejected neural drafts. */
    fun repair(query: String, candidate: String, plan: BenCognitiveArchitecture.Plan): String = buildString {
        append(candidate.take(12000).trim())
        if (plan.concepts.isNotEmpty()) {
            append("\n\nBen checked this against local concepts: ")
            append(plan.concepts.take(4).joinToString(", "))
            append(".")
        }
        append("\n\nExam safety: verify the original QBank explanation when the question depends on a specific guideline, dose, cutoff, or image.")
    }
}


