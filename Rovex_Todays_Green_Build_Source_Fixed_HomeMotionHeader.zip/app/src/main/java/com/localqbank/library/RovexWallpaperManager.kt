package com.localqbank.library
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

/** Theme-scoped wallpaper store. Preserve original bytes; decode only bounded previews. */
object RovexWallpaperManager {
    private const val PREFS = "rovex_wallpaper"
    private const val MAX_IMPORT_BYTES = 100L * 1024L * 1024L
    private const val MAX_SOURCE_EDGE = 16384
    private const val PREVIEW_EDGE = 2048
    private const val ORIGINAL_SUFFIX = ".original"
    private const val PREVIEW_SUFFIX = ".preview.jpg"
    @Volatile private var cachedTheme: String? = null
    @Volatile private var cachedBitmap: Bitmap? = null
    private val loadingThemes = ConcurrentHashMap.newKeySet<String>()
    private fun app(c: Context) = c.applicationContext
    private fun slug(t: String) = t.lowercase().replace(Regex("[^a-z0-9_-]"), "_")
    private fun key(t: String) = "enabled_" + slug(t)
    private fun original(c: Context, t: String) = File(app(c).filesDir, "rovex_wallpaper_" + slug(t) + ORIGINAL_SUFFIX)
    private fun preview(c: Context, t: String) = File(app(c).filesDir, "rovex_wallpaper_" + slug(t) + PREVIEW_SUFFIX)

    fun isEnabled(context: Context, theme: String = ThemeManager.get(context)): Boolean {
        val c = app(context)
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(key(theme), false) &&
            original(c, theme).isFile && preview(c, theme).isFile
    }

    /** Cache-only on caller thread; no file IO or decode from backgroundDrawable. */
    fun bitmap(context: Context, theme: String = ThemeManager.get(context)): Bitmap? {
        if (!isEnabled(context, theme)) return null
        if (cachedTheme == theme) return cachedBitmap
        preloadTheme(context, theme)
        return null
    }

    fun preload(context: Context) = preloadTheme(context, ThemeManager.get(context))
    private fun preloadTheme(context: Context, theme: String) {
        val c = app(context)
        if (!isEnabled(c, theme) || (cachedTheme == theme && cachedBitmap != null) || loadingThemes.contains(theme) || !loadingThemes.add("decode:active")) return
        loadingThemes.add(theme)
        PerformanceManager.submit {
            val decoded = runCatching {
                val f = preview(c, theme)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.absolutePath, bounds)
                require(bounds.outWidth > 0 && bounds.outHeight > 0)
                var sample = 1
                while (bounds.outWidth / sample > PREVIEW_EDGE || bounds.outHeight / sample > PREVIEW_EDGE) sample *= 2
                BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                })
            }.getOrNull()
            synchronized(this) {
                if (decoded != null && ThemeManager.get(c) == theme) {
                    cachedBitmap = decoded
                    cachedTheme = theme
                }
            }
            loadingThemes.remove(theme)
            loadingThemes.remove("decode:active")
            if (ThemeManager.get(c) != theme) preloadTheme(c, ThemeManager.get(c))
            if (decoded != null && AppManagers.isReady()) android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (ThemeManager.get(c) == theme) AppState.changed("wallpaper_loaded:" + theme)
            }
        }
    }

    /** Copy original bytes unchanged; generate a <=2048px JPEG preview off the UI thread. */
    fun setFromUri(context: Context, uri: Uri, theme: String = ThemeManager.get(context), onComplete: (Boolean) -> Unit) {
        val c = app(context)
        val safe = slug(theme)
        if (!loadingThemes.add("import:active")) { onComplete(false); return }
        loadingThemes.add("import:" + safe)
        PerformanceManager.submit {
            val ok = runCatching {
                val sourceTmp = File(c.filesDir, "rovex_wallpaper_" + safe + ORIGINAL_SUFFIX + ".tmp")
                var bytes = 0L
                c.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(sourceTmp).use { out ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            bytes += n
                            require(bytes <= MAX_IMPORT_BYTES) { "Wallpaper exceeds 100 MB limit" }
                            out.write(buffer, 0, n)
                        }
                        out.fd.sync()
                    }
                } ?: error("Unable to read selected image")
                require(bytes > 0)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(sourceTmp.absolutePath, bounds)
                require(bounds.outWidth > 0 && bounds.outHeight > 0 && bounds.outMimeType?.startsWith("image/") == true)
                require(bounds.outWidth <= MAX_SOURCE_EDGE && bounds.outHeight <= MAX_SOURCE_EDGE)
                var sample = 1
                while (bounds.outWidth / sample > PREVIEW_EDGE || bounds.outHeight / sample > PREVIEW_EDGE) sample *= 2
                val decoded = BitmapFactory.decodeFile(sourceTmp.absolutePath, BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }) ?: error("Unsupported image")
                val previewTmp = File(c.filesDir, "rovex_wallpaper_" + safe + PREVIEW_SUFFIX + ".tmp")
                try {
                    FileOutputStream(previewTmp).use { out ->
                        check(decoded.compress(Bitmap.CompressFormat.JPEG, 90, out))
                        out.fd.sync()
                    }
                } finally { decoded.recycle() }
                val orig = original(c, theme); val prev = preview(c, theme)
                val ob = File(c.filesDir, "rovex_wallpaper_" + safe + ORIGINAL_SUFFIX + ".bak")
                val pb = File(c.filesDir, "rovex_wallpaper_" + safe + PREVIEW_SUFFIX + ".bak")
                ob.delete(); pb.delete()
                val hadO = orig.exists(); val hadP = prev.exists()
                if (hadO) check(orig.renameTo(ob))
                if (hadP) check(prev.renameTo(pb)) { if (hadO) ob.renameTo(orig); "Cannot stage old preview" }
                try {
                    check(previewTmp.renameTo(prev))
                    check(sourceTmp.renameTo(orig))
                    check(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key(theme), true).commit())
                    ob.delete(); pb.delete()
                } catch (failure: Throwable) {
                    prev.delete(); orig.delete()
                    if (hadO) ob.renameTo(orig)
                    if (hadP) pb.renameTo(prev)
                    throw failure
                }
                synchronized(this) { if (cachedTheme == theme) { cachedBitmap = null; cachedTheme = null } }
                true
            }.getOrDefault(false)
            loadingThemes.remove("import:" + safe)
            loadingThemes.remove("import:active")
            File(c.filesDir, "rovex_wallpaper_" + safe + ORIGINAL_SUFFIX + ".tmp").delete()
            File(c.filesDir, "rovex_wallpaper_" + safe + PREVIEW_SUFFIX + ".tmp").delete()
            if (ok) preloadTheme(c, theme)
            android.os.Handler(android.os.Looper.getMainLooper()).post { onComplete(ok) }
        }
    }

    fun clear(context: Context, theme: String = ThemeManager.get(context)) {
        val c = app(context)
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key(theme), false).apply()
        original(c, theme).delete(); preview(c, theme).delete()
        synchronized(this) { if (cachedTheme == theme) { cachedBitmap = null; cachedTheme = null } }
    }
    fun originalBytes(context: Context, theme: String = ThemeManager.get(context)): Long =
        original(context, theme).takeIf { it.isFile }?.length() ?: 0L
}
