package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BenQuestionAiModePromptTest {
    @Test
    fun fourModesHaveDistinctExamPreparationJobs() {
        val modes = listOf(
            BenQuestionAiMode.PYQ_CONTEXT,
            BenQuestionAiMode.PYT_CONTEXT,
            BenQuestionAiMode.FUTURE_RELATED,
            BenQuestionAiMode.OTHER_OPTIONS
        )
        assertEquals(4, modes.map { it.label }.distinct().size)
        assertEquals(4, modes.map { it.prompt }.distinct().size)
        assertTrue(BenQuestionAiMode.PYQ_CONTEXT.prompt.contains("explicitly establishes previous-year-question provenance"))
        assertTrue(BenQuestionAiMode.PYT_CONTEXT.prompt.contains("whole-topic revision map"))
        assertTrue(BenQuestionAiMode.FUTURE_RELATED.prompt.contains("RELEVANCE GATE (mandatory)"))
        assertTrue(BenQuestionAiMode.FUTURE_RELATED.prompt.contains("exactly 4 distinct original practice questions"))
        assertTrue(BenQuestionAiMode.FUTURE_RELATED.prompt.contains("WHERE EXAMINERS CAN FRAME IT"))
        assertTrue(BenQuestionAiMode.FUTURE_RELATED.prompt.contains("TRAPS & CONFUSING DIFFERENTIATORS"))
        assertTrue(BenQuestionAiMode.FUTURE_RELATED.prompt.contains("Link to current concept"))
        assertTrue(BenQuestionAiMode.FUTURE_RELATED.prompt.contains("ORIGINAL PRACTICE, NOT A PREDICTION"))
        assertTrue(BenQuestionAiMode.OTHER_OPTIONS.prompt.contains("option-by-option discriminator analysis"))
        assertTrue(modes.all { it.prompt.contains("SOURCE POLICY (mandatory)") })
        assertTrue(modes.all { it.prompt.contains("official institutional") })
        assertTrue(modes.all { it.prompt.contains("unofficial websites") })
        assertTrue(modes.all { it.prompt.length >= 400 })
    }
}
