package com.localqbank.library

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class QBankStreamingImportSessionSourceRegressionTest {
    @Test
    fun extractedStreamingSessionRetainsRequiredHelpers() {
        val sourceRoot = File(System.getProperty("user.dir"))
        val candidates = sequenceOf(
            File(sourceRoot, "src/main/java/com/localqbank/library/QBankStreamingImportSession.kt"),
            File(sourceRoot, "app/src/main/java/com/localqbank/library/QBankStreamingImportSession.kt")
        )
        val source = candidates.firstOrNull { it.isFile }?.readText() ?: ""
        assertTrue(
            "QBankStreamingImportSession.kt must retain its extracted bindNullable helper",
            source != null && source.contains(
                "private fun bindNullable(\n        statement: android.database.sqlite.SQLiteStatement"
            )
        )
        assertTrue(
            "QBankStreamingImportSession.kt must retain its extracted makeId helper",
            source != null && source.contains(
                "private fun makeId(file: String, original: String, index: Int): String"
            )
        )
    }
}
