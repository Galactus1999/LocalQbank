package com.localqbank.library

import org.junit.Assert.*
import org.junit.Test

class QuizBookmarkOverlayTest {
    @Test fun clearUsesPresenceSafeSentinel() {
        val o=QuizBookmarkOverlay()
        o.put("q","important"); assertEquals("important",o.value("q"))
        o.put("q",null); assertTrue(o.contains("q")); assertNull(o.value("q"))
        o.removeIfEquals("q",null); assertFalse(o.contains("q"))
    }
}
