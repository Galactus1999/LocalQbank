package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexThemeProfileTest {
    private val keys = listOf(
        ThemeManager.LIGHT, ThemeManager.PASTEL, ThemeManager.MINT, ThemeManager.SUNSET,
        ThemeManager.LAVENDER, ThemeManager.AMOLED, ThemeManager.PANDORA, ThemeManager.SPACE
    )

    @Test
    fun allEightThemesHaveDistinctVisualProfiles() {
        val profiles = keys.map(RovexThemeProfile::forKey)
        assertEquals(8, profiles.size)
        assertEquals(8, profiles.map { it.name }.distinct().size)
        assertEquals(8, profiles.map { it.accent }.distinct().size)
        assertTrue(profiles.all { it.cornerDp in 20..28 })
    }

    @Test
    fun motionProfilesRemainBounded() {
        keys.map(RovexThemeProfile::forKey).forEach { profile ->
            assertTrue(profile.flowSpeed > 0f && profile.flowSpeed <= 1f)
            assertTrue(profile.motionAlpha >= 0f && profile.motionAlpha <= 1f)
        }
    }
}
