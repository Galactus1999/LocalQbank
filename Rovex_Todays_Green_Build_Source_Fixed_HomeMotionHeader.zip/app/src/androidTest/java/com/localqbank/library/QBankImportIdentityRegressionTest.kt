package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.WorkManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Proves the human filename is only presentation; the internal import identity isolates QBanks. */
@RunWith(AndroidJUnit4::class)
class QBankImportIdentityRegressionTest {
    private lateinit var db: QBankDb

    
    @After
    fun tearDownRecoveryWork() {
        cancelRecoveryWork()
    }

    private fun cancelRecoveryWork() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        runCatching { WorkManager.getInstance(context).cancelUniqueWork(QBANK_RECOVERY_WORK).result.get() }
        context.getSharedPreferences("qbank_recovery_state", Context.MODE_PRIVATE).edit().clear().commit()
    }

    @Before fun setUp() {
        cancelRecoveryWork()
        val context = ApplicationProvider.getApplicationContext<Context>()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
    }

    private fun oneQuestion(title: String) = ImportedTest(
        originalId = title, title = title, path = null, totalMarks = 1.0, duration = 0,
        timePerQuestion = 0.0, questions = listOf(
            ImportedQuestion(
                sourceId = "q1", text = "question-$title", rawText = null, correctAnswer = "A",
                explanation = null, bot = null, video = null, audio = null,
                options = listOf(ImportedOption("A", "answer", true)),
                questionImages = emptyList(), explanationImages = emptyList()
            )
        )
    )

    @Test fun sameDisplayFilenameDoesNotDeleteOtherImportedQBank() {
        db.importBundle("rvx-uri-A", "index.html", "HTML", listOf(oneQuestion("A")))
        db.importBundle("rvx-uri-B", "index.html", "HTML", listOf(oneQuestion("B")))

        val sources = db.sources()
        assertEquals(2, sources.size)
        assertTrue(sources.any { it.fileName == "index.html" })
        assertEquals(1, db.search("question-A").size)
        assertEquals(1, db.search("question-B").size)
    }

    @Test fun reimportSameIdentityReplacesOnlyThatQBank() {
        db.importBundle("rvx-uri-A", "index.html", "HTML", listOf(oneQuestion("A")))
        db.importBundle("rvx-uri-B", "index.html", "HTML", listOf(oneQuestion("B")))
        db.importBundle("rvx-uri-A", "index.html", "HTML", listOf(oneQuestion("A2")))

        assertEquals(2, db.sources().size)
        assertEquals(0, db.search("question-A").size)
        assertEquals(1, db.search("question-A2").size)
        assertEquals(1, db.search("question-B").size)
    }
    @Test fun legacyHiddenQBankIsRecoveredWithoutDeletingItsData() {
        db.importBundle("rvx-uri-legacy", "old.html", "HTML", listOf(oneQuestion("Legacy")))
        val raw = ApplicationProvider.getApplicationContext<Context>().openOrCreateDatabase("qbank.db", 0, null)
        val sourceId = db.sources().single { it.fileName == "old.html" }.id
        raw.execSQL("UPDATE source SET deleting=1,delete_requested=0 WHERE id=?", arrayOf(sourceId))
        raw.close()

        assertEquals(1, db.restoreLegacyTombstonedSources())
        val recovered = db.sources()
        assertEquals(1, recovered.size)
        assertEquals(1, db.search("question-Legacy").size)
    }

    @Test fun reimportAfterExplicitTombstoneFinishesOldPhysicalDataBeforeReplacement() {
        db.importBundle("rvx-uri-recover", "index.html", "HTML", listOf(oneQuestion("Old")))
        val raw = ApplicationProvider.getApplicationContext<Context>().openOrCreateDatabase("qbank.db", 0, null)
        // safeImportKey normalizes short/non-canonical keys, so resolve the sole imported source
        // by identity rather than assuming the presentation key is stored verbatim.
        val sourceId = db.sources().single().id
        raw.execSQL("UPDATE source SET deleting=1,delete_requested=1 WHERE id=?", arrayOf(sourceId))
        raw.close()

        var lastDeleted = -1
        val session = db.beginStreamingImport(
            "rvx-uri-recover", "index.html", "HTML",
            onReplacementProgress = { deleted, total ->
                assertTrue(total >= 1)
                lastDeleted = deleted
            }
        )
        session.addQuestion("Replacement", oneQuestion("Replacement").questions.single())
        session.finish(true)

        assertTrue(lastDeleted >= 1)
        assertEquals(1, db.sources().size)
        assertEquals(1, db.search("question-Replacement").size)
        assertEquals(0, db.search("question-Old").size)
    }


    companion object {
        private const val QBANK_RECOVERY_WORK = "rovex_qbank_delete_recovery"
    }
}
