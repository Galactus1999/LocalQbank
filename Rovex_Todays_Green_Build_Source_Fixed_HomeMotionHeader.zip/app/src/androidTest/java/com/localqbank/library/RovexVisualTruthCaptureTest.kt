package com.localqbank.library

import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Test
import org.junit.runner.RunWith
import java.io.BufferedReader
import java.io.InputStreamReader

/** Captures real rendered activity surfaces for CI visual truth. Never ships in the release APK. */
@RunWith(AndroidJUnit4::class)
class RovexVisualTruthCaptureTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext

    private fun shell(command: String) {
        val fd = InstrumentationRegistry.getInstrumentation().uiAutomation.executeShellCommand(command)
        BufferedReader(InputStreamReader(android.os.ParcelFileDescriptor.AutoCloseInputStream(fd))).use { it.readText() }
    }

    private fun capture(name: String) {
        shell("mkdir -p /sdcard/RovexVisualTruth")
        shell("screencap -p /sdcard/RovexVisualTruth/$name.png")
        // The host-side collector validates the file after instrumentation.
        // Avoid making the test depend on shell-output timing for the screenshot file.
    }

    private fun settle() { Thread.sleep(1200) }

    @Test
    fun captureCoreRenderedScreens() {
        // AndroidJUnitRunner reliably exposes its class filter to the test Bundle.
        // The extra custom argument was not consistently surfaced on the CI emulator.
        org.junit.Assume.assumeTrue(
            "Run only when this test class is explicitly selected",
            InstrumentationRegistry.getArguments().getString("class")
                ?.contains("RovexVisualTruthCaptureTest") == true
        )
        shell("rm -rf /sdcard/RovexVisualTruth")
        shell("mkdir -p /sdcard/RovexVisualTruth")
        ActivityScenario.launch<MainActivity>(Intent(context, MainActivity::class.java)).use {
            check(it.state.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)); settle(); capture("01_home")
        }
        ActivityScenario.launch<RovexSectionDashboardActivity>(
            Intent(context, RovexSectionDashboardActivity::class.java).putExtra("section","qbank")
        ).use {
            check(it.state.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)); settle(); capture("02_qbank")
        }
        ActivityScenario.launch<RovexSectionDashboardActivity>(
            Intent(context, RovexSectionDashboardActivity::class.java).putExtra("section", "flashcards")
        ).use {
            check(it.state.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)); settle(); capture("03_flashcards")
        }
        ActivityScenario.launch<RenActivity>(Intent(context, RenActivity::class.java)).use {
            check(it.state.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)); settle(); capture("04_ren")
        }
        ActivityScenario.launch<SettingsActivity>(Intent(context, SettingsActivity::class.java)).use {
            check(it.state.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)); settle(); capture("05_settings")
        }
        ActivityScenario.launch<VisualLabActivity>(Intent(context, VisualLabActivity::class.java)).use {
            check(it.state.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)); settle(); capture("06_visual_lab")
        }
    }
}
