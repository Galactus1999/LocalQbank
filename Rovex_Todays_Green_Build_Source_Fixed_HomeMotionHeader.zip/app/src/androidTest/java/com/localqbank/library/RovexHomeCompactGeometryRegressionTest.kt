package com.localqbank.library

import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RovexHomeCompactGeometryRegressionTest {
    @Test
    fun primaryHomeCardsStayCompactAndMotivationUsesStableTypography() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val oldTheme = ThemeManager.get(context)
        try {
            ThemeManager.set(context, ThemeManager.LIGHT)
            ActivityScenario.launch<MainActivity>(Intent(context, MainActivity::class.java)).use { scenario ->
                instrumentation.waitForIdleSync()
                scenario.onActivity { activity ->
                    val root = activity.findViewById<ViewGroup>(R.id.dashboardRoot)
                        ?: error("Home dashboard root missing")
                    val density = activity.resources.displayMetrics.density
                    fun assertHeight(tag: String, maximumDp: Float) {
                        val view = root.findViewWithTag<View>(tag)
                            ?: error("Missing Home geometry target: " + tag)
                        val heightDp = view.measuredHeight / density
                        check(heightDp > 0f) { tag + " was not measured" }
                        check(heightDp <= maximumDp) {
                            tag + " is oversized: " + String.format("%.1f", heightDp) +
                                "dp > " + maximumDp + "dp"
                        }
                    }
                    assertHeight("rovex_home_clinical_hero", 96f)
                    assertHeight("rovex_home_search", 50f)
                    assertHeight("rovex_home_online", 70f)
                    assertHeight("rovex_home_daily_motivation", 88f)
                    assertHeight("rovex_home_today_progress", 225f)
                    assertHeight("modern_feature_qbank", 132f)
                    assertHeight("modern_feature_flashcards", 132f)
                    val quote = root.findViewWithTag<TextView>("rovex_home_daily_quote")
                        ?: error("Daily motivation text missing")
                    check(quote !is RovexColorFlowTextView) {
                        "Daily motivation must use stable theme text, not animated flowing text gradients"
                    }
                }
            }
        } finally {
            ThemeManager.set(context, oldTheme)
        }
    }
}
