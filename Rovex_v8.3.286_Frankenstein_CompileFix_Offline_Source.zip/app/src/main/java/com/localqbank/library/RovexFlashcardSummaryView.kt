package com.localqbank.library

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.min
import kotlin.math.roundToInt

/** Native Android equivalent of the supplied futuristic Flashcards analytical widget. */
class RovexFlashcardSummaryView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var cards=0; private var due=0; private var reviews=0
    fun setStats(total:Int,dueNow:Int,reviewCount:Int){cards=total.coerceAtLeast(0);due=dueNow.coerceAtLeast(0);reviews=reviewCount.coerceAtLeast(0);invalidate()}
    override fun onDraw(c:Canvas){
        val d=resources.displayMetrics.density; val w=width.toFloat(); val h=height.toFloat(); if(w<=0||h<=0)return
        val dark=ThemeManager.isDark(context); val panel=if(ThemeManager.get(context)==ThemeManager.AMOLED_DARK) Color.rgb(24,27,34) else ThemeManager.panel(context)
        p.style=Paint.Style.FILL;p.color=panel;c.drawRoundRect(0f,0f,w,h,20*d,20*d,p)
        // Low-cost topographic wave/grid. It is deliberately Canvas-based to avoid extra Views.
        p.style=Paint.Style.STROKE;p.strokeWidth=1*d;p.color=Color.argb(45,79,231,226)
        for(i in 0..6){val path=Path();val y=h*.38f+i*8*d;path.moveTo(0f,y);var x=0f;while(x<=w*.72f){path.lineTo(x,y+((kotlin.math.sin(x/(18*d)+i)*5*d)));x+=16*d};c.drawPath(path,p)}
        p.style=Paint.Style.FILL
        val accent=if(ThemeManager.get(context)==ThemeManager.AMOLED_DARK) Color.rgb(127,231,226) else ThemeManager.accent(context)
        p.color=ThemeManager.text(context);p.textSize=17*d;p.isFakeBoldText=true;c.drawText("FLASHCARDS",16*d,24*d,p)
        p.isFakeBoldText=false;p.color=ThemeManager.muted(context);p.textSize=8.5f*d;c.drawText("Spaced repetition • imported decks",16*d,37*d,p)
        val r=min(w,h)*.22f;val cx=w-42*d;val cy=31*d;p.style=Paint.Style.STROKE;p.strokeWidth=5*d;p.strokeCap=Paint.Cap.ROUND;p.color=Color.argb(35,255,255,255);c.drawCircle(cx,cy,r,p)
        val pct=if(cards>0)((cards-due).coerceIn(0,cards).toFloat()/cards) else 0f;p.color=Color.rgb(255,193,7);c.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,pct*360f,false,p)
        p.style=Paint.Style.FILL;p.textAlign=Paint.Align.CENTER;p.color=ThemeManager.text(context);p.textSize=8.5f*d;p.isFakeBoldText=true;c.drawText("${(pct*100).roundToInt()}%",cx,cy+3*d,p);p.isFakeBoldText=false;p.textAlign=Paint.Align.LEFT
        p.color=ThemeManager.text(context);p.textSize=13*d;p.isFakeBoldText=true;c.drawText(cards.toString(),16*d,h*.60f,p);p.isFakeBoldText=false;p.color=ThemeManager.muted(context);p.textSize=8*d;c.drawText("cards  •  $reviews reviews",16*d,h*.60f+12*d,p)
        p.color=if(due>0)Color.rgb(255,183,77) else Color.rgb(54,183,124);p.isFakeBoldText=true;p.textSize=8*d;c.drawText(if(due>0)"$due DUE NOW" else "UP TO DATE",16*d,h-12*d,p);p.isFakeBoldText=false
    }
}
