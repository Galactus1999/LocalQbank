package com.localqbank.library

/**
 * Deterministic bounds and hygiene for text returned by optional Ben backends.
 *
 * AI responses are presentation data, never executable HTML/CSS. The renderer receives
 * Markdown only; CSS, scripts, event handlers and layout-bearing HTML are removed here so
 * a malformed response cannot alter the Android text renderer or theme.
 *
 * IMPORTANT: sanitiser construction is deliberately lazy and failure-tolerant. Android's
 * ICU regex implementation has rejected patterns that compile on desktop/JDKs before.
 * A regex failure must therefore degrade to plain bounded text, never to
 * ExceptionInInitializerError / process death.
 */
object BenResponsePolicy {
    const val MAX_RESPONSE_CHARS = 48_000
    const val POLICY_REVISION = "v3-markdown-visual-safe"

    private fun safeRegex(pattern: String, flags: Set<RegexOption> = emptySet()): Regex? =
        runCatching { Regex(pattern, flags) }
            .onFailure { t ->
                android.util.Log.e("Rovex.Frankenstein", "BenResponsePolicy regex disabled", t)
            }
            .getOrNull()

    // Never compile presentation-sanitisation regexes during object/class initialisation.
    // This prevents an Android ICU PatternSyntaxException from becoming
    // ExceptionInInitializerError and killing RenActivity on the main thread.
    private val styleBlock by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("<style\\b[^>]*>.*?</style\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val scriptBlock by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("<script\\b[^>]*>.*?</script\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val eventAttribute by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("\\bon[a-z][a-z0-9_-]*\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val styleAttribute by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("\\bstyle\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }
    private val cssRule by lazy(LazyThreadSafetyMode.PUBLICATION) {
        // No lookbehind: Android ICU has rejected the historical lookbehind form.
        safeRegex("(^|})\\s*[^{}]{1,240}\\{[^{}]{1,5000}\\}", setOf(RegexOption.DOT_MATCHES_ALL))
    }
    private val htmlTag by lazy(LazyThreadSafetyMode.PUBLICATION) {
        safeRegex("</?(?:!doctype|html|head|body|main|section|article|div|span|table|thead|tbody|tr|th|td|p|br|hr|ul|ol|li|h[1-6]|strong|b|em|i|u|code|pre|blockquote|a|img|mark|small|sup|sub)(?:\\s+[^>]*)?>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    }

    /**
     * Never throws for malformed/untrusted AI text. If any sanitiser stage fails, the
     * response is still returned as bounded plain text after control-character cleanup.
     */
    fun normalize(raw: String?): String? {
        if (raw.isNullOrEmpty()) return null
        return try {
            var x = raw.replace("\\r\\n", "\\n").replace("\\r", "\\n")
                .replace("\\u0000", " ")
            styleBlock?.let { x = it.replace(x, " ") }
            scriptBlock?.let { x = it.replace(x, " ") }
            eventAttribute?.let { x = it.replace(x, " ") }
            styleAttribute?.let { x = it.replace(x, " ") }
            repeat(4) { cssRule?.let { x = it.replace(x) { m -> m.groupValues[1] + " " } } }
            htmlTag?.let { x = it.replace(x, " ") }
            BoundedTextPolicy.normalize(x, MAX_RESPONSE_CHARS)
        } catch (t: Throwable) {
            // Last-resort deterministic fallback. This path is intentionally broader than
            // Exception so renderer/sanitiser defects cannot eject the user from Frankenstein.
            android.util.Log.e("Rovex.Frankenstein", "BenResponsePolicy fallback", t)
            runCatching { BoundedTextPolicy.normalize(raw, MAX_RESPONSE_CHARS) }.getOrNull()
                ?: raw.take(MAX_RESPONSE_CHARS)
        }
    }
}
