package com.localqbank.library

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Regression coverage for the current LargeHtmlScanner API.
 *
 * An earlier v8.3.568 experiment introduced tests for a transient progress/count API while the scanner
 * was being changed. That API was intentionally reverted after CI failures.
 * These tests exercise the actual production v8.3.570 scanner contract instead:
 * scan() emits questions through onQuestion and consumes the matched array '['.
 */
class LargeHtmlScannerRegressionTest {
    @Test
    fun testArrayEmitsFirstQuestion() {
        val file = File.createTempFile("rovex-large-html", ".html")
        try {
            file.writeText("""
                <html><script>const TESTS_LIST = [
                  {"title":"Pathology","questions":[{"id":"q1","text":"What is the diagnosis?","options":[{"label":"A","text":"Option A"}]}]}
                ];</script></html>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:What is the diagnosis?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun rootQuestionArrayUsesQuestionAliasWhenTextAliasesAreAbsent() {
        val file = File.createTempFile("rovex-large-html-root-alias", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q1","question":"Alias question?","choices":[{"label":"A","text":"Yes"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Alias question?"), seen)
        } finally {
            file.delete()
        }
    }

    @Test
    fun rootQuestionArrayEmitsFirstQuestion() {
        val file = File.createTempFile("rovex-large-html-root", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q1","question":"Which is correct?","options":[{"label":"A","text":"Yes"}]}];</script>
            """.trimIndent())
            var count = 0
            LargeHtmlScanner(file) { _, question ->
                count++
                assertTrue(question.text.contains("Which is correct?"))
            }.scan()
            assertEquals(1, count)
        } finally {
            file.delete()
        }
    }

    @Test
    fun explicitJsonNullDoesNotMaskQuestionAndOptionAliases() {
        val file = File.createTempFile("rovex-large-html-null-alias", ".html")
        try {
            file.writeText("""
                <script>const QUESTIONS_DATA = [{"id":"q-null","raw_text":null,"text":null,"question":"Fallback question","options":null,"choices":[{"label":"A","text":"Yes"},{"label":"B","text":"No"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<ImportedQuestion>()
            LargeHtmlScanner(file) { _, question -> seen += question }.scan()
            assertEquals(1, seen.size)
            assertEquals("Fallback question", seen.single().text)
            assertEquals(listOf("Yes", "No"), seen.single().options.map { it.text })
        } finally {
            file.delete()
        }
    }


    @Test
    fun assignmentInsideJavascriptCommentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-comment", ".html")
        try {
            file.writeText("""
                <script>
                  // const TESTS_LIST = [{"question":"wrong","options":[{"text":"bad"}]}];
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"id":"q2","text":"Actual question","options":[{"label":"A","text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Actual question"), seen)
        } finally {
            file.delete()
        }
    }


    @Test
    fun blockCommentAssignmentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-block-comment", ".html")
        try {
            file.writeText("""
                <script>
                  /* const TESTS_LIST = [{"title":"Wrong","questions":[{"text":"bad","options":[{"text":"bad"}]}]}; */
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun quotedFakeAssignmentDoesNotHijackScanner() {
        val file = File.createTempFile("rovex-large-html-string", ".html")
        try {
            file.writeText("""
                <script>
                  const fake = "const TESTS_LIST = [{\\"title\\":\\"Wrong\\"}]";
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

    @Test
    fun windowQualifiedQuestionAliasIsRecognized() {
        val file = File.createTempFile("rovex-large-html-window", ".html")
        try {
            file.writeText("""
                <script>window.QUESTIONS_DATA = [{"question":"Window alias","options":[{"text":"Yes"}]}];</script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Window alias"), seen)
        } finally { file.delete() }
    }

    @Test
    fun declarationAndWhitespaceVariantsAreRecognized() {
        val file = File.createTempFile("rovex-large-html-whitespace", ".html")
        try {
            file.writeText("""
                <script>
                  let
                    questionData
                    =
                    [
                      {"question":"Whitespace alias","options":[{"text":"Yes"}]}
                    ];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { _, question -> seen += question.text }.scan()
            assertEquals(listOf("Whitespace alias"), seen)
        } finally { file.delete() }
    }

    @Test
    fun identifierSubstringCannotHijackSupportedAlias() {
        val file = File.createTempFile("rovex-large-html-identifier", ".html")
        try {
            file.writeText("""
                <script>
                  const MY_TESTS_LIST = [{"title":"Wrong","questions":[{"text":"bad","options":[{"text":"bad"}]}]}];
                  const TESTS_LIST = [{"title":"Pathology","questions":[{"text":"Real","options":[{"text":"Yes"}]}]}];
                </script>
            """.trimIndent())
            val seen = mutableListOf<String>()
            LargeHtmlScanner(file) { section, question -> seen += "$section:${question.text}" }.scan()
            assertEquals(listOf("Pathology:Real"), seen)
        } finally { file.delete() }
    }

}
