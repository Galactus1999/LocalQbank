package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.sin

/** Theme-adaptive Rovex wordmark with one-time handwriting reveal and occasional red/gold energy arcs. */
class RovexHeaderWordmarkView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isSubpixelText = true }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val boltPath = Path()
    private val handler = Handler(Looper.getMainLooper())
    private var reveal = 0f
    private var bolt = 0f
    private var accent = ThemeManager.accent(context)
    private var writingAnimator: android.animation.ValueAnimator? = null
    private var boltAnimator: android.animation.ValueAnimator? = null
    private var attached = false

    private val boltRunnable = object : Runnable {
        override fun run() {
            if (!attached) return
            boltAnimator?.cancel()
            boltAnimator = android.animation.ValueAnimator.ofFloat(1f, 0f).apply {
                duration = 330L
                interpolator = DecelerateInterpolator()
                addUpdateListener { bolt = it.animatedValue as Float; invalidate() }
                start()
            }
            handler.postDelayed(this, 4200L)
        }
    }

    init { contentDescription = "Rovex"; setWillNotDraw(false) }

    fun refreshTheme() {
        accent = ThemeManager.accent(context)
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); attached = true
        writingAnimator?.cancel()
        writingAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1050L; interpolator = DecelerateInterpolator()
            addUpdateListener { reveal = it.animatedValue as Float; invalidate() }
            start()
        }
        handler.removeCallbacks(boltRunnable)
        handler.postDelayed(boltRunnable, 2500L)
    }

    override fun onDetachedFromWindow() {
        attached = false
        handler.removeCallbacks(boltRunnable)
        writingAnimator?.cancel(); writingAnimator = null
        boltAnimator?.cancel(); boltAnimator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val cx = width * .5f; val cy = height * .53f
        val size = (height * .72f).coerceAtLeast(22f)
        textPaint.textSize = size
        textPaint.typeface = Typeface.create("cursive", Typeface.NORMAL)
        val themeAccent = ThemeManager.accent(context)
        val themeText = ThemeManager.text(context)
        val colors = if (ThemeManager.isDark(context)) {
            intArrayOf(themeAccent, themeText, themeAccent)
        } else {
            intArrayOf(themeAccent, Color.rgb(75, 116, 145), themeAccent)
        }
        textPaint.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, colors, null, Shader.TileMode.CLAMP)
        textPaint.setShadowLayer(9f, 0f, 0f, Color.argb(95, Color.red(themeAccent), Color.green(themeAccent), Color.blue(themeAccent)))
        val baseline = cy - (textPaint.ascent() + textPaint.descent()) * .5f
        val text = "Rovex"
        val tw = textPaint.measureText(text)
        val left = cx - tw * .56f
        canvas.save()
        canvas.clipRect(left, 0f, left + tw * 1.12f * reveal, height.toFloat())
        canvas.drawText(text, cx, baseline, textPaint)
        canvas.restore()
        textPaint.clearShadowLayer(); textPaint.shader = null

        // Short red/gold electrical arcs. They are deliberately brief and sparse rather than continuous.
        if (bolt > .01f) {
            drawBolt(canvas, cx - tw * .34f, cy - size * .05f, -1, bolt)
            drawBolt(canvas, cx + tw * .34f, cy + size * .02f, 1, bolt * .9f)
        }
    }

    private fun drawBolt(canvas: Canvas, x: Float, y: Float, side: Int, intensity: Float) {
        boltPath.reset()
        boltPath.moveTo(x, y)
        boltPath.lineTo(x + side * 7f, y - 9f)
        boltPath.lineTo(x + side * 3f, y - 3f)
        boltPath.lineTo(x + side * 13f, y - 17f)
        boltPath.lineTo(x + side * 10f, y - 8f)
        boltPath.lineTo(x + side * 18f, y - 14f)
        boltPaint.strokeWidth = 1.2f + intensity * 2.1f
        boltPaint.color = Color.argb((intensity * 225).toInt(), 255, 74, 45)
        canvas.drawPath(boltPath, boltPaint)
        boltPaint.strokeWidth = .7f + intensity * 1.4f
        boltPaint.color = Color.argb((intensity * 245).toInt(), 255, 231, 96)
        canvas.drawPath(boltPath, boltPaint)
        glowPaint.color = Color.argb((intensity * 70).toInt(), 255, 160, 45)
        canvas.drawCircle(x, y - 7f, 9f * intensity, glowPaint)
    }
}
