package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Lightweight launcher-only Rovex intro. It is inspired by flowing particle/wave fields:
 * dark liquid ripples and coloured ink ribbons radiate from the wordmark. No bitmap/video,
 * worker thread, service or external asset is used. The animation is intentionally bounded.
 */
class RovexSplashView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object { const val DURATION_MS = 2100L }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("cursive", Typeface.NORMAL)
        isSubpixelText = true
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private var startTime = 0L
    private var running = false
    private var completionSent = false
    private var onFinished: (() -> Unit)? = null

    private val ink = intArrayOf(
        Color.rgb(40, 198, 255), Color.rgb(91, 112, 255), Color.rgb(174, 78, 255),
        Color.rgb(255, 75, 158), Color.rgb(255, 188, 64), Color.rgb(55, 236, 190)
    )

    fun setOnFinished(listener: () -> Unit) { onFinished = listener }

    fun start() {
        if (running || completionSent) return
        startTime = SystemClock.uptimeMillis()
        running = true
        invalidate()
    }

    fun skipToEnd() {
        if (completionSent) return
        running = false
        completionSent = true
        onFinished?.invoke()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); start() }

    override fun onDetachedFromWindow() {
        running = false
        onFinished = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w * .5f; val cy = h * .5f
        val maxR = hypot(w.toDouble(), h.toDouble()).toFloat() * .72f
        val elapsed = if (running) (SystemClock.uptimeMillis() - startTime).coerceAtLeast(0L) else DURATION_MS
        val t = (elapsed.toFloat() / DURATION_MS).coerceIn(0f, 1f)
        val ease = 1f - (1f - t) * (1f - t)

        bgPaint.shader = RadialGradient(cx, cy, maxR,
            intArrayOf(Color.rgb(8, 23, 42), Color.rgb(4, 11, 24), Color.BLACK),
            floatArrayOf(0f, .54f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, bgPaint); bgPaint.shader = null

        // Expanding dark water rings: the centre is the source and the waves travel outward.
        for (i in 0 until 9) {
            val phase = ((ease * 1.10f + i * .105f) % 1f)
            val r = maxR * (.025f + phase * 1.02f)
            wavePaint.strokeWidth = 1.5f + (1f - phase) * 5.5f
            wavePaint.color = Color.argb(((1f - phase) * 105f).toInt(), 1, 8, 18)
            canvas.drawCircle(cx, cy, r, wavePaint)
        }

        // Particle ribbons echo the reference video's flowing dotted wave field.
        for (ribbon in 0 until 5) {
            val colour = ink[(ribbon + 1) % ink.size]
            path.reset()
            val baseAngle = -0.55f + ribbon * .70f
            val points = 64
            for (p in 0 until points) {
                val u = p.toFloat() / (points - 1)
                val radius = maxR * (.035f + u * (0.98f * ease))
                val angle = baseAngle + .48f * sin(u * 7.0f + ease * 5.2f + ribbon)
                val x = (cx + cos(angle) * radius).toFloat()
                val y = (cy + sin(angle) * radius * (.70f + ribbon * .035f)).toFloat()
                if (p == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            wavePaint.color = Color.argb(125, Color.red(colour), Color.green(colour), Color.blue(colour))
            wavePaint.strokeWidth = 1.8f + 1.8f * (1f - ease)
            canvas.drawPath(path, wavePaint)

            // Dotted mesh along each ribbon.
            for (p in 0 until 52) {
                val u = p / 51f
                val radius = maxR * (.04f + u * (.98f * ease))
                val angle = baseAngle + .48f * sin(u * 7.0f + ease * 5.2f + ribbon)
                val x = (cx + cos(angle) * radius).toFloat()
                val y = (cy + sin(angle) * radius * (.70f + ribbon * .035f)).toFloat()
                val a = ((1f - u * .45f) * 185f).toInt().coerceIn(20, 185)
                particlePaint.color = Color.argb(a, Color.red(colour), Color.green(colour), Color.blue(colour))
                val size = 1.2f + 4.4f * u * ease
                canvas.drawCircle(x, y, size, particlePaint)
            }
        }

        // Small free ink droplets flow outward from the centre.
        for (i in 0 until 72) {
            val phase = ((ease * (.70f + (i % 7) * .035f) + i * .031f) % 1f)
            val angle = i * 2.399963f + .25f * sin(ease * 4f + i)
            val radius = maxR * (.08f + phase * .90f)
            val x = (cx + cos(angle) * radius).toFloat()
            val y = (cy + sin(angle) * radius).toFloat()
            val alpha = ((1f - phase) * 170f).toInt().coerceIn(0, 170)
            particlePaint.color = Color.argb(alpha, Color.red(ink[i % ink.size]), Color.green(ink[i % ink.size]), Color.blue(ink[i % ink.size]))
            canvas.drawCircle(x, y, 1.2f + (i % 4) * .75f, particlePaint)
        }

        // Golden centre glow behind the handwritten wordmark.
        val glowR = minOf(w, h) * (.16f + .035f * sin(t * Math.PI).toFloat())
        glowPaint.shader = RadialGradient(cx, cy, glowR,
            Color.argb(125, 255, 202, 84), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, glowR, glowPaint); glowPaint.shader = null

        drawWordmark(canvas, cx, cy, minOf(w, h), t)

        if (running) {
            if (elapsed >= DURATION_MS) {
                running = false
                if (!completionSent) {
                    completionSent = true
                    post { onFinished?.invoke() }
                }
            } else postInvalidateOnAnimation()
        }
    }

    private fun drawWordmark(canvas: Canvas, cx: Float, cy: Float, minDim: Float, t: Float) {
        val size = (minDim * .155f).coerceIn(54f, 118f)
        textPaint.textSize = size
        textPaint.typeface = Typeface.create("cursive", Typeface.NORMAL)
        textPaint.shader = LinearGradient(cx - size * 2f, cy - size, cx + size * 2f, cy + size,
            intArrayOf(Color.rgb(255, 239, 173), Color.rgb(255, 194, 61), Color.rgb(255, 224, 116)),
            null, Shader.TileMode.CLAMP)
        textPaint.setShadowLayer(24f, 0f, 0f, Color.argb(145, 255, 187, 45))
        val baseline = cy - (textPaint.ascent() + textPaint.descent()) * .5f
        // Reveal left-to-right to simulate handwriting; the final frame remains fully visible.
        val textWidth = textPaint.measureText("Rovex")
        val reveal = (t / .72f).coerceIn(0f, 1f)
        canvas.save()
        canvas.clipRect(cx - textWidth * .62f, 0f, cx - textWidth * .62f + textWidth * 1.24f * reveal, height.toFloat())
        canvas.drawText("Rovex", cx, baseline, textPaint)
        canvas.restore()
        textPaint.clearShadowLayer(); textPaint.shader = null
    }
}
