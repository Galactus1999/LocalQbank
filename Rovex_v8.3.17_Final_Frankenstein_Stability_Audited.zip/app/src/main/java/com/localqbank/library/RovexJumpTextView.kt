package com.localqbank.library

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.Gravity
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sin

/** Frankenstein wordmark: letters jump sequentially from left to right while retaining the existing colour flow. */
class RovexJumpTextView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : TextView(context, attrs) {
    private var phase = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() { super.onAttachedToWindow(); start() }
    override fun onDetachedFromWindow() { animator?.cancel(); animator = null; paint.shader = null; super.onDetachedFromWindow() }

    private fun start() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800L
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val value = text?.toString().orEmpty()
        if (value.isEmpty()) return super.onDraw(canvas)

        val p = Paint(paint)
        val total = p.measureText(value)
        val available = (width - paddingLeft - paddingRight).coerceAtLeast(0).toFloat()
        val gravityHorizontal = gravity and Gravity.HORIZONTAL_GRAVITY_MASK
        val xStart = when (gravityHorizontal) {
            Gravity.CENTER_HORIZONTAL -> paddingLeft + (available - total).coerceAtLeast(0f) / 2f
            Gravity.RIGHT, Gravity.END -> paddingLeft + (available - total).coerceAtLeast(0f)
            else -> paddingLeft.toFloat()
        }
        val baseline = paddingTop + ((height - paddingTop - paddingBottom) - (p.ascent() + p.descent())) / 2f

        // Preserve the existing configurable two-colour flow exactly; only the jump sequencing changes.
        val flow = RovexColorFlowTextView.flowEnabled(context)
        if (flow) {
            val travel = maxOf(total, width.toFloat()) * 1.6f
            val start = -travel + phase * travel
            p.shader = LinearGradient(
                start, 0f, start + travel, 0f,
                intArrayOf(
                    RovexColorFlowTextView.colorOne(context),
                    RovexColorFlowTextView.mix(
                        RovexColorFlowTextView.colorOne(context),
                        RovexColorFlowTextView.colorTwo(context),
                        .5f
                    ),
                    RovexColorFlowTextView.colorTwo(context),
                    RovexColorFlowTextView.colorOne(context)
                ),
                null,
                Shader.TileMode.MIRROR
            )
        } else {
            p.shader = null
            p.color = ThemeManager.text(context)
        }

        // One letter at a time, strictly left -> right, then restart from the first letter.
        val cursor = phase * value.length.toFloat()
        var x = xStart
        value.forEachIndexed { i, ch ->
            val distance = abs(cursor - (i + 0.5f))
            val jump = if (distance < 0.5f) {
                sin(((0.5f - distance) * 2f) * Math.PI).toFloat() * dp(5f)
            } else 0f
            canvas.drawText(ch.toString(), x, baseline - jump, p)
            x += p.measureText(ch.toString())
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}
