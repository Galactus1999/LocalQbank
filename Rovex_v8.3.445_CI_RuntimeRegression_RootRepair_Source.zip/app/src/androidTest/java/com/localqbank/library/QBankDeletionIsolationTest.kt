package com.localqbank.library

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Proves deleting one source cannot remove or hide another source's authoritative questions. */
@RunWith(AndroidJUnit4::class)
class QBankDeletionIsolationTest {
    private lateinit var db: QBankDb
    private lateinit var raw: android.database.sqlite.SQLiteDatabase

    @Before fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        QBankDb.resetDatabaseForTest(context)
        db = QBankDb(context)
        // Initialize the authoritative provider schema before opening the test-only raw handle.
        db.sources()
        raw = context.openOrCreateDatabase("qbank.db", 0, null)
        raw.execSQL("DELETE FROM question_fts")
        raw.execSQL("DELETE FROM question")
        raw.execSQL("DELETE FROM test")
        raw.execSQL("DELETE FROM source")
        raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(1,'delete.me','Delete Me','test',1)")
        raw.execSQL("INSERT INTO source(id,file_name,display_name,provider,imported_at) VALUES(2,'keep.me','Keep Me','test',2)")
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('delete-test',1,'Delete Test','delete',1)")
        raw.execSQL("INSERT INTO test(id,source_id,title,path,num_questions) VALUES('keep-test',2,'Keep Test','keep',1)")
        raw.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(1,'delete-test',0,'d1','delete-only-token','delete-only-token')")
        raw.execSQL("INSERT INTO question(id,test_id,position,source_question_id,text,raw_text) VALUES(2,'keep-test',0,'k1','keep-only-token','keep-only-token')")
        raw.execSQL("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(1,'delete-test',1,'delete-only-token')")
        raw.execSQL("INSERT INTO question_fts(question_id,test_id,source_id,content) VALUES(2,'keep-test',2,'keep-only-token')")
        raw.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('dirty','0')")
        raw.execSQL("INSERT OR REPLACE INTO search_index_meta(meta_key,meta_value) VALUES('garbage_pending','0')")
    }

    @Test
    fun deleteRequestHidesImmediatelyBeforePhysicalCleanup() {
        assertTrue(db.requestSourceDeletion(1L))

        // The user-visible catalog changes at the tombstone boundary, not after all questions
        // have been physically deleted. This is the critical responsiveness contract.
        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertEquals(listOf(1L), db.pendingDeletingSourceIds())

        // Physical data is still present at this point and is therefore available to the
        // resumable worker after process death. It must not be mistaken for a failed delete.
        assertEquals(1, db.questionCount("delete-test"))
        assertEquals(1, db.questionCount("keep-test"))

        assertTrue(db.deleteSource(1L, repairSearchIndex = false))
        assertTrue(db.pendingDeletingSourceIds().isEmpty())
        assertEquals(0, db.questionCount("delete-test"))
        assertEquals(1, db.questionCount("keep-test"))
    }

    @Test fun deletingOneQBankPreservesAnotherAndSearchRemainsLive() {
        assertTrue(db.deleteSource(1L, repairSearchIndex = false))

        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
        assertEquals(0, db.questionCount("delete-test"))
        assertEquals(1, db.questionCount("keep-test"))
        assertEquals(1, db.questions("keep-test").size)

        // Physical FTS garbage is intentionally tolerated until idle maintenance. Logical search
        // must still return live questions and must never return the deleted source.
        val keep = db.search("keep-only-token")
        val deleted = db.search("delete-only-token")
        assertFalse(keep.isEmpty())
        assertEquals(2L, keep.single().id)
        assertTrue(deleted.isEmpty())

        val dirty = raw.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='dirty'", null).use { it.moveToFirst(); it.getString(0) }
        val garbage = raw.rawQuery("SELECT meta_value FROM search_index_meta WHERE meta_key='garbage_pending'", null).use { it.moveToFirst(); it.getString(0) }
        assertEquals("0", dirty)
        assertEquals("1", garbage)
    }

    @Test fun boundedQuestionReferenceLookupNeverRequiresWholeCorpus() {
        val refs = db.questionRefsForIdsBounded(longArrayOf(2L))
        assertEquals(1, refs.size)
        assertEquals(2L, refs.single().id)
        assertEquals("Keep Test", refs.single().testTitle)
    }

    @Test fun deletionTombstoneIsVisibleToRecoveryUntilSourceIsFullyRemoved() {
        raw.execSQL("UPDATE source SET deleting=1 WHERE id=1")
        assertEquals(listOf(1L), db.pendingDeletingSourceIds())
        assertNull(db.sourceById(1L))
        assertNotNull(db.sourceById(2L))
    }

    @Test fun crashRecoveryOnlyResumesExplicitDeletionAndRestoresLegacyHiddenData() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val legacySource = db.importBundle("legacy-hidden", "legacy.html", "HTML", listOf(
            ImportedTest(
                originalId = "legacy", title = "Legacy", path = null, totalMarks = 1.0, duration = 0, timePerQuestion = 0.0,
                questions = listOf(ImportedQuestion("legacy-q", "legacy-only-token", null, "A", null, null, null, null,
                    listOf(ImportedOption("A", "answer", true)), emptyList(), emptyList()))
            )
        ))
        val explicitSource = db.importBundle("explicit-delete", "same.html", "HTML", listOf(
            ImportedTest(
                originalId = "explicit", title = "Explicit", path = null, totalMarks = 1.0, duration = 0, timePerQuestion = 0.0,
                questions = listOf(ImportedQuestion("explicit-q", "explicit-only-token", null, "A", null, null, null, null,
                    listOf(ImportedOption("A", "answer", true)), emptyList(), emptyList()))
            )
        ))
        assertTrue(legacySource > 0)
        assertTrue(explicitSource > 0)
        assertTrue(legacySource != explicitSource)

        raw.execSQL("UPDATE source SET deleting=1,delete_requested=0 WHERE file_name='legacy-hidden'")
        raw.execSQL("UPDATE source SET deleting=1,delete_requested=1 WHERE file_name='explicit-delete'")

        db.restoreLegacyTombstonedSources()
        assertNotNull(db.sourceById(legacySource.toLong()))
        assertEquals(listOf(explicitSource.toLong()), db.pendingDeletingSourceIds())
        assertEquals(1, db.search("legacy-only-token").size)

        // Simulate the durable recovery boundary after process death: only the explicit delete
        // intent may be destructively resumed. The legacy hidden source must remain intact.
        db.pendingDeletingSourceIds().forEach { id -> db.deleteSource(id, repairSearchIndex = false) }
        assertEquals(1, db.sources().size)
        assertNotNull(db.sourceById(legacySource.toLong()))
        assertEquals(1, db.search("legacy-only-token").size)
        assertTrue(db.search("explicit-only-token").isEmpty())
    }

}
