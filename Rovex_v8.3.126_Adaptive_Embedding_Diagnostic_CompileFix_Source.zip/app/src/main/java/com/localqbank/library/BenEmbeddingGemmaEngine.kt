package com.localqbank.library

import android.content.Context
import android.os.Build
import android.os.Debug
import com.sentencepiece.Model
import com.sentencepiece.Scoring
import com.sentencepiece.SentencePieceAlgorithm
import com.qualcomm.qti.QnnDelegate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Direct EmbeddingGemma execution boundary.
 *
 * The user-selected EmbeddingGemma .tflite graph is executed directly by LiteRT.
 * No higher-level embedding wrapper is allowed to reinterpret the model tensor contract.
 *
 * SentencePiece is used only for tokenization. Retrieval policy, learner logic and study logic
 * remain outside this class. Any failure falls back to deterministic retrieval.
 */
class BenEmbeddingGemmaEngine(context: Context) {
    private val app = context.applicationContext
    private val models = BenNeuralModelManager(app)
    private val profile = BenNeuralModelRegistry.embeddingGemma300m
    private val policy = BenAiRuntimePolicy(app)
    private val governor = BenAiResourceGovernor(app)

    data class SemanticHit<T>(val item: T, val similarity: Double)
    data class Result<T>(val hits: List<SemanticHit<T>>, val elapsedMs: Long, val usedModel: Boolean)
    data class DiagnosticReport(
        val timestampMs: Long,
        val appVersion: String,
        val android: String,
        val device: String,
        val abi: String,
        val modelName: String,
        val modelBytes: Long,
        val modelSha256: String,
        val tokenizerBytes: Long,
        val tokenizerSha256: String,
        val tokenizerParseOk: Boolean,
        val tokenizerSampleTokens: Int,
        val tokenizerSpecialTokens: String,
        val qnnAttempted: Boolean,
        val qnnAvailable: Boolean,
        val qnnFallback: Boolean,
        val qnnFailure: String?,
        val backend: String,
        val inputs: String,
        val outputs: String,
        val sequenceLength: Int,
        val embeddingDimension: Int,
        val embeddingType: String,
        val embeddingFinite: Boolean,
        val embeddingNorm: Double,
        val semanticSimilarCosine: Double,
        val semanticUnrelatedCosine: Double,
        val semanticSeparation: Double,
        val runtimeInitMs: Long,
        val inferenceMs: Long,
        val totalMs: Long,
        val availableRamBeforeMb: Int,
        val availableRamAfterMb: Int,
        val javaHeapBeforeMb: Long,
        val javaHeapAfterMb: Long,
        val nativeHeapBeforeMb: Long,
        val nativeHeapAfterMb: Long,
        val thermalBefore: Int,
        val thermalAfter: Int,
        val powerSaveBefore: Boolean,
        val powerSaveAfter: Boolean,
        val contractPassed: Boolean,
        val inferencePassed: Boolean,
        val semanticSmokePassed: Boolean,
        val overallPassed: Boolean,
        val failure: String?
    ) {
        fun toText(): String = buildString {
            appendLine("BEN / EMBEDDINGGEMMA DIAGNOSTIC REPORT")
            appendLine("Generated: ${java.util.Date(timestampMs)}")
            appendLine("Overall: ${if (overallPassed) "PASS" else "FAIL / REVIEW"}")
            appendLine()
            appendLine("1. DEVICE / RUNTIME")
            appendLine("App: $appVersion")
            appendLine("Android: $android")
            appendLine("Device: $device")
            appendLine("ABI: $abi")
            appendLine("RAM available: ${availableRamBeforeMb} MB -> ${availableRamAfterMb} MB")
            appendLine("Java heap: ${javaHeapBeforeMb} MB -> ${javaHeapAfterMb} MB")
            appendLine("Native heap: ${nativeHeapBeforeMb} MB -> ${nativeHeapAfterMb} MB")
            appendLine("Thermal: $thermalBefore -> $thermalAfter")
            appendLine("Power save: $powerSaveBefore -> $powerSaveAfter")
            appendLine()
            appendLine("2. ARTIFACTS")
            appendLine("Model: $modelName (${modelBytes / (1024 * 1024)} MB)")
            appendLine("Model SHA-256: $modelSha256")
            appendLine("SentencePiece: ${tokenizerBytes / (1024 * 1024)} MB")
            appendLine("Tokenizer SHA-256: $tokenizerSha256")
            appendLine("Tokenizer parse: ${if (tokenizerParseOk) "PASS" else "FAIL"}")
            appendLine("Tokenizer sample tokens: $tokenizerSampleTokens")
            appendLine("Special tokens: $tokenizerSpecialTokens")
            appendLine()
            appendLine("3. MODEL GRAPH / TENSOR CONTRACT")
            appendLine("Inputs: $inputs")
            appendLine("Outputs: $outputs")
            appendLine("Sequence length: $sequenceLength")
            appendLine("Embedding dimension: $embeddingDimension")
            appendLine("Embedding type: $embeddingType")
            appendLine("Contract: ${if (contractPassed) "PASS" else "FAIL"}")
            appendLine()
            appendLine("4. BACKEND")
            appendLine("Backend selected: $backend")
            appendLine("QNN attempted: $qnnAttempted")
            appendLine("QNN available: $qnnAvailable")
            appendLine("QNN fallback to CPU/XNNPACK: $qnnFallback")
            appendLine("QNN failure: ${qnnFailure ?: "none"}")
            appendLine()
            appendLine("5. INFERENCE")
            appendLine("Inference: ${if (inferencePassed) "PASS" else "FAIL"}")
            appendLine("Finite embedding: $embeddingFinite")
            appendLine("Embedding L2 norm: ${"%.5f".format(embeddingNorm)}")
            appendLine("Runtime initialization: ${runtimeInitMs} ms")
            appendLine("Inference time: ${inferenceMs} ms")
            appendLine("Total diagnostic time: ${totalMs} ms")
            appendLine()
            appendLine("6. SEMANTIC SMOKE TEST")
            appendLine("Related pair cosine: ${"%.5f".format(semanticSimilarCosine)}")
            appendLine("Unrelated pair cosine: ${"%.5f".format(semanticUnrelatedCosine)}")
            appendLine("Separation: ${"%.5f".format(semanticSeparation)}")
            appendLine("Semantic smoke test: ${if (semanticSmokePassed) "PASS" else "REVIEW"}")
            appendLine()
            appendLine("7. FAILURE / FALLBACK")
            appendLine("Failure: ${failure ?: "none"}")
            appendLine("Deterministic Ben/RAG remains authoritative if neural inference is unavailable.")
        }
    }

    suspend fun <T> rerank(
        query: String,
        candidates: List<T>,
        textOf: (T) -> String,
        limit: Int = 8
    ): Result<T> = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile)
        val tokenizer = models.installedEmbeddingGemmaTokenizer()
        if (installed == null) {
            fail("EmbeddingGemma model is not installed")
            return@withContext fallback(candidates, limit, started)
        }
        if (tokenizer == null) {
            fail("EmbeddingGemma sentencepiece.model is not installed")
            return@withContext fallback(candidates, limit, started)
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, governor.snapshot(true))
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext fallback(candidates, limit, started)
        }
        val cleanQuery = clean(query)
        if (cleanQuery.length < 2 || candidates.isEmpty()) {
            return@withContext fallback(candidates, limit, started)
        }
        try {
            val runtime = Runtime(installed.file, tokenizer)
            runtime.use {
                BenNeuralTelemetry.stage(
                    BenNeuralTelemetry.Stage.SEMANTIC_RERANK,
                    "Semantic reranking via ${it.backend()}",
                    "EmbeddingGemma 300M",
                    it.backend()
                )
                val queryVector = it.embed(cleanQuery, Task.RETRIEVAL_QUERY)
                val selected = candidates.take(8)
                val scored = selected.map { candidate ->
                    val text = clean(textOf(candidate))
                    SemanticHit(candidate, cosine(queryVector, it.embed(text, Task.RETRIEVAL_DOCUMENT)))
                }.sortedByDescending { it.similarity }.take(limit.coerceIn(1, 8))
                policy.recordBackendSuccess()
                Result(scored, max(0L, System.currentTimeMillis() - started), true)
            }
        } catch (error: LinkageError) {
            fail("EmbeddingGemma native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            fallback(candidates, limit, started)
        } catch (error: Exception) {
            fail(runtimeMessage(error))
            policy.recordBackendFailure()
            fallback(candidates, limit, started)
        }
    }

    suspend fun compare(first: String, second: String): Double? = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val installed = models.installed(profile) ?: run {
            fail("EmbeddingGemma model is not installed")
            return@withContext null
        }
        val tokenizer = models.installedEmbeddingGemmaTokenizer() ?: run {
            fail("EmbeddingGemma sentencepiece.model is not installed")
            return@withContext null
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, governor.snapshot(true))
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext null
        }
        try {
            val runtime = Runtime(installed.file, tokenizer)
            runtime.use {
                BenNeuralTelemetry.stage(
                    BenNeuralTelemetry.Stage.SEMANTIC_RERANK,
                    "EmbeddingGemma inference via ${it.backend()}",
                    "EmbeddingGemma 300M",
                    it.backend()
                )
                val a = it.embed(clean(first), Task.SENTENCE_SIMILARITY)
                val b = it.embed(clean(second), Task.SENTENCE_SIMILARITY)
                if (a.size != b.size) throw IllegalStateException("Embedding dimension mismatch: ${a.size} vs ${b.size}")
                if (a.size < 128) throw IllegalStateException("Unexpected embedding dimension: ${a.size}")
                val score = cosine(a, b)
                policy.recordBackendSuccess()
                BenNeuralTelemetry.semantic(max(0L, System.currentTimeMillis() - started), true)
                score
            }
        } catch (error: LinkageError) {
            fail("EmbeddingGemma native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(240) ?: "no message"}")
            policy.recordBackendFailure()
            null
        } catch (error: Exception) {
            fail(runtimeMessage(error))
            policy.recordBackendFailure()
            null
        }
    }

    /**
     * Non-destructive diagnostic for Adaptive Engine. It validates the installed artifact,
     * tokenizer, tensor contract, backend selection and a small semantic-similarity pair.
     * It never writes study data.
     */
    suspend fun diagnostic(): String? = diagnosticReport()?.toText()

    suspend fun diagnosticReport(): DiagnosticReport = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val before = governor.snapshot(true)
        val runtimeBefore = runtimeMemory()
        val installed = models.installed(profile)
        val tokenizerFile = models.installedEmbeddingGemmaTokenizer()
        val modelBytes = installed?.bytes ?: 0L
        val tokenizerBytes = tokenizerFile?.length() ?: 0L
        val modelHash = installed?.file?.let { runCatching { sha256(it) }.getOrNull() } ?: "not available"
        val tokenizerHash = tokenizerFile?.let { runCatching { sha256(it) }.getOrNull() } ?: "not available"
        fun publish(report: DiagnosticReport): DiagnosticReport {
            BenNeuralTelemetry.setDiagnosticReport(report.toText())
            return report
        }
        if (installed == null || tokenizerFile == null) {
            val failure = if (installed == null && tokenizerFile == null) "Model and SentencePiece tokenizer are not installed" else if (installed == null) "EmbeddingGemma model is not installed" else "EmbeddingGemma sentencepiece.model is not installed"
            fail(failure)
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, failure))
        }
        val blockReason = policy.blockReason(profile.estimatedModelMb, profile.estimatedRuntimeMb, before)
        if (blockReason != null) {
            fail("EmbeddingGemma blocked: $blockReason")
            BenNeuralTelemetry.blocked(blockReason)
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, "Governor blocked: $blockReason"))
        }
        try {
            val runtimeStarted = System.currentTimeMillis()
            Runtime(installed.file, tokenizerFile).use { runtime ->
                val runtimeInitMs = System.currentTimeMillis() - runtimeStarted
                val relatedA = "nephrotic syndrome causes edema due to urinary protein loss and reduced plasma oncotic pressure"
                val relatedB = "protein loss in urine lowers plasma oncotic pressure and produces edema"
                val unrelated = "renal calculi commonly cause severe colicky flank pain with hematuria"
                val inferenceStarted = System.currentTimeMillis()
                val a = runtime.embed(relatedA, Task.SENTENCE_SIMILARITY)
                val b = runtime.embed(relatedB, Task.SENTENCE_SIMILARITY)
                val c = runtime.embed(unrelated, Task.SENTENCE_SIMILARITY)
                val inferenceMs = System.currentTimeMillis() - inferenceStarted
                val similar = cosine(a, b)
                val unrelatedScore = cosine(a, c)
                val separation = similar - unrelatedScore
                val finite = a.all { it.isFinite() } && b.all { it.isFinite() } && c.all { it.isFinite() }
                val norm = sqrt(a.sumOf { it.toDouble() * it.toDouble() })
                val after = governor.snapshot(true)
                val runtimeAfter = runtimeMemory()
                val contractPassed = runtime.contractPassed()
                val inferencePassed = finite && a.size == 768 && b.size == 768 && c.size == 768
                val semanticPassed = finite && separation > 0.0
                val overall = contractPassed && inferencePassed && semanticPassed
                val report = DiagnosticReport(
                    timestampMs = System.currentTimeMillis(), appVersion = appVersion(),
                    android = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                    device = deviceDescription(),
                    abi = Build.SUPPORTED_ABIS.joinToString(", "), modelName = profile.name, modelBytes = modelBytes, modelSha256 = modelHash,
                    tokenizerBytes = tokenizerBytes, tokenizerSha256 = tokenizerHash, tokenizerParseOk = runtime.tokenizerParsed(),
                    tokenizerSampleTokens = runtime.lastTokenCount(), tokenizerSpecialTokens = "BOS=2, EOS=1, PAD=0; padded=${runtime.sequenceLengthValue()}",
                    qnnAttempted = runtime.qnnAttempted(), qnnAvailable = runtime.qnnAvailable(), qnnFallback = runtime.qnnFallback(), qnnFailure = runtime.qnnFailure(),
                    backend = runtime.backend(), inputs = runtime.inputsDescription(), outputs = runtime.outputsDescription(), sequenceLength = runtime.sequenceLengthValue(),
                    embeddingDimension = a.size, embeddingType = "FLOAT32", embeddingFinite = finite, embeddingNorm = norm,
                    semanticSimilarCosine = similar, semanticUnrelatedCosine = unrelatedScore, semanticSeparation = separation,
                    runtimeInitMs = runtimeInitMs, inferenceMs = inferenceMs, totalMs = System.currentTimeMillis() - started,
                    availableRamBeforeMb = before.availableMemoryMb, availableRamAfterMb = after.availableMemoryMb,
                    javaHeapBeforeMb = runtimeBefore.javaHeapMb, javaHeapAfterMb = runtimeAfter.javaHeapMb,
                    nativeHeapBeforeMb = runtimeBefore.nativeHeapMb, nativeHeapAfterMb = runtimeAfter.nativeHeapMb,
                    thermalBefore = before.thermalStatus, thermalAfter = after.thermalStatus, powerSaveBefore = before.powerSave, powerSaveAfter = after.powerSave,
                    contractPassed = contractPassed, inferencePassed = inferencePassed, semanticSmokePassed = semanticPassed, overallPassed = overall,
                    failure = if (overall) null else "One or more diagnostic gates failed or require review"
                )
                if (overall) { policy.recordBackendSuccess(); BenNeuralTelemetry.semantic(inferenceMs, true) } else { policy.recordBackendFailure(); BenNeuralTelemetry.error(report.failure ?: "Diagnostic review required") }
                return@withContext publish(report)
            }
        } catch (error: LinkageError) {
            val message = "EmbeddingGemma diagnostic native/runtime linkage: ${error.javaClass.simpleName}: ${error.message?.take(320) ?: "no message"}"
            fail(message); policy.recordBackendFailure()
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, message))
        } catch (error: Exception) {
            val message = runtimeMessage(error)
            fail(message); policy.recordBackendFailure()
            return@withContext publish(failureReport(started, before, runtimeBefore, modelBytes, tokenizerBytes, modelHash, tokenizerHash, message))
        }
    }

    private fun failureReport(started: Long, before: BenAiResourceGovernor.Snapshot, memory: RuntimeMemory, modelBytes: Long, tokenizerBytes: Long, modelHash: String, tokenizerHash: String, failure: String): DiagnosticReport {
        return DiagnosticReport(
            timestampMs = System.currentTimeMillis(), appVersion = appVersion(),
            android = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            device = deviceDescription(),
            abi = Build.SUPPORTED_ABIS.joinToString(", "), modelName = profile.name, modelBytes = modelBytes, modelSha256 = modelHash,
            tokenizerBytes = tokenizerBytes, tokenizerSha256 = tokenizerHash, tokenizerParseOk = false, tokenizerSampleTokens = 0, tokenizerSpecialTokens = "unknown",
            qnnAttempted = false, qnnAvailable = false, qnnFallback = false, qnnFailure = null, backend = "not started", inputs = "not inspected", outputs = "not inspected",
            sequenceLength = 0, embeddingDimension = 0, embeddingType = "unknown", embeddingFinite = false, embeddingNorm = 0.0, semanticSimilarCosine = 0.0, semanticUnrelatedCosine = 0.0, semanticSeparation = 0.0,
            runtimeInitMs = 0L, inferenceMs = 0L, totalMs = System.currentTimeMillis() - started, availableRamBeforeMb = before.availableMemoryMb, availableRamAfterMb = before.availableMemoryMb,
            javaHeapBeforeMb = memory.javaHeapMb, javaHeapAfterMb = memory.javaHeapMb, nativeHeapBeforeMb = memory.nativeHeapMb, nativeHeapAfterMb = memory.nativeHeapMb,
            thermalBefore = before.thermalStatus, thermalAfter = before.thermalStatus, powerSaveBefore = before.powerSave, powerSaveAfter = before.powerSave,
            contractPassed = false, inferencePassed = false, semanticSmokePassed = false, overallPassed = false, failure = failure
        )
    }

    private fun appVersion(): String {
        return try {
            @Suppress("DEPRECATION")
            app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "unknown"
        } catch (_: Exception) {
            "unknown"
        }
    }

    private fun deviceDescription(): String {
        val soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
        return "${Build.MANUFACTURER} ${Build.MODEL} / $soc"
    }

    private data class RuntimeMemory(val javaHeapMb: Long, val nativeHeapMb: Long)
    private fun runtimeMemory(): RuntimeMemory {
        val r = java.lang.Runtime.getRuntime()
        val javaMb = ((r.totalMemory() - r.freeMemory()).coerceAtLeast(0L) / (1024L * 1024L))
        val nativeMb = Debug.getNativeHeapAllocatedSize() / (1024L * 1024L)
        return RuntimeMemory(javaMb, nativeMb)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /** Direct model contract + inference implementation. */
    private inner class Runtime(model: File, tokenizerFile: File) : AutoCloseable {
        private lateinit var interpreter: Interpreter
        private lateinit var tokenizer: Model
        private val tokenizerAlgorithm = SentencePieceAlgorithm(true, Scoring.HIGHEST_SCORE)
        private var qnnDelegate: QnnDelegate? = null
        private var backendName: String = "CPU/XNNPACK"
        private var qnnAttemptedValue = false
        private var qnnAvailableValue = false
        private var qnnFallbackValue = false
        private var qnnFailureValue: String? = null
        private var tokenizerParsedValue = false
        private var lastTokenCountValue = 0
        private var inputsDescriptionValue = ""
        private var outputsDescriptionValue = ""
        private val inputIdsIndex: Int
        private val attentionMaskIndex: Int?
        private val sequenceLength: Int
        private val inputIdType: DataType
        private val maskType: DataType?
        private val outputIndex: Int
        private val outputShape: IntArray
        private val contractDescription: String

        init {
            var interpreterLocal: Interpreter? = null
            try {
                // Do not use DJL SentencePiece JNI on Android. DJL's SentencePiece loader
                // is designed around its native-library extraction/cache mechanism and can
                // fail with "IllegalStateException: Cannot copy jni files" on Android.
                // SentencePiece4J is a pure-Java implementation, so tokenizer execution is
                // offline, deterministic, and does not require JNI/native file extraction.
                qnnAttemptedValue = isQualcommDevice()
                val tokenizerReady = Model.parseFrom(tokenizerFile.toPath())
                tokenizerParsedValue = true
                val qnnAttempt = createQnnDelegateIfSupported()
                qnnAvailableValue = qnnAttempt != null
                val interpreterReady = try {
                    createAndAllocate(model, qnnAttempt)
                } catch (firstError: Exception) {
                    if (qnnAttempt != null) {
                        qnnFallbackValue = true
                        qnnFailureValue = "${firstError.javaClass.simpleName}: ${firstError.message?.take(240) ?: "no message"}"
                        fail("EmbeddingGemma QNN HTP allocation failed; falling back to CPU/XNNPACK: ${firstError.javaClass.simpleName}: ${firstError.message?.take(240) ?: "no message"}")
                        qnnDelegate = null
                        backendName = "CPU/XNNPACK (QNN fallback)"
                        createAndAllocate(model, null)
                    } else {
                        throw firstError
                    }
                } catch (firstError: LinkageError) {
                    if (qnnAttempt != null) {
                        qnnFallbackValue = true
                        qnnFailureValue = "${firstError.javaClass.simpleName}: ${firstError.message?.take(240) ?: "no message"}"
                        fail("EmbeddingGemma QNN HTP native linkage failed; falling back to CPU/XNNPACK: ${firstError.javaClass.simpleName}: ${firstError.message?.take(240) ?: "no message"}")
                        qnnDelegate = null
                        backendName = "CPU/XNNPACK (QNN fallback)"
                        createAndAllocate(model, null)
                    } else {
                        throw firstError
                    }
                }
                interpreterLocal = interpreterReady

                tokenizer = tokenizerReady
                interpreter = interpreterReady

                val inputCount = interpreter.inputTensorCount
            if (inputCount != 2) {
                throw IllegalStateException("EmbeddingGemma 512 expects 2 inputs (input_ids + attention_mask), got $inputCount")
            }

            val inputs = (0 until inputCount).map { i ->
                val t = interpreter.getInputTensor(i)
                InputInfo(i, t.name(), t.dataType(), t.shape())
            }
            val id = inputs.firstOrNull { looksLikeIds(it.name) }
                ?: inputs.firstOrNull { it.type == DataType.INT64 || it.type == DataType.INT32 }
                ?: throw IllegalStateException("No integer token-id input found. Contract=${describe(inputs)}")
            inputIdsIndex = id.index
            inputIdType = id.type
            sequenceLength = sequenceLength(id.shape)
            if (id.shape.size != 2 || id.shape[0] != 1 || sequenceLength != 512) {
                throw IllegalStateException("EmbeddingGemma 512 requires input shape [1,512], got ${id.shape.contentToString()}. Contract=${describe(inputs)}")
            }
            if (inputIdType != DataType.INT64 && inputIdType != DataType.INT32) {
                throw IllegalStateException("EmbeddingGemma 512 requires INT64/INT32 input_ids, got $inputIdType. Contract=${describe(inputs)}")
            }

            attentionMaskIndex = inputs.firstOrNull { it.index != inputIdsIndex && looksLikeMask(it.name) }?.index
                ?: inputs.firstOrNull { it.index != inputIdsIndex }?.index
            maskType = attentionMaskIndex?.let { interpreter.getInputTensor(it).dataType() }
            if (attentionMaskIndex == null) {
                throw IllegalStateException("EmbeddingGemma 512 attention_mask input is missing. Contract=${describe(inputs)}")
            }
            if (maskType != DataType.INT64 && maskType != DataType.INT32) {
                throw IllegalStateException("EmbeddingGemma 512 requires INT64/INT32 attention_mask, got $maskType. Contract=${describe(inputs)}")
            }
            val maskShape = interpreter.getInputTensor(attentionMaskIndex).shape()
            if (maskShape.contentEquals(id.shape).not()) {
                throw IllegalStateException("attention_mask shape ${maskShape.contentToString()} does not match input_ids ${id.shape.contentToString()}. Contract=${describe(inputs)}")
            }

            val outputs = (0 until interpreter.outputTensorCount).map { i ->
                val t = interpreter.getOutputTensor(i)
                OutputInfo(i, t.name(), t.dataType(), t.shape(), t.numElements())
            }
            val chosen = outputs.filter { it.type == DataType.FLOAT32 && it.elements >= 128 }
                .maxByOrNull { scoreOutput(it) }
                ?: throw IllegalStateException("No usable float embedding output. Contract=${describe(outputs)}")
            outputIndex = chosen.index
            outputShape = chosen.shape
            if (chosen.elements != 768 || chosen.type != DataType.FLOAT32) {
                throw IllegalStateException("EmbeddingGemma 512 expects 768 float32 values, got ${chosen.shape.contentToString()} ${chosen.type}. Contract=${describe(outputs)}")
            }
                inputsDescriptionValue = describe(inputs)
                outputsDescriptionValue = describe(outputs)
                contractDescription = "backend=$backendName; inputs=${inputsDescriptionValue}; output=${describe(listOf(chosen))}"
            } catch (error: Exception) {
                try { interpreterLocal?.close() } catch (_: Exception) {}
                throw error
            } catch (error: LinkageError) {
                try { interpreterLocal?.close() } catch (_: Exception) {}
                throw error
            }
        }

        fun embed(text: String, task: Task): List<Float> {
            val ids = tokenize(task.prefix + text)
            val padded = LongArray(sequenceLength)
            val count = minOf(ids.size, sequenceLength)
            for (i in 0 until count) padded[i] = ids[i].toLong()
            val mask = LongArray(sequenceLength) { if (it < count) 1L else 0L }

            val inputs = arrayOfNulls<Any>(interpreter.inputTensorCount)
            inputs[inputIdsIndex] = tokenBuffer(padded, inputIdType)
            attentionMaskIndex?.let { inputs[it] = tokenBuffer(mask, maskType ?: inputIdType) }

            val output = FloatArray(interpreter.getOutputTensor(outputIndex).numElements())
            val outputs = hashMapOf<Int, Any>(outputIndex to output)
            interpreter.runForMultipleInputsOutputs(inputs.requireNoNulls(), outputs)
            if (output.size != 768) throw IllegalStateException("EmbeddingGemma produced ${output.size} values; expected 768")
            return output.toList()
        }

        private fun tokenize(text: String): IntArray {
            val ids = tokenizer.encodeNormalized(text, tokenizerAlgorithm).map { it }.toIntArray()
            // EmbeddingGemma/Gemma tokenizer uses BOS=2, EOS=1, PAD=0. SentencePiece itself
            // does not automatically apply the model's special-token policy here, so add the
            // same special tokens used by the Hugging Face Gemma tokenizer.
            val withSpecial = IntArray(ids.size + 2)
            withSpecial[0] = 2
            ids.copyInto(withSpecial, destinationOffset = 1)
            withSpecial[withSpecial.lastIndex] = 1
            lastTokenCountValue = withSpecial.size
            return withSpecial
        }

        private fun tokenBuffer(values: LongArray, type: DataType): ByteBuffer {
            return when (type) {
                DataType.INT64 -> ByteBuffer.allocateDirect(values.size * Long.SIZE_BYTES)
                    .order(ByteOrder.nativeOrder())
                    .apply {
                        asLongBuffer().put(values)
                        rewind()
                    }
                DataType.INT32 -> ByteBuffer.allocateDirect(values.size * Int.SIZE_BYTES)
                    .order(ByteOrder.nativeOrder())
                    .apply {
                        asIntBuffer().put(values.map { it.toInt() }.toIntArray())
                        rewind()
                    }
                else -> throw IllegalStateException("EmbeddingGemma token tensors must be INT64 or INT32, got $type")
            }
        }

        fun backend(): String = backendName

        private fun createQnnDelegateIfSupported(): QnnDelegate? {
            if (!isQualcommDevice()) return null
            return try {
                val options = QnnDelegate.Options().apply {
                    setBackendType(QnnDelegate.Options.BackendType.HTP_BACKEND)
                    setSkelLibraryDir(app.applicationInfo.nativeLibraryDir)
                }
                QnnDelegate(options).also {
                    qnnDelegate = it
                    backendName = "Qualcomm QNN HTP"
                }
            } catch (error: LinkageError) {
                qnnFailureValue = "${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}"
                fail("QNN unavailable: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}")
                null
            } catch (error: Exception) {
                qnnFailureValue = "${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}"
                fail("QNN unavailable: ${error.javaClass.simpleName}: ${error.message?.take(220) ?: "no message"}")
                null
            }
        }

        private fun createInterpreter(model: File, delegate: QnnDelegate?): Interpreter {
            val options = Interpreter.Options().apply {
                setNumThreads(4)
                setCancellable(true)
                if (delegate == null) {
                    setUseXNNPACK(true)
                } else {
                    setUseXNNPACK(false)
                    addDelegate(delegate)
                }
            }
            return Interpreter(model, options)
        }

        private fun createAndAllocate(model: File, delegate: QnnDelegate?): Interpreter {
            val interpreter = createInterpreter(model, delegate)
            return try {
                interpreter.allocateTensors()
                interpreter
            } catch (error: Exception) {
                runCatching { interpreter.close() }
                throw error
            } catch (error: LinkageError) {
                runCatching { interpreter.close() }
                throw error
            }
        }

        private fun isQualcommDevice(): Boolean {
            val manufacturer = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER else Build.HARDWARE
            val model = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE
            return manufacturer.contains("qualcomm", true) || manufacturer.contains("qti", true) ||
                model.equals("SM8650", true) || model.equals("SM8550", true) ||
                model.equals("SM8750", true) || model.equals("SM8850", true) ||
                Build.HARDWARE.contains("qcom", true)
        }

        fun contract(): String = contractDescription
        fun contractPassed(): Boolean = contractDescription.isNotBlank() && sequenceLength == 512 && outputShape.contentEquals(intArrayOf(1, 768)) || (contractDescription.isNotBlank() && outputShape.reduce { a, b -> a * b } == 768)
        fun tokenizerParsed(): Boolean = tokenizerParsedValue
        fun lastTokenCount(): Int = lastTokenCountValue
        fun sequenceLengthValue(): Int = sequenceLength
        fun qnnAttempted(): Boolean = qnnAttemptedValue
        fun qnnAvailable(): Boolean = qnnAvailableValue
        fun qnnFallback(): Boolean = qnnFallbackValue
        fun qnnFailure(): String? = qnnFailureValue
        fun inputsDescription(): String = inputsDescriptionValue
        fun outputsDescription(): String = outputsDescriptionValue

        override fun close() {
            try { interpreter.close() } catch (_: Exception) {}
        }
    }

    private enum class Task(val prefix: String) {
        RETRIEVAL_QUERY("task: search result | query: "),
        RETRIEVAL_DOCUMENT("title: none | text: "),
        SENTENCE_SIMILARITY("task: sentence similarity | query: ")
    }

    private data class InputInfo(val index: Int, val name: String, val type: DataType, val shape: IntArray)
    private data class OutputInfo(val index: Int, val name: String, val type: DataType, val shape: IntArray, val elements: Int)

    private fun looksLikeIds(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("input_ids") || n.contains("token") || n.contains("text_batch") || n.contains("ids")
    }

    private fun looksLikeMask(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("attention") || n.contains("mask")
    }

    private fun sequenceLength(shape: IntArray): Int = shape.lastOrNull() ?: 0

    private fun scoreOutput(info: OutputInfo): Int {
        val name = info.name.lowercase()
        var score = 0
        if (info.elements == 768) score += 1000
        if (name.contains("embed") || name.contains("encoding") || name.contains("sentence")) score += 500
        if (info.shape.size == 2) score += 100
        return score
    }

    private fun describe(items: List<Any>): String = items.joinToString(" | ") { item ->
        when (item) {
            is InputInfo -> "in#${item.index}:${item.name}:${item.type}:${item.shape.contentToString()}"
            is OutputInfo -> "out#${item.index}:${item.name}:${item.type}:${item.shape.contentToString()}"
            else -> item.toString()
        }
    }

    private fun runtimeMessage(error: Exception): String =
        "EmbeddingGemma runtime: ${error.javaClass.simpleName}: ${error.message?.take(320) ?: "no message"}"

    private fun fail(message: String) {
        BenNeuralTelemetry.error(message)
    }

    private fun cosine(a: List<Float>, b: List<Float>): Double {
        val n = minOf(a.size, b.size)
        if (n == 0) return 0.0
        var dot = 0.0
        var aa = 0.0
        var bb = 0.0
        for (i in 0 until n) {
            val x = a[i].toDouble()
            val y = b[i].toDouble()
            dot += x * y
            aa += x * x
            bb += y * y
        }
        return if (aa <= 0.0 || bb <= 0.0) 0.0 else
            (dot / (sqrt(aa) * sqrt(bb))).coerceIn(-1.0, 1.0)
    }

    private fun clean(value: String) = value.replace(Regex("\\s+"), " ").trim().take(1800)

    private fun <T> fallback(candidates: List<T>, limit: Int, started: Long) =
        Result(candidates.take(limit.coerceAtLeast(0)).map { SemanticHit(it, 0.0) }, max(0L, System.currentTimeMillis() - started), false)
}
