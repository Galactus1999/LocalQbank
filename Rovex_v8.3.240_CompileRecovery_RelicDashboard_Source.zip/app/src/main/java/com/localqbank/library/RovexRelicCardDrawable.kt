package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable

/**
 * Theme-aware dashboard card skin.
 *
 * It is intentionally a Drawable rather than a bitmap: no extra assets, no density-specific
 * resources, and no measurable image memory cost. The decoration is kept low-contrast so the
 * card remains readable and accessible in every Rovex theme.
 */
class RovexRelicCardDrawable(
    private val context: Context,
    val kind: Kind
) : Drawable() {

    enum class Kind { TODAY, STUDY, FLASHCARD }

    private val density = context.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pressed = false

    override fun isStateful(): Boolean = true

    override fun onStateChange(state: IntArray): Boolean {
        val next = state.contains(android.R.attr.state_pressed)
        if (next == pressed) return false
        pressed = next
        invalidateSelf()
        return true
    }

    override fun draw(canvas: Canvas) {
        val dark = ThemeManager.isDark(context)
        val amoled = ThemeManager.get(context) == ThemeManager.AMOLED
        val accent = ThemeManager.accent(context)
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val r = 18f * density

        val base = when (kind) {
            Kind.TODAY -> if (amoled) Color.BLACK else if (dark) Color.rgb(23, 39, 45) else Color.rgb(237, 247, 244)
            Kind.STUDY -> if (amoled) Color.BLACK else if (dark) Color.rgb(29, 35, 50) else Color.rgb(244, 242, 250)
            Kind.FLASHCARD -> if (amoled) Color.BLACK else if (dark) Color.rgb(25, 32, 41) else Color.rgb(247, 246, 240)
        }

        fill.style = Paint.Style.FILL
        fill.color = base
        canvas.drawRoundRect(RectF(0f, 0f, w, h), r, r, fill)

        // Subtle "paper sheet" geometry.
        val fold = 28f * density
        val sheet = Path().apply {
            moveTo(w - fold, 0f)
            lineTo(w, 0f)
            lineTo(w, fold)
            close()
        }
        fill.color = Color.argb(if (dark) 24 else 30, Color.WHITE, Color.WHITE, Color.WHITE)
        canvas.drawPath(sheet, fill)

        line.strokeWidth = 1f * density
        line.color = Color.argb(if (dark) 46 else 55, Color.WHITE, Color.WHITE, Color.WHITE)
        val left = 14f * density
        val right = w - 14f * density
        val startY = h - 24f * density
        var y = startY
        while (y > 12f * density) {
            canvas.drawLine(left, y, right, y, line)
            y -= 8f * density
        }

        // Theme-colored "relic" watermark at the far right, deliberately behind content.
        line.color = Color.argb(if (dark) 68 else 72, Color.red(accent), Color.green(accent), Color.blue(accent))
        ink.color = Color.argb(if (dark) 38 else 42, Color.red(accent), Color.green(accent), Color.blue(accent))
        val cx = w - 34f * density
        val cy = h - 31f * density
        val rr = 15f * density
        canvas.drawCircle(cx, cy, rr, line)
        canvas.drawCircle(cx, cy, rr * .62f, line)

        when (kind) {
            Kind.TODAY -> {
                // Calendar stamp + check mark.
                canvas.drawLine(cx - 7f*density, cy - 5f*density, cx + 7f*density, cy - 5f*density, line)
                canvas.drawLine(cx - 7f*density, cy + 1f*density, cx - 1f*density, cy + 6f*density, line)
                canvas.drawLine(cx - 1f*density, cy + 6f*density, cx + 8f*density, cy - 5f*density, line)
                canvas.drawCircle(cx - 6f*density, cy - 9f*density, 1.5f*density, ink)
                canvas.drawCircle(cx + 6f*density, cy - 9f*density, 1.5f*density, ink)
            }
            Kind.STUDY -> {
                // Open-book / study desk glyph.
                val p = Path().apply {
                    moveTo(cx - 10f*density, cy - 7f*density)
                    quadTo(cx - 3f*density, cy - 10f*density, cx, cy - 5f*density)
                    quadTo(cx + 3f*density, cy - 10f*density, cx + 10f*density, cy - 7f*density)
                    lineTo(cx + 10f*density, cy + 8f*density)
                    quadTo(cx + 3f*density, cy + 5f*density, cx, cy + 10f*density)
                    quadTo(cx - 3f*density, cy + 5f*density, cx - 10f*density, cy + 8f*density)
                    close()
                }
                canvas.drawPath(p, line)
                canvas.drawLine(cx, cy - 5f*density, cx, cy + 9f*density, line)
            }
            Kind.FLASHCARD -> {
                canvas.drawRoundRect(
                    RectF(cx - 9f*density, cy - 6f*density, cx + 9f*density, cy + 7f*density),
                    3f*density, 3f*density, line
                )
                canvas.drawLine(cx - 5f*density, cy - 1f*density, cx + 5f*density, cy - 1f*density, line)
            }
        }

        if (pressed) {
            fill.color = Color.argb(if (dark) 22 else 16, Color.BLACK, Color.BLACK, Color.BLACK)
            canvas.drawRoundRect(RectF(0f, 0f, w, h), r, r, fill)
        }

        // Fine perimeter stroke ties the relic to the active theme.
        line.color = Color.argb(if (dark) 95 else 72, Color.red(accent), Color.green(accent), Color.blue(accent))
        line.strokeWidth = 1f * density
        canvas.drawRoundRect(RectF(.5f, .5f, w-.5f, h-.5f), r, r, line)
    }

    override fun setAlpha(alpha: Int) { /* opaque base skin; alpha is intentionally ignored */ }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) { }
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}
