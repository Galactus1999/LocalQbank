package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Tiny animated SRS dashboard for the Home Flashcards card. */
class RovexFlashcardSummaryView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var cards=0; private var due=0; private var reviews=0
    fun setStats(cards:Int,due:Int,reviews:Int){this.cards=cards.coerceAtLeast(0);this.due=due.coerceAtLeast(0);this.reviews=reviews.coerceAtLeast(0);invalidate()}
    override fun onDraw(c:Canvas){
        val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0)return
        val dark=ThemeManager.isDark(context);val accent=ThemeManager.accent(context)
        p.color=if(dark)0xFF16232C.toInt() else 0xFFE8F4F2.toInt();c.drawRoundRect(8f,8f,w-8f,h-8f,18f,18f,p)
        p.color=accent;p.textSize=10f;p.isFakeBoldText=true;c.drawText("SRS",18f,25f,p)
        p.color=if(dark)0xFFE8EEF2.toInt() else 0xFF263C46.toInt();p.textSize=16f;c.drawText(cards.toString(),18f,48f,p)
        p.isFakeBoldText=false;p.textSize=8.5f;c.drawText("CARDS",18f,61f,p)
        p.color=if(due>0)0xFFE06B63.toInt() else 0xFF43A77D.toInt();p.textSize=11f;p.isFakeBoldText=true;c.drawText(if(due>0)"$due DUE" else "READY",18f,78f,p)
        p.isFakeBoldText=false;p.color=if(dark)0xFF9FB0BA.toInt() else 0xFF60727B.toInt();p.textSize=8f;c.drawText("$reviews reviews",18f,91f,p)
    }
}
