package com.localqbank.library

import android.text.Html
import android.text.Spanned

/** Small, deterministic Markdown presentation layer for AI output. No network or model work. */
fun rovexMarkdownToSpanned(raw: String): Spanned {
        var s = raw
            .replace(Regex("(?m)^#{1,6}\\s+"), "")
            .replace(Regex("(?m)^[-*]\\s+"), "• ")
            .replace(Regex("(?m)^\\d+[.)]\\s+")) { m -> m.value }
        // Only translate bounded inline Markdown markers; existing HTML remains supported.
        s = s.replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "<b>$1</b>")
            .replace(Regex("(?<!\\*)\\*([^*\\n]+?)\\*(?!\\*)"), "<i>$1</i>")
            .replace(Regex("`([^`\\n]+?)`"), "<tt>$1</tt>")
        return Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY)
    }
