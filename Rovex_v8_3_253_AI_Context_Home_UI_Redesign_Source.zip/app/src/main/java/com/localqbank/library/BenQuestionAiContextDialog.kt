package com.localqbank.library

import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import androidx.lifecycle.lifecycleScope
import com.localqbank.library.ai.context.ContextPackBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** UI-only context chooser; canonical context remains ContextPackBuilder/FrankensteinContextEngine. */
class BenQuestionAiContextDialog {
    fun show(activity: QuizActivity, q: Question, selectedOption: String?) {
        ProductionCrashReporter.breadcrumb(activity, "AI_CONTEXT_OPENED")
        val dialog=Dialog(activity)
        val outer=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(activity,18),dp(activity,16),dp(activity,18),dp(activity,12));background=UiDrawableUtils.roundedDrawable(activity,ThemeManager.dialogBg(activity),24f)}
        outer.addView(TextView(activity).apply{text="BEN + AI • EXAM INTELLIGENCE";textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(activity))})
        outer.addView(TextView(activity).apply{text="${currentBenExamProfile(activity).label} • local evidence first • optional Free AI or Google Search";textSize=11.5f;setTextColor(ThemeManager.muted(activity));setPadding(0,dp(activity,3),0,dp(activity,6))})
        outer.addView(TextView(activity).apply{text=AppManagers.renMemory.questionAiContextLabel();textSize=10f;setTextColor(ThemeManager.accent(activity));setPadding(0,0,0,dp(activity,7))})
        val tabs=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL}
        val rows=listOf(listOf(BenQuestionAiMode.PYQ_CONTEXT,BenQuestionAiMode.PYT_CONTEXT),listOf(BenQuestionAiMode.FUTURE_RELATED,BenQuestionAiMode.OTHER_OPTIONS))
        val modeViews=linkedMapOf<BenQuestionAiMode,TextView>()
        var activeMode=AppManagers.renMemory.questionAiContextMode()
        fun renderTabState(){modeViews.forEach{(mode,v)->val selected=mode==activeMode;v.background=UiDrawableUtils.roundedDrawable(activity,if(selected)ThemeManager.accent(activity) else ThemeManager.elevated(activity),14f);v.setTextColor(if(selected)Color.WHITE else ThemeManager.text(activity))}}
        rows.forEachIndexed{ri,rowModes->val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL};rowModes.forEachIndexed{ci,mode->val v=TextView(activity).apply{text=mode.label;textSize=9.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(dp(activity,5),0,dp(activity,5),0)};modeViews[mode]=v;row.addView(v,LinearLayout.LayoutParams(0,dp(activity,40),1f).apply{if(ci>0)setMargins(dp(activity,5),0,0,0)})};tabs.addView(row,LinearLayout.LayoutParams(-1,dp(activity,40)).apply{if(ri>0)setMargins(0,dp(activity,5),0,0)})}
        outer.addView(tabs)
        val bodyScroll=ScrollView(activity).apply{isFillViewport=true}
        val body=TextView(activity).apply{text="Preparing local evidence…";textSize=14.5f;setTextColor(ThemeManager.text(activity));setLineSpacing(0f,1.18f);setPadding(dp(activity,2),dp(activity,12),dp(activity,2),dp(activity,10));setTextIsSelectable(true)}
        bodyScroll.addView(body);outer.addView(bodyScroll,LinearLayout.LayoutParams(-1,0,1f))
        val actions=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL}
        val save=TextView(activity).apply{text="SAVE CONTEXT";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));background=UiDrawableUtils.roundedDrawable(activity,ThemeManager.explanationBg(activity),12f);setOnClickListener{AppManagers.renMemory.saveQuestionAiContext(activeMode,q.id);text="SAVED ✓"}}
        val free=TextView(activity).apply{text="RUN FREE AI";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));background=UiDrawableUtils.roundedDrawable(activity,ThemeManager.explanationBg(activity),12f);setOnClickListener{renderFree(activity,dialog,body,activeMode,q,selectedOption)}}
        val close=TextView(activity).apply{text="CLOSE";textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(activity));background=UiDrawableUtils.roundedDrawable(activity,ThemeManager.elevated(activity),12f);setOnClickListener{dialog.dismiss()}}
        actions.addView(save,LinearLayout.LayoutParams(0,dp(activity,42),1f).apply{setMargins(0,0,dp(activity,4),0)});actions.addView(free,LinearLayout.LayoutParams(0,dp(activity,42),1f).apply{setMargins(dp(activity,4),0,dp(activity,4),0)});actions.addView(close,LinearLayout.LayoutParams(0,dp(activity,42),1f).apply{setMargins(dp(activity,4),0,0,0)})
        outer.addView(actions)
        modeViews.forEach{(mode,v)->v.setOnClickListener{activeMode=mode;AppManagers.renMemory.saveQuestionAiContext(mode,q.id);renderTabState();renderLocal(activity,dialog,body,mode,q)}}
        val google=TextView(activity).apply{text="GOOGLE SEARCH • OPEN IN ROVEX";textSize=10f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(ThemeManager.accent(activity));setPadding(0,dp(activity,7),0,dp(activity,4));setOnClickListener{val query="${currentBenExamProfile(activity).label} ${q.text} ${activeMode.prompt} Options: ${q.options.joinToString(" | "){it.label+" "+it.text.take(400)}}";activity.startActivity(android.content.Intent(activity,GoogleSearchActivity::class.java).putExtra("query",query))}}
        outer.addView(google)
        dialog.setContentView(outer);dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);dialog.show();dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels*.94f).toInt(),(activity.resources.displayMetrics.heightPixels*.80f).toInt())
        renderTabState();renderLocal(activity,dialog,body,activeMode,q)
    }
    private fun renderLocal(activity:QuizActivity,dialog:Dialog,body:TextView,mode:BenQuestionAiMode,q:Question){activity.lifecycleScope.launch(Dispatchers.IO){val context=runCatching{AppManagers.frankensteinContext.buildEnhanced(q)}.getOrNull();val text=buildString{append("${mode.label}\n\nQUESTION\n").append(q.text).append("\n\nLOCAL EVIDENCE\n");if(context!=null){append(context.summary).append('\n');if(context.relatedSources.isNotEmpty())append("Sources: ").append(context.relatedSources.joinToString(" • ")).append('\n');context.relatedQuestions.take(8).forEachIndexed{i,r->append("[LOCAL-${i+1}] ${r.exam} / ${r.source}\n${r.text.take(500)}\nKEY: ${r.answer.take(180)}\n")}}else append("No local evidence available.\n");append("\nTASK\n").append(mode.prompt).append("\n\nEXAM PROFILE\n").append(currentBenExamProfile(activity).label)};activity.runOnUiThread{if(dialog.isShowing)body.text=rovexMarkdownToSpanned(text)}}}
    private fun renderFree(activity:QuizActivity,dialog:Dialog,body:TextView,mode:BenQuestionAiMode,q:Question,selectedOption:String?){body.text="Building the bounded question/options packet and sending it to the selected Free AI provider…";activity.lifecycleScope.launch(Dispatchers.IO){val packet=ContextPackBuilder(activity).forQuestion(q,selectedOption,task=mode.prompt).toPromptBlock();val result=AppManagers.cloudAi.generate(packet,"You are Ben's free cloud exam-reasoning accelerator. Be concise, medically cautious and exam-oriented. The supplied QBank key is authoritative. ${mode.prompt}",1800);val text=result?.let{"${it.text}\n\n[${it.provider.label} • ${it.model}]"}?:"No Free AI provider is connected. Open the FREE AI menu in Dr. Frankenstein or Settings → Adaptive Engines.";activity.runOnUiThread{if(dialog.isShowing)body.text=rovexMarkdownToSpanned(text)}}}
    private fun dp(a:QuizActivity,v:Int)= (v*a.resources.displayMetrics.density).toInt()
}
