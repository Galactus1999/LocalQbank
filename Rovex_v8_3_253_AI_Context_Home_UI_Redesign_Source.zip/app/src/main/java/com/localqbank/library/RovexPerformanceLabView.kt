package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

/** Compact analytical infographic: three graded health bands with a live pulse. */
class RovexPerformanceLabView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var health=0; private var resilience=0; private var ram=0
    fun setScores(health:Int,resilience:Int,ram:Int){this.health=health.coerceIn(0,100);this.resilience=resilience.coerceIn(0,100);this.ram=ram.coerceIn(0,100);invalidate()}
    override fun onDraw(c:Canvas){
        val w=width.toFloat(); val h=height.toFloat(); if(w<=0||h<=0)return
        val dark=ThemeManager.isDark(context)
        p.strokeWidth=1f
        val labels=arrayOf("HEALTH" to health,"RESILIENCE" to resilience,"RAM" to ram)
        val left=10f; val right=w-10f; val bw=right-left
        labels.forEachIndexed{idx,pair->
            val y=16f+idx*22f
            p.color=if(dark)0xFF26313C.toInt() else 0xFFDDE5E9.toInt();c.drawRoundRect(left,y,right,y+7f,5f,5f,p)
            val score=pair.second/100f
            val tint=when{pair.second>=80->0xFF43C58A.toInt();pair.second>=60->0xFFE6B34A.toInt();else->0xFFE06B63.toInt()}
            p.color=tint;c.drawRoundRect(left,y,left+bw*score,y+7f,5f,5f,p)
            p.color=if(dark)0xFFE7EDF2.toInt() else 0xFF33404A.toInt();p.textSize=9f;c.drawText("${pair.first}  ${pair.second}%",left,y-3f,p)
        }
        p.color=ThemeManager.accent(context);p.textSize=8f;c.drawText("LIVE • graded resource state",left,h-4f,p)
    }
}
