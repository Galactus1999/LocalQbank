package com.localqbank.library

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** In-app Google evidence surface. Keeps user-initiated search inside Rovex instead of ACTION_VIEW. */
class GoogleSearchActivity : AppCompatActivity() {
    private lateinit var web: WebView
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val query=intent.getStringExtra("query").orEmpty().trim().ifBlank{"medical study question"}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=ThemeManager.backgroundDrawable(this@GoogleSearchActivity)}
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(5),dp(8),dp(5))}
        bar.addView(TextView(this).apply{text="‹";textSize=30f;gravity=Gravity.CENTER;setTextColor(ThemeManager.text(this@GoogleSearchActivity));setOnClickListener{finish()}},LinearLayout.LayoutParams(dp(44),dp(42)))
        bar.addView(TextView(this).apply{text="GOOGLE SEARCH";textSize=15f;typeface=android.graphics.Typeface.DEFAULT_BOLD;setTextColor(ThemeManager.text(this@GoogleSearchActivity))},LinearLayout.LayoutParams(0,dp(42),1f))
        root.addView(bar)
        web=WebView(this).apply{
            setBackgroundColor(if(ThemeManager.get(this@GoogleSearchActivity)==ThemeManager.AMOLED)Color.BLACK else Color.WHITE)
            settings.javaScriptEnabled=true
            settings.domStorageEnabled=true
            settings.loadsImagesAutomatically=true
            settings.userAgentString=settings.userAgentString+" RovexGoogleSearch/1.0"
            webViewClient=object:WebViewClient(){override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean{return false}}
            webChromeClient=WebChromeClient()
        }
        root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
        web.loadUrl("https://www.google.com/search?q="+java.net.URLEncoder.encode(query,"UTF-8"))
    }
    override fun onBackPressed(){if(::web.isInitialized&&web.canGoBack())web.goBack()else super.onBackPressed()}
    override fun onDestroy(){if(::web.isInitialized){web.stopLoading();web.destroy()};super.onDestroy()}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
