package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

/** Lightweight decorative animation drawn over the search bar; it never handles input. */
class RovexSearchChaseView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var started = 0L
    private val cycle = 5200L

    override fun onAttachedToWindow() { super.onAttachedToWindow(); started = SystemClock.uptimeMillis(); postInvalidateOnAnimation() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); if (w <= 0 || h <= 0) return
        val t = ((SystemClock.uptimeMillis() - started) % cycle).toFloat() / cycle
        val u = ((t * 1.35f) % 1f)
        val deerX = w * (0.18f + 0.62f * u)
        val tigerX = deerX - w * 0.16f
        val y = h * (0.52f + 0.06f * sin(t * Math.PI * 8).toFloat())
        drawAnimal(c, deerX, y, true)
        drawAnimal(c, tigerX, y + h * .03f, false)
        postInvalidateOnAnimation()
    }

    private fun drawAnimal(c: Canvas, x: Float, y: Float, deer: Boolean) {
        val dark = ThemeManager.isDark(context)
        p.color = if (deer) (if (dark) 0xFFFFC56E.toInt() else 0xFF8A542C.toInt()) else (if (dark) 0xFFFFA95E.toInt() else 0xFF5D3B2A.toInt())
        c.save()
        c.translate(x, y)
        val scale = width / 420f
        c.scale(scale, scale)
        // body/head/legs: intentionally icon-like so the animation remains cheap.
        c.drawOval(-20f, -7f, 18f, 7f, p)
        c.drawCircle(23f, -8f, 6f, p)
        stroke.color = p.color; stroke.strokeWidth = 2.5f
        c.drawLine(-12f, 5f, -15f, 15f, stroke); c.drawLine(5f, 5f, 8f, 15f, stroke)
        c.drawLine(14f, 4f, 18f, 14f, stroke); c.drawLine(-18f, 2f, -28f, -5f, stroke)
        if (deer) {
            c.drawLine(25f, -13f, 29f, -21f, stroke); c.drawLine(28f, -20f, 24f, -24f, stroke); c.drawLine(29f, -20f, 34f, -23f, stroke)
            c.drawLine(25f, -13f, 21f, -21f, stroke)
        } else {
            c.drawLine(27f, -8f, 34f, -6f, stroke); c.drawLine(-24f, -2f, -31f, 2f, stroke)
        }
        c.restore()
    }
}
