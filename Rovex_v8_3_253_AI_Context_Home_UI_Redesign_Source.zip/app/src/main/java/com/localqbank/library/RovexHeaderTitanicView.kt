package com.localqbank.library

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

/** Small stylized ocean liner animation for the Rovex header; no external artwork/assets. */
class RovexHeaderTitanicView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var started = 0L
    private val cycle = 7600L
    override fun onAttachedToWindow() { super.onAttachedToWindow(); started = SystemClock.uptimeMillis(); postInvalidateOnAnimation() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); if (w <= 0 || h <= 0) return
        val t = ((SystemClock.uptimeMillis() - started) % cycle).toFloat() / cycle
        val x = w * (1.16f - 1.45f * t)
        val water = if (ThemeManager.isDark(context)) 0xFF4AA9D8.toInt() else 0xFF4386A8.toInt()
        p.color = water; p.strokeWidth = 1.5f; p.style = Paint.Style.STROKE
        for (i in 0..2) {
            val yy = h * (.73f + i * .09f)
            c.drawArc(-w*.1f, yy, w*1.1f, yy+h*.22f, 180f, 180f, false, p)
        }
        p.style = Paint.Style.FILL
        c.save(); c.translate(x, h*.52f + sin(t*6.28f).toFloat()*1.2f)
        p.color = if (ThemeManager.isDark(context)) 0xFFE9EDF2.toInt() else 0xFF39454F.toInt()
        c.drawRoundRect(-34f, -6f, 34f, 5f, 4f, 4f, p)
        p.color = if (ThemeManager.isDark(context)) 0xFFFFD27A.toInt() else 0xFFB34E32.toInt()
        c.drawRect(-28f, 4f, 27f, 8f, p)
        p.color = if (ThemeManager.isDark(context)) 0xFFF5F7FA.toInt() else 0xFFEFE6D8.toInt()
        c.drawRect(-17f, -13f, 17f, -6f, p)
        p.color = if (ThemeManager.isDark(context)) 0xFFDC5B5B.toInt() else 0xFF8C3B2C.toInt()
        c.drawRect(-17f, -20f, -12f, -12f, p); c.drawRect(-5f, -20f, 0f, -12f, p); c.drawRect(7f, -20f, 12f, -12f, p)
        c.restore()
        postInvalidateOnAnimation()
    }
}
