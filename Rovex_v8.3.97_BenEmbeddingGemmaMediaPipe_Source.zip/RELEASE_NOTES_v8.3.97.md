# Rovex v8.3.97 — EmbeddingGemma MediaPipe Compatibility Fix

- Replaced the experimental GeckoEmbeddingModel/LocalAgents RAG compatibility route.
- Restored the resolvable `com.google.mediapipe:tasks-text:0.10.35` dependency.
- EmbeddingGemma 300M is executed through the stable TextEmbedder surface with explicit official query/document formatting because TextFormatContext is unavailable in the pinned artifact.
- Kept CPU-first, background execution, resource-governor gating, bounded text, lifecycle close, and deterministic fallback.
- Adaptive Engine/Model Lab now surface the actual last EmbeddingGemma failure reason instead of a misleading generic unavailable message.
- VersionCode 195 / versionName 8.3.97.
