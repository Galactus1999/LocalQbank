package com.localqbank.library

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RovexFriendRequestStateTest {
    @Test fun normalizesAndValidatesRovexIds() {
        assertTrue(RovexFriendRequestState.isValidCode(" rvx-abcd-1234 "))
        assertFalse(RovexFriendRequestState.isValidCode("RVX-ABC-1234"))
        assertFalse(RovexFriendRequestState.isValidCode("RVX-ABCD-12345"))
    }

    @Test fun queuesOnlyTransientFailures() {
        assertTrue(RovexFriendRequestState.shouldQueueAfterFailure("Failed to get document because the client is offline."))
        assertTrue(RovexFriendRequestState.shouldQueueAfterFailure("DEADLINE_EXCEEDED"))
        assertFalse(RovexFriendRequestState.shouldQueueAfterFailure("Rovex ID not found."))
    }
}
