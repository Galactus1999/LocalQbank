package com.localqbank.library

/** Pure rules for friend-request intent. No Android/Firebase dependency. */
object RovexFriendRequestState {
    private val pattern = Regex("RVX-[A-Z0-9]{4}-[A-Z0-9]{4}")

    fun normalize(raw: String): String = raw.trim().uppercase(java.util.Locale.US)

    fun isValidCode(raw: String): Boolean = pattern.matches(normalize(raw))

    fun shouldQueueAfterFailure(message: String?): Boolean {
        val m = message.orEmpty()
        return listOf("UNAVAILABLE", "DEADLINE_EXCEEDED", "network", "offline", "client is offline", "failed to get document")
            .any { m.contains(it, ignoreCase = true) }
    }
}
